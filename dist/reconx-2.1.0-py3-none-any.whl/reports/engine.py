import json
import csv
import io

class ReportEngine:
    def generate_json(self, data: dict) -> str:
        return json.dumps(data, indent=2)
        
    def generate_csv(self, data: list) -> str:
        if not data:
            return ""
        output = io.StringIO()
        writer = csv.DictWriter(output, fieldnames=data[0].keys())
        writer.writeheader()
        writer.writerows(data)
        return output.getvalue()
        
    def generate_markdown(self, title: str, data: dict) -> str:
        md = f"# {title}\n\n"
        for k, v in data.items():
            md += f"## {k}\n{v}\n\n"
        return md

    def generate_html(self, title: str, data: dict) -> str:
        html = f"<html><head><title>{title}</title></head><body><h1>{title}</h1>"
        for k, v in data.items():
            html += f"<h2>{k}</h2><p>{v}</p>"
        html += "</body></html>"
        return html

report_engine = ReportEngine()
