# Core Architecture
See Overview.