# Testing
`pytest --cov=src`