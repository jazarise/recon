"""
tests/test_stage1.py

Stage 1 test suite for Spectre.

Tests cover:
- Configuration loading and validation
- Session creation, persistence, and restoration
- Plugin base class contract
- Plugin registry discovery
- Application bootstrap

Run with:
    pytest tests/ -v

Note: These tests use only stdlib — no external dependencies required.
      Full test execution requires: pip install pydantic pyyaml loguru typer rich python-dotenv
"""

from __future__ import annotations

import json
import os
import sys
import tempfile
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

# ---------------------------------------------------------------------------
# Ensure the spectre package is importable from the project root
# ---------------------------------------------------------------------------
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


# ===========================================================================
# Configuration Tests
# ===========================================================================

class TestSettings:
    """Test Pydantic settings models."""

    def test_app_settings_defaults(self):
        from spectre.core.settings import AppSettings
        s = AppSettings()
        assert s.name == "Spectre"
        assert s.version == "0.1.0"
        assert s.environment == "development"
        assert s.debug is True

    def test_app_settings_invalid_environment(self):
        from spectre.core.settings import AppSettings
        import pydantic
        with pytest.raises(pydantic.ValidationError):
            AppSettings(environment="staging")

    def test_workspace_settings_paths_are_path_objects(self):
        from spectre.core.settings import WorkspaceSettings
        s = WorkspaceSettings()
        assert isinstance(s.base_path, Path)
        assert isinstance(s.logs_path, Path)

    def test_logging_settings_level_uppercased(self):
        from spectre.core.settings import LoggingSettings
        s = LoggingSettings(level="info")
        assert s.level == "INFO"

    def test_logging_settings_invalid_level(self):
        from spectre.core.settings import LoggingSettings
        import pydantic
        with pytest.raises(pydantic.ValidationError):
            LoggingSettings(level="VERBOSE")

    def test_threading_settings_bounds(self):
        from spectre.core.settings import ThreadingSettings
        import pydantic
        with pytest.raises(pydantic.ValidationError):
            ThreadingSettings(max_threads=0)

    def test_spectre_settings_assembles_all_sub_models(self):
        from spectre.core.settings import SpectreSettings
        s = SpectreSettings()
        assert s.app.name == "Spectre"
        assert s.session.auto_save is True
        assert s.threading.max_threads == 10


class TestConfigLoader:
    """Test YAML config loading and environment variable overrides."""

    def test_load_config_returns_settings(self, tmp_path, monkeypatch):
        from spectre.core import config as cfg_mod

        # Point config dir at a temp dir with a minimal default.yaml
        config_dir = tmp_path / "config"
        config_dir.mkdir()
        (config_dir / "default.yaml").write_text("app:\n  debug: true\n")

        monkeypatch.setattr(cfg_mod, "_CONFIG_DIR", config_dir)
        monkeypatch.setenv("SPECTRE_ENV", "development")
        cfg_mod.get_settings.cache_clear()

        settings = cfg_mod.load_config("development")
        assert settings.app.name == "Spectre"

    def test_deep_merge(self):
        from spectre.core.config import _deep_merge
        base = {"a": 1, "b": {"x": 10, "y": 20}}
        override = {"b": {"y": 99, "z": 30}, "c": 3}
        result = _deep_merge(base, override)
        assert result["a"] == 1
        assert result["b"]["x"] == 10   # preserved
        assert result["b"]["y"] == 99   # overridden
        assert result["b"]["z"] == 30   # new key added
        assert result["c"] == 3

    def test_coerce_booleans(self):
        from spectre.core.config import _coerce
        assert _coerce("true") is True
        assert _coerce("false") is False
        assert _coerce("True") is True

    def test_coerce_integers(self):
        from spectre.core.config import _coerce
        assert _coerce("42") == 42
        assert isinstance(_coerce("42"), int)

    def test_coerce_strings_unchanged(self):
        from spectre.core.config import _coerce
        assert _coerce("INFO") == "INFO"
        assert _coerce("./sessions") == "./sessions"

    def test_env_overrides_applied(self, monkeypatch, tmp_path):
        from spectre.core import config as cfg_mod

        config_dir = tmp_path / "config"
        config_dir.mkdir()
        (config_dir / "default.yaml").write_text("logging:\n  level: DEBUG\n")

        monkeypatch.setattr(cfg_mod, "_CONFIG_DIR", config_dir)
        monkeypatch.setenv("SPECTRE_LOGGING_LEVEL", "WARNING")
        cfg_mod.get_settings.cache_clear()

        settings = cfg_mod.load_config("development")
        assert settings.logging.level == "WARNING"


# ===========================================================================
# Session Tests
# ===========================================================================

class TestSessionModel:
    """Test Session and SessionMeta Pydantic models."""

    def test_session_default_id_is_uuid(self):
        from spectre.sessions.models import Session
        s = Session()
        assert len(s.id) == 36
        assert s.id.count("-") == 4

    def test_session_status_default_active(self):
        from spectre.sessions.models import Session, SessionStatus
        s = Session()
        assert s.status == SessionStatus.ACTIVE

    def test_session_touch_updates_timestamp(self):
        from spectre.sessions.models import Session
        import time
        s = Session()
        original = s.updated_at
        time.sleep(0.01)
        s.touch()
        assert s.updated_at > original

    def test_session_to_summary_keys(self):
        from spectre.sessions.models import Session
        s = Session(name="TestChallenge", target="10.0.0.1")
        summary = s.to_summary()
        expected_keys = {"id", "name", "target", "status", "category", "created"}
        assert set(summary.keys()) == expected_keys

    def test_session_serializes_to_json(self):
        from spectre.sessions.models import Session
        s = Session(name="Test", target="ctf.example.com")
        raw = s.model_dump_json()
        data = json.loads(raw)
        assert data["name"] == "Test"
        assert data["target"] == "ctf.example.com"

    def test_session_roundtrip_json(self):
        from spectre.sessions.models import Session
        s = Session(name="Roundtrip", target="192.168.1.1")
        raw = s.model_dump_json()
        restored = Session.model_validate_json(raw)
        assert restored.id == s.id
        assert restored.name == s.name
        assert restored.target == s.target


class TestSessionManager:
    """Test SessionManager CRUD and persistence."""

    @pytest.fixture
    def manager(self, tmp_path):
        from spectre.core.settings import SpectreSettings, WorkspaceSettings
        settings = SpectreSettings(
            workspace=WorkspaceSettings(
                base_path=tmp_path / "sessions",
                logs_path=tmp_path / "logs",
                datasets_path=tmp_path / "datasets",
                plugins_path=tmp_path / "plugins",
            )
        )
        from spectre.sessions.manager import SessionManager
        return SessionManager(settings=settings)

    def test_create_session_returns_session(self, manager):
        s = manager.create_session(name="Challenge1", target="10.0.0.1")
        assert s.name == "Challenge1"
        assert s.target == "10.0.0.1"

    def test_create_session_writes_file(self, manager, tmp_path):
        s = manager.create_session(name="PersistTest")
        path = tmp_path / "sessions" / s.id / "session.json"
        assert path.exists()

    def test_get_session_returns_correct_session(self, manager):
        s = manager.create_session(name="GetTest")
        retrieved = manager.get_session(s.id)
        assert retrieved is not None
        assert retrieved.id == s.id

    def test_get_session_unknown_id_returns_none(self, manager):
        result = manager.get_session("nonexistent-id")
        assert result is None

    def test_list_sessions_reflects_created_sessions(self, manager):
        manager.create_session(name="A")
        manager.create_session(name="B")
        manager.create_session(name="C")
        sessions = manager.list_sessions()
        assert len(sessions) == 3

    def test_save_session_updates_file(self, manager, tmp_path):
        s = manager.create_session(name="SaveTest")
        s.meta.notes = "Updated note"
        result = manager.save_session(s.id)
        assert result is True
        path = tmp_path / "sessions" / s.id / "session.json"
        data = json.loads(path.read_text())
        assert data["meta"]["notes"] == "Updated note"

    def test_save_unknown_session_returns_false(self, manager):
        result = manager.save_session("bad-id")
        assert result is False

    def test_restore_session_from_disk(self, manager):
        s = manager.create_session(name="RestoreTest", target="restore.target")
        # Simulate fresh manager (empty in-memory state)
        manager._sessions.clear()
        assert manager.get_session(s.id) is None

        restored = manager.restore_session(s.id)
        assert restored is not None
        assert restored.name == "RestoreTest"
        assert restored.target == "restore.target"

    def test_restore_nonexistent_session_returns_none(self, manager):
        result = manager.restore_session("does-not-exist")
        assert result is None

    def test_delete_session_archives_it(self, manager):
        from spectre.sessions.models import SessionStatus
        s = manager.create_session(name="DeleteMe")
        result = manager.delete_session(s.id)
        assert result is True
        assert manager.get_session(s.id) is None

    def test_save_all_persists_all_sessions(self, manager, tmp_path):
        s1 = manager.create_session(name="SaveAll1")
        s2 = manager.create_session(name="SaveAll2")
        manager.save_all()
        for s in [s1, s2]:
            path = tmp_path / "sessions" / s.id / "session.json"
            assert path.exists()

    def test_active_sessions_filters_correctly(self, manager):
        from spectre.sessions.models import SessionStatus
        s1 = manager.create_session(name="Active")
        s2 = manager.create_session(name="Completed")
        s2.status = SessionStatus.COMPLETED
        active = manager.active_sessions()
        ids = [s.id for s in active]
        assert s1.id in ids
        assert s2.id not in ids


# ===========================================================================
# Plugin Tests
# ===========================================================================

class TestPluginBase:
    """Test SpectrePlugin abstract base class contract."""

    def test_cannot_instantiate_abstract_plugin(self):
        from spectre.plugins.base import SpectrePlugin
        with pytest.raises(TypeError):
            SpectrePlugin()

    def test_concrete_plugin_implements_contract(self):
        from spectre.plugins.base import PluginCategory, SpectrePlugin

        class TestPlugin(SpectrePlugin):
            @property
            def name(self): return "test_plugin"
            @property
            def version(self): return "1.0.0"
            @property
            def category(self): return PluginCategory.MISC
            def load(self): self._loaded = True

        p = TestPlugin()
        p.load()
        assert p.name == "test_plugin"
        assert p.version == "1.0.0"
        assert p.is_loaded is True
        assert p.is_enabled is True

    def test_plugin_disable_enable(self):
        from spectre.plugins.base import PluginCategory, SpectrePlugin

        class TestPlugin(SpectrePlugin):
            @property
            def name(self): return "toggle_plugin"
            @property
            def version(self): return "1.0.0"
            @property
            def category(self): return PluginCategory.MISC
            def load(self): pass

        p = TestPlugin()
        p.disable()
        assert p.is_enabled is False
        p.enable()
        assert p.is_enabled is True

    def test_plugin_describe_returns_dict(self):
        from spectre.plugins.base import PluginCategory, SpectrePlugin

        class TestPlugin(SpectrePlugin):
            @property
            def name(self): return "describe_plugin"
            @property
            def version(self): return "2.0.0"
            @property
            def category(self): return PluginCategory.WEB
            def load(self): pass

        p = TestPlugin()
        desc = p.describe()
        assert desc["name"] == "describe_plugin"
        assert desc["version"] == "2.0.0"
        assert desc["category"] == PluginCategory.WEB

    def test_plugin_execute_returns_plugin_result(self):
        from spectre.plugins.base import PluginCategory, SpectrePlugin

        class TestPlugin(SpectrePlugin):
            @property
            def name(self): return "exec_plugin"
            @property
            def version(self): return "1.0.0"
            @property
            def category(self): return PluginCategory.MISC
            def load(self): pass

        p = TestPlugin()
        result = p.execute()
        assert result.plugin_name == "exec_plugin"
        assert result.success is False   # Stage 1 stub always returns False


class TestPluginRegistry:
    """Test PluginRegistry discovery and management."""

    @pytest.fixture
    def registry(self, tmp_path):
        from spectre.core.settings import SpectreSettings, WorkspaceSettings
        settings = SpectreSettings(
            workspace=WorkspaceSettings(
                base_path=tmp_path / "sessions",
                logs_path=tmp_path / "logs",
                datasets_path=tmp_path / "datasets",
                plugins_path=tmp_path / "plugins",
            )
        )
        from spectre.plugins.registry import PluginRegistry
        return PluginRegistry(settings=settings)

    def test_registry_starts_empty(self, registry):
        assert len(registry.plugins) == 0

    def test_get_unknown_plugin_returns_none(self, registry):
        assert registry.get("ghost") is None

    def test_unload_all_clears_plugins(self, registry):
        from spectre.plugins.base import PluginCategory, SpectrePlugin

        class DummyPlugin(SpectrePlugin):
            @property
            def name(self): return "dummy"
            @property
            def version(self): return "0.1"
            @property
            def category(self): return PluginCategory.MISC
            def load(self): self._loaded = True

        instance = DummyPlugin()
        instance.load()
        registry.plugins["dummy"] = instance
        assert len(registry.plugins) == 1

        registry.unload_all()
        assert len(registry.plugins) == 0


class TestConcretePluginStubs:
    """Test that shipped plugin stubs load without errors."""

    def _make_settings(self, tmp_path):
        from spectre.core.settings import SpectreSettings, WorkspaceSettings
        return SpectreSettings(
            workspace=WorkspaceSettings(
                base_path=tmp_path / "sessions",
                logs_path=tmp_path / "logs",
                datasets_path=tmp_path / "datasets",
                plugins_path=tmp_path / "plugins",
            )
        )

    def test_web_plugin_loads(self, tmp_path, capsys):
        from spectre.plugins.web.plugin import WebPlugin
        p = WebPlugin()
        p.load()
        p._loaded = True
        assert p.name == "web"
        assert p.category.value == "web"

    def test_crypto_plugin_loads(self, tmp_path):
        from spectre.plugins.crypto import CryptoPlugin
        p = CryptoPlugin()
        p.load()
        p._loaded = True
        assert p.name == "crypto"

    def test_smb_plugin_loads(self, tmp_path):
        from spectre.plugins.smb import SmbPlugin
        p = SmbPlugin()
        p.load()
        p._loaded = True
        assert p.name == "smb"

    def test_ssh_plugin_loads(self, tmp_path):
        from spectre.plugins.ssh import SshPlugin
        p = SshPlugin()
        p.load()
        p._loaded = True
        assert p.name == "ssh"

    def test_stego_plugin_loads(self, tmp_path):
        from spectre.plugins.stego import StegoPlugin
        p = StegoPlugin()
        p.load()
        p._loaded = True
        assert p.name == "stego"

    def test_forensics_plugin_loads(self, tmp_path):
        from spectre.plugins.forensics import ForensicsPlugin
        p = ForensicsPlugin()
        p.load()
        p._loaded = True
        assert p.name == "forensics"

    def test_all_stubs_return_failed_result(self):
        """All Stage 1 stubs should return success=False from execute()."""
        from spectre.plugins.web.plugin import WebPlugin
        from spectre.plugins.crypto import CryptoPlugin
        from spectre.plugins.smb import SmbPlugin

        for cls in [WebPlugin, CryptoPlugin, SmbPlugin]:
            p = cls()
            result = p.execute()
            assert result.success is False, f"{cls.__name__}.execute() should return success=False in Stage 1"
