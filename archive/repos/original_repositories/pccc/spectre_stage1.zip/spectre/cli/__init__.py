"""spectre.cli — Typer CLI package."""

from spectre.cli.main import app

__all__ = ["app"]
