"""
spectre/cli/main.py

Typer-based CLI for Spectre.

Commands (Stage 1):
    spectre start           — Initialize Spectre and show status
    spectre status          — Show current application status
    spectre session list    — List all sessions
    spectre session new     — Create a new session
    spectre session show    — Show details of a specific session
    spectre plugin list     — List all loaded plugins

TODO Stage 2: Add `spectre run` to trigger agent workflows
TODO Stage 3: Add `spectre graph` commands for knowledge graph queries
TODO Stage 4: Add `spectre memory` commands
"""

from __future__ import annotations

from typing import Optional

import typer
from rich import box
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from spectre.core.app import SpectreApp
from spectre.core.config import get_settings

# ---------------------------------------------------------------------------
# CLI app and console
# ---------------------------------------------------------------------------

app = typer.Typer(
    name="spectre",
    help="[bold cyan]Spectre[/bold cyan] — AI-powered CTF assistant platform.",
    rich_markup_mode="rich",
    no_args_is_help=True,
)

session_app = typer.Typer(help="Session management commands.")
plugin_app = typer.Typer(help="Plugin management commands.")

app.add_typer(session_app, name="session")
app.add_typer(plugin_app, name="plugin")

console = Console()

# Module-level app instance (lazy-initialized)
_spectre: Optional[SpectreApp] = None


def _get_app() -> SpectreApp:
    """Return the initialized SpectreApp singleton."""
    global _spectre
    if _spectre is None:
        _spectre = SpectreApp()
        _spectre.initialize()
    return _spectre


# ---------------------------------------------------------------------------
# Shared UI helpers
# ---------------------------------------------------------------------------

def _print_banner() -> None:
    banner = Text()
    banner.append("  ██████  ██▓███  ▓█████  ▄████▄  ▄▄▄█████▓ ██▀███  ▓█████ \n", style="bold cyan")
    banner.append("▒██    ▒ ▓██░  ██▒▓█   ▀ ▒██▀ ▀█  ▓  ██▒ ▓▒▓██ ▒ ██▒▓█   ▀ \n", style="cyan")
    banner.append("░ ▓██▄   ▓██░ ██▓▒▒███   ▒▓█    ▄ ▒ ▓██░ ▒░▓██ ░▄█ ▒▒███   \n", style="blue")
    banner.append("  ▒   ██▒▒██▄█▓▒ ▒▒▓█  ▄ ▒▓▓▄ ▄██▒░ ▓██▓ ░ ▒██▀▀█▄  ▒▓█  ▄ \n", style="blue")
    banner.append("▒██████▒▒▒██▒ ░  ░░▒████▒▒ ▓███▀ ░  ▒██▒ ░ ░██▓ ▒██▒░▒████▒\n", style="bold blue")
    banner.append("▒ ▒▓▒ ▒ ░▒▓▒░ ░  ░░░ ▒░ ░░ ░▒ ▒  ░  ▒ ░░   ░ ▒▓ ░▒▓░░░ ▒░ ░\n", style="dim")
    banner.append("  AI-Powered CTF Intelligence Platform  |  Stage 1\n", style="bold white")
    console.print(Panel(banner, border_style="cyan", padding=(0, 2)))


def _status_table(status: dict) -> Table:
    """Render the application status as a Rich table."""
    table = Table(box=box.ROUNDED, border_style="cyan", show_header=False, padding=(0, 2))
    table.add_column("Key", style="bold cyan", width=20)
    table.add_column("Value", style="white")

    table.add_row("Application", f"{status['app']} v{status['version']}")
    table.add_row("Environment", status["environment"])
    table.add_row("Status", "[green]Ready[/green]" if status["ready"] else "[red]Not Ready[/red]")
    table.add_row("Sessions (active)", str(status["sessions"]["active"]))
    table.add_row("Sessions (total)", str(status["sessions"]["total"]))
    table.add_row("Plugins loaded", str(status["plugins"]["loaded"]))
    table.add_row("Log level", status["logging"]["level"])
    table.add_row("Log file", status["logging"]["file"])
    return table


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------

@app.command("start")
def cmd_start() -> None:
    """Initialize Spectre and display startup status."""
    _print_banner()

    with console.status("[cyan]Initializing Spectre...[/cyan]", spinner="dots"):
        spectre = _get_app()

    status = spectre.status()

    console.print()
    console.print(Panel(
        _status_table(status),
        title="[bold cyan]Spectre Status[/bold cyan]",
        border_style="cyan",
    ))

    console.print()
    console.print("[bold green]✓[/bold green] [bold white]Spectre initialized[/bold white]")
    console.print(f"  Session:       [green]active[/green]")
    console.print(f"  Plugins:       [green]{status['plugins']['loaded']} loaded[/green]")
    console.print(f"  Logging:       [green]enabled[/green]")
    console.print(f"  Configuration: [green]loaded ({spectre.settings.app.environment})[/green]")
    console.print()


@app.command("status")
def cmd_status() -> None:
    """Show current application status."""
    with console.status("[cyan]Fetching status...[/cyan]", spinner="dots"):
        spectre = _get_app()
        status = spectre.status()

    console.print(Panel(
        _status_table(status),
        title="[bold cyan]Spectre Status[/bold cyan]",
        border_style="cyan",
    ))


# ---------------------------------------------------------------------------
# Session subcommands
# ---------------------------------------------------------------------------

@session_app.command("list")
def session_list() -> None:
    """List all sessions."""
    spectre = _get_app()
    sessions = spectre.session_manager.list_sessions()

    if not sessions:
        console.print("[yellow]No sessions found.[/yellow]")
        console.print("  Create one with: [cyan]spectre session new[/cyan]")
        return

    table = Table(
        title="Sessions",
        box=box.ROUNDED,
        border_style="cyan",
        header_style="bold cyan",
    )
    table.add_column("ID", width=10)
    table.add_column("Name", width=24)
    table.add_column("Target", width=20)
    table.add_column("Category", width=12)
    table.add_column("Status", width=12)
    table.add_column("Created", width=18)

    status_colors = {
        "active": "green",
        "paused": "yellow",
        "completed": "blue",
        "archived": "dim",
        "error": "red",
    }

    for s in sessions:
        summary = s.to_summary()
        color = status_colors.get(summary["status"], "white")
        table.add_row(
            summary["id"],
            summary["name"],
            summary["target"],
            summary["category"],
            f"[{color}]{summary['status']}[/{color}]",
            summary["created"],
        )

    console.print(table)


@session_app.command("new")
def session_new(
    name: str = typer.Option("Unnamed Session", "--name", "-n", help="Session name"),
    target: str = typer.Option("", "--target", "-t", help="Target IP, hostname, or challenge name"),
    category: str = typer.Option("unknown", "--category", "-c", help="Challenge category"),
) -> None:
    """Create a new session."""
    spectre = _get_app()

    from spectre.sessions.models import ChallengeCategory, SessionMeta
    try:
        cat = ChallengeCategory(category.lower())
    except ValueError:
        console.print(f"[yellow]Unknown category '{category}', defaulting to 'unknown'.[/yellow]")
        cat = ChallengeCategory.UNKNOWN

    meta = SessionMeta(category=cat)
    session = spectre.session_manager.create_session(name=name, target=target, meta=meta)

    console.print()
    console.print(f"[bold green]✓[/bold green] Session created")
    console.print(f"  ID:       [cyan]{session.id[:8]}[/cyan]")
    console.print(f"  Name:     {session.name}")
    console.print(f"  Target:   {session.target or '—'}")
    console.print(f"  Category: {session.meta.category}")
    console.print(f"  Status:   [green]{session.status}[/green]")
    console.print()


@session_app.command("show")
def session_show(
    session_id: str = typer.Argument(..., help="Session ID (or prefix)")
) -> None:
    """Show full details of a specific session."""
    spectre = _get_app()

    # Support prefix matching
    sessions = spectre.session_manager.list_sessions()
    matches = [s for s in sessions if s.id.startswith(session_id)]

    if not matches:
        console.print(f"[red]No session found matching '{session_id}'[/red]")
        raise typer.Exit(1)

    if len(matches) > 1:
        console.print(f"[yellow]Ambiguous ID prefix — {len(matches)} matches. Use more characters.[/yellow]")
        raise typer.Exit(1)

    s = matches[0]

    table = Table(box=box.ROUNDED, border_style="cyan", show_header=False, padding=(0, 2))
    table.add_column("Field", style="bold cyan", width=20)
    table.add_column("Value", style="white")

    table.add_row("ID", s.id)
    table.add_row("Name", s.name)
    table.add_row("Target", s.target or "—")
    table.add_row("Status", s.status)
    table.add_row("Category", s.meta.category)
    table.add_row("Competition", s.meta.competition or "—")
    table.add_row("Difficulty", s.meta.difficulty or "—")
    table.add_row("Points", str(s.meta.points) if s.meta.points else "—")
    table.add_row("Tags", ", ".join(s.meta.tags) or "—")
    table.add_row("Notes", s.meta.notes or "—")
    table.add_row("Workspace", s.workspace_path or "—")
    table.add_row("Created", s.created_at.strftime("%Y-%m-%d %H:%M:%S UTC"))
    table.add_row("Updated", s.updated_at.strftime("%Y-%m-%d %H:%M:%S UTC"))
    table.add_row("Findings", str(len(s.findings)))
    table.add_row("History entries", str(len(s.history)))

    console.print(Panel(
        table,
        title=f"[bold cyan]Session: {s.name}[/bold cyan]",
        border_style="cyan",
    ))


# ---------------------------------------------------------------------------
# Plugin subcommands
# ---------------------------------------------------------------------------

@plugin_app.command("list")
def plugin_list() -> None:
    """List all loaded plugins."""
    spectre = _get_app()
    plugins = spectre.plugin_registry.list_all()

    if not plugins:
        console.print("[yellow]No plugins loaded.[/yellow]")
        return

    table = Table(
        title="Loaded Plugins",
        box=box.ROUNDED,
        border_style="cyan",
        header_style="bold cyan",
    )
    table.add_column("Name", width=16)
    table.add_column("Version", width=10)
    table.add_column("Category", width=14)
    table.add_column("Capabilities", width=40)
    table.add_column("Loaded", width=8)
    table.add_column("Enabled", width=8)

    for p in plugins:
        caps = ", ".join(p["capabilities"][:3])
        if len(p["capabilities"]) > 3:
            caps += f" +{len(p['capabilities']) - 3}"
        table.add_row(
            p["name"],
            p["version"],
            p["category"],
            caps or "—",
            "[green]✓[/green]" if p["loaded"] else "[red]✗[/red]",
            "[green]✓[/green]" if p["enabled"] else "[yellow]—[/yellow]",
        )

    console.print(table)
