"""spectre.ui — placeholder package. TODO: implement in future stages."""
