"""
spectre/core/app.py

Application bootstrap for Spectre.

SpectreApp is the top-level object that wires together:
  - Configuration (SpectreSettings)
  - Logging (loguru)
  - Session Manager
  - Plugin Registry

All CLI commands and future API handlers obtain their dependencies
through this object rather than importing globals directly.

Stage 1: Foundation & Core Skeleton
TODO Stage 2: Attach PlannerAgent and TaskQueue
TODO Stage 3: Attach KnowledgeGraph
TODO Stage 4: Attach MemorySystem
TODO Stage 5: Attach ReasoningEngine
"""

from __future__ import annotations

from typing import Optional

from spectre.core.config import get_settings
from spectre.core.logger import get_logger, setup_logging
from spectre.core.settings import SpectreSettings
from spectre.plugins.registry import PluginRegistry
from spectre.sessions.manager import SessionManager

log = get_logger(__name__)


class SpectreApp:
    """
    Central application object.

    Instantiate once and pass to subsystems that need access to
    shared state, settings, or services.
    """

    def __init__(self, settings: Optional[SpectreSettings] = None) -> None:
        self.settings: SpectreSettings = settings or get_settings()

        # --- Logging must be set up before anything else logs ---
        setup_logging(self.settings.logging)

        # --- Core subsystems ---
        self.session_manager = SessionManager(settings=self.settings)
        self.plugin_registry = PluginRegistry(settings=self.settings)

        # TODO Stage 2: self.planner = PlannerAgent(app=self)
        # TODO Stage 3: self.graph = KnowledgeGraph(app=self)
        # TODO Stage 4: self.memory = MemorySystem(app=self)
        # TODO Stage 5: self.reasoning = ReasoningEngine(app=self)

        self._ready: bool = False

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def initialize(self) -> None:
        """
        Run startup sequence: discover plugins, validate workspace,
        and mark the application as ready.
        """
        log.info("[Spectre initialized]")
        log.info("App version {} | environment: {}",
                 self.settings.app.version,
                 self.settings.app.environment)

        # Discover and load plugins
        self.plugin_registry.discover()

        self._ready = True

        log.success("Spectre ready | plugins={} | sessions={}",
                    len(self.plugin_registry.plugins),
                    len(self.session_manager.list_sessions()))

    def shutdown(self) -> None:
        """Graceful shutdown: flush sessions, unload plugins."""
        log.info("Shutting down Spectre...")
        self.session_manager.save_all()
        self.plugin_registry.unload_all()
        log.info("Shutdown complete.")

    # ------------------------------------------------------------------
    # Status
    # ------------------------------------------------------------------

    @property
    def is_ready(self) -> bool:
        return self._ready

    def status(self) -> dict:
        """Return a structured status dict for CLI and API consumers."""
        return {
            "app": self.settings.app.name,
            "version": self.settings.app.version,
            "environment": self.settings.app.environment,
            "ready": self._ready,
            "sessions": {
                "active": len([
                    s for s in self.session_manager.list_sessions()
                    if s.status == "active"
                ]),
                "total": len(self.session_manager.list_sessions()),
            },
            "plugins": {
                "loaded": len(self.plugin_registry.plugins),
                "names": list(self.plugin_registry.plugins.keys()),
            },
            "logging": {
                "level": self.settings.logging.level,
                "file": str(self.settings.logging.file_path),
            },
            # TODO Stage 2: "planner": {...}
            # TODO Stage 3: "graph": {"nodes": ..., "edges": ...}
        }
