"""
spectre.core

Public surface of the core package.
Import SpectreApp, settings helpers, and logger from here.
"""

from spectre.core.app import SpectreApp
from spectre.core.config import get_settings, load_config
from spectre.core.logger import get_logger, log, setup_logging
from spectre.core.settings import SpectreSettings

__all__ = [
    "SpectreApp",
    "get_settings",
    "load_config",
    "get_logger",
    "log",
    "setup_logging",
    "SpectreSettings",
]
