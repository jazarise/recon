"""
spectre/core/logger.py

Centralized logging system for Spectre using loguru.

Features:
- Console sink with colorized output
- Rotating file sink
- Debug mode toggle
- Per-module named loggers via `get_logger(name)`
- Structured context binding for sessions and agents

Stage 1: Foundation & Core Skeleton
TODO Stage 2: Add structured JSON sink for log aggregation
TODO Stage 3: Add agent-scoped log filtering
TODO Stage 4: Add log-to-dataset export for training data collection
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Optional

from loguru import logger as _root_logger

from spectre.core.settings import LoggingSettings

# ---------------------------------------------------------------------------
# Internal state
# ---------------------------------------------------------------------------

_initialized: bool = False


# ---------------------------------------------------------------------------
# Setup
# ---------------------------------------------------------------------------

def setup_logging(settings: LoggingSettings) -> None:
    """
    Configure loguru sinks from LoggingSettings.

    Should be called once at application startup (main.py / CLI entry point).
    Safe to call multiple times — subsequent calls remove previous sinks first.
    """
    global _initialized

    # Remove all existing handlers (clean slate on reconfiguration)
    _root_logger.remove()

    log_format = settings.format

    # --- Console sink ---
    if settings.console:
        _root_logger.add(
            sys.stderr,
            level=settings.level,
            format=log_format,
            colorize=True,
            backtrace=True,
            diagnose=settings.level == "DEBUG",
        )

    # --- File sink ---
    if settings.file:
        log_file = Path(settings.file_path)
        log_file.parent.mkdir(parents=True, exist_ok=True)

        _root_logger.add(
            str(log_file),
            level=settings.level,
            format=log_format,
            rotation=settings.rotation,
            retention=settings.retention,
            encoding="utf-8",
            backtrace=True,
            diagnose=settings.level == "DEBUG",
            enqueue=True,   # thread-safe async writes
        )

    _initialized = True
    _root_logger.debug("Logging system initialized | level={} | file={}", settings.level, settings.file_path)


# ---------------------------------------------------------------------------
# Per-module logger factory
# ---------------------------------------------------------------------------

def get_logger(name: str) -> "BoundLogger":
    """
    Return a loguru logger bound with a `name` context field.

    Usage::

        from spectre.core.logger import get_logger
        log = get_logger(__name__)
        log.info("WebAgent initialized")
    """
    return _root_logger.bind(name=name)


# Type alias for IDE support
BoundLogger = type(_root_logger)


# ---------------------------------------------------------------------------
# Convenience re-export of root logger
# ---------------------------------------------------------------------------

# Modules that don't need a named logger can import this directly.
log = _root_logger
