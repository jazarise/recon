"""
spectre/core/config.py

Configuration loader for Spectre.

Loading order (later layers override earlier ones):
  1. config/default.yaml          — baseline defaults
  2. config/<environment>.yaml    — environment-specific overrides
  3. Environment variables        — highest priority (SPECTRE_ prefix)

The merged dictionary is validated into SpectreSettings (Pydantic).
A singleton instance is exposed via `get_settings()`.

Stage 1: Foundation & Core Skeleton
TODO Stage 2: Support remote config sources (Vault, SSM)
TODO Stage 3: Add live-reload on config file change
"""

from __future__ import annotations

import os
from functools import lru_cache
from pathlib import Path
from typing import Any, Dict, Optional

import yaml
from dotenv import load_dotenv

from spectre.core.settings import SpectreSettings

# Load .env file before anything else so os.environ picks up the values
load_dotenv()

_CONFIG_DIR = Path(__file__).resolve().parents[2] / "config"


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _load_yaml(path: Path) -> Dict[str, Any]:
    """Load a YAML file and return its contents as a plain dict."""
    if not path.exists():
        return {}
    with path.open("r", encoding="utf-8") as fh:
        data = yaml.safe_load(fh) or {}
    return data


def _deep_merge(base: Dict[str, Any], override: Dict[str, Any]) -> Dict[str, Any]:
    """
    Recursively merge *override* into *base*.
    Override values win on conflict; nested dicts are merged recursively.
    """
    result = dict(base)
    for key, value in override.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = _deep_merge(result[key], value)
        else:
            result[key] = value
    return result


def _apply_env_overrides(config: Dict[str, Any]) -> Dict[str, Any]:
    """
    Map SPECTRE_* environment variables into the config dict.

    Naming convention:  SPECTRE_<SECTION>_<KEY>=value
    Examples:
        SPECTRE_APP_DEBUG=false          → config["app"]["debug"] = False
        SPECTRE_LOGGING_LEVEL=INFO       → config["logging"]["level"] = "INFO"
        SPECTRE_THREADING_MAX_THREADS=20 → config["threading"]["max_threads"] = 20

    Values are coerced: "true"/"false" → bool, numeric strings → int/float.
    """
    for raw_key, raw_value in os.environ.items():
        if not raw_key.startswith("SPECTRE_"):
            continue
        parts = raw_key[len("SPECTRE_"):].lower().split("_", 1)
        if len(parts) != 2:
            continue
        section, key = parts
        value: Any = _coerce(raw_value)
        config.setdefault(section, {})[key] = value
    return config


def _coerce(value: str) -> Any:
    """Coerce a string environment variable to an appropriate Python type."""
    if value.lower() == "true":
        return True
    if value.lower() == "false":
        return False
    try:
        return int(value)
    except ValueError:
        pass
    try:
        return float(value)
    except ValueError:
        pass
    return value


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def load_config(environment: Optional[str] = None) -> SpectreSettings:
    """
    Build and validate a SpectreSettings instance.

    Parameters
    ----------
    environment:
        Override the environment name (default: reads SPECTRE_ENV or "development").
    """
    env = environment or os.getenv("SPECTRE_ENV", "development")

    # 1. Load baseline defaults
    config: Dict[str, Any] = _load_yaml(_CONFIG_DIR / "default.yaml")

    # 2. Merge environment-specific overrides
    env_config = _load_yaml(_CONFIG_DIR / f"{env}.yaml")
    config = _deep_merge(config, env_config)

    # 3. Apply environment variable overrides
    config = _apply_env_overrides(config)

    # Ensure the app.environment field reflects the resolved environment
    config.setdefault("app", {})["environment"] = env

    # 4. Validate into Pydantic model
    settings = SpectreSettings.model_validate(config)

    # 5. Create workspace directories
    settings.workspace.ensure_directories()

    return settings


@lru_cache(maxsize=1)
def get_settings() -> SpectreSettings:
    """
    Return the cached singleton SpectreSettings instance.

    The first call triggers config loading; subsequent calls return the
    cached result. Call `get_settings.cache_clear()` in tests to reset.
    """
    return load_config()
