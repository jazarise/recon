"""spectre.parsers — placeholder package. TODO: implement in future stages."""
