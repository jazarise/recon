"""spectre.skills — placeholder package. TODO: implement in future stages."""
