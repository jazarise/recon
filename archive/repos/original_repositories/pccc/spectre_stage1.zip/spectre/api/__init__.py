"""spectre.api — placeholder package. TODO: implement in future stages."""
