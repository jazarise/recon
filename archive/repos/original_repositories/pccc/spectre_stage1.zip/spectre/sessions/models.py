"""
spectre/sessions/models.py

Pydantic models for Spectre session objects.

A Session represents one CTF challenge or lab engagement.
It tracks target information, status, findings, and metadata.

Stage 1: Foundation & Core Skeleton
TODO Stage 2: Add findings list (hosts, ports, vulns) as structured types
TODO Stage 3: Link session to KnowledgeGraph snapshot
TODO Stage 4: Add episodic memory reference
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _new_id() -> str:
    return str(uuid.uuid4())


# ---------------------------------------------------------------------------
# Enumerations
# ---------------------------------------------------------------------------

class SessionStatus(str, Enum):
    ACTIVE = "active"
    PAUSED = "paused"
    COMPLETED = "completed"
    ARCHIVED = "archived"
    ERROR = "error"


class ChallengeCategory(str, Enum):
    """CTF challenge categories for session classification."""
    WEB = "web"
    PWN = "pwn"
    CRYPTO = "crypto"
    FORENSICS = "forensics"
    REVERSE = "reverse"
    STEGO = "stego"
    MISC = "misc"
    NETWORK = "network"
    OSINT = "osint"
    UNKNOWN = "unknown"


# ---------------------------------------------------------------------------
# Session model
# ---------------------------------------------------------------------------

class SessionMeta(BaseModel):
    """Metadata attached to a session for indexing and search."""

    competition: Optional[str] = None        # e.g. "picoCTF 2024"
    category: ChallengeCategory = ChallengeCategory.UNKNOWN
    difficulty: Optional[str] = None         # e.g. "easy", "hard"
    points: Optional[int] = None
    tags: List[str] = Field(default_factory=list)
    notes: str = ""

    # TODO Stage 4: Add `hints_used` and `flag_found` tracking


class Session(BaseModel):
    """
    Core session object representing one CTF challenge engagement.

    Serializes to/from JSON for persistence by SessionManager.
    """

    id: str = Field(default_factory=_new_id)
    name: str = "Unnamed Session"
    target: str = ""                             # IP, hostname, or challenge name
    status: SessionStatus = SessionStatus.ACTIVE
    created_at: datetime = Field(default_factory=_utc_now)
    updated_at: datetime = Field(default_factory=_utc_now)
    meta: SessionMeta = Field(default_factory=SessionMeta)

    # Runtime state — not persisted between restores by default
    workspace_path: Optional[str] = None

    # Arbitrary key-value store for agent findings (Stage 1 placeholder)
    # TODO Stage 2: Replace with typed FindingsList once agents are implemented
    findings: Dict[str, Any] = Field(default_factory=dict)

    # History of actions taken in this session
    # TODO Stage 2: Replace with structured ActionRecord objects
    history: List[Dict[str, Any]] = Field(default_factory=list)

    model_config = {"use_enum_values": True}

    def touch(self) -> None:
        """Update the `updated_at` timestamp to now."""
        self.updated_at = _utc_now()

    def to_summary(self) -> Dict[str, Any]:
        """Return a compact dict suitable for CLI table display."""
        return {
            "id": self.id[:8],
            "name": self.name,
            "target": self.target or "—",
            "status": self.status,
            "category": self.meta.category,
            "created": self.created_at.strftime("%Y-%m-%d %H:%M"),
        }
