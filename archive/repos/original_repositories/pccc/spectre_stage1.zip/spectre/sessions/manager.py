"""
spectre/sessions/manager.py

Session lifecycle manager for Spectre.

Responsibilities:
- Create new sessions
- Persist sessions to disk (JSON)
- Restore sessions from disk
- List and query existing sessions
- Auto-save active sessions

Stage 1: Foundation & Core Skeleton
TODO Stage 2: Add async auto-save loop
TODO Stage 3: Integrate with KnowledgeGraph — save/restore graph snapshots
TODO Stage 4: Restore episodic memory alongside session
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, List, Optional

from spectre.core.logger import get_logger
from spectre.core.settings import SpectreSettings
from spectre.sessions.models import Session, SessionStatus

log = get_logger(__name__)


class SessionManager:
    """
    Manages the full lifecycle of Spectre sessions.

    Sessions are persisted as individual JSON files under:
        <workspace.base_path>/<session_id>/session.json
    """

    def __init__(self, settings: SpectreSettings) -> None:
        self.settings = settings
        self._sessions: Dict[str, Session] = {}
        self._workspace = Path(settings.workspace.base_path)
        self._workspace.mkdir(parents=True, exist_ok=True)
        log.debug("SessionManager initialized | workspace={}", self._workspace)

    # ------------------------------------------------------------------
    # CRUD
    # ------------------------------------------------------------------

    def create_session(
        self,
        name: str = "Unnamed Session",
        target: str = "",
        **kwargs,
    ) -> Session:
        """
        Create a new session, register it in memory, and persist to disk.

        Parameters
        ----------
        name:    Human-readable session name.
        target:  CTF target identifier (IP, hostname, challenge name).
        kwargs:  Additional fields forwarded to the Session constructor.
        """
        session = Session(name=name, target=target, **kwargs)

        # Assign a workspace subdirectory for this session
        session_dir = self._workspace / session.id
        session_dir.mkdir(parents=True, exist_ok=True)
        session.workspace_path = str(session_dir)

        self._sessions[session.id] = session
        self._persist(session)

        log.info("Session created | id={} | name={} | target={}",
                 session.id[:8], session.name, session.target)
        return session

    def get_session(self, session_id: str) -> Optional[Session]:
        """Return an in-memory session by ID, or None if not found."""
        return self._sessions.get(session_id)

    def save_session(self, session_id: str) -> bool:
        """
        Persist a specific session to disk.

        Returns True on success, False if the session was not found.
        """
        session = self._sessions.get(session_id)
        if session is None:
            log.warning("save_session called with unknown id={}", session_id[:8])
            return False
        session.touch()
        self._persist(session)
        log.debug("Session saved | id={}", session_id[:8])
        return True

    def save_all(self) -> None:
        """Persist all in-memory sessions to disk."""
        for session in self._sessions.values():
            session.touch()
            self._persist(session)
        log.info("All sessions saved | count={}", len(self._sessions))

    def restore_session(self, session_id: str) -> Optional[Session]:
        """
        Load a session from disk into memory.

        If the session is already in memory it is returned directly.
        Returns None if no persisted file is found.
        """
        if session_id in self._sessions:
            return self._sessions[session_id]

        path = self._session_path(session_id)
        if not path.exists():
            log.warning("restore_session: no file found for id={}", session_id[:8])
            return None

        session = self._load(path)
        self._sessions[session.id] = session
        log.info("Session restored | id={} | name={}", session.id[:8], session.name)
        return session

    def restore_all(self) -> int:
        """
        Scan the workspace directory and restore all persisted sessions.

        Returns the number of sessions restored.
        """
        count = 0
        for path in self._workspace.glob("*/session.json"):
            try:
                session = self._load(path)
                self._sessions[session.id] = session
                count += 1
            except Exception as exc:
                log.error("Failed to restore session from {} | {}", path, exc)
        log.info("restore_all complete | restored={}", count)
        return count

    def delete_session(self, session_id: str) -> bool:
        """
        Remove a session from memory and optionally mark as archived.

        Physical files are NOT deleted — they are retained for audit purposes.
        TODO Stage 3: Add configurable hard-delete option.
        """
        session = self._sessions.pop(session_id, None)
        if session is None:
            return False
        session.status = SessionStatus.ARCHIVED
        session.touch()
        self._persist(session)
        log.info("Session archived | id={}", session_id[:8])
        return True

    # ------------------------------------------------------------------
    # Query
    # ------------------------------------------------------------------

    def list_sessions(self) -> List[Session]:
        """Return all in-memory sessions."""
        return list(self._sessions.values())

    def active_sessions(self) -> List[Session]:
        """Return only sessions with ACTIVE status."""
        return [s for s in self._sessions.values() if s.status == SessionStatus.ACTIVE]

    # ------------------------------------------------------------------
    # Internal persistence helpers
    # ------------------------------------------------------------------

    def _session_path(self, session_id: str) -> Path:
        return self._workspace / session_id / "session.json"

    def _persist(self, session: Session) -> None:
        """Write session to JSON on disk."""
        path = self._session_path(session.id)
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("w", encoding="utf-8") as fh:
            fh.write(session.model_dump_json(indent=2))

    def _load(self, path: Path) -> Session:
        """Read and deserialize a session from a JSON file."""
        with path.open("r", encoding="utf-8") as fh:
            data = json.load(fh)
        return Session.model_validate(data)
