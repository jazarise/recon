"""
Spectre — AI-powered CTF assistant and challenge-intelligence platform.

Designed strictly for controlled environments:
  - Capture The Flag competitions
  - Local labs
  - Intentionally vulnerable training machines

Stage 1: Foundation & Core Skeleton
"""

__version__ = "0.1.0"
__author__ = "Spectre Team"
