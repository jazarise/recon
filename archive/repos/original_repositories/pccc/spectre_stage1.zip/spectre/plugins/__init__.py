"""spectre.plugins — plugin system package."""

from spectre.plugins.base import (
    PluginCategory,
    PluginError,
    PluginLoadError,
    PluginExecutionError,
    PluginResult,
    SpectrePlugin,
)
from spectre.plugins.registry import PluginRegistry

__all__ = [
    "SpectrePlugin",
    "PluginResult",
    "PluginCategory",
    "PluginError",
    "PluginLoadError",
    "PluginExecutionError",
    "PluginRegistry",
]
