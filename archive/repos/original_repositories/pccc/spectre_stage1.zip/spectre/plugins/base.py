"""
spectre/plugins/base.py

Abstract base class for all Spectre plugins.

Every plugin — web, smb, crypto, stego, etc. — must subclass `SpectrePlugin`
and implement the abstract lifecycle methods below.

Design principles:
- Plugins are self-describing (name, version, category, capabilities).
- Plugins declare their tool dependencies so the registry can validate them.
- Plugin execution is always isolated from reasoning and memory.
- Plugins communicate results via structured PluginResult objects.

Stage 1: Foundation & Core Skeleton
TODO Stage 2: Add async `run()` support and tool execution integration
TODO Stage 3: Add capability advertising for the PlannerAgent
TODO Stage 4: Add training data export hooks
"""

from __future__ import annotations

import abc
from enum import Enum
from typing import Any, Dict, List, Optional

from pydantic import BaseModel


# ---------------------------------------------------------------------------
# Plugin categories (mirrors specialized agent types)
# ---------------------------------------------------------------------------

class PluginCategory(str, Enum):
    WEB = "web"
    SMB = "smb"
    SSH = "ssh"
    CRYPTO = "crypto"
    STEGO = "stego"
    FORENSICS = "forensics"
    REVERSE = "reverse"
    BINARY = "binary"
    PRIVSEC = "privsec"
    FILE = "file"
    MISC = "misc"


# ---------------------------------------------------------------------------
# Plugin result container
# ---------------------------------------------------------------------------

class PluginResult(BaseModel):
    """
    Structured output returned by a plugin after execution.

    All plugin results flow into the Parser Engine for normalization,
    entity extraction, and injection into the Knowledge Graph.
    """

    plugin_name: str
    success: bool
    data: Dict[str, Any] = {}
    findings: List[Dict[str, Any]] = []
    errors: List[str] = []
    raw_output: Optional[str] = None
    metadata: Dict[str, Any] = {}

    # TODO Stage 2: Add confidence_score: float = 0.0
    # TODO Stage 3: Add graph_entities: List[GraphEntity]


# ---------------------------------------------------------------------------
# Abstract plugin base
# ---------------------------------------------------------------------------

class SpectrePlugin(abc.ABC):
    """
    Abstract base class for all Spectre plugins.

    Subclass this and implement `name`, `version`, `category`,
    `capabilities`, and the lifecycle methods.
    """

    # --- Class-level descriptors (must be overridden) ---

    @property
    @abc.abstractmethod
    def name(self) -> str:
        """Unique plugin identifier (snake_case)."""
        ...

    @property
    @abc.abstractmethod
    def version(self) -> str:
        """Semantic version string e.g. '1.0.0'."""
        ...

    @property
    @abc.abstractmethod
    def category(self) -> PluginCategory:
        """Plugin category from PluginCategory enum."""
        ...

    @property
    def capabilities(self) -> List[str]:
        """
        Human-readable list of what this plugin can do.
        Used by the PlannerAgent (Stage 2) for task assignment.
        """
        return []

    @property
    def dependencies(self) -> List[str]:
        """
        External tool dependencies (e.g. ['nmap', 'gobuster']).
        The registry validates these on load.
        TODO Stage 2: Integrate with tool dependency checker.
        """
        return []

    # --- State ---

    def __init__(self) -> None:
        self._loaded: bool = False
        self._enabled: bool = True

    @property
    def is_loaded(self) -> bool:
        return self._loaded

    @property
    def is_enabled(self) -> bool:
        return self._enabled

    # --- Lifecycle ---

    @abc.abstractmethod
    def load(self) -> None:
        """
        Initialize the plugin. Called once by the registry on startup.
        Perform imports, validate dependencies, set up internal state.
        Raise PluginLoadError on failure.
        """
        ...

    def unload(self) -> None:
        """
        Clean up resources. Called by the registry on shutdown.
        Override if the plugin holds open connections or temp files.
        """
        self._loaded = False

    def enable(self) -> None:
        """Enable this plugin for task assignment."""
        self._enabled = True

    def disable(self) -> None:
        """Disable this plugin without unloading it."""
        self._enabled = False

    # --- Execution (Stage 1 stub) ---

    def execute(self, **kwargs: Any) -> PluginResult:
        """
        Execute the plugin's primary action.

        Stage 1: Returns a not-implemented result.
        TODO Stage 2: Replace stub with real tool invocation via ToolWrapper.
        """
        return PluginResult(
            plugin_name=self.name,
            success=False,
            errors=["execute() not yet implemented — Stage 2"],
        )

    # --- Representation ---

    def describe(self) -> Dict[str, Any]:
        """Return a structured description for CLI and registry display."""
        return {
            "name": self.name,
            "version": self.version,
            "category": self.category,
            "capabilities": self.capabilities,
            "dependencies": self.dependencies,
            "loaded": self._loaded,
            "enabled": self._enabled,
        }

    def __repr__(self) -> str:
        return f"<Plugin {self.name} v{self.version} [{self.category}]>"


# ---------------------------------------------------------------------------
# Plugin exception hierarchy
# ---------------------------------------------------------------------------

class PluginError(Exception):
    """Base exception for plugin-related errors."""


class PluginLoadError(PluginError):
    """Raised when a plugin fails to initialize."""


class PluginExecutionError(PluginError):
    """Raised when plugin execution fails."""
