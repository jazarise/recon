"""
spectre/plugins/web/__init__.py

Web plugin package.
Stage 1: Stub plugin demonstrating the SpectrePlugin authoring pattern.

TODO Stage 2: Implement real web enumeration tools:
    - gobuster / ffuf directory brute-force wrapper
    - nikto scanner wrapper
    - header / cookie analysis
    - JavaScript parsing and endpoint extraction
"""

from spectre.plugins.web.plugin import WebPlugin

__all__ = ["WebPlugin"]
