"""
spectre/plugins/registry.py

Plugin registry for Spectre.

Responsibilities:
- Auto-discover plugin classes in the plugins/ subdirectory tree
- Validate plugins against enabled/disabled lists in settings
- Provide a lookup interface for the PlannerAgent (Stage 2)
- Manage plugin lifecycle (load / unload)

Discovery works by scanning for Python modules that export a class
inheriting from SpectrePlugin. This avoids any hardcoded import lists.

Stage 1: Foundation & Core Skeleton
TODO Stage 2: Add capability-based lookup for PlannerAgent task assignment
TODO Stage 3: Add hot-reload support for plugins during a session
TODO Stage 4: Add sandboxed execution via subprocess isolation
"""

from __future__ import annotations

import importlib
import importlib.util
import inspect
import pkgutil
from pathlib import Path
from typing import Dict, List, Optional, Type

from spectre.core.logger import get_logger
from spectre.core.settings import SpectreSettings
from spectre.plugins.base import (
    PluginCategory,
    PluginError,
    PluginLoadError,
    SpectrePlugin,
)

log = get_logger(__name__)


class PluginRegistry:
    """
    Central registry for all loaded SpectrePlugin instances.

    Usage::

        registry = PluginRegistry(settings)
        registry.discover()
        plugin = registry.get("web_scanner")
    """

    def __init__(self, settings: SpectreSettings) -> None:
        self.settings = settings
        self.plugins: Dict[str, SpectrePlugin] = {}

    # ------------------------------------------------------------------
    # Discovery
    # ------------------------------------------------------------------

    def discover(self) -> int:
        """
        Scan the plugins package for SpectrePlugin subclasses and load them.

        Returns the number of plugins successfully loaded.
        """
        log.info("Starting plugin discovery...")

        # Locate the plugins package directory
        plugins_pkg_path = Path(__file__).resolve().parent
        loaded = 0

        for finder, module_name, is_pkg in pkgutil.walk_packages(
            path=[str(plugins_pkg_path)],
            prefix="spectre.plugins.",
            onerror=lambda name: log.warning("Error scanning module: {}", name),
        ):
            # Skip the base and registry modules themselves
            if module_name in ("spectre.plugins.base", "spectre.plugins.registry"):
                continue

            plugin_classes = self._import_plugin_classes(module_name)
            for cls in plugin_classes:
                loaded += self._register(cls)

        log.info("Plugin discovery complete | loaded={}", loaded)
        return loaded

    def _import_plugin_classes(self, module_name: str) -> List[Type[SpectrePlugin]]:
        """Import a module and return all SpectrePlugin subclasses inside it."""
        try:
            module = importlib.import_module(module_name)
        except Exception as exc:
            log.warning("Could not import plugin module {} | {}", module_name, exc)
            return []

        classes = []
        for _attr_name, obj in inspect.getmembers(module, inspect.isclass):
            if (
                issubclass(obj, SpectrePlugin)
                and obj is not SpectrePlugin
                and obj.__module__ == module_name
            ):
                classes.append(obj)
        return classes

    def _register(self, cls: Type[SpectrePlugin]) -> int:
        """Instantiate, validate, and load a plugin class. Returns 1 on success."""
        try:
            instance: SpectrePlugin = cls()
        except Exception as exc:
            log.error("Failed to instantiate plugin {} | {}", cls.__name__, exc)
            return 0

        name = instance.name

        # --- Enabled / disabled list checks ---
        if self.settings.plugins.disabled and name in self.settings.plugins.disabled:
            log.debug("Plugin '{}' is in disabled list — skipping", name)
            return 0

        if (
            self.settings.plugins.enabled
            and name not in self.settings.plugins.enabled
        ):
            log.debug("Plugin '{}' not in enabled list — skipping", name)
            return 0

        # --- Load lifecycle ---
        try:
            instance.load()
            instance._loaded = True
        except PluginLoadError as exc:
            log.warning("Plugin '{}' failed to load | {}", name, exc)
            return 0
        except Exception as exc:
            log.error("Unexpected error loading plugin '{}' | {}", name, exc)
            return 0

        self.plugins[name] = instance
        log.debug("Plugin loaded | name={} | category={} | version={}",
                  name, instance.category, instance.version)
        return 1

    # ------------------------------------------------------------------
    # Lookup
    # ------------------------------------------------------------------

    def get(self, name: str) -> Optional[SpectrePlugin]:
        """Return a loaded plugin by name, or None."""
        return self.plugins.get(name)

    def by_category(self, category: PluginCategory) -> List[SpectrePlugin]:
        """Return all loaded plugins matching a given category."""
        return [p for p in self.plugins.values() if p.category == category]

    def list_all(self) -> List[Dict]:
        """Return a list of plugin descriptions for display."""
        return [p.describe() for p in self.plugins.values()]

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def unload_all(self) -> None:
        """Unload all plugins (called on shutdown)."""
        for name, plugin in list(self.plugins.items()):
            try:
                plugin.unload()
            except Exception as exc:
                log.warning("Error unloading plugin '{}' | {}", name, exc)
        self.plugins.clear()
        log.info("All plugins unloaded.")
