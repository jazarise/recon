# Spectre

**AI-powered CTF assistant and challenge-intelligence platform**

> Designed strictly for controlled environments: Capture The Flag competitions, local labs, and intentionally vulnerable training machines.

---

## Stage 1 — Foundation & Core Skeleton

This release delivers the foundational architecture that all future stages build upon. No agents, no tool execution, no knowledge graph — just solid, production-grade scaffolding.

---

## Project Structure

```
spectre/                        ← project root
│
├── spectre/                    ← Python package
│   ├── core/                   ← Config, logging, app bootstrap
│   │   ├── settings.py         ← Pydantic typed settings models
│   │   ├── config.py           ← YAML + env var config loader
│   │   ├── logger.py           ← loguru logging system
│   │   └── app.py              ← SpectreApp bootstrap object
│   │
│   ├── sessions/               ← Session lifecycle
│   │   ├── models.py           ← Session, SessionMeta Pydantic models
│   │   └── manager.py          ← Create, save, restore, list sessions
│   │
│   ├── plugins/                ← Plugin system
│   │   ├── base.py             ← SpectrePlugin abstract base class
│   │   ├── registry.py         ← Auto-discovery and lifecycle management
│   │   ├── web/                ← Web plugin stub
│   │   ├── smb/                ← SMB plugin stub
│   │   ├── crypto/             ← Crypto plugin stub
│   │   ├── ssh/                ← SSH plugin stub
│   │   ├── stego/              ← Stego plugin stub
│   │   └── forensics/          ← Forensics plugin stub
│   │
│   ├── cli/                    ← Typer CLI
│   │   └── main.py             ← All CLI commands
│   │
│   ├── agents/                 ← TODO Stage 2
│   ├── planner/                ← TODO Stage 2
│   ├── memory/                 ← TODO Stage 4
│   ├── tools/                  ← TODO Stage 2
│   ├── parsers/                ← TODO Stage 2
│   ├── workflows/              ← TODO Stage 3
│   ├── graph/                  ← TODO Stage 3
│   ├── skills/                 ← TODO Stage 5
│   ├── models/                 ← TODO Stage 3
│   ├── datasets/               ← TODO Stage 4
│   ├── api/                    ← TODO Stage 6
│   └── ui/                     ← TODO Stage 6
│
├── config/
│   ├── default.yaml            ← Baseline configuration
│   ├── development.yaml        ← Dev overrides
│   └── production.yaml         ← Production overrides
│
├── logs/                       ← Runtime log files
├── tests/
│   └── test_stage1.py          ← Stage 1 test suite
│
├── main.py                     ← Entry point
├── requirements.txt
├── pyproject.toml
└── .env                        ← Environment variables (not committed)
```

---

## Installation

```bash
# Clone and enter the project
git clone <repo> spectre
cd spectre

# Create a virtual environment
python3 -m venv .venv
source .venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Install in editable mode (enables `spectre` CLI command)
pip install -e .
```

---

## Configuration

Configuration loads in this priority order (later wins):

1. `config/default.yaml` — baseline defaults
2. `config/<SPECTRE_ENV>.yaml` — environment overrides (`development` or `production`)
3. Environment variables — `SPECTRE_<SECTION>_<KEY>=value`

### Key environment variables

| Variable | Default | Description |
|---|---|---|
| `SPECTRE_ENV` | `development` | Active environment |
| `SPECTRE_DEBUG` | `true` | Enable debug mode |
| `SPECTRE_LOGGING_LEVEL` | `DEBUG` | Log verbosity |
| `SPECTRE_THREADING_MAX_THREADS` | `10` | Thread pool size |
| `SPECTRE_WORKSPACE_BASE_PATH` | `./sessions` | Session storage root |

---

## CLI Usage

```bash
# Initialize Spectre and show startup status
spectre start

# Show current status
spectre status

# Session management
spectre session list
spectre session new --name "Web Challenge" --target "10.10.10.1" --category web
spectre session show <session-id-prefix>

# Plugin management
spectre plugin list
```

### Expected startup output

```
[Spectre initialized]

  Application:       Spectre v0.1.0
  Environment:       development
  Status:            Ready
  Sessions (active): 0
  Plugins loaded:    6
  Log level:         DEBUG

✓ Spectre initialized
  Session:       active
  Plugins:       6 loaded
  Logging:       enabled
  Configuration: loaded (development)
```

---

## Plugin Architecture

All plugins implement `SpectrePlugin` from `spectre.plugins.base`:

```python
from spectre.plugins.base import SpectrePlugin, PluginCategory, PluginResult

class MyPlugin(SpectrePlugin):
    @property
    def name(self) -> str:
        return "my_plugin"

    @property
    def version(self) -> str:
        return "1.0.0"

    @property
    def category(self) -> PluginCategory:
        return PluginCategory.WEB

    @property
    def capabilities(self) -> list:
        return ["scan", "enumerate"]

    def load(self) -> None:
        # Initialize resources
        self._loaded = True

    def execute(self, **kwargs) -> PluginResult:
        # Run tools, return structured findings
        return PluginResult(
            plugin_name=self.name,
            success=True,
            findings=[{"type": "endpoint", "url": "http://..."}],
        )
```

Place the plugin in `spectre/plugins/<category>/` — the registry auto-discovers it on startup.

---

## Core Workflow (implemented progressively across stages)

```
Observe → Collect → Analyze → Reason → Decide → Execute → Learn → Repeat
```

| Stage | Scope |
|---|---|
| **Stage 1** | Foundation, config, logging, sessions, plugin skeleton, CLI |
| Stage 2 | Tool wrappers, parser engine, specialized agents, planner |
| Stage 3 | Knowledge graph (NetworkX → Neo4j), entity extraction |
| Stage 4 | Memory system (working, episodic, semantic, long-term) |
| Stage 5 | Reasoning engine, workflow prediction, confidence scoring |
| Stage 6 | REST API, web UI, dataset export, self-improving agents |

---

## Running Tests

```bash
pytest tests/ -v
pytest tests/ -v --cov=spectre --cov-report=term-missing
```

---

## Design Principles

- **Modular** — every component is independently replaceable
- **Plugin-based** — agents and tools are plugins, not hardcoded
- **Separated concerns** — collection ≠ analysis ≠ memory ≠ reasoning
- **AI-swappable** — LLM backends can be swapped without rewriting the system
- **Controlled environments only** — CTF competitions, local labs, intentionally vulnerable machines

---

## License

MIT — for educational and CTF use in controlled environments only.
