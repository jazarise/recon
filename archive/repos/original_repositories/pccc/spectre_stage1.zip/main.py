"""
main.py

Spectre top-level entry point.

Usage:
    python main.py start
    python main.py status
    python main.py session list
    python main.py session new --name "MyChallenge" --target "10.10.10.1"
    python main.py plugin list

After installation (pip install -e .):
    spectre start
    spectre session list

Stage 1: Foundation & Core Skeleton
"""

from spectre.cli.main import app

if __name__ == "__main__":
    app()
