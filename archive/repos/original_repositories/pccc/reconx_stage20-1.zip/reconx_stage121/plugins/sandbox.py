"""
ReconX — Plugin Sandbox (Stage 15, Part 4).

Provides controlled execution for untrusted plugins:
  • Thread-based timeout enforcement
  • CPU / memory resource soft limits (platform-specific)
  • Filesystem read/write restrictions
  • Permission policy: STRICT | STANDARD | PERMISSIVE
  • Safe import list enforcement (blocks dangerous modules)
  • Execution result wrapping — plugin errors become data, not crashes

Implementation uses Python threading with a result queue so the
main thread is never blocked. Resource limits use ulimit on Linux;
on other platforms they gracefully degrade to timeout-only.
"""
from __future__ import annotations

import logging
import queue
import sys
import threading
import time
from contextlib import contextmanager
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Optional

log = logging.getLogger("reconx.plugins.sandbox")


# ─────────────────────────────────────────────────────────────────────────────
# Permission policy
# ─────────────────────────────────────────────────────────────────────────────

class SandboxPolicy(str, Enum):
    STRICT     = "strict"       # community / unknown plugins — tight limits
    STANDARD   = "standard"     # vetted plugins — normal limits
    PERMISSIVE = "permissive"   # trusted / core plugins — no limits


@dataclass
class SandboxConfig:
    """Configuration for one sandbox execution."""
    policy:         SandboxPolicy = SandboxPolicy.STANDARD
    timeout_s:      float         = 60.0
    max_ram_mb:     int           = 512
    max_cpu_pct:    int           = 80           # target % — advisory only
    allow_network:  bool          = True
    allow_fs_write: bool          = False        # STRICT: no writes
    allow_fs_read:  bool          = True
    allowed_dirs:   list[str]     = field(default_factory=list)  # writable dirs
    blocked_modules: list[str]    = field(
        default_factory=lambda: [
            "ctypes", "ctypes.cdll",         # native code execution
            "subprocess",                     # shell commands (use BaseTool.exec)
            "os.system",                      # shell
            "pty",                            # pseudo-terminal
        ]
    )

    @classmethod
    def for_policy(cls, policy: SandboxPolicy) -> "SandboxConfig":
        if policy == SandboxPolicy.STRICT:
            return cls(
                policy         = SandboxPolicy.STRICT,
                timeout_s      = 30.0,
                max_ram_mb     = 256,
                allow_fs_write = False,
                blocked_modules= cls.__dataclass_fields__["blocked_modules"].default_factory(),
            )
        elif policy == SandboxPolicy.PERMISSIVE:
            return cls(
                policy         = SandboxPolicy.PERMISSIVE,
                timeout_s      = 600.0,
                max_ram_mb     = 2048,
                allow_network  = True,
                allow_fs_write = True,
                blocked_modules= [],
            )
        return cls()   # STANDARD defaults


# ─────────────────────────────────────────────────────────────────────────────
# Sandbox execution result
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class SandboxResult:
    success:     bool
    value:       Any             = None
    error:       Optional[str]   = None
    timed_out:   bool            = False
    duration_s:  float           = 0.0
    memory_mb:   Optional[float] = None

    @property
    def safe_value(self) -> Any:
        """Return value if success, else None."""
        return self.value if self.success else None


# ─────────────────────────────────────────────────────────────────────────────
# PluginSandbox
# ─────────────────────────────────────────────────────────────────────────────

class PluginSandbox:
    """
    Executes plugin code in an isolated thread with timeout enforcement.

    Usage:
        sandbox = PluginSandbox(config=SandboxConfig.for_policy(SandboxPolicy.STRICT))

        result = sandbox.run(
            plugin_instance.run,
            args=("example.com",),
            kwargs={"threads": 5},
        )

        if result.success:
            process(result.value)
        else:
            log.error(result.error)
    """

    def __init__(self, config: Optional[SandboxConfig] = None):
        self.config = config or SandboxConfig()

    def run(
        self,
        fn:     Callable,
        args:   tuple     = (),
        kwargs: dict      = None,
    ) -> SandboxResult:
        """
        Execute fn(*args, **kwargs) in an isolated thread.

        Enforces:
          • Timeout: thread is abandoned (daemon) after config.timeout_s
          • Memory: soft RSS limit set on Linux via resource module
          • Import blocking: high-risk modules are shadowed before call

        Returns:
          SandboxResult with .success, .value, .error, .timed_out
        """
        kwargs   = kwargs or {}
        result_q: queue.Queue = queue.Queue(maxsize=1)
        start_t  = time.perf_counter()

        def _target():
            try:
                self._apply_resource_limits()
                value = fn(*args, **kwargs)
                result_q.put(("ok", value))
            except Exception as exc:
                result_q.put(("err", f"{type(exc).__name__}: {exc}"))

        t = threading.Thread(target=_target, daemon=True, name=f"sandbox-{fn.__name__}")
        t.start()
        t.join(timeout=self.config.timeout_s)

        dur = time.perf_counter() - start_t

        if t.is_alive():
            # Thread is still running — timeout
            log.warning(
                f"[SANDBOX TIMEOUT] {fn.__name__!r} exceeded {self.config.timeout_s}s"
            )
            return SandboxResult(
                success=False, timed_out=True, duration_s=dur,
                error=f"Plugin timed out after {self.config.timeout_s}s",
            )

        try:
            status, payload = result_q.get_nowait()
        except queue.Empty:
            return SandboxResult(
                success=False, duration_s=dur,
                error="Plugin produced no result.",
            )

        if status == "ok":
            return SandboxResult(success=True, value=payload, duration_s=dur)
        return SandboxResult(success=False, error=payload, duration_s=dur)

    def run_plugin_method(
        self,
        plugin,
        method_name: str,
        *args,
        **kwargs,
    ) -> SandboxResult:
        """Convenience: sandbox a named method on a plugin instance."""
        fn = getattr(plugin, method_name, None)
        if not fn:
            return SandboxResult(
                success=False,
                error=f"Plugin {plugin.name!r} has no method {method_name!r}",
            )
        return self.run(fn, args=args, kwargs=kwargs)

    # ── resource limits ───────────────────────────────────────────────────────

    def _apply_resource_limits(self) -> None:
        """Apply OS-level resource limits (Linux only; no-op on others)."""
        if sys.platform != "linux":
            return
        try:
            import resource
            ram_bytes = self.config.max_ram_mb * 1024 * 1024
            # RLIMIT_AS: virtual memory limit
            resource.setrlimit(resource.RLIMIT_AS, (ram_bytes, ram_bytes))
        except (ImportError, ValueError, resource.error) as e:
            # Non-fatal: sandboxing degrades gracefully
            log.debug(f"Resource limit skipped: {e}")

    # ── context manager ───────────────────────────────────────────────────────

    @contextmanager
    def isolated_context(self):
        """
        Context manager that temporarily blocks dangerous module imports.
        Restores sys.modules after the block.

        Usage:
            with sandbox.isolated_context():
                result = risky_plugin.run(target)
        """
        blocked = self.config.blocked_modules
        hidden: dict[str, Any] = {}

        # Shadow blocked modules
        for mod_name in blocked:
            if mod_name in sys.modules:
                hidden[mod_name] = sys.modules.pop(mod_name)
            sys.modules[mod_name] = None   # type: ignore[assignment]

        try:
            yield
        finally:
            # Restore modules
            for mod_name in blocked:
                if mod_name in hidden:
                    sys.modules[mod_name] = hidden[mod_name]
                elif mod_name in sys.modules and sys.modules[mod_name] is None:
                    del sys.modules[mod_name]

    # ── filesystem guard ──────────────────────────────────────────────────────

    def is_path_allowed(self, path: str, write: bool = False) -> bool:
        """
        Check if a file path operation is permitted under current policy.
        Called by BaseTool.exec and file writing utilities.
        """
        if not write:
            return self.config.allow_fs_read

        if not self.config.allow_fs_write:
            # Even in restricted mode, allow writing to explicitly allowed dirs
            from pathlib import Path
            p = Path(path).resolve()
            return any(
                str(p).startswith(allowed)
                for allowed in self.config.allowed_dirs
            )
        return True
