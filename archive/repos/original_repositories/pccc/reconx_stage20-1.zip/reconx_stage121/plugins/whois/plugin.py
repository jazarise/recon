"""
ReconX — Stage 19 Plugin: WHOIS

Wraps the existing whois_tool.py with full Stage 19 interface.
WHOIS provides domain registration, registrar, nameserver,
and contact information for passive recon.
"""
from __future__ import annotations

from ...sdk import (
    PluginBaseTool, ToolMetadataBuilder, CAPABILITIES, CapabilitySet,
    RiskLevel, InstallMethod, InputType, OutputType,
)
from ...models.tool_result import ToolRunResult


class WhoisPlugin(PluginBaseTool):
    """
    WHOIS — domain registration and IP block ownership intelligence.

    Wraps: tools/whois_tool.py — WhoisTool
    """

    METADATA = (
        ToolMetadataBuilder(
            "Whois",
            "Domain and IP WHOIS lookup — registrar, registrant, nameservers, ASN",
        )
        .category("osint", "domain_intel")
        .binary("whois")
        .stage(1)
        .priority(5)
        .version("5.x")
        .author("ReconX")
        .risk(RiskLevel.PASSIVE)
        .passive(True)
        .permissions(requires_network=True, read_only=True)
        .capabilities(
            CapabilitySet()
            .add(CAPABILITIES.WHOIS,       "Domain and IP WHOIS registration data")
            .add(CAPABILITIES.ASN_INTEL,   "ASN and netblock ownership from ARIN/RIPE/APNIC")
            .add(CAPABILITIES.ORG_INTEL,   "Organisation, registrar, and contact intelligence")
            .add(CAPABILITIES.REVERSE_DNS, "Nameserver and reverse-lookup intelligence")
        )
        .inputs(InputType.DOMAIN, InputType.IP)
        .outputs(OutputType.FINDINGS, OutputType.DOMAINS)
        .install(InstallMethod.APT, "sudo apt install whois")
        .tags("osint", "passive", "whois", "domain", "registrar", "asn")
        .example("whois example.com")
        .homepage("https://www.whois.com")
        .timeout(30)
        .build()
    )

    def run(self, target: str, **kwargs) -> ToolRunResult:
        """Delegate to existing WhoisTool unchanged."""
        skip = self.skip_if_unavailable()
        if skip:
            return skip
        fail = self.validate_or_fail(target)
        if fail:
            return fail

        try:
            from ...tools.whois_tool import WhoisTool
            return WhoisTool().safe_run(target, **kwargs)
        except ImportError:
            return self.fail(
                reason="import_error",
                message="WhoisTool not found — ensure tools/whois_tool.py exists",
            )

    def parse_output(self, raw: str, **kwargs) -> dict:
        try:
            from ...tools.whois_tool import WhoisTool
            return WhoisTool().parse_output(raw, **kwargs)
        except Exception:
            return {}
