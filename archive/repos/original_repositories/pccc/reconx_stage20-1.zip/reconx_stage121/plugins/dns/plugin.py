"""
ReconX — Stage 19 Plugin: DNS Intelligence

Wraps existing DNS tools (DNSX, MassDNS, etc.) with full Stage 19 interface.
DNS intelligence covers record enumeration, zone transfers, brute-forcing,
and wildcard detection.
"""
from __future__ import annotations

from ...sdk import (
    PluginBaseTool, ToolMetadataBuilder, CAPABILITIES, CapabilitySet,
    RiskLevel, InstallMethod, InputType, OutputType,
)
from ...models.tool_result import ToolRunResult, ParsedFinding


class DNSPlugin(PluginBaseTool):
    """
    DNS Intelligence — record enumeration, brute force, zone transfers.

    Wraps: tools/dns/ — DnsxTool / MassDNSTool
    Primary binary: dnsx (falls back to system dig/host)
    """

    METADATA = (
        ToolMetadataBuilder(
            "DNS",
            "DNS record enumeration, brute-force, zone transfer, and wildcard detection",
        )
        .category("dns", "dns_intel")
        .binary("dnsx")
        .stage(2)
        .priority(8)
        .version("1.x")
        .author("ProjectDiscovery")
        .risk(RiskLevel.LOW)
        .passive(False)
        .permissions(requires_network=True)
        .capabilities(
            CapabilitySet()
            .add(CAPABILITIES.DNS_RESOLVE,   "Bulk DNS resolution of A, AAAA, CNAME, MX, TXT, NS")
            .add(CAPABILITIES.DNS_BRUTE,     "Subdomain brute-forcing via wordlist")
            .add(CAPABILITIES.DNS_WILDCARD,  "Wildcard DNS detection and deduplication")
            .add(CAPABILITIES.ZONE_TRANSFER, "DNS zone transfer attempt (AXFR)")
            .add(CAPABILITIES.REVERSE_DNS,   "Reverse PTR lookups on IP ranges")
        )
        .inputs(InputType.DOMAIN, InputType.IP, InputType.CIDR)
        .outputs(OutputType.SUBDOMAINS, OutputType.IPS, OutputType.DOMAINS)
        .install(InstallMethod.GO, "go install github.com/projectdiscovery/dnsx/cmd/dnsx@latest")
        .tags("dns", "subdomain", "active", "records", "brute-force", "projectdiscovery")
        .example("dnsx -d example.com -a -aaaa -cname -mx -txt -resp")
        .homepage("https://github.com/projectdiscovery/dnsx")
        .timeout(120)
        .build()
    )

    def run(self, target: str, **kwargs) -> ToolRunResult:
        """Try existing DNS tool wrappers in priority order."""
        fail = self.validate_or_fail(target)
        if fail:
            return fail

        # Try dnsx first
        for module_path, class_name in [
            ("tools.dns.dnsx_tool",    "DnsxTool"),
            ("tools.dns.massdns_tool", "MassDNSTool"),
        ]:
            try:
                import importlib
                mod  = importlib.import_module(f"reconx.{module_path}")
                cls  = getattr(mod, class_name)
                tool = cls()
                if tool.is_available():
                    return tool.safe_run(target, **kwargs)
            except (ImportError, AttributeError):
                continue

        # Final fallback: dig
        return self._dig_fallback(target)

    def _dig_fallback(self, target: str) -> ToolRunResult:
        """Use system dig as a last resort."""
        import subprocess, shutil, time
        if not shutil.which("dig"):
            return self.fail(
                reason="not_available",
                message="No DNS tool available (dnsx, massdns, or dig required)",
            )
        t0 = time.perf_counter()
        try:
            r = subprocess.run(
                ["dig", "+short", "A", target],
                capture_output=True, text=True, timeout=15,
            )
            ips = [ln.strip() for ln in r.stdout.splitlines() if ln.strip()]
            findings = [
                ParsedFinding(finding_type="ip_address", value=ip, source="DNS")
                for ip in ips
            ]
            return self.build_result(
                data={"a_records": ips, "target": target},
                findings=findings,
                duration_s=time.perf_counter() - t0,
            )
        except Exception as exc:
            return self.fail(reason="dig_error", message=str(exc))

    def parse_output(self, raw: str, **kwargs) -> dict:
        records = [ln.strip() for ln in raw.splitlines() if ln.strip()]
        return {"records": records}
