"""
ReconX — Community Plugin Marketplace (Stage 15, Part 5).

Provides a searchable catalog of community plugin packs with:
  • Browsable categories (Cloud, OSINT, Web, AI, Bug Bounty, etc.)
  • Version history and compatibility info
  • Install / uninstall via PluginManager
  • Rating metadata (from local cache)
  • Offline-first: built-in catalog ships with ReconX

Future: HTTP registry endpoint for live community submissions.

Built-in packs (ship with ReconX, install on demand):
  cloud_recon_pack   — CloudFox, S3Scanner, AWS enumeration
  osint_pack         — SpiderFoot, Maltego, PhoneInfoga extensions
  bug_bounty_pack    — Nuclei templates, Bug report formatters
  api_recon_pack     — GraphQL, gRPC, REST schema discovery
  wireless_pack      — Aircrack, WiFi survey tools
  ai_agents_pack     — LLM-powered recon suggestions (Part 10 foundation)
  enterprise_pack    — LDAP, AD, SNMP, internal network tools
  identity_pack      — Extended social OSINT, breach correlation
"""
from __future__ import annotations

import json
import logging
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Optional

log = logging.getLogger("reconx.plugins.marketplace")

_CATALOG_CACHE = Path("cache/marketplace_catalog.json")


# ─────────────────────────────────────────────────────────────────────────────
# Pack definition
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class MarketplacePack:
    """One entry in the marketplace catalog."""
    id:           str
    name:         str
    version:      str
    author:       str
    description:  str
    category:     str
    tags:         list[str]
    tools:        list[str]              # tool names included
    min_reconx:   str                    = "14.0"
    license:      str                    = "MIT"
    homepage:     str                    = ""
    rating:       float                  = 0.0    # 0–5
    installs:     int                    = 0
    installed:    bool                   = False
    install_path: str                    = ""
    requires_pip: list[str]              = field(default_factory=list)
    changelog:    dict[str, str]         = field(default_factory=dict)  # version → notes

    def summary(self) -> str:
        stars = "★" * int(self.rating) + "☆" * (5 - int(self.rating))
        return (
            f"[{self.id}] {self.name} v{self.version}  "
            f"{stars}  {self.installs} installs\n"
            f"  {self.description}\n"
            f"  Tools: {', '.join(self.tools[:5])}"
            + (f"… (+{len(self.tools)-5})" if len(self.tools) > 5 else "")
        )

    def to_dict(self) -> dict:
        return asdict(self)


# ─────────────────────────────────────────────────────────────────────────────
# Built-in catalog
# ─────────────────────────────────────────────────────────────────────────────

BUILTIN_CATALOG: list[MarketplacePack] = [
    MarketplacePack(
        id          = "cloud_recon_pack",
        name        = "Cloud Recon Pack",
        version     = "1.0.0",
        author      = "ReconX Team",
        description = "Extended cloud reconnaissance: AWS, GCP, Azure asset discovery, "
                      "IAM analysis, bucket enumeration, and serverless function mapping.",
        category    = "Cloud",
        tags        = ["cloud", "aws", "gcp", "azure", "s3", "iam"],
        tools       = ["CloudFoxTool", "S3ScannerExtended", "AWSBucketDump",
                       "GCPBucketScanner", "AzureStorageScanner", "LambdaEnumerator"],
        rating      = 4.7,
        installs    = 1240,
        requires_pip= ["boto3", "google-cloud-storage"],
        changelog   = {
            "1.0.0": "Initial release with AWS/GCP/Azure coverage",
        },
    ),
    MarketplacePack(
        id          = "osint_pack",
        name        = "OSINT Intelligence Pack",
        version     = "2.1.0",
        author      = "ReconX Community",
        description = "Extended OSINT: breach monitoring, dark web indicators, "
                      "social graph analysis, and company intelligence gathering.",
        category    = "OSINT",
        tags        = ["osint", "passive", "breach", "social", "identity"],
        tools       = ["BreachMonitor", "DarkWebScanner", "LinkedInEnumerator",
                       "CompanyGrapher", "LeakixScanner", "HudsonRock"],
        rating      = 4.5,
        installs    = 980,
        changelog   = {"2.1.0": "Added LeakIX and HudsonRock integrations",
                       "2.0.0": "Dark web monitor added"},
    ),
    MarketplacePack(
        id          = "bug_bounty_pack",
        name        = "Bug Bounty Pack",
        version     = "3.0.1",
        author      = "BugBountyPro",
        description = "Nuclei template runner, scope validator, dedup engine, "
                      "and automated report generator optimised for bug bounty workflows.",
        category    = "Bug Bounty",
        tags        = ["bugbounty", "nuclei", "scope", "reporting", "dedup"],
        tools       = ["NucleiRunner", "ScopeValidator", "DedupEngine",
                       "BugBountyReporter", "HackerOneExporter", "BugcrowdExporter"],
        rating      = 4.9,
        installs    = 3200,
        requires_pip= ["nuclei"],
        changelog   = {"3.0.1": "HackerOne API v2 support",
                       "3.0.0": "Dedup engine rewrite"},
    ),
    MarketplacePack(
        id          = "api_recon_pack",
        name        = "API Intelligence Pack",
        version     = "1.2.0",
        author      = "APIRecon Labs",
        description = "Extended API surface discovery: gRPC, GraphQL schema extraction, "
                      "OpenAPI spec generator, and API fuzzing integration.",
        category    = "API",
        tags        = ["api", "graphql", "grpc", "openapi", "rest", "swagger"],
        tools       = ["gRPCEnumerator", "GraphQLSchemaExtractor", "OpenAPIGenerator",
                       "PostmanCollectionExporter", "APIFuzzer", "SwaggerCrawler"],
        rating      = 4.6,
        installs    = 760,
        changelog   = {"1.2.0": "gRPC support added"},
    ),
    MarketplacePack(
        id          = "wireless_pack",
        name        = "Wireless Recon Pack",
        version     = "1.0.0",
        author      = "WirelessSec",
        description = "Wi-Fi survey, SSID enumeration, captive portal detection, "
                      "and Bluetooth device discovery. Requires wireless hardware.",
        category    = "Wireless",
        tags        = ["wireless", "wifi", "bluetooth", "rfmon", "ssid"],
        tools       = ["WifiSurvey", "SSIDEnumerator", "CaptivePortalDetector",
                       "BluetoothScanner", "EvilTwinDetector"],
        rating      = 4.2,
        installs    = 340,
        changelog   = {"1.0.0": "Initial wireless pack"},
    ),
    MarketplacePack(
        id          = "ai_agents_pack",
        name        = "AI Agents Pack",
        version     = "0.9.0",
        author      = "ReconX AI Lab",
        description = "LLM-powered recon agents: autonomous target analysis, "
                      "smart workflow suggestions, finding correlation, and "
                      "natural language report generation. (Beta)",
        category    = "AI",
        tags        = ["ai", "llm", "agent", "autonomous", "nlp", "beta"],
        tools       = ["ReconAgent", "FindingCorrelator", "WorkflowSuggester",
                       "NLReportGenerator", "VulnClassifier"],
        rating      = 4.1,
        installs    = 520,
        requires_pip= ["openai", "anthropic"],
        changelog   = {"0.9.0": "Beta: autonomous recon loop",
                       "0.8.0": "Finding correlation engine"},
    ),
    MarketplacePack(
        id          = "enterprise_pack",
        name        = "Enterprise Internal Pack",
        version     = "1.1.0",
        author      = "EnterpriseSec",
        description = "Internal network recon: LDAP/AD enumeration, SNMP walker, "
                      "SMB share mapping, Kerberoasting indicators, and internal "
                      "DNS zone analysis.",
        category    = "Enterprise",
        tags        = ["enterprise", "internal", "ldap", "ad", "snmp", "smb", "kerberos"],
        tools       = ["LDAPEnumerator", "ADExplorer", "SNMPWalker",
                       "SMBMapper", "KerberoastDetector", "InternalDNSAnalyzer"],
        rating      = 4.8,
        installs    = 1800,
        changelog   = {"1.1.0": "Kerberoast detection added"},
    ),
    MarketplacePack(
        id          = "identity_pack",
        name        = "Identity Intelligence Pack",
        version     = "1.0.0",
        author      = "OSINT Collective",
        description = "Extended identity OSINT: breach correlation, paste monitoring, "
                      "social graph analysis, and employee enumeration.",
        category    = "Identity",
        tags        = ["identity", "osint", "breach", "paste", "social", "employee"],
        tools       = ["PasteMonitor", "BreachCorrelator", "EmployeeEnumerator",
                       "SocialGraphAnalyzer", "LinkedInScraper", "HaveIBeenPwned"],
        rating      = 4.4,
        installs    = 670,
        changelog   = {"1.0.0": "Initial identity pack"},
    ),
]

# Category order for UI
MARKETPLACE_CATEGORIES = [
    "All", "Cloud", "OSINT", "Bug Bounty", "API",
    "Wireless", "AI", "Enterprise", "Identity",
]


# ─────────────────────────────────────────────────────────────────────────────
# Marketplace
# ─────────────────────────────────────────────────────────────────────────────

class Marketplace:
    """
    Plugin marketplace — browsing, search, install, and rating.

    Usage:
        mp = Marketplace()
        packs = mp.search("cloud")
        mp.install("cloud_recon_pack", manager=plugin_manager)
    """

    def __init__(
        self,
        manager = None,         # PluginManager instance
        catalog: Optional[list[MarketplacePack]] = None,
    ):
        self.manager = manager
        self._catalog: list[MarketplacePack] = catalog or list(BUILTIN_CATALOG)
        self._load_local_catalog()

    # ── browsing ─────────────────────────────────────────────────────────────

    def all_packs(self) -> list[MarketplacePack]:
        return list(self._catalog)

    def by_category(self, category: str) -> list[MarketplacePack]:
        if category.lower() in ("all", ""):
            return self.all_packs()
        return [p for p in self._catalog if p.category.lower() == category.lower()]

    def by_tag(self, tag: str) -> list[MarketplacePack]:
        tag_lower = tag.lower()
        return [p for p in self._catalog if tag_lower in (t.lower() for t in p.tags)]

    def search(self, query: str) -> list[MarketplacePack]:
        q = query.lower()
        return [
            p for p in self._catalog
            if q in p.name.lower()
            or q in p.description.lower()
            or q in p.id.lower()
            or any(q in t.lower() for t in p.tags)
            or any(q in tool.lower() for tool in p.tools)
        ]

    def get(self, pack_id: str) -> Optional[MarketplacePack]:
        return next((p for p in self._catalog if p.id == pack_id), None)

    def installed_packs(self) -> list[MarketplacePack]:
        return [p for p in self._catalog if p.installed]

    def top_rated(self, n: int = 5) -> list[MarketplacePack]:
        return sorted(self._catalog, key=lambda p: p.rating, reverse=True)[:n]

    def most_installed(self, n: int = 5) -> list[MarketplacePack]:
        return sorted(self._catalog, key=lambda p: p.installs, reverse=True)[:n]

    # ── install ───────────────────────────────────────────────────────────────

    def install(
        self,
        pack_id:     str,
        install_pip: bool = True,
    ) -> tuple[bool, str]:
        """
        Install a pack by ID.

        Returns (success, message).
        """
        pack = self.get(pack_id)
        if not pack:
            return False, f"Pack not found: {pack_id!r}"
        if pack.installed:
            return True, f"{pack.name} is already installed."

        install_dir = Path(f"plugins/packs/{pack_id}")
        install_dir.mkdir(parents=True, exist_ok=True)

        # Install pip dependencies
        if install_pip and pack.requires_pip:
            import subprocess, sys
            for dep in pack.requires_pip:
                try:
                    result = subprocess.run(
                        [sys.executable, "-m", "pip", "install", dep,
                         "--break-system-packages", "-q"],
                        capture_output=True, text=True
                    )
                    if result.returncode != 0:
                        log.warning(f"pip install {dep!r} failed: {result.stderr[:100]}")
                except Exception as e:
                    log.warning(f"Cannot install dep {dep!r}: {e}")

        # Write a stub __init__.py so the pack is a valid Python package
        init = install_dir / "__init__.py"
        if not init.exists():
            init.write_text(
                f'"""ReconX Pack: {pack.name} v{pack.version}"""\n'
                f'PACK_NAME = "{pack.name}"\n'
                f'PACK_VERSION = "{pack.version}"\n'
            )

        pack.installed    = True
        pack.install_path = str(install_dir)
        pack.installs    += 1

        # Notify plugin manager
        if self.manager:
            self.manager.install_pack(pack_id)

        self._save_local_catalog()
        log.info(f"Installed pack: {pack.name} v{pack.version}")
        return True, f"Installed {pack.name} v{pack.version} → {install_dir}"

    def uninstall(self, pack_id: str) -> tuple[bool, str]:
        pack = self.get(pack_id)
        if not pack:
            return False, f"Pack not found: {pack_id!r}"
        if not pack.installed:
            return False, f"{pack.name} is not installed."

        # Remove directory
        install_dir = Path(pack.install_path) if pack.install_path else None
        if install_dir and install_dir.is_dir():
            import shutil
            shutil.rmtree(install_dir)

        pack.installed    = False
        pack.install_path = ""
        self._save_local_catalog()
        return True, f"Uninstalled {pack.name}"

    def rate(self, pack_id: str, stars: float) -> bool:
        """Set local rating for a pack (1.0–5.0)."""
        pack = self.get(pack_id)
        if not pack:
            return False
        pack.rating = max(1.0, min(5.0, float(stars)))
        self._save_local_catalog()
        return True

    # ── persistence ───────────────────────────────────────────────────────────

    def _load_local_catalog(self) -> None:
        if not _CATALOG_CACHE.exists():
            return
        try:
            data = json.loads(_CATALOG_CACHE.read_text())
            for pack_data in data:
                pid = pack_data.get("id", "")
                existing = self.get(pid)
                if existing:
                    # Merge local state (installed, rating) into built-in
                    existing.installed    = pack_data.get("installed", False)
                    existing.install_path = pack_data.get("install_path", "")
                    existing.rating       = pack_data.get("rating", existing.rating)
                    existing.installs     = pack_data.get("installs", existing.installs)
                else:
                    # Community-added pack not in built-in catalog
                    try:
                        self._catalog.append(MarketplacePack(**pack_data))
                    except Exception:
                        pass
        except Exception as e:
            log.debug(f"Catalog load warning: {e}")

    def _save_local_catalog(self) -> None:
        _CATALOG_CACHE.parent.mkdir(parents=True, exist_ok=True)
        try:
            _CATALOG_CACHE.write_text(
                json.dumps([p.to_dict() for p in self._catalog], indent=2)
            )
        except Exception as e:
            log.warning(f"Cannot save marketplace catalog: {e}")
