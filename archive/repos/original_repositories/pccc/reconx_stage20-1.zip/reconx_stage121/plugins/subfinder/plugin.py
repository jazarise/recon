"""
ReconX — Stage 19 Plugin: Subfinder

Wraps the existing subfinder tool with full Stage 19 interface.
Subfinder is the fastest passive subdomain enumerator, using multiple APIs
and data sources simultaneously.
"""
from __future__ import annotations

from ...sdk import (
    PluginBaseTool, ToolMetadataBuilder, CAPABILITIES, CapabilitySet,
    RiskLevel, InstallMethod, InputType, OutputType,
)
from ...models.tool_result import ToolRunResult, ParsedFinding


class SubfinderPlugin(PluginBaseTool):
    """
    Subfinder — fast passive subdomain enumeration using multiple APIs.

    Wraps: existing subfinder tool implementations
    """

    METADATA = (
        ToolMetadataBuilder(
            "Subfinder",
            "Fast passive subdomain discovery using multiple API sources simultaneously",
        )
        .category("subdomain", "passive_enum")
        .binary("subfinder")
        .stage(2)
        .priority(5)
        .version("2.x")
        .author("ProjectDiscovery")
        .risk(RiskLevel.PASSIVE)
        .passive(True)
        .permissions(requires_network=True)
        .capabilities(
            CapabilitySet()
            .add(CAPABILITIES.SUBDOMAIN_ENUM, "Passive subdomain enumeration via 40+ sources")
            .add(CAPABILITIES.DNS_RESOLVE,    "Automated DNS resolution of discovered subdomains")
            .add(CAPABILITIES.DNS_WILDCARD,   "Wildcard subdomain detection and filtering")
        )
        .inputs(InputType.DOMAIN)
        .outputs(OutputType.SUBDOMAINS, OutputType.DOMAINS)
        .install(InstallMethod.GO, "go install github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest")
        .tags("subdomain", "passive", "osint", "dns", "projectdiscovery")
        .example("subfinder -d example.com -silent")
        .homepage("https://github.com/projectdiscovery/subfinder")
        .timeout(120)
        .build()
    )

    def run(self, target: str, **kwargs) -> ToolRunResult:
        """Run subfinder — try existing tool wrapper first."""
        skip = self.skip_if_unavailable()
        if skip:
            return skip
        fail = self.validate_or_fail(target)
        if fail:
            return fail

        # Try existing tool wrappers
        for _import_path in [
            ("tools.subfinder", "SubfinderTool"),
            ("tools.dns.subfinder_tool", "SubfinderTool"),
        ]:
            try:
                import importlib
                mod  = importlib.import_module(f"reconx.{_import_path[0]}")
                cls  = getattr(mod, _import_path[1])
                return cls().safe_run(target, **kwargs)
            except (ImportError, AttributeError):
                continue

        # Fallback: call binary directly
        return self._run_direct(target)

    def _run_direct(self, target: str) -> ToolRunResult:
        """Direct subprocess fallback."""
        import subprocess, shutil, time
        t0 = time.perf_counter()
        try:
            r = subprocess.run(
                ["subfinder", "-d", target, "-silent", "-nc"],
                capture_output=True, text=True, timeout=self.TIMEOUT,
            )
            subdomains = [
                line.strip().lower() for line in r.stdout.splitlines()
                if line.strip() and "." in line
            ]
            findings = [
                ParsedFinding(finding_type="subdomain", value=s, source="Subfinder")
                for s in subdomains
            ]
            return self.build_result(
                data={"subdomains": subdomains},
                findings=findings,
                duration_s=time.perf_counter() - t0,
            )
        except Exception as exc:
            return self.fail(reason="run_error", message=str(exc))

    def parse_output(self, raw: str, **kwargs) -> dict:
        subdomains = [
            line.strip().lower() for line in raw.splitlines()
            if line.strip() and "." in line and " " not in line.strip()
        ]
        return {"subdomains": list(set(subdomains))}
