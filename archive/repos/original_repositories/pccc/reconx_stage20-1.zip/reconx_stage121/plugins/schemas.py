"""
ReconX — Plugin Schemas (Stage 15).

Defines and validates data schemas for:
  • Plugin manifests (MANIFEST attribute)
  • Workflow pack definitions (JSON files)
  • Marketplace pack entries
  • Plugin audit records

All validation is pure Python — no external schema library required.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional


# ─────────────────────────────────────────────────────────────────────────────
# Validation result
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class ValidationResult:
    valid:    bool
    errors:   list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    def add_error(self, msg: str)   -> None: self.errors.append(msg);   self.valid = False
    def add_warning(self, msg: str) -> None: self.warnings.append(msg)

    def __str__(self) -> str:
        lines = []
        for e in self.errors:   lines.append(f"  ERROR:   {e}")
        for w in self.warnings: lines.append(f"  WARNING: {w}")
        return "\n".join(lines) or "  OK"


# ─────────────────────────────────────────────────────────────────────────────
# Regex patterns
# ─────────────────────────────────────────────────────────────────────────────

_RE_NAME    = re.compile(r"^[a-z0-9][a-z0-9\-_]{1,63}$")
_RE_VERSION = re.compile(r"^\d+\.\d+(\.\d+)?(-[a-z0-9]+)?$")
_RE_EMAIL   = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")

VALID_PLUGIN_TYPES  = ("tool", "workflow", "analyzer", "exporter", "learning", "agent")
VALID_SCAN_MODES    = ("fast", "balanced", "deep", "passive", "custom", "ai")
VALID_TARGET_TYPES  = ("domain", "ip", "cidr", "url", "asn", "email",
                        "phone", "github_repo", "github_org", "cloud_bucket",
                        "git_url", "any")
VALID_CATEGORIES    = ("web", "dns", "network", "osint", "passive", "active",
                        "subdomain", "api_recon", "cloud", "certs", "fingerprint",
                        "identity", "secrets", "screenshot", "framework", "utility",
                        "plugin", "asset", "param", "dns_intel", "dns_extra")


# ─────────────────────────────────────────────────────────────────────────────
# Manifest validator
# ─────────────────────────────────────────────────────────────────────────────

def validate_manifest(manifest_dict: dict) -> ValidationResult:
    """
    Validate a plugin manifest dict.

    Expected keys:
        name, version, plugin_type (required)
        author, description, tags, dependencies,
        min_reconx, homepage, license (optional)
    """
    vr = ValidationResult(valid=True)

    # Required fields
    name = manifest_dict.get("name", "")
    if not name:
        vr.add_error("'name' is required.")
    elif not _RE_NAME.match(name):
        vr.add_error(
            f"'name' must be lowercase alphanumeric with dashes/underscores: {name!r}"
        )

    version = manifest_dict.get("version", "")
    if not version:
        vr.add_error("'version' is required.")
    elif not _RE_VERSION.match(version):
        vr.add_error(f"'version' must match SEMVER (e.g. 1.0.0): {version!r}")

    ptype = manifest_dict.get("plugin_type", "")
    if not ptype:
        vr.add_error("'plugin_type' is required.")
    elif ptype not in VALID_PLUGIN_TYPES:
        vr.add_error(f"'plugin_type' must be one of {VALID_PLUGIN_TYPES}: {ptype!r}")

    # Optional but validated
    author = manifest_dict.get("author", "")
    if author and "@" in author and not _RE_EMAIL.match(author):
        vr.add_warning(f"'author' looks like an email but is invalid: {author!r}")

    tags = manifest_dict.get("tags", [])
    if not isinstance(tags, list):
        vr.add_error("'tags' must be a list of strings.")
    else:
        for t in tags:
            if not isinstance(t, str):
                vr.add_error(f"Each tag must be a string: {t!r}")

    deps = manifest_dict.get("dependencies", [])
    if not isinstance(deps, list):
        vr.add_error("'dependencies' must be a list of strings.")

    min_reconx = manifest_dict.get("min_reconx", "")
    if min_reconx and not _RE_VERSION.match(min_reconx):
        vr.add_warning(f"'min_reconx' does not look like a version: {min_reconx!r}")

    description = manifest_dict.get("description", "")
    if not description:
        vr.add_warning("'description' is empty — provide a brief description.")
    elif len(description) > 500:
        vr.add_warning("'description' exceeds 500 characters.")

    return vr


# ─────────────────────────────────────────────────────────────────────────────
# Workflow pack validator
# ─────────────────────────────────────────────────────────────────────────────

def validate_workflow_pack(pack_dict: dict) -> ValidationResult:
    """
    Validate a workflow pack definition (JSON file schema).

    Expected schema:
    {
      "name":         "web-recon-workflow",
      "version":      "1.0.0",
      "author":       "...",
      "description":  "...",
      "target_types": ["domain", "url"],
      "mode":         "balanced",
      "steps": [
        {"tool": "HttpxTool",       "description": "..."},
        {"tool": "KatanaTool",      "description": "...", "optional": true},
        {"tool": "FeroxbusterTool", "description": "..."}
      ]
    }
    """
    vr = ValidationResult(valid=True)

    # name / version / description (reuse manifest rules)
    for required in ("name", "version", "steps"):
        if not pack_dict.get(required):
            vr.add_error(f"'{required}' is required in workflow pack.")

    name = pack_dict.get("name", "")
    if name and not _RE_NAME.match(name):
        vr.add_error(f"'name' must be kebab-case lowercase: {name!r}")

    mode = pack_dict.get("mode", "balanced")
    if mode not in VALID_SCAN_MODES:
        vr.add_error(f"'mode' must be one of {VALID_SCAN_MODES}: {mode!r}")

    ttypes = pack_dict.get("target_types", [])
    if not isinstance(ttypes, list) or not ttypes:
        vr.add_warning("'target_types' should list applicable target types.")
    else:
        for tt in ttypes:
            if tt not in VALID_TARGET_TYPES:
                vr.add_warning(f"Unknown target_type: {tt!r}")

    # Steps validation
    steps = pack_dict.get("steps", [])
    if not isinstance(steps, list):
        vr.add_error("'steps' must be a list.")
    elif len(steps) == 0:
        vr.add_error("'steps' must not be empty.")
    else:
        for i, step in enumerate(steps):
            if not isinstance(step, dict):
                vr.add_error(f"Step [{i}] must be a dict.")
                continue
            if not step.get("tool"):
                vr.add_error(f"Step [{i}] missing 'tool' field.")
            if not step.get("description"):
                vr.add_warning(f"Step [{i}] ({step.get('tool','?')}) has no description.")

    return vr


# ─────────────────────────────────────────────────────────────────────────────
# Tool plugin validator (for BaseToolPlugin subclasses)
# ─────────────────────────────────────────────────────────────────────────────

def validate_tool_plugin(cls) -> ValidationResult:
    """
    Validate a BaseToolPlugin subclass has all required BaseTool attributes.
    """
    vr = ValidationResult(valid=True)

    required_attrs = [
        ("NAME",        str),
        ("BINARY",      str),
        ("CATEGORY",    str),
        ("STAGE",       int),
        ("TIMEOUT",     int),
        ("INSTALL_CMD", str),
    ]
    for attr, expected_type in required_attrs:
        val = getattr(cls, attr, None)
        if val is None:
            vr.add_error(f"Missing class attribute: {attr}")
        elif not isinstance(val, expected_type):
            vr.add_error(f"{attr} must be {expected_type.__name__}, got {type(val).__name__}")

    category = getattr(cls, "CATEGORY", "")
    if category and category.lower() not in VALID_CATEGORIES:
        vr.add_warning(
            f"CATEGORY {category!r} is not a standard category. "
            f"Valid: {VALID_CATEGORIES}"
        )

    # Ensure parse_output and run methods exist
    for method in ("run", "parse_output"):
        if not callable(getattr(cls, method, None)):
            vr.add_error(f"Missing required method: {method}()")

    return vr


# ─────────────────────────────────────────────────────────────────────────────
# Workflow pack file loader + validator
# ─────────────────────────────────────────────────────────────────────────────

def load_and_validate_workflow_pack(path: str) -> tuple[Optional[dict], ValidationResult]:
    """
    Load a .json workflow pack file and validate it.

    Returns (pack_dict, ValidationResult).
    pack_dict is None if the file cannot be parsed.
    """
    p = Path(path)
    if not p.exists():
        vr = ValidationResult(valid=False,
                               errors=[f"File not found: {path}"])
        return None, vr
    if p.suffix.lower() != ".json":
        vr = ValidationResult(valid=False,
                               errors=[f"Expected .json file, got: {p.suffix}"])
        return None, vr
    try:
        pack_dict = json.loads(p.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        vr = ValidationResult(valid=False,
                               errors=[f"JSON parse error: {e}"])
        return None, vr

    vr = validate_workflow_pack(pack_dict)
    return pack_dict, vr


# ─────────────────────────────────────────────────────────────────────────────
# Built-in workflow pack JSON definitions
# ─────────────────────────────────────────────────────────────────────────────

BUILTIN_WORKFLOW_PACKS: list[dict] = [
    {
        "name":        "web-recon-workflow",
        "version":     "1.0.0",
        "author":      "ReconX Team",
        "description": "Comprehensive web application reconnaissance workflow.",
        "target_types": ["domain", "url"],
        "mode":        "balanced",
        "steps": [
            {"tool": "WhoisTool",        "description": "Domain registration intel"},
            {"tool": "CrtshTool",        "description": "Certificate transparency"},
            {"tool": "HttpxTool",        "description": "HTTP probing and tech detection"},
            {"tool": "Wafw00fTool",      "description": "WAF detection"},
            {"tool": "WhatWebTool",      "description": "Technology fingerprinting"},
            {"tool": "GauTool",          "description": "Historical URL collection"},
            {"tool": "KatanaTool",       "description": "JS-aware web crawling", "optional": True},
            {"tool": "FeroxbusterTool",  "description": "Content discovery"},
            {"tool": "ParamSpiderTool",  "description": "Parameter mining"},
            {"tool": "GoWitnessTool",    "description": "Visual reconnaissance"},
        ],
    },
    {
        "name":        "passive-recon-workflow",
        "version":     "1.0.0",
        "author":      "ReconX Team",
        "description": "Zero-traffic passive reconnaissance using OSINT and archives only.",
        "target_types": ["domain", "asn", "email"],
        "mode":        "passive",
        "steps": [
            {"tool": "WhoisTool",          "description": "WHOIS registration data"},
            {"tool": "CrtshTool",          "description": "Certificate transparency logs"},
            {"tool": "TheHarvesterTool",   "description": "OSINT intelligence gathering"},
            {"tool": "GitHubSubdomainsTool","description": "GitHub code intelligence"},
            {"tool": "Sublist3rTool",      "description": "Passive subdomain enumeration"},
            {"tool": "GauTool",            "description": "Historical URL collection"},
            {"tool": "WaymoreTool",        "description": "Multi-source URL aggregation"},
            {"tool": "S3ScannerTool",      "description": "Cloud bucket enumeration"},
            {"tool": "MaltegoTool",        "description": "Entity graph export"},
        ],
    },
    {
        "name":        "cloud-recon-workflow",
        "version":     "1.0.0",
        "author":      "ReconX Team",
        "description": "Cloud infrastructure reconnaissance: ASN, CIDR, buckets, certs.",
        "target_types": ["domain", "asn", "cidr"],
        "mode":        "balanced",
        "steps": [
            {"tool": "WhoisTool",      "description": "WHOIS for org/ASN hints"},
            {"tool": "AsnmapTool",     "description": "ASN to CIDR mapping"},
            {"tool": "MapCIDRTool",    "description": "CIDR expansion"},
            {"tool": "FpingTool",      "description": "Host discovery"},
            {"tool": "CrtshTool",      "description": "Certificate transparency"},
            {"tool": "TLSXTool",       "description": "TLS fingerprinting"},
            {"tool": "S3ScannerTool",  "description": "Cloud bucket exposure"},
            {"tool": "HttpxTool",      "description": "HTTP probing on cloud IPs"},
        ],
    },
    {
        "name":        "enterprise-internal-workflow",
        "version":     "1.0.0",
        "author":      "ReconX Team",
        "description": "Internal network reconnaissance for enterprise environments.",
        "target_types": ["cidr", "ip", "domain"],
        "mode":        "balanced",
        "steps": [
            {"tool": "NetdiscoverTool",   "description": "ARP host discovery"},
            {"tool": "FpingTool",         "description": "ICMP sweep"},
            {"tool": "NmapTool",          "description": "Port scan + services"},
            {"tool": "NetcatWrapperTool", "description": "Banner grabbing"},
            {"tool": "MetasploitAuxTool", "description": "Service fingerprinting"},
            {"tool": "TLSXTool",          "description": "Internal TLS certs"},
            {"tool": "TestSSLTool",       "description": "TLS vulnerability audit"},
        ],
    },
    {
        "name":        "bug-bounty-workflow",
        "version":     "1.0.0",
        "author":      "ReconX Team",
        "description": "Modern bug bounty reconnaissance optimised for speed and coverage.",
        "target_types": ["domain"],
        "mode":        "balanced",
        "steps": [
            {"tool": "WhoisTool",           "description": "Registration intel"},
            {"tool": "CrtshTool",           "description": "CT log subdomains"},
            {"tool": "TheHarvesterTool",    "description": "OSINT harvest"},
            {"tool": "GitHubSubdomainsTool","description": "GitHub recon"},
            {"tool": "Sublist3rTool",       "description": "Passive subdomains"},
            {"tool": "AlterxTool",          "description": "Permutation generation"},
            {"tool": "PureDNSTool",         "description": "Validated subdomains"},
            {"tool": "HttpxTool",           "description": "HTTP probe"},
            {"tool": "Wafw00fTool",         "description": "WAF detection"},
            {"tool": "GauTool",             "description": "Historical URLs"},
            {"tool": "WaymoreTool",         "description": "Archive aggregation"},
            {"tool": "KatanaTool",          "description": "JS crawl"},
            {"tool": "FeroxbusterTool",     "description": "Content discovery"},
            {"tool": "ParamSpiderTool",     "description": "Parameter mining"},
            {"tool": "ArjunTool",           "description": "Active params"},
            {"tool": "GoWitnessTool",       "description": "Screenshots"},
            {"tool": "S3ScannerTool",       "description": "Cloud buckets"},
            {"tool": "TrufflehogTool",      "description": "Credential scan", "optional": True},
        ],
    },
]


def get_builtin_workflow_pack(name: str) -> Optional[dict]:
    for pack in BUILTIN_WORKFLOW_PACKS:
        if pack["name"] == name:
            return pack
    return None


def save_builtin_workflow_packs(output_dir: str = "plugins/packs/workflows") -> list[str]:
    """Write all built-in workflow packs as JSON files."""
    d = Path(output_dir)
    d.mkdir(parents=True, exist_ok=True)
    saved = []
    for pack in BUILTIN_WORKFLOW_PACKS:
        path = d / f"{pack['name']}.json"
        path.write_text(json.dumps(pack, indent=2))
        saved.append(str(path))
    return saved
