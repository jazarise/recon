"""
ReconX — Plugin SDK (Stage 15, Part 3).

Provides the base classes, hooks, decorators, and interfaces
that plugin developers use to extend ReconX.

Plugin types:
  BaseToolPlugin      — wraps a new tool (inherits BaseTool automatically)
  BaseWorkflowPlugin  — defines a new recon workflow / chain
  BaseAnalyzerPlugin  — post-processing / finding analysis
  BaseExporterPlugin  — new output format / integration
  BaseLearningPlugin  — adds tool lessons and educational content
  BaseAgentPlugin     — future AI agent interface (stub for Part 10)

Plugin lifecycle hooks:
  on_load()       — called when plugin is registered
  on_execute()    — called before each tool run
  on_finish()     — called after tool run completes
  on_error()      — called on exceptions during run
  on_report()     — called during report generation
  on_unload()     — called when plugin is removed/disabled
"""
from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Callable, Optional

log = logging.getLogger("reconx.plugins.sdk")


# ─────────────────────────────────────────────────────────────────────────────
# Plugin manifest — declared as class attributes on every plugin
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class PluginManifest:
    """Metadata every plugin must declare."""
    name:         str
    version:      str              = "1.0.0"
    author:       str              = ""
    description:  str              = ""
    plugin_type:  str              = "tool"      # tool|workflow|analyzer|exporter|learning|agent
    tags:         list[str]        = field(default_factory=list)
    dependencies: list[str]        = field(default_factory=list)  # pip packages
    min_reconx:   str              = "14.0"
    homepage:     str              = ""
    license:      str              = "MIT"

    def validate(self) -> list[str]:
        """Return list of validation errors (empty = valid)."""
        errors = []
        if not self.name:
            errors.append("Plugin 'name' is required.")
        if not self.version:
            errors.append("Plugin 'version' is required.")
        if self.plugin_type not in (
            "tool", "workflow", "analyzer", "exporter", "learning", "agent"
        ):
            errors.append(f"Unknown plugin_type: {self.plugin_type!r}")
        return errors


# ─────────────────────────────────────────────────────────────────────────────
# Base plugin
# ─────────────────────────────────────────────────────────────────────────────

class BaseReconPlugin(ABC):
    """
    Root base class for all ReconX plugins.

    Every plugin must declare a MANIFEST class attribute and may
    override any lifecycle hook method.

    Example:
        class MyPlugin(BaseToolPlugin):
            MANIFEST = PluginManifest(
                name="my-tool",
                version="1.0.0",
                author="me",
                description="Does something useful",
                plugin_type="tool",
                tags=["web", "active"],
            )

            def on_load(self):
                self.log("MyPlugin loaded.")

            def run(self, target, **kwargs):
                ...
    """

    MANIFEST: PluginManifest = PluginManifest(name="unnamed", plugin_type="tool")

    def __init__(self):
        self._enabled  = True
        self._load_error: Optional[str] = None
        self.log       = logging.getLogger(f"reconx.plugin.{self.MANIFEST.name}")

    # ── lifecycle hooks (override as needed) ──────────────────────────────────

    def on_load(self) -> None:
        """Called once when the plugin is first registered."""

    def on_execute(self, target: str, kwargs: dict) -> None:
        """Called before each execution. Can modify kwargs in-place."""

    def on_finish(self, target: str, result: Any) -> None:
        """Called after each execution with the result."""

    def on_error(self, target: str, error: Exception) -> None:
        """Called when an exception occurs during execution."""
        self.log.error(f"Plugin error on target {target!r}: {error}")

    def on_report(self, report_context: dict) -> Optional[dict]:
        """
        Called during report generation.
        Return a dict with additional data to include, or None.
        """
        return None

    def on_unload(self) -> None:
        """Called when plugin is disabled or removed."""

    # ── utility ───────────────────────────────────────────────────────────────

    @property
    def name(self) -> str:
        return self.MANIFEST.name

    @property
    def version(self) -> str:
        return self.MANIFEST.version

    @property
    def is_enabled(self) -> bool:
        return self._enabled

    def enable(self)  -> None: self._enabled = True
    def disable(self) -> None: self._enabled = False

    def __repr__(self) -> str:
        return f"<{type(self).__name__} name={self.name!r} v{self.version}>"


# ─────────────────────────────────────────────────────────────────────────────
# Specialised plugin bases
# ─────────────────────────────────────────────────────────────────────────────

class BaseToolPlugin(BaseReconPlugin):
    """
    Plugin that provides a new reconnaissance tool.

    Subclasses must also mix in BaseTool (from tools/base.py) so they
    integrate with the Tool Registry. The SDK handles registration.

    Minimal implementation:
        class MyTool(BaseToolPlugin):
            MANIFEST = PluginManifest(name="mytool", plugin_type="tool", ...)
            NAME    = "mytool"
            BINARY  = "mytool"
            CATEGORY = "web"
            STAGE   = 2
            PASSIVE = False
            TIMEOUT = 60
            INSTALL_CMD = "pip install mytool"

            def run(self, target, **kwargs):
                ...

            def parse_output(self, raw, **kwargs):
                ...
    """
    MANIFEST = PluginManifest(name="unnamed-tool", plugin_type="tool")


class BaseWorkflowPlugin(BaseReconPlugin):
    """
    Plugin that defines a new recon workflow (ordered tool chain).

    Attributes:
        WORKFLOW_STEPS: list[str]  — ordered tool class names
        WORKFLOW_NAME:  str        — human-readable chain name
        TARGET_TYPES:   list[str]  — applicable target types
    """
    MANIFEST       = PluginManifest(name="unnamed-workflow", plugin_type="workflow")
    WORKFLOW_NAME  = "Unnamed Workflow"
    WORKFLOW_STEPS: list[str] = []
    TARGET_TYPES:  list[str] = ["domain"]

    @abstractmethod
    def get_steps(self) -> list[str]:
        """Return ordered list of tool class names."""
        return list(self.WORKFLOW_STEPS)

    def get_description(self) -> str:
        return f"{self.WORKFLOW_NAME}: " + " → ".join(
            s.replace("Tool", "") for s in self.get_steps()[:5]
        ) + ("…" if len(self.get_steps()) > 5 else "")


class BaseAnalyzerPlugin(BaseReconPlugin):
    """
    Plugin that post-processes findings.

    Called after each tool run with the accumulated findings.
    Can enrich, correlate, de-duplicate, or score findings.
    """
    MANIFEST = PluginManifest(name="unnamed-analyzer", plugin_type="analyzer")

    @abstractmethod
    def analyze(self, findings: list, context: dict) -> list:
        """
        Process findings and return enriched/filtered list.

        Args:
            findings: List of ParsedFinding objects or dicts.
            context:  Shared pipeline context dict.
        Returns:
            Modified or supplemented findings list.
        """
        return findings


class BaseExporterPlugin(BaseReconPlugin):
    """
    Plugin that exports findings in a new format.

    Examples: Slack notification, Jira ticket, CSV, XML, SARIF.
    """
    MANIFEST     = PluginManifest(name="unnamed-exporter", plugin_type="exporter")
    FORMAT_NAME  = "unknown"
    FILE_EXT     = ".txt"

    @abstractmethod
    def export(
        self,
        findings:   list,
        context:    dict,
        output_path: str,
    ) -> bool:
        """
        Export findings to the given path.

        Returns True on success, False on failure.
        """
        ...


class BaseLearningPlugin(BaseReconPlugin):
    """
    Plugin that adds educational content to Learning Mode.

    Provides lessons, relationships, and example commands
    that appear alongside built-in content.
    """
    MANIFEST  = PluginManifest(name="unnamed-learning", plugin_type="learning")

    def get_lessons(self) -> list[dict]:
        """
        Return a list of lesson dicts:
            [{name, tagline, problem_solved, how_it_works,
              use_cases, examples, install, tags}]
        """
        return []

    def get_relationships(self) -> list[dict]:
        """
        Return tool relationship dicts:
            [{from_tool, to_tool, reason, benefit}]
        """
        return []


class BaseAgentPlugin(BaseReconPlugin):
    """
    Future AI agent interface (Part 10 foundation).

    Agents can observe pipeline state, propose next steps,
    and execute autonomous sub-workflows.
    """
    MANIFEST     = PluginManifest(name="unnamed-agent", plugin_type="agent")
    AGENT_TYPE   = "generic"    # "osint"|"web"|"infra"|"cloud"|"identity"

    def observe(self, state: dict) -> Optional[dict]:
        """
        Observe current pipeline state.
        Return suggestions dict or None.
        """
        return None

    def propose(self, state: dict) -> list[str]:
        """
        Propose next tool class names to execute.
        """
        return []

    def act(self, target: str, state: dict) -> Any:
        """
        Execute an autonomous action.
        Returns result or None.
        """
        return None


# ─────────────────────────────────────────────────────────────────────────────
# Decorators for plugin authors
# ─────────────────────────────────────────────────────────────────────────────

def reconx_plugin(
    name:        str,
    version:     str  = "1.0.0",
    plugin_type: str  = "tool",
    author:      str  = "",
    description: str  = "",
    tags:        Optional[list[str]] = None,
    dependencies: Optional[list[str]] = None,
    min_reconx:  str  = "14.0",
):
    """
    Class decorator that injects a MANIFEST into a plugin class.

    Usage:
        @reconx_plugin(
            name="my-custom-tool",
            version="1.2.0",
            plugin_type="tool",
            author="me@example.com",
            tags=["web", "passive"],
        )
        class MyCustomTool(BaseToolPlugin):
            ...
    """
    def decorator(cls):
        cls.MANIFEST = PluginManifest(
            name         = name,
            version      = version,
            plugin_type  = plugin_type,
            author       = author,
            description  = description or (cls.__doc__ or "").strip()[:200],
            tags         = tags or [],
            dependencies = dependencies or [],
            min_reconx   = min_reconx,
        )
        return cls
    return decorator


def plugin_hook(hook_name: str):
    """
    Method decorator that registers a function as a plugin hook.
    Primarily for documentation — the hook system uses method name conventions.

    Usage:
        @plugin_hook("on_finish")
        def my_finish_handler(self, target, result):
            ...
    """
    def decorator(fn: Callable) -> Callable:
        fn._plugin_hook = hook_name
        return fn
    return decorator
