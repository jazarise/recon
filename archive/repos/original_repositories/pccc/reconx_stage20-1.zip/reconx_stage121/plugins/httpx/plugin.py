"""
ReconX — Stage 19 Plugin: HTTPX

Wraps the existing httpx_tool.py with full Stage 19 interface.
HTTPX is the fastest HTTP/HTTPS prober — handles redirect chains,
CDN detection, TLS inspection, and technology fingerprinting.
"""
from __future__ import annotations

from ...sdk import (
    PluginBaseTool, ToolMetadataBuilder, CAPABILITIES, COMMON_CAPS,
    RiskLevel, InstallMethod, InputType, OutputType, CapabilitySet,
)
from ...models.tool_result import ToolRunResult


class HTTPXPlugin(PluginBaseTool):
    """
    HTTPX — fast multi-purpose HTTP prober and web fingerprinter.

    Wraps: tools/httpx_tool.py — HTTPXTool
    """

    METADATA = (
        ToolMetadataBuilder(
            "HTTPX",
            "Fast HTTP/HTTPS prober — fingerprints, TLS, redirects, status codes at scale",
        )
        .category("web", "http_probe")
        .binary("httpx")
        .stage(3)
        .priority(15)
        .version("1.x")
        .author("ProjectDiscovery")
        .risk(RiskLevel.LOW)
        .passive(False)
        .permissions(requires_network=True)
        .capabilities(
            CapabilitySet()
            .add(CAPABILITIES.HTTP_PROBE,     "HTTP/HTTPS status, title, and header probing")
            .add(CAPABILITIES.TECH_DETECT,    "Web technology fingerprinting via response headers")
            .add(CAPABILITIES.TLS_SCAN,       "TLS certificate inspection and validation")
            .add(CAPABILITIES.WAF_DETECT,     "Web Application Firewall detection")
            .add(CAPABILITIES.SCREENSHOT,     "Headless screenshot capture (--screenshot)")
        )
        .inputs(InputType.DOMAIN, InputType.IP, InputType.URL)
        .outputs(OutputType.URLS, OutputType.HEADERS, OutputType.FINDINGS)
        .install(InstallMethod.GO, "go install github.com/projectdiscovery/httpx/cmd/httpx@latest")
        .tags("web", "http", "probe", "tls", "fingerprint", "projectdiscovery")
        .example("httpx -u https://example.com -title -tech-detect -status-code")
        .homepage("https://github.com/projectdiscovery/httpx")
        .timeout(60)
        .build()
    )

    def run(self, target: str, **kwargs) -> ToolRunResult:
        """Delegate to existing HTTPXTool unchanged."""
        skip = self.skip_if_unavailable()
        if skip:
            return skip
        fail = self.validate_or_fail(target)
        if fail:
            return fail

        try:
            from ...tools.httpx_tool import HTTPXTool
            return HTTPXTool().safe_run(target, **kwargs)
        except ImportError:
            return self.fail(
                reason="import_error",
                message="HTTPXTool not found — ensure tools/httpx_tool.py exists",
            )

    def parse_output(self, raw: str, **kwargs) -> dict:
        try:
            from ...tools.httpx_tool import HTTPXTool
            return HTTPXTool().parse_output(raw, **kwargs)
        except Exception:
            return {}
