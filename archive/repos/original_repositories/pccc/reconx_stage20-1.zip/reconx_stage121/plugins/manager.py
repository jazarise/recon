"""
ReconX — Plugin Manager (Stage 15, Part 1).

Central authority for all plugin lifecycle operations:
  • Auto-discovery from plugins/ directory and community/ packs
  • Install / remove / update plugins
  • Enable / disable at runtime
  • Version tracking and compatibility checks
  • Dependency validation (pip package presence)
  • Health reporting

Persists plugin state to cache/plugin_registry.json between sessions.
"""
from __future__ import annotations

import importlib
import importlib.util
import json
import logging
import shutil
import subprocess
import sys
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Optional

from .sdk import BaseReconPlugin, PluginManifest

log = logging.getLogger("reconx.plugins.manager")

_REGISTRY_FILE = Path("cache/plugin_registry.json")
_PLUGIN_DIR    = Path("plugins/community")
_PACK_DIR      = Path("plugins/packs")

RECONX_VERSION = "15.0"


# ─────────────────────────────────────────────────────────────────────────────
# Plugin record
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class PluginRecord:
    """Persisted record for one installed plugin."""
    name:         str
    version:      str
    plugin_type:  str
    author:       str        = ""
    description:  str        = ""
    tags:         list[str]  = field(default_factory=list)
    dependencies: list[str]  = field(default_factory=list)
    min_reconx:   str        = "14.0"
    homepage:     str        = ""
    module_path:  str        = ""        # importable module string
    file_path:    str        = ""        # absolute path to .py file
    enabled:      bool       = True
    installed_at: float      = field(default_factory=time.time)
    updated_at:   float      = field(default_factory=time.time)
    load_error:   str        = ""
    run_count:    int        = 0
    error_count:  int        = 0

    @property
    def status(self) -> str:
        if not self.enabled:         return "DISABLED"
        if self.load_error:          return "ERROR"
        return "ACTIVE"

    @property
    def is_compatible(self) -> bool:
        """Check min_reconx version against current RECONX_VERSION."""
        try:
            min_parts = [int(x) for x in self.min_reconx.split(".")]
            cur_parts = [int(x) for x in RECONX_VERSION.split(".")]
            return cur_parts >= min_parts
        except ValueError:
            return True

    def to_dict(self) -> dict:
        return asdict(self)


# ─────────────────────────────────────────────────────────────────────────────
# PluginManager
# ─────────────────────────────────────────────────────────────────────────────

class PluginManager:
    """
    Manages the full plugin lifecycle.

    Usage:
        pm = PluginManager.load()
        pm.discover()                        # scan directories
        pm.enable("my-tool")
        pm.disable("my-tool")
        pm.install_from_file("path/to/my_plugin.py")
        pm.remove("my-tool")
        pm.save()
        print(pm.health_report())
    """

    def __init__(self, records: Optional[dict[str, PluginRecord]] = None):
        self._records:   dict[str, PluginRecord]   = records or {}
        self._instances: dict[str, BaseReconPlugin] = {}

    # ── persistence ───────────────────────────────────────────────────────────

    @classmethod
    def load(cls, path: Path = _REGISTRY_FILE) -> "PluginManager":
        if path.exists():
            try:
                raw   = json.loads(path.read_text())
                recs  = {k: PluginRecord(**v) for k, v in raw.items()}
                pm    = cls(recs)
                log.info(f"Plugin registry loaded: {len(recs)} plugin(s).")
                return pm
            except Exception as e:
                log.warning(f"Plugin registry corrupt — starting fresh: {e}")
        return cls()

    def save(self, path: Path = _REGISTRY_FILE) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        try:
            path.write_text(
                json.dumps({k: v.to_dict() for k, v in self._records.items()}, indent=2)
            )
        except Exception as e:
            log.warning(f"Cannot save plugin registry: {e}")

    # ── discovery ─────────────────────────────────────────────────────────────

    def discover(
        self,
        directories: Optional[list[Path]] = None,
        auto_enable: bool = True,
    ) -> list[PluginRecord]:
        """
        Scan plugin directories and register any new plugins found.
        Returns list of newly discovered PluginRecords.
        """
        dirs = directories or [_PLUGIN_DIR, _PACK_DIR]
        discovered: list[PluginRecord] = []

        for d in dirs:
            if not d.is_dir():
                continue
            for py_file in d.rglob("*.py"):
                if py_file.name.startswith("_"):
                    continue
                rec = self._load_plugin_file(py_file, auto_enable)
                if rec and rec.name not in self._records:
                    self._records[rec.name] = rec
                    discovered.append(rec)
                    log.info(f"Discovered plugin: {rec.name} v{rec.version}")

        self.save()
        return discovered

    # ── install ───────────────────────────────────────────────────────────────

    def install_from_file(
        self,
        source_path: str,
        target_dir:  Optional[Path] = None,
        enable:      bool           = True,
    ) -> Optional[PluginRecord]:
        """
        Copy a .py plugin file into the community directory and register it.

        Args:
            source_path: Path to plugin .py file.
            target_dir:  Destination directory (default: plugins/community/).
            enable:      Enable plugin immediately after install.

        Returns:
            PluginRecord on success, None on failure.
        """
        src  = Path(source_path)
        if not src.exists() or src.suffix != ".py":
            log.error(f"Invalid plugin file: {source_path}")
            return None

        dest_dir = target_dir or _PLUGIN_DIR
        dest_dir.mkdir(parents=True, exist_ok=True)
        dest = dest_dir / src.name

        try:
            shutil.copy2(str(src), str(dest))
        except Exception as e:
            log.error(f"Cannot copy plugin file: {e}")
            return None

        rec = self._load_plugin_file(dest, enable)
        if rec:
            self._records[rec.name] = rec
            self.save()
            log.info(f"Installed plugin: {rec.name} v{rec.version}")
        return rec

    def install_pack(self, pack_name: str) -> list[PluginRecord]:
        """Install all plugins from a named pack directory."""
        pack_dir = _PACK_DIR / pack_name
        if not pack_dir.is_dir():
            log.warning(f"Pack not found: {pack_name}")
            return []
        return self.discover(directories=[pack_dir])

    def install_pip_deps(self, plugin_name: str) -> bool:
        """Install pip dependencies for a plugin."""
        rec = self._records.get(plugin_name)
        if not rec or not rec.dependencies:
            return True
        for dep in rec.dependencies:
            try:
                importlib.import_module(dep.replace("-", "_").split("[")[0])
                log.debug(f"Dep {dep!r} already installed.")
            except ImportError:
                log.info(f"Installing pip dep: {dep}")
                result = subprocess.run(
                    [sys.executable, "-m", "pip", "install", dep,
                     "--break-system-packages"],
                    capture_output=True, text=True
                )
                if result.returncode != 0:
                    log.error(f"Failed to install {dep}: {result.stderr[:200]}")
                    return False
        return True

    # ── lifecycle operations ──────────────────────────────────────────────────

    def enable(self, name: str) -> bool:
        if rec := self._records.get(name):
            rec.enabled    = True
            rec.updated_at = time.time()
            self.save()
            return True
        return False

    def disable(self, name: str) -> bool:
        if rec := self._records.get(name):
            rec.enabled    = False
            rec.updated_at = time.time()
            # Call on_unload if instance exists
            if inst := self._instances.get(name):
                try:
                    inst.on_unload()
                except Exception:
                    pass
                del self._instances[name]
            self.save()
            return True
        return False

    def remove(self, name: str) -> bool:
        rec = self._records.get(name)
        if not rec:
            return False
        # Remove file if in community dir
        if rec.file_path:
            fp = Path(rec.file_path)
            if fp.exists() and _PLUGIN_DIR in fp.parents:
                fp.unlink()
        self.disable(name)
        del self._records[name]
        self.save()
        log.info(f"Removed plugin: {name}")
        return True

    def update(self, name: str, new_file: str) -> Optional[PluginRecord]:
        """Replace a plugin with a newer version."""
        rec = self._records.get(name)
        if not rec:
            return None
        old_path = rec.file_path
        self.remove(name)
        new_rec = self.install_from_file(new_file)
        if new_rec:
            log.info(f"Updated plugin: {name} → v{new_rec.version}")
        return new_rec

    # ── loading ───────────────────────────────────────────────────────────────

    def load_all_enabled(self) -> dict[str, BaseReconPlugin]:
        """Instantiate all enabled plugins. Returns name → instance map."""
        for name, rec in self._records.items():
            if not rec.enabled:
                continue
            if name in self._instances:
                continue
            self._load_instance(rec)
        return dict(self._instances)

    def get_instance(self, name: str) -> Optional[BaseReconPlugin]:
        if name not in self._instances:
            if rec := self._records.get(name):
                self._load_instance(rec)
        return self._instances.get(name)

    def _load_instance(self, rec: PluginRecord) -> Optional[BaseReconPlugin]:
        if not rec.file_path:
            return None
        try:
            spec   = importlib.util.spec_from_file_location(rec.name, rec.file_path)
            mod    = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)

            # Find the BaseReconPlugin subclass
            for attr_name in dir(mod):
                cls = getattr(mod, attr_name)
                if (isinstance(cls, type)
                        and issubclass(cls, BaseReconPlugin)
                        and cls is not BaseReconPlugin
                        and not attr_name.startswith("Base")):
                    inst = cls()
                    inst.on_load()
                    self._instances[rec.name] = inst
                    rec.load_error = ""
                    return inst
        except Exception as e:
            rec.load_error = str(e)[:200]
            log.error(f"Failed to load plugin {rec.name!r}: {e}")
        return None

    def _load_plugin_file(self, path: Path, enable: bool) -> Optional[PluginRecord]:
        """Load plugin metadata from a .py file without fully instantiating."""
        try:
            spec = importlib.util.spec_from_file_location(path.stem, str(path))
            mod  = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)

            for attr_name in dir(mod):
                cls = getattr(mod, attr_name)
                if (isinstance(cls, type)
                        and issubclass(cls, BaseReconPlugin)
                        and cls is not BaseReconPlugin
                        and not attr_name.startswith("Base")):
                    manifest = getattr(cls, "MANIFEST", None)
                    if not manifest:
                        continue
                    errors = manifest.validate()
                    if errors:
                        log.warning(f"Plugin {path} invalid: {errors}")
                        continue
                    return PluginRecord(
                        name        = manifest.name,
                        version     = manifest.version,
                        plugin_type = manifest.plugin_type,
                        author      = manifest.author,
                        description = manifest.description,
                        tags        = list(manifest.tags),
                        dependencies= list(manifest.dependencies),
                        min_reconx  = manifest.min_reconx,
                        homepage    = manifest.homepage,
                        module_path = path.stem,
                        file_path   = str(path.resolve()),
                        enabled     = enable,
                    )
        except Exception as e:
            log.debug(f"Cannot scan {path}: {e}")
        return None

    # ── accessors ─────────────────────────────────────────────────────────────

    def all_records(self)    -> list[PluginRecord]:
        return list(self._records.values())

    def active_records(self) -> list[PluginRecord]:
        return [r for r in self._records.values() if r.enabled]

    def by_type(self, plugin_type: str) -> list[PluginRecord]:
        return [r for r in self._records.values() if r.plugin_type == plugin_type]

    def get_record(self, name: str) -> Optional[PluginRecord]:
        return self._records.get(name)

    def search(self, query: str) -> list[PluginRecord]:
        q = query.lower()
        return [r for r in self._records.values()
                if q in r.name.lower() or q in r.description.lower()
                or any(q in t for t in r.tags)]

    def record_run(self, name: str, failed: bool = False) -> None:
        if rec := self._records.get(name):
            rec.run_count += 1
            if failed:
                rec.error_count += 1

    # ── health ────────────────────────────────────────────────────────────────

    def health_report(self) -> str:
        records = list(self._records.values())
        if not records:
            return "No plugins installed."

        w_name = max((len(r.name) for r in records), default=20)
        lines  = [
            "╔══ Plugin Health ══════════════════════════════╗",
            f"  {'Plugin':<{w_name}}  {'Status':<10}  {'Type':<12}  "
            f"{'Runs':>5}  {'Errors':>6}  {'Version'}",
            "  " + "─" * (w_name + 48),
        ]
        for rec in sorted(records, key=lambda r: r.name):
            lines.append(
                f"  {rec.name:<{w_name}}  {rec.status:<10}  "
                f"{rec.plugin_type:<12}  {rec.run_count:>5}  "
                f"{rec.error_count:>6}  {rec.version}"
            )
        active  = sum(1 for r in records if r.status == "ACTIVE")
        total   = len(records)
        lines += [
            "",
            f"  Total: {total}  Active: {active}  "
            f"Disabled: {total - active}",
            "╚═══════════════════════════════════════════════╝",
        ]
        return "\n".join(lines)
