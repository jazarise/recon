"""
ReconX — Plugin Ecosystem (Stage 15).

Exports the core plugin infrastructure:
  PluginManager   — lifecycle (install/remove/enable/disable)
  PluginLoader    — dynamic discovery and integration
  PluginSandbox   — execution isolation and resource limits
  Marketplace     — community pack browser and installer
  SDK classes     — BaseReconPlugin and all specialised bases
  Schema tools    — manifest and workflow pack validation
"""
from .sdk         import (
    BaseReconPlugin, BaseToolPlugin, BaseWorkflowPlugin,
    BaseAnalyzerPlugin, BaseExporterPlugin, BaseLearningPlugin, BaseAgentPlugin,
    PluginManifest, reconx_plugin, plugin_hook,
)
from .manager     import PluginManager, PluginRecord
from .loader      import PluginLoader, LoadResult
from .sandbox     import PluginSandbox, SandboxConfig, SandboxPolicy, SandboxResult
from .marketplace import Marketplace, MarketplacePack, BUILTIN_CATALOG
from .schemas     import (
    validate_manifest, validate_workflow_pack, validate_tool_plugin,
    load_and_validate_workflow_pack, BUILTIN_WORKFLOW_PACKS,
    ValidationResult, save_builtin_workflow_packs,
)

__all__ = [
    # SDK
    "BaseReconPlugin", "BaseToolPlugin", "BaseWorkflowPlugin",
    "BaseAnalyzerPlugin", "BaseExporterPlugin", "BaseLearningPlugin",
    "BaseAgentPlugin", "PluginManifest", "reconx_plugin", "plugin_hook",
    # Manager
    "PluginManager", "PluginRecord",
    # Loader
    "PluginLoader", "LoadResult",
    # Sandbox
    "PluginSandbox", "SandboxConfig", "SandboxPolicy", "SandboxResult",
    # Marketplace
    "Marketplace", "MarketplacePack", "BUILTIN_CATALOG",
    # Schemas
    "validate_manifest", "validate_workflow_pack", "validate_tool_plugin",
    "load_and_validate_workflow_pack", "BUILTIN_WORKFLOW_PACKS",
    "ValidationResult", "save_builtin_workflow_packs",
]
