"""
ReconX — Stage 19 Plugin: Nmap

Drop-in plugin that wraps the existing NmapTool (tools/scanning/nmap_tool.py)
with full Stage 19 PluginBaseTool interface.

No behaviour is changed — the underlying NmapTool.run() is called unchanged.
This file teaches the plugin system what Nmap can do (capabilities/permissions)
and enables `reconx tools info nmap` and capability-based routing.
"""
from __future__ import annotations

from ...sdk import (
    PluginBaseTool, ToolMetadataBuilder, CAPABILITIES, COMMON_CAPS,
    RiskLevel, InstallMethod, InputType, OutputType, CapabilitySet,
)
from ...models.tool_result import ToolRunResult


class NmapPlugin(PluginBaseTool):
    """
    Network mapper and port scanner — industry-standard network discovery tool.

    Wraps: tools/scanning/nmap_tool.py — NmapTool
    """

    METADATA = (
        ToolMetadataBuilder("Nmap", "Network mapper — port scanning, OS detection, service version detection")
        .category("network", "port_scanning")
        .binary("nmap")
        .stage(3)
        .priority(30)
        .version("7.x")
        .author("Gordon Lyon (Fyodor)")
        .risk(RiskLevel.HIGH)
        .passive(False)
        .permissions(
            requires_root=True,       # OS detection / SYN scan needs root
            requires_network=True,
        )
        .capabilities(
            CapabilitySet()
            .add(CAPABILITIES.PORT_SCAN,          "TCP/UDP port discovery across all 65535 ports")
            .add(CAPABILITIES.UDP_SCAN,           "UDP port scanning (-sU)")
            .add(CAPABILITIES.OS_DETECTION,       "OS fingerprinting via TTL and TCP window size")
            .add(CAPABILITIES.SERVICE_DETECTION,  "Banner grabbing and service identification")
            .add(CAPABILITIES.VERSION_DETECTION,  "Service version detection (-sV)")
            .add(CAPABILITIES.HOST_DISCOVERY,     "Live host ping sweep (-sn)")
            .add(CAPABILITIES.TRACEROUTE,         "Network path tracing (--traceroute)")
            .add(CAPABILITIES.VULN_SCAN,          "NSE vulnerability scripts (-script vuln)")
        )
        .inputs(InputType.IP, InputType.DOMAIN, InputType.CIDR)
        .outputs(OutputType.PORTS, OutputType.SERVICES, OutputType.IPS)
        .install(InstallMethod.APT, "sudo apt install nmap")
        .tags("network", "scanning", "active", "ports", "os-detection", "nse")
        .example("nmap -sV -O --script default 192.168.1.0/24")
        .homepage("https://nmap.org")
        .timeout(300)
        .build()
    )

    def run(self, target: str, **kwargs) -> ToolRunResult:
        """Delegate to existing NmapTool unchanged."""
        skip = self.skip_if_unavailable()
        if skip:
            return skip
        fail = self.validate_or_fail(target)
        if fail:
            return fail

        try:
            from ...tools.scanning.nmap_tool import NmapTool
            return NmapTool().safe_run(target, **kwargs)
        except ImportError:
            # Fallback for environments where scanning module not present
            return self.fail(
                reason="import_error",
                message="NmapTool not found — ensure tools/scanning/nmap_tool.py exists",
            )

    def parse_output(self, raw: str, **kwargs) -> dict:
        """Delegated to NmapTool parser."""
        try:
            from ...tools.scanning.nmap_tool import NmapTool
            return NmapTool().parse_output(raw, **kwargs)
        except Exception:
            return {}
