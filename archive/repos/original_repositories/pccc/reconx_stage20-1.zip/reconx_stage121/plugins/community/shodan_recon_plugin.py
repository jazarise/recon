"""
ReconX Community Plugin Example: Shodan Recon Tool.

This file demonstrates the complete plugin SDK usage.
Drop it into plugins/community/ and ReconX will auto-discover it.

Features shown:
  • PluginManifest declaration
  • @reconx_plugin decorator alternative
  • All lifecycle hooks
  • BaseTool attributes
  • parse_output() schema
  • Pure-Python API fallback
  • Learning content contribution
"""
from __future__ import annotations

import json
import re
import ssl
import time
import urllib.request
from typing import Optional


# ── Import SDK (handles both package and standalone execution) ──────────────

try:
    from reconx.plugins.sdk import (
        BaseToolPlugin, BaseLearningPlugin, PluginManifest, reconx_plugin
    )
    from reconx.models.tool_result import ParsedFinding, ToolRunResult, RunStatus
except ModuleNotFoundError:
    try:
        from plugins.sdk import (
            BaseToolPlugin, BaseLearningPlugin, PluginManifest, reconx_plugin
        )
        from models.tool_result import ParsedFinding, ToolRunResult, RunStatus
    except ModuleNotFoundError:
        # Fallback stubs for when run standalone
        import sys, os
        sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        from plugins.sdk import (
            BaseToolPlugin, BaseLearningPlugin, PluginManifest, reconx_plugin
        )


# ─────────────────────────────────────────────────────────────────────────────
# Shodan Recon Plugin (Tool)
# ─────────────────────────────────────────────────────────────────────────────

class ShodanReconPlugin(BaseToolPlugin):
    """
    Queries the Shodan InternetDB API (no API key required) for
    open ports, CVEs, tags, and hostnames for an IP address.

    InternetDB is Shodan's free public endpoint for basic host info.
    Full Shodan API (paid) is used when RECONX_SHODAN_KEY is set.
    """

    MANIFEST = PluginManifest(
        name        = "shodan-recon",
        version     = "1.0.0",
        author      = "community@reconx.io",
        description = "Shodan InternetDB lookup — open ports, CVEs, tags (no API key required).",
        plugin_type = "tool",
        tags        = ["osint", "passive", "shodan", "ports", "cve"],
        dependencies= [],
        min_reconx  = "14.0",
        homepage    = "https://internetdb.shodan.io",
        license     = "MIT",
    )

    # BaseTool required attributes
    NAME         = "ShodanRecon"
    BINARY       = "shodan"          # optional CLI — falls back to API
    CATEGORY     = "osint"
    STAGE        = 1
    PRIORITY     = 30
    PASSIVE      = True
    TIMEOUT      = 30
    INSTALL_CMD  = "pip install shodan  # API key optional for InternetDB"
    DEPENDENCIES: list = []

    _INTERNETDB_URL = "https://internetdb.shodan.io/{ip}"

    # ── lifecycle hooks ───────────────────────────────────────────────────────

    def on_load(self) -> None:
        self.log.info("ShodanRecon plugin loaded — using InternetDB (no key required).")

    def on_execute(self, target: str, kwargs: dict) -> None:
        self.log.debug(f"ShodanRecon executing against: {target}")

    def on_finish(self, target: str, result) -> None:
        findings_count = len(getattr(result, "findings", []))
        self.log.info(f"ShodanRecon finished: {target} — {findings_count} findings")

    def on_error(self, target: str, error: Exception) -> None:
        self.log.error(f"ShodanRecon error on {target}: {error}")

    def on_report(self, report_context: dict) -> Optional[dict]:
        return {
            "section": "Shodan Intelligence",
            "data":    report_context.get("shodan_data", {}),
        }

    # ── main run method ───────────────────────────────────────────────────────

    def run(self, target: str, **kwargs) -> "ToolRunResult":
        """Query InternetDB for an IP address."""
        # Validate: InternetDB only works on IPs
        import ipaddress
        try:
            ip = str(ipaddress.ip_address(target))
        except ValueError:
            # Try resolving domain to IP
            import socket
            try:
                ip = socket.gethostbyname(target)
            except Exception:
                return self._make_error_result("InternetDB requires an IP address.")

        t0 = time.perf_counter()
        data, err = self._query_internetdb(ip)
        dur = time.perf_counter() - t0

        if err and not data:
            return self._make_error_result(err, duration_s=dur)

        parsed   = self.parse_output(json.dumps(data))
        findings = self._build_findings(parsed, ip)
        return self._make_result(parsed, findings, duration_s=dur)

    # ── parse_output ──────────────────────────────────────────────────────────

    def parse_output(self, raw: str, **kwargs) -> dict:
        """
        InternetDB response schema:
        {
          "ip": "1.2.3.4",
          "ports": [80, 443, 22],
          "cpes": ["cpe:/a:apache:http_server"],
          "hostnames": ["host.example.com"],
          "tags": ["cloud", "vpn"],
          "vulns": ["CVE-2023-1234"]
        }
        """
        if not raw.strip():
            return self._empty()
        try:
            obj = json.loads(raw)
            return {
                "ip":        obj.get("ip", ""),
                "ports":     sorted(obj.get("ports", [])),
                "cpes":      obj.get("cpes", []),
                "hostnames": obj.get("hostnames", []),
                "tags":      obj.get("tags", []),
                "vulns":     obj.get("vulns", []),
                "count":     len(obj.get("ports", [])),
            }
        except (json.JSONDecodeError, ValueError):
            return self._empty()

    # ── internal ──────────────────────────────────────────────────────────────

    def _query_internetdb(self, ip: str) -> tuple[dict, str]:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode    = ssl.CERT_NONE
        opener = urllib.request.build_opener(urllib.request.HTTPSHandler(context=ctx))
        url = self._INTERNETDB_URL.format(ip=ip)
        try:
            req = urllib.request.Request(
                url,
                headers={"User-Agent": "ReconX-Plugin/1.0 (shodan-recon)"}
            )
            with opener.open(req, timeout=10) as resp:
                if resp.status == 404:
                    return {"ip": ip, "ports": [], "cpes": [],
                            "hostnames": [], "tags": [], "vulns": []}, ""
                body = json.loads(resp.read().decode("utf-8", errors="replace"))
            return body, ""
        except Exception as e:
            return {}, str(e)

    @staticmethod
    def _empty() -> dict:
        return {"ip": "", "ports": [], "cpes": [], "hostnames": [],
                "tags": [], "vulns": [], "count": 0}

    def _build_findings(self, data: dict, ip: str) -> list:
        findings = []
        # Open ports as findings
        for port in data.get("ports", []):
            try:
                from reconx.models.tool_result import ParsedFinding
            except ModuleNotFoundError:
                class ParsedFinding:
                    def __init__(self, **kw): self.__dict__.update(kw)
            findings.append(ParsedFinding(
                finding_type="open_port", value=str(port),
                source=self.NAME, confidence=0.95,
                metadata={"ip": ip, "source": "shodan_internetdb"},
            ))
        # CVEs as vulnerability findings
        for cve in data.get("vulns", []):
            try:
                from reconx.models.tool_result import ParsedFinding
            except ModuleNotFoundError:
                class ParsedFinding:
                    def __init__(self, **kw): self.__dict__.update(kw)
            findings.append(ParsedFinding(
                finding_type="vulnerability", value=cve,
                source=self.NAME, confidence=0.85,
                metadata={"ip": ip, "severity": "MEDIUM", "source": "shodan"},
            ))
        # Hostnames as subdomains
        for hostname in data.get("hostnames", []):
            try:
                from reconx.models.tool_result import ParsedFinding
            except ModuleNotFoundError:
                class ParsedFinding:
                    def __init__(self, **kw): self.__dict__.update(kw)
            findings.append(ParsedFinding(
                finding_type="subdomain", value=hostname,
                source=self.NAME, confidence=0.9,
                metadata={"ip": ip, "source": "shodan"},
            ))
        return findings

    def _make_error_result(self, msg: str, duration_s: float = 0.0):
        try:
            from reconx.models.tool_result import ToolRunResult
            return ToolRunResult.skipped(self.NAME, msg)
        except Exception:
            from types import SimpleNamespace
            return SimpleNamespace(status="failed", findings=[], error=msg,
                                   duration_s=duration_s)

    def _make_result(self, data: dict, findings: list, duration_s: float = 0.0):
        try:
            from reconx.models.tool_result import ToolRunResult, RunStatus
            r = ToolRunResult(tool_name=self.NAME, status=RunStatus.SUCCESS,
                              data=data, findings=findings, duration_s=duration_s)
            return r
        except Exception:
            from types import SimpleNamespace
            return SimpleNamespace(status="success", findings=findings,
                                   data=data, duration_s=duration_s)

    def safe_run(self, target: str, **kwargs):
        try:
            return self.run(target, **kwargs)
        except Exception as e:
            self.on_error(target, e)
            return self._make_error_result(str(e))

    def is_available(self) -> bool:
        """InternetDB always available (no binary required); Shodan CLI optional."""
        import shutil
        return True   # API fallback always works


# ─────────────────────────────────────────────────────────────────────────────
# Companion learning plugin
# ─────────────────────────────────────────────────────────────────────────────

class ShodanLearningPlugin(BaseLearningPlugin):
    """Adds Shodan educational content to ReconX Learning Mode."""

    MANIFEST = PluginManifest(
        name        = "shodan-learning",
        version     = "1.0.0",
        author      = "community@reconx.io",
        description = "Learning content for Shodan and InternetDB.",
        plugin_type = "learning",
        tags        = ["osint", "shodan", "internetdb"],
        min_reconx  = "14.0",
    )

    def on_load(self) -> None:
        self.log.info("Shodan learning module loaded.")

    def get_lessons(self) -> list[dict]:
        return [{
            "name":           "Shodan / InternetDB",
            "tagline":        "Passive open-port and CVE lookup without scanning",
            "problem_solved": (
                "You need to know what ports and vulnerabilities are exposed on an IP "
                "without sending any probes yourself."
            ),
            "how_it_works": (
                "Shodan's InternetDB is a free public API that returns pre-scanned "
                "data for any IP. Shodan continuously scans the internet and indexes "
                "open ports, CPE banners, CVEs, hostnames, and tags. You query their "
                "database — no packets to the target."
            ),
            "use_cases": [
                "Passive open-port lookup before active port scanning",
                "CVE exposure check for discovered IPs",
                "Hostname/subdomain discovery from IP space",
                "Corroborate or extend Nmap results passively",
            ],
            "examples": [
                "curl https://internetdb.shodan.io/1.1.1.1",
                "shodan host 1.1.1.1  # requires free API key",
                "# ReconX ShodanRecon plugin uses InternetDB automatically",
            ],
            "install":  "pip install shodan  # Shodan CLI (API key optional for InternetDB)",
            "tags":     ["osint", "passive", "shodan", "ports", "cve"],
        }]

    def get_relationships(self) -> list[dict]:
        return [
            {
                "from_tool": "ShodanRecon",
                "to_tool":   "NmapTool",
                "reason":    "Shodan gives passive pre-scan data; Nmap verifies live state",
                "benefit":   "Prioritise which ports to actively probe based on Shodan index",
            },
            {
                "from_tool": "AsnmapTool",
                "to_tool":   "ShodanRecon",
                "reason":    "ASNMap discovers the IP ranges; Shodan provides per-IP intel",
                "benefit":   "Passive recon across entire org IP space without scanning",
            },
        ]
