"""
ReconX — Stage 19 Plugin: Amass

Wraps the existing AmassTool (tools/amass.py) with full Stage 19 interface.
Amass is the most comprehensive passive subdomain enumeration tool available,
using 50+ data sources including DNS, certificates, and ASN intelligence.
"""
from __future__ import annotations

from ...sdk import (
    PluginBaseTool, ToolMetadataBuilder, CAPABILITIES, CapabilitySet,
    RiskLevel, InstallMethod, InputType, OutputType,
)
from ...models.tool_result import ToolRunResult


class AmassPlugin(PluginBaseTool):
    """
    Amass — comprehensive subdomain enumeration and network mapping.

    Wraps: tools/amass.py — AmassTool
    """

    METADATA = (
        ToolMetadataBuilder(
            "Amass",
            "Comprehensive subdomain enumeration using 50+ passive data sources",
        )
        .category("subdomain", "passive_enum")
        .binary("amass")
        .stage(2)
        .priority(10)
        .version("4.x")
        .author("OWASP")
        .risk(RiskLevel.PASSIVE)
        .passive(True)
        .permissions(requires_network=True)
        .capabilities(
            CapabilitySet()
            .add(CAPABILITIES.SUBDOMAIN_ENUM, "Passive subdomain enumeration via 50+ sources")
            .add(CAPABILITIES.DNS_RESOLVE,    "DNS resolution and A/AAAA record collection")
            .add(CAPABILITIES.ASN_INTEL,      "ASN and netblock intelligence via WHOIS/BGP")
            .add(CAPABILITIES.REVERSE_DNS,    "Reverse DNS lookups on discovered IPs")
            .add(CAPABILITIES.CERT_ENUM,      "Certificate transparency log mining")
        )
        .inputs(InputType.DOMAIN)
        .outputs(OutputType.SUBDOMAINS, OutputType.IPS, OutputType.DOMAINS)
        .install(InstallMethod.GO, "go install github.com/owasp-amass/amass/v4/...@master")
        .tags("subdomain", "passive", "osint", "dns", "asn", "certlogs")
        .example("amass enum -passive -d example.com")
        .homepage("https://github.com/owasp-amass/amass")
        .timeout(300)
        .build()
    )

    def run(self, target: str, **kwargs) -> ToolRunResult:
        """Delegate to existing AmassTool unchanged."""
        skip = self.skip_if_unavailable()
        if skip:
            return skip
        fail = self.validate_or_fail(target)
        if fail:
            return fail

        try:
            from ...tools.amass import AmassTool
            inner   = AmassTool()
            raw_out = inner.run(target, **kwargs)
            # AmassTool.run() returns a dict — wrap it as a ToolRunResult
            from ...models.tool_result import ParsedFinding
            subdomains = raw_out.get("subdomains", [])
            findings = [
                ParsedFinding(finding_type="subdomain", value=s, source="Amass")
                for s in subdomains
            ]
            return self.build_result(data=raw_out, findings=findings)
        except ImportError:
            return self.fail(
                reason="import_error",
                message="AmassTool not found — ensure tools/amass.py exists",
            )
        except Exception as exc:
            return self.fail(reason="run_error", message=str(exc))

    def parse_output(self, raw: str, **kwargs) -> dict:
        subdomains = [
            line.strip().lower() for line in raw.splitlines()
            if line.strip() and "." in line and " " not in line.strip()
        ]
        return {"subdomains": list(set(subdomains))}
