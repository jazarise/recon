"""
ReconX — Plugin Dynamic Loader (Stage 15, Part 2).

Scans plugin directories and registers discovered components
into the live ReconX systems:
  • Tools       → Tool Registry
  • Workflows   → Workflow engine (BUILTIN_CHAINS)
  • Analyzers   → Analysis pipeline
  • Exporters   → Output engine
  • Learning    → LearningMode catalog

Core safety rule: any plugin failure is caught and logged.
A broken plugin NEVER crashes ReconX.
"""
from __future__ import annotations

import importlib.util
import logging
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

from .sdk import (
    BaseReconPlugin, BaseToolPlugin, BaseWorkflowPlugin,
    BaseAnalyzerPlugin, BaseExporterPlugin, BaseLearningPlugin, BaseAgentPlugin,
)

log = logging.getLogger("reconx.plugins.loader")

# Load targets — directory list scanned by default
DEFAULT_PLUGIN_DIRS = [
    Path("plugins/community"),
    Path("plugins/packs"),
    Path("community"),
]


# ─────────────────────────────────────────────────────────────────────────────
# Loader result
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class LoadResult:
    loaded:   list[str] = field(default_factory=list)   # successfully loaded
    failed:   list[str] = field(default_factory=list)   # load errors
    skipped:  list[str] = field(default_factory=list)   # not a plugin / disabled
    errors:   dict[str, str] = field(default_factory=dict)  # name → error msg

    @property
    def success_count(self) -> int: return len(self.loaded)
    @property
    def fail_count(self)    -> int: return len(self.failed)

    def summary(self) -> str:
        return (f"Loaded: {self.success_count}  "
                f"Failed: {self.fail_count}  "
                f"Skipped: {len(self.skipped)}")


# ─────────────────────────────────────────────────────────────────────────────
# PluginLoader
# ─────────────────────────────────────────────────────────────────────────────

class PluginLoader:
    """
    Dynamically loads plugins and integrates them into live ReconX systems.

    Usage:
        loader = PluginLoader(registry=registry)
        result = loader.load_all()
        print(result.summary())

        # Load a single file
        loader.load_file(Path("plugins/community/my_tool.py"))
    """

    def __init__(
        self,
        registry  = None,       # ToolRegistry instance
        manager   = None,       # PluginManager instance
        chains    = None,       # BUILTIN_CHAINS dict (mutable)
        analyzers: Optional[list] = None,
        exporters: Optional[list] = None,
        learning_catalog: Optional[list] = None,
    ):
        self.registry         = registry
        self.manager          = manager
        self.chains           = chains or {}
        self.analyzers:  list = analyzers or []
        self.exporters:  list = exporters or []
        self.learning_catalog: list = learning_catalog or []

        self._loaded_modules: dict[str, Any] = {}   # path → module

    # ── public API ────────────────────────────────────────────────────────────

    def load_all(
        self,
        directories: Optional[list[Path]] = None,
    ) -> LoadResult:
        """
        Scan all plugin directories and load every valid plugin.
        Errors in individual plugins are caught and recorded.
        """
        dirs   = directories or DEFAULT_PLUGIN_DIRS
        result = LoadResult()

        for d in dirs:
            if not d.is_dir():
                continue
            for py_file in sorted(d.rglob("*.py")):
                if py_file.name.startswith("_"):
                    continue
                self._load_file_safe(py_file, result)

        log.info(f"Plugin load complete: {result.summary()}")
        return result

    def load_file(self, path: Path) -> Optional[BaseReconPlugin]:
        """
        Load a single plugin file and integrate it immediately.
        Returns the plugin instance or None on failure.
        """
        result = LoadResult()
        return self._load_file_safe(path, result)

    # ── core loader ───────────────────────────────────────────────────────────

    def _load_file_safe(
        self, path: Path, result: LoadResult
    ) -> Optional[BaseReconPlugin]:
        """Load one .py file; catch all exceptions; update result."""
        key = str(path)
        try:
            instances = self._import_and_extract(path)
            if not instances:
                result.skipped.append(key)
                return None

            last_inst = None
            for inst in instances:
                self._integrate(inst, path)
                result.loaded.append(inst.name)
                last_inst = inst

            return last_inst

        except Exception as exc:
            err = f"{type(exc).__name__}: {exc}"
            log.error(f"[PLUGIN LOAD FAILED] {path.name}: {err}")
            result.failed.append(key)
            result.errors[key] = err
            return None

    def _import_and_extract(self, path: Path) -> list[BaseReconPlugin]:
        """Import module and return all BaseReconPlugin instances found."""
        if str(path) in self._loaded_modules:
            mod = self._loaded_modules[str(path)]
        else:
            spec = importlib.util.spec_from_file_location(path.stem, str(path))
            if not spec or not spec.loader:
                return []
            mod = importlib.util.module_from_spec(spec)
            # Add parent to sys.path temporarily so relative imports resolve
            parent = str(path.parent)
            added = parent not in sys.path
            if added:
                sys.path.insert(0, parent)
            try:
                spec.loader.exec_module(mod)
            finally:
                if added and parent in sys.path:
                    sys.path.remove(parent)
            self._loaded_modules[str(path)] = mod

        instances: list[BaseReconPlugin] = []
        for attr_name in dir(mod):
            cls = getattr(mod, attr_name)
            if not (isinstance(cls, type)
                    and issubclass(cls, BaseReconPlugin)
                    and cls is not BaseReconPlugin
                    and not attr_name.startswith("Base")):
                continue
            manifest = getattr(cls, "MANIFEST", None)
            if not manifest or not manifest.name or manifest.name in ("unnamed", "unnamed-tool"):
                continue
            if manifest.validate():
                log.warning(f"Plugin {cls.__name__} has invalid manifest: {manifest.validate()}")
                continue
            try:
                inst = cls()
                inst.on_load()
                instances.append(inst)
            except Exception as e:
                log.error(f"Cannot instantiate {cls.__name__}: {e}")

        return instances

    def _integrate(self, inst: BaseReconPlugin, path: Path) -> None:
        """Route plugin instance to the correct ReconX subsystem."""
        ptype = inst.MANIFEST.plugin_type

        if ptype == "tool":
            self._register_tool(inst, path)
        elif ptype == "workflow":
            self._register_workflow(inst)
        elif ptype == "analyzer":
            self._register_analyzer(inst)
        elif ptype == "exporter":
            self._register_exporter(inst)
        elif ptype == "learning":
            self._register_learning(inst)
        elif ptype == "agent":
            self._register_agent(inst)
        else:
            log.debug(f"Unknown plugin type {ptype!r} for {inst.name} — skipped integration.")

        # Notify plugin manager if available
        if self.manager:
            try:
                if inst.name not in {r.name for r in self.manager.all_records()}:
                    pass   # manager.discover() handles record creation
                self.manager._instances[inst.name] = inst
            except Exception:
                pass

        log.info(f"[PLUGIN] Loaded {ptype}: {inst.name} v{inst.version}")

    # ── per-type registration ─────────────────────────────────────────────────

    def _register_tool(self, inst: BaseReconPlugin, path: Path) -> None:
        """Register a tool plugin with the ToolRegistry."""
        if not self.registry:
            return
        try:
            from reconx.orchestration.tool_registry import ToolMeta
        except ModuleNotFoundError:
            try:
                from orchestration.tool_registry import ToolMeta
            except Exception:
                return

        cat  = getattr(inst, "CATEGORY",  "plugin")
        meta = ToolMeta(
            class_name       = type(inst).__name__,
            name             = getattr(inst, "NAME",    inst.name),
            binary           = getattr(inst, "BINARY",  inst.name.lower()),
            category         = cat,
            stage            = getattr(inst, "STAGE",   2),
            passive          = getattr(inst, "PASSIVE", False),
            priority         = getattr(inst, "PRIORITY",50),
            timeout          = getattr(inst, "TIMEOUT", 60),
            install_cmd      = getattr(inst, "INSTALL_CMD", ""),
            dependencies     = list(getattr(inst, "DEPENDENCIES", [])),
            tags             = list(inst.MANIFEST.tags),
            supported_inputs = ["domain", "ip", "url"],
            description      = inst.MANIFEST.description,
            module_path      = str(path),
            instance         = inst,
        )
        self.registry.register(meta)

    def _register_workflow(self, inst: BaseReconPlugin) -> None:
        """Add workflow plugin steps to BUILTIN_CHAINS."""
        if not hasattr(inst, "get_steps"):
            return
        try:
            from reconx.orchestration.tool_chains import ChainStep
        except ModuleNotFoundError:
            try:
                from orchestration.tool_chains import ChainStep
            except Exception:
                return

        steps = [ChainStep(tc, description=f"Plugin: {inst.name}")
                 for tc in inst.get_steps()]
        if steps:
            chain_key = inst.name.lower().replace(" ", "_").replace("-", "_")
            self.chains[chain_key] = steps
            log.debug(f"Registered workflow chain: {chain_key} ({len(steps)} steps)")

    def _register_analyzer(self, inst: BaseReconPlugin) -> None:
        if inst not in self.analyzers:
            self.analyzers.append(inst)

    def _register_exporter(self, inst: BaseReconPlugin) -> None:
        if inst not in self.exporters:
            self.exporters.append(inst)

    def _register_learning(self, inst: BaseReconPlugin) -> None:
        if not hasattr(inst, "get_lessons"):
            return
        try:
            lessons = inst.get_lessons()
            for lesson in lessons:
                if lesson not in self.learning_catalog:
                    self.learning_catalog.append(lesson)
            log.debug(f"Registered {len(lessons)} lesson(s) from {inst.name}")
        except Exception as e:
            log.warning(f"Learning plugin {inst.name} get_lessons() failed: {e}")

    def _register_agent(self, inst: BaseReconPlugin) -> None:
        # Agents are stored in the plugin manager for future pipeline integration
        log.info(f"Agent plugin registered: {inst.name} (type={getattr(inst,'AGENT_TYPE','generic')})")

    # ── helpers ───────────────────────────────────────────────────────────────

    @property
    def loaded_tools(self) -> list:
        return self.analyzers   # all types available via registry

    def get_analyzers(self) -> list:
        return list(self.analyzers)

    def get_exporters(self) -> list:
        return list(self.exporters)

    def get_learning_catalog(self) -> list:
        return list(self.learning_catalog)
