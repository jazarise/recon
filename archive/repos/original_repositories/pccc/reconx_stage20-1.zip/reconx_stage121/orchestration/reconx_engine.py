"""
ReconX — Stage 13 Main Orchestrator.

Single entry point that ties together:
  target classification → workflow recommendation → pipeline execution
  → live TUI → report generation

Usage:
    from reconx.orchestration.reconx_engine import ReconXEngine
    engine = ReconXEngine()
    result = engine.run("example.com", mode="balanced")
"""
from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Optional

log = logging.getLogger("reconx.engine")


@dataclass
class ReconXRunResult:
    target:        str
    target_type:   str
    mode:          str
    workflow:      list[str]
    pipeline_result: Any              # PipelineResult
    report_path:   Optional[str] = None
    duration_s:    float         = 0.0
    started_at:    float         = 0.0

    @property
    def total_findings(self) -> int:
        return getattr(self.pipeline_result, "total_findings", 0)

    @property
    def success_count(self) -> int:
        return getattr(self.pipeline_result, "success_count", 0)

    @property
    def failed_count(self) -> int:
        return getattr(self.pipeline_result, "failed_count", 0)


class ReconXEngine:
    """
    Top-level orchestration engine.

    Wires together:
      1. ToolRegistry — auto-discover all tools
      2. TargetClassifier — classify user input
      3. RecommendationEngine — select tools for mode
      4. PipelineEngine — execute with parallelism + retries
      5. OperationsCenter — live TUI display
      6. ToolHealthMonitor — record telemetry
      7. ReportGenerator — produce HTML/JSON reports

    All components degrade gracefully if unavailable.
    """

    def __init__(
        self,
        base_package:  str          = "reconx",
        max_workers:   int          = 8,
        report_dir:    str          = "reports",
        on_task_start: Optional[Callable] = None,
        on_task_finish: Optional[Callable] = None,
    ):
        self.base_package   = base_package
        self.max_workers    = max_workers
        self.report_dir     = report_dir
        self.on_task_start  = on_task_start
        self.on_task_finish = on_task_finish

        # Lazy-loaded components
        self._registry   = None
        self._health     = None
        self._pipeline   = None

    # ── public API ────────────────────────────────────────────────────────────

    def run(
        self,
        raw_target:    str,
        mode:          str  = "balanced",
        *,
        live_tui:      bool = True,
        save_report:   bool = True,
        dry_run:       bool = False,
        custom_tools:  Optional[list[str]] = None,
    ) -> ReconXRunResult:
        """
        Full recon pipeline for a target.

        Args:
            raw_target:   Any supported target string (domain, IP, CIDR, email, …).
            mode:         'fast'|'balanced'|'deep'|'passive'|'custom'|'ai'.
            live_tui:     Show real-time Rich TUI.
            save_report:  Generate HTML/JSON reports after completion.
            dry_run:      Classify and plan workflow but do not execute.
            custom_tools: Tool class names for mode='custom'.
        """
        started = time.time()
        log.info(f"ReconX run started: target={raw_target!r} mode={mode}")

        # ── 1. Classify target ────────────────────────────────────────────────
        ct = self._classify(raw_target)
        log.info(f"Target type: {ct.target_type} ({ct.label})")

        # ── 2. Build registry ─────────────────────────────────────────────────
        registry = self._get_registry()

        # ── 3. Generate workflow ──────────────────────────────────────────────
        rec = self._recommend(ct, mode, registry, custom_tools)
        log.info(f"Workflow: {len(rec.tool_list)} tools, est ~{rec.estimated_min} min")

        if dry_run:
            log.info("Dry run — skipping execution.")
            from .pipeline_engine import PipelineResult
            dummy = PipelineResult(target=ct.normalized, tasks=[],
                                   started_at=started, finished_at=time.time())
            return ReconXRunResult(
                target=raw_target, target_type=ct.target_type, mode=mode,
                workflow=rec.tool_list, pipeline_result=dummy,
                duration_s=time.time() - started, started_at=started,
            )

        # ── 4. Execute pipeline ───────────────────────────────────────────────
        pipeline = self._get_pipeline(registry)
        tasks    = rec.to_pipeline_tasks(ct.normalized)

        if live_tui:
            pipeline_result = self._run_with_tui(
                tasks, ct.normalized, mode, pipeline
            )
        else:
            pipeline_result = pipeline.execute(tasks, ct.normalized)

        # ── 5. Record health telemetry ────────────────────────────────────────
        self._record_telemetry(pipeline_result)

        # ── 6. Save report ────────────────────────────────────────────────────
        report_path = None
        if save_report:
            report_path = self._save_report(
                ct.normalized, ct.target_type, mode, pipeline_result
            )

        duration = time.time() - started
        log.info(
            f"ReconX run complete: {pipeline_result.total_findings} findings "
            f"in {duration:.1f}s"
        )

        return ReconXRunResult(
            target        = raw_target,
            target_type   = ct.target_type,
            mode          = mode,
            workflow      = rec.tool_list,
            pipeline_result = pipeline_result,
            report_path   = report_path,
            duration_s    = duration,
            started_at    = started,
        )

    def health_check(self) -> str:
        """Run availability probe and return health dashboard text."""
        registry = self._get_registry()
        health   = self._get_health()
        health.probe_all(registry, force=True)
        health.save()
        return health.dashboard_text()

    def install_guide(self) -> str:
        """Return install commands for all missing tools."""
        registry = self._get_registry()
        health   = self._get_health()
        health.probe_all(registry)
        return health.install_guide()

    # ── internal ──────────────────────────────────────────────────────────────

    def _classify(self, raw: str):
        try:
            from reconx.analysis.target_classifier import TargetClassifier
        except ModuleNotFoundError:
            from analysis.target_classifier import TargetClassifier
        return TargetClassifier.classify(raw)

    def _get_registry(self):
        if not self._registry:
            try:
                from reconx.orchestration.tool_registry import ToolRegistry
            except ModuleNotFoundError:
                from orchestration.tool_registry import ToolRegistry
            self._registry = ToolRegistry.build(self.base_package)
        return self._registry

    def _get_health(self):
        if not self._health:
            try:
                from reconx.telemetry.tool_health import ToolHealthMonitor
            except ModuleNotFoundError:
                from telemetry.tool_health import ToolHealthMonitor
            self._health = ToolHealthMonitor.load()
        return self._health

    def _get_pipeline(self, registry):
        if not self._pipeline:
            try:
                from reconx.orchestration.pipeline_engine import PipelineEngine
            except ModuleNotFoundError:
                from orchestration.pipeline_engine import PipelineEngine
            self._pipeline = PipelineEngine(
                registry,
                max_workers    = self.max_workers,
                on_task_start  = self.on_task_start,
                on_task_finish = self.on_task_finish,
            )
        return self._pipeline

    def _recommend(self, ct, mode, registry, custom_tools):
        try:
            from reconx.workflow.recommendation_engine import RecommendationEngine
        except ModuleNotFoundError:
            from workflow.recommendation_engine import RecommendationEngine
        engine = RecommendationEngine(registry)
        return engine.recommend(ct, mode, custom_tools=custom_tools,
                                filter_unavailable=True)

    def _run_with_tui(self, tasks, target, mode, pipeline):
        try:
            from reconx.output.operations_center import OperationsCenter
        except ModuleNotFoundError:
            from output.operations_center import OperationsCenter

        ops = OperationsCenter(target, mode.upper(), total_tasks=len(tasks))

        def on_start(task):
            ops.register_task(task.tool_class)
            ops.set_status(task.tool_class, "RUNNING")

        def on_finish(task):
            ops.set_status(
                task.tool_class,
                task.status.value,
                duration_s=task.duration_s,
                findings=task.finding_count,
                error=task.error,
            )
            if task.result and hasattr(task.result, "findings"):
                ops.add_findings_bulk(task.result.findings)

        pipeline.on_task_start  = on_start
        pipeline.on_task_finish = on_finish

        with ops:
            result = pipeline.execute(tasks, target)

        ops.print_final_summary()
        return result

    def _record_telemetry(self, pipeline_result) -> None:
        health = self._get_health()
        for task in getattr(pipeline_result, "tasks", []):
            health.record_run(
                class_name = task.tool_class,
                duration_s = task.duration_s,
                failed     = task.status.value in ("failed", "cancelled"),
                error      = task.error,
            )
        health.save()

    def _save_report(self, target, ttype, mode, pipeline_result) -> Optional[str]:
        try:
            from datetime import datetime
            from reconx.output.report_121 import generate_stage121_report
        except ModuleNotFoundError:
            try:
                from output.report_121 import generate_stage121_report
            except Exception:
                return None

        Path(self.report_dir).mkdir(parents=True, exist_ok=True)
        ts   = datetime.now().strftime("%Y%m%d_%H%M%S")
        safe = target.replace(".", "_").replace("/", "_")
        path = f"{self.report_dir}/reconx_{safe}_{ts}.html"

        all_findings = getattr(pipeline_result, "all_findings", [])
        tasks        = getattr(pipeline_result, "tasks", [])
        step_results = {
            t.tool_class: {
                "status":     t.status.value,
                "duration_s": t.duration_s,
                "name":       t.tool_class,
            }
            for t in tasks
        }
        tool_errors = [
            {"tool": t.tool_class, "status": t.status.value, "error": t.error}
            for t in tasks
            if t.error
        ]

        try:
            generate_stage121_report(
                path         = path,
                target       = target,
                version      = "Stage-13",
                timestamp    = datetime.now().isoformat(),
                all_findings = [f.__dict__ if hasattr(f, "__dict__") else f
                                for f in all_findings],
                step_results = step_results,
                tool_errors  = tool_errors,
            )
            log.info(f"Report saved: {path}")
            return path
        except Exception as e:
            log.warning(f"Report generation failed: {e}")
            return None
