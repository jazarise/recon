"""
ReconX — Orchestration: Tool Chaining Engine (Stage 13).

Defines pre-built reconnaissance chains (ordered lists of tool class names)
and the runtime logic that passes structured findings from one tool's output
to the next tool's input parameters.

Chain execution model:
  1. Run tool[N] with target + accumulated context
  2. Extract findings from result
  3. Transform findings into kwargs for tool[N+1]
  4. Repeat until chain exhausted or halted

Built-in chains cover common reconnaissance workflows:
  ASSET_DISCOVERY, DNS_PIPELINE, WEB_RECON, API_RECON,
  SECRETS_PIPELINE, CLOUD_RECON, IDENTITY_RECON, FULL_RECON
"""
from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Optional

log = logging.getLogger("reconx.orchestration.chains")


# ─────────────────────────────────────────────────────────────────────────────
# Chain step definition
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class ChainStep:
    """One step in a tool chain."""
    tool_class:    str                    # registry class name, e.g. "NmapTool"
    description:   str  = ""
    required:      bool = False           # if True, failure halts the chain
    kwargs:        dict = field(default_factory=dict)   # extra static kwargs
    # Input transformer: receives accumulated context, returns kwargs for this step
    input_fn:      Optional[Callable[[dict], dict]] = field(default=None, repr=False)
    # Output transformer: receives ToolRunResult, updates context dict
    output_fn:     Optional[Callable[[Any, dict], None]] = field(default=None, repr=False)
    condition_fn:  Optional[Callable[[dict], bool]] = field(default=None, repr=False)

    def should_run(self, context: dict) -> bool:
        if self.condition_fn:
            return bool(self.condition_fn(context))
        return True

    def build_kwargs(self, context: dict) -> dict:
        kwargs = dict(self.kwargs)
        if self.input_fn:
            kwargs.update(self.input_fn(context))
        return kwargs

    def apply_output(self, result: Any, context: dict) -> None:
        if self.output_fn:
            self.output_fn(result, context)
        else:
            _default_output_fn(result, context)


# ─────────────────────────────────────────────────────────────────────────────
# Default output aggregator
# ─────────────────────────────────────────────────────────────────────────────

def _default_output_fn(result: Any, ctx: dict) -> None:
    """Merge ParsedFindings from result into context buckets."""
    if not result or not hasattr(result, "findings"):
        return
    for f in result.findings:
        ftype = getattr(f, "finding_type", None) or (f.get("finding_type") if isinstance(f, dict) else None)
        value = getattr(f, "value", None) or (f.get("value") if isinstance(f, dict) else None)
        if not ftype or not value:
            continue
        ctx.setdefault(ftype, [])
        if value not in ctx[ftype]:
            ctx[ftype].append(value)

    # Convenience aliases
    ctx["subdomains"]  = ctx.get("subdomain", []) + ctx.get("subdomain_permutation", [])
    ctx["live_hosts"]  = ctx.get("live_host", [])
    ctx["open_ports"]  = ctx.get("open_port", [])
    ctx["urls"]        = ctx.get("url", []) + ctx.get("historical_url", [])
    ctx["emails"]      = ctx.get("email", [])


# ─────────────────────────────────────────────────────────────────────────────
# Standard input transformers
# ─────────────────────────────────────────────────────────────────────────────

def _subdomains_as_list(ctx: dict) -> dict:
    subs = ctx.get("subdomains", [])
    return {"subdomains": subs} if subs else {}

def _hosts_from_context(ctx: dict) -> dict:
    return {"hosts": ctx.get("live_hosts", [])} if ctx.get("live_hosts") else {}

def _cidrs_from_context(ctx: dict) -> dict:
    return {"cidr_list": ctx.get("cidr_range", [])} if ctx.get("cidr_range") else {}

def _urls_from_context(ctx: dict) -> dict:
    urls = ctx.get("urls", [])
    return {"urls": urls[:500]} if urls else {}

def _emails_from_context(ctx: dict) -> dict:
    return {"emails": ctx.get("emails", [])} if ctx.get("emails") else {}

def _only_if_hosts(ctx: dict) -> bool:
    return bool(ctx.get("live_hosts") or ctx.get("subdomains"))

def _only_if_urls(ctx: dict) -> bool:
    return bool(ctx.get("urls"))

def _only_if_cidrs(ctx: dict) -> bool:
    return bool(ctx.get("cidr_range"))


# ─────────────────────────────────────────────────────────────────────────────
# Built-in chain definitions
# ─────────────────────────────────────────────────────────────────────────────

ASSET_DISCOVERY_CHAIN: list[ChainStep] = [
    ChainStep("WhoisTool",            description="WHOIS registration data"),
    ChainStep("TheHarvesterTool",     description="OSINT emails, subdomains, IPs"),
    ChainStep("GitHubSubdomainsTool", description="GitHub repo intelligence"),
    ChainStep("Sublist3rTool",        description="Passive subdomain enumeration"),
    ChainStep("CrtshTool",            description="Certificate transparency logs"),
    ChainStep("AmassTool",            description="Active subdomain enumeration"),
    ChainStep("AlterxTool",           description="Subdomain permutation generation",
              input_fn=_subdomains_as_list),
    ChainStep("ShuffleDNSTool",       description="Wildcard-filtered DNS validation",
              input_fn=_subdomains_as_list),
]

DNS_PIPELINE_CHAIN: list[ChainStep] = [
    ChainStep("DNSReconTool",  description="Full DNS record enumeration"),
    ChainStep("DNSEnumTool",   description="Zone transfer checks + brute force"),
    ChainStep("FierceTool",    description="Adjacent IP pivot via reverse DNS"),
    ChainStep("TLSXTool",      description="TLS SAN extraction",
              input_fn=_subdomains_as_list),
    ChainStep("PureDNSTool",   description="High-accuracy final validation",
              input_fn=_subdomains_as_list),
]

NETWORK_DISCOVERY_CHAIN: list[ChainStep] = [
    ChainStep("AsnmapTool",      description="ASN to CIDR range mapping"),
    ChainStep("MapCIDRTool",     description="CIDR expansion",
              input_fn=_cidrs_from_context, condition_fn=_only_if_cidrs),
    ChainStep("FpingTool",       description="ICMP host sweep"),
    ChainStep("NetdiscoverTool", description="ARP host discovery"),
    ChainStep("NmapTool",        description="Port scan + service detection",
              input_fn=_hosts_from_context, condition_fn=_only_if_hosts,
              required=True),
]

WEB_RECON_CHAIN: list[ChainStep] = [
    ChainStep("HttpxTool",        description="HTTP probing + tech detection",
              input_fn=_subdomains_as_list),
    ChainStep("Wafw00fTool",      description="WAF fingerprinting"),
    ChainStep("WhatWebTool",      description="Technology detection"),
    ChainStep("GauTool",          description="Historical URL collection"),
    ChainStep("WaymoreTool",      description="Multi-source URL aggregation"),
    ChainStep("KatanaTool",       description="JS-aware web crawling",
              condition_fn=_only_if_urls),
    ChainStep("GospiderTool",     description="Recursive endpoint spider",
              condition_fn=_only_if_urls),
    ChainStep("FeroxbusterTool",  description="Recursive content discovery"),
    ChainStep("ParamSpiderTool",  description="Parameter mining from archives"),
    ChainStep("ArjunTool",        description="Active parameter fuzzing",
              input_fn=_urls_from_context, condition_fn=_only_if_urls),
    ChainStep("GoWitnessTool",    description="Visual web reconnaissance",
              input_fn=_urls_from_context, condition_fn=_only_if_urls),
]

API_RECON_CHAIN: list[ChainStep] = [
    ChainStep("KiterunnerTool", description="API route discovery"),
    ChainStep("Graphw00fTool",  description="GraphQL endpoint detection"),
    ChainStep("ArjunTool",      description="Parameter discovery on API routes"),
]

SECRETS_PIPELINE_CHAIN: list[ChainStep] = [
    ChainStep("GitHubSubdomainsTool", description="GitHub code intelligence"),
    ChainStep("TrufflehogTool",       description="Credential detection (verified)"),
    ChainStep("GitleaksTool",         description="Git secret scanning"),
]

CLOUD_RECON_CHAIN: list[ChainStep] = [
    ChainStep("AsnmapTool",   description="Cloud provider ASN mapping"),
    ChainStep("S3ScannerTool", description="Cloud bucket exposure detection"),
    ChainStep("TLSXTool",     description="Certificate analysis"),
]

CERTIFICATE_CHAIN: list[ChainStep] = [
    ChainStep("CrtshTool",    description="CT log subdomain discovery"),
    ChainStep("TLSXTool",     description="TLS fingerprinting + SAN extraction"),
    ChainStep("TestSSLTool",  description="TLS vulnerability audit"),
]

IDENTITY_RECON_CHAIN: list[ChainStep] = [
    ChainStep("TheHarvesterTool",  description="Email + name harvesting"),
    ChainStep("OSRFrameworkTool",  description="Username intelligence"),
    ChainStep("SherlockTool",      description="Cross-platform account discovery"),
    ChainStep("HoleheTool",        description="Email-to-account mapping",
              input_fn=_emails_from_context, condition_fn=_only_if_hosts),
    ChainStep("SpiderFootTool",    description="OSINT correlation engine"),
    ChainStep("MaltegoTool",       description="Entity graph export"),
]

FULL_RECON_CHAIN: list[ChainStep] = (
    ASSET_DISCOVERY_CHAIN
    + DNS_PIPELINE_CHAIN
    + NETWORK_DISCOVERY_CHAIN
    + WEB_RECON_CHAIN
    + API_RECON_CHAIN
    + SECRETS_PIPELINE_CHAIN
    + CLOUD_RECON_CHAIN
)

# ── Chain registry ────────────────────────────────────────────────────────────

BUILTIN_CHAINS: dict[str, list[ChainStep]] = {
    "asset_discovery":  ASSET_DISCOVERY_CHAIN,
    "dns_pipeline":     DNS_PIPELINE_CHAIN,
    "network_discovery": NETWORK_DISCOVERY_CHAIN,
    "web_recon":        WEB_RECON_CHAIN,
    "api_recon":        API_RECON_CHAIN,
    "secrets":          SECRETS_PIPELINE_CHAIN,
    "cloud_recon":      CLOUD_RECON_CHAIN,
    "certificate":      CERTIFICATE_CHAIN,
    "identity_recon":   IDENTITY_RECON_CHAIN,
    "full_recon":       FULL_RECON_CHAIN,
}


# ─────────────────────────────────────────────────────────────────────────────
# ChainRunner
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class StepOutcome:
    step:       ChainStep
    tool_name:  str
    status:     str          # "success"|"failed"|"skipped"|"missing"|"conditional_skip"
    duration_s: float = 0.0
    error:      str   = ""
    finding_count: int = 0


class ChainRunner:
    """
    Executes a chain of ChainSteps sequentially, passing accumulated findings
    as context between steps.

    Usage:
        runner = ChainRunner(registry, on_step=my_callback)
        outcomes, context = runner.run("example.com", ASSET_DISCOVERY_CHAIN)
    """

    def __init__(
        self,
        registry,                                   # ToolRegistry instance
        on_step_start:  Optional[Callable] = None,  # (ChainStep) → None
        on_step_finish: Optional[Callable] = None,  # (StepOutcome) → None
        halt_on_required_failure: bool = True,
    ):
        self.registry   = registry
        self.on_start   = on_step_start
        self.on_finish  = on_step_finish
        self.halt_on_rf = halt_on_required_failure

    def run(
        self,
        target:     str,
        chain:      list[ChainStep],
        context:    Optional[dict] = None,
        extra_kwargs: Optional[dict] = None,
    ) -> tuple[list[StepOutcome], dict]:
        """
        Run a chain against target.

        Returns:
            (list[StepOutcome], accumulated context dict)
        """
        ctx      = context or {"target": target}
        outcomes: list[StepOutcome] = []
        global_kwargs = extra_kwargs or {}

        for step in chain:
            meta = self.registry.get(step.tool_class)
            tool_name = step.tool_class

            # ── Condition check ───────────────────────────────────────────────
            if not step.should_run(ctx):
                outcome = StepOutcome(step, tool_name, "conditional_skip")
                outcomes.append(outcome)
                log.info(f"[CONDITIONAL SKIP] {tool_name}")
                if self.on_finish:
                    self.on_finish(outcome)
                continue

            # ── Tool availability ─────────────────────────────────────────────
            if not meta or not meta.instance:
                outcome = StepOutcome(step, tool_name, "missing",
                                      error="Tool not in registry")
                outcomes.append(outcome)
                log.warning(f"[MISSING] {tool_name}")
                if self.on_finish:
                    self.on_finish(outcome)
                if step.required and self.halt_on_rf:
                    log.error(f"Required step {tool_name} missing — halting chain.")
                    break
                continue

            # ── Build kwargs ──────────────────────────────────────────────────
            run_kwargs = {**global_kwargs, **step.build_kwargs(ctx)}

            if self.on_start:
                self.on_start(step)
            log.info(f"[RUNNING] {tool_name}")

            t0 = time.perf_counter()
            try:
                result = meta.instance.safe_run(target, **run_kwargs)
            except Exception as exc:
                result = None
                err = str(exc)
                log.error(f"[FAILED] {tool_name}: {err}")
                outcome = StepOutcome(step, tool_name, "failed",
                                      duration_s=time.perf_counter() - t0, error=err)
                outcomes.append(outcome)
                if self.on_finish:
                    self.on_finish(outcome)
                if step.required and self.halt_on_rf:
                    break
                continue

            dur = time.perf_counter() - t0

            # ── Classify result ───────────────────────────────────────────────
            status = getattr(result, "status", "unknown") if result else "failed"
            findings = getattr(result, "findings", []) if result else []
            n_findings = len(findings)

            if status in ("success", "no_output", "partial"):
                # Propagate findings into context
                step.apply_output(result, ctx)
                outcome = StepOutcome(step, tool_name, "success",
                                      duration_s=dur, finding_count=n_findings)
                log.info(f"[SUCCESS] {tool_name} — {n_findings} findings in {dur:.1f}s")
            elif status == "skipped":
                outcome = StepOutcome(step, tool_name, "skipped", duration_s=dur)
                log.info(f"[SKIPPED] {tool_name}")
            else:
                err = getattr(result, "error", {})
                err_msg = (err.message if hasattr(err, "message") else str(err))
                outcome = StepOutcome(step, tool_name, "failed",
                                      duration_s=dur, error=err_msg)
                log.warning(f"[FAILED] {tool_name}: {err_msg}")
                if step.required and self.halt_on_rf:
                    outcomes.append(outcome)
                    if self.on_finish:
                        self.on_finish(outcome)
                    break

            outcomes.append(outcome)
            if self.on_finish:
                self.on_finish(outcome)

        return outcomes, ctx
