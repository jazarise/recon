"""
ReconX — Orchestration: Execution Pipeline Engine (Stage 13).

Executes tool graphs with:
  • Parallel execution of independent tools (ThreadPoolExecutor)
  • Staged execution: passive → active → deep
  • Dependency graph resolution (topological sort)
  • Priority queues within each stage
  • Per-tool retry orchestration
  • Failure isolation — one tool crash never stops the pipeline
  • Live status callbacks for TUI integration

Pipeline lifecycle:
  build() → validate() → execute() → results
"""
from __future__ import annotations

import logging
import time
from collections import defaultdict, deque
from concurrent.futures import Future, ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Optional

log = logging.getLogger("reconx.orchestration.pipeline")


# ─────────────────────────────────────────────────────────────────────────────
# Pipeline task
# ─────────────────────────────────────────────────────────────────────────────

class TaskStatus(str, Enum):
    PENDING   = "pending"
    QUEUED    = "queued"
    RUNNING   = "running"
    SUCCESS   = "success"
    FAILED    = "failed"
    SKIPPED   = "skipped"
    MISSING   = "missing"
    RETRYING  = "retrying"
    CANCELLED = "cancelled"


@dataclass
class PipelineTask:
    """One tool execution unit inside the pipeline."""
    tool_class:   str
    target:       str
    stage:        int          = 2       # 1=passive 2=active 3=deep
    priority:     int          = 50      # lower = runs first within stage
    depends_on:   list[str]   = field(default_factory=list)  # class names
    max_retries:  int          = 1
    kwargs:       dict         = field(default_factory=dict)
    # Runtime state
    status:       TaskStatus   = TaskStatus.PENDING
    result:       Optional[Any] = field(default=None, repr=False)
    error:        str          = ""
    attempts:     int          = 0
    started_at:   float        = 0.0
    finished_at:  float        = 0.0
    finding_count: int         = 0

    @property
    def duration_s(self) -> float:
        if self.started_at and self.finished_at:
            return self.finished_at - self.started_at
        return 0.0

    @property
    def can_run(self) -> bool:
        return self.status == TaskStatus.PENDING


@dataclass
class PipelineResult:
    target:       str
    tasks:        list[PipelineTask]
    total_findings: int        = 0
    duration_s:   float        = 0.0
    started_at:   float        = 0.0
    finished_at:  float        = 0.0
    all_findings: list         = field(default_factory=list)
    context:      dict         = field(default_factory=dict)

    @property
    def success_count(self) -> int:
        return sum(1 for t in self.tasks if t.status == TaskStatus.SUCCESS)

    @property
    def failed_count(self) -> int:
        return sum(1 for t in self.tasks if t.status == TaskStatus.FAILED)

    @property
    def skipped_count(self) -> int:
        return sum(1 for t in self.tasks if t.status in (TaskStatus.SKIPPED, TaskStatus.MISSING))


# ─────────────────────────────────────────────────────────────────────────────
# Pipeline Engine
# ─────────────────────────────────────────────────────────────────────────────

class PipelineEngine:
    """
    Executes a list of PipelineTasks respecting:
      1. Stage order (passive → active → deep)
      2. Dependency graph within each stage
      3. Parallel execution of independent tasks
      4. Retries with exponential back-off
      5. Context propagation between tasks

    Usage:
        engine = PipelineEngine(registry, max_workers=8)
        tasks  = engine.build_tasks(target, chain_steps, tool_kwargs)
        result = engine.execute(tasks, target)
    """

    STAGE_LABELS = {1: "Passive", 2: "Active", 3: "Deep"}

    def __init__(
        self,
        registry,
        max_workers:    int  = 8,
        retry_delay_s:  float = 2.0,
        on_task_start:  Optional[Callable[[PipelineTask], None]] = None,
        on_task_finish: Optional[Callable[[PipelineTask], None]] = None,
    ):
        self.registry       = registry
        self.max_workers    = max_workers
        self.retry_delay    = retry_delay_s
        self.on_task_start  = on_task_start
        self.on_task_finish = on_task_finish

    # ── public API ────────────────────────────────────────────────────────────

    def build_tasks(
        self,
        target:       str,
        tool_classes: list[str],
        kwargs_map:   Optional[dict[str, dict]] = None,
    ) -> list[PipelineTask]:
        """Convert a flat tool list into PipelineTasks with metadata from registry."""
        tasks: list[PipelineTask] = []
        km = kwargs_map or {}
        for tc in tool_classes:
            meta = self.registry.get(tc)
            tasks.append(PipelineTask(
                tool_class = tc,
                target     = target,
                stage      = meta.stage    if meta else 2,
                priority   = meta.priority if meta else 50,
                depends_on = [],
                kwargs     = km.get(tc, {}),
            ))
        return tasks

    def execute(
        self,
        tasks:   list[PipelineTask],
        target:  str,
        context: Optional[dict] = None,
    ) -> PipelineResult:
        ctx = context or {"target": target}
        started = time.perf_counter()

        # Group by stage and run each stage sequentially
        by_stage = defaultdict(list)
        for task in tasks:
            by_stage[task.stage].append(task)

        for stage in sorted(by_stage.keys()):
            stage_tasks = sorted(by_stage[stage], key=lambda t: t.priority)
            self._run_stage(stage, stage_tasks, ctx)

        finished = time.perf_counter()
        all_findings = []
        for task in tasks:
            if task.result and hasattr(task.result, "findings"):
                all_findings.extend(task.result.findings)

        return PipelineResult(
            target        = target,
            tasks         = tasks,
            total_findings = len(all_findings),
            duration_s    = finished - started,
            started_at    = started,
            finished_at   = finished,
            all_findings  = all_findings,
            context       = ctx,
        )

    # ── stage execution ───────────────────────────────────────────────────────

    def _run_stage(
        self, stage: int, tasks: list[PipelineTask], ctx: dict
    ) -> None:
        label = self.STAGE_LABELS.get(stage, f"Stage-{stage}")
        log.info(f"── {label} stage: {len(tasks)} task(s) ──")

        ready, waiting = self._split_by_deps(tasks)

        with ThreadPoolExecutor(max_workers=self.max_workers) as pool:
            futures: dict[Future, PipelineTask] = {}

            # Submit initially-ready tasks
            for task in ready:
                if self._check_available(task):
                    f = pool.submit(self._run_task, task, ctx)
                    futures[f] = task

            # Drain futures, check if newly-unblocked tasks can start
            while futures:
                done_futs = list(as_completed(futures, timeout=1.0))
                for fut in done_futs:
                    task = futures.pop(fut)
                    try:
                        fut.result()   # propagates exceptions if any
                    except Exception as exc:
                        task.status = TaskStatus.FAILED
                        task.error  = str(exc)
                        log.error(f"Future error [{task.tool_class}]: {exc}")

                    if self.on_task_finish:
                        self.on_task_finish(task)

                    # Check if any waiting task is now unblocked
                    newly_ready = [
                        wt for wt in waiting
                        if wt.can_run and self._deps_satisfied(wt, tasks)
                    ]
                    for wt in newly_ready:
                        waiting.remove(wt)
                        if self._check_available(wt):
                            f2 = pool.submit(self._run_task, wt, ctx)
                            futures[f2] = wt

        # Mark any still-pending tasks as cancelled (dep failure)
        for task in waiting:
            if task.status == TaskStatus.PENDING:
                task.status = TaskStatus.CANCELLED
                task.error  = "Dependency failed or missing"
                log.warning(f"[CANCELLED] {task.tool_class}")

    def _run_task(self, task: PipelineTask, ctx: dict) -> None:
        """Execute one PipelineTask with retry logic."""
        meta = self.registry.get(task.tool_class)
        if not meta or not meta.instance:
            task.status = TaskStatus.MISSING
            log.warning(f"[MISSING] {task.tool_class}")
            return

        task.status     = TaskStatus.RUNNING
        task.started_at = time.perf_counter()

        if self.on_task_start:
            self.on_task_start(task)

        # Merge context-derived inputs
        run_kwargs = {**task.kwargs, **self._context_kwargs(task.tool_class, ctx)}

        for attempt in range(task.max_retries + 1):
            task.attempts = attempt + 1
            if attempt > 0:
                task.status = TaskStatus.RETRYING
                log.info(f"[RETRY {attempt}] {task.tool_class}")
                time.sleep(self.retry_delay * attempt)

            try:
                result = meta.instance.safe_run(task.target, **run_kwargs)
                task.result = result

                status = getattr(result, "status", "unknown")
                if status in ("success", "no_output", "partial"):
                    task.status       = TaskStatus.SUCCESS
                    task.finding_count = len(getattr(result, "findings", []))
                    self._propagate(result, ctx)
                    break
                elif status == "skipped":
                    task.status = TaskStatus.SKIPPED
                    break
                else:
                    err = getattr(result, "error", None)
                    task.error = str(getattr(err, "message", err)) if err else "unknown"
                    if attempt < task.max_retries:
                        continue
                    task.status = TaskStatus.FAILED

            except Exception as exc:
                task.error = str(exc)
                log.exception(f"[ERROR] {task.tool_class}: {exc}")
                if attempt < task.max_retries:
                    continue
                task.status = TaskStatus.FAILED

        task.finished_at = time.perf_counter()

    # ── helpers ───────────────────────────────────────────────────────────────

    @staticmethod
    def _split_by_deps(
        tasks: list[PipelineTask],
    ) -> tuple[list[PipelineTask], list[PipelineTask]]:
        ready   = [t for t in tasks if not t.depends_on]
        waiting = [t for t in tasks if t.depends_on]
        return ready, waiting

    @staticmethod
    def _deps_satisfied(task: PipelineTask, all_tasks: list[PipelineTask]) -> bool:
        done = {t.tool_class for t in all_tasks
                if t.status in (TaskStatus.SUCCESS, TaskStatus.SKIPPED,
                                TaskStatus.MISSING, TaskStatus.NO_OUTPUT)}
        return all(dep in done for dep in task.depends_on)

    def _check_available(self, task: PipelineTask) -> bool:
        meta = self.registry.get(task.tool_class)
        if not meta or not meta.instance:
            task.status = TaskStatus.MISSING
            return False
        return True

    @staticmethod
    def _propagate(result: Any, ctx: dict) -> None:
        """Merge findings into the shared context."""
        for f in getattr(result, "findings", []):
            ftype = getattr(f, "finding_type", None)
            value = getattr(f, "value", None)
            if ftype and value:
                ctx.setdefault(ftype, [])
                if value not in ctx[ftype]:
                    ctx[ftype].append(value)

    @staticmethod
    def _context_kwargs(tool_class: str, ctx: dict) -> dict:
        """Build extra kwargs from context based on tool type."""
        kw: dict = {}
        subs = ctx.get("subdomain", [])
        if subs and tool_class in ("ShuffleDNSTool", "PureDNSTool", "TLSXTool"):
            kw["subdomains"] = subs
        urls = ctx.get("url", []) + ctx.get("historical_url", [])
        if urls and tool_class in ("GospiderTool", "ArjunTool", "GoWitnessTool"):
            kw["urls"] = urls[:200]
        hosts = ctx.get("live_host", [])
        if hosts and tool_class in ("NmapTool", "MetasploitAuxTool"):
            kw["hosts"] = hosts
        cidrs = ctx.get("cidr_range", [])
        if cidrs and tool_class in ("MapCIDRTool", "FpingTool"):
            kw["cidr_list"] = cidrs
        return kw

    # ── TaskStatus alias ──────────────────────────────────────────────────────
    NO_OUTPUT = TaskStatus.SKIPPED   # for compat
