"""
ReconX — Orchestration: Central Tool Registry (Stage 13).

Auto-discovers every BaseTool subclass across the tools/ tree, builds a
structured index keyed by class name, and exposes filtering / searching APIs
consumed by the pipeline engine, guided recon, learning mode, and the TUI.

Design goals:
  • Zero manual registration — scan happens at import time via importlib.
  • Metadata is read from class attributes (NAME, CATEGORY, PASSIVE, STAGE…).
  • Graceful: a broken tool module never crashes the registry.
  • Searchable by name, category, tag, input type, and dependency.
"""
from __future__ import annotations

import importlib
import inspect
import logging
import pkgutil
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Optional

log = logging.getLogger("reconx.orchestration.registry")


# ─────────────────────────────────────────────────────────────────────────────
# Tool metadata dataclass
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class ToolMeta:
    """Indexed record for one registered tool."""
    class_name:    str
    name:          str
    binary:        str
    category:      str
    stage:         int                    # 1=passive, 2=active, 3=deep
    passive:       bool
    priority:      int
    timeout:       int
    install_cmd:   str
    dependencies:  list[str]             = field(default_factory=list)
    tags:          list[str]             = field(default_factory=list)
    supported_inputs: list[str]          = field(default_factory=list)
    description:   str                   = ""
    module_path:   str                   = ""
    instance:      Optional[Any]         = field(default=None, repr=False)
    available:     Optional[bool]        = None   # None = not yet checked

    @property
    def is_available(self) -> bool:
        if self.available is None:
            self.available = (
                self.instance.is_available()
                if self.instance and hasattr(self.instance, "is_available")
                else False
            )
        return bool(self.available)

    def status_label(self) -> str:
        if self.available is True:  return "OK"
        if self.available is False: return "MISSING"
        return "UNKNOWN"


# ─────────────────────────────────────────────────────────────────────────────
# Input-type hints derived from tool category / class attributes
# ─────────────────────────────────────────────────────────────────────────────

_CATEGORY_INPUTS: dict[str, list[str]] = {
    "osint":        ["domain", "email", "username", "phone"],
    "passive":      ["domain", "subdomain"],
    "subdomain":    ["domain"],
    "dns":          ["domain"],
    "dns_intel":    ["domain", "subdomain"],
    "dns_extra":    ["domain"],
    "asset":        ["domain", "asn", "cidr"],
    "network":      ["cidr", "ip", "domain"],
    "web":          ["url", "domain", "subdomain"],
    "param":        ["url", "domain"],
    "api_recon":    ["url"],
    "screenshot":   ["url", "domain"],
    "secrets":      ["git_url", "path", "domain"],
    "cloud":        ["domain", "bucket", "cidr"],
    "certs":        ["domain", "ip"],
    "fingerprint":  ["url", "domain", "ip"],
    "framework":    ["ip", "domain"],
    "identity":     ["email", "username", "phone"],
    "utility":      ["ip", "domain", "url"],
}


# ─────────────────────────────────────────────────────────────────────────────
# ToolRegistry
# ─────────────────────────────────────────────────────────────────────────────

class ToolRegistry:
    """
    Singleton-style registry populated by scanning the tools/ package tree.

    Usage:
        registry = ToolRegistry.build()
        nmap = registry.get("NmapTool")
        dns_tools = registry.by_category("dns")
        passive = registry.filter(passive=True, stage=1)
    """

    _instance: Optional["ToolRegistry"] = None

    def __init__(self) -> None:
        self._tools: dict[str, ToolMeta] = {}
        self._built_at: float = 0.0

    # ── singleton ─────────────────────────────────────────────────────────────

    @classmethod
    def build(
        cls,
        base_package: str = "reconx",
        instantiate:  bool = True,
        force_rebuild: bool = False,
    ) -> "ToolRegistry":
        if cls._instance and not force_rebuild:
            return cls._instance
        inst = cls()
        inst._scan(base_package, instantiate)
        inst._built_at = time.time()
        cls._instance = inst
        log.info(f"ToolRegistry built: {len(inst._tools)} tools registered.")
        return inst

    # ── core API ──────────────────────────────────────────────────────────────

    def get(self, class_name: str) -> Optional[ToolMeta]:
        return self._tools.get(class_name)

    def get_instance(self, class_name: str) -> Optional[Any]:
        meta = self._tools.get(class_name)
        return meta.instance if meta else None

    def all(self) -> list[ToolMeta]:
        return list(self._tools.values())

    def count(self) -> int:
        return len(self._tools)

    # ── filtering ─────────────────────────────────────────────────────────────

    def by_category(self, category: str) -> list[ToolMeta]:
        cat = category.lower()
        return [t for t in self._tools.values()
                if t.category.lower() == cat]

    def by_tag(self, tag: str) -> list[ToolMeta]:
        tag_lower = tag.lower()
        return [t for t in self._tools.values()
                if tag_lower in (tg.lower() for tg in t.tags)]

    def by_stage(self, stage: int) -> list[ToolMeta]:
        return [t for t in self._tools.values() if t.stage == stage]

    def by_input(self, input_type: str) -> list[ToolMeta]:
        it = input_type.lower()
        return [t for t in self._tools.values()
                if it in t.supported_inputs]

    def filter(
        self,
        *,
        passive:   Optional[bool]   = None,
        stage:     Optional[int]    = None,
        category:  Optional[str]    = None,
        available: Optional[bool]   = None,
        tags:      Optional[list[str]] = None,
        inputs:    Optional[list[str]] = None,
    ) -> list[ToolMeta]:
        results = list(self._tools.values())
        if passive   is not None: results = [t for t in results if t.passive == passive]
        if stage     is not None: results = [t for t in results if t.stage == stage]
        if category  is not None: results = [t for t in results if t.category.lower() == category.lower()]
        if available is not None: results = [t for t in results if t.is_available == available]
        if tags:
            tl = [tg.lower() for tg in tags]
            results = [t for t in results if any(tg.lower() in tl for tg in t.tags)]
        if inputs:
            il = [i.lower() for i in inputs]
            results = [t for t in results if any(i in t.supported_inputs for i in il)]
        return sorted(results, key=lambda t: (t.stage, t.priority))

    def search(self, query: str) -> list[ToolMeta]:
        q = query.lower()
        return [
            t for t in self._tools.values()
            if q in t.name.lower()
            or q in t.category.lower()
            or q in t.description.lower()
            or any(q in tg.lower() for tg in t.tags)
        ]

    def categories(self) -> list[str]:
        return sorted({t.category for t in self._tools.values()})

    # ── availability check ────────────────────────────────────────────────────

    def probe_availability(self) -> dict[str, bool]:
        """Probe all tools and cache availability status. Returns name→bool map."""
        results: dict[str, bool] = {}
        for meta in self._tools.values():
            meta.available = meta.is_available
            results[meta.class_name] = meta.available
        return results

    # ── registration ──────────────────────────────────────────────────────────

    def register(self, meta: ToolMeta) -> None:
        self._tools[meta.class_name] = meta
        log.debug(f"Registered: {meta.class_name} ({meta.category})")

    def register_instance(self, instance: Any) -> bool:
        """Register a pre-built tool instance (for manual / test registration)."""
        if not hasattr(instance, "NAME"):
            return False
        meta = self._meta_from_instance(instance)
        self._tools[meta.class_name] = meta
        return True

    # ── scanning ──────────────────────────────────────────────────────────────

    def _scan(self, base_package: str, instantiate: bool) -> None:
        """Walk tools/ sub-packages and register every BaseTool subclass."""
        try:
            tools_pkg = importlib.import_module(f"{base_package}.tools")
        except ModuleNotFoundError:
            try:
                tools_pkg = importlib.import_module("tools")
            except ModuleNotFoundError:
                log.warning("Cannot locate tools package — registry empty.")
                return

        pkg_path = Path(tools_pkg.__file__).parent
        self._walk_package(tools_pkg.__name__, pkg_path, instantiate)

    def _walk_package(self, pkg_name: str, pkg_path: Path, instantiate: bool) -> None:
        for finder, module_name, is_pkg in pkgutil.walk_packages(
            path=[str(pkg_path)],
            prefix=f"{pkg_name}.",
            onerror=lambda name: log.debug(f"Walk error: {name}"),
        ):
            # Skip test, cache, and __pycache__ modules
            if any(skip in module_name for skip in ("test_", "__pycache__", "registry_")):
                continue
            try:
                mod = importlib.import_module(module_name)
                self._extract_tools(mod, module_name, instantiate)
            except Exception as e:
                log.debug(f"Skipped {module_name}: {e}")

    def _extract_tools(self, mod, module_path: str, instantiate: bool) -> None:
        """Find BaseTool subclasses in a module and register them."""
        # Lazy import to avoid circular deps
        try:
            from reconx.tools.base import BaseTool as _BaseTool
        except ModuleNotFoundError:
            try:
                from tools.base import BaseTool as _BaseTool
            except ModuleNotFoundError:
                return

        for name, obj in inspect.getmembers(mod, inspect.isclass):
            if (obj is _BaseTool
                    or not issubclass(obj, _BaseTool)
                    or obj.__module__ != mod.__name__
                    or name in self._tools):
                continue
            if not hasattr(obj, "NAME") or not hasattr(obj, "BINARY"):
                continue

            instance = None
            if instantiate:
                try:
                    instance = obj()
                except Exception as e:
                    log.debug(f"Cannot instantiate {name}: {e}")

            meta = self._meta_from_class(obj, instance, module_path)
            self._tools[name] = meta

    @staticmethod
    def _meta_from_class(cls, instance: Optional[Any], module_path: str) -> ToolMeta:
        cat = getattr(cls, "CATEGORY", "unknown")
        return ToolMeta(
            class_name       = cls.__name__,
            name             = getattr(cls, "NAME", cls.__name__),
            binary           = getattr(cls, "BINARY", ""),
            category         = cat,
            stage            = getattr(cls, "STAGE", 2),
            passive          = getattr(cls, "PASSIVE", False),
            priority         = getattr(cls, "PRIORITY", 50),
            timeout          = getattr(cls, "TIMEOUT", 60),
            install_cmd      = getattr(cls, "INSTALL_CMD", ""),
            dependencies     = list(getattr(cls, "DEPENDENCIES", [])),
            tags             = list(getattr(cls, "TAGS", [])),
            supported_inputs = _CATEGORY_INPUTS.get(cat.lower(), ["domain", "ip", "url"]),
            description      = (cls.__doc__ or "").strip()[:200],
            module_path      = module_path,
            instance         = instance,
        )

    @staticmethod
    def _meta_from_instance(inst: Any) -> ToolMeta:
        return ToolRegistry._meta_from_class(type(inst), inst, type(inst).__module__)
