"""
ReconX — CVE Mapper.
Matches discovered services/versions against a local CVE database.
"""
from __future__ import annotations
import json
import logging
import os
from pathlib import Path

from ..models.findings import Port, CVEMatch

logger = logging.getLogger("reconx.analysis.cve_mapper")

_DB_PATH = Path(__file__).parent.parent / "data" / "cve_db.json"


class CVEMapper:
    def __init__(self, db_path: str | None = None):
        path = db_path or str(_DB_PATH)
        try:
            with open(path, "r", encoding="utf-8") as f:
                self._db: dict = json.load(f)
            logger.debug("CVE DB loaded: %d service entries", len(self._db))
        except Exception as exc:
            logger.warning("Could not load CVE DB (%s): %s", path, exc)
            self._db = {}

    def scan(self, ports: list[Port]) -> list[CVEMatch]:
        """Match all ports against CVE DB; return deduplicated list."""
        matches: list[CVEMatch] = []
        seen: set[str] = set()

        for port in ports:
            service_key = port.service.lower().strip()
            version_str = (port.version or "").strip()

            entries = self._db.get(service_key, [])

            for entry in entries:
                # Empty version_match = applies to all versions
                vm = entry.get("version_match", "")
                if vm and vm not in version_str:
                    continue

                cve_id = entry["cve_id"]
                if cve_id in seen:
                    continue
                seen.add(cve_id)

                matches.append(CVEMatch(
                    cve_id=cve_id,
                    severity=entry.get("severity", "UNKNOWN"),
                    description=entry.get("description", ""),
                    service=service_key,
                    port=port.number,
                    cvss=float(entry.get("cvss", 0.0)),
                    reference=entry.get("reference", ""),
                ))

        # Sort: CRITICAL first, then by CVSS descending
        sev_order = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "UNKNOWN": 4}
        matches.sort(key=lambda x: (sev_order.get(x.severity.upper(), 4), -x.cvss))
        return matches
