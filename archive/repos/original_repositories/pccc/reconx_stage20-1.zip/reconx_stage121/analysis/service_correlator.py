"""
ReconX — Stage 17: Service Correlation Layer.

Transforms raw scan findings into a correlated infrastructure picture by
linking IPs, hostnames, services, technologies, CDN providers, and ASN info
into typed, confidence-scored correlation objects.

Correlation types produced:
  ip_hostname      — IP ↔ hostname binding (from DNS, banner, or TLS)
  hostname_sub     — hostname ↔ subdomain chain
  service_tech     — open port ↔ detected technology
  asn_infra        — ASN range ↔ infrastructure grouping
  port_app         — canonical port → application mapping
  shared_infra     — multiple hostnames sharing same IP / TLS / banner
  cdn_shielded     — host behind a CDN (traffic masked)

Usage:
    from reconx.analysis.service_correlator import ServiceCorrelator
    from reconx.models.findings import ReconResult

    correlator = ServiceCorrelator()
    report     = correlator.correlate(result)

    for node in report.nodes:
        print(node.render_tree())
"""
from __future__ import annotations

import logging
import re
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Optional

from ..models.findings import ReconResult, Port, Technology

log = logging.getLogger("reconx.analysis.service_correlator")


# ─────────────────────────────────────────────────────────────────────────────
# Known CDN / hosting ASN/banner signatures
# ─────────────────────────────────────────────────────────────────────────────

_CDN_SIGNATURES: dict[str, list[str]] = {
    "Cloudflare":  ["cloudflare", "cf-ray", "cf-cache-status", "__cfduid"],
    "Akamai":      ["akamai", "akamaighost", "x-akamai-request-id"],
    "Fastly":      ["fastly", "x-fastly-request-id", "x-served-by"],
    "AWS CloudFront": ["cloudfront", "x-amz-cf-id", "x-amz-cf-pop"],
    "Azure CDN":   ["azure", "x-msedge-ref", "x-azure-ref"],
    "Incapsula":   ["incapsula", "incap_ses", "visid_incap"],
    "Sucuri":      ["sucuri", "x-sucuri-id"],
    "Imperva":     ["imperva", "x-iinfo"],
    "Google":      ["gws", "x-google", "google-frontend"],
}

# Port → canonical application name
_PORT_APP_MAP: dict[int, str] = {
    21: "FTP", 22: "SSH", 23: "Telnet", 25: "SMTP", 53: "DNS",
    67: "DHCP", 80: "HTTP", 110: "POP3", 111: "RPC/portmapper",
    119: "NNTP", 123: "NTP", 135: "MSRPC", 139: "NetBIOS", 143: "IMAP",
    161: "SNMP", 389: "LDAP", 443: "HTTPS", 445: "SMB", 465: "SMTPS",
    514: "Syslog", 587: "SMTP-submission", 636: "LDAPS", 993: "IMAPS",
    995: "POP3S", 1433: "MSSQL", 1521: "Oracle", 2049: "NFS",
    2375: "Docker-API", 2376: "Docker-TLS", 3000: "HTTP-alt/Grafana",
    3306: "MySQL", 3389: "RDP", 4443: "HTTPS-alt", 4848: "GlassFish",
    5000: "HTTP-alt/Docker-registry", 5432: "PostgreSQL", 5601: "Kibana",
    5900: "VNC", 6379: "Redis", 6443: "Kubernetes-API", 7001: "WebLogic",
    8080: "HTTP-alt", 8443: "HTTPS-alt", 8888: "HTTP-alt/Jupyter",
    9000: "SonarQube/PHP-FPM", 9090: "Prometheus", 9200: "Elasticsearch",
    9300: "Elasticsearch-cluster", 11211: "Memcached", 15672: "RabbitMQ",
    27017: "MongoDB", 50070: "Hadoop-HDFS",
}

# Banner substring → technology name
_BANNER_TECH: list[tuple[str, str]] = [
    ("nginx",         "nginx"),
    ("apache",        "Apache"),
    ("iis",           "IIS"),
    ("microsoft-iis", "IIS"),
    ("openssl",       "OpenSSL"),
    ("openssh",       "OpenSSH"),
    ("vsftpd",        "vsftpd"),
    ("proftpd",       "ProFTPD"),
    ("filezilla",     "FileZilla FTP"),
    ("postfix",       "Postfix"),
    ("sendmail",      "Sendmail"),
    ("exim",          "Exim"),
    ("dovecot",       "Dovecot"),
    ("lighttpd",      "Lighttpd"),
    ("tomcat",        "Tomcat"),
    ("jetty",         "Jetty"),
    ("jboss",         "JBoss"),
    ("weblogic",      "WebLogic"),
    ("wordpress",     "WordPress"),
    ("drupal",        "Drupal"),
    ("joomla",        "Joomla"),
    ("django",        "Django"),
    ("flask",         "Flask"),
    ("express",       "Express.js"),
    ("php",           "PHP"),
    ("ruby",          "Ruby"),
    ("python",        "Python"),
    ("go ",           "Go"),
    ("java",          "Java"),
]


# ─────────────────────────────────────────────────────────────────────────────
# Data models
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class CorrelationEdge:
    """A typed, confidence-scored relationship between two infrastructure nodes."""
    source:      str           # label of source node
    target:      str           # label of target node
    edge_type:   str           # ip_hostname | service_tech | cdn_shielded | …
    confidence:  float         # 0.0–1.0
    evidence:    list[str]     = field(default_factory=list)
    metadata:    dict          = field(default_factory=dict)


@dataclass
class InfraNode:
    """
    A correlated infrastructure node — the result of combining raw
    findings into a single enriched object.

    Can represent: host, IP, service, technology, CDN, ASN cluster.
    """
    label:        str
    node_type:    str            # host | ip | service | technology | cdn | asn
    tags:         list[str]      = field(default_factory=list)
    children:     list["InfraNode"] = field(default_factory=list)
    edges:        list[CorrelationEdge] = field(default_factory=list)
    metadata:     dict           = field(default_factory=dict)
    confidence:   float          = 1.0
    risk_hint:    str            = ""    # empty | LOW | MEDIUM | HIGH | CRITICAL

    def add_child(self, child: "InfraNode") -> None:
        if not any(c.label == child.label for c in self.children):
            self.children.append(child)

    def render_tree(self, indent: int = 0) -> str:
        """Return an ASCII tree representation."""
        prefix = "  " * indent
        connector = "└─> " if indent > 0 else ""
        risk = f"  [{self.risk_hint}]" if self.risk_hint else ""
        tags = f"  {', '.join(self.tags)}" if self.tags else ""
        lines = [f"{prefix}{connector}{self.label}{risk}{tags}"]
        for child in self.children:
            lines.append(child.render_tree(indent + 1))
        return "\n".join(lines)


@dataclass
class CorrelationReport:
    """Full correlation output from ServiceCorrelator.correlate()."""
    target:       str
    nodes:        list[InfraNode]       = field(default_factory=list)
    edges:        list[CorrelationEdge] = field(default_factory=list)
    cdn_detected: list[str]             = field(default_factory=list)
    warnings:     list[str]             = field(default_factory=list)

    # Convenience maps built during correlation
    ip_to_hosts:   dict[str, list[str]] = field(default_factory=dict)
    host_to_ips:   dict[str, list[str]] = field(default_factory=dict)
    port_to_app:   dict[int, str]       = field(default_factory=dict)
    tech_to_ports: dict[str, list[int]] = field(default_factory=dict)

    def node_count(self) -> int:
        return len(self.nodes)

    def edge_count(self) -> int:
        return len(self.edges)

    def to_dict(self) -> dict:
        return {
            "target":       self.target,
            "node_count":   self.node_count(),
            "edge_count":   self.edge_count(),
            "cdn_detected": self.cdn_detected,
            "warnings":     self.warnings,
            "ip_to_hosts":  self.ip_to_hosts,
            "host_to_ips":  self.host_to_ips,
            "port_to_app":  self.port_to_app,
            "tech_to_ports": self.tech_to_ports,
            "nodes": [
                {
                    "label":    n.label,
                    "type":     n.node_type,
                    "tags":     n.tags,
                    "risk":     n.risk_hint,
                    "children": [c.label for c in n.children],
                }
                for n in self.nodes
            ],
            "edges": [
                {
                    "source":     e.source,
                    "target":     e.target,
                    "type":       e.edge_type,
                    "confidence": e.confidence,
                    "evidence":   e.evidence,
                }
                for e in self.edges
            ],
        }


# ─────────────────────────────────────────────────────────────────────────────
# ServiceCorrelator
# ─────────────────────────────────────────────────────────────────────────────

class ServiceCorrelator:
    """
    Builds a correlated infrastructure view from a ReconResult.

    All correlation methods are isolated and fail-safe — any single
    method crashing adds a warning to the report and continues.
    """

    def correlate(self, result: ReconResult) -> CorrelationReport:
        """
        Main entry point.  Runs all correlation passes and returns
        a CorrelationReport.  Never raises.
        """
        report = CorrelationReport(target=result.target)

        passes = [
            ("ip_hostname",   self._correlate_ip_hostname),
            ("service_tech",  self._correlate_service_tech),
            ("port_app",      self._correlate_port_app),
            ("cdn_detect",    self._detect_cdn),
            ("asn_infra",     self._correlate_asn),
            ("build_tree",    self._build_host_tree),
        ]

        for name, fn in passes:
            try:
                fn(result, report)
            except Exception as exc:
                msg = f"Correlation pass '{name}' failed: {exc}"
                report.warnings.append(msg)
                log.warning(msg)

        log.info(
            f"Correlation complete for {result.target}: "
            f"{report.node_count()} nodes, {report.edge_count()} edges, "
            f"CDN: {report.cdn_detected or 'none'}"
        )
        return report

    # ── Pass 1: IP ↔ Hostname ─────────────────────────────────────────────────

    def _correlate_ip_hostname(
        self, result: ReconResult, report: CorrelationReport
    ) -> None:
        """Map IP addresses to all associated hostnames via DNS records + subdomains."""
        ip_to_hosts: dict[str, list[str]] = defaultdict(list)
        host_to_ips: dict[str, list[str]] = defaultdict(list)

        # From DNS A/AAAA records
        for rec in result.dns_records:
            if rec.record_type in ("A", "AAAA"):
                ip   = rec.value.strip()
                host = result.target
                if ip and _is_ip(ip):
                    if host not in ip_to_hosts[ip]:
                        ip_to_hosts[ip].append(host)
                    if ip not in host_to_ips[host]:
                        host_to_ips[host].append(ip)

        # From direct IP findings
        for ip in result.ip_addresses:
            if ip not in ip_to_hosts[ip]:
                ip_to_hosts[ip]  # ensure key exists
            if result.target not in ip_to_hosts[ip]:
                ip_to_hosts[ip].append(result.target)
            if ip not in host_to_ips[result.target]:
                host_to_ips[result.target].append(ip)

        # Subdomains → attempt reverse-map via TLS SAN
        if result.tls_info and result.tls_info.san_domains:
            for san in result.tls_info.san_domains:
                san = san.lstrip("*.")
                for ip, hosts in list(ip_to_hosts.items()):
                    if result.target in hosts and san not in hosts:
                        hosts.append(san)
                    if san not in host_to_ips:
                        host_to_ips[san] = list(ip_to_hosts.keys())[:1]

        report.ip_to_hosts = dict(ip_to_hosts)
        report.host_to_ips = dict(host_to_ips)

        # Create edges
        for ip, hosts in ip_to_hosts.items():
            for host in hosts:
                report.edges.append(CorrelationEdge(
                    source     = host,
                    target     = ip,
                    edge_type  = "ip_hostname",
                    confidence = 0.95,
                    evidence   = ["dns_record"],
                ))

    # ── Pass 2: Service ↔ Technology ──────────────────────────────────────────

    def _correlate_service_tech(
        self, result: ReconResult, report: CorrelationReport
    ) -> None:
        """Link open ports to detected technologies via banner matching."""
        tech_to_ports: dict[str, list[int]] = defaultdict(list)

        for port in result.ports:
            if port.state != "open":
                continue

            app = _PORT_APP_MAP.get(port.number, port.service or "unknown")
            tech_from_banner = _tech_from_banner(
                " ".join([port.banner, port.service, port.version]).lower()
            )

            for tech in tech_from_banner:
                tech_to_ports[tech].append(port.number)
                report.edges.append(CorrelationEdge(
                    source     = str(port.number),
                    target     = tech,
                    edge_type  = "service_tech",
                    confidence = 0.80,
                    evidence   = [f"banner: {port.banner[:60]}"],
                ))

            # Also correlate declared technologies
            for tech_obj in result.technologies:
                if tech_obj.name.lower() in (port.service or "").lower():
                    tech_to_ports[tech_obj.name].append(port.number)
                    report.edges.append(CorrelationEdge(
                        source     = str(port.number),
                        target     = tech_obj.name,
                        edge_type  = "service_tech",
                        confidence = 0.90,
                        evidence   = ["service_field"],
                    ))

        report.tech_to_ports = dict(tech_to_ports)

    # ── Pass 3: Port → Application ────────────────────────────────────────────

    def _correlate_port_app(
        self, result: ReconResult, report: CorrelationReport
    ) -> None:
        """Map each open port number to its canonical application name."""
        for port in result.ports:
            if port.state == "open":
                app = (
                    port.service
                    or _PORT_APP_MAP.get(port.number)
                    or "unknown"
                )
                report.port_to_app[port.number] = app

    # ── Pass 4: CDN Detection ─────────────────────────────────────────────────

    def _detect_cdn(
        self, result: ReconResult, report: CorrelationReport
    ) -> None:
        """Identify CDN/WAF presence from server banners, headers, and technologies."""
        detected: set[str] = set()

        # From technologies already identified
        tech_names_lower = {t.name.lower() for t in result.technologies}
        for cdn, sigs in _CDN_SIGNATURES.items():
            for sig in sigs:
                if sig in tech_names_lower:
                    detected.add(cdn)
                    break

        # From port banners
        all_banners = " ".join(
            " ".join([p.banner, p.service, p.version]).lower()
            for p in result.ports
        )
        for cdn, sigs in _CDN_SIGNATURES.items():
            if any(sig in all_banners for sig in sigs):
                detected.add(cdn)

        report.cdn_detected = sorted(detected)

        for cdn in detected:
            report.edges.append(CorrelationEdge(
                source     = result.target,
                target     = cdn,
                edge_type  = "cdn_shielded",
                confidence = 0.85,
                evidence   = ["banner_or_header"],
            ))

    # ── Pass 5: ASN Infrastructure Grouping ───────────────────────────────────

    def _correlate_asn(
        self, result: ReconResult, report: CorrelationReport
    ) -> None:
        """Group IPs under their ASN when WHOIS data is available."""
        asn = result.whois.get("asn") or result.whois.get("org", "")
        if not asn:
            return

        node = InfraNode(
            label     = str(asn),
            node_type = "asn",
            tags      = ["infrastructure"],
            metadata  = {"org": result.whois.get("org", "")},
        )
        for ip in result.ip_addresses[:20]:
            node.add_child(InfraNode(label=ip, node_type="ip", tags=["ip"]))

        report.nodes.append(node)
        for ip in result.ip_addresses[:20]:
            report.edges.append(CorrelationEdge(
                source    = str(asn),
                target    = ip,
                edge_type = "asn_infra",
                confidence = 0.90,
                evidence  = ["whois"],
            ))

    # ── Pass 6: Build Host Tree ───────────────────────────────────────────────

    def _build_host_tree(
        self, result: ReconResult, report: CorrelationReport
    ) -> None:
        """
        Build root host node with hierarchical children:
          host → IP → service → technology
        """
        root = InfraNode(
            label     = result.target,
            node_type = "host",
            tags      = ["root", "target"],
            confidence = 1.0,
        )

        # IP children
        for ip in result.ip_addresses[:10]:
            ip_node = InfraNode(
                label     = ip,
                node_type = "ip",
                tags      = ["ip"],
            )
            # CDN under each IP
            for cdn in report.cdn_detected:
                ip_node.add_child(InfraNode(
                    label     = cdn,
                    node_type = "cdn",
                    tags      = ["CDN"],
                ))

            # Services / ports under each IP
            for port in result.ports:
                if port.state != "open":
                    continue
                app = report.port_to_app.get(port.number, port.service or "?")
                svc_node = InfraNode(
                    label     = f":{port.number} {app}",
                    node_type = "service",
                    tags      = _port_risk_tags(port.number),
                    metadata  = {
                        "port":    port.number,
                        "proto":   port.protocol,
                        "version": port.version,
                        "banner":  port.banner[:80],
                    },
                    risk_hint = _port_risk_hint(port.number),
                )
                # Tech children under service
                for tech in _tech_from_banner(
                    " ".join([port.banner, port.service, port.version]).lower()
                ):
                    svc_node.add_child(InfraNode(
                        label     = tech,
                        node_type = "technology",
                        tags      = ["technology"],
                        confidence = 0.80,
                    ))
                ip_node.add_child(svc_node)

            root.add_child(ip_node)

        report.nodes.insert(0, root)


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _is_ip(value: str) -> bool:
    return bool(re.match(
        r"^(\d{1,3}\.){3}\d{1,3}$|^[0-9a-fA-F:]{3,39}$", value
    ))


def _tech_from_banner(banner_lower: str) -> list[str]:
    return [
        tech for sig, tech in _BANNER_TECH
        if sig in banner_lower
    ]


def _port_risk_hint(port: int) -> str:
    critical = {23, 445, 3389, 2375, 2376, 6379, 27017, 9200, 11211}
    high     = {21, 3306, 5432, 1433, 4848, 7001, 50070}
    medium   = {80, 8080, 8888, 9000, 5601, 9090, 15672}
    if port in critical: return "CRITICAL"
    if port in high:     return "HIGH"
    if port in medium:   return "MEDIUM"
    return ""


def _port_risk_tags(port: int) -> list[str]:
    tag_map: dict[int, str] = {
        22: "SSH", 23: "TELNET", 25: "MAIL", 53: "DNS",
        80: "HTTP", 443: "HTTPS", 445: "SMB",
        3389: "RDP", 21: "FTP", 6379: "REDIS",
        27017: "MONGODB", 9200: "ELASTICSEARCH",
        2375: "DOCKER", 6443: "K8S",
    }
    tag = tag_map.get(port)
    return [tag] if tag else []
