"""
ReconX — Sensitive data / exposure detector.
Pattern-based rule engine; never generates attack payloads.
"""
from __future__ import annotations
import re
import logging

from ..models.findings import ReconResult, SensitiveFinding
from ..config.settings import SENSITIVE_PATTERNS

logger = logging.getLogger("reconx.analysis.sensitive")


class SensitiveDetector:
    """Scans collected endpoints and data for sensitive exposures."""

    def __init__(self):
        self._compiled = [
            {**rule, "_re": re.compile(rule["pattern"], re.IGNORECASE)}
            for rule in SENSITIVE_PATTERNS
        ]

    def detect(self, result: ReconResult) -> list[SensitiveFinding]:
        findings: list[SensitiveFinding] = []

        # Check all web endpoints against URL patterns
        for endpoint in result.web_endpoints:
            for rule in self._compiled:
                if rule["_re"].search(endpoint):
                    findings.append(SensitiveFinding(
                        category=rule["category"],
                        detail=rule["detail"],
                        url=endpoint,
                        severity=rule["severity"],
                    ))

        # Check for common risky ports
        risky_ports = {3306, 6379, 27017, 9200, 5432, 1433, 11211}
        for port in result.ports:
            if port.number in risky_ports:
                findings.append(SensitiveFinding(
                    category="exposed_service",
                    detail=f"Database/cache service on port {port.number} ({port.service or 'unknown'}) may be internet-facing.",
                    severity="HIGH",
                ))

        # Email addresses in WHOIS — flag for spam-list / phishing risk
        for email in result.emails:
            findings.append(SensitiveFinding(
                category="email_exposure",
                detail=f"Email address exposed in WHOIS/DNS: {email}",
                severity="LOW",
            ))

        return findings
