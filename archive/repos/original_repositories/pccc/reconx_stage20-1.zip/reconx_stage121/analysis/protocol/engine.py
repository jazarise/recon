"""
ReconX — Stage 20: Service Intelligence Engine

Top-level orchestrator for the Stage 20 pipeline:

  Scanner Output (any tool)
    ↓ ScanParser
  ServiceRecord list (raw)
    ↓ ProtocolDetectionEngine
  ServiceRecord list (classified + fingerprinted)
    ↓ ServiceAnalyzer
  ServiceIntelligenceReport
    ↓ ReconResult integration
  Enriched findings + risk scores

Entry points:
  engine = ServiceIntelligenceEngine()

  # From raw scanner text
  report = engine.analyze_output(raw_text, tool_name="nmap", host="10.0.0.1")

  # From existing ServiceRecord list
  report = engine.analyze_records(records, target="10.0.0.1")

  # Deduplication guard — prevent re-scanning the same host
  engine.mark_scanned(host)
  if engine.already_scanned(host): ...
"""
from __future__ import annotations

import logging
import time
from typing import Optional

from .models import ServiceRecord, ServiceIntelligenceReport
from .parsers import parse_scan_output, ScanParseResult
from .detection_engine import ProtocolDetectionEngine
from .service_analyzer import ServiceAnalyzer

log = logging.getLogger("reconx.analysis.protocol.engine")


class ServiceIntelligenceEngine:
    """
    Stage 20 main pipeline orchestrator.

    Stateless after construction — thread-safe for concurrent target analysis.
    Maintains a small in-memory dedup registry to prevent infinite re-analysis loops.
    """

    def __init__(
        self,
        use_ai:    bool = True,
        ai_timeout: int = 30,
    ):
        self._detector  = ProtocolDetectionEngine()
        self._analyzer  = ServiceAnalyzer(use_ai=use_ai, ai_timeout=ai_timeout)
        self._scanned:  set[str] = set()
        self._cache:    dict[str, ServiceIntelligenceReport] = {}

    # ══════════════════════════════════════════════════════════════════════════
    # Primary entry points
    # ══════════════════════════════════════════════════════════════════════════

    def analyze_output(
        self,
        raw:       str,
        tool_name: str = "generic",
        host:      str = "",
        target:    str = "",
    ) -> ServiceIntelligenceReport:
        """
        Full pipeline from raw scanner text to ServiceIntelligenceReport.

        Args:
            raw:       Raw text output from scanner.
            tool_name: "nmap" | "rustscan" | "naabu" | "masscan" | "httpx"
            host:      Scanner target IP (used when omitted in output).
            target:    Display name for the report (defaults to host).
        """
        target = target or host

        # Step 1: parse
        parse_result = parse_scan_output(raw, tool_name, host)
        if parse_result.parse_errors:
            log.warning("[ServiceIntelligenceEngine] Parse warnings: %s",
                        parse_result.parse_errors)

        # Steps 2–3: classify + analyze
        return self.analyze_records(
            parse_result.services,
            target=target,
            parse_result=parse_result,
        )

    def analyze_records(
        self,
        records:      list[ServiceRecord],
        target:       str = "",
        parse_result: Optional[ScanParseResult] = None,
    ) -> ServiceIntelligenceReport:
        """
        Classify and analyze a pre-built ServiceRecord list.
        Deduplicates records by (host, port, protocol) before analysis.
        """
        if not records:
            return ServiceIntelligenceReport(
                target=target,
                timestamp=time.time(),
            )

        # Deduplication
        records = self._dedup(records)

        # Protocol detection
        records = self._detector.classify_all(records)

        # Service analysis
        report = self._analyzer.analyze_all(records, target=target)

        # Cache by target
        if target:
            self._cache[target] = report
            self._scanned.add(target)

        return report

    # ══════════════════════════════════════════════════════════════════════════
    # Dedup guard (prevents infinite loops / excessive retries)
    # ══════════════════════════════════════════════════════════════════════════

    def already_scanned(self, target: str) -> bool:
        return target in self._scanned

    def mark_scanned(self, target: str) -> None:
        self._scanned.add(target)

    def clear_cache(self, target: Optional[str] = None) -> None:
        if target:
            self._scanned.discard(target)
            self._cache.pop(target, None)
        else:
            self._scanned.clear()
            self._cache.clear()

    def get_cached(self, target: str) -> Optional[ServiceIntelligenceReport]:
        return self._cache.get(target)

    # ══════════════════════════════════════════════════════════════════════════
    # ReconResult integration
    # ══════════════════════════════════════════════════════════════════════════

    def enrich_recon_result(self, recon_result, report: ServiceIntelligenceReport):
        """
        Attach Stage 20 intelligence to an existing ReconResult object.
        Non-destructive — adds findings without modifying existing fields.
        """
        try:
            from ...models.tool_result import ParsedFinding

            # Services → findings
            for svc in report.services:
                recon_result.findings.append(ParsedFinding(
                    finding_type="service",
                    value=f"{svc.protocol_name} {svc.service_version}".strip(),
                    source="ServiceIntelligenceEngine",
                    confidence=svc.classification.confidence if svc.classification else 0.7,
                    metadata={
                        "host":     svc.host,
                        "port":     svc.port,
                        "risk":     svc.risk_level.value,
                        "family":   svc.classification.family.value if svc.classification else "",
                    },
                ))

            # High-risk service alerts
            for svc in report.high_risk_services:
                if hasattr(recon_result, "sensitive_findings"):
                    from ...models.findings import SensitiveFinding
                    recon_result.sensitive_findings.append(SensitiveFinding(
                        category="high_risk_service",
                        detail=(
                            f"{svc.protocol_name} on {svc.address} — "
                            f"risk score {svc.ai_analysis.risk_score:.1f}/10"
                            if svc.ai_analysis else f"{svc.protocol_name} high-risk"
                        ),
                        url=svc.address,
                        severity=svc.risk_level.value.upper(),
                    ))
        except Exception as exc:
            log.debug("[ServiceIntelligenceEngine] enrich_recon_result: %s", exc)

    # ══════════════════════════════════════════════════════════════════════════
    # Logging
    # ══════════════════════════════════════════════════════════════════════════

    def get_log_entries(self, report: ServiceIntelligenceReport) -> list[dict]:
        """
        Return structured log entries for the report.
        timestamp / tool / host / service / version / risk / ai_notes
        """
        entries = []
        for svc in report.services:
            entry = {
                "timestamp": svc.scan_timestamp,
                "tool":      svc.source_tool,
                "host":      svc.host,
                "port":      svc.port,
                "service":   svc.protocol_name,
                "version":   svc.service_version,
                "risk":      svc.risk_level.value,
                "family":    svc.classification.family.value if svc.classification else "unknown",
                "ai_notes":  svc.ai_analysis.beginner_summary[:120] if svc.ai_analysis else "",
            }
            entries.append(entry)
        return entries

    # ══════════════════════════════════════════════════════════════════════════
    # Internal helpers
    # ══════════════════════════════════════════════════════════════════════════

    @staticmethod
    def _dedup(records: list[ServiceRecord]) -> list[ServiceRecord]:
        """Remove duplicate (host, port, protocol) entries."""
        seen: set[tuple] = set()
        unique: list[ServiceRecord] = []
        for r in records:
            key = (r.host, r.port, r.protocol)
            if key not in seen:
                seen.add(key)
                unique.append(r)
        return unique
