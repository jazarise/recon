"""
ReconX — Stage 20: Service Analyzer

Produces ServiceAnalysis for each classified ServiceRecord using:

  1. Static rule engine  — risk signals, misconfig patterns, CVE references
                           (always runs, zero latency, no AI dependency)
  2. AI explanation layer — beginner + technical summaries via the existing
                            ReconX AI controller (optional, graceful fallback)

The static engine covers:
  - Cleartext protocol detection
  - Unauthenticated service signals
  - Non-default port usage
  - Known-risky version patterns
  - TLS weakness flags

The AI layer enriches with natural language explanations and prioritised
enumeration paths. If the AI controller is unavailable it degrades silently
to static-only analysis.
"""
from __future__ import annotations

import logging
import time
from typing import Optional

from .models import (
    ServiceRecord, ServiceAnalysis, ServiceRisk, ServiceIntelligenceReport,
    EnumerationPath, RiskSignal, ProtocolFamily, ProtocolClassification,
)
from .knowledge_base import lookup_service, lookup_port

log = logging.getLogger("reconx.analysis.protocol.analyzer")

# ── Risk scoring weights ──────────────────────────────────────────────────────
# (signal_type, base_score_contribution)
_RISK_WEIGHTS: dict[str, float] = {
    "cleartext_protocol":   2.5,
    "no_auth_known":        4.0,
    "default_creds_risk":   3.0,
    "non_default_port":     1.0,
    "legacy_tls":           2.0,
    "expired_cert":         1.5,
    "database_exposed":     3.5,
    "critical_service":     3.0,
    "cloud_api_exposed":    3.5,
    "risky_version":        2.0,
    "internet_facing_rdp":  3.0,
    "smb_internet":         4.0,
}

# Services that are critical by definition when internet-exposed
_ALWAYS_HIGH_RISK = {
    "Redis", "MongoDB", "Elasticsearch", "Memcached", "CouchDB",
    "Docker", "Kubelet", "etcd", "ZooKeeper", "InfluxDB",
}

_CLEARTEXT_PROTOCOLS = {
    "FTP", "Telnet", "SMTP", "POP3", "IMAP", "LDAP", "SNMP",
    "HTTP", "Redis", "Memcached", "MySQL", "PostgreSQL", "MSSQL",
    "MongoDB", "Kafka",
}


class ServiceAnalyzer:
    """
    Produces ServiceAnalysis objects from classified ServiceRecords.

    Usage:
        analyzer = ServiceAnalyzer()
        analysis = analyzer.analyze(service_record)

        # Or batch:
        report = analyzer.analyze_all(services, target="example.com")
    """

    def __init__(self, use_ai: bool = True, ai_timeout: int = 30):
        self._use_ai    = use_ai
        self._ai_timeout = ai_timeout

    # ══════════════════════════════════════════════════════════════════════════
    # Public API
    # ══════════════════════════════════════════════════════════════════════════

    def analyze(self, record: ServiceRecord) -> ServiceAnalysis:
        """
        Produce a ServiceAnalysis for one ServiceRecord.
        Static rules always run; AI enrichment is attempted if enabled.
        """
        analysis = self._static_analysis(record)

        if self._use_ai:
            try:
                enriched = self._ai_enrich(record, analysis)
                if enriched:
                    analysis = enriched
            except Exception as exc:
                log.debug("[ServiceAnalyzer] AI enrichment skipped: %s", exc)

        record.ai_analysis = analysis
        return analysis

    def analyze_all(
        self,
        records:   list[ServiceRecord],
        target:    str = "",
    ) -> ServiceIntelligenceReport:
        """
        Analyze all services and produce a ServiceIntelligenceReport.
        """
        report = ServiceIntelligenceReport(
            target=target,
            timestamp=time.time(),
            services=records,
        )

        analyses: list[ServiceAnalysis] = []
        for record in records:
            try:
                analysis = self.analyze(record)
                analyses.append(analysis)
            except Exception as exc:
                log.warning("[ServiceAnalyzer] Error analyzing %s: %s", record.address, exc)

        report.analyses = analyses
        report.compute_counts()
        report.unusual_services = self._find_unusual(records)
        report.executive_summary = self._executive_summary(report)
        report.suggested_actions = self._suggested_actions(report)

        log.info(
            "[ServiceAnalyzer] %s — %d services: %d critical, %d high",
            target, len(records), report.critical_count, report.high_count,
        )
        return report

    # ══════════════════════════════════════════════════════════════════════════
    # Static rule engine
    # ══════════════════════════════════════════════════════════════════════════

    def _static_analysis(self, record: ServiceRecord) -> ServiceAnalysis:
        """
        Build ServiceAnalysis using only the knowledge base and rule engine.
        Zero external dependencies — always works.
        """
        proto_name = record.protocol_name
        kb_entry   = lookup_service(proto_name)
        port_entry = lookup_port(record.port)

        analysis = ServiceAnalysis(
            service_address=record.address,
            protocol_name=proto_name,
            generated_by="static_rules",
        )

        # ── Risk signals ──────────────────────────────────────────────────────
        signals = list(record.risk_signals)   # start with pre-detected signals

        # Cleartext protocol
        if proto_name in _CLEARTEXT_PROTOCOLS:
            signals.append(RiskSignal(
                signal_type="cleartext_protocol",
                description=f"{proto_name} transmits data without encryption",
                severity=ServiceRisk.HIGH,
                evidence=f"Protocol {proto_name} uses cleartext transport",
            ))

        # Critical service exposed
        if proto_name in _ALWAYS_HIGH_RISK:
            signals.append(RiskSignal(
                signal_type="no_auth_known",
                description=f"{proto_name} is commonly misconfigured without authentication",
                severity=ServiceRisk.CRITICAL,
                evidence=f"Service type {proto_name} on port {record.port}",
            ))

        # Non-default port (may be evasion or misconfiguration)
        if (record.classification and not record.classification.is_default_port
                and record.classification.family != ProtocolFamily.WEB):
            signals.append(RiskSignal(
                signal_type="non_default_port",
                description=f"{proto_name} running on non-standard port {record.port}",
                severity=ServiceRisk.LOW,
                evidence=f"Expected default port differs from {record.port}",
            ))

        # TLS issues
        if record.tls_enabled:
            if record.tls_cert_expired:
                signals.append(RiskSignal(
                    signal_type="expired_cert",
                    description="TLS certificate is expired",
                    severity=ServiceRisk.MEDIUM,
                    evidence=f"Certificate CN: {record.tls_cert_cn}",
                ))
            if record.tls_version and record.tls_version in ("TLSv1.0", "TLSv1.1", "SSLv3"):
                signals.append(RiskSignal(
                    signal_type="legacy_tls",
                    description=f"Legacy TLS version in use: {record.tls_version}",
                    severity=ServiceRisk.HIGH,
                    evidence=record.tls_version,
                ))

        # Database family
        if (record.classification and
                record.classification.family == ProtocolFamily.DATABASE):
            signals.append(RiskSignal(
                signal_type="database_exposed",
                description=f"Database service {proto_name} directly reachable",
                severity=ServiceRisk.CRITICAL,
                evidence=f"Port {record.port} database protocol",
            ))

        # Cloud API
        if (record.classification and
                record.classification.family == ProtocolFamily.CLOUD):
            signals.append(RiskSignal(
                signal_type="cloud_api_exposed",
                description=f"Cloud/container API {proto_name} exposed",
                severity=ServiceRisk.HIGH,
                evidence=f"Container/orchestration service on port {record.port}",
            ))

        record.risk_signals = signals

        # ── Risk score ────────────────────────────────────────────────────────
        base_score = 0.0
        for sig in signals:
            base_score += _RISK_WEIGHTS.get(sig.signal_type, 1.0)
        if kb_entry and kb_entry.risk_baseline in (ServiceRisk.CRITICAL, ServiceRisk.HIGH):
            base_score += 3.0

        risk_score = min(10.0, base_score)
        if risk_score >= 8.0:
            risk_level = ServiceRisk.CRITICAL
        elif risk_score >= 6.0:
            risk_level = ServiceRisk.HIGH
        elif risk_score >= 3.5:
            risk_level = ServiceRisk.MEDIUM
        elif risk_score >= 1.0:
            risk_level = ServiceRisk.LOW
        else:
            risk_level = ServiceRisk.INFO

        analysis.risk_score   = round(risk_score, 1)
        analysis.risk_level   = risk_level
        analysis.risk_rationale = self._risk_rationale(signals, risk_score)

        # ── KB-backed intelligence ─────────────────────────────────────────────
        if kb_entry:
            analysis.attack_vectors    = list(kb_entry.attack_vectors)
            analysis.misconfig_patterns = list(kb_entry.misconfig_patterns)
            analysis.interesting_flags  = list(kb_entry.interesting_flags)
            analysis.beginner_summary   = kb_entry.beginner_explain or kb_entry.description
            analysis.technical_summary  = self._build_technical(record, kb_entry)

            # Enumeration paths from KB
            for cmd_info in kb_entry.enum_commands[:4]:
                host = record.host
                port = str(record.port)
                cmd  = cmd_info["cmd"].replace("{host}", host).replace("{port}", port)
                analysis.enumeration_paths.append(EnumerationPath(
                    tool=cmd_info["tool"],
                    command=cmd,
                    purpose=cmd_info.get("purpose", ""),
                    priority=1 if risk_level in (ServiceRisk.CRITICAL, ServiceRisk.HIGH) else 3,
                ))
        else:
            analysis.beginner_summary  = f"Service identified as {proto_name} on port {record.port}."
            analysis.technical_summary = (
                f"{proto_name} on {record.address}. "
                f"Version: {record.service_version or 'unknown'}."
            )

        return analysis

    # ══════════════════════════════════════════════════════════════════════════
    # AI enrichment layer
    # ══════════════════════════════════════════════════════════════════════════

    def _ai_enrich(
        self,
        record:   ServiceRecord,
        analysis: ServiceAnalysis,
    ) -> Optional[ServiceAnalysis]:
        """
        Attempt to enrich analysis via the existing ReconX AI controller.
        Returns None if AI is unavailable — caller falls back to static analysis.
        """
        try:
            from ...ai.explanation_engine import ExplanationEngine
            engine = ExplanationEngine()
        except ImportError:
            return None

        prompt = self._build_ai_prompt(record, analysis)
        try:
            response = engine.explain(prompt, timeout=self._ai_timeout)
            if not response:
                return None

            # Parse structured response if available
            if isinstance(response, dict):
                if response.get("beginner"):
                    analysis.beginner_summary  = response["beginner"]
                if response.get("technical"):
                    analysis.technical_summary = response["technical"]
                if response.get("next_steps"):
                    for step in response["next_steps"][:3]:
                        analysis.enumeration_paths.append(EnumerationPath(
                            tool=step.get("tool", ""),
                            command=step.get("cmd", ""),
                            purpose=step.get("why", ""),
                        ))
            elif isinstance(response, str) and len(response) > 20:
                # Plain text response — use as technical summary enrichment
                analysis.technical_summary = response[:1000]

            analysis.generated_by = "ai_model"
            return analysis
        except Exception as exc:
            log.debug("[ServiceAnalyzer] AI call failed: %s", exc)
            return None

    def _build_ai_prompt(self, record: ServiceRecord, analysis: ServiceAnalysis) -> str:
        return f"""
You are a cybersecurity analyst performing passive reconnaissance.

Service discovered:
  Host: {record.host}
  Port: {record.port}/{record.protocol}
  Service: {record.protocol_name}
  Version: {record.service_version or 'unknown'}
  Banner: {record.banner[:200] if record.banner else 'none'}
  Risk Score: {analysis.risk_score}/10 ({analysis.risk_level.value})

Provide a structured analysis:
1. Beginner-friendly explanation (2-3 sentences, non-technical)
2. Technical summary (for security professionals)
3. Top 3 recommended next enumeration steps (tool + command + purpose)

Focus on reconnaissance and education only. No exploit code.
""".strip()

    # ══════════════════════════════════════════════════════════════════════════
    # Report-level summaries
    # ══════════════════════════════════════════════════════════════════════════

    def _find_unusual(self, records: list[ServiceRecord]) -> list[ServiceRecord]:
        """Flag services on unexpected ports (possible evasion or misconfiguration)."""
        unusual = []
        for r in records:
            entry = lookup_port(r.port)
            if not entry and r.service_name:
                unusual.append(r)
            elif (entry and r.classification and
                  entry.name.lower() != r.classification.protocol.lower() and
                  r.classification.confidence > 0.80):
                unusual.append(r)
        return unusual

    def _executive_summary(self, report: ServiceIntelligenceReport) -> str:
        lines = [
            f"Discovered {report.total_services} services on {report.target}.",
        ]
        if report.critical_count:
            lines.append(f"{report.critical_count} CRITICAL risk service(s) require immediate attention.")
        if report.high_count:
            lines.append(f"{report.high_count} HIGH risk service(s) identified.")
        if report.database_services:
            names = ", ".join(r.protocol_name for r in report.database_services[:3])
            lines.append(f"Database services directly reachable: {names}.")
        if report.cloud_services:
            names = ", ".join(r.protocol_name for r in report.cloud_services[:3])
            lines.append(f"Cloud/container APIs exposed: {names}.")
        if not report.critical_count and not report.high_count:
            lines.append("No critical or high-risk services found.")
        return " ".join(lines)

    def _suggested_actions(self, report: ServiceIntelligenceReport) -> list[str]:
        actions = []
        if report.critical_count:
            actions.append("Immediately investigate CRITICAL risk services — potential unauthenticated access")
        if report.database_services:
            actions.append("Run database-specific enumeration tools against exposed database services")
        if report.cloud_services:
            actions.append("Audit cloud/container API authentication and RBAC configuration")
        if any(r.tls_cert_expired for r in report.services):
            actions.append("Renew expired TLS certificates")
        if report.high_risk_services:
            tools = list({s.protocol_name for s in report.high_risk_services})[:3]
            actions.append(f"Enumerate high-risk services: {', '.join(tools)}")
        if not actions:
            actions.append("Review service inventory and confirm all services are intended")
        return actions

    @staticmethod
    def _risk_rationale(signals: list[RiskSignal], score: float) -> str:
        if not signals:
            return "No specific risk signals detected."
        top = sorted(signals, key=lambda s: list(ServiceRisk).index(s.severity))
        reasons = [s.description for s in top[:3]]
        return "; ".join(reasons) + f" (composite score: {score:.1f}/10)"

    @staticmethod
    def _build_technical(record: ServiceRecord, kb) -> str:
        parts = [f"{record.protocol_name} on {record.address}."]
        if record.service_version:
            parts.append(f"Version: {record.service_version}.")
        if kb.description:
            parts.append(kb.description)
        if kb.cve_patterns:
            parts.append(f"Known CVE patterns: {', '.join(kb.cve_patterns[:3])}.")
        return " ".join(parts)
