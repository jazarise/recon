"""
ReconX — Stage 20: Service Intelligence Report Injector

Injects a "Service Intelligence" HTML section into existing ReconX reports,
or creates a standalone HTML report if the target file doesn't exist.

Sections:
  1. Summary bar — target, total, critical/high counts
  2. Stats row — 7 metric cards
  3. Services table — per-service risk, protocol, version, score
  4. Risk signals table — all flagged misconfigurations
  5. AI Analysis cards — top high-risk service breakdowns
  6. Enumeration paths table — suggested next steps
"""
from __future__ import annotations

from html import escape
from pathlib import Path
from typing import Optional

# ── CSS ───────────────────────────────────────────────────────────────────────
_SVC_CSS = """
/* ── Stage 20 Service Intelligence ── */
.svc-section { margin-top:32px; }
.svc-bar {
  display:flex; gap:12px; flex-wrap:wrap; align-items:center;
  margin-bottom:18px;
  background:var(--bg2,#0c1420); border:1px solid var(--border,#1a3050);
  border-left:3px solid #ff2d55; border-radius:6px; padding:12px 20px;
  font-family:var(--font-mono,monospace); font-size:12px;
}
.svc-bar .lbl { color:var(--dim,#5a7a9a); }
.svc-bar .val { color:#c8d8e8; font-weight:600; margin-left:4px; }
.svc-stats {
  display:grid; grid-template-columns:repeat(auto-fit,minmax(100px,1fr));
  gap:10px; margin-bottom:20px;
}
.svc-stat {
  background:var(--bg2,#0c1420); border:1px solid var(--border,#1a3050);
  border-radius:6px; padding:12px 8px; text-align:center;
}
.svc-stat .n { font-size:24px; font-weight:700; font-family:var(--font-mono,monospace); line-height:1; margin-bottom:4px; }
.svc-stat .lbl { font-size:10px; letter-spacing:2px; text-transform:uppercase; color:var(--dim,#5a7a9a); }
.svc-tbl-wrap { margin-bottom:22px; }
.svc-tbl-title { font-size:13px; font-weight:600; letter-spacing:2px; text-transform:uppercase; color:#ff2d55; border-bottom:1px solid var(--border,#1a3050); padding-bottom:8px; margin-bottom:10px; }
.svc-tbl { width:100%; border-collapse:collapse; font-size:12px; }
.svc-tbl th { font-size:10px; letter-spacing:1.5px; text-transform:uppercase; color:var(--dim,#5a7a9a); text-align:left; padding:6px 10px; border-bottom:1px solid var(--border,#1a3050); }
.svc-tbl td { padding:8px 10px; border-bottom:1px solid rgba(26,48,80,0.4); font-family:var(--font-mono,monospace); vertical-align:top; }
.svc-tbl tr:last-child td { border-bottom:none; }
.svc-tbl tr:hover td { background:rgba(255,45,85,0.03); }
.risk-crit { background:rgba(255,45,85,0.2); color:#ff2d55; padding:2px 6px; border-radius:3px; font-size:10px; font-weight:700; }
.risk-high { background:rgba(255,107,53,0.2); color:#ff6b35; padding:2px 6px; border-radius:3px; font-size:10px; font-weight:700; }
.risk-med  { background:rgba(255,214,10,0.15); color:#ffd60a; padding:2px 6px; border-radius:3px; font-size:10px; font-weight:700; }
.risk-low  { background:rgba(48,209,88,0.15); color:#30d158; padding:2px 6px; border-radius:3px; font-size:10px; font-weight:700; }
.risk-info { color:#5a7a9a; font-size:10px; }
.score-bar { display:inline-block; height:5px; border-radius:2px; background:#ff2d55; vertical-align:middle; margin-right:4px; }
.svc-ai-card {
  background:var(--bg2,#0c1420); border:1px solid #ff2d55;
  border-left:3px solid #ff2d55; border-radius:6px;
  padding:14px 18px; margin-bottom:14px;
}
.svc-ai-card .proto { color:#ff2d55; font-weight:700; font-size:14px; }
.svc-ai-card .addr  { color:#5a7a9a; font-size:11px; margin-left:8px; }
.svc-ai-card .beginner { color:#c8d8e8; font-size:12px; margin:8px 0; }
.svc-ai-card .vectors  { color:#5a7a9a; font-size:11px; }
.svc-empty { text-align:center; color:var(--dim,#5a7a9a); font-style:italic; padding:14px; }
"""

_STANDALONE_HTML = """<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>ReconX — Service Intelligence Report</title>
<style>
*,*::before,*::after{{box-sizing:border-box;margin:0;padding:0}}
:root{{--bg:#060a0f;--bg2:#0c1420;--bg3:#111c2d;--border:#1a3050;--text:#c8d8e8;--dim:#5a7a9a;--font-mono:'Share Tech Mono',monospace;--font-ui:'Chakra Petch',monospace}}
body{{background:var(--bg);color:var(--text);font-family:var(--font-ui,monospace);font-size:14px;min-height:100vh;padding:40px 24px}}
.container{{max-width:1100px;margin:0 auto}}
.section{{background:var(--bg2);border:1px solid var(--border);border-radius:10px;padding:28px;margin-bottom:28px}}
.section-title{{font-size:16px;font-weight:600;letter-spacing:2px;text-transform:uppercase;color:#ff2d55;margin-bottom:20px;border-bottom:1px solid var(--border);padding-bottom:12px}}
{css}
</style></head>
<body><div class="container">
<div class="section">
<div class="section-title">ReconX — Service Intelligence Report</div>
{body}
</div>
</div></body></html>"""


# ── Helpers ────────────────────────────────────────────────────────────────────

def _risk_badge(risk: str) -> str:
    cls = {"critical": "risk-crit", "high": "risk-high",
           "medium": "risk-med", "low": "risk-low"}.get(risk.lower(), "risk-info")
    return f'<span class="{cls}">{escape(risk.upper())}</span>'


def _score_bar_html(score) -> str:
    try:
        s = float(score)
    except (TypeError, ValueError):
        s = 0.0
    w = int(s * 12)
    return f'<span class="score-bar" style="width:{w}px"></span>{s:.1f}'


def _stat(n, label: str, colour: str) -> str:
    return (f'<div class="svc-stat">'
            f'<div class="n" style="color:{colour}">{escape(str(n))}</div>'
            f'<div class="lbl">{escape(label)}</div></div>')


# ══════════════════════════════════════════════════════════════════════════════
# Section builders
# ══════════════════════════════════════════════════════════════════════════════

def _build_summary_bar(data: dict) -> str:
    target = escape(data.get("target", "—"))
    total  = data.get("total", 0)
    crit   = data.get("critical", 0)
    high   = data.get("high", 0)
    med    = data.get("medium", 0)
    return f"""
<div class="svc-bar">
  <span class="lbl">Target:</span><span class="val">{target}</span>
  &nbsp;|&nbsp;
  <span class="lbl">Services:</span><span class="val" style="color:#00d4ff">{total}</span>
  &nbsp;|&nbsp;
  <span class="lbl">Critical:</span><span class="val" style="color:#ff2d55">{crit}</span>
  &nbsp;|&nbsp;
  <span class="lbl">High:</span><span class="val" style="color:#ff6b35">{high}</span>
  &nbsp;|&nbsp;
  <span class="lbl">Medium:</span><span class="val" style="color:#ffd60a">{med}</span>
</div>"""


def _build_stats_row(data: dict) -> str:
    services = data.get("services", [])
    db_count = sum(1 for s in services if s.get("family") == "database")
    cl_count = sum(1 for s in services if s.get("family") == "cloud")
    return (
        '<div class="svc-stats">'
        + _stat(data.get("total", 0),    "Services",  "#00d4ff")
        + _stat(data.get("critical", 0), "Critical",  "#ff2d55")
        + _stat(data.get("high", 0),     "High",      "#ff6b35")
        + _stat(data.get("medium", 0),   "Medium",    "#ffd60a")
        + _stat(data.get("low", 0),      "Low",       "#30d158")
        + _stat(db_count,                "Databases", "#9b59b6")
        + _stat(cl_count,                "Cloud APIs", "#00ffcc")
        + '</div>'
    )


def _build_services_table(data: dict) -> str:
    services = sorted(
        data.get("services", []),
        key=lambda s: {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}.get(
            s.get("risk_level", "info"), 5
        )
    )

    if services:
        rows = "".join(
            f'<tr>'
            f'<td>{_risk_badge(s.get("risk_level","info"))}</td>'
            f'<td style="color:#ffd60a">{escape(str(s.get("host","—")))}</td>'
            f'<td style="color:#00d4ff">{escape(str(s.get("port","—")))}/{escape(str(s.get("protocol","tcp")))}</td>'
            f'<td style="color:#fff;font-weight:700">{escape(str(s.get("protocol_name","—")))}</td>'
            f'<td style="color:#9b59b6">{escape(str(s.get("family","—")))}</td>'
            f'<td style="color:#5a7a9a">{escape(str(s.get("version","—"))[:25])}</td>'
            f'<td>{_score_bar_html(0)}</td>'
            f'</tr>'
            for s in services[:40]
        )
        if len(services) > 40:
            rows += f'<tr><td colspan="7" class="svc-empty">+{len(services)-40} more services</td></tr>'
    else:
        rows = '<tr><td colspan="7" class="svc-empty">No services detected</td></tr>'

    return f"""
<div class="svc-tbl-wrap">
  <div class="svc-tbl-title">🔍 Services Detected</div>
  <table class="svc-tbl">
    <thead><tr><th>Risk</th><th>Host</th><th>Port</th><th>Protocol</th><th>Family</th><th>Version</th><th>Score</th></tr></thead>
    <tbody>{rows}</tbody>
  </table>
</div>"""


def _build_risk_signals(data: dict) -> str:
    signals = []
    for svc in data.get("services", []):
        for sig in svc.get("risk_signals", []):
            signals.append((svc, sig))

    signals.sort(key=lambda x: {"critical": 0, "high": 1, "medium": 2}.get(
        x[1].get("sev", "low"), 3))

    if signals:
        rows = "".join(
            f'<tr>'
            f'<td>{_risk_badge(sig.get("sev","info"))}</td>'
            f'<td style="color:#00d4ff">{escape(str(svc.get("protocol_name","—")))}</td>'
            f'<td style="color:#ffd60a">{escape(str(sig.get("type","—")).replace("_"," "))}</td>'
            f'<td style="color:#c8d8e8">{escape(str(sig.get("desc","—"))[:70])}</td>'
            f'</tr>'
            for svc, sig in signals[:20]
        )
    else:
        rows = '<tr><td colspan="4" class="svc-empty" style="color:#30d158">✅ No risk signals detected</td></tr>'

    return f"""
<div class="svc-tbl-wrap">
  <div class="svc-tbl-title">⚠️ Risk Signals</div>
  <table class="svc-tbl">
    <thead><tr><th>Severity</th><th>Service</th><th>Signal</th><th>Detail</th></tr></thead>
    <tbody>{rows}</tbody>
  </table>
</div>"""


def _build_ai_cards(data: dict) -> str:
    analyses = data.get("analyses", [])
    high_risk = [a for a in analyses
                 if a.get("risk_level") in ("critical", "high")][:5]
    if not high_risk:
        return ""

    cards = ""
    for a in high_risk:
        vectors_html = "".join(
            f'<div class="vectors">• {escape(v[:100])}</div>'
            for v in a.get("attack_vectors", [])[:3]
        )
        cards += f"""
<div class="svc-ai-card">
  <span class="proto">{escape(str(a.get("protocol","—")))}</span>
  <span class="addr">{escape(str(a.get("address","—")))}</span>
  <span style="float:right">{_risk_badge(a.get("risk_level","info"))}
  &nbsp;<span style="color:#ff2d55">{escape(str(a.get("risk_score",0))[:4])}/10</span></span>
  <div class="beginner">{escape(str(a.get("beginner",""))[:300])}</div>
  {vectors_html}
</div>"""

    return f"""
<div class="svc-tbl-wrap">
  <div class="svc-tbl-title">🤖 AI Analysis — High Risk Services</div>
  {cards}
</div>"""


def _build_next_steps(data: dict) -> str:
    steps = []
    for a in data.get("analyses", []):
        proto = a.get("protocol", "")
        for step in a.get("next_steps", [])[:2]:
            steps.append((proto, step))
    if not steps:
        return ""

    rows = "".join(
        f'<tr>'
        f'<td style="color:#00d4ff">{escape(str(step.get("tool","—")))}</td>'
        f'<td style="color:#fff">{escape(str(proto))}</td>'
        f'<td style="color:#30d158;font-family:monospace">{escape(str(step.get("cmd","—"))[:70])}</td>'
        f'<td style="color:#5a7a9a">{escape(str(step.get("why","—"))[:50])}</td>'
        f'</tr>'
        for proto, step in steps[:15]
    )

    return f"""
<div class="svc-tbl-wrap">
  <div class="svc-tbl-title">🗺️ Enumeration Paths</div>
  <table class="svc-tbl">
    <thead><tr><th>Tool</th><th>Service</th><th>Command</th><th>Purpose</th></tr></thead>
    <tbody>{rows}</tbody>
  </table>
</div>"""


def _build_section(data: dict) -> str:
    summary = escape(str(data.get("summary", "")))
    return f"""
<div class="svc-section section">
  <h2 class="section-title"><span class="icon">🔍</span> Service Intelligence
    <span class="model-tag">Stage 20</span>
  </h2>
  {_build_summary_bar(data)}
  {_build_stats_row(data)}
  {_build_services_table(data)}
  {_build_risk_signals(data)}
  {_build_ai_cards(data)}
  {_build_next_steps(data)}
  {"<p style='color:#5a7a9a;font-size:12px;margin-top:12px'>" + summary + "</p>" if summary else ""}
</div>"""


# ══════════════════════════════════════════════════════════════════════════════
# Public API
# ══════════════════════════════════════════════════════════════════════════════

def inject_service_section(
    html_path:         str,
    service_data:      dict,
    create_if_missing: bool = False,
) -> bool:
    """
    Inject a Service Intelligence section into an existing HTML report.
    If create_if_missing=True and the file doesn't exist, create standalone HTML.
    Returns True on success.
    """
    path = Path(html_path)
    section = _build_section(service_data)

    if not path.exists():
        if not create_if_missing:
            return False
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            html = _STANDALONE_HTML.format(css=_SVC_CSS, body=section)
            path.write_text(html, encoding="utf-8")
            return True
        except Exception:
            return False

    try:
        html = path.read_text(encoding="utf-8")
        if "svc-section" not in html:
            html = html.replace("</style>", f"{_SVC_CSS}\n</style>", 1)
        html = html.replace("</body>", f"{section}\n</body>", 1) if "</body>" in html else html + section
        path.write_text(html, encoding="utf-8")
        return True
    except Exception:
        return False
