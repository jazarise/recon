"""
ReconX — Stage 20: Scanner Output Parsers

Normalises raw output from multiple scanner tools into ServiceRecord objects.

Supported:
  NmapParser      — XML / grepable / normal output
  RustscanParser  — Rustscan JSON and plain output
  NaabuParser     — Naabu JSON / plain output
  MasscanParser   — Masscan JSON / list output
  HTTPXParser     — HTTPX JSON output
  GenericParser   — fallback line-by-line parser

Each parser implements:
  parse(raw: str, host: str) -> ScanParseResult

Design rules:
  - Never raises — all errors go into ScanParseResult.parse_errors
  - Every ServiceRecord.source_tool is set to the parser's tool name
  - host argument provides context when the scanner omits the target IP
"""
from __future__ import annotations

import json
import logging
import re
import time
from abc import ABC, abstractmethod
from typing import Optional

from .models import ServiceRecord, ScanParseResult, ProtocolClassification, ProtocolFamily

log = logging.getLogger("reconx.analysis.protocol.parsers")

# ── Port extraction helpers ────────────────────────────────────────────────────

def _safe_int(s) -> int:
    try:
        return int(str(s).strip())
    except (ValueError, TypeError):
        return 0


def _state_from(s: str) -> str:
    s = s.lower().strip()
    if s in ("open", "opened", "listening"):
        return "open"
    if s in ("closed", "close"):
        return "closed"
    return s or "open"


# ══════════════════════════════════════════════════════════════════════════════
# Base class
# ══════════════════════════════════════════════════════════════════════════════

class BaseParser(ABC):
    TOOL_NAME: str = "unknown"

    def _make_record(self, host: str, port: int, **kwargs) -> ServiceRecord:
        r = ServiceRecord(
            host=host,
            port=port,
            source_tool=self.TOOL_NAME,
            scan_timestamp=time.time(),
        )
        for k, v in kwargs.items():
            if hasattr(r, k):
                setattr(r, k, v)
        return r

    @abstractmethod
    def parse(self, raw: str, host: str = "") -> ScanParseResult:
        ...

    def _result(self, services=None, errors=None) -> ScanParseResult:
        return ScanParseResult(
            source_tool=self.TOOL_NAME,
            services=services or [],
            parse_errors=errors or [],
            parse_ok=not errors,
        )


# ══════════════════════════════════════════════════════════════════════════════
# Nmap parser
# ══════════════════════════════════════════════════════════════════════════════

class NmapParser(BaseParser):
    """
    Parse Nmap output in three formats:
      1. XML (-oX) — most structured, preferred
      2. Grepable (-oG) — compact line format
      3. Normal (-oN) — human-readable text

    Auto-detects format from content.
    """
    TOOL_NAME = "nmap"

    def parse(self, raw: str, host: str = "") -> ScanParseResult:
        raw = raw.strip()
        if not raw:
            return self._result(errors=["Empty Nmap output"])

        if raw.startswith("<?xml") or "<nmaprun" in raw:
            return self._parse_xml(raw, host)
        if "Host:" in raw and "Ports:" in raw:
            return self._parse_grepable(raw, host)
        return self._parse_normal(raw, host)

    def _parse_xml(self, raw: str, host: str) -> ScanParseResult:
        """Parse Nmap XML output using stdlib xml.etree."""
        import xml.etree.ElementTree as ET
        services: list[ServiceRecord] = []
        errors:   list[str]           = []

        try:
            root = ET.fromstring(raw)
        except ET.ParseError as exc:
            return self._result(errors=[f"XML parse error: {exc}"])

        for host_el in root.findall(".//host"):
            # Get IP address
            addr_el = host_el.find(".//address[@addrtype='ipv4']")
            ip = addr_el.get("addr", host) if addr_el is not None else host

            # Get hostname
            hostname_el = host_el.find(".//hostname")
            hostname = hostname_el.get("name", "") if hostname_el is not None else ""

            for port_el in host_el.findall(".//port"):
                state_el = port_el.find("state")
                if state_el is None:
                    continue
                state = state_el.get("state", "")
                if state not in ("open", "open|filtered"):
                    continue

                portid    = _safe_int(port_el.get("portid", "0"))
                transport = port_el.get("protocol", "tcp")

                svc_el    = port_el.find("service")
                svc_name  = ""
                svc_ver   = ""
                product   = ""
                if svc_el is not None:
                    svc_name = svc_el.get("name", "")
                    product  = svc_el.get("product", "")
                    ver_str  = svc_el.get("version", "")
                    extra    = svc_el.get("extrainfo", "")
                    parts    = [product, ver_str, extra]
                    svc_ver  = " ".join(p for p in parts if p).strip()

                banner = ""
                for script_el in port_el.findall("script"):
                    if script_el.get("id") in ("banner", "http-title"):
                        banner = script_el.get("output", "")[:500]
                        break

                services.append(self._make_record(
                    ip, portid,
                    protocol=transport,
                    state="open",
                    service_name=svc_name,
                    service_version=svc_ver,
                    banner=banner,
                    hostname=hostname,
                ))

        return self._result(services, errors)

    def _parse_grepable(self, raw: str, host: str) -> ScanParseResult:
        """Parse Nmap grepable (-oG) format."""
        services: list[ServiceRecord] = []
        # Pattern: Host: 1.2.3.4 (hostname)  Ports: 80/open/tcp//http//Apache/
        for line in raw.splitlines():
            if not line.startswith("Host:"):
                continue
            ip_match = re.search(r"Host:\s+(\S+)", line)
            ip = ip_match.group(1) if ip_match else host

            ports_match = re.search(r"Ports:\s+(.+?)(?:\s+Ignored|$)", line)
            if not ports_match:
                continue

            for port_str in ports_match.group(1).split(","):
                parts = port_str.strip().split("/")
                if len(parts) < 3:
                    continue
                portid    = _safe_int(parts[0])
                state     = parts[1]
                transport = parts[2]
                svc_name  = parts[4] if len(parts) > 4 else ""
                svc_ver   = parts[6] if len(parts) > 6 else ""

                if state == "open" and portid:
                    services.append(self._make_record(
                        ip, portid,
                        protocol=transport,
                        state="open",
                        service_name=svc_name,
                        service_version=svc_ver,
                    ))

        return self._result(services)

    def _parse_normal(self, raw: str, host: str) -> ScanParseResult:
        """Parse Nmap normal text output."""
        services: list[ServiceRecord] = []
        current_host = host

        host_re = re.compile(r"Nmap scan report for (.+)")
        port_re = re.compile(
            r"^(\d+)/(tcp|udp)\s+(open\S*)\s+(\S+)(?:\s+(.+))?$"
        )

        for line in raw.splitlines():
            hm = host_re.search(line)
            if hm:
                target = hm.group(1).strip()
                # "hostname (1.2.3.4)" or just IP
                ip_match = re.search(r"\((\d+\.\d+\.\d+\.\d+)\)", target)
                current_host = ip_match.group(1) if ip_match else target
                continue

            pm = port_re.match(line.strip())
            if pm:
                portid, transport, state, svc_name = (
                    _safe_int(pm.group(1)), pm.group(2),
                    pm.group(3), pm.group(4),
                )
                svc_ver = (pm.group(5) or "").strip()
                if "open" in state:
                    services.append(self._make_record(
                        current_host, portid,
                        protocol=transport,
                        state="open",
                        service_name=svc_name,
                        service_version=svc_ver,
                    ))

        return self._result(services)


# ══════════════════════════════════════════════════════════════════════════════
# Rustscan parser
# ══════════════════════════════════════════════════════════════════════════════

class RustscanParser(BaseParser):
    """
    Parse Rustscan output.

    Rustscan fast-scans ports then optionally calls Nmap for service detection.
    Handles both JSON output (--greppable or --json) and plain port lists.
    """
    TOOL_NAME = "rustscan"

    def parse(self, raw: str, host: str = "") -> ScanParseResult:
        raw = raw.strip()
        if not raw:
            return self._result(errors=["Empty Rustscan output"])

        # Try JSON first
        if raw.startswith("[") or raw.startswith("{"):
            return self._parse_json(raw, host)

        # Nmap section embedded in Rustscan output
        if "Nmap scan report" in raw or "<nmaprun" in raw:
            nmap_start = raw.find("Nmap scan report")
            if nmap_start == -1:
                nmap_start = raw.find("<nmaprun")
            return NmapParser().parse(raw[nmap_start:], host)

        return self._parse_plain(raw, host)

    def _parse_json(self, raw: str, host: str) -> ScanParseResult:
        """Parse Rustscan JSON output."""
        services: list[ServiceRecord] = []
        errors:   list[str]           = []
        try:
            data = json.loads(raw)
            if not isinstance(data, list):
                data = [data]
            for item in data:
                ip    = item.get("ip", host)
                ports = item.get("ports", [])
                for p in ports:
                    portid = _safe_int(p) if isinstance(p, (int, str)) else _safe_int(p.get("port", 0))
                    if portid:
                        services.append(self._make_record(ip, portid, state="open"))
        except json.JSONDecodeError as exc:
            errors.append(f"JSON parse error: {exc}")
        return self._result(services, errors)

    def _parse_plain(self, raw: str, host: str) -> ScanParseResult:
        """Parse Rustscan plain output: 'Open <ip>:<port>'."""
        services: list[ServiceRecord] = []
        port_re  = re.compile(r"(?:Open\s+)?(\d+\.\d+\.\d+\.\d+|\[.+\]):(\d+)", re.I)

        for line in raw.splitlines():
            m = port_re.search(line)
            if m:
                ip     = m.group(1).strip("[]")
                portid = _safe_int(m.group(2))
                if portid:
                    services.append(self._make_record(ip or host, portid, state="open"))
            elif re.match(r"^\d+$", line.strip()):
                services.append(self._make_record(host, _safe_int(line.strip()), state="open"))

        return self._result(services)


# ══════════════════════════════════════════════════════════════════════════════
# Naabu parser
# ══════════════════════════════════════════════════════════════════════════════

class NaabuParser(BaseParser):
    """
    Parse Naabu output.
    Naabu outputs: ip:port per line, or JSON with -json flag.
    """
    TOOL_NAME = "naabu"

    def parse(self, raw: str, host: str = "") -> ScanParseResult:
        raw = raw.strip()
        if not raw:
            return self._result(errors=["Empty Naabu output"])

        # JSON lines
        if raw.startswith("{"):
            return self._parse_jsonl(raw, host)
        return self._parse_plain(raw, host)

    def _parse_jsonl(self, raw: str, host: str) -> ScanParseResult:
        services: list[ServiceRecord] = []
        errors:   list[str]           = []
        for line in raw.splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                obj    = json.loads(line)
                ip     = obj.get("ip", obj.get("host", host))
                portid = _safe_int(obj.get("port", 0))
                proto  = obj.get("protocol", "tcp")
                if portid:
                    services.append(self._make_record(ip, portid, protocol=proto, state="open"))
            except json.JSONDecodeError:
                errors.append(f"JSON line error: {line[:50]}")
        return self._result(services, errors)

    def _parse_plain(self, raw: str, host: str) -> ScanParseResult:
        services: list[ServiceRecord] = []
        # Formats: "1.2.3.4:80" or "1.2.3.4:80/tcp"
        for line in raw.splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            m = re.match(r"(.+):(\d+)(?:/(\w+))?", line)
            if m:
                ip     = m.group(1)
                portid = _safe_int(m.group(2))
                proto  = m.group(3) or "tcp"
                if portid:
                    services.append(self._make_record(ip or host, portid, protocol=proto, state="open"))
        return self._result(services)


# ══════════════════════════════════════════════════════════════════════════════
# Masscan parser
# ══════════════════════════════════════════════════════════════════════════════

class MasscanParser(BaseParser):
    """
    Parse Masscan output.
    Formats: JSON (-oJ), XML (-oX), list (-oL), grepable (-oG).
    """
    TOOL_NAME = "masscan"

    def parse(self, raw: str, host: str = "") -> ScanParseResult:
        raw = raw.strip()
        if not raw:
            return self._result(errors=["Empty Masscan output"])

        if raw.startswith("[") or '{"ip"' in raw:
            return self._parse_json(raw, host)
        if raw.startswith("<?xml") or "<nmaprun" in raw:
            return NmapParser().parse(raw, host)   # Masscan XML is Nmap-compatible
        return self._parse_list(raw, host)

    def _parse_json(self, raw: str, host: str) -> ScanParseResult:
        services: list[ServiceRecord] = []
        errors:   list[str]           = []
        try:
            # Masscan JSON may have trailing comma — clean it
            raw_clean = re.sub(r",\s*\]", "]", raw.strip())
            data      = json.loads(raw_clean)
            if isinstance(data, dict):
                data = [data]
            for item in data:
                ip     = item.get("ip", host)
                for port_info in item.get("ports", []):
                    portid = _safe_int(port_info.get("port", 0))
                    proto  = port_info.get("proto", "tcp")
                    status = port_info.get("status", "open")
                    if portid and status == "open":
                        services.append(self._make_record(ip, portid, protocol=proto, state="open"))
        except json.JSONDecodeError as exc:
            errors.append(f"JSON parse error: {exc}")
        return self._result(services, errors)

    def _parse_list(self, raw: str, host: str) -> ScanParseResult:
        """Parse Masscan list output: 'open tcp 80 1.2.3.4'"""
        services: list[ServiceRecord] = []
        for line in raw.splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split()
            if len(parts) >= 4 and parts[0] == "open":
                proto  = parts[1]
                portid = _safe_int(parts[2])
                ip     = parts[3]
                if portid:
                    services.append(self._make_record(ip or host, portid, protocol=proto, state="open"))
        return self._result(services)


# ══════════════════════════════════════════════════════════════════════════════
# HTTPX parser
# ══════════════════════════════════════════════════════════════════════════════

class HTTPXParser(BaseParser):
    """
    Parse HTTPX JSON output (-json flag).
    HTTPX probes URLs and returns per-URL JSON objects.
    """
    TOOL_NAME = "httpx"

    def parse(self, raw: str, host: str = "") -> ScanParseResult:
        raw = raw.strip()
        if not raw:
            return self._result(errors=["Empty HTTPX output"])

        services: list[ServiceRecord] = []
        errors:   list[str]           = []

        for line in raw.splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                obj     = json.loads(line)
                url     = obj.get("url", obj.get("input", ""))
                status  = _safe_int(obj.get("status_code", 0))
                title   = obj.get("title", "")
                tech    = obj.get("tech", [])

                # Parse host:port from URL
                url_m = re.match(r"(https?)://([^/:]+):?(\d+)?", url)
                if not url_m:
                    continue
                scheme = url_m.group(1)
                ip     = url_m.group(2) or host
                portid = _safe_int(url_m.group(3)) if url_m.group(3) else (443 if scheme == "https" else 80)

                tls_data = obj.get("tls", {}) or {}
                cert     = tls_data.get("subject_cn", "")
                tls_ver  = tls_data.get("tls_version", "")

                banner_parts = [f"HTTP/{status}"]
                if title:
                    banner_parts.append(f'title="{title}"')
                if tech:
                    banner_parts.append(f"tech={','.join(tech[:3])}")
                banner = " | ".join(banner_parts)

                r = self._make_record(
                    ip, portid,
                    protocol="tcp",
                    state="open",
                    service_name="HTTPS" if scheme == "https" else "HTTP",
                    service_version=", ".join(tech[:3]) if tech else "",
                    banner=banner,
                    hostname=ip if not re.match(r"\d+\.\d+\.\d+\.\d+", ip) else "",
                    tls_enabled=(scheme == "https"),
                    tls_version=tls_ver,
                    tls_cert_cn=cert,
                )
                services.append(r)

            except (json.JSONDecodeError, AttributeError) as exc:
                errors.append(f"HTTPX line error: {exc} — {line[:60]}")

        return self._result(services, errors)


# ══════════════════════════════════════════════════════════════════════════════
# Generic fallback parser
# ══════════════════════════════════════════════════════════════════════════════

class GenericParser(BaseParser):
    """
    Best-effort fallback parser for unknown scanner output.
    Extracts port numbers from any line containing patterns like:
      80/tcp, :80, port 80, 80 open
    """
    TOOL_NAME = "generic"

    def parse(self, raw: str, host: str = "") -> ScanParseResult:
        services: list[ServiceRecord] = []
        seen: set[tuple] = set()

        patterns = [
            re.compile(r"(\d+\.\d+\.\d+\.\d+)(?::|\s+)(\d{1,5})/?(tcp|udp)?"),
            re.compile(r"\b(\d{1,5})/(tcp|udp)\b"),
            re.compile(r"\bport\s+(\d{1,5})\b", re.I),
            re.compile(r"\b(\d{1,5})\s+open\b", re.I),
        ]

        for line in raw.splitlines():
            for pat in patterns:
                for m in pat.finditer(line):
                    groups = m.groups()
                    if len(groups) >= 2 and re.match(r"\d+\.\d+\.\d+\.\d+", groups[0]):
                        ip, portid, proto = groups[0], _safe_int(groups[1]), groups[2] or "tcp"
                    else:
                        ip, portid, proto = host, _safe_int(groups[0]), "tcp"

                    key = (ip, portid, proto)
                    if portid and 1 <= portid <= 65535 and key not in seen:
                        seen.add(key)
                        services.append(self._make_record(ip, portid, protocol=proto, state="open"))

        return self._result(list(services))


# ══════════════════════════════════════════════════════════════════════════════
# Parser registry
# ══════════════════════════════════════════════════════════════════════════════

_PARSERS: dict[str, BaseParser] = {
    "nmap":      NmapParser(),
    "rustscan":  RustscanParser(),
    "naabu":     NaabuParser(),
    "masscan":   MasscanParser(),
    "httpx":     HTTPXParser(),
    "generic":   GenericParser(),
}


def get_parser(tool_name: str) -> BaseParser:
    """Return the parser for a named tool, falling back to GenericParser."""
    return _PARSERS.get(tool_name.lower(), _PARSERS["generic"])


def parse_scan_output(
    raw:       str,
    tool_name: str = "generic",
    host:      str = "",
) -> ScanParseResult:
    """
    Convenience function: parse raw scanner output and return ServiceRecord list.

    Args:
        raw:       Raw text output from the scanner.
        tool_name: "nmap" | "rustscan" | "naabu" | "masscan" | "httpx"
        host:      Target IP/host (used when scanner omits it)
    """
    return get_parser(tool_name).parse(raw, host)
