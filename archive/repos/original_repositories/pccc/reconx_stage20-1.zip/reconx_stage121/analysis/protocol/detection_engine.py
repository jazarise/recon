"""
ReconX — Stage 20: Protocol Detection Engine

Classifies the protocol actually running on a port by combining:
  1. Port heuristics (from knowledge base)
  2. Banner signature matching (regex patterns)
  3. Version string parsing (product/version extraction)
  4. TLS context detection
  5. HTTP header analysis

Produces ProtocolClassification with a confidence score for each ServiceRecord.
Never modifies input records in place — returns new classification objects.
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass

from .models import (
    ServiceRecord, ProtocolClassification, ProtocolFamily,
    FingerprintResult, FingerprintMethod, ServiceRisk,
)
from .knowledge_base import lookup_port, lookup_service

log = logging.getLogger("reconx.analysis.protocol.detection")

# ── Banner signature catalogue ────────────────────────────────────────────────
# (protocol_name, family, pattern, confidence, encrypted)
_BANNER_SIGS: list[tuple] = [
    # Web
    ("HTTP",        ProtocolFamily.WEB,       re.compile(r"HTTP/\d+\.?\d*\s+\d{3}", re.I), 0.99, False),
    ("HTTPS",       ProtocolFamily.WEB,       re.compile(r"SSL-Session|TLS|CERTIFICATE", re.I), 0.90, True),
    ("HTTP/2",      ProtocolFamily.WEB,       re.compile(r"PRI \* HTTP/2\.0|h2"), 0.95, False),
    ("WebSocket",   ProtocolFamily.WEB,       re.compile(r"Upgrade: websocket|101 Switching", re.I), 0.92, False),

    # Remote
    ("SSH",         ProtocolFamily.REMOTE,    re.compile(r"SSH-\d+\.\d+"), 0.99, True),
    ("Telnet",      ProtocolFamily.REMOTE,    re.compile(r"\xff\xfb|\xff\xfd|login:|Password:", re.I), 0.90, False),
    ("RDP",         ProtocolFamily.REMOTE,    re.compile(r"NTLMSSP|mstshash|rdpdr|rdpsnd", re.I), 0.88, True),
    ("VNC",         ProtocolFamily.REMOTE,    re.compile(r"RFB \d+\.\d+"), 0.97, False),

    # Mail
    ("SMTP",        ProtocolFamily.MAIL,      re.compile(r"^220.*SMTP|ESMTP", re.I), 0.98, False),
    ("POP3",        ProtocolFamily.MAIL,      re.compile(r"^\+OK.*POP3|Dovecot", re.I), 0.97, False),
    ("IMAP",        ProtocolFamily.MAIL,      re.compile(r"^\* OK.*IMAP|CAPABILITY", re.I), 0.97, False),

    # File
    ("FTP",         ProtocolFamily.FILE,      re.compile(r"^220.*FTP|vsftpd|ProFTPD|FileZilla", re.I), 0.98, False),
    ("SMB",         ProtocolFamily.FILE,      re.compile(r"\xffSMB|\xfeSMB|SMBv\d"), 0.99, False),
    ("NFS",         ProtocolFamily.FILE,      re.compile(r"NFS|portmapper", re.I), 0.80, False),

    # Network
    ("DNS",         ProtocolFamily.NETWORK,   re.compile(r"BIND|named|unbound", re.I), 0.85, False),
    ("SNMP",        ProtocolFamily.NETWORK,   re.compile(r"public|private|community|snmpd", re.I), 0.75, False),
    ("LDAP",        ProtocolFamily.DIRECTORY, re.compile(r"objectClass|cn=|dc=|LDAP", re.I), 0.88, False),

    # Databases
    ("MySQL",       ProtocolFamily.DATABASE,  re.compile(r"mysql_native_password|MariaDB|\x00mysql", re.I), 0.97, False),
    ("PostgreSQL",  ProtocolFamily.DATABASE,  re.compile(r"PostgreSQL|PGSQL|pg_hba|FATAL:.*database", re.I), 0.95, False),
    ("MSSQL",       ProtocolFamily.DATABASE,  re.compile(r"Microsoft SQL Server|MSSQL|SQL Server", re.I), 0.96, False),
    ("Oracle",      ProtocolFamily.DATABASE,  re.compile(r"Oracle|TNS|TNSLSNR", re.I), 0.93, False),
    ("MongoDB",     ProtocolFamily.DATABASE,  re.compile(r"MongoDB|mongod|ismaster|dbVersion", re.I), 0.95, False),
    ("Redis",       ProtocolFamily.DATABASE,  re.compile(r"redis_version|-ERR|PONG|\*\d+\r\n\$", re.I), 0.97, False),
    ("Elasticsearch", ProtocolFamily.DATABASE,re.compile(r"elasticsearch|_cluster|lucene_version", re.I), 0.94, False),
    ("Cassandra",   ProtocolFamily.DATABASE,  re.compile(r"Cassandra|CQL|org\.apache\.cassandra", re.I), 0.93, False),
    ("Memcached",   ProtocolFamily.DATABASE,  re.compile(r"VERSION \d+\.\d+|STAT pid|END\r\n", re.I), 0.95, False),
    ("CouchDB",     ProtocolFamily.DATABASE,  re.compile(r"couchdb|Welcome.*Apache CouchDB", re.I), 0.95, False),
    ("InfluxDB",    ProtocolFamily.DATABASE,  re.compile(r"InfluxDB|influxdb", re.I), 0.93, False),
    ("ZooKeeper",   ProtocolFamily.DATABASE,  re.compile(r"zxid|ZooKeeper|imok", re.I), 0.90, False),

    # Messaging
    ("MQTT",        ProtocolFamily.MESSAGING, re.compile(r"MQTT|mqtt", re.I), 0.90, False),
    ("AMQP",        ProtocolFamily.MESSAGING, re.compile(r"AMQP|RabbitMQ", re.I), 0.92, False),
    ("Kafka",       ProtocolFamily.MESSAGING, re.compile(r"kafka|ApiVersions|PRODUCE", re.I), 0.85, False),

    # Cloud
    ("Docker",      ProtocolFamily.CLOUD,     re.compile(r"Docker|/v\d+\.\d+/containers|moby", re.I), 0.94, False),
    ("Kubernetes",  ProtocolFamily.CLOUD,     re.compile(r"kubernetes|k8s|apiserver|Bearer", re.I), 0.85, True),
    ("Kubelet",     ProtocolFamily.CLOUD,     re.compile(r"kubelet|Node.*Kubelet|/pods", re.I), 0.88, True),
    ("etcd",        ProtocolFamily.CLOUD,     re.compile(r"etcd|/v3/kv|etcdserver", re.I), 0.90, False),
]

# Version extraction patterns (service_name → regex → group 1 = version)
_VERSION_PATTERNS: dict[str, re.Pattern] = {
    "ssh":      re.compile(r"SSH-[\d.]+-(OpenSSH)[_\-]?([\d.]+p?\d*)", re.I),
    "http":     re.compile(r"Apache(?:/| )([\d.]+)|nginx/([\d.]+)|IIS/([\d.]+)", re.I),
    "ftp":      re.compile(r"vsftpd ([\d.]+)|ProFTPD ([\d.]+)|FileZilla Server (\d[\d.]*)", re.I),
    "smtp":     re.compile(r"Postfix|Sendmail|Exim ([\d.]+)", re.I),
    "mysql":    re.compile(r"(\d+\.\d+\.\d+)(?:-MariaDB|-enterprise)?", re.I),
    "postgres": re.compile(r"PostgreSQL ([\d.]+)", re.I),
    "redis":    re.compile(r"redis_version:([\d.]+)", re.I),
    "mongodb":  re.compile(r'"version"\s*:\s*"([\d.]+)"', re.I),
}


class ProtocolDetectionEngine:
    """
    Fingerprints the protocol running on each ServiceRecord using
    multiple detection methods in confidence-priority order.

    Usage:
        engine  = ProtocolDetectionEngine()
        records = engine.classify_all(services)
    """

    def classify(self, record: ServiceRecord) -> ProtocolClassification:
        """
        Return the best ProtocolClassification for a single ServiceRecord.
        Tries methods in order: banner → version_string → port_heuristic.
        """
        # 1. Banner matching (highest specificity)
        if record.banner:
            hit = self._from_banner(record.banner, record.port)
            if hit:
                return hit

        # 2. Service version string from scanner
        combined = f"{record.service_name} {record.service_version}".strip()
        if combined:
            hit = self._from_version_string(combined, record.port)
            if hit:
                return hit

        # 3. Port knowledge base fallback
        hit = self._from_port(record.port, record.protocol)
        if hit:
            return hit

        # 4. Unknown
        return ProtocolClassification(
            protocol=record.service_name or f"unknown/{record.port}",
            family=ProtocolFamily.UNKNOWN,
            confidence=0.40,
            method=FingerprintMethod.PORT,
            detail="Could not classify protocol",
        )

    def classify_all(self, records: list[ServiceRecord]) -> list[ServiceRecord]:
        """
        Classify all records. Returns the same list with .classification set.
        Mutates records in place for efficiency.
        """
        for r in records:
            r.classification = self.classify(r)
            r.fingerprints   = self._fingerprint(r)
        return records

    # ── Fingerprint extraction ─────────────────────────────────────────────────

    def _fingerprint(self, record: ServiceRecord) -> list[FingerprintResult]:
        """Extract as many fingerprint signals as possible from a record."""
        results: list[FingerprintResult] = []

        if record.banner:
            results.append(FingerprintResult(
                method=FingerprintMethod.BANNER,
                raw=record.banner[:200],
                confidence=0.85,
            ))
            ver = self._extract_version(record)
            if ver:
                results.append(FingerprintResult(
                    method=FingerprintMethod.VERSION,
                    matched_pattern="version_string",
                    extracted_value=ver,
                    confidence=0.92,
                ))

        if record.tls_enabled:
            results.append(FingerprintResult(
                method=FingerprintMethod.TLS,
                extracted_value=f"{record.tls_version or 'TLS'} {record.tls_cert_cn}".strip(),
                confidence=0.90,
            ))

        return results

    # ── Internal detection methods ─────────────────────────────────────────────

    def _from_banner(self, banner: str, port: int) -> ProtocolClassification | None:
        """Match banner text against signature catalogue."""
        for name, family, pattern, conf, encrypted in _BANNER_SIGS:
            if pattern.search(banner):
                return ProtocolClassification(
                    protocol=name,
                    family=family,
                    confidence=conf,
                    method=FingerprintMethod.BANNER,
                    detail=f"Banner match: {pattern.pattern[:50]}",
                    is_encrypted=encrypted,
                    is_default_port=self._is_default(port, name),
                )
        return None

    def _from_version_string(self, s: str, port: int) -> ProtocolClassification | None:
        """Match scanner-reported service/version string."""
        s_lower = s.lower()

        # Direct name mapping
        _name_map = {
            "http": ("HTTP", ProtocolFamily.WEB, False),
            "https": ("HTTPS", ProtocolFamily.WEB, True),
            "ssh": ("SSH", ProtocolFamily.REMOTE, True),
            "ftp": ("FTP", ProtocolFamily.FILE, False),
            "telnet": ("Telnet", ProtocolFamily.REMOTE, False),
            "smtp": ("SMTP", ProtocolFamily.MAIL, False),
            "pop3": ("POP3", ProtocolFamily.MAIL, False),
            "imap": ("IMAP", ProtocolFamily.MAIL, False),
            "dns": ("DNS", ProtocolFamily.NETWORK, False),
            "snmp": ("SNMP", ProtocolFamily.NETWORK, False),
            "ldap": ("LDAP", ProtocolFamily.DIRECTORY, False),
            "ldaps": ("LDAPS", ProtocolFamily.DIRECTORY, True),
            "smb": ("SMB", ProtocolFamily.FILE, False),
            "microsoft-ds": ("SMB", ProtocolFamily.FILE, False),
            "netbios": ("NetBIOS", ProtocolFamily.NETWORK, False),
            "nfs": ("NFS", ProtocolFamily.FILE, False),
            "rdp": ("RDP", ProtocolFamily.REMOTE, True),
            "ms-wbt-server": ("RDP", ProtocolFamily.REMOTE, True),
            "mysql": ("MySQL", ProtocolFamily.DATABASE, False),
            "postgresql": ("PostgreSQL", ProtocolFamily.DATABASE, False),
            "mssql": ("MSSQL", ProtocolFamily.DATABASE, False),
            "ms-sql-s": ("MSSQL", ProtocolFamily.DATABASE, False),
            "oracle": ("Oracle", ProtocolFamily.DATABASE, False),
            "mongodb": ("MongoDB", ProtocolFamily.DATABASE, False),
            "redis": ("Redis", ProtocolFamily.DATABASE, False),
            "elasticsearch": ("Elasticsearch", ProtocolFamily.DATABASE, False),
            "cassandra": ("Cassandra", ProtocolFamily.DATABASE, False),
            "memcached": ("Memcached", ProtocolFamily.DATABASE, False),
            "couchdb": ("CouchDB", ProtocolFamily.DATABASE, False),
            "influxdb": ("InfluxDB", ProtocolFamily.DATABASE, False),
            "zookeeper": ("ZooKeeper", ProtocolFamily.DATABASE, False),
            "mqtt": ("MQTT", ProtocolFamily.MESSAGING, False),
            "amqp": ("AMQP", ProtocolFamily.MESSAGING, False),
            "kafka": ("Kafka", ProtocolFamily.MESSAGING, False),
            "docker": ("Docker", ProtocolFamily.CLOUD, False),
            "kubernetes": ("Kubernetes", ProtocolFamily.CLOUD, True),
            "kube": ("Kubernetes", ProtocolFamily.CLOUD, True),
            "etcd": ("etcd", ProtocolFamily.CLOUD, False),
            "vnc": ("VNC", ProtocolFamily.REMOTE, False),
        }

        for key, (proto, family, encrypted) in _name_map.items():
            if key in s_lower:
                return ProtocolClassification(
                    protocol=proto,
                    family=family,
                    confidence=0.88,
                    method=FingerprintMethod.VERSION,
                    detail=f"Service name match: {key}",
                    is_encrypted=encrypted,
                    is_default_port=self._is_default(port, proto),
                )
        return None

    def _from_port(self, port: int, transport: str) -> ProtocolClassification | None:
        """Use knowledge base port → service mapping."""
        entry = lookup_port(port)
        if not entry:
            return None
        return ProtocolClassification(
            protocol=entry.name,
            family=entry.family,
            confidence=0.72,    # lower confidence for port-only detection
            method=FingerprintMethod.PORT,
            detail=f"Port {port}/{transport} heuristic",
            is_encrypted=entry.encrypted,
            is_default_port=True,
        )

    def _extract_version(self, record: ServiceRecord) -> str:
        """Try to extract a clean version string from banner or service_version."""
        svc = record.service_name.lower()
        text = (record.banner or "") + " " + (record.service_version or "")
        pat = _VERSION_PATTERNS.get(svc)
        if pat:
            m = pat.search(text)
            if m:
                return next((g for g in m.groups() if g), "")
        # Generic semver extraction
        m = re.search(r"(\d+\.\d+(?:\.\d+)?)", text)
        return m.group(1) if m else ""

    @staticmethod
    def _is_default(port: int, protocol_name: str) -> bool:
        entry = lookup_port(port)
        if entry:
            return entry.name.lower() == protocol_name.lower()
        return False
