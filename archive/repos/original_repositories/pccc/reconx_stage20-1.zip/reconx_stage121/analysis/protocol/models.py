"""
ReconX — Stage 20: Protocol & Service Analysis Models

All data structures for Stage 20. Built on top of existing Port, Technology,
and ReconResult — never replaces them.

New models:
  ServiceRecord           — enriched service with protocol + fingerprint data
  ProtocolClassification  — protocol family and confidence from detection
  FingerprintResult       — banner / header / TLS / version pattern match
  RiskSignal              — one risk indicator from a service
  ServiceAnalysis         — full AI-driven analysis of a single service
  ServiceIntelligenceReport — aggregated report for all services on a target
  ScanParseResult         — normalised output from any scanner tool
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


# ── Enumerations ──────────────────────────────────────────────────────────────

class ProtocolFamily(str, Enum):
    WEB       = "web"
    NETWORK   = "network"
    DATABASE  = "database"
    CLOUD     = "cloud"
    MAIL      = "mail"
    FILE      = "file"
    REMOTE    = "remote"
    DIRECTORY = "directory"
    MESSAGING = "messaging"
    UNKNOWN   = "unknown"


class ServiceRisk(str, Enum):
    CRITICAL = "critical"   # immediately exploitable / data-loss risk
    HIGH     = "high"       # significant exposure
    MEDIUM   = "medium"     # worth investigating
    LOW      = "low"        # minimal concern
    INFO     = "info"       # informational only


class FingerprintMethod(str, Enum):
    BANNER   = "banner"
    HEADER   = "header"
    TLS      = "tls"
    BEHAVIOR = "behavior"
    VERSION  = "version_pattern"
    PORT     = "port_heuristic"


# ── Core service record ───────────────────────────────────────────────────────

@dataclass
class ProtocolClassification:
    """Protocol detected and classified for a port/service."""
    protocol:    str                    # "HTTP", "SSH", "Redis", ...
    family:      ProtocolFamily         = ProtocolFamily.UNKNOWN
    confidence:  float                  = 0.80       # 0.0–1.0
    method:      FingerprintMethod      = FingerprintMethod.PORT
    detail:      str                    = ""          # e.g. "OpenSSH_8.9 banner match"
    is_encrypted: bool                  = False
    is_default_port: bool               = True


@dataclass
class FingerprintResult:
    """One fingerprint match from any fingerprinting technique."""
    method:         FingerprintMethod
    matched_pattern: str               = ""
    extracted_value: str               = ""
    confidence:     float              = 0.80
    raw:            str                = ""          # raw banner / header / cert field


@dataclass
class RiskSignal:
    """One risk indicator found during service analysis."""
    signal_type:  str                  # "default_creds" | "no_auth" | "cleartext" | ...
    description:  str
    severity:     ServiceRisk          = ServiceRisk.MEDIUM
    evidence:     str                  = ""
    cve:          str                  = ""          # linked CVE if known
    cwe:          str                  = ""


@dataclass
class ServiceRecord:
    """
    Enriched representation of one open port and its running service.

    Extends the existing Port model with:
    - ProtocolClassification (what protocol is actually running)
    - Fingerprints (banner, header, TLS, version)
    - Risk signals (auth issues, cleartext, default creds, etc.)
    - Hostname and TLS context
    - Source scanner metadata

    This is the central unit Stage 20 produces.
    """
    # Identity
    host:          str
    port:          int
    protocol:      str                 = "tcp"       # transport: tcp / udp
    state:         str                 = "open"

    # Service information (from scanner)
    service_name:  str                 = ""          # scanner-reported
    service_version: str               = ""
    banner:        str                 = ""
    hostname:      str                 = ""

    # Protocol intelligence (from Stage 20)
    classification: Optional[ProtocolClassification] = None
    fingerprints:  list[FingerprintResult]            = field(default_factory=list)
    risk_signals:  list[RiskSignal]                   = field(default_factory=list)

    # TLS context
    tls_enabled:   bool                = False
    tls_version:   str                 = ""
    tls_cert_cn:   str                 = ""
    tls_cert_expired: bool             = False
    ja3:           str                 = ""

    # Source metadata
    source_tool:   str                 = ""          # "nmap" | "rustscan" | ...
    scan_timestamp: float              = 0.0

    # AI analysis (populated by ServiceAnalyzer)
    ai_analysis:   Optional["ServiceAnalysis"] = None

    @property
    def protocol_name(self) -> str:
        """Best protocol name: from classification if available, else service_name."""
        if self.classification:
            return self.classification.protocol
        return self.service_name or f"port/{self.port}"

    @property
    def risk_level(self) -> ServiceRisk:
        """Highest risk from all signals."""
        if not self.risk_signals:
            return ServiceRisk.INFO
        order = [ServiceRisk.CRITICAL, ServiceRisk.HIGH,
                 ServiceRisk.MEDIUM, ServiceRisk.LOW, ServiceRisk.INFO]
        for r in order:
            if any(s.severity == r for s in self.risk_signals):
                return r
        return ServiceRisk.INFO

    @property
    def address(self) -> str:
        return f"{self.host}:{self.port}/{self.protocol}"

    def to_dict(self) -> dict:
        return {
            "host":           self.host,
            "port":           self.port,
            "protocol":       self.protocol,
            "state":          self.state,
            "service":        self.service_name,
            "version":        self.service_version,
            "banner":         self.banner[:200] if self.banner else "",
            "hostname":       self.hostname,
            "protocol_name":  self.protocol_name,
            "family":         self.classification.family.value if self.classification else "unknown",
            "confidence":     self.classification.confidence if self.classification else 0.0,
            "risk_level":     self.risk_level.value,
            "risk_signals":   [{"type": s.signal_type, "desc": s.description,
                                "sev": s.severity.value} for s in self.risk_signals],
            "tls_enabled":    self.tls_enabled,
            "tls_version":    self.tls_version,
            "source_tool":    self.source_tool,
        }


# ── AI analysis output ────────────────────────────────────────────────────────

@dataclass
class EnumerationPath:
    """A suggested next-step enumeration action."""
    tool:        str
    command:     str
    purpose:     str
    priority:    int   = 5    # 1 = most urgent


@dataclass
class ServiceAnalysis:
    """
    Full AI-driven analysis of a single ServiceRecord.

    Produced by ServiceAnalyzer. Never contains exploits or attack code —
    educational and recon guidance only.
    """
    service_address:    str            # "10.0.0.1:6379/tcp"
    protocol_name:      str

    # Explanations at two levels
    beginner_summary:   str            = ""
    technical_summary:  str            = ""

    # Risk
    risk_score:         float          = 0.0    # 0.0–10.0 (CVSS-like scale)
    risk_level:         ServiceRisk    = ServiceRisk.INFO
    risk_rationale:     str            = ""

    # Intelligence
    attack_vectors:     list[str]      = field(default_factory=list)
    misconfig_patterns: list[str]      = field(default_factory=list)
    interesting_flags:  list[str]      = field(default_factory=list)

    # Next steps
    enumeration_paths:  list[EnumerationPath] = field(default_factory=list)

    # Source
    generated_by:       str            = "static_rules"   # "static_rules" | "ai_model"

    def to_dict(self) -> dict:
        return {
            "address":         self.service_address,
            "protocol":        self.protocol_name,
            "beginner":        self.beginner_summary,
            "technical":       self.technical_summary,
            "risk_score":      self.risk_score,
            "risk_level":      self.risk_level.value,
            "attack_vectors":  self.attack_vectors,
            "misconfigs":      self.misconfig_patterns,
            "flags":           self.interesting_flags,
            "next_steps":      [{"tool": e.tool, "cmd": e.command, "why": e.purpose}
                                for e in self.enumeration_paths],
            "source":          self.generated_by,
        }


# ── Aggregated report ─────────────────────────────────────────────────────────

@dataclass
class ServiceIntelligenceReport:
    """
    Complete Stage 20 output for a target scan.
    Fed into the ReconX reporting engine and TUI panel.
    """
    target:        str
    timestamp:     float              = 0.0
    total_services: int               = 0

    services:      list[ServiceRecord]          = field(default_factory=list)
    analyses:      list[ServiceAnalysis]        = field(default_factory=list)

    # Aggregated metrics
    critical_count: int               = 0
    high_count:     int               = 0
    medium_count:   int               = 0
    low_count:      int               = 0

    # Top findings
    high_risk_services: list[ServiceRecord]     = field(default_factory=list)
    unusual_services:   list[ServiceRecord]     = field(default_factory=list)
    database_services:  list[ServiceRecord]     = field(default_factory=list)
    cloud_services:     list[ServiceRecord]     = field(default_factory=list)

    # AI summary across all services
    executive_summary:  str           = ""
    suggested_actions:  list[str]     = field(default_factory=list)

    def compute_counts(self) -> None:
        """Recompute severity counts from services list."""
        self.total_services = len(self.services)
        self.critical_count = sum(1 for s in self.services if s.risk_level == ServiceRisk.CRITICAL)
        self.high_count     = sum(1 for s in self.services if s.risk_level == ServiceRisk.HIGH)
        self.medium_count   = sum(1 for s in self.services if s.risk_level == ServiceRisk.MEDIUM)
        self.low_count      = sum(1 for s in self.services if s.risk_level == ServiceRisk.LOW)
        self.high_risk_services = [s for s in self.services
                                    if s.risk_level in (ServiceRisk.CRITICAL, ServiceRisk.HIGH)]
        self.database_services  = [s for s in self.services
                                    if s.classification and
                                    s.classification.family == ProtocolFamily.DATABASE]
        self.cloud_services     = [s for s in self.services
                                    if s.classification and
                                    s.classification.family == ProtocolFamily.CLOUD]

    def to_dict(self) -> dict:
        self.compute_counts()
        return {
            "target":        self.target,
            "timestamp":     self.timestamp,
            "total":         self.total_services,
            "critical":      self.critical_count,
            "high":          self.high_count,
            "medium":        self.medium_count,
            "low":           self.low_count,
            "services":      [s.to_dict() for s in self.services],
            "analyses":      [a.to_dict() for a in self.analyses],
            "summary":       self.executive_summary,
            "actions":       self.suggested_actions,
        }


# ── Scanner parse result ──────────────────────────────────────────────────────

@dataclass
class ScanParseResult:
    """Normalised output from any scanner parser (Nmap, Rustscan, etc.)."""
    source_tool:  str
    raw_input:    str                  = ""
    services:     list[ServiceRecord]  = field(default_factory=list)
    parse_errors: list[str]            = field(default_factory=list)
    parse_ok:     bool                 = True
