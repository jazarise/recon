"""
ReconX — Stage 20: Protocol & Service Analysis Engine
"""
from .models           import (ServiceRecord, ProtocolClassification, FingerprintResult,
                                RiskSignal, ServiceAnalysis, ServiceIntelligenceReport,
                                ScanParseResult, ProtocolFamily, ServiceRisk, FingerprintMethod)
from .knowledge_base   import lookup_port, lookup_service, PORT_DB, SERVICE_DB
from .parsers          import parse_scan_output, get_parser, NmapParser, RustscanParser, NaabuParser, MasscanParser, HTTPXParser
from .detection_engine import ProtocolDetectionEngine
from .service_analyzer import ServiceAnalyzer
from .engine           import ServiceIntelligenceEngine
from .report_injector  import inject_service_section

__all__ = [
    "ServiceRecord", "ProtocolClassification", "RiskSignal", "ServiceAnalysis",
    "ServiceIntelligenceReport", "ScanParseResult", "ProtocolFamily", "ServiceRisk",
    "lookup_port", "lookup_service", "PORT_DB", "SERVICE_DB",
    "parse_scan_output", "get_parser",
    "NmapParser", "RustscanParser", "NaabuParser", "MasscanParser", "HTTPXParser",
    "ProtocolDetectionEngine", "ServiceAnalyzer", "ServiceIntelligenceEngine",
    "inject_service_section",
]
