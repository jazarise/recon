"""
ReconX — Stage 20: Protocol Knowledge Base

Local knowledge database mapping:
  Port   → Service name + protocol family + risk baseline
  Service → Attack vectors + misconfig patterns + enumeration tools
  Service → CVE patterns (not exhaustive — advisory only)

Used by ProtocolDetectionEngine and ServiceAnalyzer.
All data is static — no network calls, no external database required.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from .models import ProtocolFamily, ServiceRisk


@dataclass
class PortEntry:
    """Knowledge record for a single port number."""
    port:          int
    name:          str
    family:        ProtocolFamily
    transport:     str           = "tcp"       # tcp | udp | both
    risk_baseline: ServiceRisk   = ServiceRisk.LOW
    encrypted:     bool          = False
    description:   str           = ""
    common_on:     list[str]     = field(default_factory=list)  # OS / product contexts


@dataclass
class ServiceEntry:
    """Deep knowledge record for a service / protocol."""
    name:              str
    family:            ProtocolFamily
    description:       str                  = ""
    beginner_explain:  str                  = ""
    risk_baseline:     ServiceRisk          = ServiceRisk.LOW

    # Intelligence
    attack_vectors:    list[str]            = field(default_factory=list)
    misconfig_patterns: list[str]           = field(default_factory=list)
    interesting_flags:  list[str]           = field(default_factory=list)

    # Tooling
    enum_tools:        list[str]            = field(default_factory=list)
    enum_commands:     list[dict]           = field(default_factory=list)  # [{tool, cmd, purpose}]

    # Version/CVE signals (advisory — not a vuln scanner)
    known_risky_versions: list[str]         = field(default_factory=list)
    cve_patterns:      list[str]            = field(default_factory=list)


# ══════════════════════════════════════════════════════════════════════════════
# Port → PortEntry catalogue (375+ common ports)
# ══════════════════════════════════════════════════════════════════════════════

PORT_DB: dict[int, PortEntry] = {
    # ── Remote access ─────────────────────────────────────────────────────────
    21:  PortEntry(21,  "FTP",     ProtocolFamily.FILE,     risk_baseline=ServiceRisk.HIGH,
                   description="File Transfer Protocol — cleartext authentication"),
    22:  PortEntry(22,  "SSH",     ProtocolFamily.REMOTE,   risk_baseline=ServiceRisk.LOW,
                   encrypted=True, description="Secure Shell — encrypted remote access"),
    23:  PortEntry(23,  "Telnet",  ProtocolFamily.REMOTE,   risk_baseline=ServiceRisk.CRITICAL,
                   description="Telnet — plaintext remote access, deprecated"),
    2222: PortEntry(2222, "SSH-alt", ProtocolFamily.REMOTE, risk_baseline=ServiceRisk.MEDIUM,
                    description="SSH on alternate port — common evasion"),
    3389: PortEntry(3389, "RDP",   ProtocolFamily.REMOTE,   risk_baseline=ServiceRisk.HIGH,
                    description="Remote Desktop Protocol — Windows GUI access"),
    5900: PortEntry(5900, "VNC",   ProtocolFamily.REMOTE,   risk_baseline=ServiceRisk.HIGH,
                    description="VNC — graphical remote desktop, often unauthenticated"),
    5901: PortEntry(5901, "VNC-1", ProtocolFamily.REMOTE,   risk_baseline=ServiceRisk.HIGH,
                    description="VNC display 1"),

    # ── Web ───────────────────────────────────────────────────────────────────
    80:   PortEntry(80,   "HTTP",   ProtocolFamily.WEB,     risk_baseline=ServiceRisk.MEDIUM,
                    description="HTTP — unencrypted web traffic"),
    443:  PortEntry(443,  "HTTPS",  ProtocolFamily.WEB,     risk_baseline=ServiceRisk.LOW,
                    encrypted=True, description="HTTPS — TLS-encrypted web"),
    8080: PortEntry(8080, "HTTP-alt", ProtocolFamily.WEB,   risk_baseline=ServiceRisk.MEDIUM,
                    description="Common alternate HTTP port — dev servers, proxies"),
    8443: PortEntry(8443, "HTTPS-alt", ProtocolFamily.WEB,  risk_baseline=ServiceRisk.MEDIUM,
                    encrypted=True, description="Alternate HTTPS port"),
    8000: PortEntry(8000, "HTTP-dev", ProtocolFamily.WEB,   risk_baseline=ServiceRisk.MEDIUM,
                    description="HTTP development server"),
    8888: PortEntry(8888, "HTTP-dev2", ProtocolFamily.WEB,  risk_baseline=ServiceRisk.MEDIUM,
                    description="Jupyter Notebook / dev HTTP"),
    3000: PortEntry(3000, "HTTP-app", ProtocolFamily.WEB,   risk_baseline=ServiceRisk.MEDIUM,
                    description="Node.js / React / Grafana default port"),
    4000: PortEntry(4000, "HTTP-app2", ProtocolFamily.WEB,  risk_baseline=ServiceRisk.MEDIUM,
                    description="Application HTTP port"),
    9000: PortEntry(9000, "HTTP-app3", ProtocolFamily.WEB,  risk_baseline=ServiceRisk.MEDIUM,
                    description="SonarQube / PHP-FPM / other app port"),
    9200: PortEntry(9200, "Elasticsearch", ProtocolFamily.DATABASE, risk_baseline=ServiceRisk.CRITICAL,
                    description="Elasticsearch REST API — often unauthenticated by default"),
    9300: PortEntry(9300, "Elasticsearch-cluster", ProtocolFamily.DATABASE,
                    risk_baseline=ServiceRisk.HIGH,
                    description="Elasticsearch cluster communication"),

    # ── Mail ──────────────────────────────────────────────────────────────────
    25:   PortEntry(25,   "SMTP",   ProtocolFamily.MAIL,    risk_baseline=ServiceRisk.MEDIUM,
                    description="SMTP — email delivery, open relay risk"),
    110:  PortEntry(110,  "POP3",   ProtocolFamily.MAIL,    risk_baseline=ServiceRisk.HIGH,
                    description="POP3 — email retrieval, cleartext"),
    143:  PortEntry(143,  "IMAP",   ProtocolFamily.MAIL,    risk_baseline=ServiceRisk.HIGH,
                    description="IMAP — email access, cleartext credentials"),
    465:  PortEntry(465,  "SMTPS",  ProtocolFamily.MAIL,    risk_baseline=ServiceRisk.LOW,
                    encrypted=True, description="SMTP over TLS"),
    587:  PortEntry(587,  "SMTP-submission", ProtocolFamily.MAIL, risk_baseline=ServiceRisk.LOW,
                    description="SMTP message submission port"),
    993:  PortEntry(993,  "IMAPS",  ProtocolFamily.MAIL,    risk_baseline=ServiceRisk.LOW,
                    encrypted=True, description="IMAP over TLS"),
    995:  PortEntry(995,  "POP3S",  ProtocolFamily.MAIL,    risk_baseline=ServiceRisk.LOW,
                    encrypted=True, description="POP3 over TLS"),

    # ── Network services ──────────────────────────────────────────────────────
    53:   PortEntry(53,   "DNS",    ProtocolFamily.NETWORK,  transport="both",
                    description="Domain Name System"),
    67:   PortEntry(67,   "DHCP",   ProtocolFamily.NETWORK,  transport="udp",
                    description="DHCP server — dynamic IP assignment"),
    123:  PortEntry(123,  "NTP",    ProtocolFamily.NETWORK,  transport="udp",
                    risk_baseline=ServiceRisk.LOW, description="Network Time Protocol"),
    161:  PortEntry(161,  "SNMP",   ProtocolFamily.NETWORK,  transport="udp",
                    risk_baseline=ServiceRisk.HIGH,
                    description="SNMP — network device management, default community strings"),
    162:  PortEntry(162,  "SNMP-trap", ProtocolFamily.NETWORK, transport="udp",
                    risk_baseline=ServiceRisk.MEDIUM, description="SNMP trap receiver"),
    389:  PortEntry(389,  "LDAP",   ProtocolFamily.DIRECTORY, risk_baseline=ServiceRisk.HIGH,
                    description="LDAP — directory services, cleartext"),
    636:  PortEntry(636,  "LDAPS",  ProtocolFamily.DIRECTORY, risk_baseline=ServiceRisk.MEDIUM,
                    encrypted=True, description="LDAP over TLS"),
    88:   PortEntry(88,   "Kerberos", ProtocolFamily.NETWORK, risk_baseline=ServiceRisk.MEDIUM,
                    description="Kerberos authentication — AD environments"),
    135:  PortEntry(135,  "MSRPC",  ProtocolFamily.NETWORK,  risk_baseline=ServiceRisk.HIGH,
                    description="Microsoft RPC — Windows services endpoint mapper"),
    137:  PortEntry(137,  "NetBIOS-ns", ProtocolFamily.NETWORK, transport="udp",
                    risk_baseline=ServiceRisk.HIGH, description="NetBIOS name service"),
    139:  PortEntry(139,  "NetBIOS-ssn", ProtocolFamily.NETWORK, risk_baseline=ServiceRisk.HIGH,
                    description="NetBIOS session service"),
    445:  PortEntry(445,  "SMB",    ProtocolFamily.FILE,     risk_baseline=ServiceRisk.CRITICAL,
                    description="SMB — Windows file sharing, EternalBlue target"),
    2049: PortEntry(2049, "NFS",    ProtocolFamily.FILE,     risk_baseline=ServiceRisk.HIGH,
                    description="NFS — network file system, often misconfigured exports"),
    111:  PortEntry(111,  "portmapper", ProtocolFamily.NETWORK, risk_baseline=ServiceRisk.MEDIUM,
                    description="RPC portmapper — enumerates services"),

    # ── Databases ─────────────────────────────────────────────────────────────
    3306: PortEntry(3306, "MySQL",       ProtocolFamily.DATABASE, risk_baseline=ServiceRisk.CRITICAL,
                    description="MySQL database — remote access enabled"),
    3307: PortEntry(3307, "MySQL-alt",   ProtocolFamily.DATABASE, risk_baseline=ServiceRisk.CRITICAL,
                    description="MySQL on alternate port"),
    5432: PortEntry(5432, "PostgreSQL",  ProtocolFamily.DATABASE, risk_baseline=ServiceRisk.CRITICAL,
                    description="PostgreSQL database"),
    1433: PortEntry(1433, "MSSQL",       ProtocolFamily.DATABASE, risk_baseline=ServiceRisk.CRITICAL,
                    description="Microsoft SQL Server"),
    1521: PortEntry(1521, "Oracle",      ProtocolFamily.DATABASE, risk_baseline=ServiceRisk.CRITICAL,
                    description="Oracle Database listener"),
    27017: PortEntry(27017, "MongoDB",   ProtocolFamily.DATABASE, risk_baseline=ServiceRisk.CRITICAL,
                     description="MongoDB — no auth by default in older versions"),
    27018: PortEntry(27018, "MongoDB-shard", ProtocolFamily.DATABASE, risk_baseline=ServiceRisk.HIGH,
                     description="MongoDB shard server"),
    6379: PortEntry(6379, "Redis",       ProtocolFamily.DATABASE, risk_baseline=ServiceRisk.CRITICAL,
                    description="Redis in-memory database — unauthenticated by default (pre-v7)"),
    6380: PortEntry(6380, "Redis-TLS",   ProtocolFamily.DATABASE, risk_baseline=ServiceRisk.MEDIUM,
                    encrypted=True, description="Redis with TLS"),
    11211: PortEntry(11211, "Memcached", ProtocolFamily.DATABASE, risk_baseline=ServiceRisk.CRITICAL,
                     description="Memcached — no authentication, data exposure"),
    5984: PortEntry(5984, "CouchDB",     ProtocolFamily.DATABASE, risk_baseline=ServiceRisk.CRITICAL,
                    description="CouchDB — HTTP REST API, admin party by default"),
    8086: PortEntry(8086, "InfluxDB",    ProtocolFamily.DATABASE, risk_baseline=ServiceRisk.HIGH,
                    description="InfluxDB time-series database"),
    9042: PortEntry(9042, "Cassandra",   ProtocolFamily.DATABASE, risk_baseline=ServiceRisk.CRITICAL,
                    description="Apache Cassandra CQL native transport"),
    2181: PortEntry(2181, "ZooKeeper",   ProtocolFamily.DATABASE, risk_baseline=ServiceRisk.HIGH,
                    description="Apache ZooKeeper — cluster coordination, often unauthenticated"),
    5601: PortEntry(5601, "Kibana",      ProtocolFamily.DATABASE, risk_baseline=ServiceRisk.CRITICAL,
                    description="Kibana web UI — Elasticsearch data visualization"),

    # ── Messaging ─────────────────────────────────────────────────────────────
    1883: PortEntry(1883, "MQTT",        ProtocolFamily.MESSAGING, risk_baseline=ServiceRisk.HIGH,
                    description="MQTT broker — IoT messaging, often unauthenticated"),
    8883: PortEntry(8883, "MQTT-TLS",    ProtocolFamily.MESSAGING, risk_baseline=ServiceRisk.MEDIUM,
                    encrypted=True, description="MQTT over TLS"),
    5672: PortEntry(5672, "AMQP",        ProtocolFamily.MESSAGING, risk_baseline=ServiceRisk.HIGH,
                    description="RabbitMQ AMQP — message broker"),
    15672: PortEntry(15672, "RabbitMQ-mgmt", ProtocolFamily.MESSAGING, risk_baseline=ServiceRisk.CRITICAL,
                     description="RabbitMQ management UI — default guest:guest credentials"),
    9092: PortEntry(9092, "Kafka",       ProtocolFamily.MESSAGING, risk_baseline=ServiceRisk.HIGH,
                    description="Apache Kafka broker — no auth by default"),
    2375: PortEntry(2375, "Docker",      ProtocolFamily.CLOUD,     risk_baseline=ServiceRisk.CRITICAL,
                    description="Docker daemon API — unauthenticated remote code execution"),
    2376: PortEntry(2376, "Docker-TLS",  ProtocolFamily.CLOUD,     risk_baseline=ServiceRisk.HIGH,
                    encrypted=True, description="Docker daemon API over TLS"),
    6443: PortEntry(6443, "Kubernetes",  ProtocolFamily.CLOUD,     risk_baseline=ServiceRisk.HIGH,
                    encrypted=True, description="Kubernetes API server"),
    10250: PortEntry(10250, "Kubelet",   ProtocolFamily.CLOUD,     risk_baseline=ServiceRisk.CRITICAL,
                     description="Kubernetes Kubelet API — remote code execution if exposed"),
    10255: PortEntry(10255, "Kubelet-ro", ProtocolFamily.CLOUD,    risk_baseline=ServiceRisk.HIGH,
                     description="Kubernetes Kubelet read-only API"),
    8472: PortEntry(8472,  "Flannel",    ProtocolFamily.CLOUD,     risk_baseline=ServiceRisk.HIGH,
                    transport="udp", description="Flannel overlay network — container escape"),
    4243: PortEntry(4243, "Docker-alt",  ProtocolFamily.CLOUD,     risk_baseline=ServiceRisk.CRITICAL,
                    description="Docker daemon alternate API port"),

    # ── CI/CD & Dev tools ──────────────────────────────────────────────────────
    8081: PortEntry(8081, "Nexus/Jenkins-alt", ProtocolFamily.WEB, risk_baseline=ServiceRisk.MEDIUM,
                    description="Nexus repository manager or Jenkins alternate"),
    50000: PortEntry(50000, "Jenkins-slave", ProtocolFamily.WEB,   risk_baseline=ServiceRisk.HIGH,
                     description="Jenkins agent port — often unauthenticated"),
    9090: PortEntry(9090, "Prometheus",  ProtocolFamily.WEB,       risk_baseline=ServiceRisk.MEDIUM,
                    description="Prometheus metrics server"),
    3001: PortEntry(3001, "Grafana-alt", ProtocolFamily.WEB,       risk_baseline=ServiceRisk.MEDIUM,
                    description="Grafana alternate port"),

    # ── Cloud metadata ──────────────────────────────────────────────────────────
    80:   PortEntry(80, "HTTP", ProtocolFamily.WEB, risk_baseline=ServiceRisk.MEDIUM,
                    description="HTTP"),  # overridden above — last write wins
}

# ══════════════════════════════════════════════════════════════════════════════
# Service → ServiceEntry knowledge
# ══════════════════════════════════════════════════════════════════════════════

SERVICE_DB: dict[str, ServiceEntry] = {

    "Redis": ServiceEntry(
        name="Redis",
        family=ProtocolFamily.DATABASE,
        description="Redis is an in-memory key-value data store used for caching, sessions, and queuing.",
        beginner_explain=(
            "Redis is a very fast database kept entirely in RAM. "
            "It is often exposed without a password because developers leave it on the default "
            "configuration. Attackers can read/write all data, set server-side scripts, "
            "and sometimes achieve remote code execution by writing to authorized_keys or cron."
        ),
        risk_baseline=ServiceRisk.CRITICAL,
        attack_vectors=[
            "Unauthenticated access — read all keys including session tokens",
            "CONFIG SET dir / CONFIG SET dbfilename — write files to disk (SSH key injection)",
            "SLAVEOF command — data exfiltration to attacker-controlled Redis",
            "Lua scripting via EVAL — code execution on the server",
            "Sentinel/Cluster mode — lateral movement across Redis nodes",
        ],
        misconfig_patterns=[
            "No requirepass configured (default pre-Redis 7)",
            "Bound to 0.0.0.0 instead of 127.0.0.1",
            "Protected-mode disabled",
            "Rename-command CONFIG '' not applied",
        ],
        interesting_flags=["Redis version < 7.0 has no default auth", "RESP3 protocol"],
        enum_tools=["redis-cli", "nmap --script redis-info", "nuclei -t redis"],
        enum_commands=[
            {"tool": "redis-cli", "cmd": "redis-cli -h {host} -p {port} INFO", "purpose": "Service information and version"},
            {"tool": "redis-cli", "cmd": "redis-cli -h {host} -p {port} KEYS *", "purpose": "List all keys"},
            {"tool": "redis-cli", "cmd": "redis-cli -h {host} -p {port} CONFIG GET *", "purpose": "Server configuration"},
            {"tool": "nmap", "cmd": "nmap -sV --script redis-info -p {port} {host}", "purpose": "Nmap Redis enumeration"},
        ],
        known_risky_versions=["< 3.2.0", "< 4.0.0"],
        cve_patterns=["CVE-2022-0543", "CVE-2021-32761"],
    ),

    "MongoDB": ServiceEntry(
        name="MongoDB",
        family=ProtocolFamily.DATABASE,
        description="MongoDB is a NoSQL document database commonly used in web applications.",
        beginner_explain=(
            "MongoDB stores data as JSON-like documents. In versions before 3.0, "
            "it had no authentication by default — meaning anyone could read your entire database. "
            "Even today, misconfigurations frequently leave it open to the internet."
        ),
        risk_baseline=ServiceRisk.CRITICAL,
        attack_vectors=[
            "Unauthenticated access to all collections and databases",
            "mongodump — dump entire database remotely",
            "$where and server-side JS injection",
            "GridFS arbitrary file read (if application exposes it)",
        ],
        misconfig_patterns=[
            "security.authorization not enabled in mongod.conf",
            "Bound to 0.0.0.0 (--bind_ip_all flag or no bind_ip setting)",
            "Default admin credentials (admin:admin)",
            "No TLS configured for inter-node communication",
        ],
        enum_tools=["mongosh", "nmap --script mongodb-info", "nuclei"],
        enum_commands=[
            {"tool": "mongosh", "cmd": "mongosh --host {host} --port {port}", "purpose": "Connect and list databases"},
            {"tool": "nmap", "cmd": "nmap -sV --script mongodb-info,mongodb-databases -p {port} {host}", "purpose": "Database enumeration"},
        ],
        known_risky_versions=["< 3.0"],
    ),

    "Elasticsearch": ServiceEntry(
        name="Elasticsearch",
        family=ProtocolFamily.DATABASE,
        description="Elasticsearch is a distributed search and analytics engine with an HTTP REST API.",
        beginner_explain=(
            "Elasticsearch exposes all its data via a REST API on port 9200. "
            "By default, older versions require no authentication. "
            "An attacker can simply open a browser, navigate to http://target:9200/_cat/indices, "
            "and see all stored data. It has leaked millions of records in public breaches."
        ),
        risk_baseline=ServiceRisk.CRITICAL,
        attack_vectors=[
            "GET /_cat/indices — list all indices",
            "GET /index/_search — read all documents",
            "DELETE /index — destroy data",
            "Groovy/Painless script injection (older versions)",
            "Snapshot API — exfiltrate data to attacker-controlled S3",
        ],
        misconfig_patterns=[
            "xpack.security.enabled: false (default in OSS versions < 8.0)",
            "network.host: 0.0.0.0 with no firewall",
            "No authentication plugin installed",
            "HTTP API exposed directly to internet",
        ],
        enum_tools=["curl", "nuclei", "es-dump"],
        enum_commands=[
            {"tool": "curl", "cmd": "curl http://{host}:{port}/_cat/indices?v", "purpose": "List all indices"},
            {"tool": "curl", "cmd": "curl http://{host}:{port}/_cluster/health", "purpose": "Cluster status"},
            {"tool": "curl", "cmd": "curl http://{host}:{port}/_security/user", "purpose": "Check security config"},
        ],
        known_risky_versions=["< 8.0.0"],
    ),

    "SMB": ServiceEntry(
        name="SMB",
        family=ProtocolFamily.FILE,
        description="Server Message Block — Windows file and printer sharing protocol.",
        beginner_explain=(
            "SMB on port 445 is the Windows file-sharing protocol. "
            "It has been responsible for some of the most devastating attacks in history, "
            "including WannaCry (EternalBlue). Even when patched, SMB exposes shares "
            "that may contain sensitive files or allow null session authentication."
        ),
        risk_baseline=ServiceRisk.CRITICAL,
        attack_vectors=[
            "EternalBlue (CVE-2017-0144) — unauthenticated RCE on unpatched Windows",
            "SMB relay attack — capture and relay NTLM authentication",
            "Null session enumeration — list shares, users, groups without credentials",
            "Brute-force SMB authentication",
            "Pass-the-hash — reuse captured NTLM hashes",
        ],
        misconfig_patterns=[
            "SMBv1 enabled (EternalBlue prerequisite)",
            "Guest access enabled on shares",
            "Sensitive files in world-readable shares",
            "SMB signing disabled (relay attack prerequisite)",
            "Exposed to internet (should be internal only)",
        ],
        enum_tools=["smbmap", "smbclient", "enum4linux", "crackmapexec", "nmap --script smb-*"],
        enum_commands=[
            {"tool": "nmap", "cmd": "nmap --script smb-vuln-ms17-010 -p 445 {host}", "purpose": "EternalBlue detection"},
            {"tool": "smbmap", "cmd": "smbmap -H {host}", "purpose": "Enumerate SMB shares"},
            {"tool": "enum4linux", "cmd": "enum4linux -a {host}", "purpose": "Full SMB enumeration"},
            {"tool": "smbclient", "cmd": "smbclient -L //{host} -N", "purpose": "List shares without credentials"},
        ],
        cve_patterns=["CVE-2017-0144", "CVE-2020-0796", "CVE-2021-1675"],
    ),

    "FTP": ServiceEntry(
        name="FTP",
        family=ProtocolFamily.FILE,
        description="File Transfer Protocol — cleartext file transfer service.",
        beginner_explain=(
            "FTP transmits usernames, passwords, and file contents in cleartext. "
            "Anyone on the network path can intercept these credentials. "
            "Anonymous FTP access is a frequent misconfiguration that allows "
            "anyone to download or upload files without a password."
        ),
        risk_baseline=ServiceRisk.HIGH,
        attack_vectors=[
            "Anonymous login — access files without credentials",
            "Credential sniffing — cleartext protocol, visible on network",
            "Brute force authentication",
            "FTP bounce attack — use server to port-scan internal networks",
            "Write access to web root — upload webshell via FTP",
        ],
        misconfig_patterns=[
            "Anonymous FTP enabled",
            "World-writable directories",
            "FTP root is web root (webshell upload path)",
            "Weak/default credentials (admin:admin, ftp:ftp)",
        ],
        enum_tools=["nmap --script ftp-*", "hydra", "ftp"],
        enum_commands=[
            {"tool": "nmap", "cmd": "nmap --script ftp-anon,ftp-syst -p 21 {host}", "purpose": "Check anonymous access"},
            {"tool": "ftp", "cmd": "ftp {host}", "purpose": "Interactive FTP session"},
            {"tool": "hydra", "cmd": "hydra -l admin -P /usr/share/wordlists/rockyou.txt ftp://{host}", "purpose": "Brute force (authorised only)"},
        ],
    ),

    "SSH": ServiceEntry(
        name="SSH",
        family=ProtocolFamily.REMOTE,
        description="Secure Shell — encrypted remote access protocol.",
        beginner_explain=(
            "SSH provides encrypted access to remote servers. "
            "While the protocol itself is secure, common misconfigurations include "
            "password authentication enabled, root login permitted, and weak keys. "
            "The version banner reveals the exact SSH software version."
        ),
        risk_baseline=ServiceRisk.LOW,
        attack_vectors=[
            "Password brute force — especially weak or default credentials",
            "Old SSH versions with known vulnerabilities",
            "Username enumeration (OpenSSH < 7.7 CVE-2018-15473)",
            "Weak host key algorithms",
            "SSH agent hijacking",
        ],
        misconfig_patterns=[
            "PasswordAuthentication yes (prefer keys only)",
            "PermitRootLogin yes",
            "Protocol 1 support (SSHv1 deprecated)",
            "Empty passphrase private keys accessible",
        ],
        enum_tools=["nmap --script ssh-*", "ssh-audit", "hydra"],
        enum_commands=[
            {"tool": "nmap", "cmd": "nmap --script ssh-hostkey,ssh-auth-methods -p {port} {host}", "purpose": "SSH configuration enumeration"},
            {"tool": "ssh-audit", "cmd": "ssh-audit {host}:{port}", "purpose": "SSH security audit"},
        ],
        cve_patterns=["CVE-2018-15473", "CVE-2023-38408"],
    ),

    "Telnet": ServiceEntry(
        name="Telnet",
        family=ProtocolFamily.REMOTE,
        description="Legacy plaintext remote access protocol — should not be in production.",
        beginner_explain=(
            "Telnet is like SSH but without any encryption. "
            "Every keystroke including your password is sent as plaintext. "
            "Finding Telnet on the internet in 2024 is a serious red flag — "
            "it suggests old/legacy infrastructure or IoT devices."
        ),
        risk_baseline=ServiceRisk.CRITICAL,
        attack_vectors=[
            "Credential theft via network sniffing",
            "Default credentials on routers/IoT (admin:admin, root:root)",
            "Session hijacking",
            "Brute force",
        ],
        misconfig_patterns=["Telnet should not be running — replace with SSH"],
        enum_tools=["nmap", "telnet", "hydra"],
        enum_commands=[
            {"tool": "nmap", "cmd": "nmap --script telnet-ntlm-info -p 23 {host}", "purpose": "Telnet banner and info"},
        ],
    ),

    "RDP": ServiceEntry(
        name="RDP",
        family=ProtocolFamily.REMOTE,
        description="Remote Desktop Protocol — Windows graphical remote access.",
        beginner_explain=(
            "RDP provides graphical remote access to Windows machines. "
            "Internet-facing RDP is one of the most common ransomware entry points. "
            "Brute force, BlueKeep, and credential stuffing are all viable attacks."
        ),
        risk_baseline=ServiceRisk.HIGH,
        attack_vectors=[
            "Brute force — many wordlists specifically target RDP",
            "BlueKeep (CVE-2019-0708) — pre-auth RCE on unpatched Windows",
            "DejaBlue (CVE-2019-1181/1182) — similar to BlueKeep",
            "Pass-the-hash to RDP with restricted admin mode",
            "Credential stuffing from breach data",
        ],
        misconfig_patterns=[
            "RDP exposed directly to internet (VPN preferred)",
            "Network Level Authentication (NLA) disabled",
            "Weak/default credentials",
            "Unpatched Windows with BlueKeep/DejaBlue",
        ],
        enum_tools=["nmap --script rdp-*", "crowbar", "hydra"],
        enum_commands=[
            {"tool": "nmap", "cmd": "nmap --script rdp-vuln-ms12-020,rdp-enum-encryption -p 3389 {host}", "purpose": "RDP vulnerability and encryption check"},
        ],
        cve_patterns=["CVE-2019-0708", "CVE-2019-1181", "CVE-2019-1182"],
    ),

    "SNMP": ServiceEntry(
        name="SNMP",
        family=ProtocolFamily.NETWORK,
        description="Simple Network Management Protocol — device management over UDP.",
        beginner_explain=(
            "SNMP is used to monitor and manage network devices like routers and switches. "
            "SNMPv1 and v2c use community strings as passwords — "
            "the default 'public' and 'private' are still widely used, "
            "giving attackers full device information or even write access."
        ),
        risk_baseline=ServiceRisk.HIGH,
        attack_vectors=[
            "Default community strings (public/private) — enumerate device info",
            "SNMPv1/v2c — community string in cleartext",
            "SNMP write access — change device configuration",
            "sysDescr / interfaces — full network topology disclosure",
        ],
        misconfig_patterns=[
            "Community string 'public' enabled",
            "SNMPv1/v2c used instead of SNMPv3",
            "SNMP exposed on WAN interface",
            "Write community enabled",
        ],
        enum_tools=["snmpwalk", "onesixtyone", "nmap --script snmp-*", "snmpenum"],
        enum_commands=[
            {"tool": "snmpwalk", "cmd": "snmpwalk -c public -v2c {host}", "purpose": "Full SNMP walk with default community"},
            {"tool": "onesixtyone", "cmd": "onesixtyone -c /usr/share/doc/onesixtyone/dict.txt {host}", "purpose": "Community string brute force"},
            {"tool": "nmap", "cmd": "nmap -sU --script snmp-info -p 161 {host}", "purpose": "SNMP service information"},
        ],
    ),

    "MySQL": ServiceEntry(
        name="MySQL",
        family=ProtocolFamily.DATABASE,
        description="MySQL relational database management system.",
        beginner_explain=(
            "MySQL is one of the most popular databases. "
            "Finding it directly exposed to the internet is dangerous — "
            "attackers can attempt to login with default credentials and "
            "potentially read or destroy all application data."
        ),
        risk_baseline=ServiceRisk.CRITICAL,
        attack_vectors=[
            "Remote login with default/weak credentials (root:root, root:mysql)",
            "SELECT INTO OUTFILE — write files to server disk",
            "UDF exploitation — load malicious shared libraries",
            "Data exfiltration via mysqldump",
        ],
        misconfig_patterns=[
            "MySQL bound to 0.0.0.0 instead of 127.0.0.1",
            "Remote root login enabled",
            "Weak or no root password",
            "GRANT ALL PRIVILEGES TO '%'",
        ],
        enum_tools=["mysql", "nmap --script mysql-*", "hydra", "sqlmap"],
        enum_commands=[
            {"tool": "nmap", "cmd": "nmap --script mysql-info,mysql-databases,mysql-empty-password -p 3306 {host}", "purpose": "MySQL enumeration and empty password check"},
            {"tool": "mysql", "cmd": "mysql -h {host} -P {port} -u root --password=", "purpose": "Connect with empty root password"},
        ],
    ),

    "LDAP": ServiceEntry(
        name="LDAP",
        family=ProtocolFamily.DIRECTORY,
        description="Lightweight Directory Access Protocol — enterprise directory services.",
        beginner_explain=(
            "LDAP is used by Active Directory and other directory services to store "
            "users, groups, and computer accounts. "
            "Anonymous bind (connecting without credentials) often exposes user lists "
            "including email addresses, group memberships, and sometimes password hints."
        ),
        risk_baseline=ServiceRisk.HIGH,
        attack_vectors=[
            "Anonymous bind — enumerate users, groups, OUs",
            "ASREPRoasting — request TGT for users without pre-auth required",
            "Kerberoasting — request service tickets for cracking",
            "LDAP injection in web applications using LDAP backend",
        ],
        misconfig_patterns=[
            "Anonymous bind enabled",
            "Null base DN accessible",
            "User attributes containing sensitive data (passwords, notes)",
            "LDAP on cleartext port 389 instead of LDAPS 636",
        ],
        enum_tools=["ldapsearch", "nmap --script ldap-*", "enum4linux-ng", "ldapdomaindump"],
        enum_commands=[
            {"tool": "ldapsearch", "cmd": "ldapsearch -x -H ldap://{host} -b 'dc=example,dc=com'", "purpose": "Anonymous LDAP enumeration"},
            {"tool": "nmap", "cmd": "nmap --script ldap-rootdse,ldap-search -p 389 {host}", "purpose": "LDAP root DSE and search"},
        ],
    ),

    "Docker": ServiceEntry(
        name="Docker",
        family=ProtocolFamily.CLOUD,
        description="Docker daemon API — container management REST API.",
        beginner_explain=(
            "The Docker daemon API on port 2375 (or 2376 with TLS) allows full control "
            "over containers on the host. Without authentication, an attacker can start "
            "a container that mounts the host filesystem — achieving full host takeover "
            "with trivial effort."
        ),
        risk_baseline=ServiceRisk.CRITICAL,
        attack_vectors=[
            "Container escape via host filesystem mount",
            "Privileged container breakout",
            "Access host keys, credentials from mounted volumes",
            "Deploy cryptominer containers",
            "Pivot to internal network via container networking",
        ],
        misconfig_patterns=[
            "Docker daemon listening on TCP without TLS (port 2375)",
            "No client certificate authentication even with TLS (port 2376)",
            "Docker socket exposed via bind mount in containers",
        ],
        enum_tools=["curl", "docker", "nuclei"],
        enum_commands=[
            {"tool": "curl", "cmd": "curl http://{host}:{port}/v1.41/containers/json", "purpose": "List running containers"},
            {"tool": "curl", "cmd": "curl http://{host}:{port}/v1.41/info", "purpose": "Docker daemon information"},
            {"tool": "docker", "cmd": "docker -H tcp://{host}:{port} ps", "purpose": "List containers"},
        ],
    ),

    "Kubernetes": ServiceEntry(
        name="Kubernetes",
        family=ProtocolFamily.CLOUD,
        description="Kubernetes API server — orchestrates containerised workloads.",
        beginner_explain=(
            "The Kubernetes API server controls your entire container cluster. "
            "If it's exposed without authentication, an attacker can read all secrets "
            "(database passwords, API keys), deploy backdoor containers, "
            "and exfiltrate data from the entire infrastructure."
        ),
        risk_baseline=ServiceRisk.HIGH,
        attack_vectors=[
            "Anonymous API access — list secrets, pods, configmaps",
            "Misconfigured RBAC — over-permissioned service accounts",
            "Kubelet API on port 10250 — RCE via exec endpoint",
            "etcd on port 2379 — raw key-value storage including secrets",
            "Container escape to node",
        ],
        misconfig_patterns=[
            "Anonymous authentication enabled (--anonymous-auth=true)",
            "RBAC not enabled or permissive ClusterRoleBindings",
            "Kubelet port 10250 exposed without authentication",
            "etcd port 2379 without TLS client auth",
        ],
        enum_tools=["kubectl", "kube-hunter", "nuclei", "curl"],
        enum_commands=[
            {"tool": "curl", "cmd": "curl -k https://{host}:{port}/api/v1/namespaces", "purpose": "List namespaces (anonymous)"},
            {"tool": "kubectl", "cmd": "kubectl --server https://{host}:{port} --insecure-skip-tls-verify get pods --all-namespaces", "purpose": "List pods"},
            {"tool": "kube-hunter", "cmd": "kube-hunter --remote {host}", "purpose": "Kubernetes security audit"},
        ],
    ),

    "HTTP": ServiceEntry(
        name="HTTP",
        family=ProtocolFamily.WEB,
        description="Hypertext Transfer Protocol — unencrypted web service.",
        beginner_explain=(
            "HTTP serves websites without encryption. Credentials submitted over HTTP "
            "are visible to anyone on the network path. Look for admin panels, "
            "login pages, API endpoints, and software version banners."
        ),
        risk_baseline=ServiceRisk.MEDIUM,
        attack_vectors=[
            "Cleartext credential interception",
            "Web application vulnerabilities (SQLi, XSS, RCE)",
            "Directory traversal and path disclosure",
            "Default admin credentials",
            "Sensitive file exposure (/.git, /.env, /backup)",
        ],
        misconfig_patterns=[
            "Admin panel exposed to internet",
            "Default credentials on CMS (admin:admin, admin:password)",
            "Directory listing enabled",
            "Debug mode / development server on production port",
            "Missing security headers (HSTS, CSP, X-Frame-Options)",
        ],
        enum_tools=["httpx", "gobuster", "feroxbuster", "nikto", "nuclei"],
        enum_commands=[
            {"tool": "httpx", "cmd": "httpx -u http://{host}:{port} -title -tech-detect -status-code", "purpose": "Web fingerprinting"},
            {"tool": "gobuster", "cmd": "gobuster dir -u http://{host}:{port} -w /usr/share/wordlists/dirb/common.txt", "purpose": "Directory enumeration"},
            {"tool": "nikto", "cmd": "nikto -h http://{host}:{port}", "purpose": "Web vulnerability scan"},
            {"tool": "nuclei", "cmd": "nuclei -u http://{host}:{port} -severity critical,high,medium", "purpose": "Vulnerability templates"},
        ],
    ),

    "HTTPS": ServiceEntry(
        name="HTTPS",
        family=ProtocolFamily.WEB,
        description="HTTP over TLS — encrypted web service.",
        beginner_explain=(
            "HTTPS encrypts web traffic using TLS. Check the certificate for "
            "additional hostnames via SAN fields, expiry, and issuer. "
            "The same web vulnerabilities as HTTP apply — encryption doesn't prevent SQLi."
        ),
        risk_baseline=ServiceRisk.LOW,
        attack_vectors=[
            "Web application vulnerabilities despite encryption",
            "TLS misconfiguration (weak ciphers, legacy versions)",
            "Certificate transparency log mining for subdomains",
            "SSRF via internal HTTPS endpoints",
        ],
        misconfig_patterns=[
            "TLS 1.0/1.1 still enabled",
            "Self-signed certificate (no chain of trust)",
            "Expired certificate",
            "Weak cipher suites (RC4, DES, NULL)",
        ],
        enum_tools=["httpx", "testssl.sh", "sslscan", "nuclei"],
        enum_commands=[
            {"tool": "httpx", "cmd": "httpx -u https://{host}:{port} -title -tech-detect -tls-grab", "purpose": "HTTPS fingerprinting with TLS info"},
            {"tool": "testssl.sh", "cmd": "testssl.sh {host}:{port}", "purpose": "TLS configuration analysis"},
            {"tool": "sslscan", "cmd": "sslscan {host}:{port}", "purpose": "SSL/TLS cipher enumeration"},
        ],
    ),
}

# Aliases for common name variants
SERVICE_DB["redis"] = SERVICE_DB["Redis"]
SERVICE_DB["mongodb"] = SERVICE_DB["MongoDB"]
SERVICE_DB["elasticsearch"] = SERVICE_DB["Elasticsearch"]
SERVICE_DB["smb"] = SERVICE_DB["SMB"]
SERVICE_DB["ftp"] = SERVICE_DB["FTP"]
SERVICE_DB["ssh"] = SERVICE_DB["SSH"]
SERVICE_DB["telnet"] = SERVICE_DB["Telnet"]
SERVICE_DB["rdp"] = SERVICE_DB["RDP"]
SERVICE_DB["snmp"] = SERVICE_DB["SNMP"]
SERVICE_DB["mysql"] = SERVICE_DB["MySQL"]
SERVICE_DB["ldap"] = SERVICE_DB["LDAP"]
SERVICE_DB["docker"] = SERVICE_DB["Docker"]
SERVICE_DB["kubernetes"] = SERVICE_DB["Kubernetes"]
SERVICE_DB["http"] = SERVICE_DB["HTTP"]
SERVICE_DB["https"] = SERVICE_DB["HTTPS"]


def lookup_port(port: int) -> PortEntry | None:
    """Return PortEntry for a port number, or None if not in DB."""
    return PORT_DB.get(port)


def lookup_service(name: str) -> ServiceEntry | None:
    """Return ServiceEntry for a service name (case-insensitive)."""
    return SERVICE_DB.get(name) or SERVICE_DB.get(name.lower())
