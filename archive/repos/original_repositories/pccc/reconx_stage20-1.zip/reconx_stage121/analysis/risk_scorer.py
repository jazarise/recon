"""
ReconX — Risk Scorer.
Produces a 0–100 risk score and A–F grade from aggregated findings.
Higher score = higher risk.
"""
from __future__ import annotations
import logging

from ..models.findings import ReconResult, RiskScore

logger = logging.getLogger("reconx.analysis.risk_scorer")

# Severity weights
_CVE_WEIGHT  = {"CRITICAL": 20, "HIGH": 12, "MEDIUM": 6, "LOW": 2}
_SENS_WEIGHT = {"CRITICAL": 15, "HIGH": 10, "MEDIUM": 5, "LOW": 2}
_HEADER_WEIGHT   = 3    # per missing/weak required header
_TAKEOVER_WEIGHT = 20   # per takeover candidate
_EXPIRED_TLS     = 15
_EXPIRING_TLS    = 8    # < 30 days
_SELF_SIGNED_TLS = 10
_DANGEROUS_PORTS = {21: 8, 23: 10, 445: 15, 3389: 12, 3306: 10, 6379: 12,
                    27017: 10, 5432: 8, 1433: 10, 11211: 8}

_GRADE_MAP = [
    (0,  15, "A"),
    (16, 30, "B"),
    (31, 50, "C"),
    (51, 70, "D"),
    (71, 100, "F"),
]


class RiskScorer:
    def score(self, result: ReconResult) -> RiskScore:
        breakdown: dict[str, int] = {}
        total = 0

        # ── CVE matches ───────────────────────────────────────────────────────
        cve_pts = sum(_CVE_WEIGHT.get(c.severity.upper(), 0) for c in result.cve_matches)
        # Cap CVE contribution to avoid infinite score on many CVEs
        cve_pts = min(cve_pts, 40)
        if cve_pts:
            breakdown["CVE Findings"] = cve_pts
            total += cve_pts

        # ── Sensitive findings ────────────────────────────────────────────────
        sens_pts = sum(_SENS_WEIGHT.get(f.severity.upper(), 0) for f in result.sensitive_findings)
        sens_pts = min(sens_pts, 25)
        if sens_pts:
            breakdown["Sensitive Exposures"] = sens_pts
            total += sens_pts

        # ── Dangerous open ports ──────────────────────────────────────────────
        port_pts = sum(_DANGEROUS_PORTS.get(p.number, 0) for p in result.ports)
        port_pts = min(port_pts, 30)
        if port_pts:
            breakdown["Dangerous Open Ports"] = port_pts
            total += port_pts

        # ── HTTP header gaps ──────────────────────────────────────────────────
        bad_headers = [h for h in result.header_findings if h.status in ("missing", "weak")]
        hdr_pts = len(bad_headers) * _HEADER_WEIGHT
        hdr_pts = min(hdr_pts, 15)
        if hdr_pts:
            breakdown["Missing/Weak Security Headers"] = hdr_pts
            total += hdr_pts

        # ── Takeover candidates ───────────────────────────────────────────────
        to_pts = len(result.takeover_candidates) * _TAKEOVER_WEIGHT
        to_pts = min(to_pts, 30)
        if to_pts:
            breakdown["Subdomain Takeover Risk"] = to_pts
            total += to_pts

        # ── TLS issues ────────────────────────────────────────────────────────
        if result.tls_info:
            tls = result.tls_info
            tls_pts = 0
            if tls.is_expired:
                tls_pts += _EXPIRED_TLS
                breakdown["Expired TLS Certificate"] = _EXPIRED_TLS
            elif 0 <= tls.days_remaining <= 30:
                tls_pts += _EXPIRING_TLS
                breakdown["TLS Certificate Expiring Soon"] = _EXPIRING_TLS
            if tls.is_self_signed:
                tls_pts += _SELF_SIGNED_TLS
                breakdown["Self-Signed Certificate"] = _SELF_SIGNED_TLS
            total += tls_pts

        total = min(total, 100)

        grade = "A"
        for lo, hi, g in _GRADE_MAP:
            if lo <= total <= hi:
                grade = g
                break

        return RiskScore(total=total, grade=grade, breakdown=breakdown)
