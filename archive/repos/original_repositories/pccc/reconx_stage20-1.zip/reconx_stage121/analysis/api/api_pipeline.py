"""
ReconX — Stage 11: API Intelligence Pipeline.

Orchestrates all API reconnaissance and analysis modules:

  Target URL
    ↓ APIFingerprint          → framework / gateway detection
    ↓ SwaggerParser           → OpenAPI spec discovery & parsing
    ↓ GraphQLTool             → endpoint discovery & schema introspection
    ↓ KiterunnerTool          → hidden route discovery
    ↓ ArjunTool               → parameter discovery
    ↓ AuthAnalyzer            → auth mechanism analysis
    ↓ RouteCorrelator         → unified endpoint map
    ↓ ParameterMapper         → structured parameter inventory
    ↓ GraphQLAnalyzer         → schema risk analysis
    ↓ APISurfaceMapper        → attack surface graph
    ↓ APIRiskScoring          → overall risk score
    ↓ APIIntelligenceReport   (final output)

Rich terminal display with live progress.
"""
from __future__ import annotations

import json
import logging
import os
import time
from datetime import datetime
from typing import Optional

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich import box

from ...models.api_models import APIIntelligenceReport, RiskLevel
from ..api.api_surface_mapper import (
    APISurfaceMapper, GraphQLAnalyzer, AuthRiskEngine, APIRiskScoring,
)
from ...tools.api.swagger_parser import SwaggerParser
from ...tools.api.graphql_tool import GraphQLTool
from ...tools.api.kiterunner_tool import KiterunnerTool
from ...tools.api.arjun_tool import ArjunTool
from ...tools.api.api_fingerprint import APIFingerprint, AuthAnalyzer, ParameterMapper, RouteCorrelator

logger = logging.getLogger("reconx.analysis.api.pipeline")

SEV_STYLE = {
    "CRITICAL": "bold red",
    "HIGH":     "red",
    "MEDIUM":   "yellow",
    "LOW":      "cyan",
    "INFO":     "dim",
}


class APIPipelineConfig:
    """Configuration for an API intelligence pipeline run."""
    def __init__(
        self,
        run_fingerprint: bool = True,
        run_swagger:     bool = True,
        run_graphql:     bool = True,
        run_kiterunner:  bool = False,    # opt-in (active, noisy)
        run_arjun:       bool = False,    # opt-in (active, noisy)
        run_auth:        bool = True,
        graphql_introspect: bool = True,
        swagger_spec_url: Optional[str] = None,
        custom_headers:  Optional[dict] = None,
        timeout_per_req: float = 8.0,
        kiterunner_wordlist: Optional[str] = None,
        probe_paths:     Optional[list[str]] = None,
    ):
        self.run_fingerprint      = run_fingerprint
        self.run_swagger          = run_swagger
        self.run_graphql          = run_graphql
        self.run_kiterunner       = run_kiterunner
        self.run_arjun            = run_arjun
        self.run_auth             = run_auth
        self.graphql_introspect   = graphql_introspect
        self.swagger_spec_url     = swagger_spec_url
        self.custom_headers       = custom_headers or {}
        self.timeout_per_req      = timeout_per_req
        self.kiterunner_wordlist  = kiterunner_wordlist
        self.probe_paths          = probe_paths


class APIPipeline:
    """Orchestrates all Stage 11 API intelligence modules."""

    def __init__(self, console: Optional[Console] = None) -> None:
        self._console    = console or Console()
        self._fp         = APIFingerprint()
        self._swagger    = SwaggerParser()
        self._graphql    = GraphQLTool()
        self._kr         = KiterunnerTool()
        self._arjun      = ArjunTool()
        self._auth       = AuthAnalyzer()
        self._correlator = RouteCorrelator()
        self._param_map  = ParameterMapper()
        self._gql_analy  = GraphQLAnalyzer()
        self._surface    = APISurfaceMapper()
        self._auth_risk  = AuthRiskEngine()
        self._api_risk   = APIRiskScoring()

    def run(
        self,
        target:  str,
        config:  Optional[APIPipelineConfig] = None,
    ) -> APIIntelligenceReport:
        cfg = config or APIPipelineConfig()
        t0  = time.perf_counter()
        ts  = datetime.now().strftime("%Y%m%d_%H%M%S")

        self._print_header(target)

        all_endpoints:    list[dict] = []
        all_params_raw:   list[dict] = []
        all_auth_findings: list[dict] = []
        graphql_schemas:  list[dict] = []
        swagger_specs:    list[str]  = []
        frameworks:       list[str]  = []
        gateways:         list[str]  = []
        errors:           list[str]  = []

        # ── Step 1: API Fingerprint ───────────────────────────────────────────
        if cfg.run_fingerprint:
            fp_res = self._fp.run(
                target, headers=cfg.custom_headers, timeout_per=cfg.timeout_per_req
            )
            if fp_res.ok:
                d = fp_res.data
                frameworks.extend(d.get("frameworks", []))
                gateways.extend(d.get("gateways", []))
                self._status("API Fingerprint",
                             f"frameworks={d.get('frameworks', [])}, gateways={d.get('gateways', [])}")
            else:
                self._warn(f"Fingerprint: {fp_res.error.message if fp_res.error else 'failed'}")

        # ── Step 2: Swagger / OpenAPI Discovery ───────────────────────────────
        if cfg.run_swagger:
            sw_res = self._swagger.run(
                target,
                spec_url=cfg.swagger_spec_url,
                headers=cfg.custom_headers,
                timeout_per=cfg.timeout_per_req,
            )
            if sw_res.ok:
                d   = sw_res.data
                eps = d.get("endpoints", [])
                all_endpoints.extend(eps)
                all_params_raw.extend(d.get("parameters", []))
                swagger_specs.extend(d.get("specs_found", []))
                self._status(
                    "Swagger/OpenAPI",
                    f"{len(d.get('specs_found', []))} spec(s), "
                    f"{len(eps)} endpoints, {len(d.get('parameters', []))} params"
                )
                if swagger_specs:
                    self._warn(f"⚠ API spec exposed: {swagger_specs[0]}")
            else:
                self._status("Swagger/OpenAPI", "no specs found")

        # ── Step 3: GraphQL Analysis ──────────────────────────────────────────
        if cfg.run_graphql:
            gql_res = self._graphql.run(
                target,
                headers=cfg.custom_headers,
                test_introspect=cfg.graphql_introspect,
                timeout_per_req=cfg.timeout_per_req,
            )
            if gql_res.ok:
                d   = gql_res.data
                eps = d.get("endpoints", [])
                all_endpoints.extend(eps)
                graphql_schemas.extend(d.get("schemas", []))
                all_auth_findings.extend(d.get("auth_findings", []))
                introspect_on = d.get("introspection_enabled", False)
                self._status(
                    "GraphQL",
                    f"{len(eps)} endpoint(s), introspection={'✓' if introspect_on else '✗'}, "
                    f"{len(d.get('auth_findings', []))} auth issues"
                )
                if introspect_on:
                    self._warn("GraphQL introspection enabled — full schema exposed")
            else:
                self._status("GraphQL", "no GraphQL endpoints found")

        # ── Step 4: Kiterunner (opt-in) ───────────────────────────────────────
        if cfg.run_kiterunner:
            kr_res = self._kr.run(
                target,
                wordlist=cfg.kiterunner_wordlist,
                headers=cfg.custom_headers,
            )
            if kr_res.ok:
                eps = kr_res.data.get("endpoints", [])
                all_endpoints.extend(eps)
                self._status("Kiterunner", f"{len(eps)} routes discovered")
            else:
                self._warn(f"Kiterunner: {kr_res.error.message if kr_res.error else 'skipped'}")

        # ── Step 5: Arjun parameter discovery (opt-in) ────────────────────────
        if cfg.run_arjun and all_endpoints:
            ep_urls = [e.get("full_url") or e.get("url", "") for e in all_endpoints[:5]]
            for ep_url in ep_urls:
                if not ep_url:
                    continue
                ar_res = self._arjun.run(ep_url, headers=cfg.custom_headers)
                if ar_res.ok:
                    all_params_raw.extend(ar_res.data.get("parameters", []))
            self._status("Arjun", f"{len(all_params_raw)} parameters discovered")

        # ── Step 6: Auth Analysis ─────────────────────────────────────────────
        if cfg.run_auth:
            ep_urls = list(dict.fromkeys(
                e.get("full_url") or e.get("url", "") for e in all_endpoints
            ))[:20]
            auth_res = self._auth.run(
                target, endpoints=ep_urls, headers=cfg.custom_headers,
                timeout_per=cfg.timeout_per_req,
            )
            if auth_res.ok:
                afs = auth_res.data.get("auth_findings", [])
                all_auth_findings.extend(afs)
                self._status("Auth Analyzer", f"{len(afs)} auth findings")

        # ── Step 7: Route Correlation ─────────────────────────────────────────
        correlated = self._correlator.correlate(all_endpoints)
        unified_eps = correlated.get("endpoints", [])
        self._status(
            "Route Correlator",
            f"{len(unified_eps)} unique endpoints "
            f"({correlated.get('hidden', 0)} hidden, "
            f"{correlated.get('confirmed', 0)} confirmed)"
        )

        # ── Step 8: Parameter Mapping ─────────────────────────────────────────
        params = self._param_map.map(all_params_raw)
        param_summary = self._param_map.summarise(params)
        self._status(
            "Parameter Mapper",
            f"{param_summary['total']} params — "
            f"sensitive={param_summary['sensitive']}, "
            f"injection candidates={param_summary['injection_candidates']}"
        )

        # ── Step 9: GraphQL Analysis ──────────────────────────────────────────
        gql_analyses: list[dict] = []
        for schema in graphql_schemas:
            analysis = self._gql_analy.analyse(schema)
            gql_analyses.append(analysis)
        if gql_analyses:
            max_risk = max(a.get("risk_score", 0) for a in gql_analyses)
            self._status("GraphQL Analyzer", f"max risk score {max_risk:.1f}/10")

        # ── Step 10: Surface Mapping ──────────────────────────────────────────
        surface = self._surface.map(
            unified_eps, graphql_schemas, all_auth_findings,
            [{"name": p.name, "is_sensitive": p.is_sensitive} for p in params],
        )
        self._status(
            "Surface Mapper",
            f"{surface['node_count']} nodes, {surface['edge_count']} edges"
        )

        # ── Step 11: Risk Scoring ─────────────────────────────────────────────
        params_raw_for_score = [{"is_sensitive": p.is_sensitive} for p in params]
        risk_score, risk_level, risk_summary = self._api_risk.score(
            unified_eps, graphql_schemas, all_auth_findings, swagger_specs, params_raw_for_score,
        )
        auth_risk = self._auth_risk.score(all_auth_findings)

        duration = time.perf_counter() - t0

        # ── Assemble Report ───────────────────────────────────────────────────
        report = APIIntelligenceReport(
            target          = target,
            timestamp       = ts,
            endpoints       = [],          # simplified for final report
            graphql_schemas = [],
            parameters      = params,
            auth_findings   = [],
            total_endpoints = len(unified_eps),
            hidden_endpoints = correlated.get("hidden", 0),
            graphql_count   = len(graphql_schemas),
            auth_risk_count = len(all_auth_findings),
            frameworks      = list(dict.fromkeys(frameworks)),
            gateways        = list(dict.fromkeys(gateways)),
            api_versions    = list(correlated.get("version_groups", {}).keys()),
            swagger_specs   = swagger_specs,
            risk_score      = risk_score,
            risk_level      = risk_level,
            executive_summary = risk_summary,
            stats = {
                "total_endpoints":   len(unified_eps),
                "hidden_endpoints":  correlated.get("hidden", 0),
                "swagger_specs":     len(swagger_specs),
                "graphql_endpoints": len(graphql_schemas),
                "auth_findings":     len(all_auth_findings),
                "parameters":        len(params),
                "sensitive_params":  param_summary["sensitive"],
                "frameworks":        frameworks,
                "gateways":          gateways,
                "risk_score":        risk_score,
                "auth_risk":         auth_risk,
                "gql_analyses":      gql_analyses,
                "surface":           {
                    "node_count": surface["node_count"],
                    "edge_count": surface["edge_count"],
                    "hidden":     surface.get("hidden_endpoints", 0),
                },
                "duration_s":        round(duration, 2),
                "errors":            errors,
            },
        )

        self._print_results(report, unified_eps, all_auth_findings, gql_analyses)
        return report

    # ── Rich output ───────────────────────────────────────────────────────────

    def _print_header(self, target: str) -> None:
        self._console.print()
        self._console.print(Panel.fit(
            f"[bold cyan][ API Intelligence ][/bold cyan]\n"
            f"[white]Target:[/white] [yellow]{target}[/yellow]",
            border_style="cyan",
        ))
        self._console.print()

    def _print_results(
        self,
        report:        APIIntelligenceReport,
        endpoints:     list[dict],
        auth_findings: list[dict],
        gql_analyses:  list[dict],
    ) -> None:
        # Endpoint table
        if endpoints:
            table = Table(
                title="🌐 API Endpoints Discovered",
                box=box.SIMPLE_HEAD, border_style="cyan",
            )
            table.add_column("Method",  width=8)
            table.add_column("URL",     width=55)
            table.add_column("Auth",    width=7)
            table.add_column("Hidden",  width=7)
            table.add_column("Source",  width=14)

            for ep in sorted(endpoints, key=lambda e: not e.get("is_hidden", False))[:25]:
                auth_s   = "[green]✓[/green]" if ep.get("auth_required", True) else "[red]✗[/red]"
                hidden_s = "[yellow]yes[/yellow]" if ep.get("is_hidden", False) else "no"
                table.add_row(
                    ep.get("method", "GET"),
                    ep.get("url", ep.get("full_url", ""))[:54],
                    auth_s, hidden_s,
                    ", ".join(ep.get("sources", [ep.get("source", "")]))[:13],
                )
            self._console.print(table)

        # Auth findings
        if auth_findings:
            auth_table = Table(
                title="🔐 Authentication Findings",
                box=box.SIMPLE_HEAD, border_style="red",
            )
            auth_table.add_column("Risk",     width=10)
            auth_table.add_column("Endpoint", width=40)
            auth_table.add_column("Issue",    width=55)

            for af in sorted(auth_findings,
                             key=lambda f: {"CRITICAL":0,"HIGH":1,"MEDIUM":2,"LOW":3}.get(f.get("risk_level","LOW"),3))[:15]:
                sev_s = SEV_STYLE.get(af.get("risk_level","MEDIUM"), "white")
                auth_table.add_row(
                    f"[{sev_s}]{af.get('risk_level','MEDIUM')}[/{sev_s}]",
                    af.get("endpoint","")[:39],
                    af.get("issue","")[:54],
                )
            self._console.print(auth_table)

        # GraphQL analysis
        for gql in gql_analyses[:3]:
            if gql.get("risks"):
                self._console.print(
                    f"\n  [bold cyan]GraphQL:[/bold cyan] {gql['endpoint'][:60]}\n"
                    f"  [dim]Risk: {gql['risk_level']} ({gql['risk_score']:.1f}/10) — "
                    f"{gql['mutation_count']} mutations, {gql['type_count']} types[/dim]"
                )

        # Risk summary
        sev_s = SEV_STYLE.get(report.risk_level.value, "white")
        self._console.print(Panel(
            f"[bold]API Risk Score:[/bold] [{sev_s}]{report.risk_score:.0f}/100 "
            f"({report.risk_level.value})[/{sev_s}]\n"
            f"[dim]{report.executive_summary}[/dim]\n"
            f"[dim]{report.total_endpoints} endpoints | "
            f"{report.hidden_endpoints} hidden | "
            f"{report.graphql_count} GraphQL | "
            f"{report.auth_risk_count} auth issues | "
            f"{len(report.swagger_specs)} spec file(s)[/dim]",
            title="API Intelligence Report",
            border_style=sev_s,
        ))
        self._console.print()

    def _status(self, label: str, msg: str) -> None:
        self._console.print(f"  [green]✔[/green] [bold]{label:<22}[/bold] → {msg}")

    def _warn(self, msg: str) -> None:
        self._console.print(f"  [yellow]⚠[/yellow] {msg}")

    def export_json(self, report: APIIntelligenceReport, output_dir: str = "reports") -> str:
        """Serialize the API intelligence report to JSON."""
        os.makedirs(output_dir, exist_ok=True)
        ts       = report.timestamp
        filename = os.path.join(
            output_dir,
            f"reconx_api_{report.target.replace('.', '_')}_{ts}.json"
        )
        with open(filename, "w", encoding="utf-8") as f:
            json.dump(report.to_dict(), f, indent=2, default=str)
        return filename
