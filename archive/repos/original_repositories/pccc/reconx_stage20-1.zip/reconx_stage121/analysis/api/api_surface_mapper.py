"""
ReconX — Stage 11: API Analysis Layer.

Six analysis modules:
  APISurfaceMapper:    Builds structured API attack surface from all discoveries
  GraphQLAnalyzer:     Deep GraphQL schema risk analysis
  AuthRiskEngine:      Aggregates and scores auth findings
  APIRiskScoring:      Overall API risk score computation
  SchemaCorrelator:    Cross-references schema types with endpoints
  APIRelationshipGraph: Graph of API endpoint relationships
"""
from __future__ import annotations

import hashlib
import logging
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Optional

from ...models.api_models import (
    APIEndpoint, APIParameter, GraphQLSchema, AuthFinding,
    AuthType, RiskLevel, APIType, APIIntelligenceReport,
)

logger = logging.getLogger("reconx.analysis.api")


# ══════════════════════════════════════════════════════════════════════════════
#  API Surface Mapper
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class APISurfaceNode:
    """A node in the API attack surface map."""
    node_id:    str
    node_type:  str    # "endpoint" | "schema_type" | "auth_flow" | "version"
    label:      str
    risk_level: RiskLevel
    metadata:   dict = field(default_factory=dict)
    edges:      list[str] = field(default_factory=list)   # connected node IDs


class APISurfaceMapper:
    """Organises API findings into a structured attack surface map."""

    def map(
        self,
        endpoints:    list[dict],
        graphql_data: list[dict],
        auth_findings: list[dict],
        parameters:   list[dict],
    ) -> dict:
        nodes:  dict[str, APISurfaceNode] = {}
        edges:  list[dict]                = []

        # ── Endpoint nodes ────────────────────────────────────────────────────
        version_groups: dict[str, list[str]] = defaultdict(list)

        for ep in endpoints:
            url    = ep.get("url") or ep.get("full_url", "")
            method = ep.get("method", "GET")
            nid    = self._nid("ep", f"{method}:{url}")
            risk   = self._endpoint_risk(ep)

            nodes[nid] = APISurfaceNode(
                node_id   = nid,
                node_type = "endpoint",
                label     = f"{method} {url[:60]}",
                risk_level = risk,
                metadata  = {
                    "method":       method,
                    "url":          url,
                    "auth_required": ep.get("auth_required", True),
                    "is_hidden":    ep.get("is_hidden", False),
                    "source":       ep.get("source", ""),
                },
            )

            # Version grouping
            import re
            m = re.search(r"/(v\d+)/", url, re.IGNORECASE)
            if m:
                version_groups[m.group(1)].append(nid)

        # ── GraphQL nodes ─────────────────────────────────────────────────────
        for schema in graphql_data:
            ep_url = schema.get("endpoint", "")
            gql_id = self._nid("gql", ep_url)
            risk   = RiskLevel.HIGH if schema.get("introspection_enabled") else RiskLevel.MEDIUM

            nodes[gql_id] = APISurfaceNode(
                node_id   = gql_id,
                node_type = "graphql_endpoint",
                label     = f"GraphQL: {ep_url[:50]}",
                risk_level = risk,
                metadata  = {
                    "introspection_enabled": schema.get("introspection_enabled"),
                    "mutation_count":        len(schema.get("mutations", [])),
                    "type_count":            schema.get("type_count", 0),
                    "sensitive_types":       schema.get("sensitive_types", []),
                    "batch_enabled":         schema.get("batch_enabled", False),
                },
            )

            # Link mutations as child nodes
            for mut in schema.get("mutations", [])[:10]:
                mut_id = self._nid("gql_mut", f"{ep_url}:{mut}")
                nodes[mut_id] = APISurfaceNode(
                    node_id=mut_id, node_type="graphql_mutation",
                    label=f"Mutation: {mut}", risk_level=RiskLevel.MEDIUM,
                    metadata={"parent": ep_url},
                )
                edges.append({"from": gql_id, "to": mut_id, "rel": "has_mutation"})
                nodes[gql_id].edges.append(mut_id)

        # ── Auth flow nodes ───────────────────────────────────────────────────
        for af in auth_findings:
            risk  = RiskLevel.from_string(af.get("risk_level", "MEDIUM"))
            af_id = self._nid("auth", f"{af.get('endpoint','')}{af.get('issue','')}")
            nodes[af_id] = APISurfaceNode(
                node_id   = af_id,
                node_type = "auth_issue",
                label     = f"Auth: {af.get('issue','')[:50]}",
                risk_level = risk,
                metadata  = af,
            )
            # Link to endpoint
            ep_url = af.get("endpoint", "")
            for ep_node in nodes.values():
                if ep_node.node_type in ("endpoint", "graphql_endpoint") and \
                   ep_url in ep_node.metadata.get("url", ep_node.metadata.get("endpoint", "")):
                    edges.append({"from": ep_node.node_id, "to": af_id, "rel": "has_auth_issue"})
                    ep_node.edges.append(af_id)
                    break

        # ── Version group nodes ───────────────────────────────────────────────
        for version, node_ids in version_groups.items():
            ver_id = self._nid("version", version)
            nodes[ver_id] = APISurfaceNode(
                node_id=ver_id, node_type="api_version",
                label=f"API {version.upper()} ({len(node_ids)} endpoints)",
                risk_level=RiskLevel.INFO,
                metadata={"version": version, "endpoint_count": len(node_ids)},
            )
            for nid in node_ids:
                edges.append({"from": ver_id, "to": nid, "rel": "contains"})

        # ── Stats ─────────────────────────────────────────────────────────────
        risk_counts: dict[str, int] = {}
        for n in nodes.values():
            rv = n.risk_level.value
            risk_counts[rv] = risk_counts.get(rv, 0) + 1

        return {
            "nodes":         {nid: {"label": n.label, "type": n.node_type,
                                    "risk": n.risk_level.value, "metadata": n.metadata}
                              for nid, n in nodes.items()},
            "edges":         edges,
            "node_count":    len(nodes),
            "edge_count":    len(edges),
            "risk_counts":   risk_counts,
            "version_groups": dict(version_groups),
            "hidden_endpoints": sum(1 for e in endpoints if e.get("is_hidden", False)),
        }

    def _endpoint_risk(self, ep: dict) -> RiskLevel:
        url  = ep.get("url", ep.get("full_url", "")).lower()
        auth = ep.get("auth_required", True)
        hidden = ep.get("is_hidden", False)

        if not auth and any(p in url for p in ["/admin", "/internal", "/user", "/payment"]):
            return RiskLevel.CRITICAL
        if not auth:
            return RiskLevel.HIGH
        if hidden:
            return RiskLevel.MEDIUM
        return RiskLevel.LOW

    def _nid(self, prefix: str, value: str) -> str:
        return hashlib.md5(f"{prefix}::{value}".encode(), usedforsecurity=False).hexdigest()[:12]


# ══════════════════════════════════════════════════════════════════════════════
#  GraphQL Analyzer
# ══════════════════════════════════════════════════════════════════════════════

class GraphQLAnalyzer:
    """Deep GraphQL schema risk analysis."""

    DANGEROUS_MUTATIONS = {
        "deleteUser", "deleteAccount", "deleteAll", "dropDatabase", "resetPassword",
        "createAdmin", "grantRole", "updateRole", "impersonate", "sudo",
        "disableMfa", "disableAuth", "bypassAuth",
    }
    SENSITIVE_FIELD_KW = {
        "password", "secret", "token", "key", "apiKey", "ssn", "credit",
        "privateKey", "auth", "admin", "internal", "debug",
    }

    def analyse(self, schema_data: dict) -> dict:
        """Produce a risk analysis from a parsed GraphQL schema dict."""
        mutations  = schema_data.get("mutations", [])
        types      = schema_data.get("types", [])
        sensitive  = schema_data.get("sensitive_types", [])
        introspect = schema_data.get("introspection_enabled", False)

        risks: list[dict] = []
        score = 0.0

        # Introspection
        if introspect:
            risks.append({"risk": "HIGH", "finding": "Introspection enabled — full schema exposed"})
            score += 3.0

        # Dangerous mutations
        danger_muts = [m for m in mutations if m in self.DANGEROUS_MUTATIONS or
                       any(kw in m.lower() for kw in {"delete", "drop", "reset", "admin", "bypass"})]
        if danger_muts:
            risks.append({
                "risk": "CRITICAL",
                "finding": f"Dangerous mutations accessible: {', '.join(danger_muts[:5])}",
            })
            score += len(danger_muts) * 2.0

        # Sensitive types
        if sensitive:
            risks.append({
                "risk": "HIGH",
                "finding": f"Sensitive types in schema: {', '.join(sensitive[:5])}",
            })
            score += len(sensitive) * 1.5

        # Missing auth on mutations
        if mutations and not schema_data.get("anonymous_access", False):
            risks.append({
                "risk": "INFO",
                "finding": f"{len(mutations)} mutations exposed (auth requirement unknown)",
            })

        # Batch enabled
        if schema_data.get("batch_enabled"):
            risks.append({"risk": "MEDIUM", "finding": "Batch queries enabled — rate limiting bypassable"})
            score += 1.5

        # Depth limit
        if not schema_data.get("depth_limit_enabled", True):
            risks.append({"risk": "MEDIUM", "finding": "No query depth limit — DoS via nested queries"})
            score += 1.5

        score = min(score, 10.0)
        risk_level = RiskLevel.from_score(score)

        return {
            "endpoint":          schema_data.get("endpoint", ""),
            "risks":             risks,
            "risk_score":        round(score, 2),
            "risk_level":        risk_level.value,
            "introspection":     introspect,
            "dangerous_muts":    danger_muts,
            "sensitive_types":   sensitive,
            "mutation_count":    len(mutations),
            "type_count":        len(types),
        }


# ══════════════════════════════════════════════════════════════════════════════
#  Auth Risk Engine
# ══════════════════════════════════════════════════════════════════════════════

class AuthRiskEngine:
    """Aggregates auth findings into a scored risk profile."""

    RISK_WEIGHTS = {"CRITICAL": 10, "HIGH": 6, "MEDIUM": 3, "LOW": 1}

    def score(self, auth_findings: list[dict]) -> dict:
        if not auth_findings:
            return {"score": 0.0, "risk_level": "INFO", "by_type": {}, "critical_count": 0}

        total  = sum(self.RISK_WEIGHTS.get(f.get("risk_level", "LOW"), 1) for f in auth_findings)
        capped = min(total, 100)
        by_level: dict[str, int] = {}
        by_type:  dict[str, int] = {}

        for f in auth_findings:
            lv = f.get("risk_level", "LOW")
            at = f.get("auth_type", "unknown")
            by_level[lv] = by_level.get(lv, 0) + 1
            by_type[at]  = by_type.get(at, 0) + 1

        normalized = capped / 10.0   # 0–10 scale
        risk_level = RiskLevel.from_score(normalized)

        return {
            "score":         round(normalized, 2),
            "risk_level":    risk_level.value,
            "by_level":      by_level,
            "by_type":       by_type,
            "critical_count": by_level.get("CRITICAL", 0),
            "high_count":    by_level.get("HIGH", 0),
            "total_findings": len(auth_findings),
        }


# ══════════════════════════════════════════════════════════════════════════════
#  API Risk Scoring
# ══════════════════════════════════════════════════════════════════════════════

class APIRiskScoring:
    """Computes an overall API intelligence risk score."""

    def score(
        self,
        endpoints:     list[dict],
        graphql_data:  list[dict],
        auth_findings: list[dict],
        swagger_specs: list[str],
        parameters:    list[dict],
    ) -> tuple[float, RiskLevel, str]:
        """
        Compute overall API risk score.

        Returns (score_0_to_100, risk_level, summary_string)
        """
        pts = 0.0

        # Exposed swagger = significant info disclosure
        if swagger_specs:
            pts += 15.0

        # Unauthenticated endpoints
        unauth = sum(1 for e in endpoints if not e.get("auth_required", True))
        pts += min(unauth * 5.0, 20.0)

        # Hidden endpoints (found via fuzzing)
        hidden = sum(1 for e in endpoints if e.get("is_hidden", False))
        pts += min(hidden * 2.0, 10.0)

        # GraphQL introspection
        if any(s.get("introspection_enabled") for s in graphql_data):
            pts += 10.0

        # Auth findings
        auth_weights = {"CRITICAL": 15, "HIGH": 8, "MEDIUM": 4, "LOW": 1}
        pts += min(sum(auth_weights.get(f.get("risk_level", "LOW"), 1) for f in auth_findings), 30.0)

        # Sensitive parameters
        sens_params = sum(1 for p in parameters if p.get("is_sensitive", False))
        pts += min(sens_params * 2.0, 10.0)

        score = min(pts, 100.0)
        risk  = RiskLevel.from_score(score / 10.0)

        parts: list[str] = []
        if swagger_specs:
            parts.append(f"API spec exposed ({len(swagger_specs)} spec files)")
        if unauth:
            parts.append(f"{unauth} unauthenticated endpoint(s)")
        if any(s.get("introspection_enabled") for s in graphql_data):
            parts.append("GraphQL introspection enabled")
        critical_auth = sum(1 for f in auth_findings if f.get("risk_level") == "CRITICAL")
        if critical_auth:
            parts.append(f"{critical_auth} critical auth issue(s)")

        summary = f"API Risk: {score:.0f}/100 ({risk.value}). " + ". ".join(parts[:3]) + "."

        return round(score, 1), risk, summary
