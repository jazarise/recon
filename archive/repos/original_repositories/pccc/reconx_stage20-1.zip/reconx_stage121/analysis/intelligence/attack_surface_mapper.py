"""
ReconX — Stage 9: Attack Surface Mapper.

Transforms raw ReconResult data into a structured attack surface map:
  - Organizes hosts, services, endpoints, APIs, and vulnerabilities
  - Builds the AttackGraph node/edge structure
  - Identifies exploitable paths through the attack surface
  - Generates per-node risk assessments
"""
from __future__ import annotations

import hashlib
import logging
from typing import Optional

from ...models.findings import ReconResult, Port, Technology
from ...models.intelligence import (
    AttackGraph, AttackNode, AttackEdge, AttackPath,
    RiskLevel, CorrelatedFinding,
)

logger = logging.getLogger("reconx.intelligence.attack_surface_mapper")


# ── Node type definitions ─────────────────────────────────────────────────────

class NodeType:
    HOST        = "host"
    SERVICE     = "service"
    ENDPOINT    = "endpoint"
    API         = "api"
    TECHNOLOGY  = "technology"
    VULNERABILITY = "vulnerability"
    CREDENTIAL  = "credential"
    DATA        = "data"
    DOMAIN      = "domain"
    SUBDOMAIN   = "subdomain"


# ── Relationship types ────────────────────────────────────────────────────────

class RelType:
    EXPOSES        = "exposes"
    RUNS           = "runs"
    VULNERABLE_TO  = "vulnerable_to"
    LEADS_TO       = "leads_to"
    HOSTS          = "hosts"
    RESOLVES_TO    = "resolves_to"
    AUTHENTICATES  = "authenticates"
    CONTAINS       = "contains"
    DEPENDS_ON     = "depends_on"


# ── High-risk path templates ──────────────────────────────────────────────────

PATH_TEMPLATES: list[dict] = [
    {
        "name":   "RCE via Vulnerable Service",
        "steps":  ["internet", "exposed_service", "vulnerable_version", "rce"],
        "risk":   RiskLevel.CRITICAL,
        "impact": "Full server compromise — arbitrary command execution",
        "tags":   ["rce", "cve"],
    },
    {
        "name":   "Credential Theft via Exposed Config",
        "steps":  ["internet", "web_endpoint", "sensitive_file", "credential_access"],
        "risk":   RiskLevel.CRITICAL,
        "impact": "Credential exfiltration enabling lateral movement",
        "tags":   ["credential", "exposure"],
    },
    {
        "name":   "Data Exfiltration via Unauthenticated DB",
        "steps":  ["internet", "exposed_port", "database_service", "data_access"],
        "risk":   RiskLevel.CRITICAL,
        "impact": "Full database dump — sensitive data exfiltration",
        "tags":   ["database", "exposure", "data"],
    },
    {
        "name":   "Subdomain Takeover → Phishing",
        "steps":  ["dangling_dns", "subdomain_takeover", "phishing_platform"],
        "risk":   RiskLevel.HIGH,
        "impact": "Credential phishing via trusted subdomain",
        "tags":   ["takeover", "phishing"],
    },
    {
        "name":   "CI/CD Compromise → Supply Chain",
        "steps":  ["internet", "cicd_panel", "pipeline_access", "supply_chain"],
        "risk":   RiskLevel.CRITICAL,
        "impact": "Build pipeline compromise — supply chain attack vector",
        "tags":   ["cicd", "supply_chain"],
    },
    {
        "name":   "Admin Panel Brute-force → Takeover",
        "steps":  ["internet", "admin_panel", "brute_force", "admin_access"],
        "risk":   RiskLevel.HIGH,
        "impact": "Administrative access to application or infrastructure",
        "tags":   ["admin", "brute_force"],
    },
]


class AttackSurfaceMapper:
    """
    Builds an AttackGraph from ReconResult data.

    The graph represents:
      Nodes = assets, services, technologies, vulnerabilities, endpoints
      Edges = directional relationships between nodes
      Paths = exploitable attack chains

    The graph is serializable to JSON for future visualization integration.
    """

    def map(
        self,
        result:     ReconResult,
        correlated: Optional[list[CorrelatedFinding]] = None,
    ) -> AttackGraph:
        """
        Build the full attack surface graph.

        Args:
            result:     Full ReconResult
            correlated: Correlated findings from CorrelationEngine

        Returns:
            AttackGraph ready for analysis and serialization
        """
        graph = AttackGraph()

        # ── Step 1: Add root target node ──────────────────────────────────────
        root_id = self._nid("host", result.target)
        graph.add_node(AttackNode(
            node_id   = root_id,
            node_type = NodeType.HOST,
            label     = result.target,
            risk_level = RiskLevel.INFO,
            metadata  = {
                "ip":   result.ip_addresses[:3] if result.ip_addresses else [],
                "os":   result.os_info.get("os", ""),
                "mode": result.mode,
            },
            tags = ["target", "root"],
        ))

        # ── Step 2: IP addresses ──────────────────────────────────────────────
        for ip in result.ip_addresses[:10]:
            ip_id = self._nid("host", ip)
            graph.add_node(AttackNode(
                node_id=ip_id, node_type=NodeType.HOST, label=ip,
                risk_level=RiskLevel.INFO, tags=["ip"],
            ))
            graph.add_edge(AttackEdge(
                source_id=root_id, target_id=ip_id,
                relationship=RelType.RESOLVES_TO, weight=1.0,
            ))

        # ── Step 3: Subdomains ────────────────────────────────────────────────
        self._add_subdomains(graph, root_id, result)

        # ── Step 4: Open ports → service nodes ───────────────────────────────
        self._add_ports_and_services(graph, root_id, result)

        # ── Step 5: Technologies ──────────────────────────────────────────────
        self._add_technologies(graph, root_id, result)

        # ── Step 6: Web endpoints ─────────────────────────────────────────────
        self._add_endpoints(graph, root_id, result)

        # ── Step 7: CVE / vulnerability nodes ─────────────────────────────────
        self._add_vulnerabilities(graph, result)

        # ── Step 8: Sensitive findings ─────────────────────────────────────────
        self._add_sensitive_findings(graph, root_id, result)

        # ── Step 9: Correlated findings → risk amplification ──────────────────
        if correlated:
            self._add_correlated_nodes(graph, root_id, correlated)

        # ── Step 10: Attack paths ─────────────────────────────────────────────
        paths = self._identify_attack_paths(graph, result, correlated or [])
        for path in paths:
            graph.paths.append(path)

        logger.info(
            f"Attack surface mapped: {graph.node_count} nodes, "
            f"{graph.edge_count} edges, {len(graph.paths)} paths"
        )
        return graph

    # ── Node builders ─────────────────────────────────────────────────────────

    def _add_subdomains(
        self, graph: AttackGraph, root_id: str, result: ReconResult
    ) -> None:
        for sub in result.subdomains[:100]:
            sub_id = self._nid("subdomain", sub)
            risk   = self._subdomain_risk(sub)
            graph.add_node(AttackNode(
                node_id=sub_id, node_type=NodeType.SUBDOMAIN, label=sub,
                risk_level=risk, tags=["subdomain"],
                metadata={"is_takeover_candidate": any(
                    tc.subdomain == sub for tc in result.takeover_candidates
                )},
            ))
            graph.add_edge(AttackEdge(
                source_id=root_id, target_id=sub_id,
                relationship=RelType.HOSTS, weight=1.0,
                description="DNS subdomain",
            ))

        # Takeover candidates get elevated risk edges
        for tc in result.takeover_candidates:
            tc_id = self._nid("subdomain", tc.subdomain)
            if tc_id in graph.nodes:
                graph.nodes[tc_id].risk_level = RiskLevel.HIGH
                graph.nodes[tc_id].tags.append("takeover_candidate")
                graph.nodes[tc_id].metadata["takeover_service"] = tc.service

    def _add_ports_and_services(
        self, graph: AttackGraph, root_id: str, result: ReconResult
    ) -> None:
        for port in result.ports:
            if port.state not in ("open", "open|filtered"):
                continue

            svc_id  = self._nid("service", f"{result.target}:{port.number}")
            risk    = self._port_risk(port.number)
            label   = f"{port.service or 'unknown'}:{port.number}/{port.protocol}"

            graph.add_node(AttackNode(
                node_id   = svc_id,
                node_type = NodeType.SERVICE,
                label     = label,
                risk_level = risk,
                metadata  = {
                    "port":     port.number,
                    "protocol": port.protocol,
                    "service":  port.service,
                    "version":  port.version,
                    "banner":   port.banner[:80] if port.banner else "",
                },
                tags = ["service", f"port_{port.number}"],
            ))
            graph.add_edge(AttackEdge(
                source_id=root_id, target_id=svc_id,
                relationship=RelType.EXPOSES, weight=risk.numeric / 5.0,
                description=f"Port {port.number} open",
            ))

    def _add_technologies(
        self, graph: AttackGraph, root_id: str, result: ReconResult
    ) -> None:
        for tech in result.technologies:
            tech_id = self._nid("technology", tech.name.lower())
            risk    = self._tech_risk(tech.name.lower())

            graph.add_node(AttackNode(
                node_id   = tech_id,
                node_type = NodeType.TECHNOLOGY,
                label     = f"{tech.name} {tech.version}".strip(),
                risk_level = risk,
                metadata  = {
                    "name":     tech.name,
                    "version":  tech.version,
                    "category": tech.category,
                },
                tags = ["technology", tech.category or "unknown"],
            ))
            graph.add_edge(AttackEdge(
                source_id=root_id, target_id=tech_id,
                relationship=RelType.RUNS, weight=1.0,
                description=f"Technology stack",
            ))

    def _add_endpoints(
        self, graph: AttackGraph, root_id: str, result: ReconResult
    ) -> None:
        # Limit to most interesting endpoints
        endpoints = result.web_endpoints[:50]
        for ep in endpoints:
            ep_id   = self._nid("endpoint", ep)
            ep_type = self._classify_endpoint(ep)
            risk    = RiskLevel.MEDIUM if ep_type == "api" else RiskLevel.LOW

            graph.add_node(AttackNode(
                node_id=ep_id, node_type=NodeType.API if ep_type == "api" else NodeType.ENDPOINT,
                label=ep[:60], risk_level=risk,
                metadata={"url": ep, "type": ep_type},
                tags=["endpoint", ep_type],
            ))
            graph.add_edge(AttackEdge(
                source_id=root_id, target_id=ep_id,
                relationship=RelType.EXPOSES, weight=0.5,
            ))

    def _add_vulnerabilities(
        self, graph: AttackGraph, result: ReconResult
    ) -> None:
        for cve in result.cve_matches:
            vuln_id = self._nid("vulnerability", cve.cve_id)
            risk    = RiskLevel.from_string(cve.severity)

            graph.add_node(AttackNode(
                node_id=vuln_id, node_type=NodeType.VULNERABILITY,
                label=cve.cve_id, risk_level=risk,
                metadata={
                    "cve_id":      cve.cve_id,
                    "severity":    cve.severity,
                    "description": cve.description[:100],
                    "cvss":        cve.cvss,
                    "service":     cve.service,
                },
                tags=["vulnerability", "cve", cve.severity.lower()],
            ))

            # Link to service node if exists
            svc_id = self._nid("service", f"{result.target}:{cve.port}")
            if svc_id in graph.nodes:
                graph.add_edge(AttackEdge(
                    source_id=svc_id, target_id=vuln_id,
                    relationship=RelType.VULNERABLE_TO, weight=risk.numeric / 5.0,
                    description=f"{cve.cve_id} affects {cve.service}",
                ))

    def _add_sensitive_findings(
        self, graph: AttackGraph, root_id: str, result: ReconResult
    ) -> None:
        for sf in result.sensitive_findings:
            data_id = self._nid("data", f"{sf.category}:{sf.url}")
            risk    = RiskLevel.from_string(sf.severity)

            graph.add_node(AttackNode(
                node_id=data_id, node_type=NodeType.DATA,
                label=f"{sf.category}: {sf.url[:50] or 'unknown'}",
                risk_level=risk,
                metadata={"category": sf.category, "url": sf.url, "detail": sf.detail[:100]},
                tags=["sensitive", sf.category],
            ))
            graph.add_edge(AttackEdge(
                source_id=root_id, target_id=data_id,
                relationship=RelType.CONTAINS, weight=risk.numeric / 5.0,
                description=f"Sensitive exposure: {sf.category}",
            ))

    def _add_correlated_nodes(
        self,
        graph:      AttackGraph,
        root_id:    str,
        correlated: list[CorrelatedFinding],
    ) -> None:
        """Add high-risk correlated findings as amplified nodes."""
        for cf in correlated:
            if cf.risk_level not in (RiskLevel.CRITICAL, RiskLevel.HIGH):
                continue
            cf_id = self._nid("correlated", cf.finding_id)
            graph.add_node(AttackNode(
                node_id=cf_id, node_type=NodeType.VULNERABILITY,
                label=cf.title[:60], risk_level=cf.risk_level,
                metadata={
                    "description": cf.description[:100],
                    "sources":     cf.sources,
                    "cves":        cf.cves,
                    "confidence":  cf.confidence.score,
                    "remediation": cf.remediation[:100],
                },
                tags=cf.tags + ["correlated"],
            ))
            graph.add_edge(AttackEdge(
                source_id=root_id, target_id=cf_id,
                relationship=RelType.VULNERABLE_TO,
                weight=cf.risk_level.numeric / 5.0,
                description=f"Correlated: {cf.title[:40]}",
            ))

    # ── Attack path detection ─────────────────────────────────────────────────

    def _identify_attack_paths(
        self,
        graph:      AttackGraph,
        result:     ReconResult,
        correlated: list[CorrelatedFinding],
    ) -> list[AttackPath]:
        """Identify exploitable attack paths through the graph."""
        paths: list[AttackPath] = []
        path_num = 0

        # RCE path: critical CVE on open service
        critical_cves = [c for c in result.cve_matches if c.severity.upper() == "CRITICAL"]
        for cve in critical_cves[:3]:
            vuln_id = self._nid("vulnerability", cve.cve_id)
            svc_id  = self._nid("service", f"{result.target}:{cve.port}")
            root_id = self._nid("host", result.target)
            if vuln_id in graph.nodes and svc_id in graph.nodes:
                path_num += 1
                paths.append(AttackPath(
                    path_id    = f"path_{path_num:03d}",
                    steps      = [root_id, svc_id, vuln_id],
                    risk_level = RiskLevel.CRITICAL,
                    description = f"Internet → {cve.service}:{cve.port} → {cve.cve_id}",
                    impact      = f"Exploitation of {cve.cve_id} — {cve.description[:80]}",
                ))

        # Data exfiltration path: sensitive file exposure
        for sf in result.sensitive_findings[:3]:
            if sf.severity.upper() in ("CRITICAL", "HIGH"):
                data_id = self._nid("data", f"{sf.category}:{sf.url}")
                root_id = self._nid("host", result.target)
                if data_id in graph.nodes:
                    path_num += 1
                    paths.append(AttackPath(
                        path_id    = f"path_{path_num:03d}",
                        steps      = [root_id, data_id],
                        risk_level = RiskLevel.from_string(sf.severity),
                        description = f"Internet → {sf.category} at {sf.url[:50]}",
                        impact      = "Sensitive data exfiltration",
                    ))

        # Takeover path
        for tc in result.takeover_candidates[:2]:
            sub_id  = self._nid("subdomain", tc.subdomain)
            root_id = self._nid("host", result.target)
            if sub_id in graph.nodes:
                path_num += 1
                paths.append(AttackPath(
                    path_id    = f"path_{path_num:03d}",
                    steps      = [root_id, sub_id],
                    risk_level = RiskLevel.HIGH,
                    description = f"Dangling DNS → {tc.subdomain} → {tc.service} takeover",
                    impact      = "Subdomain takeover enabling phishing/cookie theft",
                ))

        # Correlated chain paths
        chain_findings = [cf for cf in correlated if cf.is_chain and cf.risk_level == RiskLevel.CRITICAL]
        for cf in chain_findings[:3]:
            root_id = self._nid("host", result.target)
            cf_id   = self._nid("correlated", cf.finding_id)
            if cf_id in graph.nodes:
                path_num += 1
                paths.append(AttackPath(
                    path_id    = f"path_{path_num:03d}",
                    steps      = [root_id, cf_id],
                    risk_level = RiskLevel.CRITICAL,
                    description = f"Attack chain: {cf.title[:60]}",
                    impact      = cf.description[:100],
                ))

        paths.sort(key=lambda p: p.risk_level.numeric, reverse=True)
        return paths

    # ── Risk helpers ──────────────────────────────────────────────────────────

    _HIGH_RISK_PORTS = {23, 21, 445, 3389, 6379, 27017, 9200, 2375, 2379, 11211}
    _MED_RISK_PORTS  = {3306, 5432, 1433, 3000, 5601, 8080, 8443, 4848}

    def _port_risk(self, port: int) -> RiskLevel:
        if port in self._HIGH_RISK_PORTS: return RiskLevel.CRITICAL
        if port in self._MED_RISK_PORTS:  return RiskLevel.MEDIUM
        return RiskLevel.LOW

    _HIGH_RISK_TECH = {"jenkins", "kubernetes", "docker", "elasticsearch", "redis", "mongodb"}
    _MED_RISK_TECH  = {"grafana", "kibana", "prometheus", "phpmyadmin", "adminer", "wordpress"}

    def _tech_risk(self, tech: str) -> RiskLevel:
        if tech in self._HIGH_RISK_TECH: return RiskLevel.HIGH
        if tech in self._MED_RISK_TECH:  return RiskLevel.MEDIUM
        return RiskLevel.LOW

    _DEV_PATTERNS = ["dev", "staging", "stage", "test", "qa", "internal", "admin",
                     "jenkins", "ci", "grafana", "kibana", "jira", "confluence"]

    def _subdomain_risk(self, sub: str) -> RiskLevel:
        sub_lower = sub.lower()
        for p in self._DEV_PATTERNS:
            if sub_lower.startswith(p + ".") or f".{p}." in sub_lower:
                return RiskLevel.MEDIUM
        return RiskLevel.LOW

    def _classify_endpoint(self, url: str) -> str:
        url_lower = url.lower()
        if any(kw in url_lower for kw in ["/api/", "/v1/", "/v2/", "/v3/", "/graphql", "/rest/"]):
            return "api"
        if any(kw in url_lower for kw in ["/admin", "/manage", "/dashboard", "/console"]):
            return "admin"
        if any(kw in url_lower for kw in ["/login", "/auth", "/oauth", "/sso"]):
            return "auth"
        return "web"

    def _nid(self, node_type: str, value: str) -> str:
        """Generate stable node ID from type + value."""
        return hashlib.md5(
            f"{node_type}::{value}".encode(), usedforsecurity=False
        ).hexdigest()[:14]
