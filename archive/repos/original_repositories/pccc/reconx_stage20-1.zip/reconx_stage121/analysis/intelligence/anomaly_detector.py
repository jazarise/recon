"""
ReconX — Stage 9: Anomaly Detector, Exposure Prioritizer, Fingerprint Correlator.

Three focused intelligence modules:

AnomalyDetector:
  - Identifies unusual ports, suspicious technologies, strange banners
  - Flags hidden admin interfaces and leaked dev systems
  - Detects uncommon endpoint patterns

ExposurePrioritizer:
  - Orders exposures by true exploitability × business impact
  - Factors: internet-facing status, auth requirements, known exploits
  - Produces ranked action list for security teams

FingerprintCorrelator:
  - Cross-references banner/version data across ports and tools
  - Resolves technology conflicts (e.g. Apache vs Nginx on same host)
  - Builds enriched technology profile from multiple signals
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import Optional

from ...models.findings import ReconResult, Port, Technology
from ...models.intelligence import RiskLevel, CorrelatedFinding, ConfidenceTier

logger = logging.getLogger("reconx.intelligence.anomaly_exposure_fingerprint")


# ══════════════════════════════════════════════════════════════════════════════
#  Anomaly Detector
# ══════════════════════════════════════════════════════════════════════════════

# Common / expected ports — everything else is "unusual" relative to web targets
EXPECTED_WEB_PORTS = {
    21, 22, 25, 53, 80, 110, 143, 443, 465, 587,
    993, 995, 8080, 8443, 8888,
}

# Ports that should almost never be internet-facing
SUSPICIOUS_PORTS = {
    2375, 2376,      # Docker API
    2379, 2380,      # etcd
    6379,            # Redis
    9200, 9300,      # Elasticsearch
    27017, 27018,    # MongoDB
    11211,           # Memcached
    4848,            # GlassFish admin
    7001, 7002,      # WebLogic admin
    4444,            # Common backdoor / Metasploit
    1099,            # Java RMI
    5985, 5986,      # WinRM
    5900,            # VNC
    6000, 6001,      # X11
    9999, 4567,      # Dev/debug servers
    8161,            # ActiveMQ admin
    61616,           # ActiveMQ broker
    5672,            # RabbitMQ
    15672,           # RabbitMQ management
    9092,            # Kafka
    2181,            # ZooKeeper
}

# Suspicious banner patterns
SUSPICIOUS_BANNER_PATTERNS = [
    (r"(?i)(metasploit|meterpreter|backdoor|rootkit|c2|cobalt.strike)", RiskLevel.CRITICAL,
     "Potential malicious tool or C2 framework detected in banner"),
    (r"(?i)(default|test|example|demo|placeholder|change.?me)", RiskLevel.HIGH,
     "Default/test banner suggests unconfigured or insecure service"),
    (r"(?i)(debug|development|dev.?mode|dev.?server|werkzeug)", RiskLevel.HIGH,
     "Debug/development server exposed to internet"),
    (r"(?i)(admin|administration|management)\s+console", RiskLevel.MEDIUM,
     "Administrative console banner detected"),
    (r"(?i)unauthorized.+access.+prosecuted", RiskLevel.LOW,
     "Security warning banner — may be honeypot or monitored system"),
    (r"(?i)(password|passwd|credentials?)\s*[:=]", RiskLevel.CRITICAL,
     "Credentials visible in banner — immediate data exposure"),
]

# Unusual technology combinations
TECH_ANOMALIES = [
    (["php", "nodejs"],     "Unusual dual-runtime (PHP + Node.js) — possible misconfiguration"),
    (["apache", "nginx"],   "Both Apache and Nginx detected — possible reverse proxy chain or misconfiguration"),
    (["python", "ruby", "nodejs"], "Multiple scripting runtimes detected — complex stack, high attack surface"),
]


@dataclass
class AnomalyFinding:
    """A single detected anomaly."""
    anomaly_type: str       # "unusual_port" | "suspicious_banner" | "tech_anomaly" | "hidden_admin"
    description:  str
    risk_level:   RiskLevel
    evidence:     str
    confidence:   float = 0.75


class AnomalyDetector:
    """Detects unusual patterns across ports, banners, technologies, and endpoints."""

    def detect(self, result: ReconResult) -> list[AnomalyFinding]:
        """Run all anomaly detection rules against a ReconResult."""
        anomalies: list[AnomalyFinding] = []

        open_ports = [p for p in result.ports if p.state in ("open", "open|filtered")]
        tech_names = [t.name.lower() for t in result.technologies]

        anomalies.extend(self._detect_unusual_ports(open_ports))
        anomalies.extend(self._detect_suspicious_banners(open_ports))
        anomalies.extend(self._detect_tech_anomalies(tech_names))
        anomalies.extend(self._detect_hidden_admin(result.web_endpoints))
        anomalies.extend(self._detect_dev_in_prod(result.subdomains, result.web_endpoints))

        # Deduplicate by description
        seen: set[str] = set()
        unique: list[AnomalyFinding] = []
        for a in anomalies:
            key = a.description[:60]
            if key not in seen:
                seen.add(key)
                unique.append(a)

        unique.sort(key=lambda a: a.risk_level.numeric, reverse=True)
        logger.debug(f"Anomaly detector: {len(unique)} anomalies found")
        return unique

    def _detect_unusual_ports(self, ports: list[Port]) -> list[AnomalyFinding]:
        findings = []
        for port in ports:
            if port.number in SUSPICIOUS_PORTS:
                findings.append(AnomalyFinding(
                    anomaly_type = "suspicious_port",
                    description  = f"High-risk port {port.number} ({port.service or 'unknown'}) exposed to internet",
                    risk_level   = RiskLevel.HIGH,
                    evidence     = f"Port {port.number}/{port.protocol} open | Service: {port.service}",
                    confidence   = 0.92,
                ))
            elif port.number not in EXPECTED_WEB_PORTS and port.number > 1024:
                # Unusual non-standard port
                findings.append(AnomalyFinding(
                    anomaly_type = "unusual_port",
                    description  = f"Unusual high port {port.number} exposed — verify intent",
                    risk_level   = RiskLevel.LOW,
                    evidence     = f"Port {port.number} open — not in standard service list",
                    confidence   = 0.65,
                ))
        return findings

    def _detect_suspicious_banners(self, ports: list[Port]) -> list[AnomalyFinding]:
        findings = []
        for port in ports:
            if not port.banner:
                continue
            for pattern, risk, message in SUSPICIOUS_BANNER_PATTERNS:
                if re.search(pattern, port.banner, re.IGNORECASE):
                    findings.append(AnomalyFinding(
                        anomaly_type = "suspicious_banner",
                        description  = f"Port {port.number}: {message}",
                        risk_level   = risk,
                        evidence     = f"Banner: {port.banner[:80]}",
                        confidence   = 0.80,
                    ))
        return findings

    def _detect_tech_anomalies(self, tech_names: list[str]) -> list[AnomalyFinding]:
        findings = []
        for combo, message in TECH_ANOMALIES:
            if all(t in tech_names for t in combo):
                findings.append(AnomalyFinding(
                    anomaly_type = "tech_anomaly",
                    description  = message,
                    risk_level   = RiskLevel.LOW,
                    evidence     = f"Detected: {', '.join(combo)}",
                    confidence   = 0.70,
                ))
        return findings

    def _detect_hidden_admin(self, endpoints: list[str]) -> list[AnomalyFinding]:
        patterns = [
            r"/(secret|hidden|private|internal|backdoor|maintenance)/",
            r"/(phpmyadmin|adminer|filemanager|cpanel|webshell)/",
            r"/\.(htaccess|htpasswd|svn|git|env|config)/",
            r"/(debug|trace|diag|diagnostics|health|status)/",
            r"/wp-login\.php",
            r"/(install|setup|wizard|upgrade)\.php",
        ]
        findings = []
        for ep in endpoints:
            for pattern in patterns:
                if re.search(pattern, ep, re.IGNORECASE):
                    findings.append(AnomalyFinding(
                        anomaly_type = "hidden_admin",
                        description  = f"Potentially sensitive endpoint: {ep[:80]}",
                        risk_level   = RiskLevel.MEDIUM,
                        evidence     = f"Pattern match on endpoint: {ep[:100]}",
                        confidence   = 0.72,
                    ))
                    break
        return findings

    def _detect_dev_in_prod(
        self, subdomains: list[str], endpoints: list[str]
    ) -> list[AnomalyFinding]:
        findings = []
        dev_indicators = ["dev.", "develop.", "staging.", "stage.", "test.", "qa.", "local."]
        for sub in subdomains:
            for ind in dev_indicators:
                if sub.lower().startswith(ind) and any(
                    e for e in endpoints if sub in e
                ):
                    findings.append(AnomalyFinding(
                        anomaly_type = "dev_system_exposed",
                        description  = f"Development/staging system with active endpoints: {sub}",
                        risk_level   = RiskLevel.MEDIUM,
                        evidence     = f"Subdomain: {sub} has accessible web endpoints",
                        confidence   = 0.78,
                    ))
                    break
        return findings


# ══════════════════════════════════════════════════════════════════════════════
#  Exposure Prioritizer
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class PrioritizedExposure:
    """A finding ranked by true exploitability and business impact."""
    rank:           int
    title:          str
    risk_level:     RiskLevel
    priority_score: float           # 0–10 composite score
    exploitability: str             # TRIVIAL | EASY | MODERATE | HARD
    business_impact: str            # CRITICAL | SIGNIFICANT | MODERATE | MINOR
    remediation:    str
    evidence:       list[str]       = field(default_factory=list)
    cves:           list[str]       = field(default_factory=list)
    effort:         str             = "MEDIUM"    # remediation effort


class ExposurePrioritizer:
    """
    Ranks exposures by true priority = exploitability × business impact.

    Produces an ordered remediation list for security teams.
    """

    # Exploitability factors: conditions → score boost
    EXPLOITABILITY_RULES: list[dict] = [
        {"condition": "no_auth",          "score": 3.0, "label": "TRIVIAL",
         "desc": "No authentication required"},
        {"condition": "default_cred",     "score": 2.5, "label": "EASY",
         "desc": "Default credentials in use"},
        {"condition": "known_exploit",    "score": 2.0, "label": "EASY",
         "desc": "Public exploit available (CVE)"},
        {"condition": "internet_facing",  "score": 1.5, "label": "MODERATE",
         "desc": "Directly internet-accessible"},
        {"condition": "weak_auth",        "score": 1.0, "label": "MODERATE",
         "desc": "Weak authentication mechanism"},
    ]

    # Business impact factors
    IMPACT_RULES: list[dict] = [
        {"condition": "rce_possible",     "score": 4.0, "label": "CRITICAL",
         "desc": "Remote code execution possible"},
        {"condition": "data_exfil",       "score": 3.5, "label": "CRITICAL",
         "desc": "Data exfiltration possible"},
        {"condition": "credential_theft", "score": 3.0, "label": "CRITICAL",
         "desc": "Credential theft possible"},
        {"condition": "full_access",      "score": 3.5, "label": "CRITICAL",
         "desc": "Full system/app access"},
        {"condition": "service_takeover", "score": 2.5, "label": "SIGNIFICANT",
         "desc": "Service account / role takeover"},
        {"condition": "data_disclosure",  "score": 2.0, "label": "SIGNIFICANT",
         "desc": "Sensitive data disclosure"},
        {"condition": "lateral_movement", "score": 2.0, "label": "SIGNIFICANT",
         "desc": "Enables lateral movement"},
    ]

    def prioritize(
        self,
        correlated: list[CorrelatedFinding],
        result:     Optional[ReconResult] = None,
    ) -> list[PrioritizedExposure]:
        """
        Rank correlated findings by true priority.

        Returns:
            Sorted list of PrioritizedExposure (rank 1 = most urgent)
        """
        scored: list[tuple[float, CorrelatedFinding]] = []

        for cf in correlated:
            priority_score = self._compute_priority(cf)
            scored.append((priority_score, cf))

        scored.sort(key=lambda x: x[0], reverse=True)

        result_list: list[PrioritizedExposure] = []
        for rank, (score, cf) in enumerate(scored, start=1):
            expl, impact, effort = self._classify_finding(cf)
            result_list.append(PrioritizedExposure(
                rank            = rank,
                title           = cf.title,
                risk_level      = cf.risk_level,
                priority_score  = round(score, 2),
                exploitability  = expl,
                business_impact = impact,
                remediation     = cf.remediation,
                evidence        = cf.evidence[:4],
                cves            = cf.cves,
                effort          = effort,
            ))

        return result_list

    def _compute_priority(self, cf: CorrelatedFinding) -> float:
        """Compute a priority score from 0–10."""
        base = cf.risk_level.score_mid   # 0.5 – 9.5
        text = (cf.title + " " + cf.description + " " + " ".join(cf.tags)).lower()

        # Exploitability signals
        if any(kw in text for kw in ["no auth", "unauthenticated", "anonymous"]):
            base = min(base + 1.5, 10.0)
        if any(kw in text for kw in ["default cred", "default password", "admin:admin"]):
            base = min(base + 1.2, 10.0)
        if cf.cves:
            base = min(base + 0.8, 10.0)

        # Impact signals
        if any(kw in text for kw in ["rce", "remote code", "code execution"]):
            base = min(base + 1.5, 10.0)
        if any(kw in text for kw in [".env", "database", "credential", "secret"]):
            base = min(base + 1.0, 10.0)

        # Confidence modifier
        base *= cf.confidence.score

        return min(base, 10.0)

    def _classify_finding(self, cf: CorrelatedFinding) -> tuple[str, str, str]:
        """Return (exploitability_label, impact_label, effort)."""
        text = (cf.title + " " + cf.description + " " + " ".join(cf.tags)).lower()

        expl = "MODERATE"
        if any(kw in text for kw in ["no auth", "unauthenticated", "anonymous", "default password"]):
            expl = "TRIVIAL"
        elif any(kw in text for kw in ["known cve", "public exploit", "cve-"]) or cf.cves:
            expl = "EASY"

        impact = "MODERATE"
        if any(kw in text for kw in ["rce", "remote code", "full access", "cluster takeover"]):
            impact = "CRITICAL"
        elif any(kw in text for kw in ["credential", "secret", ".env", "data exfil", "database"]):
            impact = "CRITICAL"
        elif any(kw in text for kw in ["admin", "management", "dashboard", "cicd", "pipeline"]):
            impact = "SIGNIFICANT"

        effort = "MEDIUM"
        if any(kw in text for kw in ["patch", "update", "upgrade"]):
            effort = "MEDIUM"
        if any(kw in text for kw in ["header", "config", "disable", "firewall"]):
            effort = "LOW"
        if any(kw in text for kw in ["refactor", "redesign", "replace"]):
            effort = "HIGH"

        return expl, impact, effort


# ══════════════════════════════════════════════════════════════════════════════
#  Fingerprint Correlator
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class TechProfile:
    """
    Enriched technology profile built from multiple detection signals.
    Resolves conflicts and produces a high-confidence technology inventory.
    """
    name:       str
    version:    str
    confidence: float
    sources:    list[str]
    category:   str
    conflicts:  list[str]           # conflicting detections
    cpe:        str = ""            # CPE string if derivable


class FingerprintCorrelator:
    """
    Cross-references technology detections from multiple sources.

    Resolves:
      - Conflicting web server banners (Apache vs Nginx)
      - Version discrepancies across sources
      - Duplicates with different naming conventions
      - CPE derivation for CVE lookup
    """

    # Canonical name normalization
    NAME_ALIASES: dict[str, str] = {
        "apache httpd":   "apache",
        "apache/":        "apache",
        "nginx/":         "nginx",
        "microsoft-iis":  "iis",
        "ms-iis":         "iis",
        "openssl":        "openssl",
        "openssh":        "openssh",
        "node.js":        "nodejs",
        "node":           "nodejs",
        "express.js":     "express",
        "spring boot":    "spring",
        "spring-boot":    "spring",
        "postgres":       "postgresql",
        "mongo":          "mongodb",
        "elastic":        "elasticsearch",
    }

    # Web server conflict resolution (only one can serve a request)
    WEB_SERVER_GROUP = {"apache", "nginx", "iis", "tomcat", "caddy", "lighttpd"}

    def correlate(
        self,
        technologies: list[Technology],
        ports:        Optional[list[Port]] = None,
    ) -> list[TechProfile]:
        """
        Produce a deduplicated, conflict-resolved technology profile list.

        Args:
            technologies: Raw Technology list from ReconResult
            ports:        Port list for banner-based corroboration

        Returns:
            list[TechProfile] sorted by confidence desc
        """
        # Step 1: Normalize names
        normalized: dict[str, list[Technology]] = {}
        for tech in technologies:
            name = self._normalize(tech.name)
            normalized.setdefault(name, []).append(tech)

        # Step 2: Merge banner evidence from ports
        port_techs = self._extract_from_banners(ports or [])
        for name, version in port_techs.items():
            name_n = self._normalize(name)
            if name_n not in normalized:
                normalized[name_n] = [Technology(name=name_n, version=version, category="banner")]

        # Step 3: Build profiles
        profiles: list[TechProfile] = []
        web_server_found: Optional[str] = None

        for name, instances in normalized.items():
            if not instances:
                continue

            # Resolve version (prefer most specific)
            versions   = [i.version for i in instances if i.version]
            best_version = self._best_version(versions)

            # Sources
            sources = list(dict.fromkeys(i.category or "unknown" for i in instances))

            # Confidence
            confidence = min(0.55 + 0.10 * len(instances), 0.95)

            # Web server conflict detection
            conflicts: list[str] = []
            if name in self.WEB_SERVER_GROUP:
                if web_server_found and web_server_found != name:
                    conflicts.append(
                        f"Conflict: both '{web_server_found}' and '{name}' detected — "
                        "likely behind reverse proxy"
                    )
                web_server_found = name

            # Category
            category = instances[0].category or self._infer_category(name)

            # CPE derivation
            cpe = self._derive_cpe(name, best_version)

            profiles.append(TechProfile(
                name       = name,
                version    = best_version,
                confidence = round(confidence, 3),
                sources    = sources,
                category   = category,
                conflicts  = conflicts,
                cpe        = cpe,
            ))

        profiles.sort(key=lambda p: p.confidence, reverse=True)
        logger.debug(f"Fingerprint correlator: {len(profiles)} tech profiles resolved")
        return profiles

    def _normalize(self, name: str) -> str:
        name_lower = name.lower().strip()
        for alias, canonical in self.NAME_ALIASES.items():
            if name_lower.startswith(alias):
                return canonical
        return name_lower

    def _best_version(self, versions: list[str]) -> str:
        """Pick the most specific (longest) version string."""
        if not versions:
            return ""
        return max(versions, key=lambda v: (len(re.findall(r"\d+", v)), len(v)))

    def _extract_from_banners(self, ports: list[Port]) -> dict[str, str]:
        """Extract technology names and versions from port banners."""
        techs: dict[str, str] = {}
        patterns = [
            (r"Apache[/ ](\d+[\d.]+)",    "apache"),
            (r"nginx[/ ](\d+[\d.]+)",     "nginx"),
            (r"OpenSSH[_ ](\S+)",          "openssh"),
            (r"PHP[/ ](\d+[\d.]+)",        "php"),
            (r"IIS[/ ](\d+[\d.]+)",        "iis"),
            (r"Tomcat[/ ](\d+[\d.]+)",     "tomcat"),
            (r"Jenkins[/ ](\d+[\d.]+)",    "jenkins"),
            (r"Werkzeug[/ ](\d+[\d.]+)",   "werkzeug"),
            (r"Express",                   "express"),
        ]
        for port in ports:
            banner = port.banner or ""
            for pattern, tech_name in patterns:
                m = re.search(pattern, banner, re.IGNORECASE)
                if m:
                    version = m.group(1) if m.lastindex else ""
                    if tech_name not in techs:
                        techs[tech_name] = version
        return techs

    def _infer_category(self, name: str) -> str:
        cats = {
            "web_server":    ["apache", "nginx", "iis", "tomcat", "caddy", "lighttpd"],
            "cms":           ["wordpress", "drupal", "joomla", "magento"],
            "database":      ["mysql", "postgresql", "mongodb", "redis", "elasticsearch"],
            "language":      ["php", "python", "ruby", "nodejs", "java"],
            "framework":     ["django", "laravel", "spring", "express", "rails"],
            "devops":        ["jenkins", "gitlab", "docker", "kubernetes"],
            "monitoring":    ["grafana", "kibana", "prometheus"],
            "security":      ["openssl", "openssh"],
        }
        for category, members in cats.items():
            if name in members:
                return category
        return "unknown"

    def _derive_cpe(self, name: str, version: str) -> str:
        """Derive a CPE 2.3 string for the technology (best-effort)."""
        cpe_vendors = {
            "apache":        ("apache", "http_server"),
            "nginx":         ("nginx", "nginx"),
            "iis":           ("microsoft", "internet_information_services"),
            "php":           ("php", "php"),
            "openssh":       ("openbsd", "openssh"),
            "openssl":       ("openssl", "openssl"),
            "tomcat":        ("apache", "tomcat"),
            "wordpress":     ("wordpress", "wordpress"),
            "jenkins":       ("jenkins", "jenkins"),
            "redis":         ("redis", "redis"),
            "mongodb":       ("mongodb", "mongodb"),
            "elasticsearch": ("elastic", "elasticsearch"),
            "postgresql":    ("postgresql", "postgresql"),
            "mysql":         ("mysql", "mysql"),
        }
        vendor_product = cpe_vendors.get(name)
        if vendor_product and version:
            vendor, product = vendor_product
            return f"cpe:2.3:a:{vendor}:{product}:{version}:*:*:*:*:*:*:*"
        return ""
