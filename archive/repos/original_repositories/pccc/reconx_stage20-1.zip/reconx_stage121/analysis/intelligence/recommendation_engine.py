"""
ReconX — Stage 9: Recommendation Engine.

Generates contextual, prioritized security recommendations based on:
  - Correlated findings and their risk levels
  - Detected technologies and known hardening requirements
  - Asset classifications and their roles
  - Attack paths and exploitability
  - Missing security controls

Recommendations are:
  - Actionable (clear what to do)
  - Contextual (explains why it applies to this target)
  - Prioritized (by risk reduction × implementation effort)
  - Severity-aware (tied to actual findings)
"""
from __future__ import annotations

import hashlib
import logging
from typing import Optional

from ...models.findings import ReconResult
from ...models.intelligence import (
    Recommendation, RiskLevel, CorrelatedFinding, ClassifiedAsset,
)

logger = logging.getLogger("reconx.intelligence.recommendation_engine")


# ── Recommendation templates ──────────────────────────────────────────────────
# Each template defines trigger conditions and recommendation content

TEMPLATES: list[dict] = [

    # ── CRITICAL ──────────────────────────────────────────────────────────────

    {
        "id":        "unauthenticated_db",
        "trigger":   lambda r, tech, ports: any(
            p in ports for p in [6379, 9200, 27017, 5432, 3306]
        ) or any(t in tech for t in ["redis", "elasticsearch", "mongodb"]),
        "risk":      RiskLevel.CRITICAL,
        "title":     "Secure Unauthenticated Database Services",
        "context":   "Database service(s) accessible without authentication — full data access possible.",
        "action":    (
            "1. Enable authentication on all database services (requirepass for Redis, "
            "X-Pack for Elasticsearch, --auth for MongoDB). "
            "2. Bind services to 127.0.0.1 or internal network interfaces. "
            "3. Implement firewall rules to block external access on database ports. "
            "4. Rotate all database credentials immediately."
        ),
        "effort":    "LOW",
        "impact":    "Eliminates unauthorized data access and exfiltration risk",
        "tags":      ["database", "authentication", "network"],
    },

    {
        "id":        "patch_critical_cves",
        "trigger":   lambda r, tech, ports: any(
            c.severity.upper() == "CRITICAL" for c in r.cve_matches
        ),
        "risk":      RiskLevel.CRITICAL,
        "title":     "Apply Critical Security Patches Immediately",
        "context":   "Critical CVEs detected in production services — public exploits likely available.",
        "action":    (
            "1. Identify the specific services and versions with critical CVEs. "
            "2. Apply vendor security patches immediately (within 24 hours). "
            "3. If patching is not immediately possible, implement WAF rules as temporary mitigation. "
            "4. Verify patch application with a follow-up scan."
        ),
        "effort":    "MEDIUM",
        "impact":    "Eliminates known critical exploitation vectors",
        "tags":      ["patch", "cve", "critical"],
    },

    {
        "id":        "cicd_restrict",
        "trigger":   lambda r, tech, ports: (
            any(t in tech for t in ["jenkins", "gitlab", "teamcity"]) or
            8080 in ports
        ),
        "risk":      RiskLevel.CRITICAL,
        "title":     "Restrict CI/CD System Internet Access",
        "context":   "CI/CD platform detected — contains secrets, pipeline configs, and build artifacts.",
        "action":    (
            "1. Place CI/CD system behind VPN or restrict by IP allowlist at firewall level. "
            "2. Enable strong authentication (LDAP/SSO + MFA). "
            "3. Rotate all pipeline secrets, API tokens, and deploy keys. "
            "4. Audit user access — remove unused accounts. "
            "5. Enable audit logging for all pipeline executions."
        ),
        "effort":    "MEDIUM",
        "impact":    "Prevents supply chain compromise and credential theft",
        "tags":      ["cicd", "secrets", "network"],
    },

    {
        "id":        "container_api_lockdown",
        "trigger":   lambda r, tech, ports: (
            any(p in ports for p in [2375, 2376, 6443, 2379]) or
            any(t in tech for t in ["docker", "kubernetes"])
        ),
        "risk":      RiskLevel.CRITICAL,
        "title":     "Secure Container Orchestration Endpoints",
        "context":   "Docker or Kubernetes API endpoints exposed — full infrastructure access possible.",
        "action":    (
            "1. Disable unauthenticated Docker daemon API (port 2375). Use TLS client certs on 2376. "
            "2. Restrict Kubernetes API server to internal network. Enable RBAC. "
            "3. Rotate all service account tokens and kubeconfig credentials. "
            "4. Audit running containers for privileged mode and host mounts. "
            "5. Enable Kubernetes audit logging."
        ),
        "effort":    "HIGH",
        "impact":    "Prevents full infrastructure compromise and container escape",
        "tags":      ["container", "kubernetes", "docker", "api"],
    },

    {
        "id":        "subdomain_takeover",
        "trigger":   lambda r, tech, ports: bool(r.takeover_candidates),
        "risk":      RiskLevel.HIGH,
        "title":     "Remediate Subdomain Takeover Vulnerabilities",
        "context":   "Dangling DNS records point to unclaimed third-party services — takeover enables phishing.",
        "action":    (
            "1. For each takeover candidate: remove the dangling CNAME or A record immediately. "
            "2. Claim the subdomain on the third-party service if still needed. "
            "3. Implement a subdomain inventory and regular DNS auditing process. "
            "4. Set up monitoring for new dangling DNS records (use tools: dnstwist, subjack)."
        ),
        "effort":    "LOW",
        "impact":    "Eliminates phishing and session hijacking via trusted subdomains",
        "tags":      ["dns", "takeover", "subdomain"],
    },

    # ── HIGH ──────────────────────────────────────────────────────────────────

    {
        "id":        "disable_dangerous_protocols",
        "trigger":   lambda r, tech, ports: any(p in ports for p in [23, 21, 445]),
        "risk":      RiskLevel.HIGH,
        "title":     "Disable Insecure Protocols (Telnet, FTP, SMB)",
        "context":   "Cleartext protocols or SMB detected — credential interception or ransomware risk.",
        "action":    (
            "1. Disable Telnet (port 23) — replace with SSH. "
            "2. Disable FTP (port 21) — replace with SFTP or FTPS. "
            "3. Block SMB (port 445) at internet perimeter firewall. Disable SMBv1. "
            "4. Patch SMB to latest version. Apply MS17-010 if not already patched."
        ),
        "effort":    "LOW",
        "impact":    "Eliminates cleartext credential interception and major ransomware vector",
        "tags":      ["protocol", "smb", "telnet", "ftp"],
    },

    {
        "id":        "restrict_rdp",
        "trigger":   lambda r, tech, ports: 3389 in ports,
        "risk":      RiskLevel.HIGH,
        "title":     "Secure Remote Desktop Protocol (RDP) Exposure",
        "context":   "RDP exposed to internet — primary ransomware delivery vector via brute-force.",
        "action":    (
            "1. Move RDP behind VPN — do not expose port 3389 to internet. "
            "2. Enable Network Level Authentication (NLA). "
            "3. Implement account lockout after 5 failed attempts. "
            "4. Use a bastion host or Remote Desktop Gateway. "
            "5. Enable multi-factor authentication for all RDP sessions."
        ),
        "effort":    "MEDIUM",
        "impact":    "Reduces ransomware delivery risk and brute-force attack surface",
        "tags":      ["rdp", "remote_access", "brute_force"],
    },

    {
        "id":        "tls_remediation",
        "trigger":   lambda r, tech, ports: (
            r.tls_info and (r.tls_info.is_expired or r.tls_info.is_self_signed or
                            r.tls_info.days_remaining <= 30)
        ),
        "risk":      RiskLevel.HIGH,
        "title":     "Fix TLS Certificate Issues",
        "context":   "TLS certificate expired, self-signed, or expiring within 30 days.",
        "action":    (
            "1. Renew or replace the TLS certificate immediately. "
            "2. Use a CA-signed certificate (Let's Encrypt for internet-facing systems). "
            "3. Implement automated certificate renewal (certbot, ACME protocol). "
            "4. Enable HSTS to prevent protocol downgrade attacks. "
            "5. Audit TLS configuration: use TLS 1.2+ only, disable weak ciphers."
        ),
        "effort":    "LOW",
        "impact":    "Restores encrypted communication integrity, prevents MITM attacks",
        "tags":      ["tls", "certificate", "encryption"],
    },

    {
        "id":        "sensitive_file_removal",
        "trigger":   lambda r, tech, ports: any(
            f.severity.upper() in ("CRITICAL", "HIGH") for f in r.sensitive_findings
        ),
        "risk":      RiskLevel.HIGH,
        "title":     "Remove Exposed Sensitive Files",
        "context":   "Sensitive files (config, backup, credentials) accessible via web server.",
        "action":    (
            "1. Immediately remove identified sensitive files from web root. "
            "2. Rotate all credentials found in exposed files (API keys, DB passwords, tokens). "
            "3. Add deny rules in web server config for sensitive file patterns: "
            "   - Apache: <FilesMatch '\\.(env|bak|sql|zip|conf|cfg)$'> Deny from all. "
            "   - Nginx: location ~* \\.(env|bak|sql)$ { deny all; }. "
            "4. Implement pre-deployment secrets scanning (truffleHog, git-secrets). "
            "5. Add sensitive file patterns to .gitignore."
        ),
        "effort":    "LOW",
        "impact":    "Stops credential theft and configuration exposure",
        "tags":      ["files", "credential", "backup"],
    },

    # ── MEDIUM ────────────────────────────────────────────────────────────────

    {
        "id":        "security_headers",
        "trigger":   lambda r, tech, ports: any(
            h.status in ("missing", "weak") for h in r.header_findings
        ),
        "risk":      RiskLevel.MEDIUM,
        "title":     "Implement HTTP Security Headers",
        "context":   "Missing or weak security headers enable client-side attacks.",
        "action":    (
            "Add to web server configuration:\n"
            "  Strict-Transport-Security: max-age=31536000; includeSubDomains; preload\n"
            "  Content-Security-Policy: default-src 'self' (tune as needed)\n"
            "  X-Frame-Options: SAMEORIGIN\n"
            "  X-Content-Type-Options: nosniff\n"
            "  Referrer-Policy: strict-origin-when-cross-origin\n"
            "  Permissions-Policy: camera=(), microphone=(), geolocation=()\n"
            "Test with: securityheaders.com"
        ),
        "effort":    "LOW",
        "impact":    "Mitigates XSS, clickjacking, MIME confusion, and downgrade attacks",
        "tags":      ["headers", "configuration", "web"],
    },

    {
        "id":        "patch_high_cves",
        "trigger":   lambda r, tech, ports: any(
            c.severity.upper() == "HIGH" for c in r.cve_matches
        ),
        "risk":      RiskLevel.MEDIUM,
        "title":     "Patch High-Severity Vulnerabilities",
        "context":   "High-severity CVEs detected — exploitation may require some preconditions.",
        "action":    (
            "1. Review each HIGH CVE and identify affected service version. "
            "2. Apply vendor patches within 72 hours. "
            "3. If patching requires downtime, implement compensating controls (WAF rules, network restriction). "
            "4. Establish a patch management schedule (monthly minimum for all services)."
        ),
        "effort":    "MEDIUM",
        "impact":    "Reduces exploitable attack surface for known vulnerability classes",
        "tags":      ["patch", "cve", "high"],
    },

    {
        "id":        "email_protection",
        "trigger":   lambda r, tech, ports: len(r.emails) >= 3,
        "risk":      RiskLevel.MEDIUM,
        "title":     "Reduce Email Address Exposure (Phishing Risk)",
        "context":   "Multiple staff email addresses discoverable via OSINT — phishing attack surface.",
        "action":    (
            "1. Implement DMARC, DKIM, and SPF records on all email domains. "
            "2. Train staff on phishing awareness and reporting. "
            "3. Enable email filtering with sandboxing (O365 Defender, Proofpoint). "
            "4. Consider using role-based emails (security@, info@) instead of personal addresses. "
            "5. Monitor dark web for credential exposure (HaveIBeenPwned API)."
        ),
        "effort":    "MEDIUM",
        "impact":    "Reduces phishing success rate and credential theft via social engineering",
        "tags":      ["email", "phishing", "osint"],
    },

    # ── LOW ───────────────────────────────────────────────────────────────────

    {
        "id":        "attack_surface_reduction",
        "trigger":   lambda r, tech, ports: len(r.subdomains) > 20 or len(r.ports) > 10,
        "risk":      RiskLevel.LOW,
        "title":     "Reduce Attack Surface (Unused Subdomains and Services)",
        "context":   "Large attack surface detected — unused assets increase exposure unnecessarily.",
        "action":    (
            "1. Audit all subdomains — decommission those no longer in use. "
            "2. Close ports/services not required for business operations. "
            "3. Implement an asset inventory process (monthly review). "
            "4. Use a web application firewall (WAF) to filter unexpected traffic. "
            "5. Enable DNS monitoring for new/unexpected subdomains."
        ),
        "effort":    "HIGH",
        "impact":    "Reduces overall attack surface — fewer assets = fewer potential entry points",
        "tags":      ["hardening", "asset_management", "surface_reduction"],
    },

    {
        "id":        "monitoring_setup",
        "trigger":   lambda r, tech, ports: True,   # always recommend
        "risk":      RiskLevel.LOW,
        "title":     "Implement Security Monitoring and Alerting",
        "context":   "No evidence of security monitoring detected during reconnaissance.",
        "action":    (
            "1. Deploy centralized logging (ELK, Splunk, or cloud-native). "
            "2. Configure alerts for: failed logins, new open ports, certificate expiry. "
            "3. Set up network intrusion detection (Suricata, Snort). "
            "4. Implement a vulnerability scanning schedule (weekly Nuclei, monthly full scan). "
            "5. Subscribe to CVE feeds for technologies in your stack."
        ),
        "effort":    "HIGH",
        "impact":    "Enables early detection of attacks and faster incident response",
        "tags":      ["monitoring", "detection", "logging"],
    },
]


class RecommendationEngine:
    """
    Generates contextual, prioritized security recommendations.

    Evaluates all TEMPLATES against the scan context and produces
    an ordered list of Recommendation objects.
    """

    def generate(
        self,
        result:     ReconResult,
        correlated: Optional[list[CorrelatedFinding]] = None,
        assets:     Optional[list[ClassifiedAsset]]   = None,
    ) -> list[Recommendation]:
        """
        Generate recommendations for a full ReconResult.

        Args:
            result:     Full ReconResult
            correlated: Optional correlated findings for context enrichment
            assets:     Optional classified assets

        Returns:
            Prioritized list of Recommendation objects
        """
        tech_names = [t.name.lower() for t in result.technologies]
        open_ports = {p.number for p in result.ports if p.state in ("open", "open|filtered")}

        triggered: list[Recommendation] = []
        priority   = 1

        # Evaluate each template
        for tpl in TEMPLATES:
            try:
                if tpl["trigger"](result, tech_names, open_ports):
                    # Enrich with CVE context
                    cves = self._relevant_cves(result, tpl["tags"])

                    rec = Recommendation(
                        rec_id     = self._rid(tpl["id"]),
                        priority   = priority,
                        title      = tpl["title"],
                        context    = self._enrich_context(tpl["context"], result, correlated),
                        action     = tpl["action"],
                        effort     = tpl["effort"],
                        impact     = tpl["impact"],
                        risk_level = tpl["risk"],
                        tags       = tpl["tags"],
                        cves       = cves,
                    )
                    triggered.append(rec)
                    priority += 1
            except Exception as e:
                logger.debug(f"Recommendation template '{tpl['id']}' evaluation error: {e}")

        # Sort: CRITICAL first, then HIGH, then by effort (LOW effort = earlier)
        effort_order = {"LOW": 0, "MEDIUM": 1, "HIGH": 2}
        triggered.sort(key=lambda r: (
            -r.risk_level.numeric,
            effort_order.get(r.effort, 1),
        ))

        # Re-assign priorities after sort
        for i, rec in enumerate(triggered, start=1):
            rec.priority = i

        logger.info(f"Recommendation engine: {len(triggered)} recommendations generated")
        return triggered

    def _enrich_context(
        self,
        context:    str,
        result:     ReconResult,
        correlated: Optional[list[CorrelatedFinding]],
    ) -> str:
        """Append target-specific context to the template context string."""
        enrichments: list[str] = []

        if result.target:
            enrichments.append(f"Target: {result.target}.")
        if result.cve_matches:
            critical_cves = [c.cve_id for c in result.cve_matches if c.severity.upper() == "CRITICAL"]
            if critical_cves:
                enrichments.append(f"Critical CVEs: {', '.join(critical_cves[:3])}.")

        if correlated:
            chain_titles = [cf.title for cf in correlated if cf.is_chain and cf.risk_level == RiskLevel.CRITICAL]
            if chain_titles:
                enrichments.append(f"Active attack chain: {chain_titles[0][:60]}.")

        if enrichments:
            return context + " " + " ".join(enrichments)
        return context

    def _relevant_cves(self, result: ReconResult, tags: list[str]) -> list[str]:
        """Extract CVEs relevant to a recommendation's tags."""
        cves: list[str] = []
        for cve in result.cve_matches:
            svc = cve.service.lower()
            if any(tag in svc or tag in cve.description.lower() for tag in tags):
                cves.append(cve.cve_id)
        return list(dict.fromkeys(cves))[:5]

    def _rid(self, template_id: str) -> str:
        return hashlib.md5(template_id.encode(), usedforsecurity=False).hexdigest()[:10]
