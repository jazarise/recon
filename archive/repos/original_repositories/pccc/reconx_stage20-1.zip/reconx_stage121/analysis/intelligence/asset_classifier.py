"""
ReconX — Stage 9: Asset Classifier.

Automatically classifies discovered assets into role categories:
  - production / staging / development
  - admin / CI-CD / API gateway / auth portal
  - cloud infrastructure / monitoring / database

Uses naming heuristics, technology detection, port fingerprints, and
response metadata to determine the most likely asset role.
"""
from __future__ import annotations

import re
import logging
from typing import Optional

from ...models.findings import ReconResult, Port, Technology
from ...models.intelligence import ClassifiedAsset, AssetType, RiskLevel

logger = logging.getLogger("reconx.intelligence.asset_classifier")


# ── Classification rules (ordered by specificity) ────────────────────────────

NAMING_RULES: list[dict] = [
    # CI/CD
    {"patterns": [r"^jenkins\.", r"\.jenkins\.", r"^ci\.", r"^build\.", r"^cd\.",
                  r"^deploy\.", r"\.ci\.", r"^teamcity\.", r"^bamboo\."],
     "asset_type": AssetType.CICD, "confidence": 0.88, "risk": RiskLevel.HIGH},

    # Admin interfaces
    {"patterns": [r"^admin\.", r"^administrator\.", r"^manage\.", r"^management\.",
                  r"^backend\.", r"^panel\.", r"^cpanel\.", r"^whm\."],
     "asset_type": AssetType.ADMIN, "confidence": 0.85, "risk": RiskLevel.HIGH},

    # Auth portals
    {"patterns": [r"^auth\.", r"^login\.", r"^sso\.", r"^oauth\.",
                  r"^id\.", r"^identity\.", r"^accounts?\.", r"^iam\."],
     "asset_type": AssetType.AUTH_PORTAL, "confidence": 0.85, "risk": RiskLevel.MEDIUM},

    # API gateways
    {"patterns": [r"^api\.", r"^apis?\.", r"^gateway\.", r"^gw\.",
                  r"^rest\.", r"^graphql\.", r"^service\.", r"^services\."],
     "asset_type": AssetType.API_GATEWAY, "confidence": 0.82, "risk": RiskLevel.MEDIUM},

    # Monitoring
    {"patterns": [r"^grafana\.", r"^kibana\.", r"^prometheus\.", r"^monitor\.",
                  r"^metrics\.", r"^stats\.", r"^telemetry\.", r"^datadog\.",
                  r"^alertmanager\.", r"^jaeger\.", r"^zipkin\."],
     "asset_type": AssetType.MONITORING, "confidence": 0.88, "risk": RiskLevel.HIGH},

    # Cloud infrastructure
    {"patterns": [r"^cloud\.", r"^aws\.", r"^azure\.", r"^gcp\.",
                  r"^k8s\.", r"^kubernetes\.", r"^rancher\.", r"^infra\."],
     "asset_type": AssetType.CLOUD_INFRA, "confidence": 0.82, "risk": RiskLevel.HIGH},

    # Database
    {"patterns": [r"^db\.", r"^database\.", r"^mysql\.", r"^postgres\.",
                  r"^mongo\.", r"^redis\.", r"^elastic\.", r"^cassandra\."],
     "asset_type": AssetType.DATABASE, "confidence": 0.85, "risk": RiskLevel.CRITICAL},

    # Staging / QA
    {"patterns": [r"^staging\.", r"^stage\.", r"^uat\.", r"^qa\.",
                  r"^sandbox\.", r"^test\.", r"^testing\.", r"^preprod\."],
     "asset_type": AssetType.STAGING, "confidence": 0.88, "risk": RiskLevel.MEDIUM},

    # Development
    {"patterns": [r"^dev\.", r"^develop\.", r"^development\.", r"^local\.",
                  r"^preview\.", r"^beta\.", r"^alpha\.", r"^canary\."],
     "asset_type": AssetType.DEVELOPMENT, "confidence": 0.88, "risk": RiskLevel.MEDIUM},

    # Mail
    {"patterns": [r"^mail\.", r"^smtp\.", r"^mx\.", r"^webmail\.",
                  r"^exchange\.", r"^imap\.", r"^pop3\.", r"^relay\."],
     "asset_type": AssetType.MAIL, "confidence": 0.85, "risk": RiskLevel.MEDIUM},

    # VPN / remote access
    {"patterns": [r"^vpn\.", r"^remote\.", r"^access\.", r"^rdp\.",
                  r"^citrix\.", r"^pulse\.", r"^fortigate\."],
     "asset_type": AssetType.VPN, "confidence": 0.85, "risk": RiskLevel.HIGH},
]

# Technology → asset type mapping
TECH_TYPE_MAP: dict[str, tuple[AssetType, RiskLevel]] = {
    "jenkins":       (AssetType.CICD,        RiskLevel.HIGH),
    "teamcity":      (AssetType.CICD,        RiskLevel.HIGH),
    "gitlab":        (AssetType.CICD,        RiskLevel.MEDIUM),
    "github":        (AssetType.CICD,        RiskLevel.MEDIUM),
    "kubernetes":    (AssetType.CLOUD_INFRA, RiskLevel.CRITICAL),
    "docker":        (AssetType.CLOUD_INFRA, RiskLevel.HIGH),
    "rancher":       (AssetType.CLOUD_INFRA, RiskLevel.HIGH),
    "portainer":     (AssetType.CLOUD_INFRA, RiskLevel.CRITICAL),
    "grafana":       (AssetType.MONITORING,  RiskLevel.HIGH),
    "kibana":        (AssetType.MONITORING,  RiskLevel.HIGH),
    "prometheus":    (AssetType.MONITORING,  RiskLevel.MEDIUM),
    "elasticsearch": (AssetType.DATABASE,    RiskLevel.CRITICAL),
    "redis":         (AssetType.DATABASE,    RiskLevel.CRITICAL),
    "mongodb":       (AssetType.DATABASE,    RiskLevel.CRITICAL),
    "mysql":         (AssetType.DATABASE,    RiskLevel.HIGH),
    "postgresql":    (AssetType.DATABASE,    RiskLevel.HIGH),
    "phpmyadmin":    (AssetType.DATABASE,    RiskLevel.CRITICAL),
    "adminer":       (AssetType.DATABASE,    RiskLevel.CRITICAL),
    "jira":          (AssetType.DEVELOPMENT, RiskLevel.MEDIUM),
    "confluence":    (AssetType.DEVELOPMENT, RiskLevel.MEDIUM),
    "wordpress":     (AssetType.PRODUCTION,  RiskLevel.MEDIUM),
}

# Port → role hints
PORT_ROLE_HINTS: dict[int, AssetType] = {
    2375:  AssetType.CLOUD_INFRA,   # Docker API
    2376:  AssetType.CLOUD_INFRA,
    6443:  AssetType.CLOUD_INFRA,   # Kubernetes API
    2379:  AssetType.CLOUD_INFRA,   # etcd
    10250: AssetType.CLOUD_INFRA,   # kubelet
    9200:  AssetType.DATABASE,      # Elasticsearch
    6379:  AssetType.DATABASE,      # Redis
    27017: AssetType.DATABASE,      # MongoDB
    3306:  AssetType.DATABASE,
    5432:  AssetType.DATABASE,
    1433:  AssetType.DATABASE,
    3000:  AssetType.MONITORING,    # Grafana
    9090:  AssetType.MONITORING,    # Prometheus
    5601:  AssetType.MONITORING,    # Kibana
    8080:  AssetType.CICD,          # Jenkins common port
    25:    AssetType.MAIL,
    465:   AssetType.MAIL,
    587:   AssetType.MAIL,
    1194:  AssetType.VPN,
    1723:  AssetType.VPN,
    4500:  AssetType.VPN,
}


class AssetClassifier:
    """
    Classifies discovered assets into role categories.

    Input: ReconResult (target + subdomains) or individual hostnames
    Output: list[ClassifiedAsset] with confidence and risk metadata
    """

    def __init__(self) -> None:
        self._compiled_rules = self._compile_rules()

    def classify_result(self, result: ReconResult) -> list[ClassifiedAsset]:
        """
        Classify all assets discovered in a ReconResult.

        Classifies: primary target + all subdomains
        """
        assets: list[ClassifiedAsset] = []

        # Primary target
        primary = self._classify_host(
            identifier  = result.target,
            technologies = result.technologies,
            ports       = result.ports,
        )
        assets.append(primary)

        # Subdomains (no per-subdomain port/tech data — use naming only)
        for sub in result.subdomains[:200]:
            asset = self._classify_host(identifier=sub)
            assets.append(asset)

        # Deduplicate by identifier
        seen: set[str] = set()
        unique: list[ClassifiedAsset] = []
        for a in assets:
            if a.identifier not in seen:
                seen.add(a.identifier)
                unique.append(a)

        # Sort by risk
        unique.sort(key=lambda a: a.risk_level.numeric, reverse=True)
        logger.info(f"Classified {len(unique)} assets")
        return unique

    def classify_host(
        self,
        hostname:     str,
        technologies: Optional[list[Technology]] = None,
        ports:        Optional[list[Port]]        = None,
    ) -> ClassifiedAsset:
        """Classify a single host by hostname/IP, technologies, and open ports."""
        return self._classify_host(hostname, technologies or [], ports or [])

    def summarize(self, assets: list[ClassifiedAsset]) -> dict:
        """Summarize classification results."""
        by_type: dict[str, int] = {}
        by_risk: dict[str, int] = {}
        high_risk: list[str] = []

        for a in assets:
            by_type[a.asset_type.value] = by_type.get(a.asset_type.value, 0) + 1
            by_risk[a.risk_level.value] = by_risk.get(a.risk_level.value, 0) + 1
            if a.risk_level in (RiskLevel.CRITICAL, RiskLevel.HIGH):
                high_risk.append(a.identifier)

        return {
            "total":       len(assets),
            "by_type":     by_type,
            "by_risk":     by_risk,
            "high_risk":   high_risk[:10],
            "production":  by_type.get("production", 0),
            "staging":     by_type.get("staging", 0),
            "development": by_type.get("development", 0),
            "admin":       by_type.get("admin", 0),
            "cicd":        by_type.get("cicd", 0),
        }

    # ── Internal classification ───────────────────────────────────────────────

    def _classify_host(
        self,
        identifier:  str,
        technologies: Optional[list[Technology]] = None,
        ports:        Optional[list[Port]] = None,
    ) -> ClassifiedAsset:
        technologies = technologies or []
        ports        = ports or []

        tech_names = [t.name.lower() for t in technologies]
        open_ports = [p.number for p in ports if p.state in ("open", "open|filtered")]
        evidence:  list[str] = []
        tags:      list[str] = []

        # ── Step 1: Naming heuristics ─────────────────────────────────────────
        name_type, name_conf, name_risk = self._classify_by_name(identifier, evidence, tags)

        # ── Step 2: Technology signals ─────────────────────────────────────────
        tech_type, tech_conf, tech_risk = self._classify_by_tech(tech_names, evidence, tags)

        # ── Step 3: Port signals ───────────────────────────────────────────────
        port_type, port_conf = self._classify_by_ports(open_ports, evidence, tags)

        # ── Step 4: Merge signals ──────────────────────────────────────────────
        # Priority: tech (highest signal) > name > port
        if tech_type and tech_conf >= 0.70:
            asset_type = tech_type
            confidence = tech_conf
            risk       = tech_risk
        elif name_type and name_conf >= 0.60:
            asset_type = name_type
            confidence = name_conf
            risk       = name_risk
            # Boost if port confirms
            if port_type == name_type:
                confidence = min(confidence + 0.08, 1.0)
        elif port_type:
            asset_type = port_type
            confidence = port_conf
            risk       = RiskLevel.MEDIUM
        else:
            asset_type = AssetType.PRODUCTION   # safe default
            confidence = 0.40
            risk       = RiskLevel.LOW

        # Ensure CICD/admin/monitoring/database are HIGH+ risk
        risk = self._enforce_min_risk(asset_type, risk)

        return ClassifiedAsset(
            identifier         = identifier,
            asset_type         = asset_type,
            confidence         = round(confidence, 3),
            risk_level         = risk,
            technologies       = tech_names,
            open_ports         = open_ports,
            tags               = list(dict.fromkeys(tags)),
            evidence           = evidence[:8],
            is_internet_facing = True,  # conservative assumption
        )

    def _classify_by_name(
        self, identifier: str, evidence: list[str], tags: list[str]
    ) -> tuple[Optional[AssetType], float, RiskLevel]:
        identifier_lower = identifier.lower()
        for rule in self._compiled_rules:
            for pattern in rule["_re"]:
                if pattern.search(identifier_lower):
                    evidence.append(f"Name pattern: {pattern.pattern}")
                    tags.append(rule["asset_type"].value)
                    return rule["asset_type"], rule["confidence"], rule["risk"]
        return None, 0.0, RiskLevel.INFO

    def _classify_by_tech(
        self, tech_names: list[str], evidence: list[str], tags: list[str]
    ) -> tuple[Optional[AssetType], float, RiskLevel]:
        best_conf = 0.0
        best_type = None
        best_risk = RiskLevel.INFO

        for tech in tech_names:
            mapping = TECH_TYPE_MAP.get(tech)
            if mapping:
                asset_type, risk = mapping
                conf = 0.85
                if conf > best_conf:
                    best_conf = conf
                    best_type = asset_type
                    best_risk = risk
                    evidence.append(f"Technology: {tech}")
                    tags.append(tech)

        return best_type, best_conf, best_risk

    def _classify_by_ports(
        self, open_ports: list[int], evidence: list[str], tags: list[str]
    ) -> tuple[Optional[AssetType], float]:
        for port in open_ports:
            role = PORT_ROLE_HINTS.get(port)
            if role:
                evidence.append(f"Port hint: {port} → {role.value}")
                tags.append(f"port_{port}")
                return role, 0.70
        return None, 0.0

    def _enforce_min_risk(self, asset_type: AssetType, risk: RiskLevel) -> RiskLevel:
        """Enforce minimum risk levels for inherently risky asset types."""
        minimums: dict[AssetType, RiskLevel] = {
            AssetType.CICD:       RiskLevel.HIGH,
            AssetType.ADMIN:      RiskLevel.HIGH,
            AssetType.DATABASE:   RiskLevel.HIGH,
            AssetType.CLOUD_INFRA: RiskLevel.HIGH,
            AssetType.MONITORING: RiskLevel.MEDIUM,
            AssetType.STAGING:    RiskLevel.MEDIUM,
            AssetType.DEVELOPMENT: RiskLevel.MEDIUM,
        }
        min_risk = minimums.get(asset_type)
        if min_risk and risk.numeric < min_risk.numeric:
            return min_risk
        return risk

    def _compile_rules(self) -> list[dict]:
        compiled = []
        for rule in NAMING_RULES:
            compiled.append({
                **rule,
                "_re": [re.compile(p, re.IGNORECASE) for p in rule["patterns"]],
            })
        return compiled
