"""
ReconX — Stage 9: Intelligence Pipeline.

Orchestrates all intelligence analysis modules in sequence:

  ReconResult
     ↓ CorrelationEngine     → CorrelatedFindings
     ↓ IntelRiskScorer       → IntelRiskScore
     ↓ ConfidenceEngine      → per-finding confidence
     ↓ AttackSurfaceMapper   → AttackGraph
     ↓ AssetClassifier       → ClassifiedAssets
     ↓ AnomalyDetector       → AnomalyFindings
     ↓ FingerprintCorrelator → TechProfiles
     ↓ ExposurePrioritizer   → PrioritizedExposures
     ↓ RecommendationEngine  → Recommendations
     ↓ RelationshipGraph     → Queryable graph
     ↓ IntelligenceReport    (final output)

Rich terminal display with live progress.
"""
from __future__ import annotations

import logging
import time
from typing import Optional

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich import box

from ...models.findings import ReconResult
from ...models.intelligence import (
    IntelligenceReport, RiskLevel, AttackGraph,
)
from .correlation_engine    import CorrelationEngine
from .risk_scoring          import IntelRiskScorer
from .confidence_engine     import ConfidenceEngine
from .attack_surface_mapper import AttackSurfaceMapper
from .asset_classifier      import AssetClassifier
from .anomaly_detector      import AnomalyDetector, ExposurePrioritizer, FingerprintCorrelator
from .recommendation_engine import RecommendationEngine
from .relationship_graph    import RelationshipGraph

logger = logging.getLogger("reconx.intelligence.pipeline")

SEV_STYLE = {
    "CRITICAL": "bold red",
    "HIGH":     "red",
    "MEDIUM":   "yellow",
    "LOW":      "cyan",
    "INFO":     "dim",
}


class IntelligencePipeline:
    """
    Orchestrates the full Stage 9 intelligence analysis pipeline.

    Usage:
        pipeline = IntelligencePipeline(console=console)
        report   = pipeline.run(result)
    """

    def __init__(self, console: Optional[Console] = None) -> None:
        self._console    = console or Console()
        self._correlator = CorrelationEngine()
        self._scorer     = IntelRiskScorer()
        self._confidence = ConfidenceEngine()
        self._mapper     = AttackSurfaceMapper()
        self._classifier = AssetClassifier()
        self._anomaly    = AnomalyDetector()
        self._fingerprint = FingerprintCorrelator()
        self._prioritizer = ExposurePrioritizer()
        self._recommender = RecommendationEngine()

    # ── Public API ─────────────────────────────────────────────────────────────

    def run(self, result: ReconResult) -> IntelligenceReport:
        """
        Execute the full intelligence pipeline on a ReconResult.

        Returns:
            IntelligenceReport — complete intelligence output
        """
        t0 = time.perf_counter()
        self._print_header(result.target)

        # ── Step 1: Fingerprint correlation ───────────────────────────────────
        tech_profiles = self._fingerprint.correlate(result.technologies, result.ports)
        self._status("Fingerprint Correlator", f"{len(tech_profiles)} technology profiles resolved")

        # ── Step 2: Finding correlation ───────────────────────────────────────
        correlated = self._correlator.correlate(result)
        critical_c = sum(1 for c in correlated if c.risk_level == RiskLevel.CRITICAL)
        high_c     = sum(1 for c in correlated if c.risk_level == RiskLevel.HIGH)
        self._status(
            "Correlation Engine",
            f"{len(correlated)} linked findings "
            f"(critical={critical_c}, high={high_c})"
        )

        # ── Step 3: Risk scoring ──────────────────────────────────────────────
        risk_score = self._scorer.score(result, correlated)
        self._status(
            "Risk Scoring",
            f"Score: {risk_score.total:.1f}/100 (Grade {risk_score.grade}) — "
            f"{risk_score.risk_level.value}"
        )

        # ── Step 4: Confidence scoring (per CVE and port) ─────────────────────
        port_confidence_avg = 0.0
        if result.ports:
            scores = [self._confidence.score_port(p) for p in result.ports]
            port_confidence_avg = sum(s.score for s in scores) / len(scores)
        self._status(
            "Confidence Engine",
            f"Avg port confidence: {port_confidence_avg:.0%} | "
            f"{len(result.cve_matches)} CVEs scored"
        )

        # ── Step 5: Attack surface mapping ────────────────────────────────────
        attack_graph = self._mapper.map(result, correlated)
        self._status(
            "Attack Surface Mapper",
            f"{attack_graph.node_count} nodes, {attack_graph.edge_count} edges, "
            f"{len(attack_graph.paths)} attack paths"
        )

        # ── Step 6: Asset classification ──────────────────────────────────────
        assets = self._classifier.classify_result(result)
        asset_summary = self._classifier.summarize(assets)
        self._status(
            "Asset Classifier",
            f"{len(assets)} assets classified — "
            f"admin={asset_summary.get('admin', 0)} "
            f"cicd={asset_summary.get('cicd', 0)} "
            f"staging={asset_summary.get('staging', 0)}"
        )

        # ── Step 7: Anomaly detection ─────────────────────────────────────────
        anomalies = self._anomaly.detect(result)
        crit_anomalies = [a for a in anomalies if a.risk_level == RiskLevel.CRITICAL]
        if crit_anomalies:
            self._warn(f"Anomaly Detector: {len(crit_anomalies)} critical anomalies — "
                       + crit_anomalies[0].description[:60])
        else:
            self._status("Anomaly Detector", f"{len(anomalies)} anomalies detected")

        # ── Step 8: Exposure prioritization ──────────────────────────────────
        prioritized = self._prioritizer.prioritize(correlated, result)
        self._status("Exposure Prioritizer", f"{len(prioritized)} findings prioritized")

        # ── Step 9: Recommendations ───────────────────────────────────────────
        recommendations = self._recommender.generate(result, correlated, assets)
        self._status("Recommendation Engine", f"{len(recommendations)} recommendations generated")

        # ── Step 10: Relationship graph ───────────────────────────────────────
        rel_graph  = RelationshipGraph(attack_graph)
        graph_stats = rel_graph.stats()
        self._status(
            "Relationship Graph",
            f"{graph_stats['node_count']} nodes, "
            f"{graph_stats['edge_count']} edges, "
            f"avg degree={graph_stats['avg_degree']}"
        )

        duration = time.perf_counter() - t0

        # ── Assemble report ───────────────────────────────────────────────────
        report = IntelligenceReport(
            target             = result.target,
            timestamp          = result.timestamp,
            risk_score         = risk_score,
            attack_graph       = attack_graph,
            correlated_findings = correlated,
            classified_assets  = assets,
            recommendations    = recommendations,
            anomalies          = [
                {
                    "type":        a.anomaly_type,
                    "description": a.description,
                    "risk":        a.risk_level.value,
                    "evidence":    a.evidence,
                    "confidence":  a.confidence,
                }
                for a in anomalies
            ],
            stats = {
                "correlated":     len(correlated),
                "critical":       critical_c,
                "high":           high_c,
                "assets":         len(assets),
                "anomalies":      len(anomalies),
                "attack_paths":   len(attack_graph.paths),
                "graph_nodes":    attack_graph.node_count,
                "graph_edges":    attack_graph.edge_count,
                "recommendations": len(recommendations),
                "tech_profiles":  len(tech_profiles),
                "duration_s":     round(duration, 2),
            },
            executive_summary = risk_score.summary,
        )

        self._print_results(report, prioritized)
        return report

    # ── Rich output ───────────────────────────────────────────────────────────

    def _print_header(self, target: str) -> None:
        self._console.print()
        self._console.print(Panel.fit(
            f"[bold cyan][ Intelligence Analysis ][/bold cyan]\n"
            f"[white]Target:[/white] [yellow]{target}[/yellow]",
            border_style="cyan",
        ))
        self._console.print()

    def _print_results(self, report: IntelligenceReport, prioritized: list) -> None:
        # ── Correlated findings table ─────────────────────────────────────────
        if report.correlated_findings:
            table = Table(
                title="🔗 Correlated Intelligence Findings",
                box=box.SIMPLE_HEAD, border_style="cyan", show_lines=True,
            )
            table.add_column("Risk",       width=10)
            table.add_column("Confidence", width=11)
            table.add_column("Finding",    width=48)
            table.add_column("Sources",    width=18)
            table.add_column("CVEs",       width=16)

            for cf in report.correlated_findings[:20]:
                sev_s  = SEV_STYLE.get(cf.risk_level.value, "white")
                conf_s = f"{cf.confidence.score:.0%} [{cf.confidence.tier.value}]"
                table.add_row(
                    f"[{sev_s}]{cf.risk_level.value}[/{sev_s}]",
                    conf_s,
                    cf.title[:47],
                    ", ".join(cf.sources[:2]),
                    ", ".join(cf.cves[:2]) or "—",
                )
            self._console.print(table)

        # ── Risk score panel ──────────────────────────────────────────────────
        rs = report.risk_score
        if rs:
            tier_style = SEV_STYLE.get(rs.risk_level.value, "white")
            self._console.print(Panel(
                f"[bold]Risk Score:[/bold] [{tier_style}]{rs.total:.1f}/100 (Grade {rs.grade})[/{tier_style}]\n"
                f"[dim]Exploitability: {rs.exploitability:.1f}/10  "
                f"Exposure: {rs.exposure:.1f}/10  "
                f"Impact: {rs.impact:.1f}/10  "
                f"Confidence: {rs.confidence:.0%}[/dim]\n"
                f"{rs.summary[:200]}",
                title="Intelligence Risk Assessment",
                border_style=tier_style,
            ))

        # ── Top recommendations ───────────────────────────────────────────────
        if report.recommendations:
            self._console.print("\n[bold cyan]🎯 Top Recommendations:[/bold cyan]")
            for rec in report.recommendations[:8]:
                sev_s  = SEV_STYLE.get(rec.risk_level.value, "white")
                effort = {"LOW": "●", "MEDIUM": "●●", "HIGH": "●●●"}.get(rec.effort, "●")
                self._console.print(
                    f"  [{rec.priority:2d}] [{sev_s}]{rec.risk_level.value:8}[/{sev_s}] "
                    f"{effort}  {rec.title}"
                )

        # ── Attack paths ──────────────────────────────────────────────────────
        if report.attack_graph and report.attack_graph.paths:
            self._console.print("\n[bold red]⚔️  Attack Paths Identified:[/bold red]")
            for path in report.attack_graph.paths[:5]:
                sev_s = SEV_STYLE.get(path.risk_level.value, "white")
                self._console.print(
                    f"  [{sev_s}]{path.risk_level.value}[/{sev_s}]  "
                    f"{path.description[:70]}"
                )

        # ── Stats summary ─────────────────────────────────────────────────────
        s = report.stats
        self._console.print()
        self._console.print(
            f"[dim]Intelligence: {s['correlated']} correlated findings | "
            f"{s['graph_nodes']} graph nodes | "
            f"{s['attack_paths']} attack paths | "
            f"{s['recommendations']} recommendations | "
            f"{s['duration_s']}s[/dim]"
        )
        self._console.print()

    def _status(self, label: str, msg: str) -> None:
        self._console.print(f"  [green]✔[/green] [bold]{label:<24}[/bold] → {msg}")

    def _warn(self, msg: str) -> None:
        self._console.print(f"  [yellow]⚠[/yellow] {msg}")
