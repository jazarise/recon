"""
ReconX — Stage 9: Confidence Engine.

Assigns evidence-weighted confidence scores to findings based on:
  - Source reliability tier
  - Signal quality (exact match vs heuristic vs regex)
  - Corroborating evidence from other sources
  - Fingerprint quality (banner/version specificity)
  - Validation success (actively verified)

Produces ConfidenceScore objects consumed throughout intelligence layer.
"""
from __future__ import annotations

import logging
import re
from typing import Optional

from ...models.findings import Port, Technology, CVEMatch, SensitiveFinding
from ...models.intelligence import (
    ConfidenceScore, ConfidenceSignal, ConfidenceTier,
)

logger = logging.getLogger("reconx.intelligence.confidence")


# ── Source reliability tiers ──────────────────────────────────────────────────

SOURCE_RELIABILITY: dict[str, float] = {
    # Active validation (highest)
    "banner_grab":          0.95,
    "tls_fingerprint":      0.92,
    "port_scan_confirmed":  0.90,
    "header_check":         0.90,
    "nuclei_template":      0.88,
    "nikto_active":         0.82,
    # Passive / corroborated
    "cve_database":         0.85,
    "technology_banner":    0.82,
    "whois":                0.80,
    "dns_record":           0.78,
    "passive_subdomain":    0.72,
    # Heuristic / inferred
    "technology_heuristic": 0.65,
    "naming_pattern":       0.60,
    "port_inference":       0.58,
    # Weak / speculative
    "regex_match":          0.45,
    "keyword_scan":         0.40,
    "single_source":        0.35,
}

# Banner specificity rules: more specific = higher confidence
BANNER_SPECIFICITY_PATTERNS: list[tuple[str, float]] = [
    # (pattern, confidence_boost)
    (r"[Aa]pache[/ ]\d+\.\d+\.\d+",         0.15),   # Apache/2.4.51
    (r"nginx/\d+\.\d+\.\d+",                0.15),   # nginx/1.21.0
    (r"OpenSSH[_ ]\d+\.\d+",                0.14),   # OpenSSH_8.9
    (r"Jenkins \d+\.\d+",                   0.18),   # Jenkins 2.387
    (r"IIS[/ ]\d+\.\d+",                    0.14),   # IIS/10.0
    (r"PHP/\d+\.\d+\.\d+",                  0.15),   # PHP/8.1.12
    (r"Tomcat/\d+\.\d+\.\d+",               0.15),   # Apache Tomcat/9.0.65
    (r"GitLab \d+\.\d+",                    0.16),
    (r"Werkzeug/\d+\.\d+",                  0.14),
    (r"Express",                            0.08),   # generic, lower boost
    (r"\d+\.\d+\.\d+",                      0.06),   # any version string
]


class ConfidenceEngine:
    """
    Multi-signal confidence scoring engine.

    Usage:
        engine = ConfidenceEngine()
        score = engine.score_port(port)
        score = engine.score_technology(tech, sources=["banner", "header"])
        score = engine.score_finding(category, evidence=[...])
    """

    # ── Port confidence ────────────────────────────────────────────────────────

    def score_port(self, port: Port) -> ConfidenceScore:
        """
        Confidence that a port finding is accurate.

        Factors:
          - Scan type (SYN vs connect)
          - Banner presence and specificity
          - Service identification quality
        """
        signals: list[ConfidenceSignal] = []
        base = SOURCE_RELIABILITY["port_scan_confirmed"]

        # State confidence
        if port.state == "open":
            signals.append(ConfidenceSignal(
                source="port_scan", signal_type="validated",
                weight=base, description=f"Port {port.number} confirmed open",
            ))
        else:
            base *= 0.75
            signals.append(ConfidenceSignal(
                source="port_scan", signal_type="heuristic",
                weight=base, description=f"Port state: {port.state}",
            ))

        # Banner specificity boost
        if port.banner:
            boost = self._banner_specificity_boost(port.banner)
            base  = min(base + boost, 1.0)
            signals.append(ConfidenceSignal(
                source="banner_grab", signal_type="banner_match",
                weight=boost, description=f"Banner: {port.banner[:50]}",
            ))

        # Service ID
        if port.service and port.service != "unknown":
            base = min(base + 0.04, 1.0)
            signals.append(ConfidenceSignal(
                source="service_detection", signal_type="heuristic",
                weight=0.04, description=f"Service identified: {port.service}",
            ))

        return ConfidenceScore(
            score   = round(base, 3),
            tier    = ConfidenceTier.from_score(base),
            signals = signals,
        )

    # ── Technology confidence ─────────────────────────────────────────────────

    def score_technology(
        self,
        tech:    Technology,
        sources: Optional[list[str]] = None,
    ) -> ConfidenceScore:
        """
        Confidence in a technology detection.

        Factors:
          - Detection sources (banner vs heuristic)
          - Version specificity
          - Number of corroborating sources
        """
        sources  = sources or ["technology_heuristic"]
        signals: list[ConfidenceSignal] = []

        # Start from best source
        best_source = max(
            (SOURCE_RELIABILITY.get(s, 0.40) for s in sources),
            default=0.40,
        )
        base = best_source

        for src in sources:
            reliability = SOURCE_RELIABILITY.get(src, 0.40)
            signals.append(ConfidenceSignal(
                source=src, signal_type="validated" if reliability > 0.80 else "heuristic",
                weight=reliability, description=f"Detected via {src}",
            ))

        # Version specificity
        if tech.version and re.search(r"\d+\.\d+", tech.version):
            boost = 0.10
            base  = min(base + boost, 1.0)
            signals.append(ConfidenceSignal(
                source="version_detection", signal_type="version_match",
                weight=boost, description=f"Version: {tech.version}",
            ))

        # Multi-source corroboration
        if len(sources) >= 3:
            base = min(base + 0.08, 1.0)
            signals.append(ConfidenceSignal(
                source="multi_source", signal_type="validated",
                weight=0.08, description=f"Corroborated by {len(sources)} sources",
            ))
        elif len(sources) == 2:
            base = min(base + 0.04, 1.0)

        return ConfidenceScore(
            score   = round(base, 3),
            tier    = ConfidenceTier.from_score(base),
            signals = signals,
        )

    # ── CVE match confidence ──────────────────────────────────────────────────

    def score_cve(self, cve: CVEMatch) -> ConfidenceScore:
        """
        Confidence that a CVE finding is a true positive.

        Factors:
          - CVSS score availability
          - Version match specificity
          - Service-port correlation
        """
        signals: list[ConfidenceSignal] = []
        base = SOURCE_RELIABILITY["cve_database"]

        signals.append(ConfidenceSignal(
            source="cve_database", signal_type="validated",
            weight=base, description=f"CVE {cve.cve_id} matched from database",
        ))

        # CVSS boosts confidence (NVD-verified entry)
        if cve.cvss and cve.cvss > 0:
            boost = 0.08
            base  = min(base + boost, 1.0)
            signals.append(ConfidenceSignal(
                source="cvss_score", signal_type="version_match",
                weight=boost, description=f"CVSS score: {cve.cvss}",
            ))

        # Port-service correlation
        if cve.port and cve.service:
            boost = 0.05
            base  = min(base + boost, 1.0)
            signals.append(ConfidenceSignal(
                source="port_service_correlation", signal_type="validated",
                weight=boost, description=f"Service {cve.service} on port {cve.port}",
            ))

        return ConfidenceScore(
            score   = round(base, 3),
            tier    = ConfidenceTier.from_score(base),
            signals = signals,
        )

    # ── Generic finding confidence ─────────────────────────────────────────────

    def score_finding(
        self,
        category:  str,
        evidence:  Optional[list[str]] = None,
        validated: bool = False,
        source:    str  = "single_source",
    ) -> ConfidenceScore:
        """
        Confidence in a generic finding (sensitive file, header issue, etc.).

        Args:
            category:  Finding category (e.g. "env_file", "missing_header")
            evidence:  List of supporting evidence strings
            validated: True if finding was actively verified (not just heuristic)
            source:    Detection source key
        """
        signals: list[ConfidenceSignal] = []
        base = SOURCE_RELIABILITY.get(source, 0.50)

        if validated:
            base = min(base + 0.10, 0.95)
            signals.append(ConfidenceSignal(
                source=source, signal_type="validated",
                weight=base, description=f"{category} actively validated",
            ))
        else:
            signals.append(ConfidenceSignal(
                source=source, signal_type="heuristic",
                weight=base, description=f"{category} detected via {source}",
            ))

        # Evidence corroboration
        ev_count = len(evidence or [])
        if ev_count >= 3:
            base = min(base + 0.08, 1.0)
            signals.append(ConfidenceSignal(
                source="evidence", signal_type="validated",
                weight=0.08, description=f"{ev_count} evidence items",
            ))
        elif ev_count >= 1:
            base = min(base + 0.03, 1.0)

        return ConfidenceScore(
            score   = round(base, 3),
            tier    = ConfidenceTier.from_score(base),
            signals = signals,
        )

    # ── Aggregate confidence ───────────────────────────────────────────────────

    def aggregate(self, scores: list[ConfidenceScore]) -> ConfidenceScore:
        """
        Combine multiple confidence scores into a single aggregate score.
        Uses weighted average with a corroboration bonus for agreement.
        """
        if not scores:
            return ConfidenceScore(score=0.0, tier=ConfidenceTier.WEAK)

        avg = sum(s.score for s in scores) / len(scores)

        # Agreement bonus: if multiple high scores agree, boost further
        high_agreement = sum(1 for s in scores if s.score >= 0.75)
        bonus = min(high_agreement * 0.03, 0.12)
        final = min(avg + bonus, 1.0)

        all_signals: list[ConfidenceSignal] = []
        for s in scores:
            all_signals.extend(s.signals)

        return ConfidenceScore(
            score   = round(final, 3),
            tier    = ConfidenceTier.from_score(final),
            signals = all_signals[:20],   # cap to avoid bloat
            note    = f"Aggregated from {len(scores)} scores (avg={avg:.2f}, bonus={bonus:.2f})",
        )

    # ── Internal helpers ──────────────────────────────────────────────────────

    def _banner_specificity_boost(self, banner: str) -> float:
        """Calculate confidence boost based on how specific a banner string is."""
        boost = 0.0
        for pattern, delta in BANNER_SPECIFICITY_PATTERNS:
            if re.search(pattern, banner, re.IGNORECASE):
                boost = max(boost, delta)   # use highest matching boost
        return boost
