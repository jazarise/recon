"""
ReconX — Stage 9: Intelligence Risk Scoring Engine.

Computes a multi-dimensional risk score from full ReconResult data.
Replaces the legacy single-axis risk scorer with correlated, contextual scoring.

Dimensions:
  - Exploitability  (how easy is an attack?)
  - Exposure        (how much attack surface is visible?)
  - Impact          (what can an attacker achieve?)
  - Confidence      (how reliable are the findings?)

Output: IntelRiskScore with A–F grade and factor breakdown.
"""
from __future__ import annotations

import logging
from typing import Optional

from ...models.findings import ReconResult
from ...models.intelligence import (
    IntelRiskScore, RiskFactor, RiskLevel, CorrelatedFinding,
)

logger = logging.getLogger("reconx.intelligence.risk_scoring")


# ── Scoring constants ─────────────────────────────────────────────────────────

# CVE severity → raw exploitability points
_CVE_EXPLOIT = {"CRITICAL": 18, "HIGH": 12, "MEDIUM": 6, "LOW": 2}

# Port danger scores (per port)
_PORT_DANGER = {
    23: 15, 21: 10, 445: 18, 3389: 14, 3306: 10,
    5432: 8, 1433: 12, 6379: 15, 27017: 12, 9200: 15,
    11211: 10, 2375: 18, 2379: 18, 5900: 10, 4848: 8,
}

# Technology sensitivity weights
_TECH_EXPOSURE = {
    "jenkins": 15, "kubernetes": 18, "docker": 15,
    "elasticsearch": 14, "redis": 14, "mongodb": 12,
    "grafana": 10, "kibana": 10, "prometheus": 8,
    "wordpress": 8, "phpmyadmin": 14, "adminer": 14,
    "jira": 8, "confluence": 8, "gitlab": 10,
}

# Sensitive finding severity → impact points
_SENSITIVE_IMPACT = {"CRITICAL": 20, "HIGH": 14, "MEDIUM": 8, "LOW": 3}

_GRADE_BANDS = [
    (0,  15, "A"),
    (16, 30, "B"),
    (31, 50, "C"),
    (51, 70, "D"),
    (71, 100, "F"),
]


class IntelRiskScorer:
    """
    Multi-dimensional attack-surface risk scorer.

    Produces an IntelRiskScore with:
      - Exploitability score   (CVEs, dangerous ports, auth issues)
      - Exposure score         (attack surface breadth, tech exposure)
      - Impact score           (sensitive findings, data exposure)
      - Confidence modifier    (reduces score if findings are low-confidence)
      - Correlated multiplier  (amplifies score when findings chain together)
    """

    MAX_PER_DIM   = 40.0    # each dimension capped at 40 pts before normalization
    MAX_TOTAL     = 100.0

    def score(
        self,
        result:     ReconResult,
        correlated: Optional[list[CorrelatedFinding]] = None,
    ) -> IntelRiskScore:
        """
        Compute a full intelligence risk score.

        Args:
            result:     Full ReconResult from scan engine
            correlated: Optional correlated findings from CorrelationEngine

        Returns:
            IntelRiskScore with factor breakdown and letter grade
        """
        factors: list[RiskFactor] = []
        exploitability = self._score_exploitability(result, factors)
        exposure       = self._score_exposure(result, factors)
        impact         = self._score_impact(result, factors)
        chain_bonus    = self._score_chain_bonus(correlated or [], factors)

        # Weighted composite (0–100)
        raw = (
            exploitability * 0.40 +
            exposure       * 0.30 +
            impact         * 0.30
        ) + chain_bonus

        # Clamp
        total = round(min(raw, self.MAX_TOTAL), 1)

        # Normalize dimensions for reporting (0–10 scale)
        expl_norm = round(min(exploitability / self.MAX_PER_DIM * 10, 10.0), 2)
        expo_norm = round(min(exposure       / self.MAX_PER_DIM * 10, 10.0), 2)
        impa_norm = round(min(impact         / self.MAX_PER_DIM * 10, 10.0), 2)

        # Risk level from total
        risk_level = RiskLevel.from_score(total / 10.0)   # convert 0–100 → 0–10

        # Grade
        grade = "A"
        for lo, hi, g in _GRADE_BANDS:
            if lo <= total <= hi:
                grade = g
                break

        # Confidence — use average of all CVE confidences if available
        confidence = self._compute_confidence(result)

        summary = self._generate_summary(total, risk_level, grade, exploitability, exposure, impact)

        logger.info(
            f"Risk score: {total:.1f}/100 ({grade}) — "
            f"expl={expl_norm:.1f} expo={expo_norm:.1f} impa={impa_norm:.1f}"
        )

        return IntelRiskScore(
            total          = total,
            risk_level     = risk_level,
            grade          = grade,
            factors        = factors,
            exploitability = expl_norm,
            exposure       = expo_norm,
            impact         = impa_norm,
            confidence     = confidence,
            summary        = summary,
        )

    # ── Dimension scorers ─────────────────────────────────────────────────────

    def _score_exploitability(
        self, result: ReconResult, factors: list[RiskFactor]
    ) -> float:
        """How easy would exploitation be? CVEs + dangerous ports + auth gaps."""
        pts = 0.0

        # CVE exploitability
        cve_pts = sum(_CVE_EXPLOIT.get(c.severity.upper(), 0) for c in result.cve_matches)
        cve_pts = min(cve_pts, 25.0)
        if cve_pts:
            factors.append(RiskFactor(
                name     = "CVE Exploitability",
                weight   = cve_pts,
                reason   = f"{len(result.cve_matches)} CVE(s) matched — patch required",
                evidence = [f"{c.cve_id} ({c.severity})" for c in result.cve_matches[:4]],
            ))
            pts += cve_pts

        # Dangerous open ports
        port_nums  = {p.number for p in result.ports if p.state in ("open", "open|filtered")}
        port_pts   = sum(_PORT_DANGER.get(n, 0) for n in port_nums)
        port_pts   = min(port_pts, 20.0)
        if port_pts:
            dangerous = [n for n in port_nums if n in _PORT_DANGER]
            factors.append(RiskFactor(
                name     = "Dangerous Open Ports",
                weight   = port_pts,
                reason   = f"{len(dangerous)} high-risk port(s) exposed",
                evidence = [str(p) for p in sorted(dangerous)[:6]],
            ))
            pts += port_pts

        # Takeover candidates (direct exploitability)
        if result.takeover_candidates:
            to_pts = min(len(result.takeover_candidates) * 15, 20.0)
            factors.append(RiskFactor(
                name     = "Subdomain Takeover Candidates",
                weight   = to_pts,
                reason   = f"{len(result.takeover_candidates)} takeover candidate(s)",
                evidence = [tc.subdomain for tc in result.takeover_candidates[:3]],
            ))
            pts += to_pts

        # Expired/self-signed TLS (facilitates MITM)
        if result.tls_info:
            tls = result.tls_info
            if tls.is_expired:
                pts += 8.0
                factors.append(RiskFactor(name="Expired TLS Certificate", weight=8.0,
                    reason="Expired certificate enables MITM attacks", evidence=[]))
            elif 0 <= tls.days_remaining <= 14:
                pts += 5.0
                factors.append(RiskFactor(name="TLS Certificate Expiring (<14d)", weight=5.0,
                    reason=f"Expires in {tls.days_remaining} days", evidence=[]))

        return min(pts, self.MAX_PER_DIM)

    def _score_exposure(
        self, result: ReconResult, factors: list[RiskFactor]
    ) -> float:
        """How much attack surface is exposed? Surface breadth + tech exposure."""
        pts = 0.0

        # Attack surface breadth (subdomains + endpoints + ports)
        surface = len(result.subdomains) + len(result.web_endpoints) // 5 + len(result.ports)
        breadth_pts = min(surface * 0.3, 12.0)
        if breadth_pts:
            factors.append(RiskFactor(
                name     = "Attack Surface Breadth",
                weight   = breadth_pts,
                reason   = (f"{len(result.subdomains)} subdomains, "
                            f"{len(result.web_endpoints)} endpoints, "
                            f"{len(result.ports)} ports"),
                evidence = [],
            ))
            pts += breadth_pts

        # Technology exposure
        tech_names = [t.name.lower() for t in result.technologies]
        tech_pts   = sum(_TECH_EXPOSURE.get(t, 0) for t in tech_names)
        tech_pts   = min(tech_pts, 20.0)
        if tech_pts:
            exposed = [t for t in tech_names if t in _TECH_EXPOSURE]
            factors.append(RiskFactor(
                name     = "High-Risk Technology Exposure",
                weight   = tech_pts,
                reason   = f"Sensitive technologies detected: {', '.join(exposed[:5])}",
                evidence = exposed[:6],
            ))
            pts += tech_pts

        # Missing security headers (exposure to client-side attacks)
        weak_hdrs = [h for h in result.header_findings if h.status in ("missing", "weak")]
        hdr_pts   = min(len(weak_hdrs) * 2.5, 8.0)
        if hdr_pts:
            factors.append(RiskFactor(
                name     = "Missing/Weak Security Headers",
                weight   = hdr_pts,
                reason   = f"{len(weak_hdrs)} header(s) missing or weak",
                evidence = [h.header for h in weak_hdrs[:5]],
            ))
            pts += hdr_pts

        return min(pts, self.MAX_PER_DIM)

    def _score_impact(
        self, result: ReconResult, factors: list[RiskFactor]
    ) -> float:
        """What can an attacker achieve? Data exposure + sensitive findings."""
        pts = 0.0

        # Sensitive findings
        sens_pts = sum(_SENSITIVE_IMPACT.get(f.severity.upper(), 0) for f in result.sensitive_findings)
        sens_pts = min(sens_pts, 25.0)
        if sens_pts:
            factors.append(RiskFactor(
                name     = "Sensitive Asset Exposure",
                weight   = sens_pts,
                reason   = f"{len(result.sensitive_findings)} sensitive finding(s)",
                evidence = [f.category for f in result.sensitive_findings[:4]],
            ))
            pts += sens_pts

        # Email exposure (phishing / spear-phishing surface)
        if result.emails:
            email_pts = min(len(result.emails) * 1.5, 6.0)
            factors.append(RiskFactor(
                name     = "Email Address Exposure",
                weight   = email_pts,
                reason   = f"{len(result.emails)} email(s) discoverable — phishing risk",
                evidence = result.emails[:3],
            ))
            pts += email_pts

        # Self-signed cert → data in transit at risk
        if result.tls_info and result.tls_info.is_self_signed:
            pts += 8.0
            factors.append(RiskFactor(
                name     = "Self-Signed Certificate (Data in Transit Risk)",
                weight   = 8.0,
                reason   = "Users accept self-signed certs → MITM data exposure",
                evidence = [],
            ))

        return min(pts, self.MAX_PER_DIM)

    def _score_chain_bonus(
        self,
        correlated: list[CorrelatedFinding],
        factors:    list[RiskFactor],
    ) -> float:
        """Bonus points when correlated findings form attack chains."""
        critical_chains = [cf for cf in correlated
                           if cf.is_chain and cf.risk_level == RiskLevel.CRITICAL]
        high_chains     = [cf for cf in correlated
                           if cf.is_chain and cf.risk_level == RiskLevel.HIGH]

        bonus = len(critical_chains) * 5.0 + len(high_chains) * 2.0
        bonus = min(bonus, 15.0)

        if bonus:
            factors.append(RiskFactor(
                name     = "Attack Chain Amplification",
                weight   = bonus,
                reason   = f"{len(critical_chains)} critical + {len(high_chains)} high chains detected",
                evidence = [cf.title for cf in (critical_chains + high_chains)[:4]],
            ))

        return bonus

    # ── Confidence ────────────────────────────────────────────────────────────

    def _compute_confidence(self, result: ReconResult) -> float:
        """Overall finding confidence — based on data richness."""
        signals = 0
        if result.ports:          signals += 2
        if result.technologies:   signals += 2
        if result.subdomains:     signals += 1
        if result.dns_records:    signals += 1
        if result.header_findings: signals += 1
        if result.tls_info:       signals += 1
        if result.cve_matches:    signals += 2
        # Normalize to 0–1
        return round(min(signals / 10.0, 1.0), 2)

    # ── Summary ───────────────────────────────────────────────────────────────

    def _generate_summary(
        self,
        total:         float,
        risk_level:    RiskLevel,
        grade:         str,
        exploitability: float,
        exposure:      float,
        impact:        float,
    ) -> str:
        tier_labels = {
            RiskLevel.CRITICAL: "CRITICAL RISK — Immediate security action required.",
            RiskLevel.HIGH:     "HIGH RISK — Urgent remediation required within 72 hours.",
            RiskLevel.MEDIUM:   "MODERATE RISK — Address within 2 weeks.",
            RiskLevel.LOW:      "LOW RISK — Scheduled hardening recommended.",
            RiskLevel.INFO:     "MINIMAL RISK — Continue monitoring.",
        }
        dominant = max(
            [("Exploitability", exploitability), ("Exposure", exposure), ("Impact", impact)],
            key=lambda x: x[1],
        )
        return (
            f"{tier_labels.get(risk_level, '')} "
            f"Score: {total:.1f}/100 (Grade {grade}). "
            f"Primary driver: {dominant[0]} ({dominant[1]:.1f} pts). "
        )
