"""
ReconX — Stage 9: Relationship Graph Engine.

Builds a queryable relationship graph from all ReconResult data.
Designed for future visual dashboard integration and graph-based
attack path analysis.

Graph schema:
  Nodes: hosts, IPs, subdomains, services, technologies, endpoints, CVEs
  Edges: resolves_to, exposes, runs, vulnerable_to, related_to, contains

Exportable to:
  - dict (for JSON serialization)
  - Graphviz DOT notation (for CLI visualization)
  - D3.js-compatible adjacency list (for web visualization)
"""
from __future__ import annotations

import hashlib
import logging
from collections import defaultdict
from typing import Optional

from ...models.findings import ReconResult
from ...models.intelligence import AttackGraph, AttackNode, AttackEdge, RiskLevel

logger = logging.getLogger("reconx.intelligence.relationship_graph")


class RelationshipGraph:
    """
    Queryable relationship graph built from ReconResult data.

    Wraps AttackGraph with query methods, path-finding utilities,
    and multiple export formats.
    """

    def __init__(self, graph: Optional[AttackGraph] = None) -> None:
        self._graph      = graph or AttackGraph()
        self._adj: dict[str, set[str]] = defaultdict(set)    # adjacency list
        self._rev: dict[str, set[str]] = defaultdict(set)    # reverse adjacency

        if graph:
            self._build_adjacency()

    # ── Construction ──────────────────────────────────────────────────────────

    def build_from_result(self, result: ReconResult) -> "RelationshipGraph":
        """
        Construct the full relationship graph from a ReconResult.

        Returns self for chaining.
        """
        g = self._graph

        # Root host
        root_id = self._nid("host", result.target)
        g.add_node(AttackNode(
            node_id=root_id, node_type="host", label=result.target,
            risk_level=RiskLevel.INFO, tags=["root", "target"],
            metadata={"ips": result.ip_addresses[:5], "os": result.os_info.get("os", "")},
        ))

        # IPs
        for ip in result.ip_addresses[:10]:
            ip_id = self._nid("ip", ip)
            g.add_node(AttackNode(
                node_id=ip_id, node_type="ip", label=ip,
                risk_level=RiskLevel.INFO, tags=["ip"],
            ))
            self._link(root_id, ip_id, "resolves_to")

        # Subdomains
        for sub in result.subdomains[:150]:
            sub_id = self._nid("subdomain", sub)
            risk   = self._subdomain_risk(sub)
            g.add_node(AttackNode(
                node_id=sub_id, node_type="subdomain", label=sub,
                risk_level=risk, tags=["subdomain"],
            ))
            self._link(root_id, sub_id, "hosts")

        # Open ports → service nodes
        for port in result.ports:
            if port.state not in ("open", "open|filtered"):
                continue
            svc_id = self._nid("service", f"{result.target}:{port.number}")
            g.add_node(AttackNode(
                node_id=svc_id, node_type="service",
                label=f"{port.service or 'unknown'}:{port.number}",
                risk_level=self._port_risk(port.number),
                metadata={"port": port.number, "banner": port.banner[:60] if port.banner else ""},
                tags=["service"],
            ))
            self._link(root_id, svc_id, "exposes")

            # Service → Technology (if banner reveals tech)
            if port.version:
                tech_id = self._nid("technology", port.version[:30])
                g.add_node(AttackNode(
                    node_id=tech_id, node_type="technology", label=port.version[:30],
                    risk_level=RiskLevel.INFO, tags=["technology"],
                ))
                self._link(svc_id, tech_id, "runs")

        # Technologies
        for tech in result.technologies:
            tech_id = self._nid("technology", tech.name.lower())
            g.add_node(AttackNode(
                node_id=tech_id, node_type="technology",
                label=f"{tech.name} {tech.version}".strip(),
                risk_level=self._tech_risk(tech.name.lower()),
                metadata={"category": tech.category, "version": tech.version},
                tags=["technology", tech.category or "unknown"],
            ))
            self._link(root_id, tech_id, "runs")

        # CVEs
        for cve in result.cve_matches:
            cve_id = self._nid("cve", cve.cve_id)
            risk   = RiskLevel.from_string(cve.severity)
            g.add_node(AttackNode(
                node_id=cve_id, node_type="vulnerability", label=cve.cve_id,
                risk_level=risk,
                metadata={"severity": cve.severity, "cvss": cve.cvss, "desc": cve.description[:80]},
                tags=["vulnerability", "cve"],
            ))
            # Link to service
            svc_id = self._nid("service", f"{result.target}:{cve.port}")
            if svc_id in g.nodes:
                self._link(svc_id, cve_id, "vulnerable_to")
            else:
                self._link(root_id, cve_id, "vulnerable_to")

        # Sensitive findings
        for sf in result.sensitive_findings:
            sf_id = self._nid("data", f"{sf.category}:{sf.url}")
            risk  = RiskLevel.from_string(sf.severity)
            g.add_node(AttackNode(
                node_id=sf_id, node_type="data",
                label=f"{sf.category}: {sf.url[:40] or 'unknown'}",
                risk_level=risk,
                metadata={"url": sf.url, "detail": sf.detail[:80]},
                tags=["sensitive", sf.category],
            ))
            self._link(root_id, sf_id, "contains")

        # Web endpoints (sample)
        for ep in result.web_endpoints[:30]:
            ep_type = "api" if "/api/" in ep.lower() or "/v1/" in ep.lower() else "endpoint"
            ep_id   = self._nid("endpoint", ep)
            g.add_node(AttackNode(
                node_id=ep_id, node_type=ep_type, label=ep[:60],
                risk_level=RiskLevel.LOW,
                metadata={"url": ep},
                tags=["endpoint", ep_type],
            ))
            self._link(root_id, ep_id, "exposes")

        self._build_adjacency()
        logger.info(f"Graph built: {g.node_count} nodes, {g.edge_count} edges")
        return self

    # ── Query methods ─────────────────────────────────────────────────────────

    def neighbors(self, node_id: str) -> list[AttackNode]:
        """Return all nodes directly reachable from node_id."""
        return [
            self._graph.nodes[n]
            for n in self._adj.get(node_id, set())
            if n in self._graph.nodes
        ]

    def predecessors(self, node_id: str) -> list[AttackNode]:
        """Return all nodes that have edges pointing TO node_id."""
        return [
            self._graph.nodes[n]
            for n in self._rev.get(node_id, set())
            if n in self._graph.nodes
        ]

    def nodes_by_type(self, node_type: str) -> list[AttackNode]:
        return [n for n in self._graph.nodes.values() if n.node_type == node_type]

    def nodes_by_risk(self, risk: RiskLevel) -> list[AttackNode]:
        return [n for n in self._graph.nodes.values() if n.risk_level == risk]

    def find_paths(
        self,
        start_id: str,
        end_type: str,
        max_depth: int = 4,
    ) -> list[list[str]]:
        """BFS to find all paths from start_id to nodes of end_type."""
        if start_id not in self._graph.nodes:
            return []

        results: list[list[str]] = []
        queue:   list[list[str]] = [[start_id]]

        while queue:
            path = queue.pop(0)
            if len(path) > max_depth:
                continue
            current = path[-1]

            for neighbor_id in self._adj.get(current, set()):
                if neighbor_id in path:   # avoid cycles
                    continue
                new_path = path + [neighbor_id]
                node     = self._graph.nodes.get(neighbor_id)
                if node and node.node_type == end_type:
                    results.append(new_path)
                else:
                    queue.append(new_path)

        return results[:20]   # limit output

    def critical_nodes(self) -> list[AttackNode]:
        """Return nodes with CRITICAL or HIGH risk, sorted by in-degree (most connected first)."""
        critical = [
            n for n in self._graph.nodes.values()
            if n.risk_level in (RiskLevel.CRITICAL, RiskLevel.HIGH)
        ]
        # Sort by in-degree (how many edges point to this node)
        in_degree = {nid: len(preds) for nid, preds in self._rev.items()}
        critical.sort(key=lambda n: in_degree.get(n.node_id, 0), reverse=True)
        return critical

    def subgraph(self, node_ids: set[str]) -> AttackGraph:
        """Extract a subgraph containing only the specified node IDs."""
        sub = AttackGraph()
        for nid in node_ids:
            if nid in self._graph.nodes:
                sub.add_node(self._graph.nodes[nid])
        for edge in self._graph.edges:
            if edge.source_id in node_ids and edge.target_id in node_ids:
                sub.add_edge(edge)
        return sub

    # ── Export formats ────────────────────────────────────────────────────────

    def to_dict(self) -> dict:
        """Serialize to dict (JSON-compatible)."""
        return self._graph.to_dict()

    def to_dot(self) -> str:
        """
        Export as Graphviz DOT notation for CLI visualization.

        Usage: python -c "..." | dot -Tpng -o graph.png
        """
        lines = ["digraph reconx_attack_surface {", "  rankdir=LR;",
                 "  node [shape=box, style=filled];"]

        risk_colors = {
            RiskLevel.CRITICAL: "#ff2d55",
            RiskLevel.HIGH:     "#ff6b35",
            RiskLevel.MEDIUM:   "#ffd60a",
            RiskLevel.LOW:      "#30d158",
            RiskLevel.INFO:     "#8e8e93",
        }

        for node in self._graph.nodes.values():
            color = risk_colors.get(node.risk_level, "#8e8e93")
            label = node.label.replace('"', "'")[:40]
            lines.append(
                f'  "{node.node_id}" [label="{label}", '
                f'fillcolor="{color}", fontcolor="white"];'
            )

        for edge in self._graph.edges:
            lines.append(
                f'  "{edge.source_id}" -> "{edge.target_id}" '
                f'[label="{edge.relationship}"];'
            )

        lines.append("}")
        return "\n".join(lines)

    def to_d3_adjacency(self) -> dict:
        """
        Export as D3.js-compatible adjacency list for web visualization.

        Format:
          {"nodes": [...], "links": [...]}
        """
        risk_numeric = {
            RiskLevel.CRITICAL: 5,
            RiskLevel.HIGH:     4,
            RiskLevel.MEDIUM:   3,
            RiskLevel.LOW:      2,
            RiskLevel.INFO:     1,
        }

        nodes = [
            {
                "id":    n.node_id,
                "label": n.label[:40],
                "type":  n.node_type,
                "risk":  n.risk_level.value,
                "group": risk_numeric.get(n.risk_level, 1),
            }
            for n in self._graph.nodes.values()
        ]

        links = [
            {
                "source":       e.source_id,
                "target":       e.target_id,
                "relationship": e.relationship,
                "weight":       e.weight,
            }
            for e in self._graph.edges
        ]

        return {"nodes": nodes, "links": links}

    def stats(self) -> dict:
        """Return graph statistics summary."""
        type_counts: dict[str, int] = {}
        risk_counts: dict[str, int] = {}

        for node in self._graph.nodes.values():
            type_counts[node.node_type] = type_counts.get(node.node_type, 0) + 1
            risk_counts[node.risk_level.value] = risk_counts.get(node.risk_level.value, 0) + 1

        avg_degree = (
            sum(len(v) for v in self._adj.values()) / len(self._adj)
            if self._adj else 0.0
        )

        return {
            "node_count":      self._graph.node_count,
            "edge_count":      self._graph.edge_count,
            "path_count":      len(self._graph.paths),
            "by_type":         type_counts,
            "by_risk":         risk_counts,
            "avg_degree":      round(avg_degree, 2),
            "critical_nodes":  risk_counts.get("CRITICAL", 0),
            "high_nodes":      risk_counts.get("HIGH", 0),
        }

    @property
    def graph(self) -> AttackGraph:
        return self._graph

    # ── Internal helpers ──────────────────────────────────────────────────────

    def _link(self, source: str, target: str, relationship: str, weight: float = 1.0) -> None:
        self._graph.add_edge(AttackEdge(
            source_id=source, target_id=target,
            relationship=relationship, weight=weight,
        ))
        self._adj[source].add(target)
        self._rev[target].add(source)

    def _build_adjacency(self) -> None:
        self._adj.clear()
        self._rev.clear()
        for edge in self._graph.edges:
            self._adj[edge.source_id].add(edge.target_id)
            self._rev[edge.target_id].add(edge.source_id)

    _HIGH_RISK_PORTS = {23, 21, 445, 6379, 27017, 9200, 2375, 2379, 11211}

    def _port_risk(self, port: int) -> RiskLevel:
        if port in self._HIGH_RISK_PORTS: return RiskLevel.CRITICAL
        if port in {3306, 5432, 1433, 3389, 3000, 5601}: return RiskLevel.MEDIUM
        return RiskLevel.LOW

    _HIGH_RISK_TECH = {"jenkins", "kubernetes", "docker", "elasticsearch", "redis", "mongodb"}

    def _tech_risk(self, tech: str) -> RiskLevel:
        if tech in self._HIGH_RISK_TECH: return RiskLevel.HIGH
        return RiskLevel.LOW

    _DEV_PATTERNS = ["dev.", "staging.", "stage.", "test.", "qa.", "admin.", "jenkins."]

    def _subdomain_risk(self, sub: str) -> RiskLevel:
        sub_lower = sub.lower()
        for p in self._DEV_PATTERNS:
            if sub_lower.startswith(p) or f".{p[:-1]}." in sub_lower:
                return RiskLevel.MEDIUM
        return RiskLevel.LOW

    def _nid(self, node_type: str, value: str) -> str:
        return hashlib.md5(
            f"{node_type}::{value}".encode(), usedforsecurity=False
        ).hexdigest()[:14]
