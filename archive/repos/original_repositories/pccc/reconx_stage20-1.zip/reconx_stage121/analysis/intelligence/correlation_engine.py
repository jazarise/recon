"""
ReconX — Stage 9: Correlation Engine.

Correlates findings across all recon sources:
  - ports ↔ services ↔ technologies ↔ vulnerabilities
  - subdomains ↔ exposures
  - endpoints ↔ authentication issues
  - technologies ↔ known CVE clusters
  - multi-source finding amplification

Produces CorrelatedFinding objects with confidence-weighted risk levels.
"""
from __future__ import annotations

import hashlib
import logging
from collections import defaultdict
from typing import Optional

from ...models.findings import ReconResult, Port, Technology, CVEMatch, SensitiveFinding
from ...models.intelligence import (
    CorrelatedFinding, ConfidenceScore, ConfidenceSignal,
    ConfidenceTier, RiskLevel,
)

logger = logging.getLogger("reconx.intelligence.correlation")


# ── Correlation rule definitions ──────────────────────────────────────────────

TECH_CVE_CLUSTERS: dict[str, list[str]] = {
    "apache":        ["CVE-2021-41773", "CVE-2021-42013", "CVE-2017-7679"],
    "nginx":         ["CVE-2021-23017", "CVE-2019-20372"],
    "jenkins":       ["CVE-2024-23897", "CVE-2018-1000861", "CVE-2019-1003000"],
    "log4j":         ["CVE-2021-44228", "CVE-2021-45046"],
    "spring":        ["CVE-2022-22965", "CVE-2022-22963"],
    "wordpress":     ["CVE-2022-21661", "CVE-2019-8942"],
    "php":           ["CVE-2021-21703", "CVE-2019-11043"],
    "tomcat":        ["CVE-2020-1938", "CVE-2019-0232"],
    "elasticsearch": ["CVE-2015-1427", "CVE-2014-3120"],
    "redis":         ["CVE-2022-0543", "CVE-2015-8080"],
    "struts":        ["CVE-2017-5638", "CVE-2018-11776"],
    "iis":           ["CVE-2017-7269", "CVE-2015-1635"],
    "openssl":       ["CVE-2014-0160", "CVE-2022-0778"],
}

# High-risk tech+port combinations → correlated finding
TECH_PORT_CORRELATIONS: list[dict] = [
    {
        "tech": "jenkins",   "ports": [8080, 8443, 80, 443],
        "title": "Jenkins CI/CD System Externally Exposed",
        "risk": RiskLevel.CRITICAL,
        "description": "Jenkins is accessible externally. Default credentials, RCE CVEs, and pipeline secrets make this a critical exposure.",
        "tags": ["cicd", "jenkins", "secrets"],
        "remediation": "Restrict Jenkins to VPN/internal network. Enable authentication. Rotate all pipeline secrets.",
    },
    {
        "tech": "elasticsearch", "ports": [9200, 9300],
        "title": "Elasticsearch Cluster Exposed Without Auth",
        "risk": RiskLevel.CRITICAL,
        "description": "Elasticsearch commonly runs without authentication by default. Full database access possible.",
        "tags": ["database", "exposure", "elasticsearch"],
        "remediation": "Enable X-Pack security. Bind to localhost or internal IPs only.",
    },
    {
        "tech": "redis",     "ports": [6379],
        "title": "Redis Service Exposed (Likely Unauthenticated)",
        "risk": RiskLevel.CRITICAL,
        "description": "Redis on default port is commonly unauthenticated and allows arbitrary data access or RCE via CONFIG SET.",
        "tags": ["database", "redis", "unauthenticated"],
        "remediation": "Set requirepass. Bind to 127.0.0.1. Disable SLAVEOF and CONFIG commands from external access.",
    },
    {
        "tech": "mongodb",   "ports": [27017, 27018],
        "title": "MongoDB Exposed Without Authentication",
        "risk": RiskLevel.CRITICAL,
        "description": "MongoDB on default port with no auth exposes all databases to any client.",
        "tags": ["database", "mongodb", "exposure"],
        "remediation": "Enable --auth flag. Bind to internal interfaces. Use network-level access control.",
    },
    {
        "tech": "grafana",   "ports": [3000, 80, 443],
        "title": "Grafana Dashboard Externally Accessible",
        "risk": RiskLevel.HIGH,
        "description": "Grafana admin interface exposed. Default credentials (admin/admin) frequently used. Contains infrastructure metrics and potential data source credentials.",
        "tags": ["monitoring", "grafana", "dashboard"],
        "remediation": "Change default credentials. Enable OAuth. Restrict by IP allowlist.",
    },
    {
        "tech": "kibana",    "ports": [5601],
        "title": "Kibana Dashboard Exposed",
        "risk": RiskLevel.HIGH,
        "description": "Kibana provides full visibility into Elasticsearch data. Often deployed without authentication.",
        "tags": ["monitoring", "kibana", "exposure"],
        "remediation": "Enable X-Pack security. Restrict access to internal network or VPN.",
    },
    {
        "tech": "kubernetes", "ports": [6443, 8443, 10250, 2379],
        "title": "Kubernetes API / Cluster Component Exposed",
        "risk": RiskLevel.CRITICAL,
        "description": "Kubernetes API server or cluster component is internet-facing. Cluster takeover risk.",
        "tags": ["kubernetes", "container", "api"],
        "remediation": "Restrict API server access. Enable RBAC. Rotate all service account tokens.",
    },
    {
        "tech": "docker",    "ports": [2375, 2376],
        "title": "Docker Daemon API Exposed",
        "risk": RiskLevel.CRITICAL,
        "description": "Unauthenticated Docker API allows container management, host filesystem access, and privilege escalation.",
        "tags": ["docker", "container", "unauthenticated"],
        "remediation": "Disable remote API or require TLS client certificates. Use Unix socket locally only.",
    },
]

# Port-based dangerous service correlations
DANGEROUS_PORT_RULES: list[dict] = [
    {"port": 23,    "title": "Telnet Service Exposed",          "risk": RiskLevel.CRITICAL,
     "desc": "Telnet transmits credentials in cleartext. Replace with SSH immediately.",
     "remediation": "Disable Telnet. Use SSH exclusively."},
    {"port": 21,    "title": "FTP Service Exposed",             "risk": RiskLevel.HIGH,
     "desc": "FTP transmits credentials in cleartext. FTPS or SFTP should be used.",
     "remediation": "Replace with SFTP or FTPS. Disable anonymous access."},
    {"port": 445,   "title": "SMB Port Exposed Externally",     "risk": RiskLevel.CRITICAL,
     "desc": "SMB exposed to internet is highly dangerous — EternalBlue, ransomware vector.",
     "remediation": "Block port 445 at perimeter firewall. Patch immediately."},
    {"port": 3389,  "title": "RDP Exposed to Internet",         "risk": RiskLevel.HIGH,
     "desc": "RDP exposed externally is a primary ransomware delivery vector.",
     "remediation": "Move RDP behind VPN. Enable NLA. Use a non-standard port if possible."},
    {"port": 3306,  "title": "MySQL Exposed Externally",        "risk": RiskLevel.HIGH,
     "desc": "MySQL on default port accessible from internet — brute-force and data exposure risk.",
     "remediation": "Bind MySQL to 127.0.0.1. Use SSH tunnels for remote access."},
    {"port": 5432,  "title": "PostgreSQL Exposed Externally",   "risk": RiskLevel.HIGH,
     "desc": "PostgreSQL accessible from internet — brute-force and data exposure.",
     "remediation": "Restrict pg_hba.conf. Bind to localhost."},
    {"port": 1433,  "title": "MSSQL Exposed Externally",        "risk": RiskLevel.HIGH,
     "desc": "MSSQL on default port accessible externally — brute-force and data exfil risk.",
     "remediation": "Block at perimeter. Use VPN for remote DBA access."},
    {"port": 11211, "title": "Memcached Exposed (DDoS Risk)",   "risk": RiskLevel.HIGH,
     "desc": "Memcached used in amplification DDoS attacks when externally accessible.",
     "remediation": "Bind to 127.0.0.1. Add firewall rule to block external access."},
    {"port": 2379,  "title": "etcd Exposed (Kubernetes Secrets)", "risk": RiskLevel.CRITICAL,
     "desc": "etcd stores all Kubernetes secrets. Unauthenticated access = full cluster compromise.",
     "remediation": "Restrict etcd to cluster-internal interfaces. Enable TLS client auth."},
]

# Sensitive finding + technology correlations
SENSITIVE_TECH_AMPLIFIERS: dict[str, dict] = {
    ("env_file", "wordpress"): {
        "title": ".env File on WordPress — Credential Exposure",
        "risk": RiskLevel.CRITICAL,
        "description": "WordPress .env file exposed — typically contains DB credentials and API keys.",
    },
    ("source_control", "php"): {
        "title": ".git Directory on PHP App — Source Code Exposure",
        "risk": RiskLevel.HIGH,
        "description": "Version control metadata exposed on PHP application — full source code reconstructable.",
    },
    ("backup_file", "database"): {
        "title": "Database Backup File Exposed",
        "risk": RiskLevel.CRITICAL,
        "description": "Database backup accessible via web — complete data exfiltration possible.",
    },
}


class CorrelationEngine:
    """
    Cross-source finding correlator for full ReconResult objects.

    Correlates:
      - Technologies × CVEs
      - Technologies × Ports → compound exposures
      - Sensitive findings × Technologies → amplified risk
      - Subdomain patterns × Exposure types
      - Open ports → dangerous service warnings
    """

    def correlate(self, result: ReconResult) -> list[CorrelatedFinding]:
        """
        Run all correlation rules against a ReconResult.

        Returns:
            Deduplicated list of CorrelatedFinding objects, sorted by risk.
        """
        all_findings: list[CorrelatedFinding] = []

        tech_names = [t.name.lower() for t in result.technologies]
        port_nums  = [p.number for p in result.ports if p.state in ("open", "open|filtered")]

        # ── Rule 1: Tech × CVE cluster ────────────────────────────────────────
        all_findings.extend(self._correlate_tech_cves(tech_names, result.cve_matches))

        # ── Rule 2: Tech × Port → compound exposure ───────────────────────────
        all_findings.extend(self._correlate_tech_ports(tech_names, port_nums))

        # ── Rule 3: Dangerous open ports ──────────────────────────────────────
        all_findings.extend(self._correlate_dangerous_ports(result.ports))

        # ── Rule 4: Sensitive findings × Technologies ──────────────────────────
        all_findings.extend(self._correlate_sensitive_tech(result.sensitive_findings, tech_names))

        # ── Rule 5: Subdomain patterns ────────────────────────────────────────
        all_findings.extend(self._correlate_subdomain_exposure(result.subdomains))

        # ── Rule 6: Auth issues ────────────────────────────────────────────────
        all_findings.extend(self._correlate_auth_issues(result))

        # ── Deduplicate ────────────────────────────────────────────────────────
        seen: set[str] = set()
        unique: list[CorrelatedFinding] = []
        for cf in all_findings:
            if cf.finding_id not in seen:
                seen.add(cf.finding_id)
                unique.append(cf)

        # Sort by risk level desc
        unique.sort(key=lambda f: f.risk_level.numeric, reverse=True)
        logger.info(f"Correlation complete — {len(unique)} findings from {len(all_findings)} candidates")
        return unique

    # ── Correlation rules ─────────────────────────────────────────────────────

    def _correlate_tech_cves(
        self, tech_names: list[str], cve_matches: list[CVEMatch]
    ) -> list[CorrelatedFinding]:
        """Correlate detected technologies with their known CVE clusters."""
        findings: list[CorrelatedFinding] = []

        for tech, cluster_cves in TECH_CVE_CLUSTERS.items():
            if tech not in tech_names:
                continue
            # Find which cluster CVEs are actually in scan results
            matched = [c for c in cve_matches if c.cve_id in cluster_cves]
            if not matched:
                # Still flag tech presence for CVE awareness (lower confidence)
                confidence = self._make_confidence(
                    0.65, [ConfidenceSignal(
                        source="technology_detection", signal_type="heuristic",
                        weight=0.65,
                        description=f"Technology '{tech}' detected — known CVE cluster exists",
                    )]
                )
                risk = RiskLevel.MEDIUM
            else:
                confidence = self._make_confidence(
                    0.90, [ConfidenceSignal(
                        source="cve_match", signal_type="validated",
                        weight=0.90,
                        description=f"{len(matched)} CVEs confirmed for {tech}",
                    )]
                )
                max_sev = max(matched, key=lambda c: {"CRITICAL": 4, "HIGH": 3, "MEDIUM": 2, "LOW": 1}.get(c.severity.upper(), 0))
                risk    = RiskLevel.from_string(max_sev.severity)

            finding_id = self._make_id(f"tech_cve_{tech}")
            findings.append(CorrelatedFinding(
                finding_id   = finding_id,
                title        = f"{tech.title()} — Known CVE Exposure",
                description  = (
                    f"Technology '{tech}' detected with {len(cluster_cves)} known CVEs in cluster. "
                    f"{len(matched)} confirmed by scanner. Immediate patching recommended."
                ),
                risk_level   = risk,
                confidence   = confidence,
                sources      = ["technology_detection", "cve_mapper"],
                cves         = [c.cve_id for c in matched] or cluster_cves[:3],
                tags         = [tech, "cve", "technology"],
                remediation  = f"Update {tech} to latest patched version. Review {', '.join(cluster_cves[:2])} advisories.",
                evidence     = [f"Detected: {tech}", f"Matched CVEs: {len(matched)}"],
            ))

        return findings

    def _correlate_tech_ports(
        self, tech_names: list[str], port_nums: list[int]
    ) -> list[CorrelatedFinding]:
        """Correlate technology presence with associated dangerous ports."""
        findings: list[CorrelatedFinding] = []

        for rule in TECH_PORT_CORRELATIONS:
            tech  = rule["tech"]
            ports = rule["ports"]

            tech_present = tech in tech_names
            port_present = any(p in port_nums for p in ports)

            if not (tech_present or port_present):
                continue

            # Both present = higher confidence
            if tech_present and port_present:
                conf_score = 0.95
                evidence   = [f"Technology '{tech}' detected", f"Port(s) {[p for p in ports if p in port_nums]} open"]
            elif port_present:
                conf_score = 0.75
                evidence   = [f"Port(s) {[p for p in ports if p in port_nums]} open (tech inferred)"]
            else:
                conf_score = 0.60
                evidence   = [f"Technology '{tech}' detected on standard port"]

            confidence = self._make_confidence(conf_score, [ConfidenceSignal(
                source="port_tech_correlation", signal_type="banner_match" if conf_score > 0.85 else "heuristic",
                weight=conf_score, description=f"Tech+port correlation: {tech}",
            )])

            finding_id = self._make_id(f"tech_port_{tech}")
            findings.append(CorrelatedFinding(
                finding_id   = finding_id,
                title        = rule["title"],
                description  = rule["description"],
                risk_level   = rule["risk"],
                confidence   = confidence,
                sources      = ["port_scan", "technology_detection"],
                tags         = rule["tags"],
                remediation  = rule["remediation"],
                evidence     = evidence,
            ))

        return findings

    def _correlate_dangerous_ports(self, ports: list[Port]) -> list[CorrelatedFinding]:
        """Flag individually dangerous open ports."""
        findings: list[CorrelatedFinding] = []
        open_ports = {p.number: p for p in ports if p.state in ("open", "open|filtered")}

        for rule in DANGEROUS_PORT_RULES:
            port_num = rule["port"]
            if port_num not in open_ports:
                continue

            port   = open_ports[port_num]
            banner = port.banner or ""
            conf_score = 0.95 if banner else 0.85

            confidence = self._make_confidence(conf_score, [ConfidenceSignal(
                source="port_scan", signal_type="banner_match" if banner else "validated",
                weight=conf_score,
                description=f"Port {port_num} confirmed open" + (f" — banner: {banner[:40]}" if banner else ""),
            )])

            finding_id = self._make_id(f"dangerous_port_{port_num}")
            findings.append(CorrelatedFinding(
                finding_id   = finding_id,
                title        = rule["title"],
                description  = rule["desc"],
                risk_level   = rule["risk"],
                confidence   = confidence,
                sources      = ["port_scan"],
                tags         = ["dangerous_port", f"port_{port_num}"],
                remediation  = rule["remediation"],
                evidence     = [f"Port {port_num}/{port.protocol} open", f"Service: {port.service or 'unknown'}"],
            ))

        return findings

    def _correlate_sensitive_tech(
        self, sensitive: list[SensitiveFinding], tech_names: list[str]
    ) -> list[CorrelatedFinding]:
        """Amplify sensitive findings when matched with technology context."""
        findings: list[CorrelatedFinding] = []

        for sf in sensitive:
            cat = sf.category.lower()
            for tech in tech_names:
                key = (cat, tech)
                rule = SENSITIVE_TECH_AMPLIFIERS.get(key)
                if not rule:
                    continue

                confidence = self._make_confidence(0.88, [ConfidenceSignal(
                    source="sensitive_detector", signal_type="validated",
                    weight=0.88,
                    description=f"Sensitive finding '{cat}' amplified by tech '{tech}'",
                )])

                finding_id = self._make_id(f"sensitive_tech_{cat}_{tech}")
                findings.append(CorrelatedFinding(
                    finding_id   = finding_id,
                    title        = rule["title"],
                    description  = rule["description"],
                    risk_level   = rule["risk"],
                    confidence   = confidence,
                    sources      = ["sensitive_detector", "technology_detection"],
                    tags         = [cat, tech, "amplified"],
                    remediation  = sf.detail[:200] if sf.detail else "Remove exposed file immediately.",
                    evidence     = [f"Sensitive: {sf.category}", f"Tech: {tech}", f"URL: {sf.url}"],
                    affected_assets = [sf.url] if sf.url else [],
                ))

        return findings

    def _correlate_subdomain_exposure(self, subdomains: list[str]) -> list[CorrelatedFinding]:
        """Detect dev/staging/admin subdomains that indicate exposed environments."""
        findings: list[CorrelatedFinding] = []

        dev_patterns = ["dev.", "develop.", "development.", "staging.", "stage.", "test.",
                        "qa.", "uat.", "sandbox.", "internal.", "admin.", "mgmt.",
                        "management.", "corp.", "intranet.", "vpn.", "git.", "jenkins.",
                        "ci.", "cd.", "build.", "deploy.", "jira.", "confluence.",
                        "grafana.", "kibana.", "prometheus."]

        for sub in subdomains:
            sub_lower = sub.lower()
            for pattern in dev_patterns:
                if sub_lower.startswith(pattern) or f".{pattern[:-1]}." in sub_lower:
                    finding_id = self._make_id(f"subdomain_exposure_{sub}")
                    findings.append(CorrelatedFinding(
                        finding_id   = finding_id,
                        title        = f"Sensitive Subdomain Discovered: {sub}",
                        description  = (
                            f"Subdomain '{sub}' matches a development/internal pattern "
                            f"('{pattern.rstrip('.')}'). These environments typically have "
                            "weaker security controls and may expose internal tools."
                        ),
                        risk_level   = RiskLevel.MEDIUM,
                        confidence   = self._make_confidence(0.80, [ConfidenceSignal(
                            source="subdomain_enumeration", signal_type="heuristic",
                            weight=0.80, description=f"Pattern match: {pattern}",
                        )]),
                        sources      = ["subdomain_enumeration"],
                        tags         = ["subdomain", pattern.rstrip("."), "environment"],
                        remediation  = "Verify intent and ensure non-production systems are not internet-facing without VPN.",
                        evidence     = [f"Subdomain: {sub}", f"Pattern: {pattern.rstrip('.')}"],
                        affected_assets = [sub],
                    ))
                    break  # one match per subdomain

        return findings

    def _correlate_auth_issues(self, result: ReconResult) -> list[CorrelatedFinding]:
        """Detect authentication-related correlations across header and endpoint data."""
        findings: list[CorrelatedFinding] = []

        # Missing auth headers on API endpoints
        api_endpoints = [e for e in result.web_endpoints
                         if any(kw in e.lower() for kw in ["/api/", "/v1/", "/v2/", "/graphql", "/rest/"])]
        weak_headers  = [h for h in result.header_findings if h.status == "missing"
                         and h.header.lower() in ("content-security-policy", "strict-transport-security")]

        if api_endpoints and weak_headers:
            missing = [h.header for h in weak_headers]
            finding_id = self._make_id("api_missing_headers")
            findings.append(CorrelatedFinding(
                finding_id   = finding_id,
                title        = "API Endpoints with Missing Security Headers",
                description  = (
                    f"{len(api_endpoints)} API endpoint(s) detected while critical security headers "
                    f"({', '.join(missing[:3])}) are absent. APIs without CSP/HSTS are susceptible "
                    "to MITM, XSS, and data leakage."
                ),
                risk_level   = RiskLevel.MEDIUM,
                confidence   = self._make_confidence(0.80, [ConfidenceSignal(
                    source="header_checker", signal_type="validated",
                    weight=0.80, description="API endpoints + missing security headers",
                )]),
                sources      = ["web_crawler", "header_checker"],
                tags         = ["api", "headers", "configuration"],
                remediation  = "Add HSTS and CSP headers to all API responses.",
                evidence     = [f"API endpoints: {len(api_endpoints)}", f"Missing: {', '.join(missing)}"],
                affected_assets = api_endpoints[:5],
            ))

        # Takeover + high subdomain count
        if result.takeover_candidates and len(result.subdomains) > 10:
            finding_id = self._make_id("takeover_large_surface")
            findings.append(CorrelatedFinding(
                finding_id   = finding_id,
                title        = f"Subdomain Takeover Risk Across Large Attack Surface",
                description  = (
                    f"{len(result.takeover_candidates)} takeover candidate(s) identified across "
                    f"{len(result.subdomains)} subdomains. Large subdomain attack surfaces increase "
                    "dangling-DNS exposure."
                ),
                risk_level   = RiskLevel.HIGH,
                confidence   = self._make_confidence(0.90, [ConfidenceSignal(
                    source="passive_recon", signal_type="validated",
                    weight=0.90, description="Takeover candidates confirmed",
                )]),
                sources      = ["subdomain_enumeration", "dns_analysis"],
                tags         = ["takeover", "subdomain", "dns"],
                remediation  = "Remove dangling DNS records. Audit all CNAME targets.",
                evidence     = [
                    f"Candidates: {[tc.subdomain for tc in result.takeover_candidates[:3]]}",
                    f"Total subdomains: {len(result.subdomains)}",
                ],
                affected_assets = [tc.subdomain for tc in result.takeover_candidates],
            ))

        return findings

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _make_id(self, key: str) -> str:
        return hashlib.md5(key.encode(), usedforsecurity=False).hexdigest()[:12]

    def _make_confidence(self, score: float, signals: list[ConfidenceSignal]) -> ConfidenceScore:
        return ConfidenceScore(
            score   = round(max(0.0, min(1.0, score)), 3),
            tier    = ConfidenceTier.from_score(score),
            signals = signals,
        )
