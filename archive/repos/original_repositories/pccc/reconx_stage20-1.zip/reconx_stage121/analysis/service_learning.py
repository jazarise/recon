"""
ReconX — Stage 17: Service Learning Context.

Provides rich educational context for any discovered service, port, or
technology encountered during a scan.  Integrates with LearningMode to
display inline when the user clicks on a service in the TUI, or
automatically in guided-learning execution mode.

For each service, provides:
  • Description           — what the service does
  • Common uses           — real-world deployments
  • Security relevance    — why attackers care about it
  • Typical risks         — common vulnerability classes
  • Recommended next tool — what to run next
  • Suggested commands    — ready-to-use command templates
  • Possible errors       — what can go wrong
  • Fix steps             — remediation guidance

Usage:
    from reconx.analysis.service_learning import ServiceLearning

    sl      = ServiceLearning()
    context = sl.get_context(port=445)
    print(context.render())

    # From technology name
    context = sl.get_context(technology="elasticsearch")
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Optional

log = logging.getLogger("reconx.analysis.service_learning")


# ─────────────────────────────────────────────────────────────────────────────
# Data model
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class ServiceContext:
    """Full educational context for a service or technology."""
    service_name:   str
    port:           Optional[int]     = None
    description:    str               = ""
    common_uses:    list[str]         = field(default_factory=list)
    security_relevance: str           = ""
    typical_risks:  list[str]         = field(default_factory=list)
    next_tools:     list[str]         = field(default_factory=list)
    commands:       list[str]         = field(default_factory=list)
    possible_errors: list[str]        = field(default_factory=list)
    fix_steps:      list[str]         = field(default_factory=list)
    references:     list[str]         = field(default_factory=list)
    risk_level:     str               = "MEDIUM"   # LOW | MEDIUM | HIGH | CRITICAL

    def render(self) -> str:
        """Return a formatted plain-text educational block."""
        lines = [
            f"{'─'*60}",
            f"  {self.service_name}"
            + (f"  (port {self.port})" if self.port else ""),
            f"  Risk: {self.risk_level}",
            f"{'─'*60}",
            f"\nDescription:\n  {self.description}",
        ]
        if self.common_uses:
            lines.append("\nCommon Uses:")
            for u in self.common_uses:
                lines.append(f"  • {u}")
        if self.security_relevance:
            lines.append(f"\nSecurity Relevance:\n  {self.security_relevance}")
        if self.typical_risks:
            lines.append("\nTypical Risks:")
            for r in self.typical_risks:
                lines.append(f"  ⚠  {r}")
        if self.next_tools:
            lines.append("\nRecommended Next Tools:")
            for t in self.next_tools:
                lines.append(f"  → {t}")
        if self.commands:
            lines.append("\nSuggested Commands:")
            for c in self.commands:
                lines.append(f"  $ {c}")
        if self.possible_errors:
            lines.append("\nPossible Errors:")
            for e in self.possible_errors:
                lines.append(f"  ! {e}")
        if self.fix_steps:
            lines.append("\nFix Steps:")
            for s in self.fix_steps:
                lines.append(f"  ✓ {s}")
        return "\n".join(lines)

    def to_dict(self) -> dict:
        return {
            "service_name":      self.service_name,
            "port":              self.port,
            "description":       self.description,
            "common_uses":       self.common_uses,
            "security_relevance": self.security_relevance,
            "typical_risks":     self.typical_risks,
            "next_tools":        self.next_tools,
            "commands":          self.commands,
            "possible_errors":   self.possible_errors,
            "fix_steps":         self.fix_steps,
            "risk_level":        self.risk_level,
        }


# ─────────────────────────────────────────────────────────────────────────────
# Service knowledge database
# ─────────────────────────────────────────────────────────────────────────────

_SERVICE_DB: dict[str, ServiceContext] = {}


def _reg(ctx: ServiceContext) -> None:
    """Register a ServiceContext by service name and optional port."""
    _SERVICE_DB[ctx.service_name.lower()] = ctx
    if ctx.port:
        _SERVICE_DB[str(ctx.port)] = ctx


_reg(ServiceContext(
    service_name    = "SMB",
    port            = 445,
    risk_level      = "CRITICAL",
    description     = "Server Message Block — Windows file and printer sharing protocol.",
    common_uses     = [
        "Windows file sharing (shared drives, UNC paths)",
        "Windows print spooling",
        "Active Directory SYSVOL / NETLOGON share distribution",
    ],
    security_relevance = (
        "SMB on port 445 is one of the highest-risk exposures on any network. "
        "EternalBlue (MS17-010) allowed WannaCry ransomware to spread globally. "
        "Null sessions, pass-the-hash, and relay attacks are all feasible."
    ),
    typical_risks   = [
        "EternalBlue / MS17-010 (if SMBv1 enabled)",
        "Null session / anonymous share enumeration",
        "Pass-the-hash (NTLM relay)",
        "Unencrypted credential capture (Responder attacks)",
        "Ransomware lateral movement vector",
    ],
    next_tools      = ["enum4linux-ng", "netexec (nxc)", "smbclient", "nmap --script smb-vuln-*"],
    commands        = [
        "enum4linux-ng -A TARGET",
        "nxc smb TARGET -u '' -p '' --shares",
        "smbclient -L //TARGET -N",
        "nmap -p445 --script smb-vuln-ms17-010 TARGET",
    ],
    possible_errors = [
        "Connection refused — SMB blocked by host firewall",
        "NT_STATUS_ACCESS_DENIED — anonymous access disabled (good)",
        "NT_STATUS_LOGON_FAILURE — credentials required",
    ],
    fix_steps       = [
        "Disable SMBv1 entirely: Set-SmbServerConfiguration -EnableSMB1Protocol $false",
        "Block port 445 at perimeter firewall — never expose to internet",
        "Enable SMB signing to prevent relay attacks",
        "Apply MS17-010 patch (KB4012212) if not already patched",
    ],
))

_reg(ServiceContext(
    service_name    = "SSH",
    port            = 22,
    risk_level      = "MEDIUM",
    description     = "Secure Shell — encrypted remote command-line access protocol.",
    common_uses     = [
        "Remote server administration",
        "Secure file transfer (SFTP/SCP)",
        "Tunneling and port forwarding",
        "Git over SSH",
    ],
    security_relevance = (
        "SSH is normally a low-risk service when properly configured. "
        "Risks arise from weak passwords, outdated versions, exposed root login, "
        "and weak key algorithms."
    ),
    typical_risks   = [
        "Password brute-force (if password auth enabled)",
        "Username enumeration (older OpenSSH versions)",
        "Weak key exchange algorithms (DH-1024, MD5)",
        "Root login enabled",
        "CVE-2023-38408 (ssh-agent forwarding RCE)",
    ],
    next_tools      = ["ssh-audit", "Hydra (brute-force)", "nmap --script ssh*"],
    commands        = [
        "ssh-audit TARGET",
        "nmap -p22 --script ssh-hostkey,ssh2-enum-algos TARGET",
        "hydra -L users.txt -P passwords.txt TARGET ssh",
    ],
    possible_errors = [
        "Connection timeout — SSH blocked or non-standard port",
        "kex_exchange_identification — banner rejection",
    ],
    fix_steps       = [
        "Disable root login: PermitRootLogin no",
        "Disable password auth: PasswordAuthentication no",
        "Update to OpenSSH ≥ 9.x",
        "Remove weak algorithms (diffie-hellman-group1-sha1)",
        "Move to non-standard port + fail2ban to reduce noise",
    ],
))

_reg(ServiceContext(
    service_name    = "RDP",
    port            = 3389,
    risk_level      = "CRITICAL",
    description     = "Remote Desktop Protocol — Microsoft graphical remote access.",
    common_uses     = [
        "Windows remote desktop access",
        "Terminal Server / RDS deployments",
        "IT support and remote management",
    ],
    security_relevance = (
        "RDP exposed to the internet is the #1 ransomware initial access vector. "
        "BlueKeep (CVE-2019-0708) and DejaBlue are wormable. "
        "Credential stuffing and brute-force are trivial."
    ),
    typical_risks   = [
        "BlueKeep (CVE-2019-0708) — pre-auth RCE",
        "DejaBlue (CVE-2019-1181/1182)",
        "Credential brute-force (no account lockout by default)",
        "Pass-the-hash / pass-the-ticket",
        "Man-in-the-middle with NLA disabled",
    ],
    next_tools      = ["nmap --script rdp*", "hydra", "metasploit auxiliary/scanner/rdp"],
    commands        = [
        "nmap -p3389 --script rdp-enum-encryption,rdp-vuln-ms12-020 TARGET",
        "hydra -L users.txt -P pass.txt rdp://TARGET",
    ],
    possible_errors = [
        "CredSSP encryption oracle remediation error — NLA version mismatch",
    ],
    fix_steps       = [
        "Block port 3389 at the perimeter — use VPN gateway instead",
        "Enable Network Level Authentication (NLA)",
        "Apply BlueKeep patch (KB4499175)",
        "Implement account lockout policy",
        "Enable RDP logging via Windows Event Forwarding",
    ],
))

_reg(ServiceContext(
    service_name    = "Redis",
    port            = 6379,
    risk_level      = "CRITICAL",
    description     = "Redis — in-memory data structure store, cache, and message broker.",
    common_uses     = [
        "Application caching layer",
        "Session storage",
        "Real-time pub/sub messaging",
        "Queue backend (Celery, Sidekiq)",
    ],
    security_relevance = (
        "Redis ships with no authentication by default. "
        "An unauthenticated Redis instance exposed to the internet "
        "allows an attacker to read all data, write SSH keys, and "
        "achieve remote code execution via SLAVEOF or cron injection."
    ),
    typical_risks   = [
        "Unauthenticated access — no password required",
        "Arbitrary file write via CONFIG SET / SAVE → SSH key injection",
        "RCE via master-slave replication attack",
        "Data exfiltration (session tokens, secrets)",
    ],
    next_tools      = ["redis-cli", "nmap --script redis-info", "nuclei -t redis/"],
    commands        = [
        "redis-cli -h TARGET info",
        "redis-cli -h TARGET config get bind",
        "nmap -p6379 --script redis-info TARGET",
    ],
    possible_errors = [
        "NOAUTH — authentication required (instance is secured)",
        "ERR operation not permitted — protected-mode active",
    ],
    fix_steps       = [
        "Bind Redis to 127.0.0.1 only (bind 127.0.0.1 in redis.conf)",
        "Set requirepass in redis.conf",
        "Enable protected-mode yes",
        "Use a firewall rule: only allow app server IPs",
        "Upgrade to Redis 7.x (ACL support)",
    ],
))

_reg(ServiceContext(
    service_name    = "Elasticsearch",
    port            = 9200,
    risk_level      = "CRITICAL",
    description     = "Elasticsearch — distributed RESTful search and analytics engine.",
    common_uses     = [
        "Full-text search (websites, apps)",
        "Log aggregation (ELK stack)",
        "Security analytics (SIEM)",
        "E-commerce product search",
    ],
    security_relevance = (
        "Elasticsearch ≤ 6.x has no authentication by default. "
        "Millions of records have been leaked from exposed clusters. "
        "A single GET /_cat/indices reveals all data."
    ),
    typical_risks   = [
        "Unauthenticated read/write access to all indices",
        "Data exfiltration via REST API",
        "Remote code execution via Groovy/Painless script injection (older versions)",
        "Index deletion (ransomware)",
    ],
    next_tools      = ["curl", "nuclei -t elasticsearch/", "nmap --script elasticsearch*"],
    commands        = [
        "curl http://TARGET:9200/_cat/indices?v",
        "curl http://TARGET:9200/_cluster/health",
        "curl http://TARGET:9200/_nodes",
    ],
    possible_errors = [
        "401 Unauthorized — X-Pack security enabled (good)",
    ],
    fix_steps       = [
        "Enable X-Pack security: xpack.security.enabled: true",
        "Bind to 127.0.0.1 or VPC-internal IP only",
        "Use Elasticsearch role-based access control",
        "Upgrade to Elasticsearch 8.x (security on by default)",
    ],
))

_reg(ServiceContext(
    service_name    = "MongoDB",
    port            = 27017,
    risk_level      = "CRITICAL",
    description     = "MongoDB — document-oriented NoSQL database.",
    common_uses     = [
        "Application primary database (Node.js, Python stacks)",
        "Content management systems",
        "IoT data storage",
    ],
    security_relevance = (
        "MongoDB historically shipped with no authentication and listened "
        "on all interfaces.  Hundreds of millions of records were exposed "
        "in large-scale breaches (2017–present)."
    ),
    typical_risks   = [
        "Unauthenticated access — read/write all databases",
        "Data exfiltration via mongodump",
        "Ransomware: data deletion + ransom note injection",
    ],
    next_tools      = ["mongo", "mongodump", "nuclei -t mongodb/"],
    commands        = [
        "mongo --host TARGET --port 27017 --eval 'db.adminCommand({listDatabases:1})'",
        "nmap -p27017 --script mongodb-info TARGET",
    ],
    possible_errors = [
        "Authentication failed — auth required (good)",
        "Connection refused — firewall blocking (good)",
    ],
    fix_steps       = [
        "Enable MongoDB authentication: security.authorization: enabled",
        "Bind to 127.0.0.1: net.bindIp: 127.0.0.1",
        "Create least-privilege application user",
        "Upgrade to MongoDB 6.x+",
    ],
))

_reg(ServiceContext(
    service_name    = "FTP",
    port            = 21,
    risk_level      = "HIGH",
    description     = "File Transfer Protocol — unencrypted file transfer service.",
    common_uses     = [
        "Legacy file hosting",
        "Web server file upload",
        "Backup transfers (legacy environments)",
    ],
    security_relevance = (
        "FTP transmits credentials and data in cleartext. "
        "Anonymous FTP access allows unauthenticated file reads/writes. "
        "vsftpd 2.3.4 contained a famous backdoor."
    ),
    typical_risks   = [
        "Cleartext credential interception",
        "Anonymous FTP access",
        "vsftpd 2.3.4 backdoor (CVE-2011-2523)",
        "FTP bounce attacks",
        "Directory traversal via crafted PASV",
    ],
    next_tools      = ["nmap --script ftp*", "hydra", "ftp (anonymous test)"],
    commands        = [
        "nmap -p21 --script ftp-anon,ftp-vsftpd-backdoor TARGET",
        "ftp -A TARGET  (anonymous login test)",
        "hydra -L users.txt -P pass.txt ftp://TARGET",
    ],
    possible_errors = [
        "530 Login incorrect — anonymous access disabled",
        "Connection refused — FTP behind firewall",
    ],
    fix_steps       = [
        "Replace FTP with SFTP or FTPS",
        "Disable anonymous access",
        "Use chroot jails for FTP users",
        "Block port 21 at perimeter — never expose to internet",
    ],
))

_reg(ServiceContext(
    service_name    = "Docker API",
    port            = 2375,
    risk_level      = "CRITICAL",
    description     = "Docker Engine REST API — unauthenticated by default on port 2375.",
    common_uses     = ["Container management by CI/CD pipelines", "Remote Docker operations"],
    security_relevance = (
        "An exposed Docker API with no TLS equals full host compromise. "
        "An attacker can launch a privileged container, mount the host "
        "filesystem, and escape to root within seconds."
    ),
    typical_risks   = [
        "Full host RCE via privileged container escape",
        "Cryptomining container deployment",
        "Data exfiltration by mounting host volumes",
        "Persistence via cron/SSH key injection",
    ],
    next_tools      = ["docker -H tcp://TARGET:2375 info", "nuclei -t docker/"],
    commands        = [
        "curl http://TARGET:2375/version",
        "docker -H tcp://TARGET:2375 ps",
        "docker -H tcp://TARGET:2375 run --rm -v /:/mnt alpine ls /mnt",
    ],
    possible_errors = [
        "Connection refused — Docker API not listening on TCP (good)",
    ],
    fix_steps       = [
        "Never expose Docker API on TCP without mutual TLS",
        "Use Unix socket only (remove -H tcp:// from dockerd)",
        "Use firewall to block port 2375/2376 from internet",
    ],
))

_reg(ServiceContext(
    service_name    = "Kubernetes API",
    port            = 6443,
    risk_level      = "CRITICAL",
    description     = "Kubernetes API server — cluster management endpoint.",
    common_uses     = [
        "kubectl CLI communication",
        "CI/CD cluster deployments",
        "Internal cluster component communication",
    ],
    security_relevance = (
        "An exposed Kubernetes API may allow unauthenticated anonymous access "
        "or token theft leading to full cluster compromise."
    ),
    typical_risks   = [
        "Anonymous access (system:anonymous binding)",
        "Service account token theft → cluster-admin escalation",
        "Malicious pod deployment for cryptomining/C2",
        "etcd data access (secrets, certs)",
    ],
    next_tools      = ["kubectl", "kube-hunter", "nuclei -t kubernetes/"],
    commands        = [
        "curl -k https://TARGET:6443/version",
        "curl -k https://TARGET:6443/api/v1/namespaces",
        "kube-hunter --remote TARGET",
    ],
    possible_errors = [
        "Unauthorized (401) — authentication required (good)",
        "Forbidden (403) — RBAC enforced (good)",
    ],
    fix_steps       = [
        "Disable anonymous access: --anonymous-auth=false",
        "Enable RBAC: --authorization-mode=RBAC",
        "Restrict API server to VPN/internal network only",
        "Audit service account permissions regularly",
    ],
))

_reg(ServiceContext(
    service_name    = "HTTP",
    port            = 80,
    risk_level      = "LOW",
    description     = "Hypertext Transfer Protocol — unencrypted web service.",
    common_uses     = ["Web application hosting", "API endpoints", "Load balancer health checks"],
    security_relevance = (
        "HTTP in isolation is low risk but signals no TLS enforcement. "
        "Interesting for directory discovery, technology fingerprinting, "
        "and login panel detection."
    ),
    typical_risks   = [
        "No encryption — credentials / sessions transmitted in cleartext",
        "Admin panel exposed on HTTP",
        "Default application on HTTP redirect target",
    ],
    next_tools      = ["httpx", "gobuster", "feroxbuster", "nikto", "nuclei -t http/"],
    commands        = [
        "httpx -u http://TARGET -title -tech-detect -status-code",
        "gobuster dir -u http://TARGET -w /usr/share/wordlists/dirb/common.txt",
        "nikto -h http://TARGET",
    ],
    possible_errors = ["Connection refused — web server not running", "301 redirect to HTTPS"],
    fix_steps       = [
        "Redirect all HTTP to HTTPS (301)",
        "Add HSTS header",
        "Remove server version header",
    ],
))

_reg(ServiceContext(
    service_name    = "SMTP",
    port            = 25,
    risk_level      = "MEDIUM",
    description     = "Simple Mail Transfer Protocol — email relay service.",
    common_uses     = ["Inbound/outbound email delivery", "Server-to-server mail relay"],
    security_relevance = (
        "Open relays can be abused for spam. VRFY/EXPN commands may "
        "enumerate valid email addresses. Mail header injection is possible "
        "if user input reaches mail headers without sanitisation."
    ),
    typical_risks   = [
        "Open mail relay (can send spam on your behalf)",
        "User enumeration via VRFY/EXPN",
        "Mail header injection",
        "Cleartext credential submission (no STARTTLS)",
    ],
    next_tools      = ["nmap --script smtp*", "smtp-user-enum", "swaks"],
    commands        = [
        "nmap -p25 --script smtp-open-relay,smtp-enum-users TARGET",
        "smtp-user-enum -M VRFY -U users.txt -t TARGET",
        "swaks --to test@example.com --server TARGET",
    ],
    possible_errors = ["550 relay not permitted — relay disabled (good)"],
    fix_steps       = [
        "Disable open relay (require authentication for non-local delivery)",
        "Disable VRFY and EXPN commands",
        "Enforce STARTTLS",
        "Implement SPF, DKIM, and DMARC records",
    ],
))


# ─────────────────────────────────────────────────────────────────────────────
# ServiceLearning
# ─────────────────────────────────────────────────────────────────────────────

class ServiceLearning:
    """
    Provides educational context for discovered services and technologies.

    Integrates with LearningMode for inline display inside the TUI.
    """

    def get_context(
        self,
        port:       Optional[int]  = None,
        service:    str            = "",
        technology: str            = "",
    ) -> Optional[ServiceContext]:
        """
        Look up service context by port, service name, or technology name.

        Returns None when no context is available (caller shows generic message).
        """
        # Port-based lookup
        if port is not None:
            ctx = _SERVICE_DB.get(str(port))
            if ctx:
                return ctx

        # Service name lookup
        for key in [service.lower(), technology.lower()]:
            if key:
                ctx = _SERVICE_DB.get(key)
                if ctx:
                    return ctx
                # Fuzzy prefix match
                for db_key, db_ctx in _SERVICE_DB.items():
                    if key.startswith(db_key) or db_key.startswith(key):
                        return db_ctx

        return None

    def get_all_risky(self, ports: list) -> list[ServiceContext]:
        """
        Return service contexts for all ports whose risk_level is HIGH or CRITICAL.
        Useful for auto-populating the learning section of a report.
        """
        risky: list[ServiceContext] = []
        seen:  set[str]             = set()
        for port in ports:
            ctx = self.get_context(port=port.number)
            if ctx and ctx.risk_level in ("HIGH", "CRITICAL"):
                key = ctx.service_name
                if key not in seen:
                    seen.add(key)
                    risky.append(ctx)
        return sorted(risky, key=lambda c: {"CRITICAL": 0, "HIGH": 1}.get(c.risk_level, 2))

    def list_all(self) -> list[ServiceContext]:
        """Return all registered service contexts (deduplicated)."""
        seen:   set[str]             = set()
        result: list[ServiceContext] = []
        for ctx in _SERVICE_DB.values():
            if ctx.service_name not in seen:
                seen.add(ctx.service_name)
                result.append(ctx)
        return result
