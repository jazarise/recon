"""
ReconX — Deduplication engine.
Merges and deduplicates findings across tool outputs.
"""
from __future__ import annotations
from ..models.findings import ReconResult, Port, DNSRecord, Technology


class Deduplicator:
    """Deduplicates all collections in a ReconResult in-place."""

    def deduplicate(self, result: ReconResult) -> ReconResult:
        result.ip_addresses = self._dedup_list(result.ip_addresses)
        result.domains = self._dedup_list(result.domains)
        result.subdomains = self._dedup_list(result.subdomains)
        result.web_endpoints = self._dedup_list(result.web_endpoints)
        result.emails = self._dedup_list(result.emails)
        result.ports = self._dedup_ports(result.ports)
        result.dns_records = self._dedup_dns(result.dns_records)
        result.technologies = self._dedup_tech(result.technologies)
        return result

    @staticmethod
    def _dedup_list(items: list[str]) -> list[str]:
        seen: set[str] = set()
        out: list[str] = []
        for item in items:
            clean = item.strip().lower()
            if clean and clean not in seen:
                seen.add(clean)
                out.append(item.strip())
        return out

    @staticmethod
    def _dedup_ports(ports: list[Port]) -> list[Port]:
        seen: set[tuple] = set()
        out: list[Port] = []
        for p in ports:
            key = (p.number, p.protocol)
            if key not in seen:
                seen.add(key)
                out.append(p)
        return sorted(out, key=lambda x: x.number)

    @staticmethod
    def _dedup_dns(records: list[DNSRecord]) -> list[DNSRecord]:
        seen: set[tuple] = set()
        out: list[DNSRecord] = []
        for r in records:
            key = (r.record_type, r.value.strip())
            if key not in seen:
                seen.add(key)
                out.append(r)
        return out

    @staticmethod
    def _dedup_tech(techs: list[Technology]) -> list[Technology]:
        seen: set[str] = set()
        out: list[Technology] = []
        for t in techs:
            key = t.name.lower()
            if key not in seen:
                seen.add(key)
                out.append(t)
        return out
