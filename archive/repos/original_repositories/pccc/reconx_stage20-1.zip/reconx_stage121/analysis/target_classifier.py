"""
ReconX — Analysis: Smart Target Classifier (Stage 13).

Auto-detects the type of a reconnaissance target and maps it to the
appropriate workflow chain(s). No configuration required — just pass
the raw user input and get back a typed, normalised target with
workflow recommendations.

Supported types:
  ip, cidr, domain, subdomain, url, asn, email, phone,
  github_repo, github_org, cloud_bucket, git_url, unknown
"""
from __future__ import annotations

import re
import socket
from dataclasses import dataclass, field
from ipaddress import ip_address, ip_network
from typing import Optional
from urllib.parse import urlparse


# ─────────────────────────────────────────────────────────────────────────────
# Target types
# ─────────────────────────────────────────────────────────────────────────────

TARGET_TYPE_LABELS: dict[str, str] = {
    "ip":           "IP Address",
    "cidr":         "IP Range (CIDR)",
    "domain":       "Domain Name",
    "subdomain":    "Subdomain",
    "url":          "URL",
    "asn":          "Autonomous System Number",
    "email":        "Email Address",
    "phone":        "Phone Number",
    "github_repo":  "GitHub Repository",
    "github_org":   "GitHub Organisation",
    "cloud_bucket": "Cloud Storage Bucket",
    "git_url":      "Git Repository URL",
    "unknown":      "Unknown Target",
}

# Workflows recommended per target type (chain names from tool_chains.py)
TARGET_WORKFLOWS: dict[str, list[str]] = {
    "ip":          ["network_discovery", "certificate", "web_recon"],
    "cidr":        ["network_discovery", "certificate"],
    "domain":      ["asset_discovery", "dns_pipeline", "network_discovery",
                    "web_recon", "api_recon", "cloud_recon", "certificate"],
    "subdomain":   ["dns_pipeline", "web_recon", "certificate"],
    "url":         ["web_recon", "api_recon"],
    "asn":         ["network_discovery"],
    "email":       ["identity_recon"],
    "phone":       ["identity_recon"],
    "github_repo": ["secrets"],
    "github_org":  ["secrets", "asset_discovery"],
    "cloud_bucket":["cloud_recon"],
    "git_url":     ["secrets"],
    "unknown":     ["asset_discovery"],
}

# Passive-only workflows per target type
PASSIVE_WORKFLOWS: dict[str, list[str]] = {
    "domain":   ["asset_discovery", "certificate", "identity_recon"],
    "email":    ["identity_recon"],
    "phone":    ["identity_recon"],
    "ip":       ["certificate"],
    "cidr":     [],
    "url":      [],
}


# ─────────────────────────────────────────────────────────────────────────────
# Compiled regexes
# ─────────────────────────────────────────────────────────────────────────────

_RE_ASN       = re.compile(r"^AS\d+$", re.IGNORECASE)
_RE_EMAIL     = re.compile(r"^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$")
_RE_PHONE     = re.compile(r"^\+?[\d\s\-\(\)]{7,20}$")
_RE_GH_REPO   = re.compile(r"^(?:https?://)?github\.com/[^/]+/[^/]+/?$")
_RE_GH_ORG    = re.compile(r"^(?:https?://)?github\.com/[^/]+/?$")
_RE_GIT_URL   = re.compile(r"(git://|\.git$|github\.com|gitlab\.com|bitbucket\.org)")
_RE_BUCKET    = re.compile(r"\.(s3\.amazonaws\.com|storage\.googleapis\.com|blob\.core\.windows\.net)")
_RE_DOMAIN    = re.compile(
    r"^(?:[a-zA-Z0-9](?:[a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?\.)+"
    r"[a-zA-Z]{2,}$"
)


# ─────────────────────────────────────────────────────────────────────────────
# Classified target
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class ClassifiedTarget:
    raw:             str
    target_type:     str
    normalized:      str
    confidence:      float = 1.0
    recommended_workflows: list[str]  = field(default_factory=list)
    passive_workflows:     list[str]  = field(default_factory=list)
    metadata:        dict             = field(default_factory=dict)
    validation_error: Optional[str]  = None

    @property
    def label(self) -> str:
        return TARGET_TYPE_LABELS.get(self.target_type, "Unknown")

    @property
    def is_valid(self) -> bool:
        return self.target_type != "unknown" and not self.validation_error

    @property
    def is_passive_friendly(self) -> bool:
        return self.target_type in ("domain", "email", "phone", "github_repo",
                                    "github_org", "asn")


# ─────────────────────────────────────────────────────────────────────────────
# TargetClassifier
# ─────────────────────────────────────────────────────────────────────────────

class TargetClassifier:
    """
    Classify a raw target string into a structured ClassifiedTarget.

    Usage:
        ct = TargetClassifier.classify("example.com")
        # ct.target_type == "domain"
        # ct.recommended_workflows == ["asset_discovery", "dns_pipeline", ...]

        ct2 = TargetClassifier.classify("192.168.1.0/24")
        # ct2.target_type == "cidr"
    """

    @staticmethod
    def classify(raw: str) -> ClassifiedTarget:
        target = raw.strip()

        # Attempt each detector in priority order
        for detector in _DETECTORS:
            result = detector(target)
            if result:
                return result

        return ClassifiedTarget(
            raw=raw, target_type="unknown", normalized=target,
            confidence=0.1,
            recommended_workflows=TARGET_WORKFLOWS["unknown"],
            passive_workflows=[],
            validation_error="Target type could not be determined.",
        )

    @staticmethod
    def classify_batch(targets: list[str]) -> list[ClassifiedTarget]:
        return [TargetClassifier.classify(t) for t in targets]

    @staticmethod
    def describe(ct: ClassifiedTarget) -> str:
        lines = [
            f"Target : {ct.raw}",
            f"Type   : {ct.label} ({ct.target_type})",
            f"Normal : {ct.normalized}",
            f"Valid  : {'Yes' if ct.is_valid else 'No — ' + (ct.validation_error or '')}",
            f"Passive-friendly: {'Yes' if ct.is_passive_friendly else 'No'}",
            f"Workflows: {', '.join(ct.recommended_workflows) or 'none'}",
        ]
        if ct.metadata:
            lines.append("Meta   : " + ", ".join(f"{k}={v}" for k, v in ct.metadata.items()))
        return "\n".join(lines)


# ─────────────────────────────────────────────────────────────────────────────
# Individual detectors (return ClassifiedTarget or None)
# ─────────────────────────────────────────────────────────────────────────────

def _detect_cidr(raw: str) -> Optional[ClassifiedTarget]:
    if "/" not in raw:
        return None
    try:
        net = ip_network(raw, strict=False)
        return ClassifiedTarget(
            raw=raw, target_type="cidr",
            normalized=str(net), confidence=1.0,
            recommended_workflows=TARGET_WORKFLOWS["cidr"],
            passive_workflows=PASSIVE_WORKFLOWS["cidr"],
            metadata={"prefix_len": net.prefixlen,
                      "num_addresses": net.num_addresses},
        )
    except ValueError:
        return None


def _detect_ip(raw: str) -> Optional[ClassifiedTarget]:
    try:
        addr = ip_address(raw)
        return ClassifiedTarget(
            raw=raw, target_type="ip",
            normalized=str(addr), confidence=1.0,
            recommended_workflows=TARGET_WORKFLOWS["ip"],
            passive_workflows=PASSIVE_WORKFLOWS["ip"],
            metadata={"version": f"IPv{addr.version}",
                      "private": addr.is_private},
        )
    except ValueError:
        return None


def _detect_asn(raw: str) -> Optional[ClassifiedTarget]:
    if _RE_ASN.match(raw):
        return ClassifiedTarget(
            raw=raw, target_type="asn",
            normalized=raw.upper(), confidence=1.0,
            recommended_workflows=TARGET_WORKFLOWS["asn"],
            passive_workflows=PASSIVE_WORKFLOWS.get("asn", []),
            metadata={"asn": raw.upper()},
        )
    return None


def _detect_email(raw: str) -> Optional[ClassifiedTarget]:
    if _RE_EMAIL.match(raw):
        domain = raw.split("@", 1)[1]
        return ClassifiedTarget(
            raw=raw, target_type="email",
            normalized=raw.lower(), confidence=1.0,
            recommended_workflows=TARGET_WORKFLOWS["email"],
            passive_workflows=PASSIVE_WORKFLOWS["email"],
            metadata={"domain": domain},
        )
    return None


def _detect_phone(raw: str) -> Optional[ClassifiedTarget]:
    cleaned = re.sub(r"[\s\-\(\)]", "", raw)
    if _RE_PHONE.match(raw) and len(cleaned) >= 7 and "@" not in raw:
        return ClassifiedTarget(
            raw=raw, target_type="phone",
            normalized=cleaned, confidence=0.85,
            recommended_workflows=TARGET_WORKFLOWS["phone"],
            passive_workflows=PASSIVE_WORKFLOWS["phone"],
        )
    return None


def _detect_github(raw: str) -> Optional[ClassifiedTarget]:
    if _RE_GH_REPO.match(raw):
        parts = raw.rstrip("/").split("/")
        return ClassifiedTarget(
            raw=raw, target_type="github_repo",
            normalized=raw, confidence=1.0,
            recommended_workflows=TARGET_WORKFLOWS["github_repo"],
            passive_workflows=TARGET_WORKFLOWS["github_repo"],
            metadata={"org": parts[-2], "repo": parts[-1]},
        )
    if _RE_GH_ORG.match(raw):
        org = raw.rstrip("/").split("/")[-1]
        return ClassifiedTarget(
            raw=raw, target_type="github_org",
            normalized=raw, confidence=0.9,
            recommended_workflows=TARGET_WORKFLOWS["github_org"],
            passive_workflows=TARGET_WORKFLOWS["github_org"],
            metadata={"org": org},
        )
    return None


def _detect_git_url(raw: str) -> Optional[ClassifiedTarget]:
    if _RE_GIT_URL.search(raw) and raw.startswith(("http", "git@", "git://")):
        return ClassifiedTarget(
            raw=raw, target_type="git_url",
            normalized=raw, confidence=0.9,
            recommended_workflows=TARGET_WORKFLOWS["git_url"],
            passive_workflows=TARGET_WORKFLOWS["git_url"],
        )
    return None


def _detect_cloud_bucket(raw: str) -> Optional[ClassifiedTarget]:
    if _RE_BUCKET.search(raw):
        provider = ("AWS S3" if "amazonaws" in raw else
                    "GCP GCS" if "googleapis" in raw else "Azure")
        return ClassifiedTarget(
            raw=raw, target_type="cloud_bucket",
            normalized=raw, confidence=0.95,
            recommended_workflows=TARGET_WORKFLOWS["cloud_bucket"],
            passive_workflows=[],
            metadata={"provider": provider},
        )
    return None


def _detect_url(raw: str) -> Optional[ClassifiedTarget]:
    if raw.startswith(("http://", "https://", "ftp://")):
        parsed = urlparse(raw)
        return ClassifiedTarget(
            raw=raw, target_type="url",
            normalized=raw, confidence=1.0,
            recommended_workflows=TARGET_WORKFLOWS["url"],
            passive_workflows=PASSIVE_WORKFLOWS["url"],
            metadata={"scheme": parsed.scheme, "host": parsed.netloc,
                      "path": parsed.path},
        )
    return None


def _detect_subdomain(raw: str) -> Optional[ClassifiedTarget]:
    """Subdomain: valid domain with 3+ labels (www.example.com)."""
    if not _RE_DOMAIN.match(raw):
        return None
    parts = raw.rstrip(".").split(".")
    if len(parts) <= 2:
        return None
    # Heuristic: if the first label is a common subdomain prefix → subdomain
    first = parts[0].lower()
    if first in ("www", "api", "dev", "staging", "mail", "ftp", "admin",
                 "portal", "app", "cdn", "static", "vpn", "remote", "auth"):
        return ClassifiedTarget(
            raw=raw, target_type="subdomain",
            normalized=raw.lower(), confidence=0.9,
            recommended_workflows=TARGET_WORKFLOWS["subdomain"],
            passive_workflows=[],
            metadata={"root_domain": ".".join(parts[-2:])},
        )
    return None


def _detect_domain(raw: str) -> Optional[ClassifiedTarget]:
    if _RE_DOMAIN.match(raw):
        return ClassifiedTarget(
            raw=raw, target_type="domain",
            normalized=raw.lower(), confidence=0.95,
            recommended_workflows=TARGET_WORKFLOWS["domain"],
            passive_workflows=PASSIVE_WORKFLOWS["domain"],
            metadata={"tld": raw.rsplit(".", 1)[-1]},
        )
    return None


def _detect_resolvable(raw: str) -> Optional[ClassifiedTarget]:
    """Last resort: try DNS resolution; if it works, treat as domain."""
    try:
        ip = socket.gethostbyname(raw)
        return ClassifiedTarget(
            raw=raw, target_type="domain",
            normalized=raw.lower(), confidence=0.7,
            recommended_workflows=TARGET_WORKFLOWS["domain"],
            passive_workflows=PASSIVE_WORKFLOWS["domain"],
            metadata={"resolved_ip": ip},
        )
    except Exception:
        return None


# Ordered detector pipeline
_DETECTORS = [
    _detect_cidr,
    _detect_ip,
    _detect_asn,
    _detect_email,
    _detect_github,
    _detect_git_url,
    _detect_cloud_bucket,
    _detect_url,
    _detect_phone,
    _detect_subdomain,
    _detect_domain,
    _detect_resolvable,
]
