"""
ReconX — Suggestion engine.
Maps findings to educational, high-level security insights.
No exploit automation — guidance only.
"""
from __future__ import annotations
import logging

from ..models.findings import ReconResult, Suggestion, SensitiveFinding
from ..config.settings import SUGGESTION_RULES

logger = logging.getLogger("reconx.analysis.suggestions")


class SuggestionEngine:

    def generate(self, result: ReconResult) -> list[Suggestion]:
        suggestions: list[Suggestion] = []
        seen: set[str] = set()

        def _add(trigger: str, risk: str, rec: str, sev: str) -> None:
            key = f"{trigger}:{risk}"
            if key not in seen:
                seen.add(key)
                suggestions.append(Suggestion(finding=trigger, risk=risk,
                                              recommendation=rec, severity=sev))

        # ── Port-based rules ─────────────────────────────────────────────────
        open_port_numbers = {p.number for p in result.ports}

        for rule in SUGGESTION_RULES:
            trigger = rule["trigger"]

            if trigger.startswith("port:"):
                port_num = int(trigger.split(":")[1])
                if port_num in open_port_numbers:
                    _add(trigger, rule["risk"], rule["recommendation"], rule["severity"])

            elif trigger == "dns:MX" and any(
                r.record_type == "MX" for r in result.dns_records
            ):
                _add(trigger, rule["risk"], rule["recommendation"], rule["severity"])

            elif trigger == "subdomain_count_high" and len(result.subdomains) > 20:
                _add(trigger, rule["risk"], rule["recommendation"], rule["severity"])

            elif trigger == "exposed_config" and any(
                f.category == "exposed_config" for f in result.sensitive_findings
            ):
                _add(trigger, rule["risk"], rule["recommendation"], rule["severity"])

        # ── HTTP on 80 without HTTPS on 443 ──────────────────────────────────
        if 80 in open_port_numbers and 443 not in open_port_numbers:
            _add("port:80_no_tls",
                 "No TLS/HTTPS detected",
                 "Deploy TLS certificate; redirect all HTTP traffic to HTTPS.",
                 "HIGH")

        # ── Large subdomain surface ──────────────────────────────────────────
        if len(result.subdomains) > 50:
            _add("large_attack_surface",
                 "Extensive subdomain footprint detected",
                 "Regularly audit and retire unused subdomains; monitor for subdomain takeover.",
                 "MEDIUM")

        # ── Many open ports ──────────────────────────────────────────────────
        if len(result.ports) > 15:
            _add("many_open_ports",
                 "High number of open ports increases attack surface",
                 "Apply principle of least exposure; close unused ports via firewall.",
                 "MEDIUM")

        return suggestions
