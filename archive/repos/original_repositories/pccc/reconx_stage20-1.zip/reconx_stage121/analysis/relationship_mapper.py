"""
ReconX — Stage 17: Asset Relationship Mapper.

Identifies relationships between discovered assets:
  • Shared IP ownership   — multiple hostnames on same IP
  • TLS fingerprint match — subdomains sharing same certificate
  • Banner inheritance    — identical server banners across hosts
  • Technology overlap    — same tech stack across multiple assets
  • Subdomain clustering  — related subdomains by prefix/suffix patterns

Output feeds:
  - Infrastructure view TUI
  - HTML report relationship section
  - Tag engine (shared infra tag)

Usage:
    from reconx.analysis.relationship_mapper import RelationshipMapper
    from reconx.models.findings import ReconResult

    mapper = RelationshipMapper()
    groups = mapper.map(result)

    for group in groups.shared_ip_groups:
        print(group.confidence, group.members)
"""
from __future__ import annotations

import logging
import re
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Optional

from ..models.findings import ReconResult

log = logging.getLogger("reconx.analysis.relationship_mapper")


# ─────────────────────────────────────────────────────────────────────────────
# Data models
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class AssetGroup:
    """
    A set of related assets grouped by a shared attribute.

    confidence:  0.0–1.0  (how certain the relationship is)
    relationship: human-readable description of what ties them
    evidence:    list of supporting facts
    """
    members:      list[str]
    relationship: str
    confidence:   float
    evidence:     list[str]   = field(default_factory=list)
    tags:         list[str]   = field(default_factory=list)
    metadata:     dict        = field(default_factory=dict)

    @property
    def size(self) -> int:
        return len(self.members)

    def render(self) -> str:
        lines = [
            f"[{self.relationship}]  confidence={self.confidence:.0%}",
            "  Members:",
        ]
        for m in self.members:
            lines.append(f"    • {m}")
        if self.evidence:
            lines.append("  Evidence:")
            for e in self.evidence:
                lines.append(f"    – {e}")
        return "\n".join(lines)


@dataclass
class RelationshipMap:
    """Complete output of RelationshipMapper.map()."""
    target:              str
    shared_ip_groups:    list[AssetGroup]  = field(default_factory=list)
    tls_match_groups:    list[AssetGroup]  = field(default_factory=list)
    banner_match_groups: list[AssetGroup]  = field(default_factory=list)
    tech_overlap_groups: list[AssetGroup]  = field(default_factory=list)
    subdomain_clusters:  list[AssetGroup]  = field(default_factory=list)
    warnings:            list[str]         = field(default_factory=list)

    @property
    def total_groups(self) -> int:
        return sum([
            len(self.shared_ip_groups),
            len(self.tls_match_groups),
            len(self.banner_match_groups),
            len(self.tech_overlap_groups),
            len(self.subdomain_clusters),
        ])

    @property
    def all_groups(self) -> list[AssetGroup]:
        return (
            self.shared_ip_groups +
            self.tls_match_groups +
            self.banner_match_groups +
            self.tech_overlap_groups +
            self.subdomain_clusters
        )

    def high_confidence_groups(self, min_confidence: float = 0.8) -> list[AssetGroup]:
        return [g for g in self.all_groups if g.confidence >= min_confidence]

    def to_dict(self) -> dict:
        def _serialise(groups: list[AssetGroup]) -> list[dict]:
            return [
                {
                    "members":      g.members,
                    "relationship": g.relationship,
                    "confidence":   g.confidence,
                    "evidence":     g.evidence,
                    "tags":         g.tags,
                    "size":         g.size,
                }
                for g in groups
            ]

        return {
            "target":              self.target,
            "total_groups":        self.total_groups,
            "shared_ip_groups":    _serialise(self.shared_ip_groups),
            "tls_match_groups":    _serialise(self.tls_match_groups),
            "banner_match_groups": _serialise(self.banner_match_groups),
            "tech_overlap_groups": _serialise(self.tech_overlap_groups),
            "subdomain_clusters":  _serialise(self.subdomain_clusters),
            "warnings":            self.warnings,
        }


# ─────────────────────────────────────────────────────────────────────────────
# RelationshipMapper
# ─────────────────────────────────────────────────────────────────────────────

class RelationshipMapper:
    """
    Identifies shared infrastructure and relationships across all discovered assets.

    Each analysis pass is isolated — failures add warnings and continue.
    """

    # Minimum group size to report (singletons aren't relationships)
    MIN_GROUP_SIZE = 2

    def map(self, result: ReconResult) -> RelationshipMap:
        """
        Full relationship analysis pass.  Returns RelationshipMap.  Never raises.
        """
        rm = RelationshipMap(target=result.target)

        passes = [
            ("shared_ip",      self._shared_ip_analysis),
            ("tls_match",      self._tls_match_analysis),
            ("banner_match",   self._banner_match_analysis),
            ("tech_overlap",   self._tech_overlap_analysis),
            ("sub_cluster",    self._subdomain_cluster_analysis),
        ]

        for name, fn in passes:
            try:
                fn(result, rm)
            except Exception as exc:
                msg = f"Relationship pass '{name}' failed: {exc}"
                rm.warnings.append(msg)
                log.warning(msg)

        log.info(
            f"RelationshipMapper complete for {result.target}: "
            f"{rm.total_groups} groups found"
        )
        return rm

    # ── Pass 1: Shared IP Ownership ───────────────────────────────────────────

    def _shared_ip_analysis(
        self, result: ReconResult, rm: RelationshipMap
    ) -> None:
        """
        Find multiple subdomains/hostnames resolving to the same IP.
        Strong indicator of shared hosting, CDN edge, or WAF cluster.
        """
        # Build ip → hostnames from DNS A records
        ip_to_names: dict[str, list[str]] = defaultdict(list)

        for rec in result.dns_records:
            if rec.record_type in ("A", "AAAA") and _is_ip(rec.value):
                host = result.target
                if host not in ip_to_names[rec.value]:
                    ip_to_names[rec.value].append(host)

        # Include subdomains — we don't have their IPs directly, but
        # if multiple subdomains share a CNAME pointing to the same apex,
        # they likely share infra
        cname_targets: dict[str, list[str]] = defaultdict(list)
        for rec in result.dns_records:
            if rec.record_type == "CNAME":
                cname_targets[rec.value].append(result.target)

        for ip, names in ip_to_names.items():
            if len(names) >= self.MIN_GROUP_SIZE:
                rm.shared_ip_groups.append(AssetGroup(
                    members      = names,
                    relationship = f"Shared IP: {ip}",
                    confidence   = 0.95,
                    evidence     = [f"All resolve to {ip}"],
                    tags         = ["shared_infra", "shared_ip"],
                    metadata     = {"shared_ip": ip},
                ))

        # Subdomain clustering by CNAME target
        for cname, subs in cname_targets.items():
            if len(subs) >= self.MIN_GROUP_SIZE:
                rm.shared_ip_groups.append(AssetGroup(
                    members      = subs,
                    relationship = f"Shared CNAME: {cname}",
                    confidence   = 0.90,
                    evidence     = [f"All CNAME → {cname}"],
                    tags         = ["shared_infra", "shared_cname"],
                    metadata     = {"cname": cname},
                ))

    # ── Pass 2: TLS Certificate Match ─────────────────────────────────────────

    def _tls_match_analysis(
        self, result: ReconResult, rm: RelationshipMap
    ) -> None:
        """
        Find subdomains sharing a TLS certificate (via SAN list).
        Strong indicator of same hosting cluster or wildcard cert coverage.
        """
        if not result.tls_info or not result.tls_info.san_domains:
            return

        san_subs = [
            s.lstrip("*.").lower()
            for s in result.tls_info.san_domains
            if s and s != result.target
        ]

        # Find SANs that also appear as discovered subdomains
        known_subs = {s.lower() for s in result.subdomains}
        matched = [s for s in san_subs if s in known_subs]

        if len(matched) >= self.MIN_GROUP_SIZE:
            rm.tls_match_groups.append(AssetGroup(
                members      = matched,
                relationship = "Shared TLS Certificate (SAN match)",
                confidence   = 0.90,
                evidence     = [
                    f"Certificate issuer: {result.tls_info.issuer}",
                    f"Subject: {result.tls_info.subject}",
                    f"Valid until: {result.tls_info.valid_until}",
                ],
                tags         = ["shared_infra", "tls_match"],
                metadata     = {
                    "issuer":      result.tls_info.issuer,
                    "subject":     result.tls_info.subject,
                    "san_count":   len(san_subs),
                    "matched":     len(matched),
                },
            ))

    # ── Pass 3: Banner Inheritance ────────────────────────────────────────────

    def _banner_match_analysis(
        self, result: ReconResult, rm: RelationshipMap
    ) -> None:
        """
        Identify ports with identical or very similar server banners.
        Same exact banner across multiple ports = same software, possibly
        same server instance or cloned config.
        """
        banner_to_ports: dict[str, list[int]] = defaultdict(list)
        for port in result.ports:
            b = _normalise_banner(port.banner)
            if b and len(b) > 8:
                banner_to_ports[b].append(port.number)

        for banner, ports in banner_to_ports.items():
            if len(ports) >= self.MIN_GROUP_SIZE:
                rm.banner_match_groups.append(AssetGroup(
                    members      = [f"port {p}" for p in ports],
                    relationship = "Identical server banner",
                    confidence   = 0.85,
                    evidence     = [f"Banner: {banner[:80]}"],
                    tags         = ["shared_infra", "banner_match"],
                    metadata     = {"banner": banner[:120]},
                ))

    # ── Pass 4: Technology Overlap ────────────────────────────────────────────

    def _tech_overlap_analysis(
        self, result: ReconResult, rm: RelationshipMap
    ) -> None:
        """
        Group subdomains/hosts that expose the same technology stack.
        Useful for finding all WordPress sites, all Nginx-backed services, etc.
        """
        tech_to_ports: dict[str, list[str]] = defaultdict(list)

        for port in result.ports:
            if port.state == "open":
                techs = _extract_techs(port)
                for tech in techs:
                    label = f":{port.number}"
                    if label not in tech_to_ports[tech]:
                        tech_to_ports[tech].append(label)

        # Also declared technologies
        for tech in result.technologies:
            name = tech.name
            if name and name not in tech_to_ports:
                tech_to_ports[name].append(result.target)

        for tech, assets in tech_to_ports.items():
            if len(assets) >= self.MIN_GROUP_SIZE:
                rm.tech_overlap_groups.append(AssetGroup(
                    members      = assets,
                    relationship = f"Shared technology: {tech}",
                    confidence   = 0.75,
                    evidence     = [f"Technology detected: {tech}"],
                    tags         = ["tech_overlap", tech.lower().replace(" ", "_")],
                    metadata     = {"technology": tech},
                ))

    # ── Pass 5: Subdomain Clustering ──────────────────────────────────────────

    def _subdomain_cluster_analysis(
        self, result: ReconResult, rm: RelationshipMap
    ) -> None:
        """
        Cluster subdomains by shared prefix patterns.

        Examples of clusters:
          admin.example.com + admin2.example.com + admin-test.example.com
          → "admin" cluster → likely same team / admin panel

          api.example.com + api-v2.example.com + api-staging.example.com
          → "api" cluster → API surface mapping target
        """
        prefix_to_subs: dict[str, list[str]] = defaultdict(list)

        for sub in result.subdomains:
            prefix = _extract_subdomain_prefix(sub)
            if prefix:
                prefix_to_subs[prefix].append(sub)

        # Interesting prefixes that signal attack surface
        HIGH_VALUE_PREFIXES = {
            "admin", "portal", "vpn", "remote", "login", "auth",
            "api", "dev", "staging", "stage", "test", "uat",
            "mail", "smtp", "mx", "webmail", "outlook",
            "ftp", "sftp", "cdn", "media", "static", "assets",
            "monitor", "status", "metrics", "grafana", "kibana",
            "jenkins", "gitlab", "git", "jira", "confluence",
            "backup", "db", "database", "sql", "mysql",
            "cloud", "aws", "azure", "gcp",
        }

        for prefix, subs in prefix_to_subs.items():
            if len(subs) < self.MIN_GROUP_SIZE:
                continue
            is_high_value = prefix in HIGH_VALUE_PREFIXES
            confidence    = 0.85 if is_high_value else 0.65
            rm.subdomain_clusters.append(AssetGroup(
                members      = subs,
                relationship = f"Subdomain cluster: '{prefix}.*'",
                confidence   = confidence,
                evidence     = [f"Prefix pattern: {prefix}"],
                tags         = (["high_value_cluster"] if is_high_value else [])
                               + ["subdomain_cluster"],
                metadata     = {"prefix": prefix, "high_value": is_high_value},
            ))

        # Sort: high-value clusters first
        rm.subdomain_clusters.sort(
            key=lambda g: (
                -g.metadata.get("high_value", False),
                -g.confidence,
                -g.size,
            )
        )


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _is_ip(value: str) -> bool:
    return bool(re.match(r"^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$", value.strip()))


def _normalise_banner(banner: str) -> str:
    """Strip version numbers so banners can be compared structurally."""
    if not banner:
        return ""
    # Remove version-like numbers
    cleaned = re.sub(r"\d+[\.\d]*", "", banner).strip()
    return cleaned.lower()[:120]


def _extract_techs(port) -> list[str]:
    """Extract technology names from a Port object's fields."""
    raw = " ".join([
        port.banner or "",
        port.service or "",
        port.version or "",
    ]).lower()

    from .service_correlator import _BANNER_TECH
    return [tech for sig, tech in _BANNER_TECH if sig in raw]


def _extract_subdomain_prefix(subdomain: str) -> str:
    """Extract the meaningful leftmost label from a subdomain."""
    parts = subdomain.split(".")
    if len(parts) < 2:
        return ""
    prefix = parts[0].lower()
    # Strip numeric suffixes: api2 → api
    prefix = re.sub(r"\d+$", "", prefix)
    # Skip generic single-char or too-short prefixes
    return prefix if len(prefix) >= 2 else ""
