"""
ReconX — Stage 12: Cloud Analysis Layer.

Modules:
  CloudSurfaceMapper:         Builds cloud attack surface graph
  CloudRiskEngine:            Computes overall cloud risk score
  BucketExposureEngine:       Analyses bucket exposure risks
  KubernetesRiskEngine:       K8s-specific risk analysis
  CloudMisconfigEngine:       Detects cloud misconfigurations
  CloudAssetCorrelator:       Correlates assets across providers
  CloudRelationshipGraph:     Graph of cloud asset relationships
  CloudPipeline:              Full Stage 12 orchestration pipeline
"""
from __future__ import annotations

import hashlib
import json
import logging
import os
import time
from collections import defaultdict
from datetime import datetime
from typing import Optional

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich import box

from ...models.cloud_models import (
    CloudAsset, StorageBucket, K8sAsset, CICDAsset, CloudMisconfig,
    CloudProvider, CloudRisk, StorageType, K8sComponent, CloudIntelligenceReport,
)
from ...tools.cloud import (
    CloudFingerprint, S3Scanner, BucketCorrelator, KubernetesAnalyzer,
    AWSRecon, AzureRecon, GCPRecon, CloudFrontMapper,
    DockerRegistryAnalyzer, CICDCloudMapper,
)

logger = logging.getLogger("reconx.analysis.cloud")


# ══════════════════════════════════════════════════════════════════════════════
#  Cloud Surface Mapper
# ══════════════════════════════════════════════════════════════════════════════

class CloudSurfaceMapper:
    """Organises cloud assets into a structured attack surface map."""

    def map(
        self,
        providers:   list[str],
        cloud_assets: list[dict],
        buckets:     list[dict],
        k8s_assets:  list[dict],
        cicd_assets: list[dict],
        misconfigs:  list[dict],
    ) -> dict:
        nodes: list[dict] = []
        edges: list[dict] = []

        # Provider nodes
        for prov in set(providers):
            nid = self._nid("provider", prov)
            nodes.append({"id": nid, "type": "cloud_provider", "label": prov.upper(),
                          "risk": CloudRisk.INFO.value})

        # Asset nodes
        for asset in cloud_assets:
            nid  = self._nid("asset", asset.get("url", asset.get("service","")))
            prov = asset.get("provider", "unknown")
            nodes.append({"id": nid, "type": "cloud_asset", "label": asset.get("service",""),
                          "risk": asset.get("risk", CloudRisk.INFO.value), "provider": prov})
            prov_nid = self._nid("provider", prov)
            edges.append({"from": prov_nid, "to": nid, "rel": "hosts"})

        # Bucket nodes
        for b in buckets:
            nid  = self._nid("bucket", b.get("name",""))
            risk = CloudRisk.CRITICAL.value if b.get("listing") else \
                   (CloudRisk.HIGH.value if b.get("is_public") else CloudRisk.LOW.value)
            nodes.append({"id": nid, "type": "storage_bucket",
                          "label": f"Bucket: {b.get('name','')}", "risk": risk,
                          "public": b.get("is_public", False), "listing": b.get("listing", False)})
            prov_nid = self._nid("provider", b.get("provider", "s3"))
            edges.append({"from": prov_nid, "to": nid, "rel": "stores"})

        # K8s nodes
        for k in k8s_assets:
            nid = self._nid("k8s", k.get("url",""))
            nodes.append({"id": nid, "type": "k8s_component",
                          "label": k.get("component",""), "risk": k.get("risk","HIGH")})
            prov_nid = self._nid("provider", k.get("provider","unknown"))
            edges.append({"from": prov_nid, "to": nid, "rel": "runs"})

        # CI/CD nodes
        for c in cicd_assets:
            nid = self._nid("cicd", c.get("url",""))
            nodes.append({"id": nid, "type": "cicd_system",
                          "label": c.get("system",""), "risk": c.get("risk","HIGH")})

        # Misconfiguration nodes
        for m in misconfigs:
            nid = self._nid("misconfig", m.get("title",""))
            nodes.append({"id": nid, "type": "misconfiguration",
                          "label": m.get("title","")[:50], "risk": m.get("risk","")})

        by_risk: dict[str, int] = {}
        for n in nodes:
            r = n.get("risk", "INFO")
            by_risk[r] = by_risk.get(r, 0) + 1

        return {
            "nodes":      nodes,
            "edges":      edges,
            "node_count": len(nodes),
            "edge_count": len(edges),
            "by_risk":    by_risk,
        }

    def _nid(self, prefix: str, value: str) -> str:
        return hashlib.md5(f"{prefix}::{value}".encode(), usedforsecurity=False).hexdigest()[:12]


# ══════════════════════════════════════════════════════════════════════════════
#  Cloud Risk Engine
# ══════════════════════════════════════════════════════════════════════════════

class CloudRiskEngine:
    """Computes an overall cloud infrastructure risk score (0–100)."""

    def score(
        self,
        buckets:    list[dict],
        k8s_assets: list[dict],
        cicd_assets: list[dict],
        misconfigs: list[dict],
        providers:  list[str],
    ) -> tuple[float, CloudRisk, str]:
        pts = 0.0

        # Bucket exposure
        public_buckets  = [b for b in buckets if b.get("is_public")]
        listing_buckets = [b for b in buckets if b.get("listing")]
        sensitive_files = sum(len(b.get("sensitive_files",[])) for b in buckets)
        pts += min(len(public_buckets) * 10, 25)
        pts += min(len(listing_buckets) * 15, 20)
        pts += min(sensitive_files * 5, 20)

        # K8s exposure
        unauth_k8s = [k for k in k8s_assets if not k.get("auth_required", True)]
        pts += min(len(unauth_k8s) * 15, 20)

        # CI/CD exposure
        unauth_cicd = [c for c in cicd_assets if not c.get("auth_required", True)]
        pts += min(len(unauth_cicd) * 12, 15)

        # Misconfigs
        crit_misconfigs = [m for m in misconfigs if m.get("risk") in ("CRITICAL","HIGH")]
        pts += min(len(crit_misconfigs) * 8, 20)

        score = min(pts, 100.0)
        risk  = CloudRisk.from_score(score / 10.0)

        parts = []
        if listing_buckets:
            parts.append(f"{len(listing_buckets)} public bucket(s) with listing")
        if unauth_k8s:
            parts.append(f"{len(unauth_k8s)} unauthenticated K8s component(s)")
        if sensitive_files:
            parts.append(f"{sensitive_files} sensitive file(s) in storage")
        if unauth_cicd:
            parts.append(f"{len(unauth_cicd)} exposed CI/CD system(s)")

        summary = f"Cloud Risk: {score:.0f}/100 ({risk.value}). " + \
                  (". ".join(parts[:3]) + "." if parts else "No critical exposures detected.")

        return round(score, 1), risk, summary


# ══════════════════════════════════════════════════════════════════════════════
#  Misconfiguration Engine
# ══════════════════════════════════════════════════════════════════════════════

class CloudMisconfigEngine:
    """Generates CloudMisconfig findings from raw tool output."""

    def analyse(
        self,
        buckets:    list[dict],
        k8s_assets: list[dict],
        cicd_assets: list[dict],
        registries: list[dict],
    ) -> list[CloudMisconfig]:
        misconfigs: list[CloudMisconfig] = []

        # Public bucket listing
        for b in buckets:
            if b.get("listing"):
                misconfigs.append(CloudMisconfig(
                    category    = "public_bucket_listing",
                    title       = f"Public Bucket Listing: {b.get('name','')}",
                    description = f"{b.get('provider','Cloud')} storage bucket {b.get('name','')} has directory listing enabled — all objects enumerable.",
                    risk        = CloudRisk.CRITICAL,
                    evidence    = f"Bucket listing returned {b.get('sample_objects',[][:3])} objects",
                    remediation = "Disable public access. Set bucket to private. Use pre-signed URLs for sharing.",
                    url         = b.get("url",""),
                ))
            elif b.get("is_public"):
                misconfigs.append(CloudMisconfig(
                    category    = "public_bucket_access",
                    title       = f"Public Bucket: {b.get('name','')}",
                    description = f"Storage bucket {b.get('name','')} is publicly accessible.",
                    risk        = CloudRisk.HIGH,
                    evidence    = "HTTP 200 returned without authentication",
                    remediation = "Apply Block Public Access settings. Review bucket policy.",
                    url         = b.get("url",""),
                ))
            if b.get("sensitive_files"):
                misconfigs.append(CloudMisconfig(
                    category    = "sensitive_files_in_bucket",
                    title       = f"Sensitive Files in {b.get('name','')}",
                    description = f"Sensitive file(s) found in public bucket: {', '.join(b['sensitive_files'][:3])}",
                    risk        = CloudRisk.CRITICAL,
                    evidence    = str(b["sensitive_files"][:5]),
                    remediation = "Remove sensitive files immediately. Rotate any exposed credentials.",
                    url         = b.get("url",""),
                ))

        # Unauthenticated K8s
        for k in k8s_assets:
            if not k.get("auth_required", True):
                comp = k.get("component", "component")
                misconfigs.append(CloudMisconfig(
                    category    = f"exposed_k8s_{comp}",
                    title       = f"Unauthenticated Kubernetes {comp.replace('_',' ').title()}",
                    description = f"Kubernetes {comp} at {k.get('url','')} accessible without authentication.",
                    risk        = CloudRisk.CRITICAL,
                    evidence    = f"HTTP 200 on {k.get('url','')}",
                    remediation = "Enable RBAC. Restrict component access to cluster-internal network.",
                    url         = k.get("url",""),
                ))

        # Exposed CI/CD
        for c in cicd_assets:
            if not c.get("auth_required", True):
                misconfigs.append(CloudMisconfig(
                    category    = "exposed_cicd_system",
                    title       = f"Unauthenticated CI/CD: {c.get('system','')}",
                    description = f"{c.get('system','CI/CD')} at {c.get('url','')} accessible without auth — pipeline secrets exposed.",
                    risk        = CloudRisk.CRITICAL,
                    evidence    = f"HTTP 200 on {c.get('url','')}",
                    remediation = "Restrict CI/CD access to VPN/internal network. Enable authentication.",
                    url         = c.get("url",""),
                ))

        # Public container registries
        for r in registries:
            if r.get("is_public") and not r.get("auth_required", True):
                misconfigs.append(CloudMisconfig(
                    category    = "public_container_registry",
                    title       = f"Public Container Registry: {r.get('registry_type','')}",
                    description = f"Container registry at {r.get('url','')} is publicly accessible — image enumeration possible.",
                    risk        = CloudRisk.HIGH,
                    evidence    = f"Catalog listing returned {len(r.get('repos',[]))} repositories",
                    remediation = "Restrict registry access. Enable authentication. Audit public images.",
                    url         = r.get("url",""),
                ))

        return misconfigs


# ══════════════════════════════════════════════════════════════════════════════
#  Cloud Intelligence Pipeline
# ══════════════════════════════════════════════════════════════════════════════

SEV_STYLE = {
    "CRITICAL": "bold red", "HIGH": "red",
    "MEDIUM": "yellow", "LOW": "cyan", "INFO": "dim",
}


class CloudPipelineConfig:
    def __init__(
        self,
        run_fingerprint: bool = True,
        run_aws:         bool = True,
        run_azure:       bool = True,
        run_gcp:         bool = True,
        run_s3:          bool = True,
        run_k8s:         bool = True,
        run_cicd:        bool = True,
        run_registry:    bool = True,
        bucket_names:    Optional[list[str]] = None,
        custom_headers:  Optional[dict] = None,
        timeout_per:     float = 5.0,
    ):
        self.run_fingerprint = run_fingerprint
        self.run_aws         = run_aws
        self.run_azure       = run_azure
        self.run_gcp         = run_gcp
        self.run_s3          = run_s3
        self.run_k8s         = run_k8s
        self.run_cicd        = run_cicd
        self.run_registry    = run_registry
        self.bucket_names    = bucket_names
        self.custom_headers  = custom_headers or {}
        self.timeout_per     = timeout_per


class CloudPipeline:
    """Orchestrates all Stage 12 cloud reconnaissance modules."""

    def __init__(self, console: Optional[Console] = None) -> None:
        self._console   = console or Console()
        self._fp        = CloudFingerprint()
        self._s3        = S3Scanner()
        self._k8s       = KubernetesAnalyzer()
        self._aws       = AWSRecon()
        self._azure     = AzureRecon()
        self._gcp       = GCPRecon()
        self._cf        = CloudFrontMapper()
        self._registry  = DockerRegistryAnalyzer()
        self._cicd      = CICDCloudMapper()
        self._surface   = CloudSurfaceMapper()
        self._risk      = CloudRiskEngine()
        self._misconfig = CloudMisconfigEngine()
        self._bucket_corr = BucketCorrelator()

    def run(self, target: str, config: Optional[CloudPipelineConfig] = None) -> CloudIntelligenceReport:
        cfg = config or CloudPipelineConfig()
        t0  = time.perf_counter()
        ts  = datetime.now().strftime("%Y%m%d_%H%M%S")

        self._print_header(target)

        providers:    list[str]  = []
        cloud_assets: list[dict] = []
        buckets_raw:  list[dict] = []
        k8s_raw:      list[dict] = []
        cicd_raw:     list[dict] = []
        registries:   list[dict] = []

        # ── Step 1: Cloud Fingerprint ─────────────────────────────────────────
        if cfg.run_fingerprint:
            fp_res = self._fp.run(target, headers=cfg.custom_headers, timeout_per=cfg.timeout_per)
            if fp_res.ok:
                d = fp_res.data
                providers.extend(d.get("detected", []))
                cloud_assets.extend(d.get("assets", []))
                self._status("Cloud Fingerprint",
                             f"providers={d.get('detected','?')}, k8s={d.get('is_kubernetes',False)}")

        # ── Step 2: AWS ───────────────────────────────────────────────────────
        if cfg.run_aws:
            aws_res = self._aws.run(target, timeout_per=cfg.timeout_per)
            if aws_res.ok and aws_res.data.get("is_aws"):
                cloud_assets.extend(aws_res.data.get("assets", []))
                if "aws" not in providers: providers.append("aws")
                self._status("AWS Recon", f"{len(aws_res.data.get('assets',[]))} service(s) detected")

        # ── Step 3: Azure ─────────────────────────────────────────────────────
        if cfg.run_azure:
            az_res = self._azure.run(target, timeout_per=cfg.timeout_per)
            if az_res.ok and az_res.data.get("is_azure"):
                cloud_assets.extend(az_res.data.get("assets", []))
                if "azure" not in providers: providers.append("azure")
                self._status("Azure Recon", f"{len(az_res.data.get('assets',[]))} service(s) detected")

        # ── Step 4: GCP ───────────────────────────────────────────────────────
        if cfg.run_gcp:
            gcp_res = self._gcp.run(target, timeout_per=cfg.timeout_per)
            if gcp_res.ok and gcp_res.data.get("is_gcp"):
                cloud_assets.extend(gcp_res.data.get("assets", []))
                if "gcp" not in providers: providers.append("gcp")
                self._status("GCP Recon", f"{len(gcp_res.data.get('assets',[]))} service(s) detected")

        # ── Step 5: Storage / Buckets ─────────────────────────────────────────
        if cfg.run_s3:
            s3_res = self._s3.run(target, bucket_names=cfg.bucket_names,
                                   timeout_per=cfg.timeout_per)
            if s3_res.ok:
                d = s3_res.data
                buckets_raw = d.get("buckets", [])
                self._status("Storage Scanner",
                             f"{d.get('buckets_found',0)} buckets, "
                             f"{d.get('public_buckets',0)} public, "
                             f"{d.get('listing_enabled',0)} listing, "
                             f"{d.get('sensitive_files',0)} sensitive files")
                if d.get("public_buckets", 0):
                    self._warn(f"⚠ {d['public_buckets']} public bucket(s) found!")

        # ── Step 6: Kubernetes ────────────────────────────────────────────────
        if cfg.run_k8s:
            k8s_res = self._k8s.run(target, timeout_per=cfg.timeout_per)
            if k8s_res.ok and k8s_res.data.get("is_kubernetes"):
                k8s_raw = k8s_res.data.get("k8s_assets", [])
                self._status("Kubernetes Analyzer",
                             f"{len(k8s_raw)} component(s), "
                             f"providers={k8s_res.data.get('providers',[])}",)
                exposed = k8s_res.data.get("exposed_count", 0)
                if exposed:
                    self._warn(f"⚠ {exposed} unauthenticated K8s component(s) exposed!")

        # ── Step 7: Container Registry ────────────────────────────────────────
        if cfg.run_registry:
            reg_res = self._registry.run(target, timeout_per=cfg.timeout_per)
            if reg_res.ok:
                registries = reg_res.data.get("registries", [])
                if registries:
                    self._status("Registry Analyzer",
                                 f"{len(registries)} registry(s), "
                                 f"{reg_res.data.get('public_count',0)} public")

        # ── Step 8: CI/CD ─────────────────────────────────────────────────────
        if cfg.run_cicd:
            cicd_res = self._cicd.run(target, timeout_per=cfg.timeout_per)
            if cicd_res.ok:
                cicd_raw = cicd_res.data.get("cicd_assets", [])
                if cicd_raw:
                    unauth = cicd_res.data.get("unauthenticated", 0)
                    self._status("CI/CD Mapper", f"{len(cicd_raw)} system(s), {unauth} unauthenticated")
                    if unauth:
                        self._warn(f"⚠ {unauth} unauthenticated CI/CD system(s) exposed!")

        # ── Step 9: Misconfiguration Engine ───────────────────────────────────
        misconfigs = self._misconfig.analyse(buckets_raw, k8s_raw, cicd_raw, registries)
        self._status("Misconfig Engine", f"{len(misconfigs)} misconfiguration(s) detected")

        # ── Step 10: Surface Mapping & Risk Scoring ───────────────────────────
        surface    = self._surface.map(providers, cloud_assets, buckets_raw,
                                        k8s_raw, cicd_raw, [m.__dict__ for m in misconfigs])
        risk_score, risk_level, risk_summary = self._risk.score(
            buckets_raw, k8s_raw, cicd_raw, [m.__dict__ for m in misconfigs], providers
        )
        duration = time.perf_counter() - t0

        report = CloudIntelligenceReport(
            target    = target,
            timestamp = ts,
            providers = [CloudProvider(p) for p in set(providers) if p in
                         [v.value for v in CloudProvider]],
            cloud_assets = [
                CloudAsset(
                    asset_id   = hashlib.md5(a.get("url","?").encode(),usedforsecurity=False).hexdigest()[:10],
                    asset_type = a.get("service","").lower().replace(" ","_"),
                    provider   = CloudProvider(a.get("provider","unknown"))
                                 if a.get("provider") in [v.value for v in CloudProvider]
                                 else CloudProvider.UNKNOWN,
                    name = a.get("service",""),
                    url  = a.get("url",""),
                    risk = CloudRisk(a.get("risk", CloudRisk.INFO.value))
                          if a.get("risk") in [v.value for v in CloudRisk]
                          else CloudRisk.INFO,
                )
                for a in cloud_assets
            ],
            misconfigs    = misconfigs,
            risk_score    = risk_score,
            risk_level    = risk_level,
            executive_summary = risk_summary,
            stats = {
                "providers":    list(set(providers)),
                "cloud_assets": len(cloud_assets),
                "buckets":      len(buckets_raw),
                "public_buckets": sum(1 for b in buckets_raw if b.get("is_public")),
                "k8s_components": len(k8s_raw),
                "cicd_systems": len(cicd_raw),
                "registries":   len(registries),
                "misconfigs":   len(misconfigs),
                "surface":      {"node_count": surface["node_count"], "edge_count": surface["edge_count"]},
                "risk_score":   risk_score,
                "duration_s":   round(duration, 2),
            },
        )

        self._print_results(report, buckets_raw, k8s_raw, cicd_raw, misconfigs)
        return report

    def export_json(self, report: CloudIntelligenceReport, output_dir: str = "reports") -> str:
        os.makedirs(output_dir, exist_ok=True)
        fn = os.path.join(output_dir,
                          f"reconx_cloud_{report.target.replace('.','_')}_{report.timestamp}.json")
        with open(fn, "w", encoding="utf-8") as f:
            json.dump(report.to_dict(), f, indent=2, default=str)
        return fn

    # ── Rich output ───────────────────────────────────────────────────────────

    def _print_header(self, target: str) -> None:
        self._console.print()
        self._console.print(Panel.fit(
            f"[bold cyan][ Cloud Intelligence ][/bold cyan]\n"
            f"[white]Target:[/white] [yellow]{target}[/yellow]",
            border_style="cyan",
        ))
        self._console.print()

    def _print_results(self, report, buckets, k8s, cicd, misconfigs) -> None:
        # Misconfigs table
        if misconfigs:
            table = Table(title="☁️ Cloud Misconfigurations",
                          box=box.SIMPLE_HEAD, border_style="red")
            table.add_column("Risk",     width=10)
            table.add_column("Category", width=28)
            table.add_column("Title",    width=48)
            table.add_column("URL",      width=40)

            for m in sorted(misconfigs, key=lambda x: x.risk.numeric, reverse=True)[:15]:
                sev_s = SEV_STYLE.get(m.risk.value, "white")
                table.add_row(
                    f"[{sev_s}]{m.risk.value}[/{sev_s}]",
                    m.category[:27], m.title[:47], m.url[:39],
                )
            self._console.print(table)

        # K8s summary
        if k8s:
            self._console.print(
                f"\n  [bold cyan]Kubernetes:[/bold cyan] {len(k8s)} component(s) — "
                + ", ".join(set(k.get("component","") for k in k8s[:4]))
            )

        # CI/CD summary
        if cicd:
            self._console.print(
                f"  [bold cyan]CI/CD:[/bold cyan] " +
                ", ".join(f"{c['system']} ({'unauth' if not c.get('auth_required') else 'auth'})"
                          for c in cicd[:4])
            )

        # Risk panel
        sev_s = SEV_STYLE.get(report.risk_level.value, "white")
        self._console.print(Panel(
            f"[bold]Cloud Risk:[/bold] [{sev_s}]{report.risk_score:.0f}/100 "
            f"({report.risk_level.value})[/{sev_s}]\n"
            f"[dim]{report.executive_summary}[/dim]\n"
            f"[dim]Providers: {report.stats.get('providers',[])} | "
            f"Assets: {report.stats.get('cloud_assets',0)} | "
            f"Buckets: {report.stats.get('buckets',0)} "
            f"({report.stats.get('public_buckets',0)} public) | "
            f"Misconfigs: {report.stats.get('misconfigs',0)}[/dim]",
            title="Cloud Intelligence Report", border_style=sev_s,
        ))
        self._console.print()

    def _status(self, label: str, msg: str) -> None:
        self._console.print(f"  [green]✔[/green] [bold]{label:<22}[/bold] → {msg}")

    def _warn(self, msg: str) -> None:
        self._console.print(f"  [yellow]⚠[/yellow] {msg}")
