"""
ReconX — Stage 17: Smart Infrastructure Tag Engine.

Automatically labels findings and assets with semantic infrastructure tags.
Tags transform raw scan data into instantly readable infrastructure context
for operators and reports.

Tags produced:
  [CDN]       — host sits behind a CDN / WAF proxy
  [LOGIN]     — authentication panel detected
  [API]       — API endpoint or API gateway detected
  [ADMIN]     — admin interface or management panel
  [CLOUD]     — cloud-hosted or cloud-managed asset
  [VPN]       — VPN gateway or remote-access service
  [MAIL]      — email-related service
  [CRITICAL]  — extremely high-risk exposure
  [DATABASE]  — database service exposed
  [DEVTOOLS]  — developer tooling (Jenkins, GitLab, Grafana, …)
  [K8S]       — Kubernetes / container orchestration
  [LEGACY]    — outdated / end-of-life technology
  [EXPOSED]   — sensitive service directly reachable
  [TLS-WEAK]  — weak or expired TLS configuration
  [TAKEOVER]  — subdomain takeover candidate

Usage:
    from reconx.analysis.tag_engine import TagEngine
    from reconx.models.findings import ReconResult

    engine  = TagEngine()
    tagged  = engine.tag(result)   # returns TaggedResult

    for asset in tagged.tagged_assets:
        print(asset.label, asset.tags)
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import Optional

from ..models.findings import ReconResult, Port, Technology

log = logging.getLogger("reconx.analysis.tag_engine")


# ─────────────────────────────────────────────────────────────────────────────
# Tag definitions
# ─────────────────────────────────────────────────────────────────────────────

# Tag → colour for Rich TUI rendering
TAG_STYLES: dict[str, str] = {
    "CDN":       "bold cyan",
    "LOGIN":     "bold yellow",
    "API":       "bold blue",
    "ADMIN":     "bold red",
    "CLOUD":     "bold cyan",
    "VPN":       "bold magenta",
    "MAIL":      "dim white",
    "CRITICAL":  "bold red on dark_red",
    "DATABASE":  "bold red",
    "DEVTOOLS":  "bold yellow",
    "K8S":       "bold blue",
    "LEGACY":    "dim yellow",
    "EXPOSED":   "bold orange3",
    "TLS-WEAK":  "bold yellow",
    "TAKEOVER":  "bold red",
    "SSH":       "dim green",
    "FTP":       "dim yellow",
    "SMB":       "bold red",
    "RDP":       "bold red",
    "DNS":       "dim cyan",
}

TAG_DESCRIPTIONS: dict[str, str] = {
    "CDN":      "Traffic proxied through Content Delivery Network or WAF",
    "LOGIN":    "Authentication panel — potential credential attack surface",
    "API":      "API surface exposed — review for unauthenticated endpoints",
    "ADMIN":    "Administrative interface — high-priority hardening target",
    "CLOUD":    "Cloud-managed asset — check IAM policies and storage ACLs",
    "VPN":      "VPN or remote-access gateway — verify patch level",
    "MAIL":     "Email service — check SPF/DKIM/DMARC and relay configuration",
    "CRITICAL": "Critical severity exposure — immediate attention required",
    "DATABASE": "Database port exposed — verify access controls and encryption",
    "DEVTOOLS": "Developer tooling exposed — potential unauthenticated access",
    "K8S":      "Kubernetes / container infrastructure — review RBAC policies",
    "LEGACY":   "Outdated or EOL software — prioritise upgrade",
    "EXPOSED":  "Sensitive service directly accessible from the internet",
    "TLS-WEAK": "Weak, misconfigured, or expired TLS — upgrade immediately",
    "TAKEOVER": "Subdomain takeover candidate — DNS points to unclaimed resource",
    "SSH":      "SSH service — verify key-based auth and disable root login",
    "FTP":      "FTP service — prefer SFTP; verify anonymous access disabled",
    "SMB":      "SMB exposed — extremely high risk if internet-facing",
    "RDP":      "RDP exposed — high-value ransomware target; use VPN gateway",
    "DNS":      "DNS service exposed — check for zone transfer and amplification",
}


# ─────────────────────────────────────────────────────────────────────────────
# Port → tag mappings
# ─────────────────────────────────────────────────────────────────────────────

_PORT_TAGS: dict[int, list[str]] = {
    21:    ["FTP", "EXPOSED"],
    22:    ["SSH"],
    23:    ["LEGACY", "CRITICAL", "EXPOSED"],
    25:    ["MAIL", "EXPOSED"],
    53:    ["DNS"],
    80:    [],
    110:   ["MAIL"],
    135:   ["EXPOSED"],
    139:   ["SMB", "EXPOSED"],
    143:   ["MAIL"],
    161:   ["EXPOSED"],
    389:   ["EXPOSED"],
    443:   [],
    445:   ["SMB", "CRITICAL", "EXPOSED"],
    465:   ["MAIL"],
    587:   ["MAIL"],
    636:   ["EXPOSED"],
    993:   ["MAIL"],
    995:   ["MAIL"],
    1433:  ["DATABASE", "CRITICAL", "EXPOSED"],
    1521:  ["DATABASE", "CRITICAL", "EXPOSED"],
    2049:  ["EXPOSED"],
    2375:  ["CRITICAL", "EXPOSED"],         # Docker API no-TLS
    2376:  ["DATABASE", "EXPOSED"],         # Docker API TLS
    2379:  ["CRITICAL", "EXPOSED"],         # etcd
    3000:  ["DEVTOOLS"],
    3306:  ["DATABASE", "EXPOSED"],
    3389:  ["RDP", "CRITICAL", "EXPOSED"],
    4848:  ["ADMIN", "DEVTOOLS", "EXPOSED"],
    5000:  ["DEVTOOLS"],
    5432:  ["DATABASE", "EXPOSED"],
    5601:  ["DEVTOOLS", "EXPOSED"],         # Kibana
    5900:  ["CRITICAL", "EXPOSED"],         # VNC
    6379:  ["DATABASE", "CRITICAL", "EXPOSED"], # Redis
    6443:  ["K8S", "EXPOSED"],
    7001:  ["ADMIN", "EXPOSED"],            # WebLogic
    8080:  [],
    8443:  [],
    8888:  ["DEVTOOLS"],                    # Jupyter
    9000:  ["DEVTOOLS"],
    9090:  ["DEVTOOLS"],                    # Prometheus
    9200:  ["DATABASE", "CRITICAL", "EXPOSED"], # Elasticsearch
    9300:  ["DATABASE", "EXPOSED"],
    10250: ["K8S", "CRITICAL"],             # Kubelet API
    11211: ["DATABASE", "CRITICAL", "EXPOSED"], # Memcached
    15672: ["DEVTOOLS", "EXPOSED"],         # RabbitMQ mgmt
    27017: ["DATABASE", "CRITICAL", "EXPOSED"], # MongoDB
    50070: ["DEVTOOLS", "CRITICAL"],        # Hadoop
}

# Technology name substring → tags
_TECH_TAGS: list[tuple[str, list[str]]] = [
    # CDN / WAF
    ("cloudflare",  ["CDN"]),
    ("akamai",      ["CDN"]),
    ("fastly",      ["CDN"]),
    ("cloudfront",  ["CDN"]),
    ("incapsula",   ["CDN"]),
    ("sucuri",      ["CDN"]),
    # Admin panels
    ("phpmyadmin",  ["ADMIN", "DATABASE", "EXPOSED"]),
    ("adminer",     ["ADMIN", "DATABASE", "EXPOSED"]),
    ("webmin",      ["ADMIN", "EXPOSED"]),
    ("cpanel",      ["ADMIN"]),
    ("plesk",       ["ADMIN"]),
    # Dev tools
    ("jenkins",     ["DEVTOOLS", "ADMIN"]),
    ("gitlab",      ["DEVTOOLS"]),
    ("jira",        ["DEVTOOLS"]),
    ("confluence",  ["DEVTOOLS"]),
    ("grafana",     ["DEVTOOLS"]),
    ("kibana",      ["DEVTOOLS", "DATABASE"]),
    ("sonarqube",   ["DEVTOOLS"]),
    ("portainer",   ["DEVTOOLS", "K8S"]),
    # Login pages
    ("login",       ["LOGIN"]),
    ("signin",      ["LOGIN"]),
    ("auth",        ["LOGIN"]),
    # API
    ("swagger",     ["API"]),
    ("graphql",     ["API"]),
    ("api",         ["API"]),
    # Cloud
    ("aws",         ["CLOUD"]),
    ("azure",       ["CLOUD"]),
    ("gcp",         ["CLOUD"]),
    ("s3",          ["CLOUD"]),
    # VPN
    ("vpn",         ["VPN"]),
    ("openvpn",     ["VPN"]),
    ("fortinet",    ["VPN"]),
    ("pulse",       ["VPN"]),
    ("cisco",       ["VPN"]),
    # Mail
    ("postfix",     ["MAIL"]),
    ("exim",        ["MAIL"]),
    ("sendmail",    ["MAIL"]),
    ("exchange",    ["MAIL"]),
    ("dovecot",     ["MAIL"]),
    # K8S
    ("kubernetes",  ["K8S"]),
    ("docker",      ["K8S"]),
    ("rancher",     ["K8S"]),
    # Legacy
    ("iis/5",       ["LEGACY"]),
    ("iis/6",       ["LEGACY"]),
    ("iis/7",       ["LEGACY"]),
    ("apache/1",    ["LEGACY"]),
    ("apache/2.0",  ["LEGACY"]),
    ("apache/2.2",  ["LEGACY"]),
    ("openssh_5",   ["LEGACY"]),
    ("openssh_6",   ["LEGACY"]),
]

# Subdomain label patterns → tags
_SUBDOMAIN_TAGS: list[tuple[str, list[str]]] = [
    (r"^admin",   ["ADMIN"]),
    (r"^portal",  ["LOGIN"]),
    (r"^login",   ["LOGIN"]),
    (r"^auth",    ["LOGIN"]),
    (r"^sso",     ["LOGIN"]),
    (r"^api",     ["API"]),
    (r"^graphql", ["API"]),
    (r"^vpn",     ["VPN"]),
    (r"^remote",  ["VPN"]),
    (r"^rdp",     ["RDP", "CRITICAL"]),
    (r"^mail",    ["MAIL"]),
    (r"^smtp",    ["MAIL"]),
    (r"^mx",      ["MAIL"]),
    (r"^webmail", ["MAIL"]),
    (r"^dev",     ["DEVTOOLS"]),
    (r"^staging", ["DEVTOOLS"]),
    (r"^jenkins", ["DEVTOOLS", "ADMIN"]),
    (r"^git",     ["DEVTOOLS"]),
    (r"^gitlab",  ["DEVTOOLS"]),
    (r"^jira",    ["DEVTOOLS"]),
    (r"^cdn",     ["CDN"]),
    (r"^cloud",   ["CLOUD"]),
    (r"^s3",      ["CLOUD"]),
    (r"^ftp",     ["FTP"]),
    (r"^db",      ["DATABASE"]),
    (r"^mysql",   ["DATABASE"]),
    (r"^sql",     ["DATABASE"]),
    (r"^backup",  ["EXPOSED"]),
    (r"^test",    ["DEVTOOLS"]),
    (r"^uat",     ["DEVTOOLS"]),
]


# ─────────────────────────────────────────────────────────────────────────────
# Result models
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class TaggedAsset:
    """A discovered asset with its semantic tags attached."""
    label:      str
    asset_type: str           # host | subdomain | port | technology | endpoint
    tags:       list[str]     = field(default_factory=list)
    confidence: float         = 1.0
    metadata:   dict          = field(default_factory=dict)

    @property
    def highest_risk_tag(self) -> str:
        priority = ["CRITICAL", "EXPOSED", "ADMIN", "DATABASE", "DEVTOOLS",
                    "LOGIN", "API", "VPN", "CDN", "MAIL", "LEGACY", "K8S"]
        for t in priority:
            if t in self.tags:
                return t
        return self.tags[0] if self.tags else ""

    def render(self) -> str:
        tag_str = "  ".join(f"[{t}]" for t in sorted(self.tags))
        return f"{self.label:<40}  {tag_str}"

    def to_dict(self) -> dict:
        return {
            "label":      self.label,
            "asset_type": self.asset_type,
            "tags":       self.tags,
            "confidence": self.confidence,
        }


@dataclass
class TaggedResult:
    """Complete tagging output from TagEngine.tag()."""
    target:        str
    tagged_assets: list[TaggedAsset]   = field(default_factory=list)
    tag_summary:   dict[str, int]      = field(default_factory=dict)   # tag → count
    warnings:      list[str]           = field(default_factory=list)

    def assets_with_tag(self, tag: str) -> list[TaggedAsset]:
        return [a for a in self.tagged_assets if tag in a.tags]

    def critical_assets(self) -> list[TaggedAsset]:
        return self.assets_with_tag("CRITICAL")

    def to_dict(self) -> dict:
        return {
            "target":       self.target,
            "tag_summary":  self.tag_summary,
            "critical":     len(self.critical_assets()),
            "assets":       [a.to_dict() for a in self.tagged_assets],
            "warnings":     self.warnings,
        }


# ─────────────────────────────────────────────────────────────────────────────
# TagEngine
# ─────────────────────────────────────────────────────────────────────────────

class TagEngine:
    """
    Auto-labels all discovered assets in a ReconResult with semantic tags.

    Designed for pipeline integration — called as a post-processing step
    after all tools have run.  Never raises.
    """

    def tag(self, result: ReconResult) -> TaggedResult:
        """Run all tagging passes over a ReconResult."""
        tagged = TaggedResult(target=result.target)

        passes = [
            ("ports",        self._tag_ports),
            ("technologies", self._tag_technologies),
            ("subdomains",   self._tag_subdomains),
            ("tls",          self._tag_tls),
            ("takeovers",    self._tag_takeovers),
            ("host",         self._tag_host),
        ]

        for name, fn in passes:
            try:
                fn(result, tagged)
            except Exception as exc:
                msg = f"Tag pass '{name}' failed: {exc}"
                tagged.warnings.append(msg)
                log.warning(msg)

        # Build summary counter
        summary: dict[str, int] = {}
        for asset in tagged.tagged_assets:
            for tag in asset.tags:
                summary[tag] = summary.get(tag, 0) + 1
        tagged.tag_summary = dict(
            sorted(summary.items(), key=lambda kv: -kv[1])
        )

        log.info(
            f"TagEngine complete for {result.target}: "
            f"{len(tagged.tagged_assets)} assets, "
            f"tags={list(tagged.tag_summary.keys())}"
        )
        return tagged

    # ── Pass: Ports ───────────────────────────────────────────────────────────

    def _tag_ports(self, result: ReconResult, tagged: TaggedResult) -> None:
        for port in result.ports:
            if port.state != "open":
                continue
            base_tags  = list(_PORT_TAGS.get(port.number, []))
            extra_tags = _tags_from_banner(
                " ".join([port.banner, port.service, port.version])
            )
            all_tags = _dedup_tags(base_tags + extra_tags)
            if not all_tags:
                continue
            tagged.tagged_assets.append(TaggedAsset(
                label      = f":{port.number} ({port.service or 'unknown'})",
                asset_type = "port",
                tags       = all_tags,
                metadata   = {
                    "port":    port.number,
                    "service": port.service,
                    "version": port.version,
                },
            ))

    # ── Pass: Technologies ────────────────────────────────────────────────────

    def _tag_technologies(
        self, result: ReconResult, tagged: TaggedResult
    ) -> None:
        for tech in result.technologies:
            tech_tags = _tags_from_tech_name(tech.name)
            if not tech_tags:
                continue
            tagged.tagged_assets.append(TaggedAsset(
                label      = tech.name + (f" {tech.version}" if tech.version else ""),
                asset_type = "technology",
                tags       = tech_tags,
                confidence = 0.85,
                metadata   = {"version": tech.version, "category": tech.category},
            ))

    # ── Pass: Subdomains ──────────────────────────────────────────────────────

    def _tag_subdomains(
        self, result: ReconResult, tagged: TaggedResult
    ) -> None:
        for sub in result.subdomains[:200]:
            sub_tags = _tags_from_subdomain(sub)
            if sub_tags:
                tagged.tagged_assets.append(TaggedAsset(
                    label      = sub,
                    asset_type = "subdomain",
                    tags       = sub_tags,
                    confidence = 0.80,
                ))

    # ── Pass: TLS Analysis ────────────────────────────────────────────────────

    def _tag_tls(self, result: ReconResult, tagged: TaggedResult) -> None:
        if not result.tls_info:
            return
        tls_tags: list[str] = []
        if result.tls_info.is_expired:
            tls_tags.append("TLS-WEAK")
            tls_tags.append("CRITICAL")
        elif result.tls_info.is_self_signed:
            tls_tags.append("TLS-WEAK")
        elif result.tls_info.days_remaining < 14:
            tls_tags.append("TLS-WEAK")
        if result.tls_info.protocol and result.tls_info.protocol in ("TLSv1", "TLSv1.1", "SSLv3"):
            tls_tags.append("TLS-WEAK")
            tls_tags.append("LEGACY")

        if tls_tags:
            tagged.tagged_assets.append(TaggedAsset(
                label      = f"TLS ({result.tls_info.protocol or 'unknown'})",
                asset_type = "tls",
                tags       = _dedup_tags(tls_tags),
                metadata   = {
                    "issuer":         result.tls_info.issuer,
                    "days_remaining": result.tls_info.days_remaining,
                    "protocol":       result.tls_info.protocol,
                },
            ))

    # ── Pass: Takeover Candidates ─────────────────────────────────────────────

    def _tag_takeovers(
        self, result: ReconResult, tagged: TaggedResult
    ) -> None:
        for candidate in result.takeover_candidates:
            tagged.tagged_assets.append(TaggedAsset(
                label      = candidate.subdomain,
                asset_type = "subdomain",
                tags       = ["TAKEOVER", "CRITICAL"],
                confidence = 0.90,
                metadata   = {
                    "cname":   candidate.cname,
                    "service": candidate.service,
                },
            ))

    # ── Pass: Host-level tags ─────────────────────────────────────────────────

    def _tag_host(self, result: ReconResult, tagged: TaggedResult) -> None:
        """Tag the root target based on aggregate findings."""
        host_tags: list[str] = []
        port_numbers = {p.number for p in result.ports if p.state == "open"}

        if 443 in port_numbers:
            pass  # HTTPS — normal, no special tag
        if {445, 3389, 23} & port_numbers:
            host_tags.append("CRITICAL")
        if result.cve_matches:
            max_sev = max(
                {"CRITICAL": 4, "HIGH": 3, "MEDIUM": 2, "LOW": 1}.get(
                    m.severity.upper(), 0
                )
                for m in result.cve_matches
            )
            if max_sev >= 3:
                host_tags.append("CRITICAL")

        if host_tags:
            tagged.tagged_assets.append(TaggedAsset(
                label      = result.target,
                asset_type = "host",
                tags       = _dedup_tags(host_tags),
                confidence = 0.95,
            ))


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _tags_from_banner(banner: str) -> list[str]:
    """Extract tags from a raw banner / service / version string."""
    tags: list[str] = []
    banner_lower = banner.lower()
    for kw, kw_tags in _TECH_TAGS:
        if kw in banner_lower:
            tags.extend(kw_tags)
    return _dedup_tags(tags)


def _tags_from_tech_name(name: str) -> list[str]:
    """Extract tags from a Technology.name value."""
    tags: list[str] = []
    name_lower = name.lower()
    for kw, kw_tags in _TECH_TAGS:
        if kw in name_lower:
            tags.extend(kw_tags)
    return _dedup_tags(tags)


def _tags_from_subdomain(subdomain: str) -> list[str]:
    """Extract tags from a subdomain label (leftmost part)."""
    tags: list[str] = []
    label = subdomain.split(".")[0].lower() if subdomain else ""
    for pattern, pat_tags in _SUBDOMAIN_TAGS:
        if re.match(pattern, label, re.IGNORECASE):
            tags.extend(pat_tags)
    return _dedup_tags(tags)


def _dedup_tags(tags: list[str]) -> list[str]:
    seen: set[str] = set()
    result: list[str] = []
    for t in tags:
        if t not in seen:
            seen.add(t)
            result.append(t)
    return result


def tag_style(tag: str) -> str:
    """Return the Rich style string for a given tag."""
    return TAG_STYLES.get(tag, "dim")


def tag_description(tag: str) -> str:
    """Return the human-readable description for a tag."""
    return TAG_DESCRIPTIONS.get(tag, "")
