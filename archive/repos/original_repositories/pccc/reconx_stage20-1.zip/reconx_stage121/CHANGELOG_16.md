# ReconX — Stage 16 Changelog

## Overview

Stage 16 elevates ReconX from a tool launcher into a **full
Intelligent Recon Workflow Platform**.  The new workflow subsystem
(`reconx/workflow/`) orchestrates complete reconnaissance chains with
automated sequencing, parallelism, checkpointing, session recording,
replay, and a guided analyst assistant — all wired into the existing
TUI OS, plugin system, reporting engine, and telemetry stack.

---

## New Files (9)

### `workflow/` — Complete Workflow Orchestration System

| File | Class / Function | Description |
|---|---|---|
| `schemas.py` | `WorkflowStep`, `WorkflowDefinition`, `WorkflowSession`, `StepStatus`, `WorkflowStatus`, `ExecutionMode` | Core data models. Full JSON serialisation (`to_dict` / `from_dict`). Runtime state fields on every step (status, error, attempts, duration, finding_count). |
| `engine.py` | `WorkflowEngine` | Main execution orchestrator. Sequential + parallel execution. Topological sort for `depends_on` resolution. Condition guards (`has_subdomains`, `has_live_hosts`, `has_open_ports`, `has_urls`, `has_findings`, `always`, `never`). Per-step retry with exponential back-off. Pause / resume via flag. `on_step_start` / `on_step_done` callbacks for TUI + recorder integration. Failure isolation — one crash never kills the workflow. |
| `templates.py` | `WorkflowTemplates` | 11 pre-built templates covering all major recon scenarios. `get(name)`, `list_all()`, `by_category()`, `for_target_type()`, `register()` for custom templates at runtime. |
| `recorder.py` | `WorkflowRecorder` | JSON session persistence. `save(session)`, `load(session_id)`, `load_path(path)`, `list_sessions()`, `delete(session_id)`. `make_step_callback()` for auto-save after every step. |
| `checkpoint.py` | `CheckpointManager` | Atomic crash-safe checkpointing (write-to-tmp then rename). `save()`, `load()` (resets non-success steps to PENDING for clean resume). `list_interrupted()` detects abandoned sessions. `make_step_callback()`. |
| `replay.py` | `WorkflowReplayer` | `replay()`, `clone()`, `resume()`, `rerun_failed()`, `diff()`. All paths go through WorkflowEngine for consistent execution guarantees. `diff()` returns finding deltas and per-tool status changes between two sessions. |
| `planner.py` | `WorkflowPlanner` | Rule-based goal→workflow planner with LLM-ready interface. `plan(goal, target_type, risk_profile, constraints)` returns a ready-to-execute `WorkflowDefinition`. `explain()` returns human-readable reasoning. `recommend_for_objective()` scores templates by objective match. |
| `guided.py` | `GuidedRecon` | Interactive 4-step analyst assistant. 10 curated objectives. Inline tool education (Learn First path). Live step-by-step workflow customisation (add/remove steps). Session auto-save on completion. |
| `__init__.py` | — | Clean public API export of all 7 public classes + all schema types. |

### `tui/views/workflow_center.py` — `WorkflowCenter`

Full-featured TUI replacing the Stage 15 stub `_workflow_center()`:

- **[1] Fast Recon** — one-click `fast_scan` template
- **[2] Deep Recon** — one-click `deep_scan` template
- **[3] Passive Recon** — one-click `passive_recon` template
- **[4] Cloud Recon** — one-click `cloud_recon` template
- **[5] Guided Recon** — launches `GuidedRecon` interactive assistant
- **[6] Replay Session** — paginated session list, replay or clone
- **[7] Resume Interrupted** — shows checkpoint count badge; interactive resume picker
- **[8] Workflow Library** — browse all 11 templates with step detail view
- **[9] Custom Template** — run any template by name

Live progress bar during execution (Rich `Progress`). Auto-checkpoint
after every step. Session saved + checkpoint cleaned on completion.

### `output/report_16.py` — `inject_workflow_section()`

Injects a workflow metadata HTML section into any existing ReconX report:

- Summary pills: workflow name, status, duration, start time, step counts, findings
- **Step timeline** — proportional CSS duration bars per step, colour-coded by
  status (success / failed / skipped / pending), parallel group badge, finding count
- **Event log** — last 20 workflow events with timestamps
- Learning resources referenced during session
- `inject_workflow_section(html_path, session)` — accepts `WorkflowSession`
- `inject_workflow_section_dict(html_path, meta)` — accepts plain dict (for
  sessions loaded from JSON)

---

## 11 Workflow Templates

| Name | Category | Steps | Est. | Root | Description |
|---|---|---|---|---|---|
| `passive_recon` | passive | 8 | 10m | no | Zero-traffic OSINT; CT logs, Subfinder, Amass passive, Wayback, Shodan |
| `active_recon` | active | 9 | 20m | no | Full active recon; DNS, subdomain enum, HTTP probe, Nmap, service detection, Nuclei |
| `fast_scan` | active | 5 | 5m | no | Speed-first; only top-yield tools in parallel |
| `deep_scan` | active | 16 | 60m | no | Maximum coverage; all 3 phases, crawling, secret scanning, screenshots |
| `web_application` | web | 10 | 25m | no | WAF, crawl, endpoint extraction, JS secrets, content discovery, Nuclei |
| `api_recon` | api | 7 | 20m | no | GraphQL introspection, OpenAPI schema, API endpoint fuzzing, key scanning |
| `cloud_recon` | cloud | 9 | 30m | no | ASN → S3 buckets → CloudFox → cloud misconfig templates |
| `internal_network` | internal | 8 | 25m | **yes** | ARP discovery, full TCP scan, SMB, SNMP, TLS audit, Nuclei |
| `bug_bounty` | bug_bounty | 16 | 45m | no | Modern BBH chain; subdomain takeover, CORS, JS secrets, screenshots |
| `full_attack_surface` | enterprise | 20 | 90m | no | All vectors; domains, ASN, cloud, email, code repos, APIs |
| `enterprise_assessment` | enterprise | 16 | 75m | no | Structured engagement; passive → active → cloud → web → vuln → screenshots |

---

## Execution Engine: Key Features

### Dependency Resolution
Steps declare `depends_on: list[str]` of tool class names. The engine
performs a topological sort — steps only run after all their dependencies
have completed successfully.

### Parallel Groups
Steps in the same `parallel_group` string run concurrently via
`ThreadPoolExecutor`. Independent groups (e.g. subdomain enumerators)
are automatically batched together.

### Conditional Execution
Steps declare `condition` strings evaluated against the accumulated
session context:

| Condition | Passes when |
|---|---|
| `has_subdomains` | Session found ≥1 subdomain |
| `has_live_hosts` | Session found ≥1 live HTTP host |
| `has_open_ports` | Session found ≥1 open port |
| `has_urls` | Session found ≥1 URL |
| `has_findings` | Any finding accumulated |
| `always` | Always |
| `never` | Skip unconditionally |

### Failure Isolation
- Non-required step failure → step is marked `FAILED`, execution continues
- Required step failure → all remaining `PENDING` steps → `CANCELLED`,
  session status → `FAILED`
- Any unhandled exception inside a tool → caught by engine, never propagates

### Retries
Each step has `max_retries` (default: 1). Retries use exponential
back-off: `min(2^attempt, 10)` seconds between attempts.

---

## Workflow Planner: Goal Keywords

The rule-based planner maps goal text to templates via keyword matching:

| Keywords | Template |
|---|---|
| passive, osint, stealth, silent | `passive_recon` |
| fast, quick, rapid, speed | `fast_scan` |
| web, http, endpoint, login, panel | `web_application` |
| api, graphql, rest, openapi | `api_recon` |
| cloud, s3, bucket, aws, gcp | `cloud_recon` |
| bug bounty, takeover, cors | `bug_bounty` |
| internal, lan, smb, active directory | `internal_network` |
| enterprise, assessment, pentest | `enterprise_assessment` |
| full, complete, attack surface, everything | `full_attack_surface` |
| deep, thorough, maximum | `deep_scan` |
| active, scan, enumerate, discover | `active_recon` |

Risk profile adjustments:
- `low` → only Stage 1 (passive) steps retained
- `medium` → Stages 1–2 only
- `high` → all stages (no filter)

---

## Modified Files (2)

### `tui/navigator.py`
- `_workflow_center()` stub replaced with full `WorkflowCenter` lazy init
- `self._workflow_view` added to lazy instance dict
- `_workflow_view` included in theme-reset cleanup

### `tui/views/__init__.py`
No changes required — `WorkflowCenter` imports cleanly from the existing package.

---

## Architecture: How it fits together

```
CLI / TUI
    │
    ▼
WorkflowCenter (tui/views/workflow_center.py)
    │
    ├── WorkflowTemplates.get("passive_recon")   ←  templates.py
    │       │
    │       ▼ WorkflowDefinition
    ├── WorkflowEngine.execute(wf_def, target)   ←  engine.py
    │       │
    │       ├── Topological sort (depends_on)
    │       ├── Parallel group dispatch (ThreadPoolExecutor)
    │       ├── Condition evaluation (context)
    │       ├── Per-step retry + isolation
    │       │
    │       ├── on_step_done → CheckpointManager.save()  ←  checkpoint.py
    │       └── returns WorkflowSession
    │
    ├── WorkflowRecorder.save(session)            ←  recorder.py
    ├── inject_workflow_section(report, session)  ←  output/report_16.py
    │
    └── WorkflowReplayer.replay / resume / clone  ←  replay.py

GuidedRecon (workflow/guided.py)
    │
    ├── WorkflowPlanner.plan(goal, target_type)   ←  planner.py
    └── WorkflowEngine.execute(planned_wf, target)

Plugin authors:
    BaseWorkflowPlugin → workflow registered in BUILTIN_CHAINS → WorkflowTemplates
    BaseAgentPlugin   → future: observe() + propose() → planner integration
```

---

## Compatibility

All Stage 16 components:
- Import gracefully from both `reconx.*` and bare module paths
- Catch all exceptions internally (engine, recorder, checkpoint)
- Use the same `ToolRegistry` / `BaseTool` / `PipelineTask` types from prior stages
- Are fully serialisable to/from JSON (no pickle, no complex objects in sessions)
- Are compatible with Stage 15 `PluginLoader` — `BaseWorkflowPlugin` steps
  inject directly into `WorkflowDefinition.steps` via the existing loader

---

## Future Foundation

`WorkflowPlanner._select_template()` is the single hook point for
LLM replacement.  Swapping the rule-based matcher for a call to an
LLM (local Ollama or remote API) requires no changes to any other
module — the interface accepts a `goal: str` and returns a
`WorkflowDefinition`.

`BaseAgentPlugin.propose(state)` (Stage 15 stub) feeds directly into
`WorkflowEngine` — agents propose the next step class name and the
engine adds it to the live session plan.
