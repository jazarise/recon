"""
ReconX — Standardized tool result models.

Every tool.run() returns a ToolRunResult.
No raw dicts. No unparsed strings. No exceptions escaping silently.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional


# ── Status ────────────────────────────────────────────────────────────────────

class RunStatus(str, Enum):
    SUCCESS      = "success"
    FAILED       = "failed"
    TIMEOUT      = "timeout"
    SKIPPED      = "skipped"       # binary not available
    NO_OUTPUT    = "no_output"     # ran fine but produced nothing
    PARSE_ERROR  = "parse_error"   # output received but parser failed
    INVALID_TARGET = "invalid_target"


# ── Sub-models ────────────────────────────────────────────────────────────────

@dataclass
class ExecutionMetrics:
    """Timing and resource info for a single tool run."""
    started_at:   float  = 0.0     # epoch seconds
    finished_at:  float  = 0.0
    duration_s:   float  = 0.0
    retries_used: int    = 0
    returncode:   int    = -1

    @property
    def timed_out(self) -> bool:
        return self.returncode == -9   # SIGKILL convention


@dataclass
class ToolError:
    """Structured failure info."""
    reason:    str          # short machine-readable key
    message:   str          # human-readable detail
    traceback: str  = ""    # optional full traceback
    stderr:    str  = ""    # raw stderr from subprocess


@dataclass
class ParsedFinding:
    """
    A single normalized finding from any tool.
    Tools produce lists of these; analysis layer consumes them.
    """
    finding_type: str           # "subdomain" | "port" | "cve" | "url" | "email" | …
    value:        str           # the actual finding (e.g. "dev.example.com")
    source:       str   = ""    # tool name that produced this
    confidence:   float = 1.0   # 0.0–1.0
    metadata:     dict  = field(default_factory=dict)  # type-specific extras


# ── Primary result ────────────────────────────────────────────────────────────

@dataclass
class ToolRunResult:
    """
    Returned by every BaseTool.run() call.
    Consumers should check .ok before using .data or .findings.
    """
    tool_name:  str
    status:     RunStatus

    # Parsed, structured data (tool-specific dict — same schema as before)
    data:       dict = field(default_factory=dict)

    # Normalized findings list (generic cross-tool format)
    findings:   list[ParsedFinding] = field(default_factory=list)

    # Metrics
    metrics:    ExecutionMetrics    = field(default_factory=ExecutionMetrics)

    # Error details (populated when status != SUCCESS)
    error:      Optional[ToolError] = None

    # Raw I/O (for debug; never used by analysis layer)
    raw_stdout: str = ""
    raw_stderr: str = ""

    # ── Convenience ───────────────────────────────────────────────────────────

    @property
    def ok(self) -> bool:
        return self.status == RunStatus.SUCCESS

    @property
    def icon(self) -> str:
        return {
            RunStatus.SUCCESS:       "✔",
            RunStatus.FAILED:        "✖",
            RunStatus.TIMEOUT:       "⏱",
            RunStatus.SKIPPED:       "○",
            RunStatus.NO_OUTPUT:     "∅",
            RunStatus.PARSE_ERROR:   "⚡",
            RunStatus.INVALID_TARGET:"⚠",
        }.get(self.status, "?")

    @property
    def style(self) -> str:
        return {
            RunStatus.SUCCESS:       "bold green",
            RunStatus.FAILED:        "bold red",
            RunStatus.TIMEOUT:       "yellow",
            RunStatus.SKIPPED:       "dim",
            RunStatus.NO_OUTPUT:     "dim cyan",
            RunStatus.PARSE_ERROR:   "orange3",
            RunStatus.INVALID_TARGET:"red",
        }.get(self.status, "white")

    # ── Factories ─────────────────────────────────────────────────────────────

    @classmethod
    def success(cls, tool_name: str, data: dict,
                findings: list[ParsedFinding] | None = None,
                metrics: ExecutionMetrics | None = None,
                stdout: str = "") -> "ToolRunResult":
        return cls(
            tool_name=tool_name,
            status=RunStatus.SUCCESS,
            data=data,
            findings=findings or [],
            metrics=metrics or ExecutionMetrics(),
            raw_stdout=stdout,
        )

    @classmethod
    def skipped(cls, tool_name: str, reason: str) -> "ToolRunResult":
        return cls(
            tool_name=tool_name,
            status=RunStatus.SKIPPED,
            error=ToolError(reason="not_installed", message=reason),
        )

    @classmethod
    def timeout(cls, tool_name: str, duration_s: float,
                timeout_s: float) -> "ToolRunResult":
        m = ExecutionMetrics(duration_s=duration_s, returncode=-9)
        return cls(
            tool_name=tool_name,
            status=RunStatus.TIMEOUT,
            metrics=m,
            error=ToolError(
                reason="timeout",
                message=f"Exceeded {timeout_s}s timeout after {duration_s:.1f}s",
            ),
        )

    @classmethod
    def failure(cls, tool_name: str, reason: str, message: str,
                stderr: str = "", traceback: str = "",
                metrics: ExecutionMetrics | None = None) -> "ToolRunResult":
        return cls(
            tool_name=tool_name,
            status=RunStatus.FAILED,
            metrics=metrics or ExecutionMetrics(),
            raw_stderr=stderr,
            error=ToolError(reason=reason, message=message,
                            stderr=stderr, traceback=traceback),
        )

    @classmethod
    def invalid_target(cls, tool_name: str, target: str,
                       detail: str = "") -> "ToolRunResult":
        return cls(
            tool_name=tool_name,
            status=RunStatus.INVALID_TARGET,
            error=ToolError(
                reason="invalid_target",
                message=f"Target '{target}' failed validation. {detail}".strip(),
            ),
        )
