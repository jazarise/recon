"""
ReconX — Unified data models for all findings.
All tool outputs are normalized into these structures.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class Port:
    number: int
    protocol: str = "tcp"
    state: str = "unknown"
    service: str = ""
    version: str = ""
    banner: str = ""


@dataclass
class DNSRecord:
    record_type: str
    value: str
    ttl: int = 0


@dataclass
class Technology:
    name: str
    version: str = ""
    category: str = ""


@dataclass
class CVEMatch:
    cve_id: str
    severity: str
    description: str
    service: str
    port: int = 0
    cvss: float = 0.0
    reference: str = ""


@dataclass
class TLSInfo:
    subject: str = ""
    issuer: str = ""
    valid_from: str = ""
    valid_until: str = ""
    days_remaining: int = -1
    is_expired: bool = False
    is_self_signed: bool = False
    san_domains: list = field(default_factory=list)
    protocol: str = ""
    cipher: str = ""


@dataclass
class HeaderFinding:
    header: str
    status: str             # "present" | "missing" | "weak"
    value: str = ""
    risk: str = ""
    recommendation: str = ""


@dataclass
class TakeoverCandidate:
    subdomain: str
    cname: str
    service: str
    confidence: str
    detail: str = ""


@dataclass
class SensitiveFinding:
    category: str
    detail: str
    url: str = ""
    severity: str = "MEDIUM"


@dataclass
class Suggestion:
    finding: str
    risk: str
    recommendation: str
    severity: str = "MEDIUM"


@dataclass
class RiskScore:
    total: int = 0
    grade: str = "A"
    breakdown: dict = field(default_factory=dict)


@dataclass
class ReconResult:
    """Aggregated, normalized output of a full ReconX run."""
    target: str
    timestamp: str = ""
    mode: str = "balanced"

    ip_addresses: list[str] = field(default_factory=list)
    ports: list[Port] = field(default_factory=list)
    domains: list[str] = field(default_factory=list)
    subdomains: list[str] = field(default_factory=list)
    dns_records: list[DNSRecord] = field(default_factory=list)
    technologies: list[Technology] = field(default_factory=list)
    web_endpoints: list[str] = field(default_factory=list)
    emails: list[str] = field(default_factory=list)

    # Security analysis
    cve_matches: list[CVEMatch] = field(default_factory=list)
    tls_info: Optional[TLSInfo] = None
    header_findings: list[HeaderFinding] = field(default_factory=list)
    takeover_candidates: list[TakeoverCandidate] = field(default_factory=list)
    risk_score: Optional[RiskScore] = None

    whois: dict = field(default_factory=dict)
    os_info: dict = field(default_factory=dict)
    sensitive_findings: list[SensitiveFinding] = field(default_factory=list)
    suggestions: list[Suggestion] = field(default_factory=list)
    raw: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        import dataclasses
        return dataclasses.asdict(self)
