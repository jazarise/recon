"""
ReconX — Stage 11: API Intelligence Data Models.

Shared dataclasses consumed and produced across all API intelligence modules.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


# ── Enumerations ──────────────────────────────────────────────────────────────

class APIType(str, Enum):
    REST      = "rest"
    GRAPHQL   = "graphql"
    GRPC      = "grpc"
    WEBSOCKET = "websocket"
    SOAP      = "soap"
    UNKNOWN   = "unknown"


class AuthType(str, Enum):
    JWT         = "jwt"
    OAUTH2      = "oauth2"
    API_KEY     = "api_key"
    BASIC       = "basic_auth"
    BEARER      = "bearer"
    SESSION     = "session"
    NONE        = "none"
    UNKNOWN     = "unknown"


class HTTPMethod(str, Enum):
    GET     = "GET"
    POST    = "POST"
    PUT     = "PUT"
    PATCH   = "PATCH"
    DELETE  = "DELETE"
    HEAD    = "HEAD"
    OPTIONS = "OPTIONS"
    ANY     = "*"


class RiskLevel(str, Enum):
    CRITICAL = "CRITICAL"
    HIGH     = "HIGH"
    MEDIUM   = "MEDIUM"
    LOW      = "LOW"
    INFO     = "INFO"

    @property
    def numeric(self) -> int:
        return {"CRITICAL": 5, "HIGH": 4, "MEDIUM": 3, "LOW": 2, "INFO": 1}[self.value]

    @classmethod
    def from_score(cls, s: float) -> "RiskLevel":
        """Map a 0–10 numeric score to a RiskLevel."""
        if s >= 8.5: return cls.CRITICAL
        if s >= 6.5: return cls.HIGH
        if s >= 4.0: return cls.MEDIUM
        if s >= 1.0: return cls.LOW
        return cls.INFO

    @classmethod
    def from_string(cls, s: str) -> "RiskLevel":
        return {
            "critical": cls.CRITICAL, "high": cls.HIGH,
            "medium": cls.MEDIUM, "med": cls.MEDIUM,
            "low": cls.LOW, "info": cls.INFO,
        }.get(s.strip().lower(), cls.INFO)


# ── API Endpoint ──────────────────────────────────────────────────────────────

@dataclass
class APIEndpoint:
    """A discovered API endpoint."""
    url:          str
    method:       str                    = "GET"
    api_type:     APIType               = APIType.REST
    auth_required: bool                 = True
    auth_type:    Optional[AuthType]    = None
    parameters:   list[str]             = field(default_factory=list)
    response_type: str                  = ""         # "json" | "xml" | "html"
    status_code:  int                   = 0
    content_type: str                   = ""
    tags:         list[str]             = field(default_factory=list)
    source:       str                   = ""         # discovery source
    description:  str                   = ""
    is_hidden:    bool                  = False      # not in docs
    is_deprecated: bool                 = False
    metadata:     dict                  = field(default_factory=dict)


# ── GraphQL ───────────────────────────────────────────────────────────────────

@dataclass
class GraphQLField:
    """A field in a GraphQL type."""
    name:         str
    type_name:    str
    is_nullable:  bool              = True
    is_list:      bool              = False
    description:  str               = ""
    args:         list[str]         = field(default_factory=list)
    is_deprecated: bool             = False


@dataclass
class GraphQLType:
    """A GraphQL object type (Query, Mutation, Subscription, or custom)."""
    name:         str
    kind:         str               = "OBJECT"   # OBJECT | INPUT_OBJECT | ENUM | SCALAR | INTERFACE
    fields:       list[GraphQLField] = field(default_factory=list)
    description:  str               = ""
    is_sensitive: bool              = False      # contains PII/admin fields


@dataclass
class GraphQLSchema:
    """Parsed GraphQL schema from introspection."""
    types:        list[GraphQLType]  = field(default_factory=list)
    query_type:   Optional[str]      = None
    mutation_type: Optional[str]     = None
    subscription_type: Optional[str] = None
    introspection_enabled: bool      = False
    endpoint:     str               = ""
    directives:   list[str]         = field(default_factory=list)


# ── Auth Finding ──────────────────────────────────────────────────────────────

@dataclass
class AuthFinding:
    """An authentication-related finding on an API."""
    endpoint:     str
    auth_type:    AuthType
    risk_level:   RiskLevel
    issue:        str                # description of the auth problem
    evidence:     str                # what was observed
    remediation:  str
    confidence:   float             = 0.80


# ── Parameter ─────────────────────────────────────────────────────────────────

@dataclass
class APIParameter:
    """A discovered API parameter."""
    name:         str
    location:     str               # "query" | "body" | "header" | "path" | "cookie"
    data_type:    str               = "string"
    is_required:  bool              = False
    is_sensitive: bool              = False      # potential for injection/IDOR
    example:      str               = ""
    description:  str               = ""
    endpoints:    list[str]         = field(default_factory=list)
    tags:         list[str]         = field(default_factory=list)


# ── API Intelligence Report ───────────────────────────────────────────────────

@dataclass
class APIIntelligenceReport:
    """Top-level output of the Stage 11 API analysis pipeline."""
    target:           str
    timestamp:        str

    # Discovered assets
    endpoints:        list[APIEndpoint]   = field(default_factory=list)
    graphql_schemas:  list[GraphQLSchema] = field(default_factory=list)
    parameters:       list[APIParameter]  = field(default_factory=list)
    auth_findings:    list[AuthFinding]   = field(default_factory=list)

    # Surface metrics
    total_endpoints:  int  = 0
    hidden_endpoints: int  = 0
    graphql_count:    int  = 0
    auth_risk_count:  int  = 0

    # Technology
    frameworks:       list[str]  = field(default_factory=list)
    gateways:         list[str]  = field(default_factory=list)
    api_versions:     list[str]  = field(default_factory=list)

    # Swagger / OpenAPI
    swagger_specs:    list[str]  = field(default_factory=list)  # discovered spec URLs

    # Scores
    risk_score:       float      = 0.0
    risk_level:       RiskLevel  = RiskLevel.INFO

    # Summary
    executive_summary: str       = ""
    stats:            dict       = field(default_factory=dict)

    def to_dict(self) -> dict:
        import dataclasses
        return {
            "target":    self.target,
            "timestamp": self.timestamp,
            "endpoints": [
                {
                    "url":           e.url,
                    "method":        e.method,
                    "api_type":      e.api_type.value,
                    "auth_required": e.auth_required,
                    "auth_type":     e.auth_type.value if e.auth_type else None,
                    "parameters":    e.parameters,
                    "is_hidden":     e.is_hidden,
                    "source":        e.source,
                }
                for e in self.endpoints
            ],
            "graphql_schemas": [
                {
                    "endpoint":              s.endpoint,
                    "introspection_enabled": s.introspection_enabled,
                    "types":                 len(s.types),
                    "query_type":            s.query_type,
                    "mutation_type":         s.mutation_type,
                }
                for s in self.graphql_schemas
            ],
            "auth_findings": [
                {
                    "endpoint":    a.endpoint,
                    "auth_type":   a.auth_type.value,
                    "risk":        a.risk_level.value,
                    "issue":       a.issue,
                    "remediation": a.remediation,
                }
                for a in self.auth_findings
            ],
            "parameters": [
                {
                    "name":         p.name,
                    "location":     p.location,
                    "is_sensitive": p.is_sensitive,
                    "endpoints":    p.endpoints[:3],
                }
                for p in self.parameters
            ],
            "frameworks":      self.frameworks,
            "gateways":        self.gateways,
            "swagger_specs":   self.swagger_specs,
            "risk_score":      self.risk_score,
            "risk_level":      self.risk_level.value,
            "stats":           self.stats,
            "executive_summary": self.executive_summary,
        }
