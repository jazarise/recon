"""
ReconX — Stage 12: Cloud Intelligence Data Models.

Shared dataclasses consumed and produced by all cloud modules.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


# ── Enumerations ──────────────────────────────────────────────────────────────

class CloudProvider(str, Enum):
    AWS        = "aws"
    AZURE      = "azure"
    GCP        = "gcp"
    CLOUDFLARE = "cloudflare"
    FASTLY     = "fastly"
    AKAMAI     = "akamai"
    DO         = "digitalocean"
    LINODE     = "linode"
    UNKNOWN    = "unknown"


class CloudRisk(str, Enum):
    CRITICAL = "CRITICAL"
    HIGH     = "HIGH"
    MEDIUM   = "MEDIUM"
    LOW      = "LOW"
    INFO     = "INFO"

    @property
    def numeric(self) -> int:
        return {"CRITICAL": 5, "HIGH": 4, "MEDIUM": 3, "LOW": 2, "INFO": 1}[self.value]

    @classmethod
    def from_score(cls, s: float) -> "CloudRisk":
        if s >= 8.5: return cls.CRITICAL
        if s >= 6.5: return cls.HIGH
        if s >= 4.0: return cls.MEDIUM
        if s >= 1.0: return cls.LOW
        return cls.INFO

    @classmethod
    def from_string(cls, s: str) -> "CloudRisk":
        return {
            "critical": cls.CRITICAL, "high": cls.HIGH,
            "medium": cls.MEDIUM, "low": cls.LOW,
        }.get(s.strip().lower(), cls.INFO)


class StorageType(str, Enum):
    S3          = "s3"
    AZURE_BLOB  = "azure_blob"
    GCS         = "gcs"
    MINIO       = "minio"
    UNKNOWN     = "unknown"


class K8sComponent(str, Enum):
    API_SERVER  = "api_server"
    DASHBOARD   = "dashboard"
    ETCD        = "etcd"
    KUBELET     = "kubelet"
    HELM        = "helm"
    INGRESS     = "ingress"
    METRICS     = "metrics_server"


# ── Storage Bucket ────────────────────────────────────────────────────────────

@dataclass
class StorageBucket:
    """A discovered cloud storage bucket."""
    name:           str
    url:            str
    provider:       StorageType
    is_public:      bool                = False
    listing_enabled: bool               = False
    object_count:   int                 = 0
    sensitive_files: list[str]          = field(default_factory=list)
    sample_objects: list[str]           = field(default_factory=list)
    region:         str                 = ""
    risk:           CloudRisk           = CloudRisk.INFO
    cors_wildcard:  bool                = False
    metadata:       dict                = field(default_factory=dict)


# ── Cloud Asset ───────────────────────────────────────────────────────────────

@dataclass
class CloudAsset:
    """A discovered cloud service or resource."""
    asset_id:    str
    asset_type:  str             # "s3_bucket" | "cloudfront" | "lambda" | "eks" | "aks" | "gke" etc.
    provider:    CloudProvider
    name:        str
    url:         str             = ""
    region:      str             = ""
    is_public:   bool            = True
    risk:        CloudRisk       = CloudRisk.INFO
    evidence:    list[str]       = field(default_factory=list)
    metadata:    dict            = field(default_factory=dict)
    tags:        list[str]       = field(default_factory=list)


# ── Kubernetes Asset ──────────────────────────────────────────────────────────

@dataclass
class K8sAsset:
    """A discovered Kubernetes infrastructure component."""
    component:   K8sComponent
    url:         str
    provider:    CloudProvider    = CloudProvider.UNKNOWN   # EKS, AKS, GKE
    is_exposed:  bool             = True
    version:     str              = ""
    namespaces:  list[str]        = field(default_factory=list)
    risk:        CloudRisk        = CloudRisk.HIGH
    auth_required: bool           = False
    evidence:    list[str]        = field(default_factory=list)
    metadata:    dict             = field(default_factory=dict)


# ── Cloud Misconfiguration ────────────────────────────────────────────────────

@dataclass
class CloudMisconfig:
    """A detected cloud misconfiguration."""
    category:    str              # "public_bucket" | "open_api" | "exposed_dashboard" etc.
    title:       str
    description: str
    risk:        CloudRisk
    evidence:    str
    remediation: str
    url:         str             = ""
    provider:    CloudProvider   = CloudProvider.UNKNOWN
    confidence:  float           = 0.85


# ── CI/CD Cloud Asset ─────────────────────────────────────────────────────────

@dataclass
class CICDAsset:
    """A discovered CI/CD system running in cloud."""
    system:      str              # "github_actions" | "gitlab_ci" | "jenkins" | "argocd" | "tekton"
    url:         str
    provider:    CloudProvider    = CloudProvider.UNKNOWN
    is_exposed:  bool             = True
    risk:        CloudRisk        = CloudRisk.HIGH
    secrets_risk: bool            = False
    evidence:    list[str]        = field(default_factory=list)


# ── Cloud Intelligence Report ─────────────────────────────────────────────────

@dataclass
class CloudIntelligenceReport:
    """Top-level output from Stage 12 cloud pipeline."""
    target:          str
    timestamp:       str

    # Detected infrastructure
    providers:       list[CloudProvider]   = field(default_factory=list)
    cloud_assets:    list[CloudAsset]      = field(default_factory=list)
    buckets:         list[StorageBucket]   = field(default_factory=list)
    k8s_assets:      list[K8sAsset]        = field(default_factory=list)
    cicd_assets:     list[CICDAsset]       = field(default_factory=list)
    misconfigs:      list[CloudMisconfig]  = field(default_factory=list)

    # Summary
    risk_score:      float                 = 0.0
    risk_level:      CloudRisk             = CloudRisk.INFO
    executive_summary: str                 = ""
    stats:           dict                  = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "target":    self.target,
            "timestamp": self.timestamp,
            "providers": [p.value for p in self.providers],
            "cloud_assets": [
                {"type": a.asset_type, "provider": a.provider.value,
                 "name": a.name, "url": a.url, "risk": a.risk.value}
                for a in self.cloud_assets
            ],
            "buckets": [
                {"name": b.name, "url": b.url, "provider": b.provider.value,
                 "is_public": b.is_public, "listing": b.listing_enabled,
                 "risk": b.risk.value, "sensitive_files": b.sensitive_files}
                for b in self.buckets
            ],
            "k8s_assets": [
                {"component": k.component.value, "url": k.url,
                 "provider": k.provider.value, "risk": k.risk.value,
                 "auth_required": k.auth_required}
                for k in self.k8s_assets
            ],
            "cicd_assets": [
                {"system": c.system, "url": c.url,
                 "provider": c.provider.value, "risk": c.risk.value}
                for c in self.cicd_assets
            ],
            "misconfigs": [
                {"category": m.category, "title": m.title,
                 "risk": m.risk.value, "evidence": m.evidence,
                 "remediation": m.remediation}
                for m in self.misconfigs
            ],
            "risk_score":   self.risk_score,
            "risk_level":   self.risk_level.value,
            "summary":      self.executive_summary,
            "stats":        self.stats,
        }
