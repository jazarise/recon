"""
ReconX — Stage 9 Intelligence Data Models.

Shared dataclasses consumed and produced by all intelligence modules.
No external dependencies beyond stdlib — everything uses these as currency.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional


# ══════════════════════════════════════════════════════════════════════════════
#  Enumerations
# ══════════════════════════════════════════════════════════════════════════════

class RiskLevel(str, Enum):
    CRITICAL = "CRITICAL"
    HIGH     = "HIGH"
    MEDIUM   = "MEDIUM"
    LOW      = "LOW"
    INFO     = "INFO"

    @property
    def numeric(self) -> int:
        return {"CRITICAL": 5, "HIGH": 4, "MEDIUM": 3, "LOW": 2, "INFO": 1}[self.value]

    @property
    def score_mid(self) -> float:
        """Representative numeric score for this level."""
        return {"CRITICAL": 9.5, "HIGH": 7.5, "MEDIUM": 5.0, "LOW": 2.5, "INFO": 0.5}[self.value]

    @classmethod
    def from_score(cls, s: float) -> "RiskLevel":
        if s >= 8.5: return cls.CRITICAL
        if s >= 6.5: return cls.HIGH
        if s >= 4.0: return cls.MEDIUM
        if s >= 1.0: return cls.LOW
        return cls.INFO

    @classmethod
    def from_string(cls, s: str) -> "RiskLevel":
        return {
            "critical": cls.CRITICAL, "high": cls.HIGH,
            "medium": cls.MEDIUM, "med": cls.MEDIUM,
            "low": cls.LOW, "info": cls.INFO, "informational": cls.INFO,
        }.get(s.strip().lower(), cls.INFO)


class AssetType(str, Enum):
    PRODUCTION      = "production"
    STAGING         = "staging"
    DEVELOPMENT     = "development"
    ADMIN           = "admin"
    CICD            = "cicd"
    API_GATEWAY     = "api_gateway"
    AUTH_PORTAL     = "auth_portal"
    CLOUD_INFRA     = "cloud_infra"
    MONITORING      = "monitoring"
    DATABASE        = "database"
    STORAGE         = "storage"
    MAIL            = "mail"
    VPN             = "vpn"
    UNKNOWN         = "unknown"


class ConfidenceTier(str, Enum):
    HIGH   = "HIGH"    # 0.80–1.00 — exact match, validated
    MEDIUM = "MEDIUM"  # 0.50–0.79 — heuristic, corroborated
    LOW    = "LOW"     # 0.20–0.49 — weak signal, single source
    WEAK   = "WEAK"    # 0.00–0.19 — speculative

    @classmethod
    def from_score(cls, s: float) -> "ConfidenceTier":
        if s >= 0.80: return cls.HIGH
        if s >= 0.50: return cls.MEDIUM
        if s >= 0.20: return cls.LOW
        return cls.WEAK


# ══════════════════════════════════════════════════════════════════════════════
#  Risk Models
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class RiskFactor:
    """A single factor contributing to a risk score."""
    name:        str
    weight:      float          # contribution to total score (0–10)
    reason:      str            # human-readable explanation
    evidence:    list[str] = field(default_factory=list)


@dataclass
class IntelRiskScore:
    """
    Rich risk score produced by the intelligence engine.
    Supersedes the legacy RiskScore — more granular and correlated.
    """
    total:          float                   # 0.0–100.0 (normalized)
    risk_level:     RiskLevel
    grade:          str                     # A / B / C / D / F
    factors:        list[RiskFactor]        = field(default_factory=list)
    exploitability: float                   = 0.0   # 0–10
    exposure:       float                   = 0.0   # 0–10
    impact:         float                   = 0.0   # 0–10
    confidence:     float                   = 1.0   # 0–1
    summary:        str                     = ""


# ══════════════════════════════════════════════════════════════════════════════
#  Confidence Models
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class ConfidenceSignal:
    """A single signal contributing to finding confidence."""
    source:      str
    signal_type: str    # "banner_match" | "version_match" | "heuristic" | "regex" | "validated"
    weight:      float  # 0.0–1.0
    description: str


@dataclass
class ConfidenceScore:
    """Confidence assessment for a finding."""
    score:   float           # 0.0–1.0
    tier:    ConfidenceTier
    signals: list[ConfidenceSignal] = field(default_factory=list)
    note:    str = ""


# ══════════════════════════════════════════════════════════════════════════════
#  Asset Models
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class ClassifiedAsset:
    """An asset with its inferred type and metadata."""
    identifier:   str                   # hostname / IP / URL
    asset_type:   AssetType
    confidence:   float                 # classification confidence 0–1
    risk_level:   RiskLevel
    technologies: list[str]             = field(default_factory=list)
    open_ports:   list[int]             = field(default_factory=list)
    tags:         list[str]             = field(default_factory=list)
    evidence:     list[str]             = field(default_factory=list)
    is_internet_facing: bool            = True
    metadata:     dict                  = field(default_factory=dict)


# ══════════════════════════════════════════════════════════════════════════════
#  Attack Graph Models
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class AttackNode:
    """A node in the attack graph (host, service, endpoint, vuln, etc.)."""
    node_id:     str
    node_type:   str        # "host" | "service" | "endpoint" | "vuln" | "credential" | "data"
    label:       str
    risk_level:  RiskLevel  = RiskLevel.INFO
    metadata:    dict       = field(default_factory=dict)
    tags:        list[str]  = field(default_factory=list)


@dataclass
class AttackEdge:
    """A directed relationship between two attack graph nodes."""
    source_id:      str
    target_id:      str
    relationship:   str     # "exposes" | "runs" | "vulnerable_to" | "leads_to" | "authenticates"
    weight:         float   = 1.0
    description:    str     = ""


@dataclass
class AttackPath:
    """A sequence of nodes forming an exploitable path."""
    path_id:     str
    steps:       list[str]   # ordered node_ids
    risk_level:  RiskLevel
    description: str
    impact:      str         # what an attacker achieves at the end


@dataclass
class AttackGraph:
    """
    Full attack surface graph.
    Nodes = assets/services/vulns. Edges = relationships. Paths = exploitable chains.
    """
    nodes:       dict[str, AttackNode]  = field(default_factory=dict)
    edges:       list[AttackEdge]       = field(default_factory=list)
    paths:       list[AttackPath]       = field(default_factory=list)
    node_count:  int                    = 0
    edge_count:  int                    = 0

    def add_node(self, node: AttackNode) -> None:
        self.nodes[node.node_id] = node
        self.node_count = len(self.nodes)

    def add_edge(self, edge: AttackEdge) -> None:
        self.edges.append(edge)
        self.edge_count = len(self.edges)

    def get_neighbors(self, node_id: str) -> list[str]:
        return [e.target_id for e in self.edges if e.source_id == node_id]

    def to_dict(self) -> dict:
        return {
            "nodes": [
                {
                    "id":        n.node_id,
                    "type":      n.node_type,
                    "label":     n.label,
                    "risk":      n.risk_level.value,
                    "tags":      n.tags,
                    "metadata":  n.metadata,
                }
                for n in self.nodes.values()
            ],
            "edges": [
                {
                    "source":       e.source_id,
                    "target":       e.target_id,
                    "relationship": e.relationship,
                    "weight":       e.weight,
                    "description":  e.description,
                }
                for e in self.edges
            ],
            "paths": [
                {
                    "id":    p.path_id,
                    "steps": p.steps,
                    "risk":  p.risk_level.value,
                    "desc":  p.description,
                    "impact": p.impact,
                }
                for p in self.paths
            ],
            "node_count": self.node_count,
            "edge_count": self.edge_count,
        }


# ══════════════════════════════════════════════════════════════════════════════
#  Correlation Models
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class CorrelatedFinding:
    """
    A finding enriched by cross-source correlation.
    Distinct from Stage 8 CorrelatedFinding — operates on full ReconResult.
    """
    finding_id:    str
    title:         str
    description:   str
    risk_level:    RiskLevel
    confidence:    ConfidenceScore
    sources:       list[str]            = field(default_factory=list)
    related_ids:   list[str]            = field(default_factory=list)
    evidence:      list[str]            = field(default_factory=list)
    tags:          list[str]            = field(default_factory=list)
    remediation:   str                  = ""
    cves:          list[str]            = field(default_factory=list)
    affected_assets: list[str]          = field(default_factory=list)
    is_chain:      bool                 = False


# ══════════════════════════════════════════════════════════════════════════════
#  Recommendation Models
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class Recommendation:
    """A prioritized, contextual security recommendation."""
    rec_id:     str
    priority:   int             # 1 = highest
    title:      str
    context:    str             # why this recommendation applies
    action:     str             # what to do
    effort:     str             # LOW | MEDIUM | HIGH
    impact:     str             # what risk is reduced
    risk_level: RiskLevel
    tags:       list[str]       = field(default_factory=list)
    cves:       list[str]       = field(default_factory=list)
    references: list[str]       = field(default_factory=list)


# ══════════════════════════════════════════════════════════════════════════════
#  Intelligence Report (top-level output)
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class IntelligenceReport:
    """
    Complete Stage 9 output — the intelligence core's final product.
    Consumed by the output engine and future AI analysis stages.
    """
    target:            str
    timestamp:         str

    # Core intelligence outputs
    risk_score:        Optional[IntelRiskScore]         = None
    attack_graph:      Optional[AttackGraph]            = None
    correlated_findings: list[CorrelatedFinding]        = field(default_factory=list)
    classified_assets: list[ClassifiedAsset]            = field(default_factory=list)
    recommendations:   list[Recommendation]             = field(default_factory=list)
    anomalies:         list[dict]                       = field(default_factory=list)

    # Summary statistics
    stats:             dict                             = field(default_factory=dict)
    executive_summary: str                              = ""

    def to_dict(self) -> dict:
        import dataclasses
        return {
            "target":    self.target,
            "timestamp": self.timestamp,
            "risk_score": dataclasses.asdict(self.risk_score) if self.risk_score else None,
            "attack_graph": self.attack_graph.to_dict() if self.attack_graph else None,
            "correlated_findings": [
                {
                    "id":         cf.finding_id,
                    "title":      cf.title,
                    "risk":       cf.risk_level.value,
                    "confidence": cf.confidence.score,
                    "sources":    cf.sources,
                    "tags":       cf.tags,
                    "cves":       cf.cves,
                    "remediation": cf.remediation,
                    "evidence":   cf.evidence,
                }
                for cf in self.correlated_findings
            ],
            "classified_assets": [
                {
                    "id":      a.identifier,
                    "type":    a.asset_type.value,
                    "risk":    a.risk_level.value,
                    "tech":    a.technologies,
                    "ports":   a.open_ports,
                    "tags":    a.tags,
                }
                for a in self.classified_assets
            ],
            "recommendations": [
                {
                    "priority":   r.priority,
                    "title":      r.title,
                    "action":     r.action,
                    "effort":     r.effort,
                    "risk":       r.risk_level.value,
                    "context":    r.context,
                }
                for r in self.recommendations
            ],
            "anomalies":  self.anomalies,
            "stats":      self.stats,
            "summary":    self.executive_summary,
        }
