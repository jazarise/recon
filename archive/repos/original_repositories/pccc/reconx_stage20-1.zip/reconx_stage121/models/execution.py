"""
ReconX — Execution data models.
Tracks tool run state, batch status, and final summaries.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional


class ToolStatus(str, Enum):
    PENDING   = "pending"
    RUNNING   = "running"
    SUCCESS   = "success"
    FAILED    = "failed"
    TIMEOUT   = "timeout"
    SKIPPED   = "skipped"    # binary not available
    DUPLICATE = "duplicate"  # already ran this session


class FailureReason(str, Enum):
    NOT_INSTALLED  = "not_installed"
    TIMEOUT        = "timeout"
    EXCEPTION      = "exception"
    BAD_OUTPUT     = "bad_output"
    DEPENDENCY_MISSING = "dependency_missing"
    INTERRUPTED    = "interrupted"


@dataclass
class ToolExecutionResult:
    """Result of a single tool invocation."""
    tool_name:    str
    status:       ToolStatus         = ToolStatus.PENDING
    duration_s:   float              = 0.0
    output:       Optional[dict]     = None        # parsed tool output
    raw_stdout:   str                = ""
    raw_stderr:   str                = ""
    failure_reason: Optional[FailureReason] = None
    error_detail: str                = ""
    retries_used: int                = 0

    # Convenience helpers
    @property
    def succeeded(self) -> bool:
        return self.status == ToolStatus.SUCCESS

    @property
    def icon(self) -> str:
        return {
            ToolStatus.SUCCESS:   "✔",
            ToolStatus.FAILED:    "✖",
            ToolStatus.TIMEOUT:   "⏱",
            ToolStatus.SKIPPED:   "○",
            ToolStatus.DUPLICATE: "◈",
            ToolStatus.RUNNING:   "◌",
            ToolStatus.PENDING:   "·",
        }[self.status]

    @property
    def style(self) -> str:
        return {
            ToolStatus.SUCCESS:   "bold green",
            ToolStatus.FAILED:    "bold red",
            ToolStatus.TIMEOUT:   "yellow",
            ToolStatus.SKIPPED:   "dim",
            ToolStatus.DUPLICATE: "dim cyan",
            ToolStatus.RUNNING:   "cyan",
            ToolStatus.PENDING:   "dim",
        }[self.status]


@dataclass
class BatchResult:
    """Result of executing one batch of tools."""
    batch_index:  int
    batch_label:  str                           = ""
    stage:        int                           = 0
    tools:        list[ToolExecutionResult]     = field(default_factory=list)
    started_at:   float                         = 0.0
    finished_at:  float                         = 0.0

    @property
    def duration_s(self) -> float:
        return max(0.0, self.finished_at - self.started_at)

    @property
    def success_count(self)  -> int: return sum(1 for t in self.tools if t.status == ToolStatus.SUCCESS)
    @property
    def failed_count(self)   -> int: return sum(1 for t in self.tools if t.status == ToolStatus.FAILED)
    @property
    def timeout_count(self)  -> int: return sum(1 for t in self.tools if t.status == ToolStatus.TIMEOUT)
    @property
    def skipped_count(self)  -> int: return sum(1 for t in self.tools if t.status == ToolStatus.SKIPPED)


@dataclass
class ExecutionSummary:
    """Aggregated summary over all batches in a run."""
    target:      str
    mode:        str
    batches:     list[BatchResult]  = field(default_factory=list)
    total_time_s: float             = 0.0

    # ── Aggregated counts ─────────────────────────────────────────────────────
    @property
    def total(self)    -> int: return sum(len(b.tools) for b in self.batches)
    @property
    def succeeded(self)-> int: return sum(b.success_count  for b in self.batches)
    @property
    def failed(self)   -> int: return sum(b.failed_count   for b in self.batches)
    @property
    def timed_out(self)-> int: return sum(b.timeout_count  for b in self.batches)
    @property
    def skipped(self)  -> int: return sum(b.skipped_count  for b in self.batches)

    def all_results(self) -> list[ToolExecutionResult]:
        return [t for b in self.batches for t in b.tools]
