"""
ReconX — Burp CLI Command Handler (Stage 18.1)

Implements the 'reconx burp' subcommand group.

Commands:
    reconx burp status
    reconx burp start <target>
    reconx burp stop
    reconx burp sessions [--target <host>]
    reconx burp replay <session_id> [--request-id ID] [--sequence]

Integration:
    Called from reconx/__main__.py or cli/interactive.py when the
    user selects a Burp-related action.

Design:
    - Thin CLI layer only — all logic in BurpIntelligenceLayer
    - Rich-formatted output for all commands
    - Never raises; prints error panels on failure
    - Graceful degradation when Burp is not running
"""
from __future__ import annotations

import logging
from typing import Optional

from rich import box
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

logger = logging.getLogger("reconx.cli.burp")


def _make_layer(console: Console):
    """Lazily instantiate BurpIntelligenceLayer with error handling."""
    try:
        from ..integrations.burp import BurpIntelligenceLayer
        return BurpIntelligenceLayer()
    except Exception as exc:
        console.print(Panel(
            f"[red]Could not load Burp integration:[/red] {exc}",
            border_style="red",
            title="Burp Error",
        ))
        return None


# ══════════════════════════════════════════════════════════════════════════════
# Command handlers
# ══════════════════════════════════════════════════════════════════════════════

def cmd_status(console: Console) -> None:
    """reconx burp status — show Burp API and proxy health."""
    layer = _make_layer(console)
    if not layer:
        return

    status = layer.get_status()

    tbl = Table(
        title="🌐 Burp Suite Status",
        border_style="cyan",
        box=box.ROUNDED,
        show_header=False,
    )
    tbl.add_column("Key",   style="dim",   width=22)
    tbl.add_column("Value", style="white")

    api_txt = Text("✓ connected", style="bold green") if status["api_reachable"] \
              else Text("✗ not reachable", style="bold red")
    proxy_txt = Text("⚡ running", style="bold cyan") if status["proxy_running"] \
                else Text("⏸ idle", style="dim")

    tbl.add_row("API Status",      api_txt)
    tbl.add_row("API URL",         status.get("api_url", "—"))
    tbl.add_row("API Key Set",     "Yes" if status.get("api_key_set") else "No")
    tbl.add_row("Proxy",           proxy_txt)
    tbl.add_row("Proxy URL",       status.get("proxy_url", "—"))
    tbl.add_row("Intercept",       "On" if status.get("intercept_on") else "Off")
    tbl.add_row("Current Session", status.get("current_session") or "—")
    tbl.add_row("Session State",   status.get("session_state", "—"))
    tbl.add_row("Current Project", status.get("current_project") or "—")
    tbl.add_row("Burp Version",    status.get("burp_version", "—"))

    if status.get("proxy_error"):
        tbl.add_row("[red]Proxy Error[/red]", f"[red]{status['proxy_error'][:80]}[/red]")

    console.print(tbl)

    if not status["api_reachable"]:
        console.print(Panel(
            "[yellow]Burp Suite is not reachable.\n\n"
            "Fix steps:\n"
            "  1. Start Burp Suite Professional\n"
            "  2. Enable REST API: Settings → Suite → REST API → Service running\n"
            "  3. Set [bold]RECONX_BURP_API_KEY[/bold] if API key is required",
            border_style="yellow",
            title="Setup Required",
        ))


def cmd_start(console: Console, target: str) -> None:
    """reconx burp start <target> — start a capture session."""
    layer = _make_layer(console)
    if not layer:
        return

    console.print(f"[cyan]Starting Burp capture session for:[/cyan] [bold]{target}[/bold]")

    session, err = layer.start_session(target)
    if err or session is None:
        console.print(Panel(
            f"[red]Failed to start session:[/red] {err}",
            border_style="red",
        ))
        return

    console.print(Panel(
        f"[bold green]✓ Session started[/bold green]\n\n"
        f"  Session ID:    [cyan]{session.short_id}[/cyan]\n"
        f"  Target:        [yellow]{session.target}[/yellow]\n"
        f"  Proxy:         [cyan]{layer.get_proxy_config().proxy_url}[/cyan]\n\n"
        f"[dim]Traffic routed through Burp proxy is now being captured.\n"
        f"Configure your browser or tool to use the proxy URL above.\n"
        f"Run [bold]reconx burp stop[/bold] when done.[/dim]",
        border_style="green",
        title="Burp Session Active",
    ))


def cmd_stop(console: Console) -> None:
    """reconx burp stop — stop the current capture session."""
    layer = _make_layer(console)
    if not layer:
        return

    console.print("[cyan]Stopping capture session and collecting traffic…[/cyan]")

    session, err = layer.stop_session()
    if err and not session:
        console.print(Panel(f"[red]Stop failed:[/red] {err}", border_style="red"))
        return

    if session:
        traffic = session.traffic_summary or {}
        console.print(Panel(
            f"[bold green]✓ Session stopped[/bold green]\n\n"
            f"  Session ID:   [cyan]{session.short_id}[/cyan]\n"
            f"  Duration:     [yellow]{session.duration_s:.1f}s[/yellow]\n"
            f"  Requests:     [white]{traffic.get('total_requests', 0)}[/white]\n"
            f"  Endpoints:    [white]{len(traffic.get('endpoints', []))}[/white]\n"
            f"  Auth tokens:  [white]{len(traffic.get('auth_tokens', []))}[/white]\n"
            f"  Issues:       [white]{len(traffic.get('security_issues', []))}[/white]\n\n"
            f"[dim]Replay with: reconx burp replay {session.short_id}[/dim]",
            border_style="green",
            title="Session Complete",
        ))
    else:
        console.print("[yellow]No active session was found.[/yellow]")


def cmd_sessions(
    console: Console,
    target:  Optional[str] = None,
) -> None:
    """reconx burp sessions [--target <host>] — list recorded sessions."""
    layer = _make_layer(console)
    if not layer:
        return

    sessions = layer.list_sessions(target=target)

    if not sessions:
        label = f" for {target}" if target else ""
        console.print(f"[dim]No sessions found{label}.[/dim]")
        return

    tbl = Table(
        title=f"📋 Burp Sessions" + (f" — {target}" if target else ""),
        border_style="cyan",
        box=box.SIMPLE_HEAVY,
    )
    tbl.add_column("ID",       style="cyan",   width=10)
    tbl.add_column("Target",   style="yellow", max_width=30)
    tbl.add_column("State",    style="white",  width=10)
    tbl.add_column("Requests", style="white",  width=10, justify="right")
    tbl.add_column("Duration", style="dim",    width=10)
    tbl.add_column("Started",  style="dim",    width=18)

    _state_colour = {
        "active":  "green",  "resumed": "cyan",
        "paused":  "yellow", "stopped": "dim",
        "error":   "red",
    }

    import datetime
    for s in sessions[:30]:
        traffic  = s.traffic_summary or {}
        state_c  = _state_colour.get(s.state, "white")
        started  = datetime.datetime.fromtimestamp(s.started_at).strftime("%Y-%m-%d %H:%M")
        tbl.add_row(
            s.short_id,
            s.target[:30],
            Text(s.state, style=state_c),
            str(traffic.get("total_requests", len(s.item_ids))),
            f"{s.duration_s:.1f}s",
            started,
        )

    console.print(tbl)


def cmd_replay(
    console:    Console,
    session_id: str,
    request_id: Optional[str] = None,
    sequence:   bool = False,
    delay_s:    float = 0.5,
) -> None:
    """reconx burp replay <session_id> [--request-id ID] [--sequence]"""
    layer = _make_layer(console)
    if not layer:
        return

    mode = "single" if request_id else ("sequence" if sequence else "workflow")
    console.print(
        f"[cyan]Replaying session[/cyan] [bold]{session_id}[/bold] "
        f"[dim](mode: {mode})[/dim]"
    )

    report = layer.replay(
        session_id=session_id,
        request_id=request_id,
        sequence=sequence,
    )

    if report.error:
        console.print(Panel(
            f"[red]Replay failed:[/red] {report.error}",
            border_style="red",
        ))
        return

    # Summary panel
    colour = "green" if report.failed == 0 else "yellow"
    console.print(Panel(
        f"[bold]Replay complete[/bold]\n\n"
        f"  Mode:         [cyan]{report.mode}[/cyan]\n"
        f"  Total:        [white]{report.total}[/white]\n"
        f"  Succeeded:    [green]{report.succeeded}[/green]\n"
        f"  Failed:       [red]{report.failed}[/red]\n"
        f"  Success rate: [yellow]{report.success_rate:.1f}%[/yellow]\n"
        f"  Duration:     [dim]{report.duration_s:.1f}s[/dim]",
        border_style=colour,
        title="Replay Report",
    ))

    # Results table (first 20)
    if report.results:
        tbl = Table(border_style="dim", box=box.SIMPLE, show_header=True)
        tbl.add_column("ID",     style="dim",   width=10)
        tbl.add_column("Method", style="yellow",width=8)
        tbl.add_column("URL",    style="white", max_width=60)
        tbl.add_column("Status", style="cyan",  width=7)
        tbl.add_column("OK",     width=4)

        for r in report.results[:20]:
            tbl.add_row(
                r.request_id[:8],
                r.method or "—",
                r.url[:60] or "—",
                str(r.status_code) if r.status_code else "—",
                "[green]✓[/green]" if r.success else "[red]✗[/red]",
            )
        console.print(tbl)


# ══════════════════════════════════════════════════════════════════════════════
# Unified dispatcher (called from __main__ or interactive CLI)
# ══════════════════════════════════════════════════════════════════════════════

def dispatch_burp_command(
    args:    list[str],
    console: Optional[Console] = None,
) -> None:
    """
    Dispatch a 'reconx burp ...' command from parsed CLI args.

    Args:
        args:    Remaining args after 'burp' (e.g. ["start", "example.com"])
        console: Rich console (created if None)
    """
    console = console or Console()

    if not args:
        _print_burp_help(console)
        return

    cmd = args[0].lower()

    if cmd == "status":
        cmd_status(console)

    elif cmd == "start":
        target = args[1] if len(args) > 1 else ""
        if not target:
            console.print("[red]Usage: reconx burp start <target>[/red]")
            return
        cmd_start(console, target)

    elif cmd == "stop":
        cmd_stop(console)

    elif cmd in ("sessions", "list"):
        target = None
        if "--target" in args:
            idx = args.index("--target")
            target = args[idx + 1] if idx + 1 < len(args) else None
        cmd_sessions(console, target=target)

    elif cmd == "replay":
        if len(args) < 2:
            console.print("[red]Usage: reconx burp replay <session_id>[/red]")
            return
        session_id = args[1]
        request_id = None
        sequence   = "--sequence" in args
        if "--request-id" in args:
            idx = args.index("--request-id")
            request_id = args[idx + 1] if idx + 1 < len(args) else None
        cmd_replay(console, session_id, request_id=request_id, sequence=sequence)

    else:
        console.print(f"[red]Unknown burp command:[/red] {cmd}")
        _print_burp_help(console)


def _print_burp_help(console: Console) -> None:
    console.print(Panel(
        "[bold cyan]reconx burp[/bold cyan] — Burp Suite Intelligence Layer\n\n"
        "  [yellow]reconx burp status[/yellow]                     Show Burp connection status\n"
        "  [yellow]reconx burp start <target>[/yellow]              Start a capture session\n"
        "  [yellow]reconx burp stop[/yellow]                        Stop the current session\n"
        "  [yellow]reconx burp sessions[/yellow]                    List all sessions\n"
        "  [yellow]reconx burp sessions --target example.com[/yellow]  Filter by target\n"
        "  [yellow]reconx burp replay <session_id>[/yellow]         Replay full session\n"
        "  [yellow]reconx burp replay <id> --request-id <rid>[/yellow]  Replay one request\n"
        "  [yellow]reconx burp replay <id> --sequence[/yellow]      Replay in order",
        border_style="cyan",
        title="Burp CLI Help",
    ))
