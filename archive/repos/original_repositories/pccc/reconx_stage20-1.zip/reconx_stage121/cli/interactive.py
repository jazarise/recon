"""
ReconX — Interactive Learning Mode CLI.
Red-dark aggressive theme. Fully YAML-driven — no hardcoded tool details.

Flow:
  reconx learn
    → Category menu
      → Tool list
        → Tool detail panel
          → [Run Tool] or [Back]
"""
from __future__ import annotations
import logging
import sys
from typing import Optional

from rich import box
from rich.align import Align
from rich.columns import Columns
from rich.console import Console
from rich.panel import Panel
from rich.prompt import Prompt
from rich.rule import Rule
from rich.table import Table
from rich.text import Text

from ..cli.categories import CATEGORIES, list_categories, get_tools_for_category
from ..knowledge.loader import load_tool, available_slugs

logger = logging.getLogger("reconx.cli.learn")

console = Console()

# ── Palette ───────────────────────────────────────────────────────────────────
C_HEAD    = "bold red"
C_ACCENT  = "red"
C_DIM     = "dim red"
C_LABEL   = "red3"
C_OK      = "bold green"
C_WARN    = "yellow"
C_MUTED   = "dim"
C_BORDER  = "red"
C_SELECT  = "bold bright_red"


# ══════════════════════════════════════════════════════════════════════════════
#  Helpers
# ══════════════════════════════════════════════════════════════════════════════

def _rule(title: str = "") -> None:
    console.print(Rule(title, style=C_ACCENT))


def _header(text: str) -> None:
    console.print()
    console.print(Align.center(f"[{C_HEAD}]  {text}  [/{C_HEAD}]"))
    console.print()


def _prompt(msg: str, choices: list[str] | None = None,
            default: str = "") -> str:
    try:
        return Prompt.ask(
            f"[{C_SELECT}]▶[/{C_SELECT}] [{C_ACCENT}]{msg}[/{C_ACCENT}]",
            choices=choices,
            default=default,
            console=console,
        ).strip()
    except (KeyboardInterrupt, EOFError):
        console.print(f"\n[{C_MUTED}]Exiting learn mode.[/{C_MUTED}]")
        sys.exit(0)


def _numbered_table(rows: list[tuple[str, str]],
                    title: str = "",
                    col1: str = "#",
                    col2: str = "NAME",
                    col3: str = "DESCRIPTION") -> None:
    t = Table(
        box=box.SIMPLE_HEAD,
        show_edge=False,
        border_style=C_DIM,
        header_style=C_HEAD,
        padding=(0, 2),
        title=f"[{C_HEAD}]{title}[/{C_HEAD}]" if title else None,
    )
    t.add_column(col1, style=C_DIM, width=4,   no_wrap=True)
    t.add_column(col2, style=C_ACCENT, width=18, no_wrap=True)
    t.add_column(col3, style=C_MUTED)

    for i, (name, desc) in enumerate(rows, 1):
        t.add_row(f"[{C_HEAD}]{i}[/{C_HEAD}]", name, desc)

    console.print(t)


# ══════════════════════════════════════════════════════════════════════════════
#  Tool detail renderer
# ══════════════════════════════════════════════════════════════════════════════

def _render_tool(data: dict) -> None:
    """Render a full tool knowledge card using Rich panels."""
    name     = data.get("name", "unknown")
    category = data.get("category", "")
    desc     = data.get("description", "").strip()
    command  = data.get("command", "")
    how      = data.get("how_it_works", "").strip()
    cases    = data.get("use_cases", [])
    integs   = data.get("integrations", [])
    tips     = data.get("tips", [])
    errors   = data.get("common_errors", [])

    console.print()
    _rule(f"  {name.upper()}  ")
    console.print()

    # ── Header bar ────────────────────────────────────────────────────────────
    console.print(
        Panel(
            f"[{C_HEAD}]{name.upper()}[/{C_HEAD}]  [{C_DIM}][{category}][/{C_DIM}]\n\n"
            f"[white]{desc}[/white]",
            border_style=C_BORDER,
            padding=(1, 3),
        )
    )

    # ── Command ───────────────────────────────────────────────────────────────
    console.print(
        Panel(
            f"[{C_OK}]{command}[/{C_OK}]",
            title=f"[{C_HEAD}]● COMMAND[/{C_HEAD}]",
            border_style=C_ACCENT,
            padding=(0, 2),
        )
    )

    # ── Two-column: Use cases + How it works ──────────────────────────────────
    uc_text = "\n".join(f"[{C_DIM}]▸[/{C_DIM}] [{C_MUTED}]{c}[/{C_MUTED}]"
                        for c in cases) or f"[{C_MUTED}]—[/{C_MUTED}]"
    how_text = f"[{C_MUTED}]{how}[/{C_MUTED}]"

    console.print(Columns([
        Panel(uc_text,
              title=f"[{C_HEAD}]USE CASES[/{C_HEAD}]",
              border_style=C_DIM, padding=(1, 2), expand=True),
        Panel(how_text,
              title=f"[{C_HEAD}]HOW IT WORKS[/{C_HEAD}]",
              border_style=C_DIM, padding=(1, 2), expand=True),
    ], equal=True, expand=True))

    # ── Integrations ──────────────────────────────────────────────────────────
    if integs:
        integ_text = "\n".join(
            f"[{C_ACCENT}]⟶[/{C_ACCENT}] [{C_MUTED}]{i}[/{C_MUTED}]"
            for i in integs
        )
        console.print(Panel(
            integ_text,
            title=f"[{C_HEAD}]RECONX INTEGRATIONS[/{C_HEAD}]",
            border_style=C_DIM, padding=(1, 2),
        ))

    # ── Tips ──────────────────────────────────────────────────────────────────
    if tips:
        tips_text = "\n".join(
            f"[yellow]★[/yellow] [{C_MUTED}]{t}[/{C_MUTED}]"
            for t in tips
        )
        console.print(Panel(
            tips_text,
            title=f"[{C_HEAD}]PRO TIPS[/{C_HEAD}]",
            border_style="yellow", padding=(1, 2),
        ))

    # ── Common errors table ───────────────────────────────────────────────────
    if errors:
        err_table = Table(
            box=box.SIMPLE_HEAD,
            show_edge=False,
            border_style=C_DIM,
            header_style=C_HEAD,
            padding=(0, 2),
        )
        err_table.add_column("ERROR",  style="red",  no_wrap=False, max_width=40)
        err_table.add_column("FIX",    style=C_OK,   no_wrap=False)

        for e in errors:
            err_table.add_row(
                str(e.get("error", "")),
                str(e.get("fix", "")),
            )

        console.print(Panel(
            err_table,
            title=f"[{C_HEAD}]COMMON ERRORS & FIXES[/{C_HEAD}]",
            border_style="red", padding=(1, 1),
        ))

    console.print()


# ══════════════════════════════════════════════════════════════════════════════
#  Run-tool integration
# ══════════════════════════════════════════════════════════════════════════════

def _run_tool_prompt(tool_slug: str) -> None:
    """Ask for a target then delegate to ExecutionEngine."""
    console.print()
    console.print(Panel(
        f"[{C_MUTED}]Running [bold]{tool_slug}[/bold] via ReconX engine.[/{C_MUTED}]\n"
        f"[{C_MUTED}]This will execute the tool against the specified target.[/{C_MUTED}]",
        border_style=C_ACCENT, padding=(1, 2),
    ))

    target = _prompt("Enter target (IP or hostname)")
    if not target:
        console.print(f"[{C_WARN}]No target entered — returning to menu.[/{C_WARN}]")
        return

    try:
        from ..engine.executor import ExecutionEngine
        engine = ExecutionEngine(mode="fast", console=console)
        console.print(f"\n[{C_HEAD}]Launching scan against [bold]{target}[/bold]...[/{C_HEAD}]\n")
        result, _summary = engine.run_tools([tool_slug], target)

        # Mini summary
        _rule("SCAN COMPLETE")
        console.print(f"  [{C_OK}]Open ports:[/{C_OK}]  {len(result.ports)}")
        console.print(f"  [{C_OK}]Subdomains:[/{C_OK}]  {len(result.subdomains)}")
        console.print(f"  [{C_OK}]CVE matches:[/{C_OK}] {len(result.cve_matches)}")
        console.print(f"  [{C_OK}]Risk score:[/{C_OK}]  "
                      f"{result.risk_score.total if result.risk_score else 'N/A'}"
                      f" (grade: {result.risk_score.grade if result.risk_score else '—'})")
        console.print()

    except Exception as exc:
        console.print(f"[red]Engine error: {exc}[/red]")
        logger.exception("Engine error from learn mode")


# ══════════════════════════════════════════════════════════════════════════════
#  Navigation
# ══════════════════════════════════════════════════════════════════════════════

def _tool_detail_menu(slug: str) -> None:
    """Show tool details and offer Run / Back."""
    data = load_tool(slug)
    if not data:
        console.print(Panel(
            f"[yellow]No knowledge file found for [bold]{slug}[/bold].\n"
            f"Create [bold]knowledge/tools/{slug}.yaml[/bold] to add it.[/yellow]",
            border_style="yellow",
        ))
        _prompt("Press Enter to go back", default="")
        return

    _render_tool(data)

    # Action menu
    action_table = Table(box=box.SIMPLE, show_header=False,
                         show_edge=False, padding=(0, 3))
    action_table.add_column(style=C_HEAD,  width=4)
    action_table.add_column(style=C_MUTED)
    action_table.add_row("[1]", "Run Tool against a target")
    action_table.add_row("[2]", "Back to tool list")
    action_table.add_row("[0]", "Main menu")
    console.print(action_table)

    choice = _prompt("Action", choices=["1", "2", "0"], default="2")
    if choice == "1":
        _run_tool_prompt(slug)
    elif choice == "0":
        return  # caller will handle exit back to main


def _tool_list_menu(category_key: str) -> None:
    """Show all tools in a category; navigate into tool detail."""
    meta  = CATEGORIES[category_key]
    tools = get_tools_for_category(category_key)
    known = available_slugs()

    _header(f"{meta['icon']}  {meta['label'].upper()}")
    console.print(f"  [{C_MUTED}]{meta['description']}[/{C_MUTED}]\n")

    if not tools:
        console.print(f"  [{C_WARN}]No tools defined for this category yet.[/{C_WARN}]")
        _prompt("Press Enter to go back", default="")
        return

    rows = []
    for t in tools:
        data = load_tool(t)
        desc = data["description"].split(".")[0].strip() if data else "[dim]knowledge coming soon[/dim]"
        status = f"[{C_OK}]●[/{C_OK}]" if t in known else f"[{C_DIM}]○[/{C_DIM}]"
        rows.append((f"{status} {t}", desc))

    _numbered_table(rows, col2="TOOL", col3="DESCRIPTION")

    valid_choices = [str(i) for i in range(1, len(tools) + 1)] + ["0"]
    console.print(f"  [{C_DIM}][0] ← Back to categories[/{C_DIM}]\n")

    while True:
        choice = _prompt(f"Select tool (1–{len(tools)}) or 0 to go back",
                         default="0")
        if choice == "0":
            return
        if choice.isdigit() and 1 <= int(choice) <= len(tools):
            selected_slug = tools[int(choice) - 1]
            _tool_detail_menu(selected_slug)
            # Re-render the list after returning from detail
            console.clear()
            _header(f"{meta['icon']}  {meta['label'].upper()}")
            _numbered_table(rows, col2="TOOL", col3="DESCRIPTION")
            console.print(f"  [{C_DIM}][0] ← Back to categories[/{C_DIM}]\n")
        else:
            console.print(f"  [{C_WARN}]Invalid selection — enter a number between 1 and {len(tools)}.[/{C_WARN}]")


def _category_menu() -> None:
    """Top-level category selection loop."""
    cats = list_categories()

    while True:
        console.clear()

        # Category table
        _rule("  LEARN MODE — SELECT CATEGORY  ")
        console.print()

        t = Table(
            box=box.SIMPLE_HEAD,
            show_edge=False,
            border_style=C_DIM,
            header_style=C_HEAD,
            padding=(0, 3),
        )
        t.add_column("#",    style=C_HEAD, width=4,  no_wrap=True)
        t.add_column("ICON", style="",     width=4,  no_wrap=True)
        t.add_column("CATEGORY",    style=C_ACCENT,  width=24)
        t.add_column("TOOLS",       style=C_MUTED,   width=40)

        for i, (key, meta) in enumerate(cats, 1):
            tool_list = ", ".join(meta["tools"][:4])
            if len(meta["tools"]) > 4:
                tool_list += f" +{len(meta['tools'])-4}"
            t.add_row(
                f"[{C_HEAD}]{i}[/{C_HEAD}]",
                meta["icon"],
                f"[{C_ACCENT}]{meta['label']}[/{C_ACCENT}]",
                f"[{C_MUTED}]{tool_list}[/{C_MUTED}]",
            )

        console.print(t)
        console.print(f"\n  [{C_DIM}][0] Exit learn mode[/{C_DIM}]\n")

        valid = [str(i) for i in range(1, len(cats) + 1)] + ["0"]
        choice = _prompt(f"Select category (1–{len(cats)}) or 0 to exit")

        if choice == "0":
            console.print(f"\n[{C_MUTED}]Returning to main menu.[/{C_MUTED}]\n")
            return
        if choice.isdigit() and 1 <= int(choice) <= len(cats):
            key = cats[int(choice) - 1][0]
            _tool_list_menu(key)
        else:
            console.print(f"  [{C_WARN}]Enter a number between 0 and {len(cats)}.[/{C_WARN}]")
            import time; time.sleep(0.8)


# ══════════════════════════════════════════════════════════════════════════════
#  Public entry point
# ══════════════════════════════════════════════════════════════════════════════

def launch_learn_mode() -> None:
    """Entry point called from __main__.py when 'learn' subcommand is used."""
    try:
        _category_menu()
    except (KeyboardInterrupt, EOFError):
        console.print(f"\n[{C_MUTED}]Learn mode exited.[/{C_MUTED}]\n")
