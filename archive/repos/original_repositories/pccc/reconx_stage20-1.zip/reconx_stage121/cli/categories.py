"""
ReconX — Tool categories registry.
Each category maps to a list of tool knowledge file slugs.
"""
from __future__ import annotations

CATEGORIES: dict[str, dict] = {
    "passive": {
        "label": "Passive Reconnaissance",
        "icon": "👁",
        "description": "Gather intel without touching the target directly.",
        "tools": ["whois", "shodan", "theHarvester"],
        "color": "red",
    },
    "dns": {
        "label": "DNS Enumeration",
        "icon": "🌐",
        "description": "Probe DNS records, zone transfers and misconfigs.",
        "tools": ["dnsx", "massdns", "puredns", "shuffledns"],
        "color": "bright_red",
    },
    "subdomain": {
        "label": "Subdomain Discovery",
        "icon": "🔍",
        "description": "Enumerate subdomains via passive and active sources.",
        "tools": ["subfinder", "amass", "assetfinder", "findomain", "crtsh", "chaos"],
        "color": "red1",
    },
    "scanning": {
        "label": "Port & Service Scanning",
        "icon": "📡",
        "description": "Discover open ports, services and OS fingerprints.",
        "tools": ["rustscan", "naabu", "nmap", "masscan"],
        "color": "bold red",
    },
    "web": {
        "label": "Web Analysis",
        "icon": "🕸",
        "description": "Fingerprint web stacks, probe HTTP, detect technologies.",
        "tools": ["httpx", "whatweb", "wafw00f"],
        "color": "dark_red",
    },
    "url": {
        "label": "URL & Path Discovery",
        "icon": "🔗",
        "description": "Crawl and fuzz paths, endpoints and parameters.",
        "tools": ["katana", "hakrawler", "ffuf", "gobuster", "dirsearch", "gau", "waybackurls"],
        "color": "red3",
    },
    "vuln": {
        "label": "Vulnerability Detection",
        "icon": "⚠",
        "description": "Identify CVEs, misconfigs and exploitable weaknesses.",
        "tools": ["nuclei", "nikto", "sqlmap"],
        "color": "bold red",
    },
    "cloud": {
        "label": "Cloud & S3 Recon",
        "icon": "☁",
        "description": "Discover exposed buckets, cloud assets and misconfigs.",
        "tools": ["s3scanner", "cloudbrute", "awsbucketdump"],
        "color": "red",
    },
}


def list_categories() -> list[tuple[str, dict]]:
    """Return ordered (key, meta) list."""
    return list(CATEGORIES.items())


def get_tools_for_category(key: str) -> list[str]:
    return CATEGORIES.get(key, {}).get("tools", [])
