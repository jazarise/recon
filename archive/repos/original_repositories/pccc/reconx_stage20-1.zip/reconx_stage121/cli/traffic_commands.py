"""
ReconX — Traffic Intelligence CLI Commands (Stage 18.2)

Implements:
    reconx pcap analyze <file.pcap>
    reconx traffic live [--iface eth0] [--duration 30]
    reconx traffic interfaces
    reconx traffic status
"""
from __future__ import annotations

import logging
from typing import Optional

from rich import box
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

logger = logging.getLogger("reconx.cli.traffic")


def _make_tool(console: Console):
    try:
        from ..network import TrafficIntelligenceTool
        return TrafficIntelligenceTool()
    except Exception as exc:
        console.print(Panel(f"[red]Could not load Traffic Intelligence:[/red] {exc}",
                            border_style="red"))
        return None


# ── reconx pcap analyze <file> ────────────────────────────────────────────────

def cmd_pcap_analyze(console: Console, pcap_path: str, display_filter: str = "") -> None:
    tool = _make_tool(console)
    if not tool:
        return

    console.print(f"[cyan]Analyzing PCAP:[/cyan] [bold]{pcap_path}[/bold]")
    from ..network.pcap_parser import PCAPParser
    parser  = PCAPParser()
    summary, err = parser.analyze(pcap_path, display_filter=display_filter)

    if err and not summary.total_packets:
        console.print(Panel(f"[red]Analysis failed:[/red] {err}", border_style="red"))
        return

    from ..tui.views.traffic_view import TrafficIntelligencePanel
    TrafficIntelligencePanel().render(
        console, summary=summary, state="complete",
        interface=pcap_path, duration_s=int(summary.duration_s),
    )

    # Report high-severity findings
    high_anomalies = [a for a in summary.anomalies if a.severity.value in ("HIGH", "CRITICAL")]
    if high_anomalies:
        console.print(Panel(
            "\n".join(f"  [red]⚠[/red] {a.summary()}" for a in high_anomalies[:5]),
            title="[bold red]High Severity Alerts[/bold red]", border_style="red",
        ))
    if summary.credentials:
        console.print(Panel(
            "\n".join(f"  {c.display()}" for c in summary.credentials[:5]),
            title="[bold yellow]Credential Findings (masked)[/bold yellow]",
            border_style="yellow",
        ))


# ── reconx traffic live ───────────────────────────────────────────────────────

def cmd_traffic_live(
    console: Console,
    iface:   str = "",
    duration_s: int = 30,
    display_filter: str = "",
) -> None:
    from ..network.live_capture import LiveCaptureEngine
    engine = LiveCaptureEngine()

    if not iface:
        iface = engine.get_default_interface()

    console.print(Panel(
        f"[cyan]Interface:[/cyan] [bold]{iface}[/bold]   "
        f"[cyan]Duration:[/cyan] [bold]{duration_s}s[/bold]   "
        f"[dim]Press Ctrl+C to stop early[/dim]",
        title="[bold cyan]Live Traffic Capture[/bold cyan]",
        border_style="cyan",
    ))

    import time
    t0 = time.time()
    with console.status(f"[cyan]Capturing on {iface}…[/cyan]"):
        session = engine.start(interface=iface, duration_s=duration_s,
                               display_filter=display_filter)

    if session.state == "error":
        console.print(Panel(
            f"[red]Capture failed:[/red] {session.error}\n\n"
            f"[yellow]Fix:[/yellow] sudo setcap cap_net_raw,cap_net_admin=eip /usr/bin/dumpcap",
            border_style="red",
        ))
        return

    summary = session.summary
    from ..tui.views.traffic_view import TrafficIntelligencePanel
    TrafficIntelligencePanel().render(
        console, summary=summary, state="complete",
        interface=iface, duration_s=session.duration_s,
    )


# ── reconx traffic interfaces ─────────────────────────────────────────────────

def cmd_traffic_interfaces(console: Console) -> None:
    from ..network.live_capture import LiveCaptureEngine
    engine = LiveCaptureEngine()
    ifaces, err = engine.list_interfaces()

    if err:
        console.print(Panel(
            f"[red]Could not list interfaces:[/red] {err}\n\n"
            f"[yellow]Install tshark:[/yellow] sudo apt install tshark",
            border_style="red",
        ))
        return

    tbl = Table(title="🌐  Network Interfaces", border_style="cyan", box=box.ROUNDED)
    tbl.add_column("#",    style="dim",   width=4)
    tbl.add_column("Name", style="bold cyan")
    default = engine.get_default_interface()
    for i in ifaces:
        name = i["name"]
        marker = " [green](default)[/green]" if name.startswith(default) else ""
        tbl.add_row(str(i["index"]), name + marker)
    console.print(tbl)


# ── reconx traffic status ─────────────────────────────────────────────────────

def cmd_traffic_status(console: Console) -> None:
    from ..network.tshark_engine import TSharkEngine
    from ..network.pyshark_engine import PySharkEngine

    ts = TSharkEngine()
    ps = PySharkEngine()

    tbl = Table(title="📡  Traffic Intelligence Status", border_style="cyan",
                box=box.ROUNDED, show_header=False)
    tbl.add_column("Component", style="dim",  width=22)
    tbl.add_column("Status",    style="white")

    ts_ok  = ts.available()
    ps_ok  = ps.available()
    ts_ver = ts.version() if ts_ok else ""

    tbl.add_row("TShark",
                Text("✓ " + (ts_ver[:40] or "available"), style="bold green") if ts_ok
                else Text("✗ not found", style="bold red"))
    tbl.add_row("PyShark",
                Text("✓ installed", style="bold green") if ps_ok
                else Text("✗ not installed (optional)", style="dim"))
    tbl.add_row("PCAP analysis",  Text("✓ ready", style="green") if ts_ok else Text("✗ requires tshark", style="red"))
    tbl.add_row("Live capture",   Text("✓ ready", style="green") if ts_ok else Text("✗ requires tshark", style="red"))
    tbl.add_row("Deep scan",      Text("✓ ready", style="green") if ps_ok else Text("⚠ install pyshark", style="yellow"))
    console.print(tbl)

    if not ts_ok:
        console.print(Panel(ts.install_hint(), border_style="yellow", title="Setup Required"))


# ── Unified dispatcher ────────────────────────────────────────────────────────

def dispatch_pcap_command(args: list[str], console: Optional[Console] = None) -> None:
    console = console or Console()
    if not args:
        _print_pcap_help(console); return
    cmd = args[0].lower()
    if cmd == "analyze":
        if len(args) < 2:
            console.print("[red]Usage: reconx pcap analyze <file.pcap>[/red]"); return
        filt = ""
        if "--filter" in args:
            idx  = args.index("--filter")
            filt = args[idx + 1] if idx + 1 < len(args) else ""
        cmd_pcap_analyze(console, args[1], display_filter=filt)
    else:
        console.print(f"[red]Unknown pcap command:[/red] {cmd}")
        _print_pcap_help(console)


def dispatch_traffic_command(args: list[str], console: Optional[Console] = None) -> None:
    console = console or Console()
    if not args:
        _print_traffic_help(console); return
    cmd = args[0].lower()

    if cmd in ("live", "capture"):
        iface    = ""
        duration = 30
        filt     = ""
        if "--iface" in args:
            idx = args.index("--iface"); iface = args[idx+1] if idx+1 < len(args) else ""
        if "--duration" in args:
            idx = args.index("--duration")
            try: duration = int(args[idx+1])
            except (IndexError, ValueError): pass
        if "--filter" in args:
            idx = args.index("--filter"); filt = args[idx+1] if idx+1 < len(args) else ""
        cmd_traffic_live(console, iface=iface, duration_s=duration, display_filter=filt)

    elif cmd == "interfaces":
        cmd_traffic_interfaces(console)
    elif cmd == "status":
        cmd_traffic_status(console)
    else:
        console.print(f"[red]Unknown traffic command:[/red] {cmd}")
        _print_traffic_help(console)


def _print_pcap_help(console: Console) -> None:
    console.print(Panel(
        "[bold cyan]reconx pcap[/bold cyan] — PCAP File Analysis\n\n"
        "  [yellow]reconx pcap analyze <file.pcap>[/yellow]           Full analysis pipeline\n"
        "  [yellow]reconx pcap analyze <file.pcap> --filter dns[/yellow]  With display filter",
        border_style="cyan", title="PCAP Commands",
    ))


def _print_traffic_help(console: Console) -> None:
    console.print(Panel(
        "[bold cyan]reconx traffic[/bold cyan] — Live Traffic Capture\n\n"
        "  [yellow]reconx traffic live[/yellow]                       Auto-detect interface, 30s\n"
        "  [yellow]reconx traffic live --iface eth0[/yellow]           Specific interface\n"
        "  [yellow]reconx traffic live --duration 60[/yellow]          Custom duration\n"
        "  [yellow]reconx traffic live --filter 'port 80'[/yellow]     BPF filter\n"
        "  [yellow]reconx traffic interfaces[/yellow]                  List interfaces\n"
        "  [yellow]reconx traffic status[/yellow]                      Check tool availability",
        border_style="cyan", title="Traffic Commands",
    ))
