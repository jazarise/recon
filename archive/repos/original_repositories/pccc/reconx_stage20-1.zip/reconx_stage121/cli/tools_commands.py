"""
ReconX — Stage 19: CLI Tools Commands

Implements the `reconx tools` subcommand group:

  reconx tools list                    List all registered plugins
  reconx tools list --category network Filter by category
  reconx tools info nmap               Full metadata for one tool
  reconx tools category                List all categories
  reconx tools capabilities            Full capability → tool map
  reconx tools search port_scan        Find tools by capability
  reconx tools health                  Check tool binary availability
  reconx tools health nmap             Health check one tool

Integrates with PluginManager — reads from the Stage 19 registry.
Backward compatible: legacy tools appear alongside Stage 19 plugins.
"""
from __future__ import annotations

import logging
from typing import Optional

from rich import box
from rich.columns import Columns
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

logger = logging.getLogger("reconx.cli.tools19")

# ── Colour palette (matches existing ReconX theme) ────────────────────────────
C  = "red"
CB = "bold red"
CD = "dim red"


def _get_manager():
    """Lazy-import PluginManager to avoid circular imports at module load."""
    from ..core.plugin_manager import get_plugin_manager
    pm = get_plugin_manager()
    if not pm._bootstrapped:
        pm.bootstrap()
    return pm


# ══════════════════════════════════════════════════════════════════════════════
# reconx tools list
# ══════════════════════════════════════════════════════════════════════════════

def cmd_tools_list(console: Console, category: Optional[str] = None) -> None:
    """List all registered plugins with status, category, stage, and capabilities."""
    pm      = _get_manager()
    records = pm.list(category=category)
    stats   = pm.stats()

    title = "Plugin Registry"
    if category:
        title += f" — {category}"

    tbl = Table(
        title=f"[{CB}]{title}[/{CB}]",
        border_style=C,
        box=box.ROUNDED,
        show_lines=False,
    )
    tbl.add_column("",         width=2,  no_wrap=True)
    tbl.add_column("Name",     style="bold white",    min_width=14)
    tbl.add_column("Category", style="cyan",          min_width=12)
    tbl.add_column("Stage",    style="yellow",        width=6, justify="center")
    tbl.add_column("Risk",     width=9)
    tbl.add_column("Passive",  width=8, justify="center")
    tbl.add_column("Installed",width=10, justify="center")
    tbl.add_column("Capabilities", style="dim",       max_width=50)

    _risk_style = {
        "passive":  "bold green",
        "low":      "green",
        "medium":   "yellow",
        "high":     "red",
        "critical": "bold red",
    }

    for r in records:
        m     = r.metadata
        risk  = m.risk_level.value
        caps  = m.capabilities.slugs()
        cap_str = ", ".join(caps[:3]) + (f" +{len(caps)-3}" if len(caps) > 3 else "")

        inst_text = (Text("✓ ready", style="green") if r.available
                     else Text("✗ missing", style="dim red"))

        tbl.add_row(
            r.status_icon(),
            Text(m.name, style="bold white" if not r.is_legacy else "dim white"),
            m.category,
            str(m.stage),
            Text(risk, style=_risk_style.get(risk, "white")),
            "✓" if m.passive else "—",
            inst_text,
            cap_str or "—",
        )

    console.print(tbl)
    console.print(
        f"\n  [{CD}]Total: {stats['total']}  "
        f"Available: {stats['available']}  "
        f"Plugins: {stats['plugins']}  "
        f"Legacy: {stats['legacy']}  "
        f"Categories: {stats['categories']}[/{CD}]\n"
    )


# ══════════════════════════════════════════════════════════════════════════════
# reconx tools info <name>
# ══════════════════════════════════════════════════════════════════════════════

def cmd_tools_info(console: Console, name: str) -> None:
    """Display full metadata for a single tool."""
    pm   = _get_manager()
    info = pm.info(name)

    if not info:
        # Try case-insensitive search
        all_names = [r.metadata.name for r in pm.list()]
        match = next((n for n in all_names if n.lower() == name.lower()), None)
        if match:
            info = pm.info(match)
        if not info:
            console.print(f"[{CB}]Tool not found:[/{CB}] '{name}'")
            console.print(f"[{CD}]Use [bold]reconx tools list[/bold] to see all tools.[/{CD}]")
            return

    # Header
    record = pm.get(info["name"])
    avail  = record.available if record else False
    status = Text("✓ installed", style="bold green") if avail else Text("✗ not installed", style="dim red")

    console.print(Panel(
        f"[bold white]{info['name']}[/bold white]  {status}\n"
        f"[dim]{info['description']}[/dim]",
        border_style=C,
        title=f"[{CB}]Tool Info[/{CB}]",
    ))

    # Metadata table
    meta_tbl = Table(border_style="dim", box=box.SIMPLE, show_header=False)
    meta_tbl.add_column("Field", style="dim", width=18)
    meta_tbl.add_column("Value", style="white")

    fields = [
        ("Category",    f"{info['category']}" + (f" / {info['sub_category']}" if info.get("sub_category") else "")),
        ("Stage",       str(info["stage"])),
        ("Priority",    str(info["priority"])),
        ("Risk Level",  info["risk_level"]),
        ("Passive",     "Yes" if info["passive"] else "No"),
        ("Binary",      info["binary"] or "(none)"),
        ("Install",     info["install_cmd"] or "—"),
        ("Timeout",     f"{info['default_timeout']}s"),
        ("Version",     info["version"]),
        ("Author",      info["author"] or "—"),
        ("Homepage",    info["homepage"] or "—"),
    ]
    for label, value in fields:
        meta_tbl.add_row(label, value)
    console.print(meta_tbl)

    # Permissions
    perms = info.get("permissions", [])
    if perms:
        console.print(f"  [yellow]Permissions:[/yellow] {', '.join(perms)}")

    # Inputs / Outputs
    if info.get("supported_inputs"):
        console.print(f"  [cyan]Inputs:[/cyan]  {', '.join(info['supported_inputs'])}")
    if info.get("supported_outputs"):
        console.print(f"  [cyan]Outputs:[/cyan] {', '.join(info['supported_outputs'])}")

    # Tags
    if info.get("tags"):
        console.print(f"  [{CD}]Tags: {', '.join(info['tags'])}[/{CD}]")

    # Capabilities
    caps = info.get("capabilities", [])
    if caps:
        console.print(f"\n  [bold yellow]Capabilities ({len(caps)}):[/bold yellow]")
        for cap in caps:
            console.print(f"    [{CD}]•[/{CD}] {cap}")

    # Example
    if info.get("example_usage"):
        console.print(Panel(
            f"[green]{info['example_usage']}[/green]",
            title="Example",
            border_style="dim",
            padding=(0, 2),
        ))
    console.print()


# ══════════════════════════════════════════════════════════════════════════════
# reconx tools category
# ══════════════════════════════════════════════════════════════════════════════

def cmd_tools_category(console: Console) -> None:
    """List all available categories with tool counts."""
    pm = _get_manager()

    tbl = Table(
        title=f"[{CB}]Tool Categories[/{CB}]",
        border_style=C, box=box.ROUNDED,
    )
    tbl.add_column("Category", style="bold cyan", min_width=18)
    tbl.add_column("Tools",    style="white",     width=8, justify="right")
    tbl.add_column("Available",style="green",     width=10, justify="right")
    tbl.add_column("Tool Names",style="dim",      max_width=55)

    for cat in pm.all_categories():
        records   = pm.category(cat)
        available = sum(1 for r in records if r.available)
        names     = ", ".join(r.metadata.name for r in records[:5])
        if len(records) > 5:
            names += f" +{len(records)-5}"
        tbl.add_row(cat, str(len(records)), str(available), names)

    console.print(tbl)
    console.print(
        f"\n  [{CD}]Use [bold]reconx tools list --category <name>[/bold] to filter by category.[/{CD}]\n"
    )


# ══════════════════════════════════════════════════════════════════════════════
# reconx tools capabilities
# ══════════════════════════════════════════════════════════════════════════════

def cmd_tools_capabilities(console: Console, filter_tool: Optional[str] = None) -> None:
    """Display the full capability → tool mapping."""
    pm   = _get_manager()
    cmap = pm.capabilities()

    if not cmap:
        console.print(f"[{CD}]No capabilities registered yet.[/{CD}]")
        return

    tbl = Table(
        title=f"[{CB}]Capability Map[/{CB}]",
        border_style=C, box=box.SIMPLE_HEAVY,
    )
    tbl.add_column("Capability",  style="bold yellow", min_width=28)
    tbl.add_column("Tools",       style="cyan",        min_width=10, justify="right")
    tbl.add_column("Provided By", style="white",       max_width=55)

    for cap_slug, tool_names in sorted(cmap.items()):
        if filter_tool and filter_tool.lower() not in [n.lower() for n in tool_names]:
            continue
        tbl.add_row(cap_slug, str(len(tool_names)), ", ".join(tool_names))

    console.print(tbl)

    total_caps  = len(cmap)
    total_tools = len(set(t for tools in cmap.values() for t in tools))
    console.print(
        f"\n  [{CD}]{total_caps} capabilities across {total_tools} tools.[/{CD}]\n"
        f"  [{CD}]Use [bold]reconx tools search <capability>[/bold] to find tools by capability.[/{CD}]\n"
    )


# ══════════════════════════════════════════════════════════════════════════════
# reconx tools search <capability>
# ══════════════════════════════════════════════════════════════════════════════

def cmd_tools_search(console: Console, capability: str) -> None:
    """Find all tools that provide a given capability."""
    pm      = _get_manager()
    records = pm.search(capability)

    if not records:
        console.print(
            f"[{CB}]No tools found[/{CB}] with capability: [yellow]{capability}[/yellow]\n"
            f"[{CD}]Run [bold]reconx tools capabilities[/bold] to see all capabilities.[/{CD}]"
        )
        return

    console.print(Panel(
        f"[yellow]{len(records)} tool(s)[/yellow] provide: [bold cyan]{capability}[/bold cyan]",
        border_style=C,
    ))
    for r in records:
        m      = r.metadata
        avail  = "✓" if r.available else "✗"
        console.print(
            f"  {avail} [bold]{m.name}[/bold]  [{CD}]{m.category}  stage:{m.stage}  "
            f"{'passive' if m.passive else 'active'}[/{CD}]"
        )
        console.print(f"     [{CD}]{m.description}[/{CD}]")
    console.print()


# ══════════════════════════════════════════════════════════════════════════════
# reconx tools health
# ══════════════════════════════════════════════════════════════════════════════

def cmd_tools_health(console: Console, name: Optional[str] = None) -> None:
    """Run healthcheck on one or all registered tools."""
    pm      = _get_manager()
    results = pm.healthcheck(name=name)

    tbl = Table(
        title=f"[{CB}]Tool Health[/{CB}]" + (f" — {name}" if name else ""),
        border_style=C, box=box.ROUNDED,
    )
    tbl.add_column("Status",  width=8,  justify="center")
    tbl.add_column("Tool",    style="bold white", min_width=16)
    tbl.add_column("Version", style="dim",        max_width=45)
    tbl.add_column("Latency", style="cyan",       width=10, justify="right")
    tbl.add_column("Note",    style="dim red",    max_width=40)

    for h in results:
        status = Text("✓", style="bold green") if h["available"] else Text("✗", style="bold red")
        lat    = f"{h['latency_ms']:.0f}ms" if h["latency_ms"] else "—"
        tbl.add_row(status, h["name"], h["version"][:45] or "—", lat, h["error"][:40] or "")

    console.print(tbl)

    ok    = sum(1 for h in results if h["available"])
    total = len(results)
    console.print(f"\n  [{CD}]{ok}/{total} tools available.[/{CD}]\n")


# ══════════════════════════════════════════════════════════════════════════════
# Unified dispatcher
# ══════════════════════════════════════════════════════════════════════════════

def dispatch_tools_command(args: list[str], console: Optional[Console] = None) -> int:
    """
    Dispatch `reconx tools <subcommand>` args.
    Returns exit code (0=ok, 1=error).
    """
    console = console or Console()

    if not args:
        _print_tools_help(console)
        return 0

    cmd = args[0].lower()

    if cmd == "list":
        cat = None
        if "--category" in args:
            idx = args.index("--category")
            cat = args[idx + 1] if idx + 1 < len(args) else None
        cmd_tools_list(console, category=cat)

    elif cmd == "info":
        if len(args) < 2:
            console.print(f"[{CB}]Usage:[/{CB}] reconx tools info <name>")
            return 1
        cmd_tools_info(console, args[1])

    elif cmd == "category":
        cmd_tools_category(console)

    elif cmd == "capabilities":
        tool_filter = args[1] if len(args) > 1 else None
        cmd_tools_capabilities(console, filter_tool=tool_filter)

    elif cmd == "search":
        if len(args) < 2:
            console.print(f"[{CB}]Usage:[/{CB}] reconx tools search <capability>")
            return 1
        cmd_tools_search(console, args[1])

    elif cmd == "health":
        name = args[1] if len(args) > 1 else None
        cmd_tools_health(console, name=name)

    else:
        console.print(f"[{CB}]Unknown tools command:[/{CB}] {cmd}")
        _print_tools_help(console)
        return 1

    return 0


def _print_tools_help(console: Console) -> None:
    console.print(Panel(
        "[bold cyan]reconx tools[/bold cyan] — Plugin Registry\n\n"
        "  [yellow]reconx tools list[/yellow]                     List all plugins\n"
        "  [yellow]reconx tools list --category network[/yellow]  Filter by category\n"
        "  [yellow]reconx tools info <name>[/yellow]              Full tool metadata\n"
        "  [yellow]reconx tools category[/yellow]                 List all categories\n"
        "  [yellow]reconx tools capabilities[/yellow]             Capability → tool map\n"
        "  [yellow]reconx tools search <capability>[/yellow]      Find tools by capability\n"
        "  [yellow]reconx tools health[/yellow]                   Check all tools\n"
        "  [yellow]reconx tools health <name>[/yellow]            Health check one tool",
        border_style="cyan",
        title="Tools Help",
    ))
