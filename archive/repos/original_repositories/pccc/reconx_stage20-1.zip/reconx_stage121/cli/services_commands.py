"""
ReconX — Stage 20: Service Intelligence CLI Commands

Implements the `reconx services` subcommand group:

  reconx services analyze <file>              Analyze scanner output file
  reconx services analyze <file> --tool nmap  Specify parser
  reconx services scan <host>                 Run live analysis pipeline
  reconx services info <host> <port>          Detail on one service
  reconx services report <file>               Generate HTML report

All commands feed through ServiceIntelligenceEngine — never bypass it.
Non-fatal: a bad file or parse error shows a warning, not a crash.
"""
from __future__ import annotations

import logging
import os
from typing import Optional

from rich import box
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

log = logging.getLogger("reconx.cli.services")


def _engine():
    from ..analysis.protocol.engine import ServiceIntelligenceEngine
    return ServiceIntelligenceEngine()


# ══════════════════════════════════════════════════════════════════════════════
# reconx services analyze <file> [--tool nmap]
# ══════════════════════════════════════════════════════════════════════════════

def cmd_services_analyze(
    console:   Console,
    file_path: str,
    tool_name: str = "generic",
    host:      str = "",
    no_ai:     bool = False,
) -> None:
    """Analyze a scanner output file and display service intelligence."""
    if not os.path.exists(file_path):
        console.print(Panel(
            f"[red]File not found:[/red] {file_path}",
            border_style="red",
        ))
        return

    try:
        raw = open(file_path, encoding="utf-8", errors="replace").read()
    except Exception as exc:
        console.print(Panel(f"[red]Could not read file:[/red] {exc}", border_style="red"))
        return

    console.print(f"[dim]Analyzing:[/dim] [bold]{file_path}[/bold] "
                  f"([cyan]{tool_name}[/cyan] parser)\n")

    from ..analysis.protocol.engine import ServiceIntelligenceEngine
    engine = ServiceIntelligenceEngine(use_ai=not no_ai)

    with console.status("[red]Running service intelligence pipeline…[/red]"):
        report = engine.analyze_output(raw, tool_name=tool_name, host=host,
                                       target=host or file_path)

    from ..tui.views.service_intelligence_view import ServiceIntelligencePanel
    ServiceIntelligencePanel().render(console, report)

    # Log output
    entries = engine.get_log_entries(report)
    if entries:
        log.info("[services analyze] %d services logged from %s", len(entries), file_path)


# ══════════════════════════════════════════════════════════════════════════════
# reconx services info <host> <port>
# ══════════════════════════════════════════════════════════════════════════════

def cmd_services_info(console: Console, host: str, port: int) -> None:
    """Show detailed knowledge-base information for a specific service/port."""
    from ..analysis.protocol.knowledge_base import lookup_port, lookup_service
    from ..analysis.protocol.models import ServiceRecord
    from ..analysis.protocol.detection_engine import ProtocolDetectionEngine

    port_entry = lookup_port(port)
    proto_name = port_entry.name if port_entry else f"port/{port}"
    svc_entry  = lookup_service(proto_name)

    # Header
    risk_colour = {
        "critical": "bold red", "high": "red",
        "medium": "yellow", "low": "green", "info": "dim",
    }.get(port_entry.risk_baseline.value if port_entry else "info", "white")

    console.print(Panel(
        f"[bold white]{proto_name}[/bold white]  "
        f"Port [cyan]{port}[/cyan]  "
        f"[{risk_colour}]{port_entry.risk_baseline.value.upper() if port_entry else 'UNKNOWN'}[/{risk_colour}]\n"
        + (f"[dim]{port_entry.description}[/dim]" if port_entry else ""),
        border_style="red",
        title="[bold red]Service Info[/bold red]",
    ))

    if svc_entry:
        # Beginner explanation
        console.print(Panel(
            svc_entry.beginner_explain or svc_entry.description,
            title="[yellow]Beginner Explanation[/yellow]",
            border_style="yellow",
        ))

        # Attack vectors
        if svc_entry.attack_vectors:
            console.print("\n  [bold red]Attack Vectors:[/bold red]")
            for v in svc_entry.attack_vectors:
                console.print(f"  [dim]•[/dim] {v}")

        # Misconfigurations
        if svc_entry.misconfig_patterns:
            console.print("\n  [bold yellow]Common Misconfigurations:[/bold yellow]")
            for m in svc_entry.misconfig_patterns:
                console.print(f"  [dim]•[/dim] {m}")

        # Enumeration commands
        if svc_entry.enum_commands:
            tbl = Table(border_style="green", box=box.SIMPLE_HEAVY,
                        title="🗺️  Enumeration Commands")
            tbl.add_column("Tool",    style="cyan",  width=14)
            tbl.add_column("Command", style="green", max_width=60)
            tbl.add_column("Purpose", style="dim",   max_width=40)
            for cmd in svc_entry.enum_commands:
                command = cmd["cmd"].replace("{host}", host or "<host>").replace("{port}", str(port))
                tbl.add_row(cmd["tool"], command, cmd.get("purpose", ""))
            console.print()
            console.print(tbl)

        # CVE references
        if svc_entry.cve_patterns:
            console.print(f"\n  [bold red]CVE References:[/bold red] "
                          f"{', '.join(svc_entry.cve_patterns)}")

    else:
        console.print("[dim]No detailed knowledge base entry for this service.[/dim]")

    console.print()


# ══════════════════════════════════════════════════════════════════════════════
# reconx services report <file> [--output report.html]
# ══════════════════════════════════════════════════════════════════════════════

def cmd_services_report(
    console:     Console,
    file_path:   str,
    tool_name:   str = "generic",
    host:        str = "",
    output_path: str = "",
    no_ai:       bool = False,
) -> None:
    """Analyze scanner output and generate an HTML report."""
    if not os.path.exists(file_path):
        console.print(Panel(f"[red]File not found:[/red] {file_path}", border_style="red"))
        return

    try:
        raw = open(file_path, encoding="utf-8", errors="replace").read()
    except Exception as exc:
        console.print(Panel(f"[red]Read error:[/red] {exc}", border_style="red"))
        return

    from ..analysis.protocol.engine import ServiceIntelligenceEngine
    engine = ServiceIntelligenceEngine(use_ai=not no_ai)

    with console.status("[red]Analyzing…[/red]"):
        report = engine.analyze_output(raw, tool_name=tool_name, host=host,
                                       target=host or file_path)

    # Determine output path
    if not output_path:
        base = os.path.splitext(os.path.basename(file_path))[0]
        os.makedirs("reports", exist_ok=True)
        output_path = f"reports/service_intel_{base}.html"

    # Inject into HTML report
    from ..analysis.protocol.report_injector import inject_service_section
    success = inject_service_section(output_path, report.to_dict(),
                                     create_if_missing=True)

    if success:
        console.print(Panel(
            f"[bold green]✓ Report generated:[/bold green] {output_path}\n"
            f"  Services: {report.total_services}  "
            f"Critical: {report.critical_count}  "
            f"High: {report.high_count}",
            border_style="green",
        ))
    else:
        console.print(Panel(
            f"[red]Report generation failed.[/red]\n"
            f"Check write permissions for: {output_path}",
            border_style="red",
        ))


# ══════════════════════════════════════════════════════════════════════════════
# reconx services kb [--search redis]
# ══════════════════════════════════════════════════════════════════════════════

def cmd_services_kb(console: Console, search: str = "") -> None:
    """Browse the Stage 20 service knowledge base."""
    from ..analysis.protocol.knowledge_base import SERVICE_DB, PORT_DB

    if search:
        entries = {k: v for k, v in SERVICE_DB.items()
                   if search.lower() in k.lower() and k == k.capitalize()}
        if not entries:
            console.print(f"[dim]No knowledge base entries matching '{search}'[/dim]")
            return
        for name, entry in entries.items():
            cmd_services_info(console, "", 0)
        return

    # Summary table of all entries
    tbl = Table(title="[bold red]Service Knowledge Base[/bold red]",
                border_style="red", box=box.ROUNDED)
    tbl.add_column("Service",  style="bold white", min_width=14)
    tbl.add_column("Family",   style="cyan",       width=12)
    tbl.add_column("Risk",     width=9,            justify="center")
    tbl.add_column("Vectors",  style="dim",        width=8,  justify="right")
    tbl.add_column("Commands", style="dim",        width=10, justify="right")

    risk_colours = {
        "critical": "bold red", "high": "red",
        "medium": "yellow", "low": "green", "info": "dim",
    }

    seen = set()
    for name, entry in sorted(SERVICE_DB.items()):
        if name in seen or name != name.capitalize():
            continue
        seen.add(name)
        risk = entry.risk_baseline.value
        tbl.add_row(
            name,
            entry.family.value,
            Text(risk.upper(), style=risk_colours.get(risk, "white")),
            str(len(entry.attack_vectors)),
            str(len(entry.enum_commands)),
        )

    console.print(tbl)
    console.print(
        f"\n  [dim]Use [bold]reconx services info <host> <port>[/bold] "
        f"for full detail on any service.[/dim]\n"
    )


# ══════════════════════════════════════════════════════════════════════════════
# Unified dispatcher
# ══════════════════════════════════════════════════════════════════════════════

def dispatch_services_command(
    args:    list[str],
    console: Optional[Console] = None,
) -> int:
    """Dispatch `reconx services <subcommand>` args. Returns exit code."""
    console = console or Console()

    if not args:
        _print_services_help(console)
        return 0

    cmd = args[0].lower()

    if cmd == "analyze":
        if len(args) < 2:
            console.print("[red]Usage: reconx services analyze <file> [--tool nmap][/red]")
            return 1
        file_path = args[1]
        tool = "generic"
        host = ""
        no_ai = "--no-ai" in args
        if "--tool" in args:
            idx = args.index("--tool")
            tool = args[idx + 1] if idx + 1 < len(args) else "generic"
        if "--host" in args:
            idx = args.index("--host")
            host = args[idx + 1] if idx + 1 < len(args) else ""
        cmd_services_analyze(console, file_path, tool_name=tool, host=host, no_ai=no_ai)

    elif cmd == "info":
        if len(args) < 3:
            console.print("[red]Usage: reconx services info <host> <port>[/red]")
            return 1
        host = args[1]
        try:
            port = int(args[2])
        except ValueError:
            console.print("[red]Port must be an integer[/red]")
            return 1
        cmd_services_info(console, host, port)

    elif cmd == "report":
        if len(args) < 2:
            console.print("[red]Usage: reconx services report <file> [--output report.html][/red]")
            return 1
        file_path = args[1]
        tool  = "generic"
        host  = ""
        out   = ""
        no_ai = "--no-ai" in args
        if "--tool"   in args: idx = args.index("--tool");   tool = args[idx+1] if idx+1 < len(args) else tool
        if "--host"   in args: idx = args.index("--host");   host = args[idx+1] if idx+1 < len(args) else host
        if "--output" in args: idx = args.index("--output"); out  = args[idx+1] if idx+1 < len(args) else out
        cmd_services_report(console, file_path, tool_name=tool, host=host,
                            output_path=out, no_ai=no_ai)

    elif cmd in ("kb", "knowledge", "database"):
        search = args[1] if len(args) > 1 else ""
        cmd_services_kb(console, search=search)

    else:
        console.print(f"[red]Unknown services command:[/red] {cmd}")
        _print_services_help(console)
        return 1

    return 0


def _print_services_help(console: Console) -> None:
    console.print(Panel(
        "[bold red]reconx services[/bold red] — Service Intelligence Engine\n\n"
        "  [yellow]reconx services analyze <file>[/yellow]               Analyze scanner output\n"
        "  [yellow]reconx services analyze <file> --tool nmap[/yellow]   Specify parser\n"
        "  [yellow]reconx services analyze <file> --no-ai[/yellow]       Skip AI enrichment\n"
        "  [yellow]reconx services info <host> <port>[/yellow]           Port/service knowledge\n"
        "  [yellow]reconx services report <file>[/yellow]                Generate HTML report\n"
        "  [yellow]reconx services report <file> --output out.html[/yellow]\n"
        "  [yellow]reconx services kb[/yellow]                           Browse knowledge base\n"
        "  [yellow]reconx services kb redis[/yellow]                     Search knowledge base",
        border_style="red",
        title="Services Help",
    ))
