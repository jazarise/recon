"""
ReconX — CLI Banner. Blood-red / dark theme.
"""
from __future__ import annotations
import shutil
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from rich import box

VERSION = "2.0.0"

_ASCII = r"""
 ██▀███  ▓█████  ▄████▄  ▒█████   ███▄    █ ▒██   ██▒
▓██ ▒ ██▒▓█   ▀ ▒██▀ ▀█ ▒██▒  ██▒ ██ ▀█   █ ▒▒ █ █ ▒░
▓██ ░▄█ ▒▒███   ▒▓█    ▄ ▒██░  ██▒▓██  ▀█ ██▒░░  █   ░
▒██▀▀█▄  ▒▓█  ▄ ▒▓▓▄ ▄██▒▒██   ██░▓██▒  ▐▌██▒ ░ █ █ ▒ 
░██▓ ▒██▒░▒████▒▒ ▓███▀ ░░ ████▓▒░▒██░   ▓██░▒██▒ ▒██▒
░ ▒▓ ░▒▓░░░ ▒░ ░░ ░▒ ▒  ░░ ▒░▒░▒░ ░ ▒░   ▒ ▒ ▒▒ ░ ░▓ ░
  ░▒ ░ ▒░ ░ ░  ░  ░  ▒     ░ ▒ ▒░ ░ ░░   ░ ▒░░░   ░▒ ░
  ░░   ░    ░   ░        ░ ░ ░ ▒     ░   ░ ░  ░    ░  
   ░        ░  ░░ ░          ░ ░           ░  ░    ░  
"""

_TOOLS = [
    ("nmap",      "scanning",  True),
    ("masscan",   "scanning",  False),
    ("subfinder", "subdomain", False),
    ("amass",     "subdomain", False),
    ("httpx",     "web",       False),
    ("whatweb",   "web",       False),
    ("whois",     "passive",   False),
]


def print_banner(console: Console, show_tools: bool = True) -> None:
    lines = _ASCII.strip("\n").splitlines()
    gradient = ["bold red", "red", "bold red", "red1", "dark_red", "red3", "dim red", "dim red", "dim red"]
    art = "\n".join(
        f"[{gradient[min(i, len(gradient)-1)]}]{line}[/{gradient[min(i, len(gradient)-1)]}]"
        for i, line in enumerate(lines)
    )
    subtitle = (
        f"[dim]v{VERSION}[/dim]  "
        "[bold red]AI-Powered Reconnaissance Orchestrator[/bold red]\n"
        "[dim]For authorized security testing and educational use only.[/dim]"
    )
    console.print(Panel(art + "\n\n" + subtitle,
                        border_style="red", padding=(0, 2)))
    if show_tools:
        _tool_table(console)


def _tool_table(console: Console) -> None:
    t = Table(box=box.SIMPLE_HEAD, border_style="dim",
              header_style="bold red", padding=(0, 2), show_edge=False)
    t.add_column("TOOL",     style="red",      width=12)
    t.add_column("CATEGORY", style="dim",      width=12)
    t.add_column("STATUS",                     width=18)
    t.add_column("ROLE",     style="dim",      width=10)

    for name, cat, required in _TOOLS:
        ok = shutil.which(name) is not None
        st = Text("● available", style="bold green") if ok else Text("○ not found", style="dim red")
        role = Text("core",     style="yellow") if required else Text("optional", style="dim")
        t.add_row(name, cat, st, role)

    console.print(t)
    console.print()
