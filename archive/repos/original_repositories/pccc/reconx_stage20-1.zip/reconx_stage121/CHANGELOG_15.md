# ReconX — Stage 15 Changelog

## Overview

Stage 15 transforms ReconX from a fixed tool collection into an
**expandable plugin ecosystem**. Third-party tools, workflows, analyzers,
exporters, learning modules, and future AI agents can be added at runtime
without modifying any core ReconX code.

---

## New Files (12)

### `plugins/` — Core Plugin Infrastructure

| File | Class/Function | Description |
|---|---|---|
| `sdk.py` | `BaseReconPlugin`, `BaseToolPlugin`, `BaseWorkflowPlugin`, `BaseAnalyzerPlugin`, `BaseExporterPlugin`, `BaseLearningPlugin`, `BaseAgentPlugin`, `PluginManifest`, `@reconx_plugin`, `@plugin_hook` | Complete plugin developer SDK. 6 specialised bases, manifest dataclass, two decorators. All lifecycle hooks: `on_load`, `on_execute`, `on_finish`, `on_error`, `on_report`, `on_unload`. |
| `manager.py` | `PluginManager`, `PluginRecord` | Full lifecycle management: `install_from_file()`, `install_pack()`, `enable()`, `disable()`, `remove()`, `update()`. Persists state to `cache/plugin_registry.json`. `health_report()` ASCII dashboard. |
| `loader.py` | `PluginLoader`, `LoadResult` | Dynamic discovery via `importlib.util`. Walks plugin directories, extracts `BaseReconPlugin` subclasses, routes to correct subsystem: tools → ToolRegistry, workflows → BUILTIN_CHAINS, analyzers/exporters/learning → respective lists. **Broken plugins never crash ReconX.** |
| `sandbox.py` | `PluginSandbox`, `SandboxConfig`, `SandboxPolicy`, `SandboxResult` | Thread-based execution isolation with configurable timeout (default 60s). Linux `resource.setrlimit` for RAM limits. Filesystem path guard. Module shadowing for dangerous imports. Three policies: STRICT / STANDARD / PERMISSIVE. |
| `marketplace.py` | `Marketplace`, `MarketplacePack` | 8 built-in pack catalog entries. `search()`, `by_category()`, `top_rated()`, `most_installed()`. `install()` creates pack directory and pip deps. `uninstall()` removes directory. Persists install state to `cache/marketplace_catalog.json`. |
| `schemas.py` | `validate_manifest()`, `validate_workflow_pack()`, `validate_tool_plugin()`, `BUILTIN_WORKFLOW_PACKS` | Pure-Python validation. Regex-checked name (kebab-case), semver version, enum plugin_type, list fields. 5 built-in workflow pack JSON definitions: web-recon, passive-recon, cloud-recon, enterprise-internal, bug-bounty. |
| `__init__.py` | — | Full package export of all SDK classes, manager, loader, sandbox, marketplace, and schema tools. |
| `community/shodan_recon_plugin.py` | `ShodanReconPlugin`, `ShodanLearningPlugin` | **Reference implementation** showing the complete SDK in action: both tool and learning plugins, all lifecycle hooks, InternetDB API fallback, `parse_output()`, `safe_run()`, and `on_report()`. |

### `tui/views/plugin_center.py` — `PluginCenter`

Interactive TUI for the plugin ecosystem:
- `[1]` Marketplace Browser — pack list, detail view, install/uninstall
- `[2]` Installed Plugins — list with status/runs/errors, enable/disable/remove
- `[3]` Workflow Packs — browse 5 built-in workflow templates with step lists
- `[4]` Plugin Health — `PluginManager.health_report()` rendered in terminal
- `[5]` Install from File — load a local .py plugin by path

### `output/report_15.py` — `inject_plugin_section()`

Adds a plugin metadata section to HTML reports:
- Active plugin list: name, status, type, version, author, run count, error count
- Workflow source attribution
- Plugin-generated findings table (tagged by source plugin)
- `inject_plugin_section()` follows same in-place injection pattern as `report_14.py`

### `tests/test_stage15_plugins.py` — 8 test classes, 45+ tests

---

## 8 Marketplace Packs

| Pack ID | Name | Category | Key Tools |
|---|---|---|---|
| `cloud_recon_pack` | Cloud Recon Pack | Cloud | CloudFox, S3Scanner+, AWS/GCP/Azure scanners |
| `osint_pack` | OSINT Intelligence Pack | OSINT | BreachMonitor, DarkWeb, LinkedIn, LeakIX |
| `bug_bounty_pack` | Bug Bounty Pack | Bug Bounty | Nuclei, ScopeValidator, HackerOne/Bugcrowd exporters |
| `api_recon_pack` | API Intelligence Pack | API | gRPC enum, GraphQL schema, OpenAPI gen, Postman |
| `wireless_pack` | Wireless Recon Pack | Wireless | WiFi survey, SSID enum, Bluetooth, Evil twin |
| `ai_agents_pack` | AI Agents Pack (β) | AI | ReconAgent, FindingCorrelator, NL report gen |
| `enterprise_pack` | Enterprise Internal Pack | Enterprise | LDAP, AD, SNMP, SMB, Kerberoast, internal DNS |
| `identity_pack` | Identity Intelligence Pack | Identity | PasteMonitor, BreachCorrelator, HIBP, SocialGraph |

## 5 Built-in Workflow Packs

| Pack | Target Types | Steps | Description |
|---|---|---|---|
| `web-recon-workflow` | domain, url | 10 | WHOIS → CT → HTTPX → WAF → Crawl → Content → Visual |
| `passive-recon-workflow` | domain, asn, email | 9 | Zero-traffic OSINT only |
| `cloud-recon-workflow` | domain, asn, cidr | 8 | ASN → CIDR → Hosts → Certs → Buckets |
| `enterprise-internal-workflow` | cidr, ip, domain | 7 | ARP → Ports → Services → TLS → Vuln audit |
| `bug-bounty-workflow` | domain | 18 | Complete modern bug bounty chain |

---

## Plugin Developer Guide

### Minimal tool plugin (30 lines)

```python
from reconx.plugins.sdk import BaseToolPlugin, PluginManifest

class MyTool(BaseToolPlugin):
    MANIFEST = PluginManifest(
        name="my-tool",
        version="1.0.0",
        author="me@example.com",
        description="Does something useful.",
        plugin_type="tool",
        tags=["web", "passive"],
    )
    NAME        = "MyTool"
    BINARY      = "mytool"
    CATEGORY    = "web"
    STAGE       = 2
    PASSIVE     = False
    TIMEOUT     = 60
    INSTALL_CMD = "pip install mytool"
    DEPENDENCIES: list = []

    def run(self, target, **kwargs):
        # your logic here
        ...

    def parse_output(self, raw, **kwargs):
        return {"items": [], "count": 0}

    def safe_run(self, target, **kwargs):
        try:
            return self.run(target, **kwargs)
        except Exception as e:
            self.on_error(target, e)
```

### Install a plugin

```python
from reconx.plugins.manager import PluginManager

pm = PluginManager.load()
rec = pm.install_from_file("path/to/my_tool.py")
print(f"Installed: {rec.name} v{rec.version}")
```

### Use the sandbox

```python
from reconx.plugins.sandbox import PluginSandbox, SandboxConfig, SandboxPolicy

sandbox = PluginSandbox(config=SandboxConfig.for_policy(SandboxPolicy.STRICT))
result  = sandbox.run(plugin_instance.run, args=("example.com",))
if result.success:
    process(result.value)
```

### Install a marketplace pack

```python
from reconx.plugins.marketplace import Marketplace

mp = Marketplace()
ok, msg = mp.install("cloud_recon_pack")
print(msg)
```

---

## Architecture: Plugin → ReconX Integration

```
.py file dropped into plugins/community/
    │
    ▼
PluginLoader.load_file()
    │
    ├── importlib.util.spec_from_file_location()
    ├── find BaseReconPlugin subclasses
    ├── validate MANIFEST
    ├── inst.on_load()
    │
    └── route by plugin_type:
        ├── tool     → ToolRegistry.register(ToolMeta)
        ├── workflow → BUILTIN_CHAINS[name] = [ChainStep, ...]
        ├── analyzer → loader.analyzers.append(inst)
        ├── exporter → loader.exporters.append(inst)
        ├── learning → loader.learning_catalog.append(lessons)
        └── agent    → logged for future pipeline integration

Any exception above → caught → LoadResult.failed updated
ReconX never crashes.
```

---

## Future Foundation (Part 10)

`BaseAgentPlugin` is a stub today with three abstract methods:
- `observe(state)` — inspect current pipeline state
- `propose(state)` — suggest next tool class names
- `act(target, state)` — execute autonomous sub-workflow

This interface is intentionally minimal to remain stable while the
AI agent architecture (Stage 16+) is developed. Plugin authors who
implement `BaseAgentPlugin` today will be compatible with the future
autonomous recon loop.

The `ai_agents_pack` marketplace entry reserves space for LLM-powered
agents (ReconAgent, FindingCorrelator, NLReportGenerator) that will
be populated in a future stage.
