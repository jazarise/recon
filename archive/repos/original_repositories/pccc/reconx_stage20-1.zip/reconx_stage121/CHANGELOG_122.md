# ReconX — Stage 12.2 Changelog

## Overview

Stage 12.2 adds modern bug-bounty and large-scale asset discovery
capability — 7 new tools across 4 new learning categories, a full
24-step guided recon chain, a merged registry, and a comprehensive
integration test suite.

---

## Existing Tools Enhanced / Already Present

The following tools were already production-quality from Stages 11–12.1
and required **no changes**. Stage 12.2 adds them to the new learning
category structure and guided workflow:

| Tool | Module | New Category |
|---|---|---|
| `GauTool` | `tools/passive/gau.py` | Historical Recon |
| `WaybackurlsTool` | `tools/passive/waybackurls.py` | Historical Recon |
| `KatanaTool` | `tools/web/katana_tool.py` | URL Discovery |
| `HakrawlerTool` | `tools/web/hakrawler_tool.py` | URL Discovery |
| `ArjunTool` | `tools/api/arjun_tool.py` | Parameter Discovery |
| `AssetfinderTool` | `tools/passive/assetfinder.py` | Attack Surface |
| `FindomainTool` | `tools/passive/findomain.py` | Attack Surface |
| `ChaosTool` | `tools/passive/chaos.py` | Attack Surface |

---

## New Files — Stage 12.2

### Asset Discovery  (`tools/asset/`)

| File | Class | Description |
|---|---|---|
| `github_subdomains.py` | `GitHubSubdomainsTool` | Mine GitHub repos for leaked subdomains/configs. GitHub API fallback. |
| `asnmap.py` | `AsnmapTool` | ASN → CIDR range mapping. BGPView API fallback. |
| `mapcidr.py` | `MapCIDRTool` | CIDR expand/aggregate/split. Python ipaddress fallback. |
| `alterx.py` | `AlterxTool` | Intelligent subdomain permutation. Full Python fallback with 50 seed words. |
| `__init__.py` | — | Package init exporting all 4 tools. |

### Parameter & URL Discovery  (`tools/param/`)

| File | Class | Description |
|---|---|---|
| `paramspider.py` | `ParamSpiderTool` | Passive param mining from Wayback CDX. CDX API fallback. |
| `gospider.py` | `GospiderTool` | Recursive spider extracting URLs, JS, forms, params. |
| `waymore.py` | `WaymoreTool` | Multi-source archive aggregation (Wayback + URLScan). API fallback. |
| `__init__.py` | — | Package init. |

### Knowledge Catalog  (`knowledge/tools/s122/stage122_catalog.py`)
- 12 `ToolKnowledge` entries covering all new + catalogued existing tools
- 4 new categories: Attack Surface, Historical Recon, URL Discovery, Parameter Discovery
- `get_stage122_by_category()`, `search_stage122()` utility functions

### Guided Workflow  (`workflow/guided_recon_122.py`)
- `GUIDED_STEPS_122` — 24+ step workflow integrating all Stage 12.2 tools
- 8 new steps: `github_recon`, `asn_mapping`, `cidr_expansion`, `permutation`,
  `historical_urls`, `active_crawl`, `param_discovery`, `js_analysis`
- Dependency graph: ASN → CIDR → fping → Nmap; Subdomains → alterx → DNS resolve
- `build_122_workflow()` — merges new steps into Stage 12.1 chain with correct ordering
- Reuses `WorkflowRunner` from Stage 12.1 unchanged

### Registry  (`tools/registry_122.py`)
- `get_122_additions()` — loads 12 tools (7 new + 5 re-registrations)
- `get_full_registry()` — merged 12.1 + 12.2 registry, single entry point
- `_NullTool` stub pattern — registry never crashes on missing tools

### Tests  (`tests/test_stage122_integration.py`)
- **5 test classes, 35+ test methods**
- Tool imports, attribute presence, parse_output safety, is_available()
- 15 correctness tests: GitHub parse, ASNmap JSON, MapCIDR Python expand,
  bogon filter, AlterX permute, valid_subdomain, ParamSpider FUZZ URLs,
  GoSpider type classification, Waymore ext categorisation
- Catalog: 12 entries, 4 categories, example commands, install present
- Workflow: ≥24 steps, unique IDs, dep graph integrity, new steps present
- Registry: all 7 new tools registered, no crash on missing deps

---

## Architecture Decisions

### Why pure-Python fallbacks for every tool?
Every net-new tool (`github-subdomains`, `asnmap`, `mapcidr`, `alterx`,
`paramspider`, `waymore`) has a working fallback implemented in plain Python
using standard library only (`urllib`, `ipaddress`, `re`, `json`). This means:
- ReconX is **immediately useful** on a fresh install with no Go tools
- CI/CD environments without Go binaries still get results
- Fallback performance is acceptable for reconnaissance scale (not red-team speed)

### Why not rewrite gau/waybackurls/katana/hakrawler/arjun?
These tools were already production-quality from Stages 11–12.1 with:
- Proper BaseTool inheritance, full parse_output, findings, retries, timeout
- CDX/CDX fallback where applicable
Stage 12.2 adds them to the new category structure and guided workflow
without touching their implementation.

### Workflow insertion strategy
New steps insert at semantically correct positions relative to Stage 12.1
steps via `_new_steps_after()`. This avoids hardcoded indices and survives
future step additions to the base workflow.

---

## Installation for Full Capability

```bash
# Go tools (Asset Discovery)
go install github.com/gwen001/github-subdomains@latest
go install github.com/projectdiscovery/asnmap/cmd/asnmap@latest
go install github.com/projectdiscovery/mapcidr/cmd/mapcidr@latest
go install github.com/projectdiscovery/alterx/cmd/alterx@latest

# Go tools (URL/Param)
go install github.com/jaeles-project/gospider@latest

# Python tools
pip install paramspider waymore arjun

# Already installed (Stages 11-12.1)
go install github.com/lc/gau/v2/cmd/gau@latest
go install github.com/tomnomnom/waybackurls@latest
go install github.com/projectdiscovery/katana/cmd/katana@latest
go install github.com/hakluke/hakrawler@latest
```

ReconX degrades gracefully when any binary is absent —
all tools report `[MISSING]` / `[SKIPPED]` and activate fallbacks.
