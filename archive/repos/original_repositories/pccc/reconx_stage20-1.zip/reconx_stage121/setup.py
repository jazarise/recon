from setuptools import setup, find_packages

setup(
    name="reconx",
    version="1.0.0",
    author="The Commit Crew",
    description="AI-Powered Reconnaissance Orchestrator",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    python_requires=">=3.10",
    install_requires=[
        "rich>=13.0.0",
        "dnspython>=2.4.0",
    ],
    entry_points={
        "console_scripts": [
            "reconx=reconx.__main__:main",
        ]
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: POSIX :: Linux",
        "Topic :: Security",
    ],
)
