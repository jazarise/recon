# ReconX — Stage 12.1 Changelog

## Overview

Stage 12.1 extends ReconX into a **complete Kali-style reconnaissance platform**,
adding 15 new tools across 6 categories, an expanded learning mode, a full guided
workflow, a live TUI dashboard, and an extended report generator.

---

## New Files Added

### OSINT / Passive Recon  (`tools/osint/`)
| File | Class | Description |
|---|---|---|
| `theharvester.py` | `TheHarvesterTool` | Email, subdomain, IP, employee name harvesting from 20+ public sources |
| `spiderfoot.py` | `SpiderFootTool` | Automated OSINT across 200+ sources with breach indicator correlation |
| `osrframework.py` | `OSRFrameworkTool` | Username intelligence across 300+ platforms (usufy / mailfy / searchfy) |
| `maltego.py` | `MaltegoTool` | Entity graph extraction; MTGL export from ReconX findings when CLI unavailable |

### DNS Expansion  (`tools/dns_extra/`)
| File | Class | Description |
|---|---|---|
| `dnsenum_tool.py` | `DNSEnumTool` | DNS brute-force, zone transfer checks, wildcard detection |
| `dnsrecon_tool.py` | `DNSReconTool` | Full record enumeration (A/AAAA/MX/NS/TXT/SRV/SOA), AXFR, JSON output |
| `fierce_tool.py` | `FierceTool` | Subdomain discovery + adjacent IP pivoting via reverse DNS |
| `sublist3r_tool.py` | `Sublist3rTool` | Passive subdomain enumeration via search engines and OSINT sources |

### Network Discovery  (`tools/network/`)
| File | Class | Description |
|---|---|---|
| `netdiscover_tool.py` | `NetdiscoverTool` | ARP host discovery — IP, MAC, vendor; CIDR range support |
| `fping_tool.py` | `FpingTool` | ICMP sweep across ranges; per-host latency and packet loss |

### Web Recon  (`tools/web/`)
| File | Class | Description |
|---|---|---|
| `dirbuster.py` | `DirbusterTool` | Hidden directory/file discovery via dirb (DirBuster CLI fallback) |
| `feroxbuster.py` | `FeroxbusterTool` | Recursive web content discovery with JSON output and smart filtering |
| `eyewitness.py` | `EyeWitnessTool` | Automated web screenshots, login detection, category tagging |

### Frameworks  (`tools/frameworks/`)
| File | Class | Description |
|---|---|---|
| `metasploit_aux.py` | `MetasploitAuxTool` | Safe Metasploit auxiliary modules only: HTTP/SMB/SSH/FTP enumeration |

### Utilities  (`tools/utilities/`)
| File | Class | Description |
|---|---|---|
| `netcat_wrapper.py` | `NetcatWrapperTool` | Banner grabbing via nc/ncat; Python socket fallback; service probes |

---

## Updated / New Infrastructure

### Knowledge Catalog  (`knowledge/tools/stage121_catalog.py`)
- 15 new `ToolKnowledge` entries
- Full fields: description, how_it_works, use_cases, example_commands, common_errors,
  install, typical_workflow, integrations, tags
- `search()`, `get_by_category()`, `get_by_name()` utility functions
- `CATEGORY_ORDER` list for consistent UI ordering

### Learning Mode Engine  (`learning/learning_mode.py`)
- Interactive terminal UI with Rich
- Category browser → tool lesson → sub-menu (examples / errors / practice)
- Practice mode: shows command intent, checks binary installation, displays install cmd
- Full-text search across all 15 new tool entries
- `learning_mode_menu()` — drop-in replacement for existing learning mode entry point

### Guided Recon Workflow  (`workflow/guided_recon_121.py`)
- 16-step workflow covering the full recon chain:
  WHOIS → theHarvester → SpiderFoot → Subdomains → DNS → Host Discovery →
  Port Scan → Banner Grab → Service Fingerprint → Web Discovery →
  Tech Detection → Visual Recon → Social Footprint → Graph Export →
  Risk Analysis → Report
- `WorkflowRunner`: dependency resolution, skip support, state persistence (JSON), resume
- Finding propagation between steps (subdomains from DNS feed into port scan scope, etc.)
- Callbacks: `on_step_start` / `on_step_finish` for dashboard integration

### Tool Registry  (`tools/registry_121.py`)
- `get_tool_registry()` — single call returns all 25+ tool instances
- Dynamic import with graceful `_NullTool` fallback for missing dependencies
- Zero crashes on partial installs

### Terminal Dashboard  (`output/dashboard.py`)
- `ReconDashboard` — Rich Live context manager with per-tool status rows
- Status tags: `[RUNNING]` `[SUCCESS]` `[FAILED]` `[MISSING]` `[SKIPPED]`
- Progress bar with step completion count
- `print_summary()` — post-run table with findings by type
- `print_tool_event()` — single-line non-Live fallback

### Report Generator Extension  (`output/report_121.py`)
- `generate_stage121_report()` — standalone full HTML report
- New sections: OSINT, DNS Intelligence, Live Host Discovery, Visual Screenshots,
  Tool Execution Timeline, Error/Missing log
- EyeWitness screenshots inlined as base64 (with size cap)
- Horizontal bar chart for step durations
- Navigation TOC with anchor links
- Zero external CDN dependencies (Google Fonts degrades gracefully)

### Integration Tests  (`tests/test_stage121_integration.py`)
- Import test for all 15 new tool classes
- Attribute presence validation (NAME, BINARY, CATEGORY, STAGE, TIMEOUT, INSTALL_CMD)
- `parse_output("")` safety check (must not raise, must return dict)
- `is_available()` bool return check
- Knowledge catalog: field completeness, category coverage, search
- Workflow: step count, unique IDs, dependency graph integrity, skippability
- 7 parse_output correctness tests with real output samples

---

## Architecture Principles Maintained

- Every new tool inherits `BaseTool`
- All tools support: `is_available()`, `skip_if_unavailable()`, `validate_or_fail()`,
  timeout handling, structured exceptions, logging, execution telemetry
- All outputs normalised to `{finding_type, value, source, confidence, metadata}`
- Deduplication applied at parse level in each tool
- No tool crashes ReconX — `_NullTool` stub prevents registry failures
- Metasploit integration is **enumeration-only** — exploitation modules are hard-blocked

---

## Dependency Summary

All tools use system binaries via subprocess. No new Python package dependencies.
Optional installs for full functionality:

```
sudo apt install theharvester spiderfoot sublist3r dnsenum dnsrecon fierce \
                 netdiscover fping dirb feroxbuster eyewitness \
                 metasploit-framework netcat-openbsd

pip install osrframework spiderfoot
```

ReconX degrades gracefully when any binary is absent — tools report `[MISSING]`
and are skipped rather than failing the workflow.
