"""
ReconX — Burp Suite Intelligence Layer Orchestrator (Stage 18.1)

Top-level coordinator for all Burp Suite integration components.
Implements the BaseTool interface so it plugs into the ReconX engine
and tool registry without any special handling.

Architecture:
    BurpIntelligenceLayer
        ├── BurpClient          (REST API comms)
        ├── ProjectManager      (project lifecycle)
        ├── ProxyController     (proxy start/stop/configure)
        ├── SessionManager      (session lifecycle)
        ├── TrafficParser       (traffic → intelligence)
        ├── IssueImporter       (Burp findings → ReconX findings)
        └── ReplayEngine        (request/session replay)

Usage from ReconX engine:
    tool   = BurpIntelligenceLayer()
    result = tool.safe_run("https://example.com")

Usage from CLI:
    reconx burp start example.com
    reconx burp stop
    reconx burp replay SESSION_ID
    reconx burp replay SESSION_ID --request-id ITEM_ID
    reconx burp status
"""
from __future__ import annotations

import logging
import time
from typing import Optional

# BaseTool and result models
try:
    from ...tools.base import BaseTool
    from ...models.tool_result import ParsedFinding, RunStatus, ToolRunResult
    from ...models.findings import ReconResult, SensitiveFinding, Suggestion
except ImportError:
    from dataclasses import dataclass, field

    class BaseTool:
        NAME = ""; BINARY = ""; CATEGORY = ""; STAGE = 0; PRIORITY = 50
        PASSIVE = True; TIMEOUT = 300; DEPENDENCIES: list = []; INSTALL_CMD = ""
        def __init__(self, **kw): pass
        def _log(self, lvl, msg): logging.getLogger("reconx.burp").info(msg)
        def validate_or_fail(self, t): return None
        def build_result(self, **kw): return None
        def fail(self, **kw): return None
        def safe_run(self, target, **kw): return self.run(target, **kw)

    @dataclass
    class ParsedFinding:
        finding_type: str; value: str; source: str = ""; confidence: float = 1.0
        metadata: dict = field(default_factory=dict)

    class RunStatus:
        SUCCESS = "success"; FAILED = "failed"; SKIPPED = "skipped"

    class ToolRunResult:
        @staticmethod
        def skipped(name, msg): return {"status": "skipped", "msg": msg}
        @staticmethod
        def failure(**kw): return {"status": "failed", **kw}


# Burp components
from .burp_client      import BurpClient, DEFAULT_HOST, DEFAULT_PORT
from .project_manager  import ProjectManager, BurpProject
from .proxy_controller import ProxyController, ProxyConfig
from .session_manager  import SessionManager, BurpSession
from .traffic_parser   import TrafficParser, TrafficSummary
from .issue_importer   import IssueImporter, ImportedFindings
from .replay_engine    import ReplayEngine, ReplayReport

logger = logging.getLogger("reconx.integrations.burp")


class BurpIntelligenceLayer(BaseTool):
    """
    ReconX Burp Suite Intelligence Layer.

    Provides browser-aware web intelligence and automatic traffic analysis
    through Burp Suite's REST API. No GUI embedding.

    Capabilities:
      - Passive traffic analysis from Burp proxy
      - Automatic endpoint, auth token, and cookie extraction
      - Burp passive findings import (headers, TLS, CORS, cookies)
      - Session lifecycle management (start/pause/resume/stop)
      - Request and workflow replay via Burp Repeater

    Requires:
      - Burp Suite Professional with REST API enabled on port 1337
      - RECONX_BURP_API_KEY env var (if API key auth is configured)
    """

    # ── BaseTool metadata ─────────────────────────────────────────────────────
    NAME         = "Burp Suite"
    BINARY       = ""              # Not a CLI binary — REST API integration
    CATEGORY     = "web_intelligence"
    STAGE        = 4              # After service detection and web crawling
    PRIORITY     = 20
    PASSIVE      = True           # Passive analysis only (no active scanning)
    TIMEOUT      = 300
    DEPENDENCIES = []
    INSTALL_CMD  = (
        "Install Burp Suite Professional from https://portswigger.net/burp. "
        "Enable REST API: Burp → Settings → Suite → REST API → Service running. "
        "Set RECONX_BURP_API_KEY environment variable if API key is required."
    )

    def __init__(
        self,
        api_host:   str = DEFAULT_HOST,
        api_port:   int = DEFAULT_PORT,
        api_key:    Optional[str] = None,
        proxy_port: int = 8080,
        timeout:    Optional[int] = None,
    ):
        super().__init__(timeout=timeout)

        self._client   = BurpClient(host=api_host, port=api_port, api_key=api_key)
        self._projects = ProjectManager(self._client)
        self._proxy    = ProxyController(
            self._client,
            config=ProxyConfig(port=proxy_port),
        )
        self._sessions = SessionManager(self._client)
        self._parser   = TrafficParser()
        self._importer = IssueImporter(self._client)
        self._replay   = ReplayEngine(self._client, self._sessions)

        self._current_project: Optional[BurpProject] = None
        self._current_session: Optional[BurpSession]  = None

    # ══════════════════════════════════════════════════════════════════════════
    # BaseTool interface
    # ══════════════════════════════════════════════════════════════════════════

    def run(self, target: str, **kwargs) -> ToolRunResult:
        fail = self.validate_or_fail(target)
        if fail:
            return fail

        ok, ping_err = self._client.ping()
        if not ok:
            self._log("warning", f"Burp Suite not reachable: {ping_err}")
            return ToolRunResult.skipped(
                self.NAME,
                f"Burp Suite REST API not available at "
                f"{self._client.base_url}. {self.INSTALL_CMD}",
            )

        t0 = time.perf_counter()
        findings: list[ParsedFinding] = []

        try:
            project, err = self._projects.create_for_target(target)
            if err or project is None:
                return self.fail(
                    reason="project_create_failed",
                    message=f"Could not create Burp project for {target}: {err}",
                    duration_s=time.perf_counter() - t0,
                )
            self._current_project = project

            session, err = self._sessions.start(project, target=target)
            if err or session is None:
                return self.fail(
                    reason="session_start_failed",
                    message=f"Could not start Burp session: {err}",
                    duration_s=time.perf_counter() - t0,
                )
            self._current_session = session

            self._proxy.start()
            proxy_status = self._proxy.status

            session, stop_err = self._sessions.stop(session)

            imported: ImportedFindings = self._importer.import_findings(
                target_prefix=self._guess_url_prefix(target)
            )
            findings.extend(imported.to_parsed_findings())

            site_map_urls = self._importer.import_site_map_findings(
                target_prefix=self._guess_url_prefix(target)
            )
            for url in site_map_urls:
                findings.append(ParsedFinding(
                    finding_type="web_endpoint",
                    value=url,
                    source=self.NAME,
                    confidence=0.95,
                ))

            self._projects.save(project)

            duration = time.perf_counter() - t0
            data = self._build_output_data(
                session=session,
                imported=imported,
                proxy_status=proxy_status,
                site_map_urls=site_map_urls,
            )

            self._log(
                "info",
                f"Complete — {imported.total} issues, "
                f"{len(site_map_urls)} site map URLs, "
                f"session={session.short_id}, duration={duration:.1f}s",
            )

            return self.build_result(data=data, findings=findings, duration_s=duration)

        except Exception as exc:
            import traceback
            return self.fail(
                reason="unhandled_exception",
                message=str(exc),
                tb=traceback.format_exc(),
                duration_s=time.perf_counter() - t0,
            )

    def parse_output(self, raw: str, **kwargs) -> dict:
        return {}

    # ══════════════════════════════════════════════════════════════════════════
    # Session management (for CLI/TUI)
    # ══════════════════════════════════════════════════════════════════════════

    def start_session(self, target: str) -> tuple[Optional[BurpSession], str]:
        ok, err = self._client.ping()
        if not ok:
            return None, f"Burp unreachable: {err}"
        project, err = self._projects.create_for_target(target)
        if err:
            return None, err
        self._current_project = project
        session, err = self._sessions.start(project, target=target)
        if not err:
            self._current_session = session
        return session, err

    def stop_session(self) -> tuple[Optional[BurpSession], str]:
        if not self._current_session:
            return None, "No active session."
        session, err = self._sessions.stop(self._current_session)
        self._current_session = None
        return session, err

    def resume_session(self, session_id: str) -> tuple[Optional[BurpSession], str]:
        return self._sessions.resume(session_id)

    def list_sessions(self, target: Optional[str] = None) -> list[BurpSession]:
        return self._sessions.list_sessions(target=target)

    # ══════════════════════════════════════════════════════════════════════════
    # Replay
    # ══════════════════════════════════════════════════════════════════════════

    def replay(
        self,
        session_id:  str,
        request_id:  Optional[str] = None,
        sequence:    bool = False,
    ) -> ReplayReport:
        return self._replay.run_from_cli(
            session_id=session_id,
            request_id=request_id,
            sequence=sequence,
        )

    # ══════════════════════════════════════════════════════════════════════════
    # Status
    # ══════════════════════════════════════════════════════════════════════════

    def get_status(self) -> dict:
        diag    = self._client.get_diagnostics()
        proxy   = self._proxy.status
        session = self._current_session
        return {
            "api_reachable":   diag["reachable"],
            "api_url":         diag["base_url"],
            "api_key_set":     diag["api_key_set"],
            "proxy_running":   proxy.running,
            "proxy_url":       f"http://{proxy.host}:{proxy.port}",
            "intercept_on":    proxy.intercept_on,
            "proxy_error":     proxy.error,
            "current_session": session.short_id if session else None,
            "session_state":   session.state if session else "none",
            "current_project": self._current_project.name if self._current_project else None,
            "burp_version":    diag.get("version", {}).get("burpVersion", "unknown"),
        }

    def get_proxy_config(self) -> ProxyConfig:
        return self._proxy.config

    # ══════════════════════════════════════════════════════════════════════════
    # Helpers
    # ══════════════════════════════════════════════════════════════════════════

    def _build_output_data(
        self,
        session:       BurpSession,
        imported:      ImportedFindings,
        proxy_status:  object,
        site_map_urls: list[str],
    ) -> dict:
        traffic = session.traffic_summary or {}
        return {
            "session": {
                "id":         session.session_id,
                "short_id":   session.short_id,
                "target":     session.target,
                "state":      session.state,
                "duration_s": round(session.duration_s, 2),
                "item_count": len(session.item_ids),
            },
            "proxy": {
                "running": getattr(proxy_status, "running", False),
                "url":     f"http://{getattr(proxy_status, 'host', '127.0.0.1')}:{getattr(proxy_status, 'port', 8080)}",
                "error":   getattr(proxy_status, "error", ""),
            },
            "traffic":      traffic,
            "issues": {
                "total":       imported.total,
                "headers":     len(imported.headers),
                "sensitive":   len(imported.sensitive),
                "suggestions": len(imported.suggestions),
            },
            "site_map": {
                "url_count": len(site_map_urls),
                "urls":      site_map_urls[:100],
            },
            "endpoints":    traffic.get("endpoints", [])[:50],
            "api_routes":   traffic.get("api_routes", []),
            "auth_tokens":  traffic.get("auth_tokens", []),
            "cookies":      traffic.get("cookies", []),
            "admin_portals": traffic.get("admin_portals", []),
            "login_pages":  traffic.get("login_pages", []),
        }

    @staticmethod
    def _guess_url_prefix(target: str) -> str:
        if target.startswith(("http://", "https://")):
            return target
        return f"https://{target}"


# ── Public re-exports ─────────────────────────────────────────────────────────
__all__ = [
    "BurpIntelligenceLayer",
    "BurpClient",
    "ProjectManager",
    "BurpProject",
    "ProxyController",
    "ProxyConfig",
    "SessionManager",
    "BurpSession",
    "TrafficParser",
    "TrafficSummary",
    "IssueImporter",
    "ImportedFindings",
    "ReplayEngine",
    "ReplayReport",
]
