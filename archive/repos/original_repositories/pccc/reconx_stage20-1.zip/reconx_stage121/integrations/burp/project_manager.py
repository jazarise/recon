"""
ReconX — Burp Suite Project Manager (Stage 18.1)

Creates, loads, saves, and manages Burp Suite projects through the REST API.
All project state is cached locally in reconx/cache/burp/ so sessions can
be resumed across ReconX runs without re-scanning.

Project lifecycle:
  create → active → save → resume  (or)  load existing → active → save
"""
from __future__ import annotations

import json
import logging
import os
import time
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Optional

from .burp_client import BurpClient

logger = logging.getLogger("reconx.integrations.burp.project")

# Local cache directory for Burp project metadata
_CACHE_DIR = Path(__file__).resolve().parents[3] / "cache" / "burp"


@dataclass
class BurpProject:
    """Represents a Burp project — both remote state and local metadata."""
    project_id:   str
    name:         str
    target:       str
    created_at:   float = field(default_factory=time.time)
    last_saved:   float = 0.0
    description:  str   = ""
    status:       str   = "active"   # active | saved | resumed | closed
    remote_meta:  dict  = field(default_factory=dict)

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "BurpProject":
        return cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})

    @property
    def cache_path(self) -> Path:
        safe_id = self.project_id.replace("/", "_").replace(":", "_")
        return _CACHE_DIR / f"{safe_id}.json"


class ProjectManager:
    """
    Manages the full lifecycle of Burp projects for ReconX scans.

    Each ReconX target gets its own Burp project to keep traffic isolated
    and results attributable.

    Usage:
        pm = ProjectManager(client)
        proj = pm.create_for_target("example.com")
        ...
        pm.save(proj)
        proj2 = pm.resume(proj.project_id)
    """

    def __init__(self, client: BurpClient):
        self._client = client
        _CACHE_DIR.mkdir(parents=True, exist_ok=True)

    # ══════════════════════════════════════════════════════════════════════════
    # Project CRUD
    # ══════════════════════════════════════════════════════════════════════════

    def create_for_target(
        self,
        target:      str,
        description: str = "",
    ) -> tuple[Optional[BurpProject], str]:
        """
        Create a new Burp project scoped to a recon target.
        Returns (project, error). Caches metadata locally on success.
        """
        ts   = time.strftime("%Y%m%d_%H%M%S")
        name = f"reconx_{target}_{ts}"
        desc = description or f"ReconX auto-project for {target} at {ts}"

        data, err = self._client.create_project(name, desc)
        if err:
            logger.warning("[ProjectManager] create failed for %s: %s", target, err)
            return None, f"Failed to create Burp project: {err}"

        proj = BurpProject(
            project_id=data.get("id", name),
            name=name,
            target=target,
            description=desc,
            remote_meta=data,
        )
        self._cache_save(proj)
        logger.info("[ProjectManager] Created project '%s' (id=%s)", name, proj.project_id)
        return proj, ""

    def load(self, project_id: str) -> tuple[Optional[BurpProject], str]:
        """
        Load an existing Burp project by ID.
        Checks local cache first, then queries Burp API.
        """
        # Check local cache
        cached = self._cache_load(project_id)
        if cached:
            logger.debug("[ProjectManager] Loaded %s from cache", project_id)
            cached.status = "resumed"
            return cached, ""

        # Fall back to API
        data, err = self._client.load_project(project_id)
        if err:
            return None, f"Cannot load project {project_id}: {err}"

        proj = BurpProject(
            project_id=project_id,
            name=data.get("name", project_id),
            target=data.get("description", ""),
            remote_meta=data,
            status="resumed",
        )
        self._cache_save(proj)
        return proj, ""

    def save(self, project: BurpProject) -> str:
        """
        Persist local project metadata. (Burp auto-saves its own state.)
        Returns "" on success, error string otherwise.
        """
        project.last_saved = time.time()
        project.status     = "saved"
        self._cache_save(project)
        logger.info("[ProjectManager] Saved project %s", project.project_id)
        return ""

    def resume(self, project_id: str) -> tuple[Optional[BurpProject], str]:
        """
        Resume a previously saved project. Validates API connectivity first.
        """
        ok, ping_err = self._client.ping()
        if not ok:
            return None, f"Burp unreachable, cannot resume: {ping_err}"

        proj, err = self.load(project_id)
        if err:
            return None, err

        proj.status = "resumed"
        self._cache_save(proj)
        logger.info("[ProjectManager] Resumed project %s", project_id)
        return proj, ""

    def close(self, project: BurpProject) -> None:
        """Mark project as closed in local cache."""
        project.status = "closed"
        self._cache_save(project)
        logger.info("[ProjectManager] Closed project %s", project.project_id)

    # ══════════════════════════════════════════════════════════════════════════
    # Listing and discovery
    # ══════════════════════════════════════════════════════════════════════════

    def list_remote(self) -> tuple[list[dict], str]:
        """List all projects available in Burp Suite."""
        return self._client.list_projects()

    def list_cached(self) -> list[BurpProject]:
        """Return all locally cached project records."""
        projects = []
        for f in _CACHE_DIR.glob("*.json"):
            try:
                data = json.loads(f.read_text())
                projects.append(BurpProject.from_dict(data))
            except Exception as exc:
                logger.debug("[ProjectManager] Skipping corrupt cache %s: %s", f, exc)
        return sorted(projects, key=lambda p: p.created_at, reverse=True)

    def find_for_target(self, target: str) -> list[BurpProject]:
        """Find cached projects for a specific target host."""
        return [p for p in self.list_cached() if p.target == target]

    # ══════════════════════════════════════════════════════════════════════════
    # Local cache helpers
    # ══════════════════════════════════════════════════════════════════════════

    def _cache_save(self, proj: BurpProject) -> None:
        try:
            proj.cache_path.write_text(json.dumps(proj.to_dict(), indent=2))
        except Exception as exc:
            logger.debug("[ProjectManager] Cache write failed: %s", exc)

    def _cache_load(self, project_id: str) -> Optional[BurpProject]:
        safe_id  = project_id.replace("/", "_").replace(":", "_")
        path     = _CACHE_DIR / f"{safe_id}.json"
        if not path.exists():
            return None
        try:
            data = json.loads(path.read_text())
            return BurpProject.from_dict(data)
        except Exception as exc:
            logger.debug("[ProjectManager] Cache read failed for %s: %s", project_id, exc)
            return None
