"""
ReconX — Burp Suite REST API Client (Stage 18.1)

Handles all HTTP communication with the Burp Suite Professional REST API.
Burp Suite Pro exposes a REST API on http://127.0.0.1:1337 by default.

Reference: https://portswigger.net/burp/documentation/desktop/tools/api

Contract:
  - Never raises; all methods return (data, error_str) tuples.
  - API key is read from config or env: RECONX_BURP_API_KEY.
  - Connection failures produce structured error results, not exceptions.
  - All responses are normalized to dicts before being returned.
"""
from __future__ import annotations

import json
import logging
import os
import time
from typing import Any, Optional
from urllib.error import URLError
from urllib.parse import urljoin
from urllib.request import Request, urlopen

logger = logging.getLogger("reconx.integrations.burp.client")

# ── Defaults ──────────────────────────────────────────────────────────────────
DEFAULT_HOST    = "127.0.0.1"
DEFAULT_PORT    = 1337
DEFAULT_TIMEOUT = 10          # seconds per request
API_VERSION     = "0.1"       # Burp REST API version prefix

# Burp REST API base path
_BASE_PATH = f"/v{API_VERSION}/"


class BurpAPIError(Exception):
    """Raised only inside the client; caught before returning to callers."""
    def __init__(self, status: int, body: str):
        self.status = status
        self.body   = body
        super().__init__(f"HTTP {status}: {body[:200]}")


class BurpClient:
    """
    Thin, synchronous HTTP client for the Burp Suite REST API.

    Usage:
        client = BurpClient(api_key="my-key")
        ok, err = client.ping()
        if not ok:
            print(f"Burp unreachable: {err}")
    """

    def __init__(
        self,
        host:    str            = DEFAULT_HOST,
        port:    int            = DEFAULT_PORT,
        api_key: Optional[str]  = None,
        timeout: int            = DEFAULT_TIMEOUT,
        tls:     bool           = False,
    ):
        self.host    = host
        self.port    = port
        self.timeout = timeout
        self.tls     = tls

        # API key: explicit > env var > empty string (no auth on older builds)
        self.api_key = (
            api_key
            or os.environ.get("RECONX_BURP_API_KEY", "")
        )

        scheme       = "https" if tls else "http"
        self.base_url = f"{scheme}://{host}:{port}{_BASE_PATH}"

    # ══════════════════════════════════════════════════════════════════════════
    # Internal HTTP helpers
    # ══════════════════════════════════════════════════════════════════════════

    def _headers(self, extra: Optional[dict] = None) -> dict:
        h = {
            "Content-Type": "application/json",
            "Accept":       "application/json",
        }
        if self.api_key:
            # Burp uses X-Burp-Key header for API authentication
            h["X-Burp-Key"] = self.api_key
        if extra:
            h.update(extra)
        return h

    def _request(
        self,
        method:  str,
        path:    str,
        payload: Optional[dict] = None,
    ) -> dict:
        """
        Execute an HTTP request and return the parsed JSON body.
        Raises BurpAPIError on non-2xx or network failure.
        """
        url  = urljoin(self.base_url, path.lstrip("/"))
        body = json.dumps(payload).encode() if payload else None
        req  = Request(url, data=body, headers=self._headers(), method=method.upper())

        try:
            with urlopen(req, timeout=self.timeout) as resp:
                raw = resp.read().decode("utf-8", errors="replace")
                if not raw.strip():
                    return {}
                return json.loads(raw)
        except URLError as exc:
            raise BurpAPIError(0, str(exc)) from exc
        except json.JSONDecodeError as exc:
            raise BurpAPIError(0, f"JSON parse error: {exc}") from exc

    # ── Public API conveniences ───────────────────────────────────────────────

    def _get(self, path: str) -> tuple[dict, str]:
        """GET request. Returns (data, error)."""
        try:
            return self._request("GET", path), ""
        except BurpAPIError as exc:
            logger.debug("[BurpClient] GET %s failed: %s", path, exc)
            return {}, str(exc)

    def _post(self, path: str, payload: dict) -> tuple[dict, str]:
        """POST request. Returns (data, error)."""
        try:
            return self._request("POST", path, payload), ""
        except BurpAPIError as exc:
            logger.debug("[BurpClient] POST %s failed: %s", path, exc)
            return {}, str(exc)

    def _delete(self, path: str) -> tuple[dict, str]:
        """DELETE request. Returns (data, error)."""
        try:
            return self._request("DELETE", path), ""
        except BurpAPIError as exc:
            logger.debug("[BurpClient] DELETE %s failed: %s", path, exc)
            return {}, str(exc)

    # ══════════════════════════════════════════════════════════════════════════
    # Connectivity
    # ══════════════════════════════════════════════════════════════════════════

    def ping(self) -> tuple[bool, str]:
        """
        Check whether the Burp API is reachable and responding.
        Returns (True, "") on success, (False, error_msg) otherwise.
        """
        data, err = self._get("health")
        if err:
            return False, f"Burp API unreachable at {self.base_url}: {err}"
        return True, ""

    def get_version(self) -> tuple[dict, str]:
        """Fetch Burp Suite version information."""
        return self._get("burp/versions")

    # ══════════════════════════════════════════════════════════════════════════
    # Project management
    # ══════════════════════════════════════════════════════════════════════════

    def list_projects(self) -> tuple[list, str]:
        """Return list of available Burp projects."""
        data, err = self._get("projects")
        if err:
            return [], err
        return data.get("projects", []), ""

    def create_project(self, name: str, description: str = "") -> tuple[dict, str]:
        """Create a new Burp project. Returns project metadata."""
        payload = {"name": name}
        if description:
            payload["description"] = description
        return self._post("projects", payload)

    def load_project(self, project_id: str) -> tuple[dict, str]:
        """Load a Burp project by ID."""
        return self._get(f"projects/{project_id}")

    def delete_project(self, project_id: str) -> tuple[dict, str]:
        """Delete a Burp project by ID."""
        return self._delete(f"projects/{project_id}")

    # ══════════════════════════════════════════════════════════════════════════
    # Proxy traffic
    # ══════════════════════════════════════════════════════════════════════════

    def get_proxy_history(
        self,
        limit:  int = 1000,
        offset: int = 0,
    ) -> tuple[list, str]:
        """
        Fetch captured proxy HTTP history.
        Returns (items_list, error).
        """
        data, err = self._get(f"proxy/history?count={limit}&offset={offset}")
        if err:
            return [], err
        return data.get("messages", []), ""

    def get_proxy_config(self) -> tuple[dict, str]:
        """Fetch current proxy listener configuration."""
        return self._get("proxy/listeners")

    def set_proxy_intercept(self, enabled: bool) -> tuple[dict, str]:
        """Enable or disable proxy interception."""
        return self._post("proxy/intercept", {"enabled": enabled})

    def clear_proxy_history(self) -> tuple[dict, str]:
        """Clear all proxy history items."""
        return self._delete("proxy/history")

    # ══════════════════════════════════════════════════════════════════════════
    # Scanner / issues
    # ══════════════════════════════════════════════════════════════════════════

    def get_scan_issues(
        self,
        url_prefix: Optional[str] = None,
    ) -> tuple[list, str]:
        """
        Retrieve passive scan issues from Burp.
        Optionally filter by URL prefix.
        """
        path = "scanner/issues"
        if url_prefix:
            path += f"?urlPrefix={url_prefix}"
        data, err = self._get(path)
        if err:
            return [], err
        return data.get("issues", []), ""

    def get_issue_definitions(self) -> tuple[list, str]:
        """Fetch Burp's built-in issue type definitions."""
        data, err = self._get("scanner/issue-definitions")
        if err:
            return [], err
        return data.get("issueDefinitions", []), ""

    def start_scan(self, url: str, config: Optional[dict] = None) -> tuple[dict, str]:
        """Initiate a Burp active/passive scan against a URL."""
        payload: dict = {"urls": [url]}
        if config:
            payload["scanConfiguration"] = config
        return self._post("scanner/scans", payload)

    def get_scan_status(self, scan_id: str) -> tuple[dict, str]:
        """Check progress of a running scan."""
        return self._get(f"scanner/scans/{scan_id}")

    # ══════════════════════════════════════════════════════════════════════════
    # Session / cookies
    # ══════════════════════════════════════════════════════════════════════════

    def get_cookies(self, domain: Optional[str] = None) -> tuple[list, str]:
        """Retrieve cookies from the Burp cookie jar."""
        path = "cookies" + (f"?domain={domain}" if domain else "")
        data, err = self._get(path)
        if err:
            return [], err
        return data.get("cookies", []), ""

    def get_site_map(self, url_prefix: Optional[str] = None) -> tuple[list, str]:
        """
        Fetch the Burp site map (all observed URLs).
        Optionally filter by URL prefix.
        """
        path = "sitemap"
        if url_prefix:
            path += f"?urlPrefix={url_prefix}"
        data, err = self._get(path)
        if err:
            return [], err
        return data.get("items", []), ""

    # ══════════════════════════════════════════════════════════════════════════
    # Repeater (request replay)
    # ══════════════════════════════════════════════════════════════════════════

    def send_to_repeater(
        self,
        host:    str,
        port:    int,
        use_tls: bool,
        request: str,
    ) -> tuple[dict, str]:
        """Send a raw HTTP request to Burp Repeater."""
        payload = {
            "host":    host,
            "port":    port,
            "useTls":  use_tls,
            "request": request,
        }
        return self._post("repeater/requests", payload)

    def replay_request(self, request_id: str) -> tuple[dict, str]:
        """Re-issue a previously captured request via Burp Repeater."""
        return self._post(f"repeater/requests/{request_id}/send", {})

    # ══════════════════════════════════════════════════════════════════════════
    # Diagnostics
    # ══════════════════════════════════════════════════════════════════════════

    def get_diagnostics(self) -> dict:
        """
        Return a diagnostics snapshot for display / logging.
        Never raises — returns partial data on error.
        """
        ok, ping_err = self.ping()
        version, v_err = self.get_version() if ok else ({}, "")
        return {
            "reachable":   ok,
            "ping_error":  ping_err,
            "base_url":    self.base_url,
            "api_key_set": bool(self.api_key),
            "version":     version,
        }
