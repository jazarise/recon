"""
ReconX — Burp Issue Importer (Stage 18.1)

Imports Burp Suite passive scan findings and normalises them into
ReconX's standard finding models (SensitiveFinding, HeaderFinding,
Suggestion, ParsedFinding).

Burp passive findings include:
  - Missing security headers
  - Cookie attribute issues
  - TLS/SSL misconfigurations
  - Information disclosure
  - CORS misconfigurations
  - Clickjacking vulnerabilities
  - Open redirects (passive detection)
  - Content type mismatches

This module does NOT run active scans. Passive only — analysis of
already-captured traffic from the Burp proxy history.

Integration contract:
  importer = IssueImporter(client)
  findings = importer.import_findings(target_prefix="https://example.com")
  result.sensitive_findings.extend(findings.sensitive)
  result.header_findings.extend(findings.headers)
  result.suggestions.extend(findings.suggestions)
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Optional

from .burp_client import BurpClient

# Import ReconX finding models (relative from integrations package)
try:
    from ...models.findings import (
        HeaderFinding,
        SensitiveFinding,
        Suggestion,
    )
    from ...models.tool_result import ParsedFinding
except ImportError:
    # Fallback for standalone testing
    from dataclasses import dataclass as _dc

    @_dc
    class HeaderFinding:
        header: str; status: str; value: str = ""; risk: str = ""; recommendation: str = ""

    @_dc
    class SensitiveFinding:
        category: str; detail: str; url: str = ""; severity: str = "MEDIUM"

    @_dc
    class Suggestion:
        finding: str; risk: str; recommendation: str; severity: str = "MEDIUM"

    @_dc
    class ParsedFinding:
        finding_type: str; value: str; source: str = ""; confidence: float = 1.0; metadata: dict = field(default_factory=dict)


logger = logging.getLogger("reconx.integrations.burp.importer")


# ── Severity mapping from Burp to ReconX ─────────────────────────────────────

_SEVERITY_MAP = {
    "high":         "HIGH",
    "medium":       "MEDIUM",
    "low":          "LOW",
    "information":  "INFO",
    "false positive": "INFO",
}

# Burp issue type → ReconX category mapping
_ISSUE_CATEGORY_MAP: dict[str, tuple[str, str]] = {
    # (reconx_category, reconx_label)
    "Strict transport security not enforced":  ("header",      "HSTS not enforced"),
    "X-Frame-Options header":                  ("header",      "Clickjacking risk"),
    "X-Content-Type-Options header":           ("header",      "MIME sniffing risk"),
    "Content Security Policy":                 ("header",      "CSP misconfiguration"),
    "Cookie without HttpOnly flag":            ("cookie",      "Cookie missing HttpOnly"),
    "Cookie without Secure flag":              ("cookie",      "Cookie missing Secure flag"),
    "Cookie SameSite":                         ("cookie",      "Cookie SameSite issue"),
    "TLS":                                     ("tls",         "TLS misconfiguration"),
    "SSL":                                     ("tls",         "SSL issue"),
    "CORS":                                    ("cors",        "CORS misconfiguration"),
    "Information disclosure":                  ("disclosure",  "Information disclosure"),
    "Server software and technology":          ("disclosure",  "Server banner leak"),
    "Open redirect":                           ("redirect",    "Open redirect"),
    "Password submitted":                      ("credential",  "Password in cleartext"),
    "Frameable response":                      ("clickjack",   "Clickjackable page"),
}


@dataclass
class ImportedFindings:
    """Container for all normalised Burp findings."""
    headers:    list[HeaderFinding]    = field(default_factory=list)
    sensitive:  list[SensitiveFinding] = field(default_factory=list)
    suggestions: list[Suggestion]      = field(default_factory=list)
    raw_issues: list[dict]             = field(default_factory=list)
    total:      int = 0
    error:      str = ""

    def to_parsed_findings(self) -> list[ParsedFinding]:
        """Convert to generic ParsedFinding list for tool result compatibility."""
        findings = []
        for s in self.sensitive:
            findings.append(ParsedFinding(
                finding_type=s.category,
                value=s.detail,
                source="burp_suite",
                confidence=0.85,
                metadata={"url": s.url, "severity": s.severity},
            ))
        for h in self.headers:
            findings.append(ParsedFinding(
                finding_type="header_finding",
                value=f"{h.header}: {h.status}",
                source="burp_suite",
                confidence=0.9,
                metadata={"risk": h.risk, "recommendation": h.recommendation},
            ))
        return findings


class IssueImporter:
    """
    Imports and normalises Burp passive scan issues into ReconX finding models.

    Passive only — never triggers active scanning.
    All findings are enriched with remediation suggestions.
    """

    def __init__(self, client: BurpClient):
        self._client = client

    def import_findings(
        self,
        target_prefix: Optional[str] = None,
    ) -> ImportedFindings:
        """
        Pull passive findings from Burp and return normalised ImportedFindings.

        Args:
            target_prefix: URL prefix to filter findings (e.g. "https://example.com").
                           None = import all Burp findings.
        """
        result = ImportedFindings()

        issues, err = self._client.get_scan_issues(url_prefix=target_prefix)
        if err:
            result.error = f"Failed to fetch Burp issues: {err}"
            logger.warning("[IssueImporter] %s", result.error)
            return result

        result.raw_issues = issues
        result.total      = len(issues)

        for issue in issues:
            try:
                self._normalise_issue(issue, result)
            except Exception as exc:
                logger.debug("[IssueImporter] Skipping issue: %s", exc)

        logger.info(
            "[IssueImporter] Imported %d issues → %d headers, %d sensitive, %d suggestions",
            result.total,
            len(result.headers),
            len(result.sensitive),
            len(result.suggestions),
        )
        return result

    def import_site_map_findings(
        self,
        target_prefix: Optional[str] = None,
    ) -> list[str]:
        """
        Return all URLs observed in the Burp site map.
        Useful for supplementing endpoint discovery.
        """
        items, err = self._client.get_site_map(url_prefix=target_prefix)
        if err:
            logger.warning("[IssueImporter] Site map fetch failed: %s", err)
            return []
        return [item.get("url", "") for item in items if item.get("url")]

    # ══════════════════════════════════════════════════════════════════════════
    # Normalisation logic
    # ══════════════════════════════════════════════════════════════════════════

    def _normalise_issue(self, issue: dict, result: ImportedFindings) -> None:
        """Route a raw Burp issue dict to the appropriate finding model."""
        issue_type  = issue.get("type", "")
        issue_name  = issue.get("name", "")
        severity    = _SEVERITY_MAP.get(
            issue.get("severity", "").lower(), "MEDIUM"
        )
        url         = issue.get("host", "") + issue.get("path", "")
        detail      = issue.get("detail", "") or issue.get("issueDetail", "")
        background  = issue.get("background", "") or issue.get("issueBackground", "")
        remediation = issue.get("remediation", "") or issue.get("remediationBackground", "")

        category, label = self._categorise(issue_name)

        if category == "header":
            result.headers.append(self._make_header_finding(
                issue_name, severity, url, detail, remediation
            ))

        elif category in ("cookie", "tls", "cors", "disclosure", "redirect",
                          "credential", "clickjack"):
            result.sensitive.append(SensitiveFinding(
                category=category,
                detail=label + (f": {detail[:120]}" if detail else ""),
                url=url,
                severity=severity,
            ))

        else:
            # Generic finding → SensitiveFinding with category "other"
            result.sensitive.append(SensitiveFinding(
                category="burp_passive",
                detail=f"{issue_name}: {detail[:120]}" if detail else issue_name,
                url=url,
                severity=severity,
            ))

        # Always produce a Suggestion with remediation guidance
        if remediation or background:
            result.suggestions.append(Suggestion(
                finding=issue_name,
                risk=detail[:200] if detail else issue_name,
                recommendation=(remediation or background)[:250],
                severity=severity,
            ))

    def _categorise(self, issue_name: str) -> tuple[str, str]:
        """Map Burp issue name to (reconx_category, label) via prefix matching."""
        for key, (cat, label) in _ISSUE_CATEGORY_MAP.items():
            if key.lower() in issue_name.lower():
                return cat, label
        return "other", issue_name

    def _make_header_finding(
        self,
        name:        str,
        severity:    str,
        url:         str,
        detail:      str,
        remediation: str,
    ) -> HeaderFinding:
        """Build a HeaderFinding from a Burp header-related issue."""
        # Extract the header name from common Burp naming patterns
        header_name = "unknown"
        name_lower  = name.lower()

        if "strict transport" in name_lower:
            header_name = "strict-transport-security"
            status      = "missing"
        elif "x-frame" in name_lower:
            header_name = "x-frame-options"
            status      = "missing"
        elif "x-content-type" in name_lower:
            header_name = "x-content-type-options"
            status      = "missing"
        elif "content security" in name_lower:
            header_name = "content-security-policy"
            status      = "weak" if "unsafe" in detail.lower() else "missing"
        else:
            header_name = name.lower().replace(" ", "-")
            status      = "weak"

        risk_map = {
            "CRITICAL": "Critical security header issue",
            "HIGH":     "High-risk header misconfiguration",
            "MEDIUM":   "Security header misconfiguration",
            "LOW":      "Minor header issue",
            "INFO":     "Informational header finding",
        }

        return HeaderFinding(
            header=header_name,
            status=status,
            value=detail[:100] if detail else "",
            risk=risk_map.get(severity, "Security header issue"),
            recommendation=remediation[:200] if remediation else (
                f"Configure the {header_name} header on all responses."
            ),
        )
