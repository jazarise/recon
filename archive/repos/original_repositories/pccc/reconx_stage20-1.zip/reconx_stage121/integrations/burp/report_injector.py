"""
ReconX — Stage 18.1 Burp Report Injector

Injects a "Web Intelligence" HTML section into an existing ReconX report.

The section covers:
  1. Proxy & Session Summary     — connection status, session info, timing
  2. Captured Endpoints          — URL, method, status, category table
  3. Authentication Artefacts    — JWT/Bearer/API-key tokens with context
  4. Session Cookies             — cookie jar with security flag analysis
  5. Passive Security Findings   — headers, CORS, TLS, info disclosure
  6. Web Discovery               — login/admin/upload/OAuth/GraphQL/SPA

Usage:
    from reconx.integrations.burp.report_injector import inject_burp_section

    inject_burp_section(
        html_path  = "reports/reconx_example_com.html",
        burp_data  = burp_tool_result.data,     # from BurpIntelligenceLayer
        session    = session.to_dict(),         # BurpSession.to_dict()
        imported   = imported.to_dict(),        # ImportedFindings data
    )
"""
from __future__ import annotations

from html import escape
from pathlib import Path
from typing import Optional


# ── CSS ───────────────────────────────────────────────────────────────────────

_BURP_CSS = """
/* ── Stage 18.1 Web Intelligence ─── */
.burp-section { margin-top: 32px; }

.burp-status-bar {
  display: flex; gap: 12px; flex-wrap: wrap;
  align-items: center; margin-bottom: 20px;
  background: var(--bg2,#0c1420); border: 1px solid var(--border,#1a3050);
  border-left: 3px solid #00d4ff; border-radius: 6px; padding: 12px 20px;
  font-family: var(--font-mono, monospace); font-size: 12px;
}
.burp-status-bar .label { color: var(--dim,#5a7a9a); }
.burp-status-bar .value { color: #c8d8e8; font-weight: 600; margin-left: 4px; }
.burp-status-bar .ok    { color: #30d158; }
.burp-status-bar .fail  { color: #ff2d55; }
.burp-status-bar .active { color: #00d4ff; }

.burp-stats {
  display: grid; grid-template-columns: repeat(auto-fit, minmax(110px, 1fr));
  gap: 12px; margin-bottom: 24px;
}
.burp-stat {
  background: var(--bg2,#0c1420); border: 1px solid var(--border,#1a3050);
  border-radius: 6px; padding: 14px 10px; text-align: center;
}
.burp-stat .n {
  font-size: 28px; font-weight: 700;
  font-family: var(--font-mono, monospace); line-height: 1; margin-bottom: 4px;
}
.burp-stat .lbl {
  font-size: 10px; letter-spacing: 2px; text-transform: uppercase;
  color: var(--dim,#5a7a9a);
}

.burp-tbl-wrap { margin-bottom: 24px; }
.burp-tbl-title {
  font-size: 13px; font-weight: 600; letter-spacing: 2px;
  text-transform: uppercase; color: #00d4ff;
  border-bottom: 1px solid var(--border,#1a3050);
  padding-bottom: 8px; margin-bottom: 12px;
}
.burp-tbl { width: 100%; border-collapse: collapse; font-size: 12px; }
.burp-tbl th {
  font-size: 10px; letter-spacing: 1.5px; text-transform: uppercase;
  color: var(--dim,#5a7a9a); text-align: left;
  padding: 6px 10px; border-bottom: 1px solid var(--border,#1a3050);
}
.burp-tbl td {
  padding: 8px 10px; border-bottom: 1px solid rgba(26,48,80,0.4);
  font-family: var(--font-mono, monospace); vertical-align: top; word-break: break-all;
}
.burp-tbl tr:hover td { background: rgba(0,212,255,0.03); }
.burp-tbl tr:last-child td { border-bottom: none; }

.burp-method { display: inline-block; padding: 1px 6px; border-radius: 3px;
  font-size: 10px; font-weight: 700; letter-spacing: 1px; }
.m-get  { background:rgba(48,209,88,0.15); color:#30d158; }
.m-post { background:rgba(0,212,255,0.15); color:#00d4ff; }
.m-put  { background:rgba(255,214,10,0.15); color:#ffd60a; }
.m-del  { background:rgba(255,45,85,0.15);  color:#ff2d55; }
.m-other { background:rgba(100,100,100,0.2); color:#888; }

.burp-status-2xx { color: #30d158; }
.burp-status-3xx { color: #ffd60a; }
.burp-status-4xx { color: #ff6b35; }
.burp-status-5xx { color: #ff2d55; }

.burp-flag-ok   { color: #30d158; }
.burp-flag-miss { color: #ff2d55; }

.burp-cat { display:inline-block; padding:1px 6px; border-radius:10px;
  font-size:10px; background:rgba(0,212,255,0.1); color:#00d4ff;
  border:1px solid rgba(0,212,255,0.3); margin-right: 2px; }

.burp-tok-jwt    { color:#ff6b35; }
.burp-tok-bearer { color:#00d4ff; }
.burp-tok-apikey { color:#ffd60a; }

.burp-disc-grid {
  display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 12px; margin-top: 16px;
}
.burp-disc-card {
  background: var(--bg2,#0c1420); border: 1px solid var(--border,#1a3050);
  border-radius: 6px; padding: 12px;
}
.burp-disc-card .title {
  font-size: 10px; letter-spacing: 2px; text-transform: uppercase;
  color: var(--dim,#5a7a9a); margin-bottom: 8px;
}
.burp-disc-card .item {
  font-size: 11px; font-family: monospace;
  white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
  color: #c8d8e8; padding: 2px 0;
}
.burp-disc-card .empty { color: var(--dim,#5a7a9a); font-style: italic; font-size: 11px; }

.burp-empty { text-align:center; color:var(--dim,#5a7a9a);
  font-style:italic; padding:16px; }
"""


# ── HTML helpers ──────────────────────────────────────────────────────────────

def _method_badge(method: str) -> str:
    m  = method.upper()
    cls = {"GET": "m-get", "POST": "m-post", "PUT": "m-put",
           "DELETE": "m-del", "PATCH": "m-put"}.get(m, "m-other")
    return f'<span class="burp-method {cls}">{escape(m)}</span>'


def _status_class(code: int) -> str:
    if 200 <= code < 300:  return "burp-status-2xx"
    if 300 <= code < 400:  return "burp-status-3xx"
    if 400 <= code < 500:  return "burp-status-4xx"
    if code >= 500:        return "burp-status-5xx"
    return ""


def _flag(val) -> str:
    return '<span class="burp-flag-ok">✓</span>' if val else '<span class="burp-flag-miss">✗</span>'


def _stat(n: int, label: str, colour: str) -> str:
    return (
        f'<div class="burp-stat">'
        f'<div class="n" style="color:{colour}">{n}</div>'
        f'<div class="lbl">{escape(label)}</div>'
        f'</div>'
    )


def _cat_badges(cats: list[str]) -> str:
    return "".join(f'<span class="burp-cat">{escape(c)}</span>' for c in cats[:3])


def _disc_card(title: str, items: list[str], colour: str = "#00d4ff") -> str:
    if not items:
        body = '<div class="empty">None detected</div>'
    else:
        body = "".join(
            f'<div class="item" title="{escape(u)}">{escape(u[:55])}</div>'
            for u in items[:5]
        )
        if len(items) > 5:
            body += f'<div class="item" style="color:#5a7a9a">+{len(items)-5} more…</div>'
    return (
        f'<div class="burp-disc-card">'
        f'<div class="title" style="color:{colour}">{escape(title)}</div>'
        f'{body}</div>'
    )


# ══════════════════════════════════════════════════════════════════════════════
# Section builder
# ══════════════════════════════════════════════════════════════════════════════

def _build_burp_section(
    burp_data:  dict,
    session:    dict,
    imported:   Optional[dict] = None,
) -> str:
    """
    Build the full HTML block for the Web Intelligence section.
    """
    traffic  = burp_data.get("traffic", {})
    proxy    = burp_data.get("proxy", {})
    sess_d   = burp_data.get("session", session)
    issues_d = burp_data.get("issues", {})
    site_d   = burp_data.get("site_map", {})

    endpoints    = burp_data.get("endpoints",    traffic.get("endpoints",    []))
    api_routes   = burp_data.get("api_routes",   traffic.get("api_routes",   []))
    auth_tokens  = burp_data.get("auth_tokens",  traffic.get("auth_tokens",  []))
    cookies      = burp_data.get("cookies",      traffic.get("cookies",      []))
    sec_issues   = traffic.get("security_issues",  [])
    admin_portals = burp_data.get("admin_portals", traffic.get("admin_portals", []))
    login_pages  = burp_data.get("login_pages",   traffic.get("login_pages",  []))
    oauth_flows  = traffic.get("oauth_flows",  [])
    sso_pages    = traffic.get("sso_pages",    [])
    gql_eps      = traffic.get("graphql_endpoints", [])
    spa_routes   = traffic.get("spa_routes",   [])
    upload_forms = traffic.get("upload_forms", [])

    # ── Status bar ────────────────────────────────────────────────────────────
    api_ok  = proxy.get("running", False)
    api_cls = "ok" if api_ok else "fail"
    api_txt = "✓ active" if api_ok else "✗ not connected"
    proxy_url = proxy.get("url", "127.0.0.1:8080")
    sess_id   = sess_d.get("short_id", sess_d.get("session_id", "—"))[:8]
    duration  = sess_d.get("duration_s", 0)
    items     = sess_d.get("item_count", 0)

    status_bar = f"""
<div class="burp-status-bar">
  <span class="label">API:</span>
  <span class="{api_cls}">{api_txt}</span>
  &nbsp;|&nbsp;
  <span class="label">Proxy:</span>
  <span class="active">{escape(proxy_url)}</span>
  &nbsp;|&nbsp;
  <span class="label">Session:</span>
  <span class="value">{escape(sess_id)}</span>
  &nbsp;|&nbsp;
  <span class="label">Items:</span>
  <span class="value">{items}</span>
  &nbsp;|&nbsp;
  <span class="label">Duration:</span>
  <span class="value">{duration:.1f}s</span>
</div>"""

    # ── Stats row ─────────────────────────────────────────────────────────────
    stats_html = (
        '<div class="burp-stats">'
        + _stat(traffic.get("total_requests", 0),  "Requests",   "#00d4ff")
        + _stat(len(endpoints),                     "Endpoints",  "#30d158")
        + _stat(len(api_routes),                    "API Routes", "#ffd60a")
        + _stat(len(auth_tokens),                   "Auth Tokens","#ff6b35")
        + _stat(len(cookies),                       "Cookies",    "#9b59b6")
        + _stat(issues_d.get("total", len(sec_issues)), "Issues", "#ff2d55")
        + _stat(site_d.get("url_count", 0),         "Site Map",  "#00ffcc")
        + '</div>'
    )

    # ── Endpoints table ───────────────────────────────────────────────────────
    if endpoints:
        ep_rows = "".join(
            f'<tr>'
            f'<td>{_method_badge(ep.get("method","GET"))}</td>'
            f'<td style="word-break:break-all">{escape(ep.get("url","")[:100])}</td>'
            f'<td class="{_status_class(ep.get("status",0))}">{ep.get("status","—")}</td>'
            f'<td>{_cat_badges(ep.get("categories",[]))}</td>'
            f'</tr>'
            for ep in endpoints[:30]
        )
        if len(endpoints) > 30:
            ep_rows += f'<tr><td colspan="4" style="text-align:center;color:#5a7a9a;font-style:italic">+{len(endpoints)-30} more endpoints</td></tr>'
    else:
        ep_rows = '<tr><td colspan="4" class="burp-empty">No endpoints captured</td></tr>'

    endpoints_tbl = f"""
<div class="burp-tbl-wrap">
  <div class="burp-tbl-title">🛰️ Captured Endpoints</div>
  <table class="burp-tbl">
    <thead><tr><th>Method</th><th>URL</th><th>Status</th><th>Type</th></tr></thead>
    <tbody>{ep_rows}</tbody>
  </table>
</div>"""

    # ── Auth tokens table ─────────────────────────────────────────────────────
    if auth_tokens:
        tok_rows = "".join(
            f'<tr>'
            f'<td class="burp-tok-{escape(t.get("type","").replace("-",""))}">'
            f'{escape(t.get("type","—"))}</td>'
            f'<td>{escape(str(t.get("value","—"))[:60])}</td>'
            f'<td style="color:#5a7a9a">{escape(t.get("url","—")[:60])}</td>'
            f'</tr>'
            for t in auth_tokens[:15]
        )
    else:
        tok_rows = '<tr><td colspan="3" class="burp-empty">No auth tokens captured</td></tr>'

    auth_tbl = f"""
<div class="burp-tbl-wrap">
  <div class="burp-tbl-title">🔑 Authentication Artefacts</div>
  <table class="burp-tbl">
    <thead><tr><th>Type</th><th>Value (truncated)</th><th>Observed At</th></tr></thead>
    <tbody>{tok_rows}</tbody>
  </table>
</div>"""

    # ── Cookies table ─────────────────────────────────────────────────────────
    seen_ck = set()
    ck_rows_list = []
    for ck in cookies:
        key = f"{ck.get('name')}@{ck.get('host')}"
        if key in seen_ck:
            continue
        seen_ck.add(key)
        ck_rows_list.append(
            f'<tr>'
            f'<td>{escape(ck.get("name","—"))}</td>'
            f'<td style="color:#5a7a9a">{escape(ck.get("host","—"))}</td>'
            f'<td>{_flag(ck.get("secure"))}</td>'
            f'<td>{_flag(ck.get("http_only"))}</td>'
            f'<td style="color:#ffd60a">{escape(ck.get("same_site","—") or "—")}</td>'
            f'</tr>'
        )
    if not ck_rows_list:
        ck_rows_list = ['<tr><td colspan="5" class="burp-empty">No cookies captured</td></tr>']

    cookie_tbl = f"""
<div class="burp-tbl-wrap">
  <div class="burp-tbl-title">🍪 Session Cookies</div>
  <table class="burp-tbl">
    <thead><tr>
      <th>Name</th><th>Host</th>
      <th style="text-align:center">Secure</th>
      <th style="text-align:center">HttpOnly</th>
      <th>SameSite</th>
    </tr></thead>
    <tbody>{"".join(ck_rows_list[:20])}</tbody>
  </table>
</div>"""

    # ── Passive issues table ──────────────────────────────────────────────────
    if sec_issues:
        iss_rows = "".join(
            f'<tr>'
            f'<td style="color:#ff6b35">{escape(i.get("type","—"))}</td>'
            f'<td>{escape(i.get("detail", i.get("header","—"))[:80])}</td>'
            f'<td style="color:#5a7a9a">{escape(i.get("url","—")[:60])}</td>'
            f'</tr>'
            for i in sec_issues[:20]
        )
    else:
        iss_rows = '<tr><td colspan="3" class="burp-empty" style="color:#30d158">✅ No passive issues detected</td></tr>'

    issues_tbl = f"""
<div class="burp-tbl-wrap">
  <div class="burp-tbl-title">⚠️ Passive Security Findings</div>
  <table class="burp-tbl">
    <thead><tr><th>Type</th><th>Detail</th><th>URL</th></tr></thead>
    <tbody>{iss_rows}</tbody>
  </table>
</div>"""

    # ── Web discovery grid ────────────────────────────────────────────────────
    disc_grid = (
        '<div class="burp-disc-grid">'
        + _disc_card("Login Pages",   login_pages,   "#ffd60a")
        + _disc_card("Admin Portals", admin_portals, "#ff2d55")
        + _disc_card("Upload Forms",  upload_forms,  "#ff6b35")
        + _disc_card("OAuth / Token", oauth_flows,   "#00d4ff")
        + _disc_card("SSO Pages",     sso_pages,     "#9b59b6")
        + _disc_card("GraphQL",       gql_eps,       "#30d158")
        + _disc_card("SPA Routes",    spa_routes,    "#00ffcc")
        + _disc_card("API Routes",    api_routes[:5],"#ffd60a")
        + '</div>'
    )

    disc_section = f"""
<div class="burp-tbl-wrap">
  <div class="burp-tbl-title">🔍 Web Discovery</div>
  {disc_grid}
</div>"""

    # ── Assemble ──────────────────────────────────────────────────────────────
    return f"""
<div class="burp-section section">
  <h2 class="section-title"><span class="icon">🌐</span> Web Intelligence
    <span class="model-tag">Burp Suite</span>
  </h2>
  {status_bar}
  {stats_html}
  {endpoints_tbl}
  {auth_tbl}
  {cookie_tbl}
  {issues_tbl}
  {disc_section}
</div>"""


# ══════════════════════════════════════════════════════════════════════════════
# Public injection API
# ══════════════════════════════════════════════════════════════════════════════

def inject_burp_section(
    html_path:  str,
    burp_data:  dict,
    session:    Optional[dict]  = None,
    imported:   Optional[dict]  = None,
) -> bool:
    """
    Inject a Web Intelligence section into an existing ReconX HTML report.

    Inserts just before </body>. If the report doesn't exist, no-op.

    Args:
        html_path:  Path to the existing HTML report.
        burp_data:  Output data dict from BurpIntelligenceLayer (ToolRunResult.data).
        session:    BurpSession.to_dict() — optional, used if not in burp_data.
        imported:   ImportedFindings data — optional enrichment.

    Returns:
        True on success, False on any error.
    """
    path = Path(html_path)
    if not path.exists():
        return False

    try:
        html = path.read_text(encoding="utf-8")

        # Inject CSS into <head> if not already present
        if "burp-section" not in html:
            html = html.replace(
                "</style>",
                f"{_BURP_CSS}\n</style>",
                1,
            )

        # Build and inject the section
        section = _build_burp_section(
            burp_data=burp_data,
            session=session or burp_data.get("session", {}),
            imported=imported,
        )

        # Insert before </body>
        if "</body>" in html:
            html = html.replace("</body>", f"{section}\n</body>", 1)
        else:
            html += section

        path.write_text(html, encoding="utf-8")
        return True

    except Exception:
        return False
