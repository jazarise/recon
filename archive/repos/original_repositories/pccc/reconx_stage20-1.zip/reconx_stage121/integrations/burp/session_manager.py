"""
ReconX — Burp Session Manager (Stage 18.1)

Manages named capture sessions — discrete windows of proxy traffic
collection tied to a specific target and scan run.

A session encapsulates:
  - A time-bounded window of captured proxy traffic
  - The BurpProject it belongs to
  - Traffic statistics and parsed summary
  - Serialisation to/from local cache for resume support

Session lifecycle:
  start() → [traffic captured] → pause() → resume() → stop() → saved

Sessions are referenced by a short ID (e.g. "abc12") so the CLI can
issue: reconx burp replay abc12
"""
from __future__ import annotations

import json
import logging
import time
import uuid
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Optional

from .burp_client     import BurpClient
from .project_manager import BurpProject
from .traffic_parser  import TrafficParser, TrafficSummary

logger = logging.getLogger("reconx.integrations.burp.session")

_SESSION_CACHE = Path(__file__).resolve().parents[3] / "cache" / "burp" / "sessions"


# ── Session state machine ─────────────────────────────────────────────────────

class SessionState:
    ACTIVE   = "active"
    PAUSED   = "paused"
    STOPPED  = "stopped"
    RESUMED  = "resumed"
    ERROR    = "error"


@dataclass
class BurpSession:
    """
    Represents one bounded traffic capture session.

    Short session_id is 8 hex characters for ergonomic CLI use.
    """
    session_id:    str
    target:        str
    project_id:    str
    state:         str   = SessionState.ACTIVE
    started_at:    float = field(default_factory=time.time)
    stopped_at:    float = 0.0
    paused_at:     float = 0.0
    resumed_at:    float = 0.0
    error:         str   = ""

    # Traffic snapshot taken at stop time
    traffic_summary: dict = field(default_factory=dict)

    # Proxy history item IDs captured during this session
    # (used to scope replays to this session's traffic)
    item_ids: list[str] = field(default_factory=list)

    # Baseline item count at session start (to identify new items)
    baseline_count: int = 0

    @property
    def duration_s(self) -> float:
        end = self.stopped_at or time.time()
        return max(0.0, end - self.started_at)

    @property
    def is_active(self) -> bool:
        return self.state in (SessionState.ACTIVE, SessionState.RESUMED)

    @property
    def short_id(self) -> str:
        return self.session_id[:8]

    @property
    def cache_path(self) -> Path:
        return _SESSION_CACHE / f"{self.session_id}.json"

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "BurpSession":
        fields = {k for k in cls.__dataclass_fields__}
        return cls(**{k: v for k, v in d.items() if k in fields})


class SessionManager:
    """
    Creates, tracks, pauses, resumes, and stops Burp capture sessions.

    Usage:
        sm      = SessionManager(client)
        session = sm.start(project, target="example.com")
        # ... traffic flows through Burp proxy ...
        sm.stop(session)
        print(session.traffic_summary)
    """

    def __init__(self, client: BurpClient):
        self._client  = client
        self._parser  = TrafficParser()
        _SESSION_CACHE.mkdir(parents=True, exist_ok=True)

        # In-memory registry of active sessions this process knows about
        self._active: dict[str, BurpSession] = {}

    # ══════════════════════════════════════════════════════════════════════════
    # Lifecycle
    # ══════════════════════════════════════════════════════════════════════════

    def start(
        self,
        project: BurpProject,
        target:  str = "",
    ) -> tuple[Optional[BurpSession], str]:
        """
        Start a new capture session for a project.

        Records the current proxy history size as a baseline so we can
        distinguish traffic captured during this session from prior history.
        """
        # Record current history length as baseline
        history, err = self._client.get_proxy_history(limit=1, offset=0)
        if err:
            logger.warning("[SessionManager] Could not read baseline: %s", err)

        session = BurpSession(
            session_id=uuid.uuid4().hex,
            target=target or project.target,
            project_id=project.project_id,
            state=SessionState.ACTIVE,
            baseline_count=len(history),
        )
        self._active[session.session_id] = session
        self._save(session)

        logger.info(
            "[SessionManager] Started session %s for %s",
            session.short_id, session.target,
        )
        return session, ""

    def pause(self, session: BurpSession) -> str:
        """
        Pause an active session without stopping it.
        Traffic continues flowing through the proxy; we just mark the timestamp.
        """
        if not session.is_active:
            return f"Session {session.short_id} is not active (state={session.state})"
        session.state    = SessionState.PAUSED
        session.paused_at = time.time()
        self._save(session)
        logger.info("[SessionManager] Paused session %s", session.short_id)
        return ""

    def resume(self, session_id: str) -> tuple[Optional[BurpSession], str]:
        """
        Resume a paused or stopped session by ID (full or short).
        """
        session = self._find(session_id)
        if session is None:
            return None, f"Session '{session_id}' not found in cache."

        if session.state == SessionState.ACTIVE:
            return session, ""   # already active, idempotent

        session.state      = SessionState.RESUMED
        session.resumed_at = time.time()
        self._active[session.session_id] = session
        self._save(session)
        logger.info("[SessionManager] Resumed session %s", session.short_id)
        return session, ""

    def stop(self, session: BurpSession) -> tuple[BurpSession, str]:
        """
        Stop a session, collect its traffic, parse it, and save results.
        Returns the updated session with traffic_summary populated.
        """
        session.state      = SessionState.STOPPED
        session.stopped_at = time.time()

        # Collect all traffic since baseline
        summary, err = self._collect_traffic(session)
        if err:
            session.error = err
            logger.warning("[SessionManager] Traffic collection partial: %s", err)

        session.traffic_summary = summary.to_dict() if summary else {}

        self._save(session)
        self._active.pop(session.session_id, None)
        logger.info(
            "[SessionManager] Stopped session %s — %d requests captured",
            session.short_id,
            session.traffic_summary.get("total_requests", 0),
        )
        return session, err

    # ══════════════════════════════════════════════════════════════════════════
    # Listing and lookup
    # ══════════════════════════════════════════════════════════════════════════

    def list_sessions(
        self,
        target:  Optional[str] = None,
        state:   Optional[str] = None,
    ) -> list[BurpSession]:
        """
        Return all cached sessions, optionally filtered.
        Sorted newest-first.
        """
        sessions = []
        for f in _SESSION_CACHE.glob("*.json"):
            try:
                data = json.loads(f.read_text())
                s    = BurpSession.from_dict(data)
                if target and s.target != target:
                    continue
                if state and s.state != state:
                    continue
                sessions.append(s)
            except Exception as exc:
                logger.debug("[SessionManager] Skipping corrupt session: %s", exc)

        return sorted(sessions, key=lambda s: s.started_at, reverse=True)

    def get_session(self, session_id: str) -> Optional[BurpSession]:
        """Fetch a session by full or short ID."""
        return self._find(session_id)

    def get_traffic_summary(
        self,
        session: BurpSession,
    ) -> tuple[Optional[TrafficSummary], str]:
        """
        Re-parse traffic for a session (or return cached summary).
        Useful for re-analysis after the session is stopped.
        """
        return self._collect_traffic(session)

    # ══════════════════════════════════════════════════════════════════════════
    # Internal helpers
    # ══════════════════════════════════════════════════════════════════════════

    def _collect_traffic(
        self,
        session: BurpSession,
    ) -> tuple[Optional[TrafficSummary], str]:
        """
        Fetch proxy history items captured since session start and parse them.
        Uses baseline_count to isolate session-specific traffic.
        """
        items, err = self._client.get_proxy_history(limit=5000)
        if err:
            return None, f"Could not fetch proxy history: {err}"

        # Items newer than baseline (Burp history is newest-last)
        session_items = items[session.baseline_count:]
        session.item_ids = [str(i.get("id", "")) for i in session_items]

        if not session_items:
            logger.debug("[SessionManager] No new traffic for session %s", session.short_id)
            return TrafficSummary(), ""

        summary = self._parser.parse_history(session_items)
        return summary, ""

    def _save(self, session: BurpSession) -> None:
        try:
            session.cache_path.write_text(json.dumps(session.to_dict(), indent=2))
        except Exception as exc:
            logger.debug("[SessionManager] Save failed: %s", exc)

    def _find(self, session_id: str) -> Optional[BurpSession]:
        """Find by full UUID or first 8 chars."""
        # Check in-memory first
        if session_id in self._active:
            return self._active[session_id]

        # Search cache files
        for f in _SESSION_CACHE.glob("*.json"):
            stem = f.stem
            if stem == session_id or stem.startswith(session_id):
                try:
                    return BurpSession.from_dict(json.loads(f.read_text()))
                except Exception:
                    return None
        return None
