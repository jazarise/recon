"""
ReconX — Burp Traffic Intelligence Parser (Stage 18.1)

Parses raw Burp proxy history into structured ReconX intelligence.

Extracts from every request/response pair:
  - URLs and hidden endpoints
  - API routes (REST, GraphQL, RPC)
  - Auth artefacts (JWTs, Bearer tokens, cookies, API keys)
  - Interesting headers (CORS, CSP, server banners)
  - Form parameters and query parameters
  - Redirect chains
  - SPA route patterns (pushState, hash-routes)
  - Web discovery signals (login pages, admin portals, upload forms)

Design: stateless functions operating on raw Burp message dicts.
All heavy logic lives here; burp_client only does HTTP.
"""
from __future__ import annotations

import base64
import logging
import re
from dataclasses import dataclass, field
from typing import Optional
from urllib.parse import parse_qs, urlparse, urljoin

logger = logging.getLogger("reconx.integrations.burp.parser")

# ── Regex patterns ────────────────────────────────────────────────────────────

_RE_JWT = re.compile(
    r"eyJ[A-Za-z0-9_-]{10,}\.eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}"
)
_RE_BEARER   = re.compile(r"Bearer\s+([A-Za-z0-9\-_\.]+)", re.I)
_RE_API_KEY  = re.compile(
    r"(?:api[_-]?key|apikey|x-api-key|token)[=:\s]+([A-Za-z0-9\-_]{16,})",
    re.I,
)
_RE_GRAPHQL  = re.compile(r"graphql|gql", re.I)
_RE_OAUTH    = re.compile(r"oauth|authorize\?|access_token|code=", re.I)
_RE_SSO      = re.compile(r"saml|sso|cas|openid|oidc", re.I)
_RE_UPLOAD   = re.compile(r"multipart/form-data|content-type.*upload", re.I)

# Patterns that signal interesting endpoints
_ENDPOINT_SIGNALS: list[tuple[str, str, str]] = [
    # (regex, category, label)
    (r"/admin",                "admin",   "Admin portal"),
    (r"/login|/signin|/auth",  "auth",    "Login page"),
    (r"/api/|/v\d+/",         "api",     "API route"),
    (r"graphql",               "graphql", "GraphQL endpoint"),
    (r"/upload|/file",         "upload",  "Upload form"),
    (r"/oauth|/token",         "oauth",   "OAuth/token endpoint"),
    (r"/sso|/saml",            "sso",     "SSO endpoint"),
    (r"/dashboard|/console",   "admin",   "Dashboard/console"),
    (r"/swagger|/openapi",     "api",     "API docs"),
    (r"\.json$|\.xml$",        "data",    "Data endpoint"),
    (r"/health|/status|/ping", "infra",   "Health/status endpoint"),
    (r"/debug|/__debug__",     "debug",   "Debug endpoint"),
    (r"/metrics|/prometheus",  "infra",   "Metrics endpoint"),
]

# Security headers that should be present; absence is a finding
_REQUIRED_SECURITY_HEADERS = {
    "strict-transport-security": "HSTS missing",
    "x-frame-options":           "Clickjacking risk (no X-Frame-Options)",
    "x-content-type-options":    "MIME sniffing risk (no X-Content-Type-Options)",
    "content-security-policy":   "CSP missing",
    "x-xss-protection":          "XSS protection header absent",
}

# Headers that reveal server information
_INFO_DISCLOSURE_HEADERS = {
    "server", "x-powered-by", "x-aspnet-version",
    "x-aspnetmvc-version", "x-generator", "x-php-version",
}


# ── Data structures ───────────────────────────────────────────────────────────

@dataclass
class ParsedRequest:
    """Normalised representation of one Burp proxy history item."""
    url:          str
    method:       str
    host:         str
    path:         str
    query:        dict[str, list[str]]  # parsed query params
    req_headers:  dict[str, str]
    req_body:     str
    resp_headers: dict[str, str]
    resp_body:    str
    status_code:  int
    content_type: str
    duration_ms:  int  = 0

    # ── Derived signals (populated by classifier) ─────────────────────────────
    endpoint_categories: list[str]              = field(default_factory=list)
    auth_tokens:         list["AuthToken"]      = field(default_factory=list)
    cookies:             list["CookieInfo"]     = field(default_factory=list)
    parameters:          list["ParameterInfo"]  = field(default_factory=list)
    redirect_chain:      list[str]              = field(default_factory=list)
    is_api_call:         bool = False
    is_graphql:          bool = False
    is_oauth_flow:       bool = False


@dataclass
class AuthToken:
    token_type:  str   # "jwt" | "bearer" | "api_key" | "session_cookie"
    value:       str   # raw token value
    location:    str   # "header" | "cookie" | "body" | "query"
    header_name: str = ""
    decoded:     dict = field(default_factory=dict)


@dataclass
class CookieInfo:
    name:      str
    value:     str
    domain:    str   = ""
    path:      str   = "/"
    secure:    bool  = False
    http_only: bool  = False
    same_site: str   = ""
    session:   bool  = False


@dataclass
class ParameterInfo:
    name:     str
    value:    str
    location: str  # "query" | "body" | "header" | "cookie"
    param_type: str = "string"  # "string" | "json" | "xml"


@dataclass
class TrafficSummary:
    """Aggregated intelligence from a full proxy history session."""
    total_requests:  int = 0
    unique_hosts:    set[str] = field(default_factory=set)
    endpoints:       list[dict] = field(default_factory=list)    # {url, method, category}
    api_routes:      list[str]  = field(default_factory=list)
    graphql_endpoints: list[str] = field(default_factory=list)
    auth_tokens:     list[dict] = field(default_factory=list)
    cookies:         list[dict] = field(default_factory=list)
    parameters:      list[dict] = field(default_factory=list)
    security_issues: list[dict] = field(default_factory=list)    # missing headers, etc.
    info_disclosure: list[dict] = field(default_factory=list)    # server banners, etc.
    interesting_urls: list[str] = field(default_factory=list)
    redirect_chains: list[list[str]] = field(default_factory=list)
    oauth_flows:     list[str] = field(default_factory=list)
    sso_pages:       list[str] = field(default_factory=list)
    upload_forms:    list[str] = field(default_factory=list)
    admin_portals:   list[str] = field(default_factory=list)
    login_pages:     list[str] = field(default_factory=list)
    spa_routes:      list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "total_requests":     self.total_requests,
            "unique_hosts":       sorted(self.unique_hosts),
            "endpoints":          self.endpoints,
            "api_routes":         self.api_routes,
            "graphql_endpoints":  self.graphql_endpoints,
            "auth_tokens":        self.auth_tokens,
            "cookies":            self.cookies,
            "parameters":         self.parameters,
            "security_issues":    self.security_issues,
            "info_disclosure":    self.info_disclosure,
            "interesting_urls":   self.interesting_urls,
            "redirect_chains":    self.redirect_chains,
            "oauth_flows":        self.oauth_flows,
            "sso_pages":          self.sso_pages,
            "upload_forms":       self.upload_forms,
            "admin_portals":      self.admin_portals,
            "login_pages":        self.login_pages,
            "spa_routes":         self.spa_routes,
        }


# ══════════════════════════════════════════════════════════════════════════════
# Core parser
# ══════════════════════════════════════════════════════════════════════════════

class TrafficParser:
    """
    Converts raw Burp proxy history items into structured TrafficSummary.

    Burp proxy history items are dicts with keys:
      id, host, port, protocol, method, path, extension,
      request (base64), response (base64), status, responseLength, ...
    """

    def parse_history(self, items: list[dict]) -> TrafficSummary:
        """
        Parse a list of Burp proxy history items.
        Returns a TrafficSummary with all extracted intelligence.
        """
        summary = TrafficSummary()
        seen_endpoints: set[str] = set()

        for raw in items:
            try:
                pr = self._parse_item(raw)
                summary.total_requests += 1
                summary.unique_hosts.add(pr.host)

                self._extract_endpoints(pr, summary, seen_endpoints)
                self._extract_auth(pr, summary)
                self._extract_cookies(pr, summary)
                self._extract_parameters(pr, summary)
                self._check_security_headers(pr, summary)
                self._check_info_disclosure(pr, summary)
                self._extract_redirects(pr, summary)
                self._classify_page_type(pr, summary)

            except Exception as exc:
                logger.debug("[TrafficParser] Skipping item: %s", exc)

        return summary

    # ══════════════════════════════════════════════════════════════════════════
    # Item-level parsing
    # ══════════════════════════════════════════════════════════════════════════

    def _parse_item(self, raw: dict) -> ParsedRequest:
        """Convert one raw Burp history item into a ParsedRequest."""
        host     = raw.get("host", "")
        proto    = raw.get("protocol", "https")
        method   = raw.get("method", "GET").upper()
        path     = raw.get("path", "/")
        url      = f"{proto}://{host}{path}"
        parsed   = urlparse(url)

        req_raw  = _b64_decode(raw.get("request", ""))
        resp_raw = _b64_decode(raw.get("response", ""))

        req_headers, req_body   = _split_http_message(req_raw)
        resp_headers, resp_body = _split_http_message(resp_raw)

        status = _parse_status(resp_raw)

        return ParsedRequest(
            url          = url,
            method       = method,
            host         = host,
            path         = parsed.path,
            query        = parse_qs(parsed.query),
            req_headers  = req_headers,
            req_body     = req_body,
            resp_headers = resp_headers,
            resp_body    = resp_body,
            status_code  = status,
            content_type = resp_headers.get("content-type", ""),
            duration_ms  = raw.get("time", 0),
        )

    # ══════════════════════════════════════════════════════════════════════════
    # Extraction routines
    # ══════════════════════════════════════════════════════════════════════════

    def _extract_endpoints(
        self,
        pr:             ParsedRequest,
        summary:        TrafficSummary,
        seen:           set[str],
    ) -> None:
        key = f"{pr.method}:{pr.url}"
        if key in seen:
            return
        seen.add(key)

        categories = []
        for pattern, category, label in _ENDPOINT_SIGNALS:
            if re.search(pattern, pr.url, re.I):
                categories.append(category)
                if category == "api":
                    _add_unique(summary.api_routes, pr.url)
                if category == "graphql":
                    _add_unique(summary.graphql_endpoints, pr.url)

        summary.endpoints.append({
            "url":        pr.url,
            "method":     pr.method,
            "status":     pr.status_code,
            "categories": categories,
        })

        if categories or pr.status_code in (200, 201, 301, 302):
            _add_unique(summary.interesting_urls, pr.url)

    def _extract_auth(self, pr: ParsedRequest, summary: TrafficSummary) -> None:
        combined = (
            pr.req_body
            + " ".join(f"{k}: {v}" for k, v in pr.req_headers.items())
        )

        # JWTs
        for jwt in _RE_JWT.findall(combined):
            summary.auth_tokens.append({
                "type":    "jwt",
                "value":   jwt[:80] + "…",
                "url":     pr.url,
                "decoded": _decode_jwt(jwt),
            })

        # Bearer tokens
        for token in _RE_BEARER.findall(combined):
            summary.auth_tokens.append({
                "type":  "bearer",
                "value": token[:60] + "…",
                "url":   pr.url,
            })

        # API keys (header-style)
        for key in _RE_API_KEY.findall(combined):
            summary.auth_tokens.append({
                "type":  "api_key",
                "value": key[:30] + "…",
                "url":   pr.url,
            })

        # OAuth flows
        if _RE_OAUTH.search(pr.url) or _RE_OAUTH.search(pr.req_body):
            _add_unique(summary.oauth_flows, pr.url)

    def _extract_cookies(self, pr: ParsedRequest, summary: TrafficSummary) -> None:
        """Parse Set-Cookie response headers."""
        cookie_header = pr.resp_headers.get("set-cookie", "")
        if not cookie_header:
            return

        for part in cookie_header.split(","):
            name_val = part.strip().split(";")[0]
            if "=" not in name_val:
                continue
            name, _, value = name_val.partition("=")
            directives      = [d.strip().lower() for d in part.split(";")[1:]]

            summary.cookies.append({
                "name":      name.strip(),
                "value":     value[:20] + "…" if len(value) > 20 else value,
                "host":      pr.host,
                "secure":    "secure" in directives,
                "http_only": "httponly" in directives,
                "same_site": next(
                    (d.split("=")[-1] for d in directives if d.startswith("samesite")),
                    "",
                ),
            })

    def _extract_parameters(self, pr: ParsedRequest, summary: TrafficSummary) -> None:
        """Extract query and body parameters."""
        for name, values in pr.query.items():
            summary.parameters.append({
                "name":     name,
                "value":    values[0][:30] if values else "",
                "location": "query",
                "url":      pr.url,
            })

        # Simple key=value body params
        if "application/x-www-form-urlencoded" in pr.content_type.lower():
            for name, values in parse_qs(pr.req_body).items():
                summary.parameters.append({
                    "name":     name,
                    "value":    values[0][:30] if values else "",
                    "location": "body",
                    "url":      pr.url,
                })

    def _check_security_headers(
        self, pr: ParsedRequest, summary: TrafficSummary
    ) -> None:
        """Flag missing security headers on HTML responses."""
        if "text/html" not in pr.content_type:
            return
        if pr.status_code not in range(200, 400):
            return

        lower_headers = {k.lower(): v for k, v in pr.resp_headers.items()}

        for header, issue in _REQUIRED_SECURITY_HEADERS.items():
            if header not in lower_headers:
                summary.security_issues.append({
                    "type":   "missing_header",
                    "header": header,
                    "detail": issue,
                    "url":    pr.url,
                })

        # CORS check: overly permissive ACAO
        acao = lower_headers.get("access-control-allow-origin", "")
        if acao == "*":
            summary.security_issues.append({
                "type":   "cors",
                "header": "access-control-allow-origin",
                "detail": "CORS wildcard (*) — any origin can read responses",
                "url":    pr.url,
            })

    def _check_info_disclosure(
        self, pr: ParsedRequest, summary: TrafficSummary
    ) -> None:
        """Detect server banners and technology fingerprints."""
        lower_headers = {k.lower(): v for k, v in pr.resp_headers.items()}

        for h in _INFO_DISCLOSURE_HEADERS:
            if h in lower_headers:
                summary.info_disclosure.append({
                    "header": h,
                    "value":  lower_headers[h],
                    "url":    pr.url,
                })

    def _extract_redirects(
        self, pr: ParsedRequest, summary: TrafficSummary
    ) -> None:
        """Capture redirect chains from 3xx responses."""
        if pr.status_code not in (301, 302, 303, 307, 308):
            return
        location = pr.resp_headers.get("location", "")
        if location:
            summary.redirect_chains.append([pr.url, location])

    def _classify_page_type(
        self, pr: ParsedRequest, summary: TrafficSummary
    ) -> None:
        """Classify page type for web discovery summary."""
        url = pr.url.lower()

        if re.search(r"/login|/signin|/auth|/logon", url):
            _add_unique(summary.login_pages, pr.url)
        if re.search(r"/admin|/administrator|/manage|/console|/dashboard", url):
            _add_unique(summary.admin_portals, pr.url)
        if re.search(r"/upload|/file|multipart", url):
            _add_unique(summary.upload_forms, pr.url)
        if re.search(r"/sso|/saml|/cas", url):
            _add_unique(summary.sso_pages, pr.url)
        if re.search(r"/oauth|/authorize|/token", url):
            _add_unique(summary.oauth_flows, pr.url)

        # SPA route detection from JS pushState / hash fragments
        if "#/" in pr.url or re.search(r"/app/|/spa/|/ng/", url):
            _add_unique(summary.spa_routes, pr.url)


# ══════════════════════════════════════════════════════════════════════════════
# Utility functions
# ══════════════════════════════════════════════════════════════════════════════

def _b64_decode(data: str) -> str:
    """Safe base64 decode; returns empty string on failure."""
    try:
        return base64.b64decode(data).decode("utf-8", errors="replace")
    except Exception:
        return data  # might already be plain text


def _split_http_message(raw: str) -> tuple[dict[str, str], str]:
    """Split raw HTTP message into (headers_dict, body_str)."""
    headers: dict[str, str] = {}
    body    = ""

    if "\r\n\r\n" in raw:
        header_block, _, body = raw.partition("\r\n\r\n")
    elif "\n\n" in raw:
        header_block, _, body = raw.partition("\n\n")
    else:
        header_block = raw

    for line in header_block.splitlines()[1:]:  # skip request/status line
        if ":" in line:
            k, _, v = line.partition(":")
            headers[k.strip().lower()] = v.strip()

    return headers, body


def _parse_status(raw_response: str) -> int:
    """Extract HTTP status code from raw response."""
    try:
        first_line = raw_response.split("\n", 1)[0].strip()
        # e.g. "HTTP/1.1 200 OK"
        return int(first_line.split()[1])
    except (IndexError, ValueError):
        return 0


def _decode_jwt(token: str) -> dict:
    """Safely decode JWT payload (no verification)."""
    try:
        parts   = token.split(".")
        payload = parts[1] + "=="   # pad
        decoded = base64.urlsafe_b64decode(payload)
        import json
        return json.loads(decoded)
    except Exception:
        return {}


def _add_unique(lst: list, value: str) -> None:
    """Append value to list only if not already present."""
    if value not in lst:
        lst.append(value)
