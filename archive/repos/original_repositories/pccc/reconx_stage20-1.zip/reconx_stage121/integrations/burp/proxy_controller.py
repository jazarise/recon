"""
ReconX — Burp Proxy Controller (Stage 18.1)

Manages Burp Suite as a proxy server for traffic interception.

Responsibilities:
  1. Launch Burp Suite headlessly (--unpause-spider --headless flags)
  2. Configure proxy listener port and bind address
  3. Signal browser automation (Playwright/httpx) to route via Burp
  4. Stop the proxy cleanly when the session ends

Flow:
    Browser Automation
          ↓
    Burp Proxy (127.0.0.1:8080)
          ↓
    Traffic Capture
          ↓
    ReconX Analysis (via traffic_parser.py)

Safety: proxy launch is always localhost-bound; never exposes to network.
"""
from __future__ import annotations

import logging
import os
import shutil
import signal
import subprocess
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from .burp_client import BurpClient

logger = logging.getLogger("reconx.integrations.burp.proxy")

# Default proxy configuration
DEFAULT_PROXY_HOST = "127.0.0.1"
DEFAULT_PROXY_PORT = 8080

# Seconds to wait for Burp to start its REST API after launch
BURP_STARTUP_TIMEOUT = 30
BURP_STARTUP_POLL    = 1.0


@dataclass
class ProxyConfig:
    """Configuration for a Burp proxy listener."""
    host:          str  = DEFAULT_PROXY_HOST
    port:          int  = DEFAULT_PROXY_PORT
    intercept:     bool = False   # intercept off for automated capture
    follow_redirects: bool = True

    @property
    def proxy_url(self) -> str:
        return f"http://{self.host}:{self.port}"

    @property
    def env_vars(self) -> dict[str, str]:
        """
        Environment variables that configure standard tools (curl, httpx, etc.)
        to route traffic through the Burp proxy.
        """
        return {
            "HTTP_PROXY":  self.proxy_url,
            "HTTPS_PROXY": self.proxy_url,
            "http_proxy":  self.proxy_url,
            "https_proxy": self.proxy_url,
        }

    @property
    def playwright_proxy(self) -> dict:
        """Playwright proxy argument dict."""
        return {"server": self.proxy_url}

    @property
    def httpx_proxy(self) -> dict:
        """httpx proxy kwarg dict."""
        return {"proxy": self.proxy_url}


@dataclass
class ProxyStatus:
    """Current state of the Burp proxy controller."""
    running:        bool  = False
    pid:            int   = 0
    host:           str   = DEFAULT_PROXY_HOST
    port:           int   = DEFAULT_PROXY_PORT
    intercept_on:   bool  = False
    started_at:     float = 0.0
    error:          str   = ""
    requests_count: int   = 0


class ProxyController:
    """
    Controls Burp Suite as a transparent proxy for ReconX traffic capture.

    Does NOT embed or control the Burp GUI.
    Communicates exclusively via Burp's REST API for configuration and
    reads traffic via the API's proxy history endpoint.

    Usage:
        cfg    = ProxyConfig(port=8080)
        ctrl   = ProxyController(client, config=cfg)
        status = ctrl.start()
        ...
        ctrl.stop()
    """

    def __init__(
        self,
        client:        BurpClient,
        config:        Optional[ProxyConfig] = None,
        burp_jar_path: Optional[str]         = None,
        jvm_args:      Optional[list[str]]   = None,
    ):
        self._client       = client
        self.config        = config or ProxyConfig()
        self._burp_jar     = burp_jar_path or os.environ.get("RECONX_BURP_JAR", "")
        self._jvm_args     = jvm_args or []
        self._proc: Optional[subprocess.Popen] = None
        self._status       = ProxyStatus()

    # ══════════════════════════════════════════════════════════════════════════
    # Lifecycle
    # ══════════════════════════════════════════════════════════════════════════

    def start(self) -> ProxyStatus:
        """
        Start the Burp proxy.

        Strategy:
          1. If Burp API is already alive, skip launch (Burp already running).
          2. If a .jar path is configured, launch Burp headlessly.
          3. Disable interception (we want automated capture, not blocking).
          4. Return status.
        """
        # If the API is already reachable, Burp is already running
        ok, _ = self._client.ping()
        if ok:
            logger.info("[ProxyController] Burp API already live — skipping launch")
            self._status.running    = True
            self._status.started_at = time.time()
            self._configure_listener()
            return self._status

        # Try headless launch if jar is configured
        if self._burp_jar and Path(self._burp_jar).exists():
            self._launch_headless()
        else:
            # Burp not launched; mark as requiring manual start
            logger.warning(
                "[ProxyController] RECONX_BURP_JAR not set or jar missing. "
                "Start Burp manually with REST API enabled, then retry."
            )
            self._status.error = (
                "Burp Suite not reachable. "
                "Start Burp manually and enable REST API on port "
                f"{self._client.port}, or set RECONX_BURP_JAR."
            )
            return self._status

        return self._status

    def stop(self) -> None:
        """Gracefully stop the Burp process if ReconX launched it."""
        if self._proc and self._proc.poll() is None:
            logger.info("[ProxyController] Stopping Burp process (pid=%d)", self._proc.pid)
            try:
                self._proc.send_signal(signal.SIGTERM)
                self._proc.wait(timeout=10)
            except Exception as exc:
                logger.debug("[ProxyController] Terminate failed: %s — killing", exc)
                try:
                    self._proc.kill()
                except Exception:
                    pass
        self._status.running = False
        self._proc = None

    def is_running(self) -> bool:
        """Check whether the proxy (and underlying Burp) is live."""
        ok, _ = self._client.ping()
        return ok

    @property
    def status(self) -> ProxyStatus:
        return self._status

    # ══════════════════════════════════════════════════════════════════════════
    # Proxy listener management
    # ══════════════════════════════════════════════════════════════════════════

    def get_listener_config(self) -> tuple[dict, str]:
        """Return the current Burp proxy listener configuration."""
        return self._client.get_proxy_config()

    def enable_intercept(self) -> str:
        """Enable Burp proxy interception (manual analysis mode)."""
        _, err = self._client.set_proxy_intercept(True)
        if not err:
            self._status.intercept_on = True
        return err

    def disable_intercept(self) -> str:
        """
        Disable Burp proxy interception (passive capture mode).
        This is the default for automated ReconX runs.
        """
        _, err = self._client.set_proxy_intercept(False)
        if not err:
            self._status.intercept_on = False
        return err

    # ══════════════════════════════════════════════════════════════════════════
    # Browser proxy configuration helpers
    # ══════════════════════════════════════════════════════════════════════════

    def playwright_config(self) -> dict:
        """
        Return Playwright browser launch kwargs to route traffic via Burp.

        Usage in Playwright:
            async with async_playwright() as p:
                browser = await p.chromium.launch(**ctrl.playwright_config())
        """
        return {
            "proxy": self.config.playwright_proxy,
            # Burp's default CA cert is not trusted; ignore TLS errors
            # for internal/test targets only.
            "args": ["--ignore-certificate-errors"],
        }

    def httpx_config(self) -> dict:
        """
        Return httpx client kwargs to route traffic via Burp.

        Usage:
            import httpx
            async with httpx.AsyncClient(**ctrl.httpx_config()) as c:
                r = await c.get(url)
        """
        return {
            "proxy":   self.config.proxy_url,
            "verify":  False,   # Burp CA not in default trust store
        }

    def subprocess_env(self) -> dict[str, str]:
        """
        Returns env-var dict to make curl/wget/etc proxy through Burp.
        Merge with os.environ before calling subprocess.
        """
        return {**os.environ, **self.config.env_vars}

    # ══════════════════════════════════════════════════════════════════════════
    # Internal helpers
    # ══════════════════════════════════════════════════════════════════════════

    def _launch_headless(self) -> None:
        """Launch Burp Suite headlessly and wait for the REST API to come up."""
        java = shutil.which("java") or "java"
        cmd  = [java] + self._jvm_args + [
            "-Djava.awt.headless=true",
            "-jar", self._burp_jar,
            "--unpause-spider-and-scanner",
            "--headless=true",
        ]
        logger.info("[ProxyController] Launching Burp: %s", " ".join(cmd))

        try:
            self._proc = subprocess.Popen(
                cmd,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                preexec_fn=os.setsid if hasattr(os, "setsid") else None,
            )
            self._status.pid = self._proc.pid
        except FileNotFoundError:
            self._status.error = "Java not found. Install Java 11+ to launch Burp."
            logger.error("[ProxyController] %s", self._status.error)
            return
        except Exception as exc:
            self._status.error = f"Burp launch failed: {exc}"
            logger.error("[ProxyController] %s", self._status.error)
            return

        # Poll until REST API responds or timeout
        deadline = time.time() + BURP_STARTUP_TIMEOUT
        while time.time() < deadline:
            ok, _ = self._client.ping()
            if ok:
                self._status.running    = True
                self._status.started_at = time.time()
                logger.info("[ProxyController] Burp API live (pid=%d)", self._proc.pid)
                self._configure_listener()
                return
            time.sleep(BURP_STARTUP_POLL)

        self._status.error = (
            f"Burp did not start within {BURP_STARTUP_TIMEOUT}s. "
            "Check Burp licence and REST API configuration."
        )
        logger.error("[ProxyController] %s", self._status.error)

    def _configure_listener(self) -> None:
        """Configure Burp proxy listener and disable interception."""
        self.disable_intercept()
        self._status.host = self.config.host
        self._status.port = self.config.port
        logger.debug(
            "[ProxyController] Proxy listener: %s:%d | intercept=off",
            self.config.host, self.config.port,
        )
