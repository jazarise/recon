"""
ReconX — Burp Request Replay Engine (Stage 18.1)

Replays captured HTTP requests back through Burp Suite's Repeater.

Supports three replay modes:
  1. Single request  — reconx burp replay SESSION_ID --request-id ITEM_ID
  2. Sequence replay — replay a list of requests in order with configurable delay
  3. Workflow replay — replay an entire captured session's traffic

Use cases:
  - Verify an endpoint is still accessible after initial capture
  - Replay an authentication flow to confirm session tokens
  - Re-issue API calls with modified parameters (headers injected by ReconX)

Safety:
  - Only replays to original hosts captured by Burp (no host rewriting)
  - Does not perform fuzzing or payload injection
  - Replay results are logged but NOT fed back to the scanner pipeline
    (replay is verification only, not discovery)

CLI:
    reconx burp replay SESSION_ID
    reconx burp replay SESSION_ID --request-id abc123
    reconx burp replay SESSION_ID --sequence  (replay all in order)
"""
from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Optional

from .burp_client    import BurpClient
from .session_manager import BurpSession, SessionManager

logger = logging.getLogger("reconx.integrations.burp.replay")

# Minimum delay between replayed requests (politeness)
MIN_DELAY_S  = 0.2
DEFAULT_DELAY = 0.5


@dataclass
class ReplayResult:
    """Outcome of replaying one HTTP request."""
    request_id:  str
    url:         str
    method:      str     = "GET"
    status_code: int     = 0
    response_len: int    = 0
    duration_ms: float   = 0.0
    error:       str     = ""
    success:     bool    = False

    def summary_line(self) -> str:
        if self.error:
            return f"  ✗ [{self.request_id[:8]}] {self.method} {self.url} — {self.error}"
        return (
            f"  ✓ [{self.request_id[:8]}] {self.method} {self.url} "
            f"→ HTTP {self.status_code} ({self.response_len}B, {self.duration_ms:.0f}ms)"
        )


@dataclass
class ReplayReport:
    """Aggregate report for a full replay run."""
    session_id:   str
    mode:         str            # "single" | "sequence" | "workflow"
    total:        int    = 0
    succeeded:    int    = 0
    failed:       int    = 0
    duration_s:   float  = 0.0
    results:      list[ReplayResult] = field(default_factory=list)
    error:        str    = ""

    @property
    def success_rate(self) -> float:
        return (self.succeeded / self.total * 100) if self.total else 0.0

    def to_dict(self) -> dict:
        return {
            "session_id":   self.session_id,
            "mode":         self.mode,
            "total":        self.total,
            "succeeded":    self.succeeded,
            "failed":       self.failed,
            "success_rate": f"{self.success_rate:.1f}%",
            "duration_s":   round(self.duration_s, 2),
            "results":      [
                {
                    "request_id":  r.request_id,
                    "url":         r.url,
                    "method":      r.method,
                    "status_code": r.status_code,
                    "success":     r.success,
                    "error":       r.error,
                }
                for r in self.results
            ],
            "error": self.error,
        }


class ReplayEngine:
    """
    Replays captured Burp requests via the Repeater API.

    Usage:
        engine = ReplayEngine(client, session_manager)

        # Single request
        report = engine.replay_single(session, request_id="abc123")

        # Full session sequence
        report = engine.replay_session(session)
    """

    def __init__(
        self,
        client:          BurpClient,
        session_manager: SessionManager,
        delay_s:         float = DEFAULT_DELAY,
    ):
        self._client  = client
        self._sm      = session_manager
        self._delay   = max(MIN_DELAY_S, delay_s)

    # ══════════════════════════════════════════════════════════════════════════
    # Public replay API
    # ══════════════════════════════════════════════════════════════════════════

    def replay_single(
        self,
        session:    BurpSession,
        request_id: str,
    ) -> ReplayReport:
        """
        Replay one specific request captured during a session.
        Returns a ReplayReport with a single result entry.
        """
        report = ReplayReport(
            session_id=session.session_id,
            mode="single",
        )
        t0 = time.time()

        result = self._replay_one(request_id)
        report.results.append(result)
        report.total     = 1
        report.succeeded = 1 if result.success else 0
        report.failed    = 0 if result.success else 1
        report.duration_s = time.time() - t0

        logger.info(
            "[ReplayEngine] Single replay: %s → %s",
            request_id[:8],
            "OK" if result.success else result.error,
        )
        return report

    def replay_sequence(
        self,
        session:     BurpSession,
        request_ids: list[str],
        delay_s:     Optional[float] = None,
    ) -> ReplayReport:
        """
        Replay a specific list of requests in order with inter-request delay.
        """
        delay  = max(MIN_DELAY_S, delay_s or self._delay)
        report = ReplayReport(session_id=session.session_id, mode="sequence")
        t0     = time.time()

        for i, req_id in enumerate(request_ids):
            result = self._replay_one(req_id)
            report.results.append(result)
            report.total += 1
            if result.success:
                report.succeeded += 1
            else:
                report.failed += 1

            logger.debug("[ReplayEngine] Sequence %d/%d: %s", i + 1, len(request_ids), result.summary_line())

            if i < len(request_ids) - 1:
                time.sleep(delay)

        report.duration_s = time.time() - t0
        logger.info(
            "[ReplayEngine] Sequence complete: %d/%d ok in %.1fs",
            report.succeeded, report.total, report.duration_s,
        )
        return report

    def replay_session(
        self,
        session:  BurpSession,
        delay_s:  Optional[float] = None,
        limit:    int = 200,
    ) -> ReplayReport:
        """
        Replay all requests captured during a session (workflow replay).

        Args:
            session: The session to replay.
            delay_s: Inter-request delay. Defaults to self._delay.
            limit:   Max requests to replay (safety cap).
        """
        if not session.item_ids:
            report         = ReplayReport(session_id=session.session_id, mode="workflow")
            report.error   = "Session has no captured item IDs. Was it stopped cleanly?"
            return report

        ids_to_replay = session.item_ids[:limit]
        if len(session.item_ids) > limit:
            logger.warning(
                "[ReplayEngine] Session has %d items; replaying first %d only.",
                len(session.item_ids), limit,
            )

        return self.replay_sequence(session, ids_to_replay, delay_s=delay_s)

    # ══════════════════════════════════════════════════════════════════════════
    # CLI entry point (called by reconx burp replay SESSION_ID)
    # ══════════════════════════════════════════════════════════════════════════

    def run_from_cli(
        self,
        session_id:  str,
        request_id:  Optional[str] = None,
        sequence:    bool = False,
        delay_s:     float = DEFAULT_DELAY,
        limit:       int   = 200,
    ) -> ReplayReport:
        """
        Unified entry point for 'reconx burp replay SESSION_ID'.

        Selects replay mode based on flags:
          - request_id set → single request replay
          - sequence=True  → replay all session items in order
          - default        → replay full session workflow
        """
        session = self._sm.get_session(session_id)
        if session is None:
            report       = ReplayReport(session_id=session_id, mode="workflow")
            report.error = f"Session '{session_id}' not found."
            return report

        if request_id:
            return self.replay_single(session, request_id)
        elif sequence or not session.item_ids:
            return self.replay_session(session, delay_s=delay_s, limit=limit)
        else:
            return self.replay_session(session, delay_s=delay_s, limit=limit)

    # ══════════════════════════════════════════════════════════════════════════
    # Internal
    # ══════════════════════════════════════════════════════════════════════════

    def _replay_one(self, request_id: str) -> ReplayResult:
        """
        Replay a single request ID via Burp Repeater API.
        Returns a ReplayResult; never raises.
        """
        t0 = time.time()
        result = ReplayResult(request_id=request_id, url="", method="")

        try:
            data, err = self._client.replay_request(request_id)
            duration  = (time.time() - t0) * 1000

            if err:
                result.error    = err
                result.success  = False
                result.duration_ms = duration
                return result

            result.status_code  = data.get("statusCode", 0)
            result.response_len = data.get("responseLength", 0)
            result.url          = data.get("url", "")
            result.method       = data.get("method", "GET").upper()
            result.duration_ms  = data.get("roundTripMs", duration)
            result.success      = result.status_code in range(100, 600)

        except Exception as exc:
            result.error   = str(exc)
            result.success = False
            logger.debug("[ReplayEngine] Replay exception for %s: %s", request_id, exc)

        return result
