# ReconX

**AI-Powered Reconnaissance Orchestration Tool**

> *Fast. Clean. Intelligent. Built for real-world security workflows.*

---

## What is ReconX?

ReconX is a modular, high-performance reconnaissance tool that orchestrates multiple recon utilities, normalizes their outputs into structured data, detects sensitive exposures, and delivers educational security suggestions — all from a single command.

Unlike monolithic scripts, ReconX uses a **staged execution model** that runs independent tools in parallel and feeds their results forward into dependent stages. Missing tools are skipped gracefully — the scan continues with whatever is available.

---

## Architecture

```
reconx/
├── __main__.py          CLI entry point (argparse)
├── engine/
│   └── executor.py      Staged execution orchestrator
├── tools/               One file per external tool
│   ├── base.py          BaseTool — availability check, subprocess safety
│   ├── whois_tool.py
│   ├── dns_tool.py      Pure-Python (dnspython), no binary needed
│   ├── subfinder.py
│   ├── amass.py
│   ├── masscan.py
│   ├── tcp_scanner.py   Fallback if masscan unavailable
│   ├── nmap_tool.py     XML output parser
│   ├── httpx_tool.py
│   └── whatweb.py
├── analysis/
│   ├── deduplicator.py  Deduplication across all tool outputs
│   ├── sensitive_detector.py  Pattern-based exposure detection
│   └── suggestion_engine.py  Rule-based educational suggestions
├── output/
│   └── exporter.py      Terminal (Rich), TXT, JSON, HTML exporters
├── models/
│   └── findings.py      Unified data model (ReconResult, Port, …)
└── config/
    └── settings.py      Profiles, tool paths, rules
```

### Execution Stages

| Stage | Tools | Execution |
|-------|-------|-----------|
| 1 — Basic Recon | whois, DNS | Parallel |
| 2 — Discovery | subfinder, amass | Parallel |
| 3 — Scanning | masscan/TCP → nmap | Sequential |
| 4 — Web Analysis | httpx, whatweb | Parallel (conditional) |

---

## Installation

### 1. Clone and install Python package

```bash
git clone https://github.com/yourorg/reconx.git
cd reconx
pip install -r requirements.txt
pip install -e .
```

### 2. Install system tools (Kali Linux / Debian)

```bash
sudo apt update
sudo apt install -y nmap masscan whois
```

### 3. Install Go-based tools

```bash
go install -v github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest
go install -v github.com/projectdiscovery/httpx/cmd/httpx@latest
go install -v github.com/owasp-amass/amass/v4/...@latest
sudo apt install whatweb
```

> **Note:** masscan and nmap require root for raw packet scanning. Run with `sudo` or grant `CAP_NET_RAW` capability.

---

## Usage

```bash
# Basic scan (balanced mode, HTML report)
reconx -t example.com

# Fast scan, JSON output
reconx -t 192.168.1.1 --mode fast --output json

# Deep scan, all formats, 100 threads
reconx -t example.com --mode deep --output json,html,txt --threads 100

# Silent mode (no progress, just summary)
reconx -t example.com --silent

# No file reports — terminal only
reconx -t example.com --no-reports

# Debug tool execution
reconx -t example.com --log-level DEBUG
```

### Options

| Flag | Description | Default |
|------|-------------|---------|
| `-t / --target` | IP address or hostname | *(required)* |
| `--mode` | `fast` / `balanced` / `deep` | `balanced` |
| `--output` | `txt,json,html` (comma-separated) | `html` |
| `--threads` | Thread count override | auto |
| `--silent` | Suppress progress bars | off |
| `--no-reports` | Terminal summary only | off |
| `--log-level` | DEBUG/INFO/WARNING/ERROR | WARNING |

### Scan Profiles

| Profile | Port Range | Rate | Threads | Web Analysis |
|---------|-----------|------|---------|--------------|
| `fast` | 1–1000 | 5000/s | 50 | ✗ |
| `balanced` | 1–10000 | 2000/s | 80 | ✓ |
| `deep` | 1–65535 | 1000/s | 100 | ✓ + amass |

---

## Output

### Terminal
A clean Rich-formatted summary with tables for DNS, ports, findings, and suggestions.

### Reports (saved to `reports/`)
- `reconx_<target>_<timestamp>.html` — Styled dark-theme report
- `reconx_<target>_<timestamp>.json` — Full structured data
- `reconx_<target>_<timestamp>.txt` — Human-readable plain text

---

## Extending ReconX

### Adding a new tool

1. Create `tools/my_tool.py` inheriting from `BaseTool`
2. Implement `run(self, target, **kwargs) -> dict`
3. Add the tool call inside the appropriate stage in `engine/executor.py`

### Adding detection rules

Edit `config/settings.py`:
- `SENSITIVE_PATTERNS` — URL/path pattern rules
- `SUGGESTION_RULES` — Port/finding → recommendation mappings

---

## Disclaimer

> ReconX is for **authorized security testing and educational use only**.  
> Do not use this tool against systems you do not own or have **explicit written permission** to test.  
> The authors accept no liability for misuse.

---

## License

MIT
