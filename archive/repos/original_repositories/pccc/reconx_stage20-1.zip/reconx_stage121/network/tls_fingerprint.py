"""
ReconX — TLS Fingerprinter (Stage 18.2)

Parses TLS handshake fields from tshark into TLSRecord objects.

Detects:
  - JA3 / JA3S client+server fingerprints
  - TLS version (legacy TLS < 1.2 flagged HIGH)
  - Cipher suite weaknesses (NULL, EXPORT, RC4, DES, 3DES)
  - Expired certificates
  - Self-signed certificates
  - SNI (Server Name Indication) — hostname intelligence
  - Certificate SANs (Subject Alternative Names)
"""
from __future__ import annotations

import logging
import re
from datetime import datetime, timezone
from typing import Optional

from .models import TLSRecord, Severity

logger = logging.getLogger("reconx.network.tls_fingerprint")

# Weak cipher fragments — match against cipher suite name
_WEAK_CIPHER_PATTERNS = re.compile(
    r"NULL|EXPORT|RC4|DES(?!3)|3DES|MD5|anon|IDEA|SEED|CAMELLIA_128_CBC",
    re.I,
)

# Legacy TLS version strings
_LEGACY_TLS = {"SSLv2", "SSLv3", "TLSv1", "TLSv1.0", "TLSv1.1",
               "0x0300", "0x0301", "0x0302"}  # hex version codes

_TLS_VERSION_MAP = {
    "0x0300": "SSLv3",   "0x0301": "TLSv1.0",
    "0x0302": "TLSv1.1", "0x0303": "TLSv1.2",
    "0x0304": "TLSv1.3",
}


class TLSFingerprinter:
    """
    Parses tshark TLS field rows into TLSRecord objects.

    Usage:
        fp = TLSFingerprinter()
        rows, _ = tshark.extract_tls_fields("capture.pcap")
        records = fp.parse_rows(rows)
        weak = fp.get_weak_records(records)
    """

    def parse_rows(self, rows: list[dict]) -> list[TLSRecord]:
        """Convert tshark TLS field rows to TLSRecord list."""
        records: list[TLSRecord] = []
        seen: set[str] = set()

        for row in rows:
            src     = row.get("ip.src", "")
            dst     = row.get("ip.dst", "")
            sni     = (row.get("tls.handshake.extensions_server_name") or "").strip()
            ja3     = (row.get("tls.handshake.ja3") or "").strip()
            ja3s    = (row.get("tls.handshake.ja3s") or "").strip()
            ver_raw = (row.get("tls.record.version") or "").strip()
            cert    = (row.get("x509sat.uTF8String") or "").strip()

            # Normalise TLS version
            tls_ver = _TLS_VERSION_MAP.get(ver_raw.lower(), ver_raw)

            # Deduplicate by SNI+src
            key = f"{sni or dst}:{src}"
            if key in seen:
                continue
            seen.add(key)

            record = TLSRecord(
                src_ip=src,
                dst_ip=dst,
                sni=sni,
                ja3=ja3,
                ja3s=ja3s,
                tls_version=tls_ver,
                cert_subject=cert,
            )

            # Flag legacy TLS
            record.is_legacy_tls = tls_ver in _LEGACY_TLS or ver_raw in _LEGACY_TLS

            # Flag weak cipher
            if record.cipher:
                record.is_weak_cipher = bool(_WEAK_CIPHER_PATTERNS.search(record.cipher))

            records.append(record)

        logger.debug("[TLSFingerprinter] Parsed %d TLS records", len(records))
        return records

    def get_weak_records(self, records: list[TLSRecord]) -> list[TLSRecord]:
        """Return records with any TLS risk flag set."""
        return [r for r in records if
                r.is_expired or r.is_self_signed or
                r.is_weak_cipher or r.is_legacy_tls]

    def get_unique_snis(self, records: list[TLSRecord]) -> list[str]:
        """Return unique SNI hostnames observed."""
        return list(dict.fromkeys(r.sni for r in records if r.sni))

    def get_ja3_hashes(self, records: list[TLSRecord]) -> list[dict]:
        """Return unique JA3 fingerprints with SNI context."""
        seen: set[str] = set()
        result = []
        for r in records:
            if r.ja3 and r.ja3 not in seen:
                seen.add(r.ja3)
                result.append({"ja3": r.ja3, "ja3s": r.ja3s, "sni": r.sni, "src": r.src_ip})
        return result

    def risk_summary(self, records: list[TLSRecord]) -> dict:
        """Return a counts summary of TLS risks."""
        return {
            "total":        len(records),
            "legacy_tls":   sum(1 for r in records if r.is_legacy_tls),
            "weak_cipher":  sum(1 for r in records if r.is_weak_cipher),
            "self_signed":  sum(1 for r in records if r.is_self_signed),
            "expired":      sum(1 for r in records if r.is_expired),
            "unique_snis":  len(self.get_unique_snis(records)),
            "unique_ja3":   len(set(r.ja3 for r in records if r.ja3)),
        }
