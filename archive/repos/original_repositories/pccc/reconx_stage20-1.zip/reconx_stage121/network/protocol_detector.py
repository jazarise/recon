"""
ReconX — Protocol Detector (Stage 18.2)

Identifies application-layer protocols from:
  1. Protocol statistics from tshark -qz io,phs (primary)
  2. Port-based heuristics (fallback)
  3. Packet payload signatures (deep inspection)

Produces ProtocolHit objects with confidence scores:
  DNS  on port 53  UDP  → 100%
  HTTP on port 80  TCP  → 98%
  TLS  on port 443 TCP  → 97%
  ...

Protocol catalogue covers 16 protocols with port ranges and signatures.
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass
from typing import Optional

from .models import ProtocolHit

logger = logging.getLogger("reconx.network.protocol_detector")


# ── Protocol catalogue ────────────────────────────────────────────────────────
# Each entry: name, standard_ports, default_confidence, signature_pattern
# signature_pattern matched against first bytes of payload (hex or ASCII)

@dataclass
class _ProtoDef:
    name:       str
    ports:      tuple[int, ...]
    confidence: float           # base confidence when matched by port
    layer:      str             # "app" | "transport" | "network"
    description: str = ""
    sig_hex:    str  = ""       # hex signature in first payload bytes (optional)
    sig_ascii:  str  = ""       # ASCII pattern in payload (optional, compiled as regex)


_PROTO_CATALOGUE: list[_ProtoDef] = [
    _ProtoDef("HTTP",       (80, 8080, 8000, 8888, 3000, 5000),   0.98, "app",
              "Hypertext Transfer Protocol",
              sig_ascii=r"^(GET|POST|PUT|DELETE|HEAD|OPTIONS|PATCH|CONNECT) .+ HTTP/"),
    _ProtoDef("HTTPS/TLS",  (443, 8443, 4443),                    0.97, "app",
              "HTTP over TLS",
              sig_hex="160301|160302|160303|160304"),   # TLS ClientHello
    _ProtoDef("DNS",        (53,),                                 1.00, "app",
              "Domain Name System"),
    _ProtoDef("FTP",        (21,),                                 0.96, "app",
              "File Transfer Protocol",
              sig_ascii=r"^(220|USER|PASS|QUIT|LIST|RETR|STOR)"),
    _ProtoDef("FTP-DATA",   (20,),                                 0.90, "app",
              "FTP Data channel"),
    _ProtoDef("SSH",        (22,),                                 0.98, "app",
              "Secure Shell",
              sig_ascii=r"^SSH-\d+\.\d+"),
    _ProtoDef("SMTP",       (25, 587, 465),                        0.95, "app",
              "Simple Mail Transfer Protocol",
              sig_ascii=r"^(220|EHLO|HELO|MAIL FROM|RCPT TO|DATA|QUIT)"),
    _ProtoDef("POP3",       (110, 995),                            0.95, "app",
              "Post Office Protocol v3",
              sig_ascii=r"^\+OK|^-ERR"),
    _ProtoDef("IMAP",       (143, 993),                            0.95, "app",
              "Internet Message Access Protocol",
              sig_ascii=r"^\* (OK|BYE|BAD|NO)|^[A-Z0-9]+ (LOGIN|SELECT|FETCH)"),
    _ProtoDef("LDAP",       (389, 636),                            0.93, "app",
              "Lightweight Directory Access Protocol"),
    _ProtoDef("SMB",        (445, 139),                            0.98, "app",
              "Server Message Block",
              sig_hex="ff534d42|fe534d42"),  # \xffSMB or \xfeSMB
    _ProtoDef("RDP",        (3389,),                               0.97, "app",
              "Remote Desktop Protocol"),
    _ProtoDef("Kerberos",   (88,),                                 0.99, "app",
              "Kerberos authentication"),
    _ProtoDef("MQTT",       (1883, 8883),                          0.95, "app",
              "Message Queuing Telemetry Transport",
              sig_hex="1040|1000"),   # CONNECT packet
    _ProtoDef("WebSocket",  (80, 443, 8080),                       0.80, "app",
              "WebSocket protocol",
              sig_ascii=r"Upgrade: websocket"),
    _ProtoDef("SNMP",       (161, 162),                            0.95, "app",
              "Simple Network Management Protocol"),
    _ProtoDef("NTP",        (123,),                                0.95, "app",
              "Network Time Protocol"),
    _ProtoDef("DHCP",       (67, 68),                              0.97, "app",
              "Dynamic Host Configuration Protocol"),
    _ProtoDef("HTTP/2",     (443, 80),                             0.88, "app",
              "HTTP version 2",
              sig_hex="505249202a20485454502f322e300d0a0d0a534d0d0a0d0a"),  # PRI * HTTP/2
    _ProtoDef("gRPC",       (443, 50051),                          0.85, "app",
              "gRPC over HTTP/2"),
]

# Build port→proto lookup
_PORT_MAP: dict[int, list[_ProtoDef]] = {}
for _pd in _PROTO_CATALOGUE:
    for _port in _pd.ports:
        _PORT_MAP.setdefault(_port, []).append(_pd)


class ProtocolDetector:
    """
    Identifies protocols present in captured traffic.

    Usage:
        detector = ProtocolDetector()

        # From tshark protocol statistics
        hits = detector.from_stats({"http": {"packets": 1200}, "dns": {"packets": 400}})

        # From a single packet's port
        hit = detector.from_port(dst_port=443, src_port=54321, proto="TCP")

        # From raw payload bytes
        hit = detector.from_payload(payload_bytes, src_port=80, dst_port=54321)
    """

    def __init__(self):
        # Pre-compile payload signatures
        self._sigs: list[tuple[_ProtoDef, Optional[re.Pattern]]] = []
        for pd in _PROTO_CATALOGUE:
            if pd.sig_ascii:
                try:
                    pat = re.compile(pd.sig_ascii, re.I | re.MULTILINE)
                    self._sigs.append((pd, pat))
                except re.error:
                    self._sigs.append((pd, None))
            else:
                self._sigs.append((pd, None))

    # ══════════════════════════════════════════════════════════════════════════
    # Detection methods
    # ══════════════════════════════════════════════════════════════════════════

    def from_stats(self, proto_stats: dict) -> list[ProtocolHit]:
        """
        Build ProtocolHit list from tshark protocol statistics dict.
        {protocol_name: {packets: N, bytes: N}}
        """
        hits: list[ProtocolHit] = []

        # Normalise tshark proto names to our catalogue names
        _name_map = {
            "http":     "HTTP",
            "http2":    "HTTP/2",
            "tls":      "HTTPS/TLS",
            "ssl":      "HTTPS/TLS",
            "dns":      "DNS",
            "ftp":      "FTP",
            "ftp-data": "FTP-DATA",
            "ssh":      "SSH",
            "smtp":     "SMTP",
            "pop":      "POP3",
            "imap":     "IMAP",
            "ldap":     "LDAP",
            "smb":      "SMB",
            "smb2":     "SMB",
            "rdp":      "RDP",
            "kerberos": "Kerberos",
            "mqtt":     "MQTT",
            "websocket":"WebSocket",
            "snmp":     "SNMP",
            "ntp":      "NTP",
            "dhcp":     "DHCP",
            "bootp":    "DHCP",
            "grpc":     "gRPC",
        }

        seen: set[str] = set()
        for raw_name, stats in proto_stats.items():
            norm = _name_map.get(raw_name.lower(), raw_name.upper())
            if norm in seen:
                continue
            seen.add(norm)

            # Find catalogue entry for confidence
            catalogue_entry = next(
                (p for p in _PROTO_CATALOGUE if p.name == norm), None
            )
            conf = catalogue_entry.confidence if catalogue_entry else 0.80

            pkts = stats.get("packets", 0) if isinstance(stats, dict) else 0
            if pkts > 0:
                hits.append(ProtocolHit(
                    protocol=norm,
                    confidence=conf,
                    detail=f"{pkts} packets" if pkts else "",
                ))

        return sorted(hits, key=lambda h: h.confidence, reverse=True)

    def from_port(
        self,
        dst_port: int,
        src_port: int,
        proto:    str = "TCP",
    ) -> Optional[ProtocolHit]:
        """
        Identify protocol from destination port.
        Returns the highest-confidence match, or None.
        """
        candidates = _PORT_MAP.get(dst_port, [])
        if not candidates:
            return None

        best = max(candidates, key=lambda p: p.confidence)
        return ProtocolHit(
            protocol=best.name,
            confidence=best.confidence,
            port=dst_port,
            detail=f"{best.description} (port {dst_port}/{proto.lower()})",
        )

    def from_payload(
        self,
        payload: bytes,
        src_port: int,
        dst_port: int,
    ) -> Optional[ProtocolHit]:
        """
        Identify protocol from packet payload via signature matching.
        Returns best match, or None.
        """
        if not payload:
            return None

        text = ""
        try:
            text = payload[:256].decode("utf-8", errors="replace")
        except Exception:
            pass
        hexstr = payload[:32].hex()

        best_hit: Optional[ProtocolHit] = None
        best_conf = 0.0

        for pd, regex in self._sigs:
            matched = False
            if pd.sig_hex:
                for sig in pd.sig_hex.split("|"):
                    if hexstr.startswith(sig.lower()):
                        matched = True
                        break
            if not matched and regex and text:
                if regex.search(text):
                    matched = True

            if matched and pd.confidence > best_conf:
                best_conf = pd.confidence
                best_hit  = ProtocolHit(
                    protocol=pd.name,
                    confidence=pd.confidence,
                    port=dst_port,
                    detail=f"Payload signature match — {pd.description}",
                )

        return best_hit

    def describe(self, protocol_name: str) -> str:
        """Return a human-readable description for a protocol name."""
        pd = next((p for p in _PROTO_CATALOGUE if p.name == protocol_name), None)
        return pd.description if pd else protocol_name

    def get_all_known(self) -> list[str]:
        """Return all protocol names in the catalogue."""
        return [p.name for p in _PROTO_CATALOGUE]
