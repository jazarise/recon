"""
ReconX — PyShark Engine (Stage 18.2)

Python-native PCAP analysis via the pyshark library.
PyShark wraps tshark internally but provides a Pythonic packet object API
rather than raw subprocess output.

Role in the pipeline:
  - Fallback when tshark field extraction misses edge cases
  - Deep payload inspection for credential scanning
  - Layer-specific field access without manual string parsing
  - Zeek-ready bridge: pyshark packet objects translate cleanly to Zeek log format

Used by:
  - live_capture.py   (live packet stream)
  - pcap_parser.py    (supplementary pass on small captures)

Availability: optional — if pyshark not installed, this module
returns graceful stubs and the pipeline falls back to tshark_engine.
"""
from __future__ import annotations

import importlib
import logging
import time
from typing import Optional, Iterator

from .models import (
    Packet, FlowRecord, TrafficSummary,
    ProtocolHit, DNSEntry, HTTPRecord,
)
from .credential_detector import CredentialDetector
from .protocol_detector   import ProtocolDetector

logger = logging.getLogger("reconx.network.pyshark_engine")

# Lazy import pyshark — not in requirements (optional dependency)
def _import_pyshark():
    try:
        return importlib.import_module("pyshark")
    except ImportError:
        return None


class PySharkEngine:
    """
    Supplementary packet analysis engine using pyshark.

    If pyshark is not installed, all methods return empty results
    with a clear message — never raises.

    Usage:
        ps = PySharkEngine()
        if ps.available():
            packets = ps.read_pcap("capture.pcap", max_packets=1000)
    """

    def __init__(self):
        self._pyshark    = _import_pyshark()
        self._cred_det   = CredentialDetector()
        self._proto_det  = ProtocolDetector()

    def available(self) -> bool:
        """Return True if pyshark is importable."""
        return self._pyshark is not None

    def install_hint(self) -> str:
        return "pip install pyshark  (requires tshark on PATH)"

    # ══════════════════════════════════════════════════════════════════════════
    # PCAP reading
    # ══════════════════════════════════════════════════════════════════════════

    def read_pcap(
        self,
        pcap_path:   str,
        max_packets: int = 5_000,
        display_filter: str = "",
    ) -> tuple[list[Packet], str]:
        """
        Read a PCAP file via pyshark. Returns (packets, error).
        Packets are our own Packet dataclass — not pyshark objects.
        """
        if not self.available():
            return [], self.install_hint()

        pyshark = self._pyshark
        packets: list[Packet] = []

        try:
            kwargs: dict = {"input_file": pcap_path}
            if display_filter:
                kwargs["display_filter"] = display_filter

            cap = pyshark.FileCapture(**kwargs)
            cap.set_debug(False)

            for i, pkt in enumerate(cap):
                if i >= max_packets:
                    break
                p = self._convert_packet(pkt)
                if p:
                    packets.append(p)

            cap.close()
        except Exception as exc:
            return packets, f"pyshark read error: {exc}"

        logger.debug("[PyShark] Read %d packets from %s", len(packets), pcap_path)
        return packets, ""

    def deep_credential_scan(
        self,
        pcap_path:   str,
        max_packets: int = 10_000,
    ) -> list:
        """
        Deep scan of payload bytes for credentials missed by tshark field extraction.
        Returns list[CredentialHit].
        """
        if not self.available():
            return []

        hits = []
        packets, err = self.read_pcap(pcap_path, max_packets=max_packets,
                                       display_filter="http or ftp or smtp")
        if err:
            logger.debug("[PyShark] deep_credential_scan error: %s", err)
            return []

        for pkt in packets:
            if pkt.payload:
                text = pkt.payload.decode("utf-8", errors="replace")
                found = self._cred_det.scan_text(text, pkt.src_ip, pkt.dst_ip, pkt.protocol)
                hits.extend(found)

        return hits

    # ══════════════════════════════════════════════════════════════════════════
    # Live capture (used by live_capture.py)
    # ══════════════════════════════════════════════════════════════════════════

    def live_packet_stream(
        self,
        interface:   str,
        max_packets: int = 500,
        timeout_s:   int = 10,
    ) -> Iterator[Packet]:
        """
        Yield Packet objects from a live interface.
        Stops after max_packets or timeout_s, whichever comes first.
        """
        if not self.available():
            logger.warning("[PyShark] pyshark not available for live capture")
            return

        pyshark = self._pyshark
        deadline = time.time() + timeout_s
        count    = 0

        try:
            cap = pyshark.LiveCapture(interface=interface)
            for pkt in cap.sniff_continuously():
                if count >= max_packets or time.time() > deadline:
                    break
                p = self._convert_packet(pkt)
                if p:
                    yield p
                    count += 1
            cap.close()
        except Exception as exc:
            logger.debug("[PyShark] live_packet_stream error: %s", exc)

    # ══════════════════════════════════════════════════════════════════════════
    # Packet conversion
    # ══════════════════════════════════════════════════════════════════════════

    def _convert_packet(self, pkt) -> Optional[Packet]:
        """Convert a pyshark Packet to our Packet dataclass. Returns None on parse error."""
        try:
            src_ip  = ""
            dst_ip  = ""
            src_port = 0
            dst_port = 0
            proto    = ""
            payload  = b""

            layers = [layer.layer_name for layer in pkt.layers]

            if hasattr(pkt, "ip"):
                src_ip = pkt.ip.src
                dst_ip = pkt.ip.dst

            if hasattr(pkt, "tcp"):
                src_port = int(pkt.tcp.srcport)
                dst_port = int(pkt.tcp.dstport)
                proto    = "TCP"
                if hasattr(pkt.tcp, "payload"):
                    try:
                        payload = bytes.fromhex(pkt.tcp.payload.replace(":", ""))
                    except Exception:
                        pass

            elif hasattr(pkt, "udp"):
                src_port = int(pkt.udp.srcport)
                dst_port = int(pkt.udp.dstport)
                proto    = "UDP"

            elif hasattr(pkt, "icmp"):
                proto = "ICMP"

            return Packet(
                timestamp   = float(pkt.sniff_timestamp),
                src_ip      = src_ip,
                dst_ip      = dst_ip,
                src_port    = src_port,
                dst_port    = dst_port,
                protocol    = proto,
                length      = int(pkt.length) if hasattr(pkt, "length") else 0,
                payload     = payload,
                layer_names = layers,
            )
        except Exception:
            return None

    # ══════════════════════════════════════════════════════════════════════════
    # Flow reconstruction from Packet list
    # ══════════════════════════════════════════════════════════════════════════

    def reconstruct_flows(self, packets: list[Packet]) -> list[FlowRecord]:
        """
        Reconstruct bidirectional flows from a list of Packet objects.
        Groups packets by canonical 5-tuple.
        """
        flow_map: dict[tuple, FlowRecord] = {}

        for pkt in packets:
            key = pkt.flow_key
            # Canonical key: sort endpoints
            ckey = tuple(sorted([pkt.src_ip, pkt.dst_ip]) +
                         sorted([pkt.src_port, pkt.dst_port]) +
                         [pkt.protocol])

            if ckey not in flow_map:
                flow_map[ckey] = FlowRecord(
                    src_ip   = pkt.src_ip,
                    dst_ip   = pkt.dst_ip,
                    src_port = pkt.src_port,
                    dst_port = pkt.dst_port,
                    protocol = pkt.protocol,
                    start_time = pkt.timestamp,
                )
            flow = flow_map[ckey]
            flow.packets    += 1
            flow.bytes_sent += pkt.length
            flow.end_time    = max(flow.end_time or 0, pkt.timestamp)

        return list(flow_map.values())
