"""
ReconX — PCAP Analysis Pipeline (Stage 18.2)

Top-level PCAP/PCAPNG analysis orchestrator.

Ingests a capture file and runs the full extraction pipeline:
  1. TShark decode → raw packet list
  2. Protocol detection
  3. DNS extraction
  4. HTTP extraction
  5. TLS fingerprinting
  6. Credential detection
  7. Anomaly analysis
  8. Flow reconstruction
  9. Host / IP aggregation

Returns a TrafficSummary — the canonical output of the Traffic Intelligence Layer.

CLI entry point:
    reconx pcap analyze file.pcap
"""
from __future__ import annotations

import logging
import os
import time
from pathlib import Path
from typing import Optional

from .models import (
    TrafficSummary, FlowRecord, ProtocolHit,
    Severity, CredentialHit, CredentialTag,
)
from .tshark_engine      import TSharkEngine
from .protocol_detector  import ProtocolDetector
from .dns_extractor      import DNSExtractor
from .http_extractor     import HTTPExtractor
from .tls_fingerprint    import TLSFingerprinter
from .credential_detector import CredentialDetector
from .anomaly_engine     import AnomalyEngine

logger = logging.getLogger("reconx.network.pcap_parser")


class PCAPParser:
    """
    Full PCAP/PCAPNG analysis pipeline.

    Usage:
        parser = PCAPParser()
        summary, err = parser.analyze("capture.pcap")
        if err:
            print(f"Error: {err}")
        else:
            print(f"{summary.total_packets} packets, {len(summary.credentials)} credentials")
    """

    def __init__(
        self,
        tshark:       Optional[TSharkEngine]      = None,
        protocols:    Optional[ProtocolDetector]  = None,
        dns:          Optional[DNSExtractor]      = None,
        http:         Optional[HTTPExtractor]     = None,
        tls:          Optional[TLSFingerprinter]  = None,
        credentials:  Optional[CredentialDetector] = None,
        anomalies:    Optional[AnomalyEngine]     = None,
    ):
        self._tshark  = tshark      or TSharkEngine()
        self._protos  = protocols   or ProtocolDetector()
        self._dns     = dns         or DNSExtractor()
        self._http    = http        or HTTPExtractor()
        self._tls     = tls         or TLSFingerprinter()
        self._creds   = credentials or CredentialDetector()
        self._anomaly = anomalies   or AnomalyEngine()

    # ══════════════════════════════════════════════════════════════════════════
    # Public API
    # ══════════════════════════════════════════════════════════════════════════

    def analyze(
        self,
        pcap_path:      str,
        display_filter: str = "",
        max_packets:    int = 50_000,
    ) -> tuple[TrafficSummary, str]:
        """
        Run the full analysis pipeline against a PCAP file.

        Returns (TrafficSummary, error_string).
        TrafficSummary is always returned (possibly empty) — error is advisory.
        """
        summary = TrafficSummary(source_file=pcap_path)
        t0      = time.perf_counter()

        # ── Preflight ─────────────────────────────────────────────────────────
        if not os.path.exists(pcap_path):
            return summary, f"File not found: {pcap_path}"

        if not self._tshark.available():
            return summary, self._tshark.install_hint()

        ext = Path(pcap_path).suffix.lower()
        if ext not in (".pcap", ".pcapng", ".cap", ".dmp"):
            logger.warning("[PCAPParser] Unexpected file extension: %s", ext)

        logger.info("[PCAPParser] Analyzing: %s", pcap_path)

        # ── Step 1: Protocol statistics (fast, no full decode) ────────────────
        try:
            proto_stats, err = self._tshark.protocol_stats(pcap_path)
            if proto_stats:
                summary.protocol_counts = proto_stats
                summary.protocols = self._protos.from_stats(proto_stats)
        except Exception as exc:
            logger.debug("[PCAPParser] protocol_stats error: %s", exc)

        # ── Step 2: Conversation table (top talkers) ──────────────────────────
        try:
            convs, _ = self._tshark.conversation_table(pcap_path, layer="ip")
            self._build_top_talkers(summary, convs)
        except Exception as exc:
            logger.debug("[PCAPParser] conversation_table error: %s", exc)

        # ── Step 3: DNS extraction ────────────────────────────────────────────
        try:
            dns_rows, _ = self._tshark.extract_dns(pcap_path)
            dns_entries  = self._dns.parse_rows(dns_rows)
            summary.dns_entries = dns_entries
            for e in dns_entries:
                if e.query_name and e.query_name not in summary.domains:
                    summary.domains.append(e.query_name)
                for ip in e.answers:
                    summary.add_ip(ip)
                summary.add_ip(e.src_ip)
                summary.add_ip(e.dst_ip)
        except Exception as exc:
            logger.debug("[PCAPParser] dns_extract error: %s", exc)

        # ── Step 4: HTTP extraction ───────────────────────────────────────────
        try:
            http_rows, _ = self._tshark.extract_http(pcap_path)
            http_records  = self._http.parse_rows(http_rows)
            summary.http_records = http_records
            for r in http_records:
                if r.host and r.host not in summary.hosts:
                    summary.hosts.append(r.host)
                summary.add_ip(r.src_ip)
                summary.add_ip(r.dst_ip)
        except Exception as exc:
            logger.debug("[PCAPParser] http_extract error: %s", exc)

        # ── Step 5: TLS fingerprinting ────────────────────────────────────────
        try:
            tls_rows, _ = self._tshark.extract_tls_fields(pcap_path)
            tls_records  = self._tls.parse_rows(tls_rows)
            summary.tls_records = tls_records
            for r in tls_records:
                if r.sni and r.sni not in summary.hosts:
                    summary.hosts.append(r.sni)
                summary.add_ip(r.src_ip)
                summary.add_ip(r.dst_ip)
        except Exception as exc:
            logger.debug("[PCAPParser] tls_fingerprint error: %s", exc)

        # ── Step 6: Credential detection ─────────────────────────────────────
        try:
            cred_rows, _ = self._tshark.extract_credentials(pcap_path)
            cred_hits     = self._creds.scan_rows(cred_rows)
            summary.credentials = cred_hits
        except Exception as exc:
            logger.debug("[PCAPParser] credential_detect error: %s", exc)

        # ── Step 7: Anomaly analysis ──────────────────────────────────────────
        try:
            summary.anomalies = self._anomaly.analyze(summary)
        except Exception as exc:
            logger.debug("[PCAPParser] anomaly_engine error: %s", exc)

        # ── Step 8: Packet count from stats ──────────────────────────────────
        if summary.protocol_counts:
            # Total frames = ethernet frame count (or sum of top-level protos)
            eth_count = summary.protocol_counts.get("eth", {})
            if isinstance(eth_count, dict):
                summary.total_packets = eth_count.get("packets", 0)
                summary.total_bytes   = eth_count.get("bytes", 0)

        # ── Step 9: Derived statistics ────────────────────────────────────────
        self._compute_derived(summary)

        duration = time.perf_counter() - t0
        logger.info(
            "[PCAPParser] Done in %.1fs — %d protocols, %d DNS, %d HTTP, "
            "%d TLS, %d creds, %d anomalies",
            duration,
            len(summary.protocols),
            len(summary.dns_entries),
            len(summary.http_records),
            len(summary.tls_records),
            len(summary.credentials),
            len(summary.anomalies),
        )
        return summary, ""

    # ══════════════════════════════════════════════════════════════════════════
    # Helpers
    # ══════════════════════════════════════════════════════════════════════════

    def _build_top_talkers(
        self,
        summary: TrafficSummary,
        convs:   list[dict],
    ) -> None:
        """Build top_talkers and top_destinations from conversation table."""
        ip_counts: dict[str, dict] = {}

        for c in convs:
            for role, ip in [("src", c.get("src", "")), ("dst", c.get("dst", ""))]:
                # Strip port if present (IP:port format)
                ip_clean = ip.split(":")[0] if ":" in ip else ip
                if not ip_clean:
                    continue
                summary.add_ip(ip_clean)
                if ip_clean not in ip_counts:
                    ip_counts[ip_clean] = {"ip": ip_clean, "packets": 0, "bytes": 0}
                ip_counts[ip_clean]["packets"] += c.get("frames_a", 0) + c.get("frames_b", 0)
                ip_counts[ip_clean]["bytes"]   += c.get("bytes_a", 0)  + c.get("bytes_b", 0)

        ranked = sorted(ip_counts.values(), key=lambda x: x["packets"], reverse=True)
        summary.top_talkers      = ranked[:10]
        summary.top_destinations = ranked[:10]

    def _compute_derived(self, summary: TrafficSummary) -> None:
        """Compute packets/sec and other derived metrics."""
        if summary.duration_s > 0 and summary.total_packets > 0:
            summary.packets_per_sec = summary.total_packets / summary.duration_s

        # Deduplicate host lists
        summary.hosts   = list(dict.fromkeys(filter(None, summary.hosts)))
        summary.domains = list(dict.fromkeys(filter(None, summary.domains)))
        summary.ips     = list(dict.fromkeys(filter(None, summary.ips)))
