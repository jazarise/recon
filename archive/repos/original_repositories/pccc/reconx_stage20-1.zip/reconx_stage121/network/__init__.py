"""
ReconX — Traffic Intelligence Layer (Stage 18.2)
"""
from __future__ import annotations
import logging
import time
from typing import Optional

try:
    from ..tools.base import BaseTool
    from ..models.tool_result import ParsedFinding, ToolRunResult
except ImportError:
    from dataclasses import dataclass, field
    class BaseTool:
        NAME=""; BINARY=""; CATEGORY=""; STAGE=0; PRIORITY=50
        PASSIVE=True; TIMEOUT=300; DEPENDENCIES=[]; INSTALL_CMD=""
        def __init__(self, **kw): pass
        def _log(self, lvl, msg): logging.getLogger("reconx.network").info(msg)
        def validate_or_fail(self, t): return None
        def build_result(self, **kw): return kw
        def fail(self, **kw): return kw
        def safe_run(self, t, **kw): return self.run(t, **kw)
    @dataclass
    class ParsedFinding:
        finding_type: str; value: str; source: str = ""; confidence: float = 1.0
        metadata: dict = field(default_factory=dict)
    class ToolRunResult:
        @staticmethod
        def skipped(n, m): return {"status": "skipped", "msg": m}

from .models             import (TrafficSummary, Packet, FlowRecord, ProtocolHit,
                                  CredentialHit, CredentialTag, DNSEntry,
                                  HTTPRecord, TLSRecord, AnomalyAlert, Severity)
from .tshark_engine      import TSharkEngine
from .pyshark_engine     import PySharkEngine
from .pcap_parser        import PCAPParser
from .protocol_detector  import ProtocolDetector
from .credential_detector import CredentialDetector
from .dns_extractor      import DNSExtractor
from .http_extractor     import HTTPExtractor
from .tls_fingerprint    import TLSFingerprinter
from .anomaly_engine     import AnomalyEngine
from .live_capture       import LiveCaptureEngine, CaptureSession

logger = logging.getLogger("reconx.network")


class TrafficIntelligenceTool(BaseTool):
    NAME        = "Traffic Intelligence"
    BINARY      = "tshark"
    CATEGORY    = "network_analysis"
    STAGE       = 2
    PRIORITY    = 15
    PASSIVE     = True
    TIMEOUT     = 300
    DEPENDENCIES = []
    INSTALL_CMD  = (
        "sudo apt install tshark  (Linux)\n"
        "brew install wireshark   (macOS)\n"
        "Linux permissions: sudo setcap cap_net_raw,cap_net_admin=eip /usr/bin/dumpcap"
    )

    def __init__(self, timeout: Optional[int] = None, max_packets: int = 50_000):
        super().__init__(timeout=timeout)
        self._tshark  = TSharkEngine(max_packets=max_packets)
        self._pyshark = PySharkEngine()
        self._parser  = PCAPParser(tshark=self._tshark)
        self._live    = LiveCaptureEngine(tshark=self._tshark, pyshark=self._pyshark, parser=self._parser)

    def run(self, target: str, **kwargs) -> ToolRunResult:
        mode = kwargs.get("mode", "")
        if not mode:
            mode = "live" if target.startswith("live:") else "pcap"
        t0 = time.perf_counter()
        if mode == "live":
            iface = target.replace("live:", "") if ":" in target else ""
            return self._run_live(iface, kwargs, t0)
        return self._run_pcap(target, kwargs, t0)

    def parse_output(self, raw: str, **kwargs) -> dict:
        return {}

    def _run_pcap(self, pcap_path: str, kwargs: dict, t0: float) -> ToolRunResult:
        if not self._tshark.available():
            return ToolRunResult.skipped(self.NAME, self._tshark.install_hint())
        self._log("info", f"PCAP analysis: {pcap_path}")
        summary, err = self._parser.analyze(pcap_path,
            display_filter=kwargs.get("display_filter", ""),
            max_packets=kwargs.get("max_packets", 50_000))
        if err and not summary.total_packets:
            return self.fail(reason="pcap_parse_failed", message=err,
                             duration_s=time.perf_counter() - t0)
        return self.build_result(data=summary.to_dict(),
            findings=self._to_findings(summary), duration_s=time.perf_counter() - t0)

    def _run_live(self, iface: str, kwargs: dict, t0: float) -> ToolRunResult:
        if not self._tshark.available():
            return ToolRunResult.skipped(self.NAME, self._tshark.install_hint())
        session = self._live.start(interface=iface,
            duration_s=kwargs.get("duration_s", 30),
            max_packets=kwargs.get("max_packets", 10_000),
            display_filter=kwargs.get("display_filter", ""))
        if session.state == "error":
            return self.fail(reason="live_capture_failed", message=session.error,
                             duration_s=time.perf_counter() - t0)
        summary = session.summary or TrafficSummary()
        return self.build_result(data=summary.to_dict(),
            findings=self._to_findings(summary), duration_s=time.perf_counter() - t0)

    def _to_findings(self, summary: TrafficSummary) -> list[ParsedFinding]:
        findings: list[ParsedFinding] = []
        for ip in summary.ips:
            findings.append(ParsedFinding(finding_type="ip_address", value=ip, source=self.NAME, confidence=0.99))
        for host in summary.hosts:
            findings.append(ParsedFinding(finding_type="hostname", value=host, source=self.NAME, confidence=0.95))
        for domain in summary.domains:
            findings.append(ParsedFinding(finding_type="domain", value=domain, source=self.NAME, confidence=0.90))
        for cred in summary.credentials:
            findings.append(ParsedFinding(finding_type="credential_hit", value=cred.display(),
                source=self.NAME, confidence=0.85,
                metadata={"tag": cred.tag.value, "proto": cred.source_proto, "severity": cred.severity.value}))
        for alert in summary.anomalies:
            findings.append(ParsedFinding(finding_type="anomaly", value=alert.summary(),
                source=self.NAME, confidence=alert.confidence,
                metadata={"alert_type": alert.alert_type, "severity": alert.severity.value, "evidence": alert.evidence}))
        for tls in summary.tls_records:
            if tls.is_legacy_tls or tls.is_weak_cipher or tls.is_expired:
                findings.append(ParsedFinding(finding_type="tls_weakness",
                    value=f"{tls.sni or tls.dst_ip} — {tls.tls_version} {tls.cipher}",
                    source=self.NAME, confidence=0.90,
                    metadata={"legacy_tls": tls.is_legacy_tls, "weak_cipher": tls.is_weak_cipher,
                              "expired": tls.is_expired, "risk": tls.risk_level.value}))
        return findings


__all__ = [
    "TrafficIntelligenceTool", "TrafficSummary", "Packet", "FlowRecord",
    "ProtocolHit", "CredentialHit", "CredentialTag", "DNSEntry",
    "HTTPRecord", "TLSRecord", "AnomalyAlert", "Severity",
    "TSharkEngine", "PySharkEngine", "PCAPParser", "ProtocolDetector",
    "CredentialDetector", "DNSExtractor", "HTTPExtractor",
    "TLSFingerprinter", "AnomalyEngine", "LiveCaptureEngine", "CaptureSession",
]
