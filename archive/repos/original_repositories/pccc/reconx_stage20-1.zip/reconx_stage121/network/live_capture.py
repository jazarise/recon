"""
ReconX — Live Capture Engine (Stage 18.2)

Manages real-time network traffic capture sessions.

Commands:
    reconx traffic live
    reconx traffic live --iface eth0 --duration 30

Features:
  - Network interface enumeration
  - Short burst capture → PCAP → full pipeline analysis
  - Live stats display: packets/sec, top protocols, top talkers
  - Session reconstruction via PyShark
  - Graceful fallback: pyshark unavailable → tshark burst capture

Display (Rich live panel):
  ┌─ Traffic Intelligence — Live Capture ─────────────────────┐
  │ Interface: eth0    Duration: 30s    Packets: 1,247         │
  │ Packets/sec: 41.6  Protocols: TCP HTTP DNS TLS             │
  ├── Top Talkers ──────────────────────────────────────────────┤
  │  192.168.1.10  →  8.8.8.8      1,024 pkts  DNS            │
  │  192.168.1.10  →  142.x.x.x    341  pkts  HTTPS           │
  ├── Alerts ───────────────────────────────────────────────────┤
  │  ⚠ [HIGH] beaconing 192.168.1.50→91.x.x.x every 30s      │
  └────────────────────────────────────────────────────────────┘
"""
from __future__ import annotations

import logging
import os
import tempfile
import time
from dataclasses import dataclass, field
from typing import Optional

from .models import TrafficSummary, AnomalyAlert
from .tshark_engine import TSharkEngine
from .pyshark_engine import PySharkEngine
from .pcap_parser    import PCAPParser

logger = logging.getLogger("reconx.network.live_capture")


@dataclass
class CaptureSession:
    """State for an active or completed live capture session."""
    interface:    str
    duration_s:   int
    started_at:   float = field(default_factory=time.time)
    stopped_at:   float = 0.0
    pcap_path:    str   = ""
    packet_count: int   = 0
    state:        str   = "idle"    # idle | capturing | analyzing | complete | error
    error:        str   = ""
    summary:      Optional[TrafficSummary] = None

    @property
    def elapsed(self) -> float:
        end = self.stopped_at or time.time()
        return max(0.0, end - self.started_at)

    @property
    def is_active(self) -> bool:
        return self.state in ("capturing", "analyzing")


class LiveCaptureEngine:
    """
    Orchestrates live network traffic capture and real-time analysis.

    Usage:
        engine  = LiveCaptureEngine()
        ifaces, _ = engine.list_interfaces()
        session = engine.start("eth0", duration_s=30)
        summary = session.summary
    """

    def __init__(
        self,
        tshark:   Optional[TSharkEngine]  = None,
        pyshark:  Optional[PySharkEngine] = None,
        parser:   Optional[PCAPParser]    = None,
    ):
        self._tshark  = tshark  or TSharkEngine()
        self._pyshark = pyshark or PySharkEngine()
        self._parser  = parser  or PCAPParser()

    # ══════════════════════════════════════════════════════════════════════════
    # Interface management
    # ══════════════════════════════════════════════════════════════════════════

    def list_interfaces(self) -> tuple[list[dict], str]:
        """
        List available network interfaces for capture.
        Returns ([{index, name}], error_string).
        """
        if not self._tshark.available():
            return [], self._tshark.install_hint()
        return self._tshark.list_interfaces()

    def get_default_interface(self) -> str:
        """
        Try to find a sensible default interface (eth0, en0, wlan0, etc.).
        Falls back to first available interface.
        """
        ifaces, err = self.list_interfaces()
        if err or not ifaces:
            return "eth0"

        # Prefer common interface names
        preferred = ["eth0", "en0", "wlan0", "ens33", "ens3", "enp0s3"]
        names = [i["name"].split()[0] for i in ifaces]

        for pref in preferred:
            if pref in names:
                return pref

        # Return first non-loopback interface
        for name in names:
            if "lo" not in name.lower():
                return name

        return names[0] if names else "eth0"

    # ══════════════════════════════════════════════════════════════════════════
    # Capture
    # ══════════════════════════════════════════════════════════════════════════

    def start(
        self,
        interface:   str  = "",
        duration_s:  int  = 30,
        max_packets: int  = 10_000,
        display_filter: str = "",
    ) -> CaptureSession:
        """
        Capture live traffic and run the full analysis pipeline.

        Args:
            interface:      Network interface name. Auto-detected if empty.
            duration_s:     How long to capture (seconds).
            max_packets:    Max packets to capture (safety cap).
            display_filter: BPF filter for tshark (e.g. "port 80 or port 443").

        Returns a CaptureSession with .summary populated after completion.
        """
        iface = interface or self.get_default_interface()
        session = CaptureSession(interface=iface, duration_s=duration_s)

        if not self._tshark.available():
            session.state = "error"
            session.error = self._tshark.install_hint()
            return session

        # ── Step 1: Capture burst to temp PCAP ───────────────────────────────
        session.state = "capturing"
        logger.info("[LiveCapture] Starting %ds capture on %s", duration_s, iface)

        pcap_path, cap_err = self._tshark.capture_burst(
            interface=iface,
            duration_s=duration_s,
            max_packets=max_packets,
            display_filter=display_filter,
        )

        if cap_err or not pcap_path:
            session.state = "error"
            session.error = cap_err or "Capture produced no output"
            logger.warning("[LiveCapture] Capture failed: %s", session.error)
            return session

        session.pcap_path  = pcap_path
        session.stopped_at = time.time()
        logger.info("[LiveCapture] Capture complete: %s (%.1fs)", pcap_path, session.elapsed)

        # ── Step 2: Full analysis pipeline ───────────────────────────────────
        session.state = "analyzing"

        summary, parse_err = self._parser.analyze(pcap_path)
        if parse_err:
            logger.warning("[LiveCapture] Parse warning: %s", parse_err)

        summary.capture_iface = iface
        summary.start_time    = session.started_at
        summary.end_time      = session.stopped_at

        session.summary      = summary
        session.packet_count = summary.total_packets
        session.state        = "complete"

        logger.info(
            "[LiveCapture] Analysis complete: %d pkts, %d protocols, "
            "%d creds, %d anomalies",
            summary.total_packets,
            len(summary.protocols),
            len(summary.credentials),
            len(summary.anomalies),
        )

        # ── Cleanup temp file ─────────────────────────────────────────────────
        self._cleanup(pcap_path)
        return session

    # ══════════════════════════════════════════════════════════════════════════
    # Stats helpers (used by TUI live panel)
    # ══════════════════════════════════════════════════════════════════════════

    def quick_stats(self, pcap_path: str) -> dict:
        """
        Fast stats from a PCAP without full analysis — for live display updates.
        Returns a dict suitable for TUI rendering.
        """
        stats, _ = self._tshark.protocol_stats(pcap_path)
        convs, _ = self._tshark.conversation_table(pcap_path, layer="ip")

        total_pkts = sum(
            v.get("packets", 0) for v in stats.values()
            if isinstance(v, dict)
        )
        top_protos = sorted(
            [k.upper() for k in stats if k not in ("eth", "ip", "ipv6", "tcp", "udp")],
            key=lambda p: stats.get(p.lower(), {}).get("packets", 0),
            reverse=True,
        )[:6]

        return {
            "total_packets": total_pkts,
            "protocols":     top_protos,
            "top_talkers":   convs[:5],
            "proto_stats":   stats,
        }

    # ══════════════════════════════════════════════════════════════════════════
    # Internal
    # ══════════════════════════════════════════════════════════════════════════

    def _cleanup(self, path: str) -> None:
        """Remove temp PCAP files after analysis."""
        if path and os.path.exists(path) and path.startswith(tempfile.gettempdir()):
            try:
                os.remove(path)
                logger.debug("[LiveCapture] Removed temp PCAP: %s", path)
            except Exception as exc:
                logger.debug("[LiveCapture] Could not remove temp PCAP: %s", exc)
