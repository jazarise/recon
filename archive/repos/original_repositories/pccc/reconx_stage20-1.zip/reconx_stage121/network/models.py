"""
ReconX — Traffic Intelligence Layer: Shared Data Models (Stage 18.2)

All structs that flow between modules inside reconx/network/.
Kept in one place so every module imports from here — no circular deps.

Model hierarchy:
  Packet          → one captured frame
  FlowRecord      → reconstructed TCP/UDP conversation
  ProtocolHit     → one protocol detected with confidence
  CredentialHit   → one potential credential/token found
  DNSEntry        → one DNS query or response
  HTTPRecord      → one HTTP request/response pair
  TLSRecord       → one TLS session metadata record
  AnomalyAlert    → one anomaly engine detection
  TrafficSummary  → aggregated session-level intelligence
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


# ── Severity / Confidence ─────────────────────────────────────────────────────

class Severity(str, Enum):
    LOW      = "LOW"
    MEDIUM   = "MEDIUM"
    HIGH     = "HIGH"
    CRITICAL = "CRITICAL"


class CredentialTag(str, Enum):
    TOKEN      = "TOKEN"
    CREDENTIAL = "CREDENTIAL"
    SESSION    = "SESSION"
    JWT        = "JWT"
    API_KEY    = "API_KEY"
    BASIC_AUTH = "BASIC_AUTH"


# ── Packet-level ──────────────────────────────────────────────────────────────

@dataclass
class Packet:
    """Minimal representation of one captured network frame."""
    timestamp:  float          # epoch seconds
    src_ip:     str
    dst_ip:     str
    src_port:   int = 0
    dst_port:   int = 0
    protocol:   str = ""       # "TCP" | "UDP" | "ICMP" | "ARP" | ...
    length:     int = 0
    payload:    bytes = field(default_factory=bytes)
    layer_names: list[str] = field(default_factory=list)

    @property
    def is_tcp(self) -> bool:   return self.protocol.upper() == "TCP"
    @property
    def is_udp(self) -> bool:   return self.protocol.upper() == "UDP"
    @property
    def flow_key(self) -> tuple: return (self.src_ip, self.dst_ip, self.src_port, self.dst_port, self.protocol)


@dataclass
class FlowRecord:
    """Reconstructed bidirectional network conversation."""
    src_ip:     str
    dst_ip:     str
    src_port:   int
    dst_port:   int
    protocol:   str
    start_time: float = field(default_factory=time.time)
    end_time:   float = 0.0
    packets:    int   = 0
    bytes_sent: int   = 0
    app_proto:  str   = ""    # detected application protocol

    @property
    def duration_s(self) -> float:
        return max(0.0, (self.end_time or time.time()) - self.start_time)

    @property
    def key(self) -> tuple:
        # Canonical: sort src/dst so A→B and B→A share a key
        if (self.src_ip, self.src_port) < (self.dst_ip, self.dst_port):
            return (self.src_ip, self.dst_ip, self.src_port, self.dst_port, self.protocol)
        return (self.dst_ip, self.src_ip, self.dst_port, self.src_port, self.protocol)


# ── Protocol detection ────────────────────────────────────────────────────────

@dataclass
class ProtocolHit:
    """One protocol identified in captured traffic."""
    protocol:   str          # "HTTP" | "DNS" | "TLS" | "FTP" | ...
    confidence: float        # 0.0–1.0
    port:       int   = 0
    direction:  str   = ""   # "inbound" | "outbound" | "internal"
    detail:     str   = ""   # e.g. "HTTP/1.1 on port 8080"

    @property
    def confidence_pct(self) -> str:
        return f"{self.confidence * 100:.0f}%"


# ── Credential / token detection ──────────────────────────────────────────────

@dataclass
class CredentialHit:
    """
    Potential credential or sensitive token detected in traffic.

    The raw value is NEVER stored in full — always masked.
    .masked_value shows the first 4 chars + asterisks.
    .display() returns a safe string for TUI/report output.
    """
    tag:        CredentialTag
    masked_value: str          # e.g. "eyJh********"
    source_proto: str          # "HTTP" | "FTP" | "SMTP" | ...
    src_ip:     str = ""
    dst_ip:     str = ""
    detail:     str = ""       # "Authorization: Bearer ..."
    severity:   Severity = Severity.HIGH

    def display(self) -> str:
        return f"[{self.tag.value}] {self.source_proto} {self.src_ip}→{self.dst_ip} — {self.masked_value}"

    @staticmethod
    def mask(value: str, keep: int = 4) -> str:
        """Mask all but the first `keep` characters."""
        if len(value) <= keep:
            return "*" * len(value)
        return value[:keep] + "*" * min(8, len(value) - keep)


# ── DNS intelligence ──────────────────────────────────────────────────────────

@dataclass
class DNSEntry:
    """One DNS query or response extracted from traffic."""
    query_name:  str
    record_type: str           # "A" | "AAAA" | "CNAME" | "MX" | "TXT" | ...
    answers:     list[str] = field(default_factory=list)
    src_ip:      str = ""
    dst_ip:      str = ""
    timestamp:   float = field(default_factory=time.time)
    is_response: bool = False
    ttl:         int  = 0
    # Anomaly flags
    is_tunnel_suspect: bool = False
    is_high_freq:      bool = False
    tunnel_reason:     str  = ""


# ── HTTP intelligence ─────────────────────────────────────────────────────────

@dataclass
class HTTPRecord:
    """One HTTP request/response pair extracted from traffic."""
    src_ip:      str
    dst_ip:      str
    method:      str           # "GET" | "POST" | ...
    host:        str
    path:        str
    status_code: int  = 0
    user_agent:  str  = ""
    content_type: str = ""
    req_headers: dict[str, str] = field(default_factory=dict)
    resp_headers: dict[str, str] = field(default_factory=dict)
    body_preview: str = ""    # first 200 chars of body
    timestamp:   float = field(default_factory=time.time)

    @property
    def url(self) -> str:
        return f"http://{self.host}{self.path}"

    @property
    def is_api(self) -> bool:
        import re
        return bool(re.search(r"/api/|/v\d+/|graphql|/rpc", self.path, re.I))

    @property
    def is_auth(self) -> bool:
        import re
        return bool(re.search(r"/login|/auth|/signin|/token|/oauth", self.path, re.I))

    @property
    def is_admin(self) -> bool:
        import re
        return bool(re.search(r"/admin|/console|/dashboard|/manage", self.path, re.I))

    @property
    def is_upload(self) -> bool:
        import re
        return bool(re.search(r"/upload|/file|multipart", self.path + self.content_type, re.I))


# ── TLS fingerprinting ────────────────────────────────────────────────────────

@dataclass
class TLSRecord:
    """TLS session metadata extracted from a handshake."""
    src_ip:      str
    dst_ip:      str
    sni:         str  = ""    # Server Name Indication
    ja3:         str  = ""    # JA3 client fingerprint hash
    ja3s:        str  = ""    # JA3S server fingerprint hash
    tls_version: str  = ""    # "TLSv1.2" | "TLSv1.3" | ...
    cipher:      str  = ""
    # Certificate fields (from server cert if captured)
    cert_subject: str = ""
    cert_issuer:  str = ""
    cert_not_after: str = ""
    cert_not_before: str = ""
    cert_serial:  str = ""
    cert_sans:    list[str] = field(default_factory=list)
    # Risk flags
    is_expired:   bool = False
    is_self_signed: bool = False
    is_weak_cipher: bool = False
    is_legacy_tls:  bool = False   # TLS < 1.2
    timestamp:    float = field(default_factory=time.time)

    @property
    def risk_level(self) -> Severity:
        if self.is_expired or self.is_legacy_tls:
            return Severity.HIGH
        if self.is_self_signed or self.is_weak_cipher:
            return Severity.MEDIUM
        return Severity.LOW


# ── Anomaly detection ─────────────────────────────────────────────────────────

@dataclass
class AnomalyAlert:
    """One anomaly detected by the anomaly engine."""
    alert_type:  str           # "beaconing" | "high_freq" | "protocol_misuse" | ...
    description: str
    src_ip:      str = ""
    dst_ip:      str = ""
    severity:    Severity = Severity.MEDIUM
    confidence:  float = 0.75  # 0.0–1.0
    evidence:    dict  = field(default_factory=dict)
    timestamp:   float = field(default_factory=time.time)

    @property
    def confidence_pct(self) -> str:
        return f"{self.confidence * 100:.0f}%"

    def summary(self) -> str:
        return (f"[{self.severity.value}] {self.alert_type} "
                f"{self.src_ip}→{self.dst_ip} ({self.confidence_pct}) — {self.description}")


# ── Session-level summary ─────────────────────────────────────────────────────

@dataclass
class TrafficSummary:
    """
    Aggregated intelligence from an entire PCAP file or live capture session.
    This is the top-level object fed into ToolRunResult.data and the report.
    """
    # Source metadata
    source_file:    str   = ""
    capture_iface:  str   = ""
    start_time:     float = 0.0
    end_time:       float = 0.0
    total_packets:  int   = 0
    total_bytes:    int   = 0

    # Discovered hosts and IPs
    hosts:          list[str] = field(default_factory=list)
    ips:            list[str] = field(default_factory=list)
    internal_ips:   list[str] = field(default_factory=list)
    external_ips:   list[str] = field(default_factory=list)
    domains:        list[str] = field(default_factory=list)

    # Protocol inventory
    protocols:      list[ProtocolHit]    = field(default_factory=list)
    flows:          list[FlowRecord]     = field(default_factory=list)

    # Intelligence layers
    dns_entries:    list[DNSEntry]       = field(default_factory=list)
    http_records:   list[HTTPRecord]     = field(default_factory=list)
    tls_records:    list[TLSRecord]      = field(default_factory=list)
    credentials:    list[CredentialHit]  = field(default_factory=list)
    anomalies:      list[AnomalyAlert]   = field(default_factory=list)

    # Derived statistics
    packets_per_sec: float = 0.0
    top_talkers:    list[dict] = field(default_factory=list)   # {ip, packets, bytes}
    top_destinations: list[dict] = field(default_factory=list)  # {ip, port, count}
    protocol_counts: dict[str, int] = field(default_factory=dict)

    @property
    def duration_s(self) -> float:
        return max(0.0, self.end_time - self.start_time) if self.end_time else 0.0

    @property
    def has_credentials(self) -> bool:
        return len(self.credentials) > 0

    @property
    def has_anomalies(self) -> bool:
        return len(self.anomalies) > 0

    @property
    def high_severity_anomalies(self) -> list[AnomalyAlert]:
        return [a for a in self.anomalies if a.severity in (Severity.HIGH, Severity.CRITICAL)]

    def to_dict(self) -> dict:
        """JSON-serialisable representation for ToolRunResult.data and caching."""
        def _ser(obj):
            """Recursively serialise dataclass instances."""
            if hasattr(obj, "__dataclass_fields__"):
                return {k: _ser(v) for k, v in obj.__dict__.items()
                        if not k.startswith("_") and k != "payload"}
            if isinstance(obj, list):
                return [_ser(i) for i in obj]
            if isinstance(obj, dict):
                return {k: _ser(v) for k, v in obj.items()}
            if isinstance(obj, Enum):
                return obj.value
            if isinstance(obj, bytes):
                return ""   # never serialise raw bytes
            return obj

        return _ser(self)

    def add_ip(self, ip: str) -> None:
        """Classify and add an IP to the appropriate list."""
        import ipaddress
        if ip in self.ips:
            return
        self.ips.append(ip)
        try:
            addr = ipaddress.ip_address(ip)
            if addr.is_private:
                if ip not in self.internal_ips:
                    self.internal_ips.append(ip)
            else:
                if ip not in self.external_ips:
                    self.external_ips.append(ip)
        except ValueError:
            pass
