"""
ReconX — Traffic Anomaly Engine (Stage 18.2)

Detects behavioral anomalies in captured/live traffic:

  1. Beaconing     — periodic connections to same external host (C2 signal)
  2. High-freq     — >N connections/sec to same destination
  3. Protocol misuse — known protocol on unexpected port
  4. Unusual outbound — internal host contacting rare external IPs
  5. DNS tunneling — flagged by dns_extractor, re-raised as AnomalyAlert
  6. Data exfil signal — large outbound bytes to single destination
  7. Port scan signal — single src contacting many ports on one dst

All detections assign: severity (LOW/MEDIUM/HIGH) + confidence (0.0–1.0).
Passive only — no traffic is generated or blocked.
"""
from __future__ import annotations

import logging
import math
import statistics
from collections import Counter, defaultdict
from typing import TYPE_CHECKING

from .models import AnomalyAlert, Severity, TrafficSummary

if TYPE_CHECKING:
    pass

logger = logging.getLogger("reconx.network.anomaly_engine")

# ── Thresholds ────────────────────────────────────────────────────────────────
_BEACON_MIN_HITS       = 8      # min occurrences to consider beaconing
_BEACON_JITTER_PCT     = 0.15   # allowed jitter (15%) in interval regularity
_HIGH_FREQ_CONNS       = 50     # connections/session to same dst = high-freq
_EXFIL_BYTES           = 10_000_000   # 10 MB outbound to single external dst
_PORT_SCAN_PORTS       = 20     # unique dst ports from same src to same host
_PROTO_MISUSE_MAP: dict[str, set[int]] = {
    # protocol → expected standard ports
    "HTTP":     {80, 8080, 8000, 3000, 5000, 8888},
    "HTTPS/TLS":{443, 8443, 4443},
    "SSH":      {22},
    "FTP":      {21, 20},
    "SMTP":     {25, 587, 465},
    "DNS":      {53},
    "RDP":      {3389},
    "SMB":      {445, 139},
}


class AnomalyEngine:
    """
    Behavioral anomaly detector for TrafficSummary data.

    Called after all extractors have populated the TrafficSummary.
    Operates on flows, DNS entries, and top-talker data.

    Usage:
        engine = AnomalyEngine()
        alerts = engine.analyze(summary)
    """

    def analyze(self, summary: TrafficSummary) -> list[AnomalyAlert]:
        """
        Run all anomaly detectors against a populated TrafficSummary.
        Returns list of AnomalyAlert (may be empty).
        Never raises.
        """
        alerts: list[AnomalyAlert] = []

        try:
            alerts.extend(self._detect_beaconing(summary))
        except Exception as exc:
            logger.debug("[AnomalyEngine] beaconing error: %s", exc)

        try:
            alerts.extend(self._detect_high_frequency(summary))
        except Exception as exc:
            logger.debug("[AnomalyEngine] high_freq error: %s", exc)

        try:
            alerts.extend(self._detect_protocol_misuse(summary))
        except Exception as exc:
            logger.debug("[AnomalyEngine] proto_misuse error: %s", exc)

        try:
            alerts.extend(self._detect_exfil_signal(summary))
        except Exception as exc:
            logger.debug("[AnomalyEngine] exfil error: %s", exc)

        try:
            alerts.extend(self._detect_port_scan(summary))
        except Exception as exc:
            logger.debug("[AnomalyEngine] port_scan error: %s", exc)

        try:
            alerts.extend(self._import_dns_tunnel_alerts(summary))
        except Exception as exc:
            logger.debug("[AnomalyEngine] dns_tunnel error: %s", exc)

        logger.info("[AnomalyEngine] %d anomaly alerts generated", len(alerts))
        return alerts

    # ══════════════════════════════════════════════════════════════════════════
    # Detectors
    # ══════════════════════════════════════════════════════════════════════════

    def _detect_beaconing(self, summary: TrafficSummary) -> list[AnomalyAlert]:
        """
        Beaconing: same src→dst pair appears repeatedly at regular intervals.
        Groups flow records by (src_ip, dst_ip), computes inter-flow intervals,
        checks for low coefficient-of-variation (regularity).
        """
        alerts: list[AnomalyAlert] = []
        if not summary.flows:
            return alerts

        # Group flows by (src, dst)
        groups: dict[tuple, list[float]] = defaultdict(list)
        for flow in summary.flows:
            key = (flow.src_ip, flow.dst_ip)
            groups[key].append(flow.start_time)

        for (src, dst), timestamps in groups.items():
            if len(timestamps) < _BEACON_MIN_HITS:
                continue

            timestamps_sorted = sorted(timestamps)
            intervals = [
                timestamps_sorted[i + 1] - timestamps_sorted[i]
                for i in range(len(timestamps_sorted) - 1)
            ]
            if not intervals or min(intervals) <= 0:
                continue

            mean_iv = statistics.mean(intervals)
            if mean_iv <= 0:
                continue

            try:
                cv = statistics.stdev(intervals) / mean_iv   # coefficient of variation
            except statistics.StatisticsError:
                continue

            # Low CV = very regular = suspicious
            if cv <= _BEACON_JITTER_PCT:
                confidence = min(0.95, 0.60 + (1.0 - cv) * 0.40)
                alerts.append(AnomalyAlert(
                    alert_type  = "beaconing",
                    description = (
                        f"Regular connection pattern: every ~{mean_iv:.1f}s "
                        f"(CV={cv:.3f}, {len(timestamps)} flows) — possible C2 beacon"
                    ),
                    src_ip      = src,
                    dst_ip      = dst,
                    severity    = Severity.HIGH,
                    confidence  = confidence,
                    evidence    = {
                        "flow_count":  len(timestamps),
                        "interval_s":  round(mean_iv, 2),
                        "cv":          round(cv, 4),
                    },
                ))

        return alerts

    def _detect_high_frequency(self, summary: TrafficSummary) -> list[AnomalyAlert]:
        """
        High-frequency: single src connects to same dst more than threshold times.
        """
        alerts: list[AnomalyAlert] = []
        counts: Counter = Counter()

        for flow in summary.flows:
            counts[(flow.src_ip, flow.dst_ip, flow.dst_port)] += 1

        for (src, dst, port), count in counts.items():
            if count >= _HIGH_FREQ_CONNS:
                sev = Severity.HIGH if count >= _HIGH_FREQ_CONNS * 3 else Severity.MEDIUM
                alerts.append(AnomalyAlert(
                    alert_type  = "high_frequency",
                    description = (
                        f"{count} connections from {src} to {dst}:{port} — "
                        f"unusually high connection frequency"
                    ),
                    src_ip      = src,
                    dst_ip      = dst,
                    severity    = sev,
                    confidence  = min(0.90, 0.60 + count / (_HIGH_FREQ_CONNS * 10)),
                    evidence    = {"connection_count": count, "dst_port": port},
                ))

        return alerts

    def _detect_protocol_misuse(self, summary: TrafficSummary) -> list[AnomalyAlert]:
        """
        Protocol misuse: detected protocol on non-standard port (e.g. SSH on 443).
        """
        alerts: list[AnomalyAlert] = []

        for proto_hit in summary.protocols:
            name     = proto_hit.protocol
            port     = proto_hit.port
            expected = _PROTO_MISUSE_MAP.get(name)
            if not expected or not port:
                continue
            if port not in expected:
                alerts.append(AnomalyAlert(
                    alert_type  = "protocol_misuse",
                    description = (
                        f"{name} detected on non-standard port {port} "
                        f"(expected: {sorted(expected)})"
                    ),
                    severity    = Severity.MEDIUM,
                    confidence  = 0.75,
                    evidence    = {"protocol": name, "observed_port": port,
                                   "expected_ports": sorted(expected)},
                ))

        return alerts

    def _detect_exfil_signal(self, summary: TrafficSummary) -> list[AnomalyAlert]:
        """
        Data exfiltration signal: large outbound bytes to a single external IP.
        """
        alerts: list[AnomalyAlert] = []
        outbound: dict[str, int] = defaultdict(int)

        for flow in summary.flows:
            if flow.src_ip in summary.internal_ips and flow.dst_ip in summary.external_ips:
                outbound[flow.dst_ip] += flow.bytes_sent

        for dst_ip, total_bytes in outbound.items():
            if total_bytes >= _EXFIL_BYTES:
                mb = total_bytes / 1_000_000
                alerts.append(AnomalyAlert(
                    alert_type  = "exfil_signal",
                    description = (
                        f"{mb:.1f} MB sent to external {dst_ip} — "
                        f"possible data exfiltration"
                    ),
                    dst_ip      = dst_ip,
                    severity    = Severity.HIGH,
                    confidence  = min(0.85, 0.55 + (mb / 100) * 0.30),
                    evidence    = {"bytes": total_bytes, "megabytes": round(mb, 2)},
                ))

        return alerts

    def _detect_port_scan(self, summary: TrafficSummary) -> list[AnomalyAlert]:
        """
        Port scan signal: one source contacts many unique ports on same destination.
        """
        alerts: list[AnomalyAlert] = []
        # {(src_ip, dst_ip): set of ports}
        port_sets: dict[tuple, set] = defaultdict(set)

        for flow in summary.flows:
            port_sets[(flow.src_ip, flow.dst_ip)].add(flow.dst_port)

        for (src, dst), ports in port_sets.items():
            if len(ports) >= _PORT_SCAN_PORTS:
                alerts.append(AnomalyAlert(
                    alert_type  = "port_scan_signal",
                    description = (
                        f"{src} contacted {len(ports)} unique ports on {dst} — "
                        f"possible port scan"
                    ),
                    src_ip      = src,
                    dst_ip      = dst,
                    severity    = Severity.MEDIUM,
                    confidence  = min(0.90, 0.60 + len(ports) / 200),
                    evidence    = {
                        "unique_ports": len(ports),
                        "sample_ports": sorted(ports)[:10],
                    },
                ))

        return alerts

    def _import_dns_tunnel_alerts(self, summary: TrafficSummary) -> list[AnomalyAlert]:
        """Promote DNS tunnel suspects to AnomalyAlerts."""
        alerts: list[AnomalyAlert] = []
        seen: set[str] = set()

        for entry in summary.dns_entries:
            if not entry.is_tunnel_suspect:
                continue
            key = f"{entry.query_name}:{entry.src_ip}"
            if key in seen:
                continue
            seen.add(key)

            alerts.append(AnomalyAlert(
                alert_type  = "dns_tunneling",
                description = (
                    f"DNS tunneling suspect: {entry.query_name} — {entry.tunnel_reason}"
                ),
                src_ip      = entry.src_ip,
                dst_ip      = entry.dst_ip,
                severity    = Severity.HIGH,
                confidence  = 0.80,
                evidence    = {
                    "query_name":    entry.query_name,
                    "tunnel_reason": entry.tunnel_reason,
                },
            ))

        return alerts
