"""
ReconX — Stage 18.2 Traffic Intelligence Report Injector

Injects a "Traffic Intelligence" HTML section into an existing ReconX report.

Sections added:
  1. Capture Summary      — source, interface, duration, packet counts
  2. Protocol Inventory   — detected protocols with confidence bars
  3. Credential Findings  — masked credential hits with severity badges
  4. DNS Intelligence     — query table with tunnel suspect flagging
  5. TLS Analysis         — session table with risk indicators
  6. Anomaly Timeline     — behavioral anomalies with severity + evidence
  7. Traffic Stats        — top talkers, top destinations, packets/sec

Usage:
    from reconx.network.report_injector import inject_traffic_section
    inject_traffic_section("reports/reconx_target.html", summary.to_dict())
"""
from __future__ import annotations

from html import escape
from pathlib import Path
from typing import Optional

# ── CSS ───────────────────────────────────────────────────────────────────────
_TRAFFIC_CSS = """
/* ── Stage 18.2 Traffic Intelligence ── */
.traffic-section { margin-top: 32px; }
.traffic-status-bar {
  display:flex; gap:12px; flex-wrap:wrap; align-items:center;
  margin-bottom:20px;
  background:var(--bg2,#0c1420); border:1px solid var(--border,#1a3050);
  border-left:3px solid #30d158; border-radius:6px; padding:12px 20px;
  font-family:var(--font-mono,monospace); font-size:12px;
}
.traffic-status-bar .lbl { color:var(--dim,#5a7a9a); }
.traffic-status-bar .val { color:#c8d8e8; font-weight:600; margin-left:4px; }
.traffic-status-bar .ok  { color:#30d158; }
.traffic-stats {
  display:grid; grid-template-columns:repeat(auto-fit,minmax(100px,1fr));
  gap:10px; margin-bottom:20px;
}
.traffic-stat {
  background:var(--bg2,#0c1420); border:1px solid var(--border,#1a3050);
  border-radius:6px; padding:12px 8px; text-align:center;
}
.traffic-stat .n {
  font-size:24px; font-weight:700; font-family:var(--font-mono,monospace);
  line-height:1; margin-bottom:4px;
}
.traffic-stat .lbl {
  font-size:10px; letter-spacing:2px; text-transform:uppercase;
  color:var(--dim,#5a7a9a);
}
.trf-tbl-wrap { margin-bottom:22px; }
.trf-tbl-title {
  font-size:13px; font-weight:600; letter-spacing:2px; text-transform:uppercase;
  color:#30d158; border-bottom:1px solid var(--border,#1a3050);
  padding-bottom:8px; margin-bottom:10px;
}
.trf-tbl { width:100%; border-collapse:collapse; font-size:12px; }
.trf-tbl th {
  font-size:10px; letter-spacing:1.5px; text-transform:uppercase;
  color:var(--dim,#5a7a9a); text-align:left;
  padding:6px 10px; border-bottom:1px solid var(--border,#1a3050);
}
.trf-tbl td {
  padding:8px 10px; border-bottom:1px solid rgba(26,48,80,0.4);
  font-family:var(--font-mono,monospace); vertical-align:top; word-break:break-all;
}
.trf-tbl tr:last-child td { border-bottom:none; }
.trf-tbl tr:hover td { background:rgba(48,209,88,0.03); }
.conf-bar {
  display:inline-block; height:6px; border-radius:3px;
  background:#30d158; vertical-align:middle; margin-right:6px;
}
.sev-critical { color:#ff2d55; } .sev-high { color:#ff6b35; }
.sev-medium   { color:#ffd60a; } .sev-low  { color:#30d158; }
.tag-jwt   { color:#ff6b35; } .tag-token   { color:#00d4ff; }
.tag-cred  { color:#ff2d55; } .tag-session { color:#ffd60a; }
.tag-apikey { color:#9b59b6; } .tag-basic  { color:#ff2d55; }
.tunnel-flag { color:#ff2d55; font-weight:700; font-size:10px; }
.tls-ok   { color:#30d158; } .tls-risk { color:#ff6b35; }
.traffic-empty { text-align:center; color:var(--dim,#5a7a9a); font-style:italic; padding:14px; }
"""

# ── Helpers ───────────────────────────────────────────────────────────────────

def _stat(n, label: str, colour: str) -> str:
    return (f'<div class="traffic-stat">'
            f'<div class="n" style="color:{colour}">{escape(str(n))}</div>'
            f'<div class="lbl">{escape(label)}</div></div>')


def _sev_class(sev: str) -> str:
    return {"HIGH": "sev-high", "CRITICAL": "sev-critical",
            "MEDIUM": "sev-medium", "LOW": "sev-low"}.get(sev.upper(), "")


def _conf_bar(conf: float) -> str:
    width = int(conf * 80)
    return f'<span class="conf-bar" style="width:{width}px"></span>{conf*100:.0f}%'


def _human_bytes(b) -> str:
    try:
        b = int(b)
    except (ValueError, TypeError):
        return "—"
    for unit in ("B", "KB", "MB", "GB"):
        if b < 1024:
            return f"{b}{unit}"
        b //= 1024
    return f"{b}TB"


# ══════════════════════════════════════════════════════════════════════════════
# Section builders
# ══════════════════════════════════════════════════════════════════════════════

def _build_status_bar(data: dict) -> str:
    src      = escape(data.get("source_file") or data.get("capture_iface") or "—")
    pkts     = f"{data.get('total_packets', 0):,}"
    dur      = f"{data.get('duration_s', 0) or (data.get('end_time', 0) - data.get('start_time', 0)):.1f}s"
    pps      = f"{data.get('packets_per_sec', 0):.1f}" if data.get("packets_per_sec") else "—"
    return f"""
<div class="traffic-status-bar">
  <span class="lbl">Source:</span><span class="val">{src}</span>
  &nbsp;|&nbsp;
  <span class="lbl">Packets:</span><span class="val ok">{pkts}</span>
  &nbsp;|&nbsp;
  <span class="lbl">Duration:</span><span class="val">{dur}</span>
  &nbsp;|&nbsp;
  <span class="lbl">Pkt/s:</span><span class="val">{pps}</span>
</div>"""


def _build_stats_row(data: dict) -> str:
    protos = data.get("protocols", [])
    return (
        '<div class="traffic-stats">'
        + _stat(f"{data.get('total_packets', 0):,}", "Packets",   "#30d158")
        + _stat(len(protos),                          "Protocols", "#00d4ff")
        + _stat(len(data.get("ips", [])),             "IPs",       "#ffd60a")
        + _stat(len(data.get("hosts", [])),           "Hosts",     "#00ffcc")
        + _stat(len(data.get("dns_entries", [])),     "DNS",       "#9b59b6")
        + _stat(len(data.get("http_records", [])),    "HTTP",      "#00d4ff")
        + _stat(len(data.get("tls_records", [])),     "TLS",       "#00d4ff")
        + _stat(len(data.get("credentials", [])),     "Creds",     "#ff2d55")
        + _stat(len(data.get("anomalies", [])),       "Anomalies", "#ff6b35")
        + '</div>'
    )


def _build_protocol_table(data: dict) -> str:
    protos = data.get("protocols", [])
    if protos:
        rows = "".join(
            f'<tr>'
            f'<td style="color:#30d158;font-weight:700">{escape(str(p.get("protocol","—")))}</td>'
            f'<td>{_conf_bar(float(p.get("confidence", 0.8)))}</td>'
            f'<td style="color:#ffd60a">{escape(str(p.get("port","—")))}</td>'
            f'<td style="color:#5a7a9a">{escape(str(p.get("detail",""))[:60])}</td>'
            f'</tr>'
            for p in protos[:20]
        )
    else:
        rows = '<tr><td colspan="4" class="traffic-empty">No protocols detected</td></tr>'

    return f"""
<div class="trf-tbl-wrap">
  <div class="trf-tbl-title">📡 Protocol Inventory</div>
  <table class="trf-tbl">
    <thead><tr><th>Protocol</th><th>Confidence</th><th>Port</th><th>Detail</th></tr></thead>
    <tbody>{rows}</tbody>
  </table>
</div>"""


def _build_credential_table(data: dict) -> str:
    creds = data.get("credentials", [])
    if creds:
        rows = "".join(
            f'<tr>'
            f'<td class="tag-{escape(str(c.get("tag","")).lower().replace("_",""))}">'
            f'[{escape(str(c.get("tag","—")))}]</td>'
            f'<td style="color:#00d4ff">{escape(str(c.get("source_proto","—")))}</td>'
            f'<td style="font-family:monospace">{escape(str(c.get("masked_value","—")))}</td>'
            f'<td style="color:#5a7a9a">'
            f'{escape(str(c.get("src_ip","")))}→{escape(str(c.get("dst_ip","")))}</td>'
            f'<td class="{_sev_class(str(c.get("severity","MEDIUM")))}">'
            f'{escape(str(c.get("severity","—")))}</td>'
            f'</tr>'
            for c in creds[:15]
        )
    else:
        rows = '<tr><td colspan="5" class="traffic-empty" style="color:#30d158">✅ No credentials detected</td></tr>'

    return f"""
<div class="trf-tbl-wrap">
  <div class="trf-tbl-title">🔑 Credential Findings (masked)</div>
  <table class="trf-tbl">
    <thead><tr><th>Tag</th><th>Protocol</th><th>Value (masked)</th><th>Route</th><th>Severity</th></tr></thead>
    <tbody>{rows}</tbody>
  </table>
</div>"""


def _build_dns_table(data: dict) -> str:
    entries = data.get("dns_entries", [])
    seen    = set()
    rows    = []
    for e in entries:
        name = str(e.get("query_name", ""))
        if name in seen or len(rows) >= 25:
            continue
        seen.add(name)
        flag = ""
        if e.get("is_tunnel_suspect"):
            flag = f'<span class="tunnel-flag">⚠ TUNNEL</span>'
        elif e.get("is_high_freq"):
            flag = '<span style="color:#ffd60a">↑ HIGH-FREQ</span>'
        answers = ", ".join(e.get("answers", [])[:2])
        rows.append(
            f'<tr><td style="color:#00d4ff">{escape(name[:50])}</td>'
            f'<td style="color:#ffd60a">{escape(str(e.get("record_type","—")))}</td>'
            f'<td style="color:#5a7a9a">{escape(answers[:35])}</td>'
            f'<td>{flag}</td></tr>'
        )
    if not rows:
        rows = ['<tr><td colspan="4" class="traffic-empty">No DNS data</td></tr>']

    tunnel_count = sum(1 for e in entries if e.get("is_tunnel_suspect"))
    warning = (f'<p style="color:#ff2d55;margin-top:8px;font-size:12px">'
               f'⚠ {tunnel_count} DNS tunneling suspect(s) detected</p>') if tunnel_count else ""

    return f"""
<div class="trf-tbl-wrap">
  <div class="trf-tbl-title">🌐 DNS Intelligence</div>
  <table class="trf-tbl">
    <thead><tr><th>Query</th><th>Type</th><th>Answers</th><th>Flag</th></tr></thead>
    <tbody>{"".join(rows)}</tbody>
  </table>
  {warning}
</div>"""


def _build_tls_table(data: dict) -> str:
    records = data.get("tls_records", [])
    if records:
        rows = "".join(
            f'<tr>'
            f'<td style="color:#00d4ff">{escape(str(r.get("sni") or r.get("dst_ip","—")))}</td>'
            f'<td style="color:#ffd60a">{escape(str(r.get("tls_version","—")))}</td>'
            f'<td style="color:#5a7a9a;font-size:11px">{escape(str(r.get("ja3","—"))[:20])}</td>'
            f'<td class="{"tls-risk" if any([r.get("is_legacy_tls"),r.get("is_weak_cipher"),r.get("is_expired")]) else "tls-ok"}">'
            f'{"  ".join(filter(None, ["Legacy TLS" if r.get("is_legacy_tls") else "","Weak cipher" if r.get("is_weak_cipher") else "","Expired" if r.get("is_expired") else ""])) or "✓ OK"}'
            f'</td></tr>'
            for r in records[:15]
        )
    else:
        rows = '<tr><td colspan="4" class="traffic-empty">No TLS sessions captured</td></tr>'

    return f"""
<div class="trf-tbl-wrap">
  <div class="trf-tbl-title">🔒 TLS Analysis</div>
  <table class="trf-tbl">
    <thead><tr><th>SNI / Host</th><th>TLS Version</th><th>JA3</th><th>Risks</th></tr></thead>
    <tbody>{rows}</tbody>
  </table>
</div>"""


def _build_anomaly_table(data: dict) -> str:
    anomalies = data.get("anomalies", [])
    if anomalies:
        sorted_a = sorted(anomalies,
            key=lambda a: {"CRITICAL":4,"HIGH":3,"MEDIUM":2,"LOW":1}.get(
                str(a.get("severity","LOW")).upper(), 0), reverse=True)
        rows = "".join(
            f'<tr>'
            f'<td class="{_sev_class(str(a.get("severity","MEDIUM")))}" style="font-weight:700">'
            f'{escape(str(a.get("severity","—")))}</td>'
            f'<td style="color:#ffd60a">{escape(str(a.get("alert_type","—")).replace("_"," "))}</td>'
            f'<td>{_conf_bar(float(a.get("confidence", 0.7)))}</td>'
            f'<td style="color:#c8d8e8">{escape(str(a.get("description","—"))[:80])}</td>'
            f'<td style="color:#5a7a9a">{escape(str(a.get("src_ip","")))}→{escape(str(a.get("dst_ip","")))}</td>'
            f'</tr>'
            for a in sorted_a[:15]
        )
    else:
        rows = '<tr><td colspan="5" class="traffic-empty" style="color:#30d158">✅ No anomalies detected</td></tr>'

    return f"""
<div class="trf-tbl-wrap">
  <div class="trf-tbl-title">⚠️ Anomaly Timeline</div>
  <table class="trf-tbl">
    <thead><tr><th>Severity</th><th>Type</th><th>Confidence</th><th>Description</th><th>Route</th></tr></thead>
    <tbody>{rows}</tbody>
  </table>
</div>"""


def _build_talkers_table(data: dict) -> str:
    talkers = data.get("top_talkers", [])
    if talkers:
        rows = "".join(
            f'<tr>'
            f'<td style="color:#ffd60a">{escape(str(t.get("ip","—")))}</td>'
            f'<td style="color:#00d4ff;text-align:right">{t.get("packets",0):,}</td>'
            f'<td style="color:#c8d8e8;text-align:right">{_human_bytes(t.get("bytes",0))}</td>'
            f'</tr>'
            for t in talkers[:8]
        )
    else:
        rows = '<tr><td colspan="3" class="traffic-empty">No talker data</td></tr>'

    return f"""
<div class="trf-tbl-wrap">
  <div class="trf-tbl-title">📊 Top Talkers</div>
  <table class="trf-tbl">
    <thead><tr><th>IP</th><th style="text-align:right">Packets</th><th style="text-align:right">Bytes</th></tr></thead>
    <tbody>{rows}</tbody>
  </table>
</div>"""


def _build_traffic_section(data: dict) -> str:
    return f"""
<div class="traffic-section section">
  <h2 class="section-title">
    <span class="icon">📡</span> Traffic Intelligence
    <span class="model-tag">TShark</span>
  </h2>
  {_build_status_bar(data)}
  {_build_stats_row(data)}
  {_build_protocol_table(data)}
  {_build_credential_table(data)}
  {_build_dns_table(data)}
  {_build_tls_table(data)}
  {_build_anomaly_table(data)}
  {_build_talkers_table(data)}
</div>"""


# ══════════════════════════════════════════════════════════════════════════════
# Public API
# ══════════════════════════════════════════════════════════════════════════════

def inject_traffic_section(
    html_path:   str,
    traffic_data: dict,
) -> bool:
    """
    Inject the Traffic Intelligence section into an existing ReconX HTML report.
    Returns True on success, False on any error.
    """
    path = Path(html_path)
    if not path.exists():
        return False
    try:
        html = path.read_text(encoding="utf-8")
        if "traffic-section" not in html:
            html = html.replace("</style>", f"{_TRAFFIC_CSS}\n</style>", 1)
        section = _build_traffic_section(traffic_data)
        html = html.replace("</body>", f"{section}\n</body>", 1) if "</body>" in html else html + section
        path.write_text(html, encoding="utf-8")
        return True
    except Exception:
        return False
