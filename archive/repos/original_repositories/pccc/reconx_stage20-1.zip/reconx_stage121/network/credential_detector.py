"""
ReconX — Credential Detector (Stage 18.2)

Scans network traffic for authentication artefacts:
  - HTTP Basic Auth credentials
  - Bearer / API tokens
  - JWTs (header.payload.signature)
  - Session cookies
  - FTP / SMTP cleartext credentials
  - Generic high-entropy tokens

SAFETY RULES (enforced unconditionally):
  1. Raw secret values are NEVER stored or logged.
  2. All values are masked: first 4 chars + "********".
  3. No complete credential is written to any file, log, or report.
  4. Detector is passive — it reads already-captured traffic only.

Output: list[CredentialHit] — each carries a masked value and a tag.
"""
from __future__ import annotations

import base64
import logging
import re
from typing import Optional

from .models import CredentialHit, CredentialTag, Severity

logger = logging.getLogger("reconx.network.credential_detector")

# ── Detection patterns ────────────────────────────────────────────────────────

# JWT: three base64url segments separated by dots
_RE_JWT = re.compile(
    r"eyJ[A-Za-z0-9_-]{10,}\.eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}"
)

# Bearer tokens
_RE_BEARER = re.compile(r"Bearer\s+([A-Za-z0-9\-_\.]+)", re.I)

# API key patterns (header-style)
_RE_API_KEY = re.compile(
    r"(?:x-api-key|api[_-]?key|apikey|api[_-]?token|x-auth-token)"
    r"[:\s]+([A-Za-z0-9\-_\.]{16,})",
    re.I,
)

# HTTP Basic Auth (base64-encoded "user:pass")
_RE_BASIC = re.compile(r"Basic\s+([A-Za-z0-9+/=]{8,})", re.I)

# Session / auth cookies
_RE_SESSION_COOKIE = re.compile(
    r"(?:session|sess|auth|token|sid|jwt|access[_-]?token|refresh[_-]?token)"
    r"=([A-Za-z0-9\-_\.%+/]{8,})",
    re.I,
)

# FTP cleartext password
_RE_FTP_PASS = re.compile(r"PASS\s+(.+)", re.I)

# SMTP AUTH credentials
_RE_SMTP_AUTH = re.compile(r"AUTH\s+(?:PLAIN|LOGIN)\s+([A-Za-z0-9+/=]+)", re.I)

# High-entropy generic token (>= 32 chars, hex or base64-like)
_RE_HIGH_ENTROPY = re.compile(r"[A-Za-z0-9+/=_\-]{32,}")

# Minimum entropy threshold (shannon entropy score)
_MIN_ENTROPY = 3.5


def _shannon_entropy(s: str) -> float:
    """Calculate Shannon entropy of a string."""
    import math
    if not s:
        return 0.0
    freq = {}
    for c in s:
        freq[c] = freq.get(c, 0) + 1
    n = len(s)
    return -sum((f / n) * math.log2(f / n) for f in freq.values())


class CredentialDetector:
    """
    Scans tshark field rows for credential / token patterns.

    Input: raw rows from tshark field extraction
    Output: list[CredentialHit] with masked values

    Usage:
        detector = CredentialDetector()
        hits = detector.scan_rows(tshark_rows)
        for hit in hits:
            print(hit.display())
    """

    def __init__(self, min_entropy: float = _MIN_ENTROPY):
        self._min_entropy = min_entropy

    # ══════════════════════════════════════════════════════════════════════════
    # Primary scan entry points
    # ══════════════════════════════════════════════════════════════════════════

    def scan_rows(self, rows: list[dict]) -> list[CredentialHit]:
        """
        Scan tshark field extraction rows for credentials.
        Each row is a dict of {field_name: value}.
        """
        hits: list[CredentialHit] = []
        seen: set[str] = set()   # dedup by masked prefix

        for row in rows:
            src  = row.get("ip.src", "")
            dst  = row.get("ip.dst", "")
            auth = row.get("http.authorization", "")
            cook = row.get("http.cookie", "")
            ftp  = row.get("ftp.request.arg", "")
            smtp = row.get("smtp.auth.password", "")

            for hit in self._scan_string(auth, src, dst, "HTTP"):
                k = f"{hit.tag.value}:{hit.masked_value}"
                if k not in seen:
                    seen.add(k)
                    hits.append(hit)

            for hit in self._scan_cookie(cook, src, dst):
                k = f"{hit.tag.value}:{hit.masked_value}"
                if k not in seen:
                    seen.add(k)
                    hits.append(hit)

            if ftp:
                hit = self._check_ftp(ftp, src, dst)
                if hit:
                    k = f"{hit.tag.value}:{hit.masked_value}"
                    if k not in seen:
                        seen.add(k)
                        hits.append(hit)

            if smtp:
                hit = self._check_smtp(smtp, src, dst)
                if hit:
                    k = f"{hit.tag.value}:{hit.masked_value}"
                    if k not in seen:
                        seen.add(k)
                        hits.append(hit)

        logger.info("[CredentialDetector] Found %d credential hits", len(hits))
        return hits

    def scan_text(
        self,
        text:    str,
        src_ip:  str = "",
        dst_ip:  str = "",
        proto:   str = "unknown",
    ) -> list[CredentialHit]:
        """
        Scan arbitrary text for credential patterns.
        Used by pyshark_engine for payload scanning.
        """
        return self._scan_string(text, src_ip, dst_ip, proto)

    # ══════════════════════════════════════════════════════════════════════════
    # Internal scanners
    # ══════════════════════════════════════════════════════════════════════════

    def _scan_string(
        self,
        text:   str,
        src_ip: str,
        dst_ip: str,
        proto:  str,
    ) -> list[CredentialHit]:
        """Run all pattern detectors on a text string."""
        hits: list[CredentialHit] = []
        if not text or len(text) < 8:
            return hits

        # JWTs (highest priority)
        for m in _RE_JWT.finditer(text):
            raw = m.group(0)
            hits.append(CredentialHit(
                tag=CredentialTag.JWT,
                masked_value=CredentialHit.mask(raw, keep=8),
                source_proto=proto,
                src_ip=src_ip,
                dst_ip=dst_ip,
                detail="JWT token in " + proto,
                severity=Severity.HIGH,
            ))

        # Bearer tokens (skip if already caught as JWT)
        jwt_ranges = {m.start() for m in _RE_JWT.finditer(text)}
        for m in _RE_BEARER.finditer(text):
            if m.start(1) in jwt_ranges:
                continue   # already captured as JWT
            raw = m.group(1)
            hits.append(CredentialHit(
                tag=CredentialTag.TOKEN,
                masked_value=CredentialHit.mask(raw, keep=6),
                source_proto=proto,
                src_ip=src_ip,
                dst_ip=dst_ip,
                detail=f"Bearer token ({len(raw)} chars)",
                severity=Severity.HIGH,
            ))

        # API keys
        for m in _RE_API_KEY.finditer(text):
            raw = m.group(1)
            if _shannon_entropy(raw) >= self._min_entropy:
                hits.append(CredentialHit(
                    tag=CredentialTag.API_KEY,
                    masked_value=CredentialHit.mask(raw, keep=6),
                    source_proto=proto,
                    src_ip=src_ip,
                    dst_ip=dst_ip,
                    detail="API key header",
                    severity=Severity.HIGH,
                ))

        # HTTP Basic Auth
        for m in _RE_BASIC.finditer(text):
            raw_b64 = m.group(1)
            decoded = self._decode_basic(raw_b64)
            hits.append(CredentialHit(
                tag=CredentialTag.BASIC_AUTH,
                masked_value=CredentialHit.mask(decoded or raw_b64, keep=4),
                source_proto=proto,
                src_ip=src_ip,
                dst_ip=dst_ip,
                detail="HTTP Basic Authentication",
                severity=Severity.CRITICAL,   # cleartext credentials
            ))

        return hits

    def _scan_cookie(
        self,
        cookie_str: str,
        src_ip:     str,
        dst_ip:     str,
    ) -> list[CredentialHit]:
        """Scan Cookie header for session tokens."""
        hits: list[CredentialHit] = []
        if not cookie_str:
            return hits

        for m in _RE_SESSION_COOKIE.finditer(cookie_str):
            raw = m.group(1)
            if len(raw) < 8:
                continue
            hits.append(CredentialHit(
                tag=CredentialTag.SESSION,
                masked_value=CredentialHit.mask(raw, keep=6),
                source_proto="HTTP",
                src_ip=src_ip,
                dst_ip=dst_ip,
                detail="Session cookie",
                severity=Severity.MEDIUM,
            ))

        return hits

    def _check_ftp(
        self,
        arg:    str,
        src_ip: str,
        dst_ip: str,
    ) -> Optional[CredentialHit]:
        """Detect FTP cleartext password."""
        m = _RE_FTP_PASS.match(arg.strip())
        if m:
            raw = m.group(1).strip()
            return CredentialHit(
                tag=CredentialTag.CREDENTIAL,
                masked_value=CredentialHit.mask(raw, keep=2),
                source_proto="FTP",
                src_ip=src_ip,
                dst_ip=dst_ip,
                detail="FTP cleartext password (PASS command)",
                severity=Severity.CRITICAL,
            )
        return None

    def _check_smtp(
        self,
        auth_str: str,
        src_ip:   str,
        dst_ip:   str,
    ) -> Optional[CredentialHit]:
        """Detect SMTP AUTH credential."""
        if auth_str and len(auth_str) >= 8:
            decoded = self._decode_basic(auth_str)
            return CredentialHit(
                tag=CredentialTag.CREDENTIAL,
                masked_value=CredentialHit.mask(decoded or auth_str, keep=3),
                source_proto="SMTP",
                src_ip=src_ip,
                dst_ip=dst_ip,
                detail="SMTP AUTH credential",
                severity=Severity.CRITICAL,
            )
        return None

    @staticmethod
    def _decode_basic(b64: str) -> Optional[str]:
        """Safely decode a base64 Basic Auth token."""
        try:
            decoded = base64.b64decode(b64 + "==").decode("utf-8", errors="replace")
            if ":" in decoded:
                user, _, _ = decoded.partition(":")
                return user  # return only the username for masking
            return decoded[:20]
        except Exception:
            return None
