"""
ReconX — DNS Intelligence Extractor (Stage 18.2)

Extracts DNS intelligence from tshark field rows:
  - All queries and responses
  - Resolved subdomains and IPs
  - DNS tunneling heuristics (long labels, high entropy, unusual frequency)
  - Unusual query frequencies (DGA detection signal)
  - Response anomalies (NXDOMAIN floods, ANY queries)

DNS Tunneling Detection:
  Tunneling tools (iodine, dns2tcp, dnscat2) encode data in DNS query labels.
  Signals we detect:
    1. Query name length > 50 chars
    2. Label entropy > 3.8 (random-looking subdomains)
    3. Same base domain queried > 100 times in session
    4. Long hex/base32 labels

Safety: passive analysis only. We read already-captured traffic.
"""
from __future__ import annotations

import logging
import math
import re
from collections import Counter
from typing import Optional

from .models import DNSEntry

logger = logging.getLogger("reconx.network.dns_extractor")

# ── Constants ─────────────────────────────────────────────────────────────────
_TUNNEL_LABEL_LEN    = 50    # chars — domain name suspicious length threshold
_TUNNEL_ENTROPY      = 3.8   # shannon entropy of query name
_TUNNEL_FREQ         = 100   # queries to same base domain → suspect
_HIGH_FREQ_THRESHOLD = 50    # queries to same domain in session

# Record type map (numeric → string)
_QTYPE_MAP = {
    "1": "A", "2": "NS", "5": "CNAME", "6": "SOA", "12": "PTR",
    "15": "MX", "16": "TXT", "28": "AAAA", "33": "SRV", "255": "ANY",
    "52": "TLSA", "257": "CAA",
}

# Common internal / benign domains to exclude from suspicious classification
_ALLOWLIST_SUFFIXES = (
    ".in-addr.arpa", ".local", ".localhost",
    "windows.com", "microsoft.com", "apple.com",
    "googleapis.com", "gstatic.com",
)


class DNSExtractor:
    """
    Parses tshark DNS field rows into DNSEntry objects.

    Usage:
        extractor = DNSExtractor()
        dns_rows, _ = tshark.extract_dns("capture.pcap")
        entries = extractor.parse_rows(dns_rows)
        for e in extractor.get_suspicious(entries):
            print(f"[TUNNEL?] {e.query_name} — {e.tunnel_reason}")
    """

    def parse_rows(self, rows: list[dict]) -> list[DNSEntry]:
        """
        Convert tshark DNS field rows to DNSEntry objects.
        Each row is a dict of {field_name: value} from tshark -T fields.
        """
        entries: list[DNSEntry] = []
        domain_counter: Counter = Counter()

        for row in rows:
            name    = (row.get("dns.qry.name") or row.get("dns.resp.name") or "").strip().lower()
            if not name:
                continue

            qtype_raw = row.get("dns.qry.type", "1")
            qtype     = _QTYPE_MAP.get(str(qtype_raw), str(qtype_raw))

            # Parse answers (may be comma-separated in field output)
            answers_raw = row.get("dns.a", "")
            answers     = [a.strip() for a in answers_raw.split(",") if a.strip()] if answers_raw else []

            entry = DNSEntry(
                query_name  = name,
                record_type = qtype,
                answers     = answers,
                src_ip      = row.get("ip.src", ""),
                dst_ip      = row.get("ip.dst", ""),
                is_response = bool(answers),
            )

            domain_counter[_base_domain(name)] += 1
            entries.append(entry)

        # Run tunneling detection after collecting all entries
        self._detect_tunneling(entries, domain_counter)
        return entries

    def get_suspicious(self, entries: list[DNSEntry]) -> list[DNSEntry]:
        """Return entries flagged as tunnel suspects or high frequency."""
        return [e for e in entries if e.is_tunnel_suspect or e.is_high_freq]

    def get_unique_domains(self, entries: list[DNSEntry]) -> list[str]:
        """Return unique base domains queried."""
        return list(dict.fromkeys(_base_domain(e.query_name) for e in entries if e.query_name))

    def get_resolved_ips(self, entries: list[DNSEntry]) -> list[str]:
        """Return all IP addresses from DNS A responses."""
        ips = []
        for e in entries:
            for ans in e.answers:
                if _is_ip(ans) and ans not in ips:
                    ips.append(ans)
        return ips

    def get_subdomains(self, entries: list[DNSEntry], base: str) -> list[str]:
        """Return all subdomains of a given base domain observed in queries."""
        base = base.lower().lstrip(".")
        subs = []
        for e in entries:
            name = e.query_name.rstrip(".")
            if name.endswith("." + base) and name != base:
                if name not in subs:
                    subs.append(name)
        return subs

    # ══════════════════════════════════════════════════════════════════════════
    # Internal tunneling detection
    # ══════════════════════════════════════════════════════════════════════════

    def _detect_tunneling(
        self,
        entries:        list[DNSEntry],
        domain_counter: Counter,
    ) -> None:
        """Annotate entries with tunnel suspect flags in-place."""
        for entry in entries:
            name = entry.query_name

            # Skip allowlisted suffixes
            if any(name.endswith(s) for s in _ALLOWLIST_SUFFIXES):
                continue

            reasons: list[str] = []

            # 1. Long query name
            if len(name) > _TUNNEL_LABEL_LEN:
                reasons.append(f"long name ({len(name)} chars > {_TUNNEL_LABEL_LEN})")

            # 2. High label entropy
            ent = _entropy(name.split(".")[0])   # entropy of first label
            if ent > _TUNNEL_ENTROPY:
                reasons.append(f"high entropy ({ent:.2f} > {_TUNNEL_ENTROPY})")

            # 3. High query frequency to same base domain
            base = _base_domain(name)
            freq = domain_counter.get(base, 0)
            if freq > _TUNNEL_FREQ:
                reasons.append(f"high freq ({freq} queries to {base})")
                entry.is_high_freq = True

            # 4. Hex/base32-looking label (>= 20 hex chars)
            first_label = name.split(".")[0]
            if len(first_label) >= 20 and _is_hex_like(first_label):
                reasons.append("hex-encoded label")

            if reasons:
                entry.is_tunnel_suspect = True
                entry.tunnel_reason     = "; ".join(reasons)


# ── Utilities ─────────────────────────────────────────────────────────────────

def _base_domain(name: str) -> str:
    """Extract base domain (last two labels)."""
    parts = name.rstrip(".").split(".")
    return ".".join(parts[-2:]) if len(parts) >= 2 else name


def _entropy(s: str) -> float:
    """Shannon entropy of a string."""
    if not s:
        return 0.0
    freq = Counter(s)
    n    = len(s)
    return -sum((c / n) * math.log2(c / n) for c in freq.values())


def _is_ip(s: str) -> bool:
    """Quick check if string looks like an IPv4 address."""
    parts = s.split(".")
    if len(parts) != 4:
        return False
    return all(p.isdigit() and 0 <= int(p) <= 255 for p in parts)


def _is_hex_like(s: str) -> bool:
    """Return True if string is >= 90% hexadecimal characters."""
    hex_chars = sum(1 for c in s.lower() if c in "0123456789abcdef")
    return hex_chars / len(s) >= 0.90 if s else False
