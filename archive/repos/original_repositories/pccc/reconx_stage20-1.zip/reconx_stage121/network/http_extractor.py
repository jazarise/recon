"""
ReconX — HTTP Intelligence Extractor (Stage 18.2)

Converts tshark HTTP field rows into structured HTTPRecord objects.

Extracts and classifies:
  - Request method, host, path, user-agent
  - Response status codes
  - Auth routes, admin panels, API endpoints, upload forms
  - Redirect chains (3xx tracking)
  - Interesting headers (server, X-Powered-By, CORS, CSP)
"""
from __future__ import annotations

import logging
import re
from collections import defaultdict
from typing import Optional

from .models import HTTPRecord

logger = logging.getLogger("reconx.network.http_extractor")

_RE_REDIRECT = re.compile(r"^3\d{2}$")

# Headers worth flagging in reports
_INTERESTING_HEADERS = {
    "server", "x-powered-by", "x-aspnet-version",
    "access-control-allow-origin", "content-security-policy",
    "x-frame-options", "strict-transport-security",
    "x-generator", "x-drupal-cache", "x-wordpress",
}


class HTTPExtractor:
    """
    Parses tshark HTTP field rows into HTTPRecord objects.

    Usage:
        extractor = HTTPExtractor()
        rows, _ = tshark.extract_http("capture.pcap")
        records = extractor.parse_rows(rows)
        admin = [r for r in records if r.is_admin]
    """

    def parse_rows(self, rows: list[dict]) -> list[HTTPRecord]:
        """Convert tshark HTTP field rows to HTTPRecord list."""
        records: list[HTTPRecord] = []
        seen: set[str] = set()

        for row in rows:
            method = (row.get("http.request.method") or "GET").upper()
            host   = (row.get("http.host") or "").strip()
            path   = (row.get("http.request.uri") or "/").strip()
            status = _safe_int(row.get("http.response.code") or "0")
            ua     = (row.get("http.user_agent") or "").strip()
            src    = row.get("ip.src", "")
            dst    = row.get("ip.dst", "")

            # Deduplicate by method+host+path
            key = f"{method}:{host}{path}"
            if key in seen:
                continue
            seen.add(key)

            record = HTTPRecord(
                src_ip=src,
                dst_ip=dst,
                method=method,
                host=host,
                path=path,
                status_code=status,
                user_agent=ua,
            )
            records.append(record)

        logger.debug("[HTTPExtractor] Parsed %d unique HTTP records", len(records))
        return records

    def get_api_endpoints(self, records: list[HTTPRecord]) -> list[str]:
        return list(dict.fromkeys(r.url for r in records if r.is_api))

    def get_auth_routes(self, records: list[HTTPRecord]) -> list[str]:
        return list(dict.fromkeys(r.url for r in records if r.is_auth))

    def get_admin_panels(self, records: list[HTTPRecord]) -> list[str]:
        return list(dict.fromkeys(r.url for r in records if r.is_admin))

    def get_upload_endpoints(self, records: list[HTTPRecord]) -> list[str]:
        return list(dict.fromkeys(r.url for r in records if r.is_upload))

    def get_unique_user_agents(self, records: list[HTTPRecord]) -> list[str]:
        return list(dict.fromkeys(r.user_agent for r in records if r.user_agent))

    def get_redirect_chains(self, records: list[HTTPRecord]) -> list[dict]:
        """Return records that are HTTP redirects (3xx)."""
        return [
            {"url": r.url, "status": r.status_code}
            for r in records if 300 <= r.status_code < 400
        ]

    def get_top_hosts(self, records: list[HTTPRecord], top: int = 10) -> list[dict]:
        """Return top hosts by request count."""
        counts: dict[str, int] = defaultdict(int)
        for r in records:
            if r.host:
                counts[r.host] += 1
        return [
            {"host": h, "requests": c}
            for h, c in sorted(counts.items(), key=lambda x: x[1], reverse=True)[:top]
        ]


def _safe_int(s: str) -> int:
    try:
        return int(str(s).strip())
    except (ValueError, TypeError):
        return 0
