"""
ReconX — TShark Engine (Stage 18.2)

Wraps the tshark CLI for PCAP file analysis and live capture.
TShark is the CLI counterpart of Wireshark — no GUI, full protocol dissection.

Responsibilities:
  1. PCAP/PCAPNG file analysis via tshark JSON output (-T json)
  2. Field extraction via tshark -T fields
  3. Protocol statistics via tshark -qz io,phs
  4. Conversation tables via tshark -qz conv,tcp
  5. Binary availability check with helpful install guidance
  6. Output normalisation into TrafficSummary-compatible dicts

All subprocess calls go through run_subprocess() — no shell=True,
hard timeouts, structured errors.

TShark output format used:
  -T json       → full packet decode (used for HTTP/DNS/TLS extraction)
  -T fields -e  → targeted field extraction (faster for large PCAPs)
"""
from __future__ import annotations

import json
import logging
import os
import shutil
from typing import Optional

try:
    from ..utils.subprocess_runner import SubprocessResult, run_subprocess
except ImportError:
    from utils.subprocess_runner import SubprocessResult, run_subprocess

logger = logging.getLogger("reconx.network.tshark")

# Fields extracted in targeted mode (faster than full JSON decode)
_DNS_FIELDS   = ["dns.qry.name", "dns.resp.name", "dns.a", "dns.qry.type",
                  "ip.src", "ip.dst", "frame.time_epoch"]
_HTTP_FIELDS  = ["http.host", "http.request.uri", "http.request.method",
                  "http.response.code", "http.user_agent",
                  "ip.src", "ip.dst", "frame.time_epoch"]
_TLS_FIELDS   = ["tls.handshake.extensions_server_name",
                  "tls.handshake.ja3",
                  "tls.handshake.ja3s",
                  "tls.record.version",
                  "x509sat.uTF8String",
                  "ip.src", "ip.dst", "frame.time_epoch"]
_CRED_FIELDS  = ["http.authorization", "http.cookie",
                  "ftp.request.arg", "smtp.auth.password",
                  "ip.src", "ip.dst", "frame.time_epoch"]


class TSharkEngine:
    """
    Wraps tshark for PCAP analysis and live capture.

    Usage:
        ts = TSharkEngine()
        if not ts.available():
            ... handle gracefully ...

        # Full JSON decode
        packets = ts.decode_pcap("capture.pcap")

        # Fast field extraction
        dns = ts.extract_fields("capture.pcap", _DNS_FIELDS)

        # Protocol statistics
        stats = ts.protocol_stats("capture.pcap")
    """

    def __init__(
        self,
        binary:    str  = "tshark",
        timeout_s: int  = 120,
        max_packets: int = 50_000,   # safety cap for large PCAPs
    ):
        self._binary    = shutil.which(binary) or binary
        self.timeout_s  = timeout_s
        self.max_packets = max_packets

    # ══════════════════════════════════════════════════════════════════════════
    # Availability
    # ══════════════════════════════════════════════════════════════════════════

    def available(self) -> bool:
        """Check that tshark is on PATH and executable."""
        return bool(shutil.which(self._binary))

    def version(self) -> str:
        """Return tshark version string, or '' on failure."""
        r = run_subprocess([self._binary, "--version"], timeout_s=10)
        return r.stdout.splitlines()[0] if r.ok and r.stdout else ""

    def install_hint(self) -> str:
        return (
            "TShark not found. Install:\n"
            "  Linux:   sudo apt install tshark\n"
            "  macOS:   brew install wireshark\n"
            "  Windows: Install Wireshark (includes TShark) from https://www.wireshark.org\n"
            "  Linux permissions: sudo setcap cap_net_raw,cap_net_admin=eip /usr/bin/dumpcap"
        )

    # ══════════════════════════════════════════════════════════════════════════
    # PCAP file analysis
    # ══════════════════════════════════════════════════════════════════════════

    def decode_pcap(
        self,
        pcap_path: str,
        display_filter: str = "",
        max_packets: Optional[int] = None,
    ) -> tuple[list[dict], str]:
        """
        Decode a PCAP/PCAPNG file to a list of packet dicts via tshark -T json.

        Returns (packets_list, error_string).
        packets_list is empty on error or empty file.

        Args:
            pcap_path:      Path to the .pcap or .pcapng file.
            display_filter: Optional Wireshark display filter (e.g. "http or dns").
            max_packets:    Cap on packets parsed (defaults to self.max_packets).
        """
        if not os.path.exists(pcap_path):
            return [], f"File not found: {pcap_path}"

        cap = max_packets or self.max_packets
        cmd = [
            self._binary,
            "-r", pcap_path,
            "-T", "json",
            "-n",           # no name resolution (faster)
            "-c", str(cap),
        ]
        if display_filter:
            cmd += ["-Y", display_filter]

        logger.debug("[TShark] decode_pcap: %s (filter=%r)", pcap_path, display_filter)
        result = run_subprocess(cmd, timeout_s=self.timeout_s)

        if not result.ok or not result.stdout.strip():
            err = result.stderr.strip() or "tshark produced no output"
            logger.warning("[TShark] decode_pcap failed: %s", err)
            return [], err

        try:
            packets = json.loads(result.stdout)
            return packets if isinstance(packets, list) else [], ""
        except json.JSONDecodeError as exc:
            logger.warning("[TShark] JSON parse error: %s", exc)
            return [], f"JSON parse error: {exc}"

    def extract_fields(
        self,
        pcap_path:      str,
        fields:         list[str],
        display_filter: str = "",
        max_packets:    Optional[int] = None,
    ) -> tuple[list[dict], str]:
        """
        Fast targeted field extraction using tshark -T fields.

        Returns (rows, error) where each row is {field_name: value}.
        Empty strings are excluded from each row dict.
        """
        if not os.path.exists(pcap_path):
            return [], f"File not found: {pcap_path}"

        cap = max_packets or self.max_packets
        cmd = [
            self._binary,
            "-r", pcap_path,
            "-T", "fields",
            "-E", "separator=|",
            "-E", "quote=d",
            "-E", "occurrence=f",    # first occurrence only
            "-n",
            "-c", str(cap),
        ]
        for f in fields:
            cmd += ["-e", f]
        if display_filter:
            cmd += ["-Y", display_filter]

        logger.debug("[TShark] extract_fields: %s fields=%s", pcap_path, fields[:3])
        result = run_subprocess(cmd, timeout_s=self.timeout_s)

        if not result.ok:
            return [], result.stderr.strip() or "tshark field extraction failed"

        rows = []
        for line in result.stdout.splitlines():
            if not line.strip():
                continue
            parts = line.split("|")
            # Strip surrounding quotes added by -E quote=d
            parts = [p.strip('"') for p in parts]
            row = {f: v for f, v in zip(fields, parts) if v}
            if row:
                rows.append(row)

        return rows, ""

    # ══════════════════════════════════════════════════════════════════════════
    # Statistics
    # ══════════════════════════════════════════════════════════════════════════

    def protocol_stats(self, pcap_path: str) -> tuple[dict, str]:
        """
        Return per-protocol packet and byte counts via tshark -qz io,phs.
        Returns ({protocol: {packets, bytes}}, error).
        """
        if not os.path.exists(pcap_path):
            return {}, f"File not found: {pcap_path}"

        cmd = [self._binary, "-r", pcap_path, "-qz", "io,phs", "-n"]
        result = run_subprocess(cmd, timeout_s=self.timeout_s)

        if not result.ok:
            return {}, result.stderr.strip()

        stats: dict[str, dict] = {}
        # Parse lines like: "  tcp                             1234  5678901"
        import re
        pattern = re.compile(r"^\s+(\S+)\s+(\d+)\s+(\d+)\s*$")
        for line in result.stdout.splitlines():
            m = pattern.match(line)
            if m:
                proto, pkts, bts = m.group(1), int(m.group(2)), int(m.group(3))
                stats[proto.lower()] = {"packets": pkts, "bytes": bts}

        return stats, ""

    def conversation_table(
        self,
        pcap_path: str,
        layer: str = "tcp",
    ) -> tuple[list[dict], str]:
        """
        Extract conversation table (top talkers) via tshark -qz conv,<layer>.
        layer: "tcp" | "udp" | "ip" | "eth"
        """
        if not os.path.exists(pcap_path):
            return [], f"File not found: {pcap_path}"

        cmd = [self._binary, "-r", pcap_path, "-qz", f"conv,{layer}", "-n"]
        result = run_subprocess(cmd, timeout_s=self.timeout_s)

        if not result.ok:
            return [], result.stderr.strip()

        convs = []
        import re
        # Parse tab/space-separated conversation lines
        for line in result.stdout.splitlines():
            # Skip header/separator lines
            if not re.search(r"\d+\.\d+\.\d+\.\d+", line):
                continue
            parts = line.split()
            if len(parts) >= 8:
                convs.append({
                    "src":       parts[0],
                    "dst":       parts[2],
                    "frames_a":  _safe_int(parts[3]),
                    "bytes_a":   _safe_int(parts[4]),
                    "frames_b":  _safe_int(parts[5]),
                    "bytes_b":   _safe_int(parts[6]),
                    "total_frames": _safe_int(parts[7]) if len(parts) > 7 else 0,
                })

        return convs, ""

    # ══════════════════════════════════════════════════════════════════════════
    # Targeted extractions (used by protocol-specific extractors)
    # ══════════════════════════════════════════════════════════════════════════

    def extract_dns(self, pcap_path: str) -> tuple[list[dict], str]:
        return self.extract_fields(
            pcap_path, _DNS_FIELDS, display_filter="dns"
        )

    def extract_http(self, pcap_path: str) -> tuple[list[dict], str]:
        return self.extract_fields(
            pcap_path, _HTTP_FIELDS, display_filter="http"
        )

    def extract_tls_fields(self, pcap_path: str) -> tuple[list[dict], str]:
        return self.extract_fields(
            pcap_path, _TLS_FIELDS, display_filter="tls.handshake.type == 1"
        )

    def extract_credentials(self, pcap_path: str) -> tuple[list[dict], str]:
        return self.extract_fields(
            pcap_path, _CRED_FIELDS,
            display_filter="http.authorization or http.cookie or ftp.request.arg",
        )

    # ══════════════════════════════════════════════════════════════════════════
    # Live capture (short burst for stats)
    # ══════════════════════════════════════════════════════════════════════════

    def list_interfaces(self) -> tuple[list[dict], str]:
        """List available capture interfaces via tshark -D."""
        cmd = [self._binary, "-D"]
        result = run_subprocess(cmd, timeout_s=10)
        if not result.ok:
            return [], result.stderr.strip() or "Could not list interfaces"

        ifaces = []
        import re
        for line in result.stdout.splitlines():
            m = re.match(r"^(\d+)\.\s+(.+)$", line.strip())
            if m:
                ifaces.append({"index": int(m.group(1)), "name": m.group(2).strip()})
        return ifaces, ""

    def capture_burst(
        self,
        interface: str,
        duration_s: int = 10,
        output_file: str = "",
        max_packets: int = 5000,
        display_filter: str = "",
    ) -> tuple[str, str]:
        """
        Capture a short burst of live traffic to a temp PCAP file.
        Returns (output_path, error). Caller parses the PCAP.
        """
        import tempfile
        outfile = output_file or tempfile.mktemp(suffix=".pcap", prefix="reconx_")

        cmd = [
            self._binary,
            "-i", interface,
            "-a", f"duration:{duration_s}",
            "-c", str(max_packets),
            "-w", outfile,
            "-n",
        ]
        if display_filter:
            cmd += ["-f", display_filter]   # BPF filter for live capture

        logger.info("[TShark] Live capture: iface=%s dur=%ds out=%s", interface, duration_s, outfile)
        result = run_subprocess(cmd, timeout_s=duration_s + 15)

        if os.path.exists(outfile):
            return outfile, ""
        return "", result.stderr.strip() or "Capture file not created"


def _safe_int(s: str) -> int:
    try:
        return int(s.replace(",", ""))
    except (ValueError, AttributeError):
        return 0
