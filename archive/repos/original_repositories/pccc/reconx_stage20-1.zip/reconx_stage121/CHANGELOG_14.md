# ReconX — Stage 14 Changelog

## Overview

Stage 14 transforms ReconX from an orchestration engine into a full
**Cyber Reconnaissance Operating System** with an interactive terminal UI,
an integrated learning platform, guided step-by-step recon, and a
multi-theme visual environment. Every component wires cleanly into the
Stage 13 orchestration layer.

---

## New Files (14 total)

### `tui/` — Terminal UI Layer

| File | Class | Description |
|---|---|---|
| `app.py` | `main()`, `build_app()` | Entry point. Bootstraps registry + engine + navigator. CLI flags: `--theme`, `--verbose`, `--health`, `--install-guide`, `--version`, `target`. |
| `dashboard.py` | `Dashboard` | Home screen. 8-item main menu + quick-action bar + system status panel (tool counts, recent scans). Rich-rendered, no Textual required. |
| `tool_browser.py` | `ToolBrowser` | Category-driven tool explorer. 17 categories. Search mode. Per-tool detail view with status, stage, inputs, install cmd. `[R]un / [A]dd to Workflow / [L]earn` action buttons. |
| `guided_view.py` | `GuidedReconView`, `GuidedSession` | 7-step guided recon flow: target → mode → preview → customise → execute with per-step explanations → save workflow. 25+ step explanations built-in. |
| `execution_view.py` | `ExecutionView` | Live execution screen. 7 quick-action presets (QS/DS/WS/PS/IS/CS/CW). `prompt_and_run()` for interactive target entry. Post-run summary with report path. |
| `navigator.py` | `Navigator`, `ReconXTheme` | Top-level screen router. Lazy-loads all views. 5 colour themes: `dark`, `neon`, `green`, `light`, `compact`. Settings view for theme switching. |
| `widgets/quick_action_bar.py` | `QuickActionBar`, `StatusBar` | Reusable Rich panels. Full and compact render modes. 7 action definitions with time estimates. `StatusBar` shows available/missing counts. |

### `learning/` — Learning Platform

| File | Class | Description |
|---|---|---|
| `tool_lessons.py` | `LearningMode`, `ToolLesson`, `ToolRelationship` | Full learning platform. 3 deep lessons (Subfinder, HTTPX, Feroxbuster). Pulls from Stage 12.1 knowledge catalog. 18 tool relationships with chaining rationale. 7 named chains. |

### `output/` — Report Extension

| File | Function | Description |
|---|---|---|
| `report_14.py` | `generate_stage14_sections()`, `inject_into_report()` | Adds 4 new report sections: workflow chain diagram, tool execution table, timeline bar chart, learning notes. CSS injected inline. Works on existing report HTML files. |

### `tests/test_stage14_tui.py` — 9 test classes, 45+ tests

---

## Architecture

### Launch Flow

```
reconx  (CLI entry)
    │
    ▼
main() / build_app()
    ├── ToolRegistry.build()     → auto-discover 40+ tools
    ├── ReconXEngine()           → Stage 13 orchestrator
    └── Navigator(theme="dark")
            │
            ▼
        dashboard.run()          → home screen, user picks [1]–[8] / QS–CS
            │
     ┌──────┴────────────────────────────────────────────┐
     │  [1] Execute    [2] Learn    [3] Guided            │
     │  [4] Workflow   [5] Browse   [6] Reports           │
     │  [7] Telemetry  [8] Settings [QS–CW] Quick Actions │
     └──────────────────────────────────────────────────┘
            │
            ▼ (routing via Navigator._route())
        View.run()   →  user interaction  →  back to Dashboard
```

### Component Wiring

```
Navigator
  ├── Dashboard           (renders + reads choice)
  ├── ToolBrowser         (registry.by_category, registry.search)
  │     └── on_run   →  ExecutionView.run_target()
  │     └── on_learn →  LearningMode._show_lesson()
  ├── GuidedReconView     (TargetClassifier + RecommendationEngine)
  │     └── execute →  meta.instance.safe_run() per step
  ├── ExecutionView       (ReconXEngine.run() with live_tui=True)
  ├── LearningMode        (LESSONS dict + Stage 12.1 catalog)
  ├── Telemetry view      (ToolHealthMonitor.dashboard_text())
  └── Settings view       (theme switching, Console rebuild)
```

### Theme System

Five themes, each a `ReconXTheme` dataclass converted to a `rich.Theme`:

| Theme | Accent | Border | Use |
|---|---|---|---|
| `dark` | cyan | cyan | Default — dark terminal |
| `neon` | bright_magenta | bright_magenta | High-contrast neon |
| `green` | green | green | Matrix-style monochrome |
| `light` | blue | blue | Light terminal backgrounds |
| `compact` | white | white | Minimal colour for screen recording |

Switching theme at runtime rebuilds the `Console` and resets all lazy view instances so they inherit the new theme immediately.

### Learning Platform

`LearningMode` has two entry points:

1. **`browse_lessons()`** — catalog of tool lessons with a sub-menu per lesson:
   - Overview (problem solved)
   - How It Works
   - Use Cases
   - Examples + sample output
   - Common Mistakes
   - Comparisons (vs similar tools)
   - Workflow Chain (ASCII chain visualization)

2. **`show_relationships()`** — 7 named chains with full rationale:
   - Infrastructure: WHOIS → ASN → CIDR → Masscan → Nmap
   - Subdomain: Harvest → Permute → Validate → Probe
   - Web Recon: HTTP → Crawl → Parameters
   - Historical: GAU → Waymore → Content Discovery
   - Certificate: CT Logs → TLS → Vuln Audit
   - Secrets: GitHub → TruffleHog → Gitleaks
   - Comparisons: Gobuster vs Feroxbuster, Masscan vs Nmap, etc.

### Guided Recon 7-Step Flow

```
Step 1: Enter target (with type examples)
    │  → TargetClassifier.classify()
Step 2: Select mode (Fast/Balanced/Deep/Passive/AI/Custom)
Step 3: View recommended workflow
    │  → RecommendationEngine.recommend()
    │  → Shows tool list with WHY each tool runs
Step 4: Confirm or customise (skip individual tools by number)
Step 5: Execute with live progress + per-step explanations
    │  → meta.instance.safe_run() per tool
    │  → STEP_EXPLANATIONS dict explains each tool as it runs
Step 6: Summary (completed / skipped counts + duration)
Step 7: Save workflow to workflows/guided_*.json for replay
```

### Report Extension (Part 10)

`inject_into_report(html_path, tool_list, tasks, ctx)` adds 4 sections to existing report HTML:

1. **Workflow Chain Diagram** — HTML flex column with colour-coded status per step, hover tooltips with tool purpose
2. **Tool Execution Table** — status pill + duration + finding count + notes per tool
3. **Timeline Bar Chart** — proportional horizontal bars per tool duration, colour-coded by status
4. **Learning Notes** — per-tool educational note explaining what the tool found and why it matters

CSS is injected into `<head>` on first call; idempotent (won't duplicate).

---

## Quick Actions Reference

| Key | Name | Tools | Est. Time |
|---|---|---|---|
| QS | Quick Scan | WHOIS → DNS → Subs → HTTPX → Report | ~15 min |
| DS | Deep Scan | Full pipeline (all modes) | ~2 hrs |
| WS | Web Scan | HTTP → Crawl → Content → Visual | ~45 min |
| PS | Passive Only | OSINT + archives, zero active traffic | ~20 min |
| IS | Internal Scan | ARP → fping → Nmap → Services | ~30 min |
| CS | Cloud Scan | ASN → CIDR → S3 → Certs | ~25 min |
| CW | Custom | User-defined tool chain | varies |

---

## Test Coverage

| Class | Tests | Covers |
|---|---|---|
| `TestDashboard` | 6 | Menu items, unique keys, quit option |
| `TestToolBrowser` | 6 | 17 categories, search, count helpers |
| `TestLearningMode` | 8 | Lessons, relationships, chains, all_lessons() |
| `TestGuidedView` | 6 | 6 modes, session dataclass, classify |
| `TestExecutionView` | 5 | Quick actions, mode field, instantiation |
| `TestNavigator` | 8 | 5 themes, status icons, ASCII banners, routing |
| `TestQuickActionBar` | 5 | 7 defs, key/label/tools fields, compact+full |
| `TestReport14` | 6 | HTML generation, CSS content, file injection |
| `TestAppEntry` | 3 | build_app(), --version flag, action keys |

---

## CLI Usage After Stage 14

```bash
# Launch interactive TUI
reconx

# Launch with specific theme
reconx --theme neon

# Non-interactive: scan a target immediately
reconx example.com --mode balanced

# Quick passive scan
reconx example.com --mode passive

# Health check (no TUI)
reconx --health

# Show install commands for missing tools
reconx --install-guide

# Debug mode
reconx --verbose
```

---

## Dependency Summary

Stage 14 adds zero new Python dependencies. All TUI components use:
- `rich` (already required from Stage 12.1)
- `pathlib`, `json`, `time`, `threading` (stdlib)

Optional enhancements (not required):
- `textual` — for future Textual-based widget migration
- `prompt_toolkit` — for advanced readline-style input
