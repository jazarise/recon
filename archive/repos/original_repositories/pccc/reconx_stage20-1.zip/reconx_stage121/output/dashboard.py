"""
ReconX — Terminal UX Dashboard (Stage 12.1).

Provides a Rich-powered live TUI showing:
  • Tool status indicators  [RUNNING] [SUCCESS] [FAILED] [MISSING] [SKIPPED]
  • Progress bars per workflow step
  • Live finding counts
  • Colour-coded severity for findings

Used by both Guided Recon Mode and standalone tool runs.
"""
from __future__ import annotations
import threading
import time
from typing import Optional

from rich.console import Console, Group
from rich.live import Live
from rich.panel import Panel
from rich.progress import (
    BarColumn,
    MofNCompleteColumn,
    Progress,
    SpinnerColumn,
    TaskProgressColumn,
    TextColumn,
    TimeElapsedColumn,
)
from rich.table import Table
from rich.text import Text
from rich import box


# ─────────────────────────────────────────────────────────────────────────────
# Colour palette
# ─────────────────────────────────────────────────────────────────────────────

STATUS_STYLES: dict[str, str] = {
    "RUNNING":  "bold cyan",
    "SUCCESS":  "bold green",
    "FAILED":   "bold red",
    "MISSING":  "bold yellow",
    "SKIPPED":  "dim white",
    "PENDING":  "dim",
}

SEVERITY_STYLES: dict[str, str] = {
    "CRITICAL": "bold red",
    "HIGH":     "bold orange3",
    "MEDIUM":   "bold yellow",
    "LOW":      "bold green",
    "INFO":     "dim white",
}


def status_tag(status: str) -> Text:
    """Return a coloured [STATUS] tag as a Rich Text object."""
    label  = f"[{status.upper():^9}]"
    style  = STATUS_STYLES.get(status.upper(), "white")
    return Text(label, style=style)


def severity_badge(severity: str) -> Text:
    style = SEVERITY_STYLES.get(severity.upper(), "white")
    return Text(f" {severity.upper()} ", style=f"on {style.split()[-1]} bold white"
                if "bold" in style else style)


# ─────────────────────────────────────────────────────────────────────────────
# ToolStatusRow — one row per tool
# ─────────────────────────────────────────────────────────────────────────────

class ToolStatusRow:
    def __init__(self, tool_name: str, category: str = ""):
        self.tool_name   = tool_name
        self.category    = category
        self.status      = "PENDING"
        self.message     = ""
        self.finding_cnt = 0
        self.duration_s  = 0.0

    def set_running(self, msg: str = "") -> None:
        self.status  = "RUNNING"
        self.message = msg

    def set_success(self, findings: int = 0, duration: float = 0.0) -> None:
        self.status      = "SUCCESS"
        self.finding_cnt = findings
        self.duration_s  = duration
        self.message     = f"{findings} finding{'s' if findings != 1 else ''}"

    def set_failed(self, error: str = "") -> None:
        self.status  = "FAILED"
        self.message = error[:60]

    def set_missing(self) -> None:
        self.status  = "MISSING"
        self.message = "tool not installed"

    def set_skipped(self, reason: str = "") -> None:
        self.status  = "SKIPPED"
        self.message = reason or "manually skipped"


# ─────────────────────────────────────────────────────────────────────────────
# ReconDashboard — main live display
# ─────────────────────────────────────────────────────────────────────────────

class ReconDashboard:
    """
    Live Rich dashboard for a ReconX run.

    Usage:
        dash = ReconDashboard(target="example.com", total_steps=16)
        with dash:
            dash.set_tool_status("theHarvester", "RUNNING")
            # ... run tool ...
            dash.set_tool_status("theHarvester", "SUCCESS", findings=42)
    """

    BANNER = (
        "[bold cyan]██████╗[/]  [bold cyan]███████╗[/]  [bold cyan]██████╗[/]  "
        "[bold cyan]███╗   ██╗[/]  [bold cyan]██╗  ██╗[/]\n"
        "[cyan]██╔══██╗ ██╔════╝ ██╔════╝ ████╗  ██║ ╚██╗██╔╝[/]\n"
        "[cyan]██████╔╝ █████╗   ██║      ██╔██╗ ██║  ╚███╔╝[/]\n"
        "[dim cyan]██╔══██╗ ██╔══╝   ██║      ██║╚██╗██║  ██╔██╗[/]\n"
        "[dim cyan]██║  ██║ ███████╗ ╚██████╗ ██║ ╚████║ ██╔╝ ██╗[/]\n"
        "[dim cyan]╚═╝  ╚═╝ ╚══════╝  ╚═════╝ ╚═╝  ╚═══╝ ╚═╝  ╚═╝[/]"
    )

    def __init__(
        self,
        target:       str,
        total_steps:  int  = 16,
        console:      Optional[Console] = None,
        refresh_rate: float = 0.25,
    ):
        self.target       = target
        self.total_steps  = total_steps
        self.console      = console or Console()
        self.refresh_rate = refresh_rate

        self._rows:      dict[str, ToolStatusRow] = {}
        self._findings:  list[dict]               = []
        self._lock       = threading.Lock()
        self._completed  = 0

        # Progress bar
        self._progress = Progress(
            SpinnerColumn(style="cyan"),
            TextColumn("[cyan]{task.description}"),
            BarColumn(bar_width=40, style="cyan", complete_style="bold green"),
            MofNCompleteColumn(),
            TimeElapsedColumn(),
            console=self.console,
        )
        self._task = self._progress.add_task(
            f"Scanning [bold]{target}[/bold]", total=total_steps
        )
        self._live: Optional[Live] = None

    # ── context manager ───────────────────────────────────────────────────────

    def __enter__(self) -> "ReconDashboard":
        self._live = Live(
            self._render(),
            console=self.console,
            refresh_per_second=int(1 / self.refresh_rate),
            transient=False,
        )
        self._live.__enter__()
        return self

    def __exit__(self, *args) -> None:
        if self._live:
            self._live.update(self._render())
            self._live.__exit__(*args)

    # ── public API ────────────────────────────────────────────────────────────

    def register_tool(self, tool_name: str, category: str = "") -> None:
        with self._lock:
            if tool_name not in self._rows:
                self._rows[tool_name] = ToolStatusRow(tool_name, category)
        self._refresh()

    def set_tool_status(
        self,
        tool_name: str,
        status:    str,
        *,
        findings:  int   = 0,
        duration:  float = 0.0,
        message:   str   = "",
        category:  str   = "",
    ) -> None:
        with self._lock:
            if tool_name not in self._rows:
                self._rows[tool_name] = ToolStatusRow(tool_name, category)
            row = self._rows[tool_name]
            s = status.upper()
            if s == "RUNNING":
                row.set_running(message)
            elif s == "SUCCESS":
                row.set_success(findings, duration)
                self._completed += 1
                self._progress.advance(self._task)
            elif s == "FAILED":
                row.set_failed(message)
                self._completed += 1
                self._progress.advance(self._task)
            elif s == "MISSING":
                row.set_missing()
                self._completed += 1
                self._progress.advance(self._task)
            elif s == "SKIPPED":
                row.set_skipped(message)
                self._completed += 1
                self._progress.advance(self._task)
        self._refresh()

    def add_finding(self, finding: dict) -> None:
        with self._lock:
            self._findings.append(finding)
        self._refresh()

    def print_summary(self) -> None:
        """Print final summary table after Live context exits."""
        table = Table(title="ReconX Summary", box=box.ROUNDED, border_style="cyan")
        table.add_column("Tool",     style="bold white", width=22)
        table.add_column("Status",   width=12)
        table.add_column("Findings", justify="right", width=10)
        table.add_column("Duration", justify="right", width=10)
        table.add_column("Notes",    style="dim")

        with self._lock:
            for row in self._rows.values():
                table.add_row(
                    row.tool_name,
                    status_tag(row.status),
                    str(row.finding_cnt) if row.finding_cnt else "—",
                    f"{row.duration_s:.1f}s" if row.duration_s else "—",
                    row.message,
                )
        self.console.print(table)

        # Finding counts by type
        if self._findings:
            by_type: dict[str, int] = {}
            for f in self._findings:
                ft = f.get("finding_type", "unknown")
                by_type[ft] = by_type.get(ft, 0) + 1

            count_table = Table(title="Findings by Type", box=box.SIMPLE, border_style="dim cyan")
            count_table.add_column("Type",  style="cyan")
            count_table.add_column("Count", justify="right", style="bold white")
            for ftype, cnt in sorted(by_type.items(), key=lambda x: -x[1]):
                count_table.add_row(ftype, str(cnt))
            self.console.print(count_table)

    # ── rendering ─────────────────────────────────────────────────────────────

    def _render(self):
        """Build the Rich renderable group for the live display."""
        components = []

        # Status table
        table = Table(box=box.SIMPLE_HEAVY, border_style="dim cyan", show_header=True,
                      header_style="bold dim")
        table.add_column("Status",   width=11)
        table.add_column("Tool",     style="bold white", width=22)
        table.add_column("Category", style="dim cyan",   width=18)
        table.add_column("Findings", justify="right",    width=10)
        table.add_column("Info",     style="dim")

        with self._lock:
            for row in self._rows.values():
                table.add_row(
                    status_tag(row.status),
                    row.tool_name,
                    row.category,
                    str(row.finding_cnt) if row.finding_cnt else "",
                    row.message,
                )

        components.append(Panel(
            Group(table, self._progress),
            title=f"[bold cyan]ReconX[/] — [yellow]{self.target}[/]",
            border_style="cyan",
            subtitle=f"[dim]{self._completed}/{self.total_steps} steps complete[/]",
        ))

        return Group(*components)

    def _refresh(self) -> None:
        if self._live:
            self._live.update(self._render())


# ─────────────────────────────────────────────────────────────────────────────
# Convenience: print_tool_event (non-live, single-line output)
# ─────────────────────────────────────────────────────────────────────────────

def print_tool_event(
    tool_name: str,
    status:    str,
    message:   str   = "",
    console:   Optional[Console] = None,
) -> None:
    """Print a single [STATUS] ToolName — message line. For non-Live contexts."""
    c   = console or Console()
    tag = status_tag(status)
    c.print(tag, f"[bold white]{tool_name}[/]", f"[dim]{message}[/]")
