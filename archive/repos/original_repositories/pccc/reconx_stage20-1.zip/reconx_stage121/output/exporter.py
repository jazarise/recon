"""
ReconX — Output Engine v2. Red theme HTML, JSON, TXT exporters.
"""
from __future__ import annotations
import json, os
from html import escape
from rich.console import Console
from ..models.findings import ReconResult

OutputFormat = str   # "txt" | "json" | "html"


class JsonExporter:
    def export(self, result: ReconResult, path: str) -> str:
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(result.to_dict(), f, indent=2, default=str)
        return path


class TxtExporter:
    def export(self, result: ReconResult, path: str) -> str:
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        lines = [
            "=" * 64,
            f"RECONX REPORT  —  {result.target}",
            f"Mode: {result.mode}   Timestamp: {result.timestamp}",
            "=" * 64,
        ]
        rs = result.risk_score
        if rs:
            lines += ["", f"RISK SCORE: {rs.total}/100  Grade {rs.grade}"]
            for k, v in rs.breakdown.items():
                lines.append(f"  {k}: {v} pts")
        if result.ip_addresses:
            lines += ["", "IPs:", *[f"  {ip}" for ip in result.ip_addresses]]
        if result.ports:
            lines += ["", "OPEN PORTS:"]
            for p in result.ports:
                lines.append(f"  {p.number:<7}{p.protocol:<8}{p.service:<14}{p.version or '—'}")
        if result.subdomains:
            lines += ["", f"SUBDOMAINS ({len(result.subdomains)}):"]
            lines += [f"  {s}" for s in result.subdomains]
        if result.cve_matches:
            lines += ["", "CVE MATCHES:"]
            for c in result.cve_matches:
                lines.append(f"  [{c.severity}] {c.cve_id}  {c.description}")
        if result.takeover_candidates:
            lines += ["", "TAKEOVER CANDIDATES:"]
            for tc in result.takeover_candidates:
                lines.append(f"  [{tc.confidence}] {tc.subdomain} → {tc.cname} ({tc.service})")
        if result.header_findings:
            lines += ["", "HTTP HEADERS:"]
            for h in result.header_findings:
                lines.append(f"  [{h.status.upper():<8}] {h.header}")
        if result.sensitive_findings:
            lines += ["", "SENSITIVE FINDINGS:"]
            for sf in result.sensitive_findings:
                lines.append(f"  [{sf.severity}] {sf.category}: {sf.detail}")
        if result.suggestions:
            lines += ["", "SUGGESTIONS:"]
            for s in result.suggestions:
                lines.append(f"  [{s.severity}] {s.risk}")
                lines.append(f"    → {s.recommendation}")
        lines += ["", "=" * 64,
                  "For authorized security testing and educational use only."]
        with open(path, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))
        return path


class HtmlExporter:
    """Dark red-theme HTML report."""

    _SEV = {"CRITICAL": "#ff2d55", "HIGH": "#ff6b35", "MEDIUM": "#ffd60a", "LOW": "#30d158"}

    def export(self, result: ReconResult, path: str) -> str:
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)

        def badge(sev: str) -> str:
            col = self._SEV.get(sev.upper(), "#888")
            return (f'<span style="display:inline-block;font-size:10px;font-weight:700;'
                    f'letter-spacing:1px;padding:2px 8px;border-radius:4px;'
                    f'border:1px solid {col};color:{col}">{escape(sev.upper())}</span>')

        # ── DNS ───────────────────────────────────────────────────────────────
        dns_rows = "".join(
            f"<tr><td class='mono c'>{escape(r.record_type)}</td>"
            f"<td class='mono'>{escape(r.value)}</td></tr>"
            for r in result.dns_records[:40]
        ) or "<tr><td colspan='2' class='empty'>No records.</td></tr>"

        # ── Ports ─────────────────────────────────────────────────────────────
        port_rows = "".join(
            f"<tr><td><span class='tag'>{p.number}</span></td>"
            f"<td class='dim'>{escape(p.protocol)}</td>"
            f"<td class='c'>{escape(p.service)}</td>"
            f"<td class='mono dim'>{escape(p.version or '—')}</td></tr>"
            for p in result.ports
        ) or "<tr><td colspan='4' class='empty'>No open ports found.</td></tr>"

        # ── Subdomains ────────────────────────────────────────────────────────
        sub_items = "".join(
            f"<li>{escape(s)}</li>" for s in result.subdomains[:100]
        ) or "<li>None discovered.</li>"

        # ── CVEs ──────────────────────────────────────────────────────────────
        cve_rows = "".join(
            f"<tr><td class='mono red'>{escape(c.cve_id)}</td>"
            f"<td>{badge(c.severity)}</td>"
            f"<td class='mono dim'>{escape(str(c.cvss))}</td>"
            f"<td class='c'>{escape(c.service)}</td>"
            f"<td class='dim'>{escape(c.description[:80])}</td></tr>"
            for c in result.cve_matches
        ) or "<tr><td colspan='5' class='empty'>✓ No CVEs matched.</td></tr>"

        # ── TLS ───────────────────────────────────────────────────────────────
        tls_html = ""
        if result.tls_info:
            tls = result.tls_info
            exp_col = "#ff2d55" if tls.is_expired else ("#ffd60a" if 0 <= tls.days_remaining <= 30 else "#30d158")
            ss_col  = "#ff2d55" if tls.is_self_signed else "#30d158"
            tls_html = f"""
  <div class="card">
    <div class="card-title">TLS Certificate</div>
    <table><thead><tr><th>Field</th><th>Value</th></tr></thead><tbody>
      <tr><td class="dim">Subject</td><td class="mono">{escape(tls.subject)}</td></tr>
      <tr><td class="dim">Issuer</td><td class="mono">{escape(tls.issuer)}</td></tr>
      <tr><td class="dim">Valid Until</td>
          <td class="mono" style="color:{exp_col}">{escape(tls.valid_until)}
          ({tls.days_remaining}d remaining)</td></tr>
      <tr><td class="dim">Self-Signed</td>
          <td style="color:{ss_col}">{'YES ⚠' if tls.is_self_signed else 'No'}</td></tr>
      <tr><td class="dim">Protocol</td><td class="mono">{escape(tls.protocol)}</td></tr>
      <tr><td class="dim">Cipher</td><td class="mono">{escape(tls.cipher)}</td></tr>
    </tbody></table>
  </div>"""

        # ── Headers ───────────────────────────────────────────────────────────
        hdr_rows = "".join(
            f"<tr><td class='mono'>{escape(h.header)}</td>"
            f"<td><span class='hstatus {h.status}'>{escape(h.status.upper())}</span></td>"
            f"<td class='dim'>{escape((h.risk or h.value or '')[:80])}</td></tr>"
            for h in result.header_findings
        ) or "<tr><td colspan='3' class='empty'>No header data.</td></tr>"

        # ── Takeovers ─────────────────────────────────────────────────────────
        to_rows = "".join(
            f"<tr><td class='red mono'>{escape(tc.subdomain)}</td>"
            f"<td class='c'>{escape(tc.service)}</td>"
            f"<td><span style='color:{'#ff2d55' if tc.confidence=='HIGH' else '#ffd60a'}'>"
            f"{escape(tc.confidence)}</span></td>"
            f"<td class='dim'>{escape(tc.detail[:70])}</td></tr>"
            for tc in result.takeover_candidates
        ) or "<tr><td colspan='4' class='empty'>✓ No takeover candidates.</td></tr>"

        # ── Sensitive ─────────────────────────────────────────────────────────
        sens_rows = "".join(
            f"<tr><td>{badge(f.severity)}</td>"
            f"<td class='c'>{escape(f.category)}</td>"
            f"<td class='dim'>{escape(f.detail)}"
            f"{'<br><small class=mono>'+escape(f.url)+'</small>' if f.url else ''}"
            f"</td></tr>"
            for f in result.sensitive_findings
        ) or "<tr><td colspan='3' class='empty'>✓ No sensitive findings.</td></tr>"

        # ── Suggestions ───────────────────────────────────────────────────────
        sug_rows = "".join(
            f"<tr><td>{badge(s.severity)}</td>"
            f"<td class='c'>{escape(s.risk)}</td>"
            f"<td class='dim'>{escape(s.recommendation)}</td></tr>"
            for s in result.suggestions
        ) or "<tr><td colspan='3' class='empty'>No suggestions.</td></tr>"

        # ── Risk score ────────────────────────────────────────────────────────
        rs = result.risk_score
        rs_html = ""
        if rs:
            grade_col = {"A":"#30d158","B":"#30d158","C":"#ffd60a",
                         "D":"#ff6b35","F":"#ff2d55"}.get(rs.grade,"#fff")
            bk_rows = "".join(
                f"<tr><td class='dim'>{escape(k)}</td>"
                f"<td style='color:{grade_col};font-family:var(--mono)'>{v} pts</td></tr>"
                for k, v in rs.breakdown.items()
            )
            rs_html = f"""
  <div class="card">
    <div class="card-title">Risk Score</div>
    <div style="text-align:center;padding:12px 0">
      <span style="font-size:56px;font-weight:700;color:{grade_col};
                   font-family:var(--mono)">{rs.total}</span>
      <span style="font-size:20px;color:var(--dim)">/100</span>
      <div style="font-size:28px;color:{grade_col};letter-spacing:4px;
                  margin-top:4px">Grade {rs.grade}</div>
    </div>
    <table><thead><tr><th>Factor</th><th>Points</th></tr></thead>
    <tbody>{bk_rows}</tbody></table>
  </div>"""

        # Technologies
        techs_html = " ".join(
            f'<span class="tech">{escape(t.name)}</span>'
            for t in result.technologies
        ) or "—"

        try:
            from datetime import datetime as _dt
            friendly = _dt.strptime(result.timestamp, "%Y%m%d_%H%M%S").strftime("%B %d, %Y %H:%M")
        except Exception:
            friendly = result.timestamp

        crit_count = sum(1 for c in result.cve_matches if c.severity == "CRITICAL")
        high_count = sum(1 for c in result.cve_matches if c.severity == "HIGH")

        html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<title>ReconX — {escape(result.target)}</title>
<link href="https://fonts.googleapis.com/css2?family=Share+Tech+Mono&family=Chakra+Petch:wght@400;600;700&display=swap" rel="stylesheet"/>
<style>
*,*::before,*::after{{box-sizing:border-box;margin:0;padding:0}}
:root{{
  --bg:#07040a;--bg2:#100810;--bg3:#180d18;--border:#3a0a1a;
  --red:#ff1a3a;--red2:#cc0022;--dim-red:#661122;
  --text:#e8c8d0;--dim:#7a4455;--mono:'Share Tech Mono',monospace;
  --font:'Chakra Petch',monospace;
  --glow:0 0 24px rgba(255,26,58,.18);
}}
body{{background:var(--bg);color:var(--text);font-family:var(--font);
     font-size:14px;line-height:1.6;
     background-image:
       radial-gradient(ellipse at 10% 0%,rgba(200,0,40,.06) 0%,transparent 55%),
       radial-gradient(ellipse at 90% 100%,rgba(150,0,30,.04) 0%,transparent 55%),
       repeating-linear-gradient(0deg,transparent,transparent 39px,
         rgba(255,26,58,.025) 39px,rgba(255,26,58,.025) 40px);}}
.wrap{{max-width:1140px;margin:0 auto;padding:40px 24px 80px}}
h1{{font-size:40px;letter-spacing:8px;color:var(--red);
    text-shadow:0 0 30px rgba(255,26,58,.5),0 0 60px rgba(255,26,58,.2)}}
.subtitle{{color:var(--dim);font-family:var(--mono);font-size:12px;
           margin-top:6px;letter-spacing:2px}}
.subtitle span{{color:#ff6688}}
.stats{{display:grid;grid-template-columns:repeat(auto-fit,minmax(110px,1fr));
        gap:12px;margin:28px 0}}
.stat{{background:var(--bg2);border:1px solid var(--border);border-radius:8px;
       padding:16px;text-align:center;transition:border-color .2s,box-shadow .2s}}
.stat:hover{{border-color:var(--red);box-shadow:var(--glow)}}
.stat .num{{font-size:34px;font-family:var(--mono);font-weight:700;
            color:var(--red);line-height:1;margin-bottom:4px}}
.stat .lbl{{font-size:9px;letter-spacing:2px;text-transform:uppercase;color:var(--dim)}}
.card{{background:var(--bg2);border:1px solid var(--border);border-radius:10px;
       padding:24px;margin-bottom:24px;box-shadow:0 4px 20px rgba(0,0,0,.5)}}
.card-title{{font-size:11px;letter-spacing:3px;text-transform:uppercase;
             color:var(--red);margin-bottom:16px;padding-bottom:10px;
             border-bottom:1px solid var(--border)}}
table{{width:100%;border-collapse:collapse;font-size:13px}}
th{{font-size:9px;letter-spacing:2px;text-transform:uppercase;color:var(--dim);
    padding:8px 10px;border-bottom:1px solid var(--border);text-align:left}}
td{{padding:9px 10px;border-bottom:1px solid rgba(58,10,26,.5);vertical-align:top}}
tr:last-child td{{border-bottom:none}}
tr:hover td{{background:rgba(255,26,58,.03)}}
.mono{{font-family:var(--mono);font-size:12px}}
.dim{{color:var(--dim)}}
.c{{color:#ff8899}}
.red{{color:var(--red)}}
.tag{{display:inline-block;background:rgba(255,26,58,.1);
      border:1px solid rgba(255,26,58,.3);color:var(--red);
      font-family:var(--mono);font-size:12px;padding:1px 7px;border-radius:4px}}
.tech{{display:inline-block;background:rgba(255,26,58,.07);
       border:1px solid rgba(255,26,58,.2);color:#ff8899;
       font-size:11px;padding:2px 8px;border-radius:12px;margin:2px}}
ul.subs{{columns:3;column-gap:24px;list-style:none;
          font-family:var(--mono);font-size:12px;color:var(--dim)}}
ul.subs li::before{{content:"▸ ";color:var(--red)}}
.hstatus.present{{color:#30d158}}.hstatus.missing{{color:#ff2d55}}
.hstatus.weak{{color:#ffd60a}}
.empty{{text-align:center;color:var(--dim);padding:20px;font-style:italic}}
.footer{{text-align:center;color:var(--dim);font-size:11px;
         font-family:var(--mono);border-top:1px solid var(--border);
         padding-top:20px;margin-top:40px;letter-spacing:1px}}
body::after{{content:'';position:fixed;inset:0;
  background:repeating-linear-gradient(0deg,transparent,transparent 2px,
    rgba(0,0,0,.06) 2px,rgba(0,0,0,.06) 4px);
  pointer-events:none;z-index:9999}}
</style>
</head>
<body>
<div class="wrap">
  <h1>RECONX</h1>
  <div class="subtitle">
    Target: <span>{escape(result.target)}</span> &nbsp;·&nbsp;
    Mode: <span>{escape(result.mode.upper())}</span> &nbsp;·&nbsp;
    <span>{escape(friendly)}</span>
  </div>

  <div class="stats">
    <div class="stat"><div class="num">{len(result.ip_addresses)}</div><div class="lbl">IPs</div></div>
    <div class="stat"><div class="num">{len(result.subdomains)}</div><div class="lbl">Subdomains</div></div>
    <div class="stat"><div class="num">{len(result.ports)}</div><div class="lbl">Open Ports</div></div>
    <div class="stat"><div class="num" style="color:#ff2d55">{len(result.cve_matches)}</div><div class="lbl">CVEs</div></div>
    <div class="stat"><div class="num" style="color:#ff2d55">{crit_count}</div><div class="lbl">Critical</div></div>
    <div class="stat"><div class="num" style="color:#ff6b35">{high_count}</div><div class="lbl">High</div></div>
    <div class="stat"><div class="num" style="color:#ff2d55">{len(result.takeover_candidates)}</div><div class="lbl">Takeovers</div></div>
    <div class="stat"><div class="num">{len(result.technologies)}</div><div class="lbl">Technologies</div></div>
  </div>

  {rs_html}

  <div class="card">
    <div class="card-title">🌐 DNS Records</div>
    <table><thead><tr><th>Type</th><th>Value</th></tr></thead>
    <tbody>{dns_rows}</tbody></table>
  </div>

  {'<div class="card"><div class="card-title">🔍 Subdomains ('+str(len(result.subdomains))+')</div><ul class="subs">'+sub_items+'</ul></div>' if result.subdomains else ''}

  <div class="card">
    <div class="card-title">📡 Open Ports & Services</div>
    <table><thead><tr><th>Port</th><th>Proto</th><th>Service</th><th>Version</th></tr></thead>
    <tbody>{port_rows}</tbody></table>
  </div>

  {'<div class="card"><div class="card-title">🧩 Technologies</div><p style="padding-top:6px">'+techs_html+'</p></div>' if result.technologies else ''}

  {tls_html}

  <div class="card">
    <div class="card-title">🔒 HTTP Security Headers</div>
    <table><thead><tr><th>Header</th><th>Status</th><th>Detail</th></tr></thead>
    <tbody>{hdr_rows}</tbody></table>
  </div>

  <div class="card">
    <div class="card-title">⚠ CVE Matches</div>
    <table><thead><tr><th>CVE ID</th><th>Severity</th><th>CVSS</th><th>Service</th><th>Description</th></tr></thead>
    <tbody>{cve_rows}</tbody></table>
  </div>

  <div class="card">
    <div class="card-title">💀 Subdomain Takeover Candidates</div>
    <table><thead><tr><th>Subdomain</th><th>Service</th><th>Confidence</th><th>Detail</th></tr></thead>
    <tbody>{to_rows}</tbody></table>
  </div>

  <div class="card">
    <div class="card-title">🔎 Sensitive Findings</div>
    <table><thead><tr><th>Severity</th><th>Category</th><th>Detail</th></tr></thead>
    <tbody>{sens_rows}</tbody></table>
  </div>

  <div class="card">
    <div class="card-title">💡 Security Suggestions</div>
    <table><thead><tr><th>Severity</th><th>Risk</th><th>Recommendation</th></tr></thead>
    <tbody>{sug_rows}</tbody></table>
  </div>

  <footer class="footer">
    RECONX v2.0 &nbsp;·&nbsp; For authorized security testing and educational use only.<br/>
    <small style="opacity:.4">Do not use against systems you do not own or have explicit written permission to test.</small>
  </footer>
</div>
</body>
</html>"""

        with open(path, "w", encoding="utf-8") as f:
            f.write(html)
        return path


class OutputEngine:
    def __init__(self, base_dir: str = "reports"):
        self.base_dir = base_dir

    def print_summary(self, result: ReconResult, console=None) -> None:
        pass  # handled by __main__._print_scan_summary

    def export(self, result: ReconResult, formats: list[str],
               console: Console | None = None) -> dict[str, str]:
        os.makedirs(self.base_dir, exist_ok=True)
        safe  = result.target.replace(".", "_").replace("/", "_")
        base  = os.path.join(self.base_dir, f"reconx_{safe}_{result.timestamp}")
        out   = {}
        c     = console or Console()
        _map  = {"json": (JsonExporter, ".json"),
                 "txt":  (TxtExporter,  ".txt"),
                 "html": (HtmlExporter, ".html")}
        for fmt in formats:
            if fmt not in _map:
                continue
            cls, ext = _map[fmt]
            path = cls().export(result, base + ext)
            out[fmt] = path
            c.print(f"[bold green]✔[/bold green] [dim]{fmt.upper()}:[/dim] [red]{path}[/red]")
        return out
