"""
ReconX — Output: Live Terminal Operations Center (Stage 13).

Full-screen Rich TUI rendered during pipeline execution.

Panels:
  ┌── Target & Mode ──────────────────────────────────────────────────────┐
  │  Target: example.com (domain)    Mode: BALANCED    Start: 14:22:01   │
  └───────────────────────────────────────────────────────────────────────┘
  ┌── Pipeline ───────────────────────────┐  ┌── Findings ──────────────┐
  │  [RUNNING] TheHarvesterTool          │  │  subdomain      : 142    │
  │  [SUCCESS] CrtshTool       12.3s     │  │  email          : 8      │
  │  [FAILED]  AmassTool        3.1s     │  │  url            : 567    │
  │  [MISSING] ShuffleDNSTool            │  │  secret         : 2      │
  └───────────────────────────────────────┘  └──────────────────────────┘
  ┌── Progress ───────────────────────────────────────────────────────────┐
  │  ████████████░░░░░░░░░  12/20 tasks    3 failed   eta ~8 min         │
  └───────────────────────────────────────────────────────────────────────┘
  ┌── System ─────────────────────────────────────────────────────────────┐
  │  CPU: 42%   RAM: 1.2 GB   Success rate: 85%   Running: 00:12:34      │
  └───────────────────────────────────────────────────────────────────────┘
"""
from __future__ import annotations

import threading
import time
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Optional

from rich import box
from rich.columns import Columns
from rich.console import Console
from rich.layout import Layout
from rich.live import Live
from rich.panel import Panel
from rich.progress import (
    BarColumn, MofNCompleteColumn, Progress,
    SpinnerColumn, TaskProgressColumn, TextColumn, TimeElapsedColumn,
)
from rich.table import Table
from rich.text import Text


# ─────────────────────────────────────────────────────────────────────────────
# Status styling
# ─────────────────────────────────────────────────────────────────────────────

_STATUS_STYLE: dict[str, tuple[str, str]] = {
    "RUNNING":   ("cyan",   "▶"),
    "SUCCESS":   ("green",  "✓"),
    "FAILED":    ("red",    "✗"),
    "MISSING":   ("yellow", "?"),
    "SKIPPED":   ("dim",    "–"),
    "RETRYING":  ("orange3","↺"),
    "CANCELLED": ("dim red","✕"),
    "PENDING":   ("dim",    "○"),
}


def _status_text(status: str) -> Text:
    style, icon = _STATUS_STYLE.get(status.upper(), ("white", "?"))
    label = f"[{status.upper():^9}]"
    return Text(f"{icon} {label}", style=style)


# ─────────────────────────────────────────────────────────────────────────────
# Task row state
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class TaskRow:
    tool_class: str
    status:     str   = "PENDING"
    duration_s: float = 0.0
    findings:   int   = 0
    error:      str   = ""
    started_at: float = 0.0


# ─────────────────────────────────────────────────────────────────────────────
# OperationsCenter
# ─────────────────────────────────────────────────────────────────────────────

class OperationsCenter:
    """
    Live Rich TUI for the ReconX orchestration pipeline.

    Usage (context manager):
        with OperationsCenter(target, mode, total_tasks=20) as ops:
            ops.set_status("NmapTool", "RUNNING")
            ...
            ops.set_status("NmapTool", "SUCCESS", duration_s=12.3, findings=42)
            ops.add_finding("subdomain", "api.example.com")
    """

    _RECONX_BANNER = (
        "[bold cyan]██████╗ [/][cyan]███████╗[/][bold cyan]██████╗ [/]"
        "[cyan]╔═╗╔╦╗╔═╗╔═╗[/]\n"
        "[cyan]██╔══██╗██╔════╝██╔════╝[/][bold cyan]╠═╝ ║ ╠═╣║ ╦[/]\n"
        "[dim cyan]██████╔╝█████╗  ██║     [/][cyan]╩   ╩ ╩ ╩╚═╝[/]"
    )

    def __init__(
        self,
        target:       str,
        mode:         str       = "BALANCED",
        total_tasks:  int       = 20,
        console:      Optional[Console] = None,
        refresh_rate: float     = 0.3,
    ):
        self.target       = target
        self.mode         = mode
        self.total_tasks  = total_tasks
        self.console      = console or Console()
        self.refresh_rate = refresh_rate
        self._start_time  = time.time()
        self._lock        = threading.Lock()

        # State
        self._rows:     dict[str, TaskRow]   = {}
        self._findings: dict[str, list[str]] = defaultdict(list)
        self._system:   dict[str, str]       = {}
        self._log_lines: list[str]           = []

        # Progress bar
        self._progress = Progress(
            SpinnerColumn("dots", style="cyan"),
            TextColumn("[cyan]{task.description}"),
            BarColumn(bar_width=32, style="cyan", complete_style="green"),
            MofNCompleteColumn(),
            TimeElapsedColumn(),
            console=self.console,
        )
        self._ptask = self._progress.add_task(
            f"[bold]{target}[/] [{mode}]", total=total_tasks
        )
        self._completed = 0
        self._live: Optional[Live] = None

    # ── context manager ───────────────────────────────────────────────────────

    def __enter__(self) -> "OperationsCenter":
        self._live = Live(
            self._render(),
            console=self.console,
            refresh_per_second=int(1 / self.refresh_rate),
            screen=False,
        )
        self._live.__enter__()
        return self

    def __exit__(self, *args) -> None:
        if self._live:
            self._live.update(self._render())
            self._live.__exit__(*args)

    # ── public API ────────────────────────────────────────────────────────────

    def register_task(self, tool_class: str) -> None:
        with self._lock:
            if tool_class not in self._rows:
                self._rows[tool_class] = TaskRow(tool_class=tool_class)
        self._refresh()

    def set_status(
        self,
        tool_class:  str,
        status:      str,
        *,
        duration_s:  float = 0.0,
        findings:    int   = 0,
        error:       str   = "",
    ) -> None:
        with self._lock:
            if tool_class not in self._rows:
                self._rows[tool_class] = TaskRow(tool_class=tool_class)
            row = self._rows[tool_class]
            row.status = status.upper()
            if duration_s:
                row.duration_s = duration_s
            if findings:
                row.findings = findings
            if error:
                row.error = error[:60]

            terminal_statuses = {"SUCCESS", "FAILED", "SKIPPED", "MISSING", "CANCELLED"}
            if status.upper() in terminal_statuses:
                self._completed += 1
                self._progress.advance(self._ptask)

        log_icon = _STATUS_STYLE.get(status.upper(), ("", "?"))[1]
        self._push_log(f"{log_icon} {tool_class}: {status}")
        self._refresh()

    def add_finding(self, finding_type: str, value: str) -> None:
        with self._lock:
            if value not in self._findings[finding_type]:
                self._findings[finding_type].append(value)
        self._refresh()

    def add_findings_bulk(self, findings: list) -> None:
        with self._lock:
            for f in findings:
                ftype = getattr(f, "finding_type", None) or (
                    f.get("finding_type") if isinstance(f, dict) else None
                )
                val   = getattr(f, "value", None) or (
                    f.get("value") if isinstance(f, dict) else None
                )
                if ftype and val and val not in self._findings[ftype]:
                    self._findings[ftype].append(val)
        self._refresh()

    def update_system(self, **metrics: str) -> None:
        """Update system metrics: cpu, ram, net etc."""
        with self._lock:
            self._system.update(metrics)
        self._refresh()

    def log(self, message: str) -> None:
        self._push_log(message)
        self._refresh()

    def print_final_summary(self) -> None:
        """Print post-run summary table after Live context exits."""
        table = Table(title="ReconX Run Summary", box=box.ROUNDED, border_style="cyan")
        table.add_column("Tool",     style="bold white", min_width=28)
        table.add_column("Status",   min_width=12)
        table.add_column("Duration", justify="right", min_width=8)
        table.add_column("Findings", justify="right", min_width=8)
        table.add_column("Notes",    style="dim")

        with self._lock:
            for row in sorted(self._rows.values(), key=lambda r: r.tool_class):
                table.add_row(
                    row.tool_class,
                    _status_text(row.status),
                    f"{row.duration_s:.1f}s" if row.duration_s else "—",
                    str(row.findings) if row.findings else "—",
                    row.error or "",
                )
        self.console.print(table)

        # Finding counts
        with self._lock:
            ftypes = dict(self._findings)
        if ftypes:
            ft = Table(title="Finding Summary", box=box.SIMPLE, border_style="dim cyan")
            ft.add_column("Type",  style="cyan")
            ft.add_column("Count", justify="right", style="bold white")
            for ftype, values in sorted(ftypes.items(), key=lambda x: -len(x[1])):
                ft.add_row(ftype, str(len(values)))
            self.console.print(ft)

    # ── rendering ─────────────────────────────────────────────────────────────

    def _render(self):
        """Build the full-screen Rich renderable."""
        elapsed = time.time() - self._start_time

        # ── Header ────────────────────────────────────────────────────────────
        header = Panel(
            f"[bold white]Target:[/] [yellow]{self.target}[/]   "
            f"[bold white]Mode:[/] [cyan]{self.mode}[/]   "
            f"[bold white]Elapsed:[/] [dim]{self._fmt_time(elapsed)}[/]   "
            f"[bold white]Tasks:[/] [green]{self._completed}[/]/{self.total_tasks}",
            title="[bold cyan]RECONX Operations Center[/]",
            border_style="cyan",
        )

        # ── Task table ────────────────────────────────────────────────────────
        task_table = Table(box=box.SIMPLE_HEAVY, show_header=True,
                           header_style="bold dim", border_style="dim cyan",
                           expand=True)
        task_table.add_column("Status",   width=13)
        task_table.add_column("Tool",     style="bold white")
        task_table.add_column("Duration", justify="right", width=8)
        task_table.add_column("Found",    justify="right", width=6)

        with self._lock:
            rows = sorted(self._rows.values(), key=lambda r: (
                {"RUNNING": 0, "RETRYING": 1}.get(r.status, 2), r.tool_class
            ))
        for row in rows[-25:]:   # show last 25
            task_table.add_row(
                _status_text(row.status),
                row.tool_class,
                f"{row.duration_s:.1f}s" if row.duration_s else "—",
                str(row.findings) if row.findings else "—",
            )

        task_panel = Panel(task_table, title="[cyan]Pipeline[/]",
                           border_style="dim cyan")

        # ── Findings panel ────────────────────────────────────────────────────
        with self._lock:
            ftypes = dict(self._findings)
        find_table = Table(box=box.SIMPLE, show_header=False, expand=True)
        find_table.add_column("Type",  style="cyan", min_width=16)
        find_table.add_column("Count", style="bold white", justify="right")
        total_f = 0
        for ftype, vals in sorted(ftypes.items(), key=lambda x: -len(x[1])):
            find_table.add_row(ftype, str(len(vals)))
            total_f += len(vals)
        find_table.add_row("[bold]TOTAL[/]", f"[bold green]{total_f}[/]")
        find_panel = Panel(find_table, title="[cyan]Findings[/]",
                           border_style="dim cyan")

        # ── System metrics ────────────────────────────────────────────────────
        with self._lock:
            sys_metrics = dict(self._system)
        succ = sum(1 for r in self._rows.values() if r.status == "SUCCESS")
        fail = sum(1 for r in self._rows.values() if r.status == "FAILED")
        rate = f"{succ / max(self._completed, 1) * 100:.0f}%" if self._completed else "—"

        sys_line = (
            f"[bold white]Success rate:[/] [green]{rate}[/]   "
            f"[bold white]Passed:[/] [green]{succ}[/]   "
            f"[bold white]Failed:[/] [red]{fail}[/]"
        )
        if sys_metrics:
            extras = "   ".join(
                f"[bold white]{k}:[/] [cyan]{v}[/]" for k, v in sys_metrics.items()
            )
            sys_line = extras + "   " + sys_line

        sys_panel = Panel(sys_line, title="[cyan]System[/]",
                          border_style="dim cyan", height=3)

        # ── Log panel ─────────────────────────────────────────────────────────
        with self._lock:
            log_lines = list(self._log_lines[-6:])
        log_text = "\n".join(f"[dim]{ln}[/]" for ln in log_lines) or "[dim]—[/]"
        log_panel = Panel(log_text, title="[cyan]Log[/]",
                          border_style="dim", height=8)

        from rich import group as rg
        from rich.console import Group as RG

        return RG(
            header,
            Columns([task_panel, find_panel], equal=False, expand=True),
            self._progress,
            sys_panel,
            log_panel,
        )

    # ── internals ─────────────────────────────────────────────────────────────

    def _push_log(self, message: str) -> None:
        ts = time.strftime("%H:%M:%S")
        with self._lock:
            self._log_lines.append(f"[{ts}] {message}")
            if len(self._log_lines) > 200:
                self._log_lines = self._log_lines[-100:]

    def _refresh(self) -> None:
        if self._live:
            try:
                self._live.update(self._render())
            except Exception:
                pass

    @staticmethod
    def _fmt_time(seconds: float) -> str:
        s = int(seconds)
        return f"{s // 3600:02d}:{(s % 3600) // 60:02d}:{s % 60:02d}"
