"""
ReconX — Stage 12.1 Report Extension.

Extends the existing ReportGenerator with new sections:
  • Screenshots gallery (EyeWitness integration)
  • OSINT findings (theHarvester / SpiderFoot / OSRFramework)
  • DNS findings (dnsenum / dnsrecon / fierce / Sublist3r)
  • Network discovery (netdiscover / fping)
  • Tool execution timeline (per-step duration chart)
  • Error / MISSING tool log

Generates a self-contained HTML report. No external CDN dependencies
beyond Google Fonts (degrades gracefully if offline).
"""
from __future__ import annotations
import base64
import json
import os
from datetime import datetime
from html import escape
from pathlib import Path
from typing import Optional


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _badge(text: str, colour: str) -> str:
    return f'<span class="badge" style="background:{colour}">{escape(text)}</span>'


def _status_pill(status: str) -> str:
    colours = {
        "SUCCESS": "#00c853", "FAILED": "#d50000", "MISSING": "#ff6d00",
        "SKIPPED": "#607d8b", "RUNNING": "#00b0ff", "PENDING": "#455a64",
    }
    col = colours.get(status.upper(), "#546e7a")
    return f'<span class="pill" style="background:{col}">{escape(status.upper())}</span>'


def _screenshot_img(path: str, max_b64_kb: int = 800) -> str:
    """Inline a screenshot as a base64 <img> tag. Returns empty if file missing/too large."""
    try:
        size_kb = os.path.getsize(path) / 1024
        if size_kb > max_b64_kb:
            return f'<p class="dim">[Screenshot too large to inline — {size_kb:.0f} KB]</p>'
        data = Path(path).read_bytes()
        b64  = base64.b64encode(data).decode()
        return f'<img src="data:image/png;base64,{b64}" class="screenshot" alt="screenshot"/>'
    except Exception:
        return '<p class="dim">[Screenshot not available]</p>'


# ─────────────────────────────────────────────────────────────────────────────
# Section renderers
# ─────────────────────────────────────────────────────────────────────────────

def _render_osint_section(findings: list[dict]) -> str:
    emails     = [f for f in findings if f.get("finding_type") == "email"]
    subdomains = [f for f in findings if f.get("finding_type") == "subdomain"]
    profiles   = [f for f in findings if f.get("finding_type") == "social_profile"]
    breaches   = [f for f in findings if f.get("finding_type") == "breach_indicator"]

    if not any([emails, subdomains, profiles, breaches]):
        return ""

    rows_email = "".join(
        f'<tr><td class="mono">{escape(f["value"])}</td>'
        f'<td class="dim">{escape(f.get("source",""))}</td></tr>'
        for f in emails
    )
    rows_sub = "".join(
        f'<tr><td class="mono">{escape(f["value"])}</td>'
        f'<td class="dim">{escape(f.get("source",""))}</td></tr>'
        for f in subdomains[:100]   # cap at 100 for readability
    )
    sub_overflow = f'<p class="dim">… and {len(subdomains)-100} more</p>' if len(subdomains) > 100 else ""

    rows_profile = "".join(
        f'<tr><td><a href="{escape(f["value"])}" target="_blank" class="link">{escape(f["value"])}</a></td>'
        f'<td class="dim">{escape(f.get("metadata",{}).get("platform",""))}</td></tr>'
        for f in profiles
    )
    rows_breach = "".join(
        f'<tr><td class="mono danger">{escape(f["value"])}</td>'
        f'<td class="dim">{escape(f.get("source",""))}</td></tr>'
        for f in breaches
    )

    return f"""
<section class="report-section" id="osint">
  <h2 class="section-title">🕵️ OSINT &amp; Passive Intelligence</h2>

  <div class="stat-row">
    <div class="stat-card"><div class="stat-n">{len(emails)}</div><div class="stat-l">Emails</div></div>
    <div class="stat-card"><div class="stat-n">{len(subdomains)}</div><div class="stat-l">Subdomains</div></div>
    <div class="stat-card"><div class="stat-n">{len(profiles)}</div><div class="stat-l">Social Profiles</div></div>
    <div class="stat-card {'stat-danger' if breaches else ''}">
      <div class="stat-n">{len(breaches)}</div><div class="stat-l">Breach Indicators</div>
    </div>
  </div>

  {'<h3>Email Addresses</h3><table class="data-table"><thead><tr><th>Email</th><th>Source</th></tr></thead><tbody>' + rows_email + '</tbody></table>' if rows_email else ''}
  {'<h3>Subdomains Discovered</h3><table class="data-table"><thead><tr><th>Subdomain</th><th>Source</th></tr></thead><tbody>' + rows_sub + '</tbody></table>' + sub_overflow if rows_sub else ''}
  {'<h3>Social Profiles</h3><table class="data-table"><thead><tr><th>URL</th><th>Platform</th></tr></thead><tbody>' + rows_profile + '</tbody></table>' if rows_profile else ''}
  {'<h3 class="danger">⚠️ Breach Indicators</h3><table class="data-table"><thead><tr><th>Indicator</th><th>Source</th></tr></thead><tbody>' + rows_breach + '</tbody></table>' if rows_breach else ''}
</section>
"""


def _render_dns_section(findings: list[dict]) -> str:
    dns_records   = [f for f in findings if f.get("finding_type") == "dns_txt_record"]
    zone_transfer = [f for f in findings if f.get("finding_type") == "vulnerability"
                     and "zone" in f.get("value", "").lower()]
    wildcards     = [f for f in findings if f.get("finding_type") == "dns_wildcard"]

    if not any([dns_records, zone_transfer, wildcards]):
        return ""

    zt_html = ""
    if zone_transfer:
        zt_html = '<div class="alert alert-danger">⚠️ <strong>Zone Transfer Allowed (AXFR)</strong> — The DNS server accepts zone transfer requests, leaking the entire DNS zone to any requestor. Severity: HIGH. Fix: restrict AXFR to authorised secondary nameservers only.</div>'

    wc_html = ""
    if wildcards:
        entries = "".join(f'<li class="mono">{escape(w["value"])}</li>' for w in wildcards)
        wc_html = f'<div class="alert alert-warn">⚠️ <strong>Wildcard DNS Detected</strong> — Subdomain brute-force results may contain false positives.<ul>{entries}</ul></div>'

    txt_html = ""
    if dns_records:
        rows = "".join(
            f'<tr><td class="mono small">{escape(r["value"])}</td></tr>'
            for r in dns_records
        )
        txt_html = f'<h3>TXT Records</h3><table class="data-table"><thead><tr><th>Record</th></tr></thead><tbody>{rows}</tbody></table>'

    return f"""
<section class="report-section" id="dns">
  <h2 class="section-title">🌐 DNS Intelligence</h2>
  {zt_html}
  {wc_html}
  {txt_html}
</section>
"""


def _render_network_section(findings: list[dict]) -> str:
    live_hosts = [f for f in findings if f.get("finding_type") == "live_host"]
    if not live_hosts:
        return ""

    rows = "".join(
        f'<tr>'
        f'<td class="mono">{escape(h["value"])}</td>'
        f'<td class="mono dim">{escape(h.get("metadata",{}).get("mac",""))}</td>'
        f'<td>{escape(h.get("metadata",{}).get("vendor",""))}</td>'
        f'<td>{escape(str(h.get("metadata",{}).get("latency_ms","")) + " ms" if h.get("metadata",{}).get("latency_ms") else "—")}</td>'
        f'<td class="dim">{escape(h.get("metadata",{}).get("method",""))}</td>'
        f'</tr>'
        for h in live_hosts
    )
    return f"""
<section class="report-section" id="network">
  <h2 class="section-title">📡 Live Host Discovery</h2>
  <div class="stat-row">
    <div class="stat-card"><div class="stat-n">{len(live_hosts)}</div><div class="stat-l">Live Hosts</div></div>
  </div>
  <table class="data-table">
    <thead><tr><th>IP Address</th><th>MAC</th><th>Vendor</th><th>Latency</th><th>Method</th></tr></thead>
    <tbody>{rows}</tbody>
  </table>
</section>
"""


def _render_screenshots_section(findings: list[dict], inline: bool = True) -> str:
    shots = [f for f in findings if f.get("finding_type") in ("web_screenshot", "login_page")]
    if not shots:
        return ""

    cards = ""
    for s in shots:
        url   = s.get("value", "")
        meta  = s.get("metadata", {})
        title = meta.get("title", "")
        path  = meta.get("screenshot_path", "")
        login = meta.get("login_detected", False)

        img_html = _screenshot_img(path) if (inline and path) else ""
        login_badge = _badge("LOGIN PAGE", "#d50000") if login else ""

        cards += f"""
<div class="screenshot-card">
  <div class="screenshot-header">
    {login_badge}
    <a href="{escape(url)}" class="link mono small" target="_blank">{escape(url)}</a>
    {'<span class="dim small">' + escape(title) + '</span>' if title else ''}
  </div>
  {img_html if img_html else f'<p class="dim small">Screenshot path: {escape(path)}</p>'}
</div>
"""

    return f"""
<section class="report-section" id="screenshots">
  <h2 class="section-title">📸 Visual Web Reconnaissance</h2>
  <p class="dim">{len(shots)} web service(s) captured via EyeWitness</p>
  <div class="screenshot-grid">
    {cards}
  </div>
</section>
"""


def _render_timeline_section(step_results: dict[str, dict]) -> str:
    """Render a horizontal bar chart of step durations."""
    if not step_results:
        return ""

    max_dur = max((v.get("duration_s", 0) for v in step_results.values()), default=1) or 1
    rows = ""
    for step_id, info in step_results.items():
        dur     = info.get("duration_s", 0)
        status  = info.get("status", "UNKNOWN")
        name    = info.get("name", step_id)
        pct     = int((dur / max_dur) * 100)
        colour  = {"SUCCESS": "#00c853", "FAILED": "#d50000",
                   "MISSING": "#ff6d00", "SKIPPED": "#607d8b"}.get(status, "#00b0ff")
        rows += f"""
<div class="timeline-row">
  <div class="timeline-label">{_status_pill(status)} {escape(name)}</div>
  <div class="timeline-bar-wrap">
    <div class="timeline-bar" style="width:{pct}%;background:{colour}"></div>
    <span class="timeline-dur">{dur:.1f}s</span>
  </div>
</div>
"""
    return f"""
<section class="report-section" id="timeline">
  <h2 class="section-title">⏱️ Tool Execution Timeline</h2>
  <div class="timeline">{rows}</div>
</section>
"""


def _render_error_log(tool_errors: list[dict]) -> str:
    if not tool_errors:
        return ""
    rows = "".join(
        f'<tr>'
        f'<td>{escape(e.get("tool",""))}</td>'
        f'<td>{_status_pill(e.get("status","FAILED"))}</td>'
        f'<td class="mono small danger">{escape(e.get("error",""))}</td>'
        f'</tr>'
        for e in tool_errors
    )
    return f"""
<section class="report-section" id="errors">
  <h2 class="section-title">⚠️ Tool Errors &amp; Missing Dependencies</h2>
  <table class="data-table">
    <thead><tr><th>Tool</th><th>Status</th><th>Error</th></tr></thead>
    <tbody>{rows}</tbody>
  </table>
</section>
"""


# ─────────────────────────────────────────────────────────────────────────────
# Main entry point
# ─────────────────────────────────────────────────────────────────────────────

def generate_stage121_report(
    path:         str,
    target:       str,
    version:      str,
    timestamp:    str,
    all_findings: list[dict],
    step_results: Optional[dict] = None,
    tool_errors:  Optional[list[dict]] = None,
    base_report_html: Optional[str] = None,   # existing report HTML to extend
) -> None:
    """
    Generate a full Stage 12.1 HTML report.

    Args:
        path:             Output file path.
        target:           Scan target.
        version:          ReconX version string.
        timestamp:        ISO timestamp string.
        all_findings:     Flat list of all ParsedFinding dicts.
        step_results:     Dict of step_id → {status, duration_s, name}.
        tool_errors:      List of {tool, status, error} dicts.
        base_report_html: Optional existing report HTML to embed.
    """
    try:
        dt         = datetime.fromisoformat(timestamp)
        friendly_ts = dt.strftime("%B %d, %Y at %H:%M:%S UTC")
    except Exception:
        friendly_ts = timestamp

    # --- Render sections ---
    osint_sec      = _render_osint_section(all_findings)
    dns_sec        = _render_dns_section(all_findings)
    network_sec    = _render_network_section(all_findings)
    screenshots    = _render_screenshots_section(all_findings, inline=True)
    timeline       = _render_timeline_section(step_results or {})
    error_log      = _render_error_log(tool_errors or [])

    # Overall counts
    total_findings    = len(all_findings)
    critical_findings = sum(1 for f in all_findings
                            if f.get("metadata", {}).get("severity") == "CRITICAL")

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1"/>
  <title>ReconX Report — {escape(target)}</title>
  <link rel="preconnect" href="https://fonts.googleapis.com"/>
  <link href="https://fonts.googleapis.com/css2?family=Share+Tech+Mono&family=Chakra+Petch:wght@400;600;700&display=swap" rel="stylesheet"/>
  <style>
    *,*::before,*::after{{box-sizing:border-box;margin:0;padding:0}}
    :root{{
      --bg:#060a0f;--bg2:#0c1420;--bg3:#111c2d;--border:#1a3050;
      --accent:#00d4ff;--accent2:#00ff88;--danger:#ff2d55;--warn:#ff9800;
      --text:#c8d8e8;--dim:#5a7a9a;
      --font-ui:'Chakra Petch',monospace;--font-mono:'Share Tech Mono',monospace;
    }}
    body{{background:var(--bg);color:var(--text);font-family:var(--font-ui);font-size:14px;
          line-height:1.6;min-height:100vh;padding:0 0 80px}}
    .container{{max-width:1100px;margin:0 auto;padding:40px 24px}}
    /* Header */
    .report-header{{border-bottom:1px solid var(--border);padding-bottom:24px;margin-bottom:40px}}
    .report-header h1{{font-size:36px;letter-spacing:6px;color:var(--accent);
                       text-shadow:0 0 20px rgba(0,212,255,.4)}}
    .report-header .meta{{color:var(--dim);font-family:var(--font-mono);font-size:12px;
                          margin-top:8px;line-height:2}}
    .report-header .meta span{{color:var(--accent2)}}
    /* Stats row */
    .stat-row{{display:flex;gap:16px;flex-wrap:wrap;margin:16px 0 24px}}
    .stat-card{{background:var(--bg2);border:1px solid var(--border);border-radius:8px;
                padding:16px 20px;text-align:center;min-width:100px}}
    .stat-card.stat-danger{{border-color:var(--danger)}}
    .stat-n{{font-size:32px;font-weight:700;font-family:var(--font-mono);color:var(--accent)}}
    .stat-card.stat-danger .stat-n{{color:var(--danger)}}
    .stat-l{{font-size:10px;letter-spacing:2px;text-transform:uppercase;color:var(--dim)}}
    /* Sections */
    .report-section{{background:var(--bg2);border:1px solid var(--border);border-radius:10px;
                     padding:28px;margin-bottom:28px}}
    .section-title{{font-size:15px;font-weight:600;letter-spacing:2px;text-transform:uppercase;
                    color:var(--accent);margin-bottom:20px;border-bottom:1px solid var(--border);
                    padding-bottom:12px}}
    /* Tables */
    table.data-table{{width:100%;border-collapse:collapse;font-size:13px;margin-top:12px}}
    .data-table th{{font-size:10px;letter-spacing:2px;text-transform:uppercase;color:var(--dim);
                    text-align:left;padding:8px 12px;border-bottom:1px solid var(--border)}}
    .data-table td{{padding:9px 12px;border-bottom:1px solid rgba(26,48,80,.5);vertical-align:top}}
    .data-table tr:last-child td{{border-bottom:none}}
    .data-table tr:hover td{{background:rgba(0,212,255,.03)}}
    /* Utilities */
    .mono{{font-family:var(--font-mono);font-size:12px}}
    .small{{font-size:12px}}
    .dim{{color:var(--dim)}}
    .danger{{color:var(--danger)}}
    .link{{color:var(--accent);text-decoration:none}}
    .link:hover{{text-decoration:underline}}
    /* Badges & pills */
    .badge{{font-size:10px;font-weight:700;letter-spacing:1px;padding:2px 8px;
            border-radius:4px;color:#fff;margin-right:6px}}
    .pill{{font-size:10px;font-weight:700;letter-spacing:1px;padding:2px 8px;
           border-radius:12px;color:#fff;display:inline-block}}
    /* Alerts */
    .alert{{border-radius:6px;padding:14px 18px;margin-bottom:14px;font-size:13px}}
    .alert-danger{{background:rgba(255,45,85,.1);border:1px solid rgba(255,45,85,.3);
                   color:#ff6b8a}}
    .alert-warn{{background:rgba(255,152,0,.1);border:1px solid rgba(255,152,0,.3);
                 color:#ffb74d}}
    .alert ul{{margin:8px 0 0 20px}}
    /* Screenshots */
    .screenshot-grid{{display:grid;grid-template-columns:repeat(auto-fill,minmax(340px,1fr));
                      gap:20px;margin-top:16px}}
    .screenshot-card{{background:var(--bg3);border:1px solid var(--border);border-radius:8px;
                      overflow:hidden}}
    .screenshot-header{{padding:10px 14px;border-bottom:1px solid var(--border);
                        display:flex;flex-wrap:wrap;gap:8px;align-items:center}}
    img.screenshot{{width:100%;display:block;max-height:240px;object-fit:cover;
                    border-bottom:1px solid var(--border)}}
    /* Timeline */
    .timeline{{display:flex;flex-direction:column;gap:10px;margin-top:12px}}
    .timeline-row{{display:flex;align-items:center;gap:16px}}
    .timeline-label{{width:260px;flex-shrink:0;font-size:12px;display:flex;
                     align-items:center;gap:8px}}
    .timeline-bar-wrap{{flex:1;display:flex;align-items:center;gap:10px}}
    .timeline-bar{{height:14px;border-radius:4px;transition:width .3s;min-width:2px}}
    .timeline-dur{{font-family:var(--font-mono);font-size:11px;color:var(--dim);
                   white-space:nowrap}}
    /* Nav */
    .toc{{display:flex;gap:12px;flex-wrap:wrap;margin-bottom:32px}}
    .toc a{{background:var(--bg3);border:1px solid var(--border);border-radius:20px;
             padding:4px 14px;font-size:11px;letter-spacing:1px;color:var(--dim);
             text-decoration:none}}
    .toc a:hover{{border-color:var(--accent);color:var(--accent)}}
    /* Footer */
    footer{{text-align:center;color:var(--dim);font-size:11px;font-family:var(--font-mono);
            border-top:1px solid var(--border);padding-top:24px;margin-top:48px}}
  </style>
</head>
<body>
<div class="container">

  <header class="report-header">
    <h1>RECONX</h1>
    <div class="meta">
      <div>Version: <span>{escape(version)}</span> &nbsp;|&nbsp; Stage 12.1 Report</div>
      <div>Target: <span>{escape(target)}</span></div>
      <div>Generated: <span>{escape(friendly_ts)}</span></div>
      <div>Total Findings: <span>{total_findings}</span> &nbsp;|&nbsp;
           Critical: <span style="color:var(--danger)">{critical_findings}</span></div>
    </div>
  </header>

  <!-- Table of Contents -->
  <nav class="toc">
    <a href="#osint">🕵️ OSINT</a>
    <a href="#dns">🌐 DNS</a>
    <a href="#network">📡 Hosts</a>
    <a href="#screenshots">📸 Screenshots</a>
    <a href="#timeline">⏱️ Timeline</a>
    <a href="#errors">⚠️ Errors</a>
  </nav>

  {osint_sec}
  {dns_sec}
  {network_sec}
  {screenshots}
  {timeline}
  {error_log}

  <footer>
    ReconX {escape(version)} · Stage 12.1 · MIT License<br/>
    <span style="opacity:.5">For authorised security testing and educational use only.</span>
  </footer>

</div>
</body>
</html>"""

    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(html, encoding="utf-8")
