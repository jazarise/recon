"""
ReconX — Stage 14 Report Extension.

Adds Stage 14 sections to HTML reports:
  • Workflow diagram (ASCII → HTML chain visualization)
  • Tool execution path with statuses
  • Execution timeline (per-tool duration)
  • Learning notes (what each tool found and why it matters)
  • Tool relationship explanations
"""
from __future__ import annotations

from html import escape
from pathlib import Path
from typing import Optional


# ─────────────────────────────────────────────────────────────────────────────
# Workflow diagram HTML
# ─────────────────────────────────────────────────────────────────────────────

_STATUS_COLOURS = {
    "success":   "#00c853",
    "failed":    "#d50000",
    "missing":   "#ff6d00",
    "skipped":   "#607d8b",
    "cancelled": "#455a64",
    "pending":   "#37474f",
}

_STEP_NOTES: dict[str, str] = {
    "WhoisTool":       "Reveals registrar, nameservers, and org — guides ASN lookup.",
    "CrtshTool":       "Certificate logs reveal forgotten subdomains without touching target.",
    "TheHarvesterTool":"Emails and subdomains from 20+ OSINT sources simultaneously.",
    "Sublist3rTool":   "Passive subdomain enumeration — builds seed list for permutation.",
    "AlterxTool":      "Permutations turn 100 known subs into 50k targeted candidates.",
    "ShuffleDNSTool":  "Wildcard-filtered validation — removes false positives accurately.",
    "NmapTool":        "Service/version detection enables targeted CVE lookup.",
    "HttpxTool":       "Filters live web targets from large lists with tech detection.",
    "KatanaTool":      "Renders JS SPAs — finds routes static crawlers miss entirely.",
    "FeroxbusterTool": "Recursive discovery finds admin panels and backup files.",
    "ParamSpiderTool": "Archive-based param mining — no traffic to target required.",
    "ArjunTool":       "Active fuzzing confirms hidden params: debug, verbose, internal.",
    "GoWitnessTool":   "Screenshots enable visual triage of hundreds of services.",
    "TrufflehogTool":  "Verified live credentials — git history holds deleted secrets.",
    "S3ScannerTool":   "Bucket naming patterns often reveal publicly accessible backups.",
    "AsnmapTool":      "Maps all IP space the org owns — reveals shadow infrastructure.",
    "GauTool":         "Historical URLs expose removed endpoints still accessible.",
    "WaymoreTool":     "Multi-source archive adds Common Crawl + URLScan coverage.",
}


def _render_workflow_diagram(tool_list: list[str], step_statuses: dict[str, str]) -> str:
    """Render an HTML workflow chain diagram."""
    if not tool_list:
        return ""

    items = []
    for tc in tool_list:
        status  = step_statuses.get(tc, "pending").lower()
        colour  = _STATUS_COLOURS.get(status, "#455a64")
        icon    = {"success": "✓", "failed": "✗", "missing": "○",
                   "skipped": "–"}.get(status, "·")
        note    = _STEP_NOTES.get(tc, "")
        tooltip = f' title="{escape(note)}"' if note else ""

        items.append(
            f'<div class="wf-step"{tooltip}>'
            f'<span class="wf-icon" style="color:{colour}">{icon}</span>'
            f'<span class="wf-name">{escape(tc.replace("Tool", ""))}</span>'
            f'<span class="wf-status" style="color:{colour}">{escape(status.upper())}</span>'
            f'</div>'
        )

    arrows = f'<div class="wf-arrow">↓</div>'.join(items)
    return f"""
<section class="report-section" id="workflow">
  <h2 class="section-title">🔗 Workflow Execution Path</h2>
  <div class="workflow-chain">{arrows}</div>
  <p class="dim-note">Hover over a step to see why it was included.</p>
</section>
"""


def _render_tool_path_table(tasks: list[dict]) -> str:
    """Render HTML table of tool execution results."""
    if not tasks:
        return ""

    rows = ""
    for task in tasks:
        tc      = task.get("tool_class", "")
        status  = task.get("status", "pending")
        dur     = task.get("duration_s", 0)
        n_found = task.get("finding_count", 0)
        err     = task.get("error", "")
        colour  = _STATUS_COLOURS.get(status.lower(), "#607d8b")
        note    = _STEP_NOTES.get(tc, "")

        rows += f"""
<tr>
  <td class="mono">{escape(tc)}</td>
  <td><span class="status-pill" style="background:{colour}">{escape(status.upper())}</span></td>
  <td class="right">{f"{dur:.1f}s" if dur else "—"}</td>
  <td class="right">{str(n_found) if n_found else "—"}</td>
  <td class="dim small">{escape(err[:60]) if err else escape(note[:60])}</td>
</tr>"""

    return f"""
<section class="report-section" id="tool-path">
  <h2 class="section-title">🛠️ Tool Execution Detail</h2>
  <table class="data-table">
    <thead>
      <tr><th>Tool</th><th>Status</th><th>Duration</th><th>Findings</th><th>Notes</th></tr>
    </thead>
    <tbody>{rows}</tbody>
  </table>
</section>
"""


def _render_timeline(tasks: list[dict]) -> str:
    """Horizontal bar chart of per-tool execution duration."""
    timed = [t for t in tasks if t.get("duration_s", 0) > 0]
    if not timed:
        return ""

    max_dur = max(t["duration_s"] for t in timed) or 1
    rows = ""
    for task in timed:
        tc     = task.get("tool_class", "")
        dur    = task.get("duration_s", 0)
        status = task.get("status", "pending").lower()
        pct    = int((dur / max_dur) * 100)
        colour = _STATUS_COLOURS.get(status, "#00b0ff")
        rows += f"""
<div class="timeline-row">
  <div class="tl-label">{escape(tc.replace("Tool",""))}</div>
  <div class="tl-bar-wrap">
    <div class="tl-bar" style="width:{pct}%;background:{colour}"></div>
    <span class="tl-dur">{dur:.1f}s</span>
  </div>
</div>"""

    return f"""
<section class="report-section" id="timeline">
  <h2 class="section-title">⏱️ Execution Timeline</h2>
  <div class="timeline">{rows}</div>
</section>
"""


def _render_learning_notes(tool_list: list[str], findings_ctx: dict) -> str:
    """Generate educational notes explaining findings."""
    notes = ""
    for tc in tool_list:
        note = _STEP_NOTES.get(tc, "")
        if not note:
            continue
        notes += f"""
<div class="learn-note">
  <span class="learn-tool">{escape(tc.replace("Tool",""))}</span>
  <span class="learn-text">{escape(note)}</span>
</div>"""

    if not notes:
        return ""

    return f"""
<section class="report-section" id="learning">
  <h2 class="section-title">📖 Learning Notes</h2>
  <p class="dim-note">Why each tool was run and what its findings mean.</p>
  <div class="learn-notes">{notes}</div>
</section>
"""


# ─────────────────────────────────────────────────────────────────────────────
# CSS additions for Stage 14 report elements
# ─────────────────────────────────────────────────────────────────────────────

STAGE14_CSS = """
/* ── Workflow chain ────────────────────────── */
.workflow-chain {
  display: flex; flex-direction: column; gap: 0;
  align-items: flex-start; padding: 8px 0;
}
.wf-step {
  display: flex; align-items: center; gap: 12px;
  padding: 8px 16px; background: var(--bg3);
  border: 1px solid var(--border); border-radius: 6px;
  cursor: default; transition: border-color .2s;
  min-width: 260px;
}
.wf-step:hover { border-color: var(--accent); }
.wf-icon   { font-size: 16px; width: 20px; text-align: center; }
.wf-name   { font-family: var(--font-mono); font-size: 13px; flex: 1; }
.wf-status { font-size: 10px; letter-spacing: 1px; }
.wf-arrow  {
  padding: 2px 0 2px 28px; color: var(--dim); font-size: 14px;
}
/* ── Timeline ───────────────────────────────── */
.timeline { display: flex; flex-direction: column; gap: 8px; margin-top: 12px; }
.timeline-row { display: flex; align-items: center; gap: 12px; }
.tl-label  { width: 200px; flex-shrink:0; font-size:12px;
             font-family: var(--font-mono); color: var(--text); }
.tl-bar-wrap { flex:1; display:flex; align-items:center; gap:8px; }
.tl-bar    { height: 14px; border-radius: 4px; min-width: 2px; }
.tl-dur    { font-family: var(--font-mono); font-size: 11px;
             color: var(--dim); white-space: nowrap; }
/* ── Status pills ───────────────────────────── */
.status-pill {
  display: inline-block; font-size: 10px; font-weight: 700;
  letter-spacing: 1px; padding: 2px 8px; border-radius: 12px;
  color: #fff;
}
/* ── Learning notes ─────────────────────────── */
.learn-notes { display: flex; flex-direction: column; gap: 10px; margin-top: 12px; }
.learn-note  {
  display: flex; gap: 16px; align-items: baseline;
  background: var(--bg3); border-left: 3px solid var(--accent);
  padding: 10px 16px; border-radius: 0 6px 6px 0;
}
.learn-tool  {
  font-family: var(--font-mono); font-size: 12px;
  color: var(--accent); min-width: 140px; flex-shrink: 0;
}
.learn-text  { font-size: 13px; color: var(--text); }
.dim-note    { color: var(--dim); font-size: 12px; margin-top: 4px; }
.right       { text-align: right; }
"""


# ─────────────────────────────────────────────────────────────────────────────
# Main generator
# ─────────────────────────────────────────────────────────────────────────────

def generate_stage14_sections(
    tool_list:       list[str],
    tasks:           list[dict],   # [{tool_class, status, duration_s, finding_count, error}]
    findings_ctx:    dict,
) -> str:
    """
    Return an HTML string with all Stage 14 report sections.
    Inject into existing report HTML before </body>.
    """
    step_statuses = {t.get("tool_class", ""): t.get("status", "pending") for t in tasks}

    return "\n".join([
        _render_workflow_diagram(tool_list, step_statuses),
        _render_tool_path_table(tasks),
        _render_timeline(tasks),
        _render_learning_notes(tool_list, findings_ctx),
    ])


def inject_into_report(html_path: str, tool_list: list[str],
                       tasks: list[dict], findings_ctx: dict) -> bool:
    """
    Inject Stage 14 sections into an existing report HTML file in-place.
    Returns True on success.
    """
    path = Path(html_path)
    if not path.exists():
        return False

    content = path.read_text(encoding="utf-8")
    sections = generate_stage14_sections(tool_list, tasks, findings_ctx)

    # Add CSS
    css_tag = f"<style>\n{STAGE14_CSS}\n</style>"
    if css_tag not in content:
        content = content.replace("</head>", f"{css_tag}\n</head>", 1)

    # Inject sections before </body>
    content = content.replace("</body>", f"{sections}\n</body>", 1)
    path.write_text(content, encoding="utf-8")
    return True
