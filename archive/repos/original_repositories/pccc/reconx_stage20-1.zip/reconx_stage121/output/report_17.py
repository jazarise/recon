"""
ReconX — Stage 17 Report Extension: Infrastructure Intelligence Section.

Injects a rich infrastructure intelligence section into HTML reports.
Reads from result.raw["intelligence"] populated by the Stage 17
ExecutionEngine pipeline.

Sections added to the report:
  1. Infrastructure Summary   — correlated asset counts + CDN notice
  2. Asset Relationship Tree  — host → IP → service → tech hierarchy (CSS tree)
  3. Infrastructure Tags      — tagged assets grouped by tag category
  4. Asset Relationships      — shared IP, TLS match, banner, subdomain clusters
  5. Banner Intelligence      — parsed software versions + risk flags
  6. Service Learning         — high-risk services with educational context

Usage:
    from reconx.output.report_17 import inject_intelligence_section

    inject_intelligence_section(
        html_path = "reports/reconx_example_com.html",
        intel     = result.raw.get("intelligence", {}),
        target    = result.target,
    )
"""
from __future__ import annotations

from html import escape
from pathlib import Path
from typing import Optional


# ─────────────────────────────────────────────────────────────────────────────
# CSS
# ─────────────────────────────────────────────────────────────────────────────

_INTEL_CSS = """
/* ── Stage 17 Infrastructure Intelligence ───────── */
.intel-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(130px, 1fr));
  gap: 14px; margin: 20px 0 28px;
}
.intel-card {
  background: var(--bg2); border: 1px solid var(--border);
  border-radius: 8px; padding: 16px 12px; text-align: center;
  transition: border-color .2s;
}
.intel-card:hover { border-color: var(--accent); }
.intel-card .ic-number {
  font-size: 30px; font-weight: 700;
  font-family: var(--font-mono); line-height: 1; margin-bottom: 4px;
}
.intel-card .ic-label {
  font-size: 10px; letter-spacing: 2px;
  text-transform: uppercase; color: var(--dim);
}
/* Asset tree */
.asset-tree { font-family: var(--font-mono); font-size: 12.5px; line-height: 1.9; }
.asset-tree ul { list-style: none; padding-left: 20px; border-left: 1px solid rgba(0,212,255,.15); }
.asset-tree li { position: relative; }
.asset-tree li::before {
  content: "└─ "; color: rgba(0,212,255,.4);
  position: absolute; left: -20px;
}
.node-host { color: var(--accent); font-weight: 600; }
.node-ip   { color: #ffd60a; }
.node-svc  { color: var(--text); }
.node-tech { color: #30d158; }
.node-cdn  { color: var(--accent); }
/* Tags */
.tag-pill {
  display: inline-block; font-size: 10px; font-weight: 700;
  letter-spacing: 1.5px; padding: 2px 7px; border-radius: 4px;
  text-transform: uppercase; margin: 2px;
}
.tag-CRITICAL { background:rgba(255,45,85,.2);  color:#ff2d55; border:1px solid rgba(255,45,85,.4); }
.tag-EXPOSED  { background:rgba(255,107,53,.2); color:#ff6b35; border:1px solid rgba(255,107,53,.4); }
.tag-ADMIN    { background:rgba(255,45,85,.15); color:#ff4466; border:1px solid rgba(255,45,85,.3); }
.tag-DATABASE { background:rgba(255,45,85,.15); color:#ff4466; border:1px solid rgba(255,45,85,.3); }
.tag-RDP      { background:rgba(255,45,85,.2);  color:#ff2d55; border:1px solid rgba(255,45,85,.4); }
.tag-SMB      { background:rgba(255,45,85,.2);  color:#ff2d55; border:1px solid rgba(255,45,85,.4); }
.tag-DEVTOOLS { background:rgba(255,214,10,.15);color:#ffd60a; border:1px solid rgba(255,214,10,.3); }
.tag-LOGIN    { background:rgba(255,214,10,.15);color:#ffd60a; border:1px solid rgba(255,214,10,.3); }
.tag-API      { background:rgba(0,100,255,.15); color:#4d8bff; border:1px solid rgba(0,100,255,.3); }
.tag-VPN      { background:rgba(175,0,255,.15); color:#bf5fff; border:1px solid rgba(175,0,255,.3); }
.tag-CDN      { background:rgba(0,212,255,.1);  color:var(--accent); border:1px solid rgba(0,212,255,.3); }
.tag-MAIL     { background:rgba(200,200,200,.1);color:#c8c8c8; border:1px solid rgba(200,200,200,.2); }
.tag-K8S      { background:rgba(0,100,255,.15); color:#4d8bff; border:1px solid rgba(0,100,255,.3); }
.tag-LEGACY   { background:rgba(255,150,0,.15); color:#ff9900; border:1px solid rgba(255,150,0,.3); }
.tag-TLS-WEAK { background:rgba(255,214,10,.15);color:#ffd60a; border:1px solid rgba(255,214,10,.3); }
.tag-TAKEOVER { background:rgba(255,45,85,.2);  color:#ff2d55; border:1px solid rgba(255,45,85,.4); }
.tag-SSH      { background:rgba(48,209,88,.1);  color:#30d158; border:1px solid rgba(48,209,88,.3); }
.tag-FTP      { background:rgba(255,214,10,.1); color:#ffd60a; border:1px solid rgba(255,214,10,.2); }
/* Relationships */
.rel-group {
  background: var(--bg3); border: 1px solid var(--border);
  border-radius: 6px; padding: 12px 16px; margin-bottom: 10px;
}
.rel-group .rel-title {
  font-size: 12px; font-weight: 600; color: var(--accent);
  letter-spacing: 1px; margin-bottom: 6px;
}
.rel-group .rel-conf { color: var(--dim); font-size: 11px; margin-left: 8px; }
.rel-group .rel-members {
  font-family: var(--font-mono); font-size: 11.5px;
  color: var(--text); margin-top: 4px;
}
/* Banner risk */
.banner-risk-HIGH     { color: #ff6b35; }
.banner-risk-CRITICAL { color: #ff2d55; font-weight: 600; }
.banner-risk-MEDIUM   { color: #ffd60a; }
/* Service learning card */
.svc-learn-card {
  background: var(--bg3); border: 1px solid var(--border);
  border-left: 3px solid var(--accent); border-radius: 0 6px 6px 0;
  padding: 16px 20px; margin-bottom: 12px;
}
.svc-learn-card .svc-name { color: var(--accent); font-weight: 700; font-size: 14px; }
.svc-learn-card .svc-risk-CRITICAL { color: #ff2d55; font-weight: 700; }
.svc-learn-card .svc-risk-HIGH     { color: #ff6b35; font-weight: 600; }
.svc-learn-card ul { margin: 6px 0 0 16px; padding: 0; font-size: 12.5px; }
.svc-learn-card li { margin-bottom: 3px; }
.svc-learn-card .cmd-block {
  background: var(--bg2); border: 1px solid var(--border);
  border-radius: 4px; padding: 8px 12px; margin-top: 8px;
  font-family: var(--font-mono); font-size: 11.5px; color: #30d158;
}
"""


# ─────────────────────────────────────────────────────────────────────────────
# Section renderers
# ─────────────────────────────────────────────────────────────────────────────

def _render_summary_cards(intel: dict) -> str:
    corr = intel.get("correlation", {})
    rels = intel.get("relationships", {})
    tags = intel.get("tags", {})
    ban  = intel.get("banner_summary", {})

    node_count    = corr.get("node_count", 0)
    edge_count    = corr.get("edge_count", 0)
    group_count   = rels.get("total_groups", 0)
    identified    = ban.get("identified", 0)
    critical_tags = tags.get("critical", 0)
    cdn           = corr.get("cdn_detected", [])
    cdn_str       = ", ".join(cdn) if cdn else "None"

    critical_style = "color:#ff2d55" if critical_tags else ""

    return f"""
<div class="intel-grid">
  <div class="intel-card">
    <div class="ic-number" style="color:var(--accent)">{node_count}</div>
    <div class="ic-label">Correlated Nodes</div>
  </div>
  <div class="intel-card">
    <div class="ic-number" style="color:#ffd60a">{edge_count}</div>
    <div class="ic-label">Relationships</div>
  </div>
  <div class="intel-card">
    <div class="ic-number" style="color:#bf5fff">{group_count}</div>
    <div class="ic-label">Asset Groups</div>
  </div>
  <div class="intel-card">
    <div class="ic-number" style="color:#30d158">{identified}</div>
    <div class="ic-label">IDs from Banners</div>
  </div>
  <div class="intel-card">
    <div class="ic-number" style="{critical_style or 'color:var(--dim)'}">
      {critical_tags}
    </div>
    <div class="ic-label">Critical Tags</div>
  </div>
  <div class="intel-card" style="grid-column:span 2">
    <div class="ic-number" style="font-size:14px;color:var(--accent)">{escape(cdn_str)}</div>
    <div class="ic-label">CDN / WAF Detected</div>
  </div>
</div>"""


def _render_asset_tree(intel: dict) -> str:
    corr  = intel.get("correlation", {})
    nodes = corr.get("nodes", [])
    if not nodes:
        return ""

    root = next((n for n in nodes if n.get("type") == "host"), None)
    if not root:
        root = nodes[0]

    def _node_html(node: dict, depth: int = 0) -> str:
        ntype   = node.get("type", "")
        label   = escape(node.get("label", "?"))
        risk    = node.get("risk", "")
        tags    = node.get("tags", [])
        children = node.get("children", [])

        cls_map = {
            "host": "node-host", "ip": "node-ip",
            "service": "node-svc", "technology": "node-tech",
            "cdn": "node-cdn",
        }
        cls  = cls_map.get(ntype, "node-svc")
        risk_html = f' <span class="sev-{risk.lower()}" style="font-size:10px">[{risk}]</span>' if risk else ""
        tag_html  = "".join(
            f'<span class="tag-pill tag-{t}">{t}</span>'
            for t in tags if t not in ("root", "target", "ip", "infrastructure")
        )

        inner = f'<span class="{cls}">{label}</span>{risk_html} {tag_html}'
        if children:
            # For depth > 0 only render first 8 service children to keep HTML manageable
            child_limit = 8 if depth == 1 else 4
            child_html  = "".join(_node_html({"label": c}, depth + 1)
                                  for c in children[:child_limit])
            overflow    = ""
            if len(children) > child_limit:
                overflow = f'<li><span class="dim">… {len(children)-child_limit} more</span></li>'
            inner += f"<ul>{child_html}{overflow}</ul>"

        return f"<li>{inner}</li>"

    return f"""
<section class="report-section">
  <h2 class="section-title">🌐 Infrastructure Asset Tree</h2>
  <div class="asset-tree">
    <ul style="padding-left:0;border-left:none">
      {_node_html(root)}
    </ul>
  </div>
</section>"""


def _render_tags_section(intel: dict) -> str:
    tags_data = intel.get("tags", {})
    assets    = tags_data.get("assets", [])
    summary   = tags_data.get("tag_summary", {})
    if not assets:
        return ""

    warning = tags_data.get("warning")
    if warning:
        return f"""
<section class="report-section">
  <h2 class="section-title">🏷️ Infrastructure Tags</h2>
  <p class="dim">[WARNING] {escape(str(warning))}</p>
</section>"""

    # Tag summary pills
    summary_html = "".join(
        f'<span class="tag-pill tag-{escape(tag)}">{escape(tag)} '
        f'<strong>{count}</strong></span>'
        for tag, count in list(summary.items())[:16]
    )

    # Critical + exposed assets table
    high_risk = [
        a for a in assets
        if any(t in ("CRITICAL", "EXPOSED", "ADMIN", "DATABASE", "SMB", "RDP")
               for t in a.get("tags", []))
    ]
    rows = "".join(
        f"""<tr>
          <td class="mono">{escape(a.get("label","?")[:50])}</td>
          <td>{" ".join(f'<span class="tag-pill tag-{t}">{t}</span>'
                        for t in a.get("tags",[])[:6])}</td>
          <td class="dim">{escape(a.get("asset_type",""))}</td>
        </tr>"""
        for a in high_risk[:20]
    )
    overflow = (
        f'<tr><td colspan="3" class="dim">… {len(high_risk)-20} more high-risk assets</td></tr>'
        if len(high_risk) > 20 else ""
    )

    return f"""
<section class="report-section">
  <h2 class="section-title">🏷️ Infrastructure Tags</h2>
  <div style="margin-bottom:16px">{summary_html}</div>
  {f'''<table class="data-table">
    <thead><tr><th>Asset</th><th>Tags</th><th>Type</th></tr></thead>
    <tbody>{rows}{overflow}</tbody>
  </table>''' if rows else '<p class="dim">No high-risk tagged assets.</p>'}
</section>"""


def _render_relationships_section(intel: dict) -> str:
    rels = intel.get("relationships", {})
    if not rels or rels.get("warning"):
        warn = rels.get("warning", "")
        return f"""
<section class="report-section">
  <h2 class="section-title">🔗 Asset Relationships</h2>
  <p class="dim">{'[WARNING] ' + escape(str(warn)) if warn else 'No relationships detected.'}</p>
</section>""" if rels else ""

    sections = [
        ("Shared IP / Infrastructure",  rels.get("shared_ip_groups", []),   "#ffd60a"),
        ("TLS Certificate Match",        rels.get("tls_match_groups", []),   "var(--accent)"),
        ("Shared Server Banner",         rels.get("banner_match_groups", []),"#c8c8c8"),
        ("Technology Overlap",           rels.get("tech_overlap_groups", []),"#30d158"),
        ("Subdomain Clusters",           rels.get("subdomain_clusters", []), "#bf5fff"),
    ]

    groups_html = ""
    for section_title, groups, colour in sections:
        if not groups:
            continue
        groups_html += f'<h3 style="color:{colour};font-size:12px;letter-spacing:2px;text-transform:uppercase;margin:16px 0 8px">{escape(section_title)}</h3>'
        for grp in groups[:6]:
            members_str = escape(", ".join(grp.get("members", [])[:5]))
            overflow    = f" +{len(grp.get('members',[]))-5}" if len(grp.get("members",[])) > 5 else ""
            conf_pct    = f"{grp.get('confidence', 0):.0%}"
            evidence    = escape(". ".join(grp.get("evidence", [])[:2]))
            groups_html += f"""
<div class="rel-group">
  <div class="rel-title">{escape(grp.get("relationship","?"))}<span class="rel-conf">{conf_pct} confidence</span></div>
  <div class="rel-members">{members_str}{overflow}</div>
  {f'<div class="dim" style="font-size:11px;margin-top:4px">{evidence}</div>' if evidence else ""}
</div>"""
        if len(groups) > 6:
            groups_html += f'<p class="dim">… {len(groups)-6} more groups</p>'

    if not groups_html:
        groups_html = '<p class="dim">No significant asset relationships detected.</p>'

    total = rels.get("total_groups", 0)
    return f"""
<section class="report-section">
  <h2 class="section-title">🔗 Asset Relationships  <span style="font-size:12px;color:var(--dim)">{total} groups</span></h2>
  {groups_html}
</section>"""


def _render_banner_section(intel: dict) -> str:
    banners = intel.get("banner_analysis", [])
    if not banners:
        return ""

    risky   = [b for b in banners if b.get("risk_level")]
    ident   = [b for b in banners if b.get("software") != "unknown"]
    summary = intel.get("banner_summary", {})

    sw_counts = summary.get("software_counts", {})
    sw_pills  = "".join(
        f'<span class="tag-pill" style="background:rgba(0,212,255,.08);'
        f'color:var(--accent);border:1px solid rgba(0,212,255,.2)">'
        f'{escape(sw)} ×{cnt}</span>'
        for sw, cnt in list(sw_counts.items())[:12]
    )

    risk_rows = "".join(
        f"""<tr>
          <td class="mono">:{b.get("port","?")}</td>
          <td class="mono">{escape(b.get("software","?"))}</td>
          <td class="mono">{escape(b.get("version","—")[:20])}</td>
          <td><span class="banner-risk-{b.get('risk_level','')}">{escape(b.get("risk_level",""))}</span></td>
          <td class="dim" style="font-size:11px">{escape(b.get("risk_reason","")[:80])}</td>
        </tr>"""
        for b in risky[:12]
    )

    return f"""
<section class="report-section">
  <h2 class="section-title">📡 Banner Intelligence</h2>
  <p class="dim" style="margin-bottom:12px">
    {len(ident)} services identified from {len(banners)} banners.
    {len(risky)} carry version-based risk flags.
  </p>
  <div style="margin-bottom:16px">{sw_pills}</div>
  {f'''<table class="data-table">
    <thead><tr><th>Port</th><th>Software</th><th>Version</th><th>Risk</th><th>Reason</th></tr></thead>
    <tbody>{risk_rows}</tbody>
  </table>''' if risk_rows else '<p class="dim">No version-based risks identified from banners.</p>'}
</section>"""


def _render_service_learning_section(intel: dict, target: str) -> str:
    """Service learning cards for high-risk ports found in correlation data."""
    corr  = intel.get("correlation", {})
    p_app = corr.get("port_to_app", {})
    if not p_app:
        return ""

    try:
        from ..analysis.service_learning import ServiceLearning
        sl = ServiceLearning()
    except ImportError:
        try:
            import sys, os
            sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
            from analysis.service_learning import ServiceLearning
            sl = ServiceLearning()
        except Exception:
            return ""

    cards_html = ""
    seen: set[str] = set()

    for port_str, _app in p_app.items():
        try:
            port = int(port_str)
        except ValueError:
            continue
        ctx = sl.get_context(port=port)
        if not ctx or ctx.risk_level not in ("HIGH", "CRITICAL"):
            continue
        if ctx.service_name in seen:
            continue
        seen.add(ctx.service_name)

        risk_cls  = f"svc-risk-{ctx.risk_level}"
        risks_html = "".join(f"<li>{escape(r)}</li>" for r in ctx.typical_risks[:4])
        tools_html = "".join(
            f"<li><code>{escape(t)}</code></li>" for t in ctx.next_tools[:3]
        )
        cmds_html  = "".join(
            f"<div>$ {escape(c.replace('TARGET', target))}</div>"
            for c in ctx.commands[:2]
        )

        cards_html += f"""
<div class="svc-learn-card">
  <div>
    <span class="svc-name">{escape(ctx.service_name)}</span>
    {"&nbsp;&nbsp;" + f'<span class="{risk_cls}">■ {ctx.risk_level}</span>' if ctx.risk_level else ""}
  </div>
  <p style="font-size:12.5px;color:var(--text);margin:6px 0 10px">{escape(ctx.description)}</p>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;font-size:12px">
    <div>
      <div style="color:var(--dim);text-transform:uppercase;letter-spacing:1px;font-size:10px;margin-bottom:4px">Typical Risks</div>
      <ul>{risks_html}</ul>
    </div>
    <div>
      <div style="color:var(--dim);text-transform:uppercase;letter-spacing:1px;font-size:10px;margin-bottom:4px">Next Tools</div>
      <ul>{tools_html}</ul>
    </div>
  </div>
  {f'<div class="cmd-block">{cmds_html}</div>' if cmds_html else ""}
</div>"""

    if not cards_html:
        return ""

    return f"""
<section class="report-section">
  <h2 class="section-title">📚 Service Intelligence</h2>
  <p class="dim" style="margin-bottom:16px">
    Security context and remediation guidance for high-risk services.
  </p>
  {cards_html}
</section>"""


# ─────────────────────────────────────────────────────────────────────────────
# Public API
# ─────────────────────────────────────────────────────────────────────────────

def inject_intelligence_section(
    html_path: str,
    intel:     dict,
    target:    str = "",
) -> bool:
    """
    Inject the Stage 17 infrastructure intelligence section into a report.

    Args:
        html_path: Path to the HTML report file to update.
        intel:     The result.raw["intelligence"] dict from ExecutionEngine.
        target:    Target hostname / IP (used in command substitution).

    Returns True on success, False if file not found or all sections empty.
    """
    p = Path(html_path)
    if not p.exists():
        return False

    content = p.read_text(encoding="utf-8")

    # Inject CSS once
    if "intel-grid" not in content:
        content = content.replace(
            "</head>",
            f"<style>{_INTEL_CSS}</style>\n</head>",
            1,
        )

    # Build all sections
    sections = [
        f"""
<section class="report-section" id="intelligence">
  <h2 class="section-title">⚡ Infrastructure Intelligence</h2>
  {_render_summary_cards(intel)}
</section>""",
        _render_asset_tree(intel),
        _render_tags_section(intel),
        _render_relationships_section(intel),
        _render_banner_section(intel),
        _render_service_learning_section(intel, target),
    ]

    full_block = "\n".join(s for s in sections if s.strip())
    if not full_block.strip():
        return False

    if "<!-- intelligence-section -->" in content:
        content = content.replace("<!-- intelligence-section -->", full_block, 1)
    elif "</body>" in content:
        content = content.replace("</body>", f"{full_block}\n</body>", 1)
    else:
        content += full_block

    p.write_text(content, encoding="utf-8")
    return True
