# ReconX — Stage 18.2 Changelog: Traffic Intelligence Layer

## Overview

Stage 18.2 adds packet-level network intelligence to ReconX using TShark,
PyShark, and Scapy-compatible data structures. ReconX does NOT embed
Wireshark GUI. Instead it uses tshark as a headless analysis engine and
PyShark as an optional Python-native supplement.

**Capability gained:** ReconX can now analyse PCAP/PCAPNG capture files or
capture live traffic from a network interface, extracting structured
intelligence: protocols, hosts, credentials (masked), DNS intelligence, TLS
fingerprints, and behavioural anomalies — all feeding into the same
intelligence pipeline as all other stages.

---

## New Files (12)

### `network/models.py` — Shared Data Models

All data structures shared across the Traffic Intelligence Layer.

| Model | Purpose |
|---|---|
| `Packet` | One captured frame (src/dst IP, port, protocol, payload) |
| `FlowRecord` | Reconstructed bidirectional TCP/UDP conversation |
| `ProtocolHit` | One detected protocol with confidence score |
| `CredentialHit` | Masked credential/token with tag and source context |
| `DNSEntry` | One DNS query/response with tunnel-suspect flags |
| `HTTPRecord` | One HTTP request/response pair with endpoint classification |
| `TLSRecord` | TLS session metadata (JA3, SNI, version, cert flags) |
| `AnomalyAlert` | One behavioural anomaly with severity and evidence |
| `TrafficSummary` | Aggregated session-level intelligence — top-level output |

**`CredentialHit` safety contract:**
- `.masked_value` always limited to first 4–8 chars + asterisks
- `.display()` returns safe string for TUI/report output
- Raw secrets are never stored in any field

**`TrafficSummary.to_dict()`** — fully JSON-serialisable, recursively serialises all nested dataclasses. `payload` bytes fields are always excluded.

---

### `network/tshark_engine.py` — TShark Subprocess Engine

Wraps the tshark CLI for PCAP analysis and live capture.

**Key methods:**

| Method | Purpose |
|---|---|
| `decode_pcap(path, filter, max)` | Full JSON decode via `-T json` |
| `extract_fields(path, fields, filter)` | Fast targeted field extraction via `-T fields` |
| `protocol_stats(path)` | Protocol packet/byte counts via `-qz io,phs` |
| `conversation_table(path, layer)` | Top talkers via `-qz conv,<layer>` |
| `extract_dns(path)` | DNS fields with `dns` display filter |
| `extract_http(path)` | HTTP fields with `http` display filter |
| `extract_tls_fields(path)` | TLS handshake fields (JA3, SNI, version) |
| `extract_credentials(path)` | Auth/cookie/FTP fields |
| `list_interfaces()` | Available capture interfaces via `-D` |
| `capture_burst(iface, dur, out)` | Live capture to temp PCAP |

No `shell=True`. All subprocess calls go through `run_subprocess()` with hard timeouts.

---

### `network/pcap_parser.py` — PCAP Analysis Pipeline

Top-level orchestrator that runs the full 9-step extraction pipeline:

```
PCAP file
   ↓ Step 1: Protocol statistics    (tshark -qz io,phs)
   ↓ Step 2: Conversation table     (tshark -qz conv,ip)
   ↓ Step 3: DNS extraction         (tshark -T fields, filter=dns)
   ↓ Step 4: HTTP extraction        (tshark -T fields, filter=http)
   ↓ Step 5: TLS fingerprinting     (tshark -T fields, filter=tls)
   ↓ Step 6: Credential detection   (tshark -T fields + CredentialDetector)
   ↓ Step 7: Anomaly analysis       (AnomalyEngine on populated TrafficSummary)
   ↓ Step 8: Packet count           (from protocol stats)
   ↓ Step 9: Derived statistics     (pkt/s, deduplication)
   ↓
TrafficSummary
```

Each step is independently try-caught — partial failures never stop the pipeline.

---

### `network/protocol_detector.py` — Protocol Detection Engine

Detects 19 application-layer protocols with confidence scores.

**Three detection methods:**
1. `from_stats(proto_stats)` — from tshark statistics dict (primary)
2. `from_port(dst_port, src_port, proto)` — port-based heuristics
3. `from_payload(payload, src_port, dst_port)` — payload signature matching

**Protocol catalogue (19 protocols):**
HTTP, HTTPS/TLS, DNS, FTP, FTP-DATA, SSH, SMTP, POP3, IMAP, LDAP, SMB,
RDP, Kerberos, MQTT, WebSocket, SNMP, NTP, DHCP, HTTP/2, gRPC

**Example confidence scores:**
- DNS on port 53 → **100%**
- HTTP on port 80 → **98%**
- HTTPS/TLS on port 443 → **97%**
- WebSocket (port-based) → **80%**

---

### `network/credential_detector.py` — Credential Discovery Engine

Scans traffic for authentication artefacts with full masking.

**Detection patterns:**

| Tag | Pattern | Example |
|---|---|---|
| `JWT` | `eyJ...` three-part base64url | `eyJh****` |
| `BEARER` / `TOKEN` | `Bearer <value>` | `abcd****` |
| `API_KEY` | `x-api-key:`, `api-token:` | `MyS3****` |
| `BASIC_AUTH` | `Basic <base64>` — decoded | `admi****` |
| `SESSION` | `session=`, `auth=`, `sid=` cookies | `abc1****` |
| `CREDENTIAL` | FTP PASS, SMTP AUTH | `pa**` |

**Safety rules (unconditional):**
1. Raw values are never stored — only `.masked_value` (first 4–8 + `***`)
2. `.display()` never exposes full secrets
3. Deduplication prevents the same masked hit appearing twice
4. Passive only — reads captured traffic

---

### `network/dns_extractor.py` — DNS Intelligence Extractor

Parses DNS queries/responses and detects tunneling patterns.

**Extracted intelligence:**
- All queries and responses with record type (A, AAAA, CNAME, MX, TXT, etc.)
- Resolved IP addresses per hostname
- Unique base domains queried
- Subdomains by parent domain
- High-frequency domains (> 50 queries/session)

**DNS Tunneling Detection (3 signals):**

| Signal | Threshold | Reason |
|---|---|---|
| Long query name | > 50 chars | Encoded data in label |
| High label entropy | Shannon > 3.8 | Random-looking subdomain |
| High query frequency | > 100 to same base | C2/exfil via DNS |
| Hex-encoded label | ≥ 20 chars, ≥ 90% hex | Data encoding |

Allowlisted: `.local`, `.in-addr.arpa`, Microsoft, Apple, Google domains.

---

### `network/http_extractor.py` — HTTP Intelligence Extractor

Parses HTTP request/response pairs into `HTTPRecord` objects.

**Endpoint classification:**

| Property | Path pattern |
|---|---|
| `is_api` | `/api/`, `/v1/`, `/graphql`, `/rpc` |
| `is_auth` | `/login`, `/auth`, `/signin`, `/token`, `/oauth` |
| `is_admin` | `/admin`, `/console`, `/dashboard`, `/manage` |
| `is_upload` | `/upload`, `/file`, `multipart` in content-type |

**Helper methods:** `get_api_endpoints()`, `get_auth_routes()`, `get_admin_panels()`, `get_upload_endpoints()`, `get_top_hosts()`, `get_redirect_chains()`

---

### `network/tls_fingerprint.py` — TLS Fingerprinter

Parses TLS handshake rows into `TLSRecord` objects.

**Extracts:**
- JA3 client fingerprint hash
- JA3S server fingerprint hash
- SNI (Server Name Indication) — hostname intelligence
- TLS version with legacy flagging
- Cipher suite with weakness detection

**Risk flags:**

| Flag | Trigger | Severity |
|---|---|---|
| `is_legacy_tls` | SSLv3, TLS 1.0, TLS 1.1 | HIGH |
| `is_weak_cipher` | NULL, EXPORT, RC4, DES, 3DES, MD5, anon | MEDIUM |
| `is_expired` | cert `notAfter` < now | HIGH |
| `is_self_signed` | issuer == subject | MEDIUM |

TLS version normalisation: hex codes (`0x0303`) → human-readable (`TLSv1.2`).

---

### `network/anomaly_engine.py` — Behavioural Anomaly Engine

Detects six classes of network anomalies:

| Anomaly | Detection Method | Severity |
|---|---|---|
| **Beaconing** | Coefficient of variation ≤ 15% across ≥ 8 flows | HIGH |
| **High frequency** | > 50 connections to same dst:port | MEDIUM–HIGH |
| **Protocol misuse** | Known protocol on non-standard port | MEDIUM |
| **Exfil signal** | > 10 MB outbound to single external IP | HIGH |
| **Port scan signal** | Single src → > 20 unique dst ports on same host | MEDIUM |
| **DNS tunneling** | Promoted from `DNSExtractor` suspects | HIGH |

All detections produce `AnomalyAlert` with:
- `severity` (LOW/MEDIUM/HIGH/CRITICAL)
- `confidence` (0.0–1.0)
- `evidence` dict (thresholds, counts, sampled ports)

---

### `network/pyshark_engine.py` — PyShark Engine (Optional)

Python-native packet analysis using the `pyshark` library.

**Role:** supplement to TShark for deep payload inspection and live streams.

**Key methods:**
- `read_pcap(path, max)` — reads PCAP via pyshark, returns `list[Packet]`
- `deep_credential_scan(path)` — payload-level credential scanning
- `live_packet_stream(iface, max, timeout)` — yields `Packet` objects live
- `reconstruct_flows(packets)` — groups packets into `FlowRecord` objects

**Graceful degradation:** if `pyshark` is not installed, all methods return empty results with a clear message — never raises.

---

### `network/live_capture.py` — Live Capture Engine

Manages real-time capture sessions.

**Workflow:**
```
start(interface, duration_s)
   ↓ tshark capture_burst → temp PCAP
   ↓ PCAPParser.analyze(temp_pcap)
   ↓ summary.capture_iface / start_time set
   ↓ temp PCAP deleted
CaptureSession.summary populated
```

**`CaptureSession` states:** `idle → capturing → analyzing → complete / error`

**Auto-interface detection:** tries `eth0`, `en0`, `wlan0`, `ens33`, `ens3`, `enp0s3` in order, falls back to first non-loopback interface.

---

### `network/__init__.py` — `TrafficIntelligenceTool`

BaseTool orchestrator implementing the `BaseTool` interface.

| Field | Value |
|---|---|
| `NAME` | `"Traffic Intelligence"` |
| `BINARY` | `"tshark"` |
| `CATEGORY` | `"network_analysis"` |
| `STAGE` | `2` (alongside active scanning) |
| `PASSIVE` | `True` |

**Dual-mode `run(target)`:**
- `target` = file path → PCAP mode
- `target` = `"live:<iface>"` → Live capture mode

**`_to_findings(summary)`** converts `TrafficSummary` into `list[ParsedFinding]` covering: IPs, hostnames, domains, credential hits (masked), anomalies, TLS weaknesses.

---

### `network/report_injector.py` — HTML Report Injector

Injects a **Traffic Intelligence** section into any existing ReconX HTML report.

**7 sections injected:**
1. Capture status bar (source, packets, duration, pkt/s)
2. Stats row (9 stat cards)
3. Protocol Inventory table with confidence bars
4. Credential Findings table (masked values, severity badges)
5. DNS Intelligence table with tunnel-suspect flags
6. TLS Analysis table with risk indicators
7. Anomaly Timeline table sorted by severity
8. Top Talkers table

CSS is injected once (idempotent guard). Designed to match the ReconX dark cyberpunk theme.

---

### `tui/views/traffic_view.py` — `TrafficIntelligencePanel`

Rich-rendered TUI panel with full traffic intelligence display.

**Status bar icons:**

| State | Icon |
|---|---|
| capturing | `⚡ capturing` (bold cyan) |
| analyzing | `⚡ analyzing` (bold yellow) |
| complete  | `✓ complete`  (bold green) |
| error     | `✗ failed`    (bold red) |

**Panel sections:** Status bar → Stats row (9 cards) → Protocol Inventory → Top Talkers → Credentials → Anomalies → DNS Intelligence → TLS Analysis → Web Discovery grid

**Standalone helper:** `render_traffic_intelligence(console, summary, state, interface, duration_s)`

---

### `cli/traffic_commands.py` — CLI Command Dispatcher

Implements `reconx pcap` and `reconx traffic` subcommand groups.

```bash
reconx pcap analyze <file.pcap>                  # Full PCAP pipeline
reconx pcap analyze <file.pcap> --filter dns     # With display filter
reconx traffic live                              # Auto-detect interface, 30s
reconx traffic live --iface eth0                 # Specific interface
reconx traffic live --duration 60               # Custom duration
reconx traffic live --filter 'port 80'          # BPF filter
reconx traffic interfaces                        # List interfaces
reconx traffic status                            # Check tool availability
```

---

### `tools/registry_182.py` — Stage 18.2 Registry

Registers `TrafficIntelligenceTool` with the execution engine, TUI tool browser, and workflow builder.

**`get_stage182_catalog()`** — 14-field metadata entry with 12 capabilities:
`pcap_analysis`, `live_capture`, `protocol_detection`, `credential_discovery`,
`dns_intelligence`, `http_extraction`, `tls_fingerprinting`, `anomaly_detection`,
`beaconing_detection`, `dns_tunnel_detection`, `flow_reconstruction`, + more.

**`get_stage182_tool_chains()`** — two chain definitions:
- `network_intelligence` — Traffic Intelligence alongside active scanning
- `full_intelligence` — Traffic Intelligence + Burp Suite (18.1 + 18.2 together)

---

### `knowledge/network/tshark.yaml` — Learning Mode Entry

Complete YAML knowledge entry for Learning Mode.

Covers: description, 7 use cases, both capture modes, full extraction table, DNS tunneling detection thresholds, 5 common errors (permission denied, no interfaces, Npcap, libpcap, pyshark), recommended integrations (Burp, Scapy, Zeek), safety notes.

---

## Test Suite

### `tests/test_stage182_traffic.py` — 87 tests, 11 classes

**Results: 87/87 passing (0.17s)**

| Class | Tests |
|---|---|
| `TestModels` | 13 — dataclass fields, IP classification, masking, JSON serialisation |
| `TestTSharkEngine` | 8 — availability, file-not-found, protocol stats parse, field parse, JSON decode, interfaces |
| `TestProtocolDetector` | 10 — HTTP/DNS from stats, port 80/443, unknown port, HTTP payload, SSH payload, sort order |
| `TestCredentialDetector` | 9 — JWT, Bearer, API key, Basic Auth, masking, empty rows, FTP PASS, dedup |
| `TestDNSExtractor` | 8 — basic parse, multi-answer, tunnel long name, high-freq, allowlist, domains, IPs, subdomains |
| `TestHTTPExtractor` | 8 — parse, dedup, API/admin/auth/upload, get_api_endpoints, redirect chains |
| `TestTLSFingerprinter` | 8 — parse, version normalise, legacy flag, TLS 1.3 ok, dedup, SNIs, weak records, risk summary |
| `TestAnomalyEngine` | 7 — empty no crash, beaconing, no-beacon irregular, high-freq, protocol misuse, DNS tunnel, exfil |
| `TestPySharkEngine` | 5 — availability, read pcap graceful, deep scan graceful, reconstruct empty, install hint |
| `TestNetworkReportInjector` | 5 — inject true, adds section, missing file false, idempotent CSS, empty creds safe |
| `TestRegistry182` | 7 — catalog list, required fields, passive true, capabilities, tool chains, graceful load |

**Combined Stage 18 + 18.1 + 18.2: 164 + 87 = 251 tests, all passing.**

---

## Architecture

```
TrafficIntelligenceTool (BaseTool, STAGE=2, PASSIVE=True)
│
├── TSharkEngine         ← subprocess wrapper for tshark CLI
│     ├── decode_pcap()      → list[dict] (JSON packets)
│     ├── extract_fields()   → list[dict] (targeted fields)
│     ├── protocol_stats()   → {proto: {packets, bytes}}
│     ├── conversation_table() → list[dict] (top talkers)
│     ├── capture_burst()    → temp PCAP path
│     └── list_interfaces()  → list[{index, name}]
│
├── PySharkEngine (optional)
│     ├── read_pcap()         → list[Packet]
│     ├── deep_credential_scan() → list[CredentialHit]
│     ├── live_packet_stream()   → Iterator[Packet]
│     └── reconstruct_flows()    → list[FlowRecord]
│
├── PCAPParser           ← 9-step pipeline orchestrator
│     ├── protocol_stats → ProtocolDetector.from_stats()
│     ├── conv_table     → top_talkers
│     ├── extract_dns    → DNSExtractor.parse_rows()
│     ├── extract_http   → HTTPExtractor.parse_rows()
│     ├── extract_tls    → TLSFingerprinter.parse_rows()
│     ├── extract_creds  → CredentialDetector.scan_rows()
│     └── anomaly        → AnomalyEngine.analyze()
│         → TrafficSummary
│
├── ProtocolDetector     ← 19 protocols, 3 detection methods
├── CredentialDetector   ← JWT/Bearer/API-key/Basic/FTP/SMTP (all masked)
├── DNSExtractor         ← queries + tunnel detection
├── HTTPExtractor        ← HTTP records + endpoint classification
├── TLSFingerprinter     ← JA3 + version + cipher risks
├── AnomalyEngine        ← beaconing/high-freq/misuse/exfil/scan/DNS-tunnel
└── LiveCaptureEngine    ← tshark capture_burst → PCAPParser → CaptureSession

Supporting:
  network/report_injector.py    → HTML section injection
  tui/views/traffic_view.py      → Rich TUI panel
  cli/traffic_commands.py        → CLI dispatcher
  tools/registry_182.py         → tool + catalog + chain registration
  knowledge/network/tshark.yaml → Learning Mode entry
```

---

## Combined Full Changelog (Stages 18 → 18.1 → 18.2)

| Stage | Feature | Files |
|---|---|---|
| 18 | Burp Intelligence Layer core | 8 |
| 18 | TUI Web Intelligence panel | 1 |
| 18 | Burp CLI commands | 1 |
| 18 | Burp report injector | 1 |
| 18 | Burp registry + catalog | 1 |
| 18 | Burp knowledge YAML | 1 |
| 18 | Stage 18 Burp tests (77) | 1 |
| 18.2 | Traffic Intelligence models | 1 |
| 18.2 | TShark engine | 1 |
| 18.2 | PCAP pipeline | 1 |
| 18.2 | Protocol detector | 1 |
| 18.2 | Credential detector | 1 |
| 18.2 | DNS extractor | 1 |
| 18.2 | HTTP extractor | 1 |
| 18.2 | TLS fingerprinter | 1 |
| 18.2 | Anomaly engine | 1 |
| 18.2 | PyShark engine | 1 |
| 18.2 | Live capture engine | 1 |
| 18.2 | Traffic tool + __init__ | 1 |
| 18.2 | Traffic report injector | 1 |
| 18.2 | Traffic TUI panel | 1 |
| 18.2 | Traffic CLI commands | 1 |
| 18.2 | Traffic registry + catalog | 1 |
| 18.2 | Traffic knowledge YAML | 1 |
| 18.2 | Stage 18.2 tests (87) | 1 |
| **Total** | **251 tests, 0 failures** | **27 new files** |

---

## Safety Contract

| Rule | Implementation |
|---|---|
| Passive analysis only | No packets sent; tshark reads only |
| Credentials always masked | `CredentialHit.mask()` enforced in all code paths |
| Tool failures non-fatal | Every pipeline step independently try-caught |
| BaseTool compatible | `run(target)` signature identical to all tools |
| Plugin compatible | Registers via `registry_182.py` merge pattern |
| Zero breaking changes | No existing files modified in 18.2 |
| TShark-unavailable graceful | Returns `ToolRunResult.skipped()` not exception |
| Temp files cleaned up | `LiveCaptureEngine._cleanup()` removes temp PCAPs |
