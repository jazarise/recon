"""
ReconX — Central configuration and scan profiles.
"""
from __future__ import annotations
from dataclasses import dataclass, field


# ── Scan Profiles ────────────────────────────────────────────────────────────

PROFILES: dict[str, dict] = {
    "fast": {
        "port_range": "1-1000",
        "masscan_rate": 5000,
        "threads": 50,
        "timeout": 3,
        "subdomain_tools": ["subfinder"],
        "web_analysis": False,
        "amass_passive": False,
    },
    "balanced": {
        "port_range": "1-10000",
        "masscan_rate": 2000,
        "threads": 80,
        "timeout": 5,
        "subdomain_tools": ["subfinder"],
        "web_analysis": True,
        "amass_passive": False,
    },
    "deep": {
        "port_range": "1-65535",
        "masscan_rate": 1000,
        "threads": 100,
        "timeout": 8,
        "subdomain_tools": ["subfinder", "amass"],
        "web_analysis": True,
        "amass_passive": True,
    },
}


# ── Tool Paths (override via env var RECONX_TOOL_<NAME>) ────────────────────

TOOL_PATHS: dict[str, str] = {
    "nmap": "nmap",
    "masscan": "masscan",
    "subfinder": "subfinder",
    "amass": "amass",
    "httpx": "httpx",
    "whatweb": "whatweb",
    "whois": "whois",
}


# ── Sensitive Pattern Rules ──────────────────────────────────────────────────

SENSITIVE_PATTERNS: list[dict] = [
    # Exposed config / secrets
    {"pattern": r"\.env$",            "category": "exposed_config",   "severity": "CRITICAL", "detail": "Exposed .env file"},
    {"pattern": r"\.git/config$",     "category": "exposed_config",   "severity": "HIGH",     "detail": "Exposed Git config"},
    {"pattern": r"config\.json$",     "category": "exposed_config",   "severity": "HIGH",     "detail": "Exposed config.json"},
    {"pattern": r"wp-config\.php$",   "category": "exposed_config",   "severity": "CRITICAL", "detail": "Exposed WordPress config"},
    {"pattern": r"backup\.(zip|tar|sql|gz)$", "category": "backup_exposed", "severity": "CRITICAL", "detail": "Exposed backup file"},

    # Debug / admin endpoints
    {"pattern": r"/debug$",           "category": "debug_endpoint",   "severity": "HIGH",     "detail": "Debug endpoint exposed"},
    {"pattern": r"/admin$",           "category": "admin_panel",      "severity": "MEDIUM",   "detail": "Admin panel exposed"},
    {"pattern": r"/phpinfo\.php$",    "category": "debug_endpoint",   "severity": "HIGH",     "detail": "phpinfo() exposed"},
    {"pattern": r"/_profiler",        "category": "debug_endpoint",   "severity": "HIGH",     "detail": "Symfony profiler exposed"},

    # Storage / listing
    {"pattern": r"s3\.amazonaws\.com", "category": "cloud_storage",   "severity": "MEDIUM",   "detail": "S3 bucket reference"},
    {"pattern": r"storage\.googleapis\.com", "category": "cloud_storage", "severity": "MEDIUM", "detail": "GCS bucket reference"},
]


# ── Suggestion Rules ─────────────────────────────────────────────────────────
# Maps finding context → educational suggestion

SUGGESTION_RULES: list[dict] = [
    {
        "trigger": "port:22",
        "risk": "SSH service exposed",
        "recommendation": "Ensure key-based auth only; disable password login; consider port knocking.",
        "severity": "MEDIUM",
    },
    {
        "trigger": "port:21",
        "risk": "FTP service exposed (plaintext)",
        "recommendation": "Replace with SFTP/FTPS; ensure anonymous login is disabled.",
        "severity": "HIGH",
    },
    {
        "trigger": "port:3306",
        "risk": "MySQL exposed to network",
        "recommendation": "Bind to 127.0.0.1; use a firewall rule to restrict access.",
        "severity": "CRITICAL",
    },
    {
        "trigger": "port:6379",
        "risk": "Redis exposed (no auth by default)",
        "recommendation": "Bind Redis to localhost; enable AUTH; never expose publicly.",
        "severity": "CRITICAL",
    },
    {
        "trigger": "port:27017",
        "risk": "MongoDB potentially exposed",
        "recommendation": "Enable auth; bind to internal IP; restrict network access.",
        "severity": "CRITICAL",
    },
    {
        "trigger": "port:445",
        "risk": "SMB exposed (ransomware vector)",
        "recommendation": "Disable SMBv1; block port 445 on perimeter; apply MS17-010 patches.",
        "severity": "CRITICAL",
    },
    {
        "trigger": "port:3389",
        "risk": "RDP exposed to internet",
        "recommendation": "Place behind VPN; enable NLA; use MFA; restrict by IP.",
        "severity": "CRITICAL",
    },
    {
        "trigger": "port:5432",
        "risk": "PostgreSQL potentially exposed",
        "recommendation": "Restrict pg_hba.conf; bind to loopback; use firewall.",
        "severity": "HIGH",
    },
    {
        "trigger": "port:8080",
        "risk": "Alternative HTTP port open",
        "recommendation": "Investigate if staging/dev service; ensure it requires auth.",
        "severity": "LOW",
    },
    {
        "trigger": "dns:MX",
        "risk": "Mail server identified",
        "recommendation": "Verify SPF, DKIM, and DMARC records; check for open relay.",
        "severity": "LOW",
    },
    {
        "trigger": "subdomain_count_high",
        "risk": "Large attack surface via subdomains",
        "recommendation": "Audit each subdomain; retire unused ones; check for subdomain takeover.",
        "severity": "MEDIUM",
    },
    {
        "trigger": "exposed_config",
        "risk": "Sensitive configuration file accessible",
        "recommendation": "Remove immediately; rotate any exposed credentials; audit server config.",
        "severity": "CRITICAL",
    },
    {
        "trigger": "port:80",
        "risk": "HTTP (unencrypted) service active",
        "recommendation": "Redirect all HTTP to HTTPS; enforce HSTS.",
        "severity": "LOW",
    },
]


# ══════════════════════════════════════════════════════════════════════════════
#  Scheduler / Execution Control
# ══════════════════════════════════════════════════════════════════════════════

SCHEDULER_DEFAULTS: dict = {
    "batch_size":    8,        # tools per parallel batch
    "thread_count":  10,       # max worker threads per batch
    "timeout":       90,       # seconds per tool
    "retry_limit":   1,        # retries on non-timeout failures
    "inter_batch_delay": 0.3,  # seconds pause between batches
}

# Per-mode overrides (merged with SCHEDULER_DEFAULTS at runtime)
SCHEDULER_MODE_OVERRIDES: dict[str, dict] = {
    "fast": {
        "batch_size":   6,
        "timeout":      45,
        "retry_limit":  0,
    },
    "balanced": {
        "batch_size":   8,
        "timeout":      90,
        "retry_limit":  1,
    },
    "deep": {
        "batch_size":   10,
        "timeout":      180,
        "retry_limit":  2,
    },
}


# ══════════════════════════════════════════════════════════════════════════════
#  Passive Recon — API Keys & Timeouts
# ══════════════════════════════════════════════════════════════════════════════

PASSIVE_CONFIG: dict = {
    # API keys — set via env vars or edit here
    "chaos_api_key":       "",   # RECONX_CHAOS_KEY
    "shodan_api_key":      "",   # RECONX_SHODAN_KEY
    "virustotal_api_key":  "",   # RECONX_VT_KEY

    # Per-tool timeouts (seconds)
    "assetfinder_timeout": 60,
    "findomain_timeout":   90,
    "crtsh_timeout":       30,
    "chaos_timeout":       60,
    "gau_timeout":         120,
    "waybackurls_timeout": 120,

    # URL collection limits
    "gau_max_urls":        5000,
    "wayback_max_urls":    5000,

    # Passive pipeline batching
    "passive_batch_size":  3,
    "passive_threads":     6,
}

def get_passive_cfg(key: str, env_override: str = "") -> str:
    """Get passive config value; check env var first."""
    import os
    if env_override:
        val = os.environ.get(env_override, "")
        if val:
            return val
    return PASSIVE_CONFIG.get(key, "")


# ══════════════════════════════════════════════════════════════════════════════
#  DNS Intelligence Engine — Configuration
# ══════════════════════════════════════════════════════════════════════════════

DNS_CONFIG: dict = {
    # Resolver pools
    "public_resolvers": [
        "1.1.1.1", "1.0.0.1",           # Cloudflare
        "8.8.8.8", "8.8.4.4",           # Google
        "9.9.9.9", "149.112.112.112",   # Quad9
        "208.67.222.222", "208.67.220.220", # OpenDNS
        "64.6.64.6", "64.6.65.6",       # Verisign
    ],
    "custom_resolvers": [],              # user-supplied — set via env or CLI
    "resolver_file":    "",              # path to resolvers.txt

    # Resolution settings
    "dns_threads":        50,
    "dns_timeout":        3.0,           # seconds per query
    "dns_retries":        2,
    "dns_batch_size":     500,

    # Wildcard detection
    "wildcard_test_count":  3,           # random probes per domain
    "wildcard_threshold":   0.8,         # fraction of probes that must match to flag

    # Brute-force
    "wordlist_path":    "/usr/share/seclists/Discovery/DNS/subdomains-top1million-5000.txt",
    "wordlist_fallback": "",             # built-in mini wordlist if file missing
    "bruteforce_threads": 100,
    "bruteforce_timeout": 120,

    # Scoring
    "min_confidence": 0.5,              # below this → subdomain discarded

    # Tool-specific timeouts (seconds)
    "dnsx_timeout":        90,
    "shuffledns_timeout":  120,
    "massdns_timeout":     120,
    "puredns_timeout":     120,
}

# Tiny built-in wordlist used when no external wordlist exists
DNS_MINI_WORDLIST: list[str] = [
    "www", "mail", "ftp", "smtp", "pop", "imap", "webmail",
    "dev", "staging", "test", "api", "admin", "portal", "vpn",
    "remote", "secure", "cdn", "static", "assets", "media",
    "app", "apps", "beta", "alpha", "demo", "docs", "blog",
    "shop", "store", "m", "mobile", "ns1", "ns2", "mx",
    "autodiscover", "autoconfig", "cpanel", "whm", "panel",
    "git", "gitlab", "jenkins", "ci", "jira", "confluence",
    "grafana", "kibana", "monitor", "status", "health",
    "backup", "db", "database", "mysql", "redis", "elastic",
    "internal", "intranet", "corp", "cloud", "s3", "bucket",
]


# ══════════════════════════════════════════════════════════════════════════════
#  Scanning Engine — Configuration
# ══════════════════════════════════════════════════════════════════════════════

SCAN_CONFIG: dict = {
    # Port ranges
    "port_range_fast":     "1-1000",
    "port_range_balanced": "1-10000",
    "port_range_deep":     "1-65535",
    "top_ports":           1000,

    # Rates
    "naabu_rate":          1000,
    "rustscan_batch":      2500,
    "rustscan_timeout":    1500,   # ms per port
    "masscan_rate":        2000,

    # Threads / concurrency
    "scan_threads":        50,
    "nmap_timing":         4,      # T0–T5
    "nmap_version_intensity": 5,

    # Timeouts
    "naabu_timeout":       90,
    "rustscan_timeout_s":  120,
    "nmap_timeout":        300,

    # NSE script profiles
    "nse_profiles": {
        "default":  ["version", "default"],
        "safe":     ["safe"],
        "vuln":     ["vuln", "exploit"],
        "web":      ["http-title", "http-headers", "http-methods"],
        "smb":      ["smb-security-mode", "smb2-security-mode"],
    },

    # High-value ports for priority scanning
    "priority_ports": [
        21, 22, 23, 25, 53, 80, 110, 111, 135, 139,
        143, 443, 445, 465, 587, 993, 995, 1433, 1521,
        2049, 2375, 2376, 3000, 3306, 3389, 4443, 4848,
        5432, 5900, 5985, 5986, 6379, 7001, 8000, 8080,
        8443, 8888, 9000, 9090, 9200, 9300, 11211, 27017,
    ],

    # Service → risk level mapping
    "risky_services": {
        "telnet": "CRITICAL", "ftp": "HIGH", "smb": "CRITICAL",
        "rdp": "CRITICAL",    "redis": "CRITICAL", "mongodb": "CRITICAL",
        "elasticsearch": "HIGH", "memcached": "HIGH", "vnc": "HIGH",
        "mysql": "HIGH",      "mssql": "HIGH", "postgresql": "MEDIUM",
        "jenkins": "HIGH",    "grafana": "MEDIUM", "kubernetes": "HIGH",
        "docker": "CRITICAL", "etcd": "CRITICAL",
    },
}


# ══════════════════════════════════════════════════════════════════════════════
#  Web Reconnaissance — Configuration
# ══════════════════════════════════════════════════════════════════════════════

WEB_CONFIG: dict = {
    # Crawling
    "crawl_depth":          3,
    "crawl_concurrency":    10,
    "crawl_rate_limit":     150,          # requests/min
    "crawl_timeout":        10,           # seconds per request
    "crawl_max_urls":       5000,
    "crawl_extensions_skip": [
        "png","jpg","jpeg","gif","svg","ico","woff","woff2",
        "ttf","eot","mp4","mp3","pdf","zip","gz","tar",
    ],
    "crawl_scope":          "fqdn",       # "fqdn" | "rdn" | "dn" | "url"

    # Fuzzing / content discovery
    "ffuf_threads":         50,
    "ffuf_rate":            0,            # 0 = unlimited
    "gobuster_threads":     50,
    "dirsearch_threads":    30,
    "fuzz_timeout":         10,           # seconds per request
    "fuzz_match_codes":     [200, 204, 301, 302, 307, 401, 403, 405],
    "fuzz_filter_size":     "",           # response size to filter
    "fuzz_recursive":       True,
    "fuzz_recursion_depth": 2,

    # Wordlists
    "wordlist_dir":    "wordlist_medium",
    "wordlist_small":  "/usr/share/seclists/Discovery/Web-Content/common.txt",
    "wordlist_medium": "/usr/share/seclists/Discovery/Web-Content/directory-list-2.3-medium.txt",
    "wordlist_large":  "/usr/share/seclists/Discovery/Web-Content/directory-list-2.3-big.txt",
    "wordlist_api":    "/usr/share/seclists/Discovery/Web-Content/api/api-endpoints.txt",

    # Extensions to fuzz
    "extensions_web":   ["php","asp","aspx","jsp","html","txt","xml","json","bak","old"],
    "extensions_common":["php","html","txt","js","json"],

    # JavaScript analysis
    "js_max_size_kb":       500,          # skip JS files larger than this
    "js_secret_min_length": 20,

    # Endpoint classification
    "admin_paths":    ["admin","administrator","wp-admin","panel","dashboard","control","manage"],
    "api_indicators": ["api","v1","v2","v3","graphql","rest","swagger","openapi","json","xml"],
    "debug_paths":    ["debug","phpinfo","test","dev","staging","console","actuator","metrics","health"],
    "upload_paths":   ["upload","uploads","file","files","attachment","media","import"],

    # Tool timeouts
    "katana_timeout":     120,
    "hakrawler_timeout":  60,
    "ffuf_timeout":       300,
    "gobuster_timeout":   300,
    "dirsearch_timeout":  300,
}

# Built-in mini wordlist (used when no wordlist file exists)
WEB_MINI_WORDLIST: list[str] = [
    "admin","login","dashboard","api","v1","v2","v3","upload","uploads",
    "backup","backup.zip","backup.sql","config","config.php",".env",
    "wp-admin","phpmyadmin","adminer","panel","control","manage",
    "debug","phpinfo","test","dev","staging","console","actuator","health",
    "metrics","status","info","about","contact","register","signup",
    "logout","profile","account","settings","security","password","reset",
    "forgot","user","users","admin/users","static","assets","media","files",
    "file","download","export","import","api/v1","api/v2","graphql",
    "swagger","openapi","docs","documentation","wiki","internal","private",
    "secret","hidden","old","archive","bak","tmp","temp","cache",
]


# ─────────────────────────────────────────────────────────────────────────────
# Stage 8 — Vulnerability Detection & Exposure Analysis Configuration
# ─────────────────────────────────────────────────────────────────────────────

VULN_CONFIG: dict = {

    # ── Nuclei ────────────────────────────────────────────────────────────────
    "nuclei": {
        # Severities scanned by default
        "default_severities": ["critical", "high", "medium"],

        # HTTP request rate limit (requests per minute)
        "rate_limit": 150,

        # Parallel template execution concurrency
        "concurrency": 25,

        # Retry failed requests
        "retries": 1,

        # Per-request timeout in seconds
        "timeout_per_req": 10,

        # Auto-update templates on each run (slow, do manually instead)
        "auto_update_templates": False,

        # Scan profiles: profile_name → {severities, tags, concurrency}
        "profiles": {
            "fast": {
                "severities":  ["critical", "high"],
                "tags":        ["cve", "exposure", "default-login"],
                "concurrency": 40,
                "rate_limit":  200,
            },
            "balanced": {
                "severities":  ["critical", "high", "medium"],
                "tags":        ["cve", "exposure", "default-login", "misconfiguration"],
                "concurrency": 25,
                "rate_limit":  150,
            },
            "deep": {
                "severities":  ["critical", "high", "medium", "low"],
                "tags":        [],      # empty = all templates
                "concurrency": 15,
                "rate_limit":  80,
            },
        },
    },

    # ── Nikto ─────────────────────────────────────────────────────────────────
    "nikto": {
        # Tuning categories (1-9 + letters, see nikto_tool.py for legend)
        # 1=interesting 2=misconfig 3=info 4=inject 5=RFR 7=RFR-wide 8=exec b=sw-id
        "tuning": "1234578b",

        # Maximum scan time (Nikto -maxtime format: 10m, 1h, etc.)
        "max_time": "10m",

        # Force SSL probe regardless of URL scheme
        "force_ssl": False,
    },

    # ── False Positive Filter ─────────────────────────────────────────────────
    "fp_filter": {
        # Findings below this confidence score are suppressed
        "min_confidence": 0.50,

        # Drop ALL info-level findings
        "suppress_info": False,

        # Strictly drop findings whose tech tags don't match detected stack
        "tech_strict": False,
    },

    # ── Severity Engine ───────────────────────────────────────────────────────
    "severity": {
        # Assume target is internet-exposed (adds +1.0 contextual boost to all findings)
        "assume_internet_exposed": True,
    },

    # ── Pipeline ──────────────────────────────────────────────────────────────
    "pipeline": {
        # Default scan profile (fast / balanced / deep / web / cloud / network)
        "default_profile": "balanced",

        # Run Nuclei by default
        "run_nuclei": True,

        # Run Nikto by default
        "run_nikto": True,

        # Maximum total pipeline runtime in seconds
        "max_runtime_s": 900,
    },

    # ── Output ────────────────────────────────────────────────────────────────
    "output": {
        # Max findings shown in terminal table (full data always in JSON output)
        "max_table_rows": 30,

        # Include INFO-severity in terminal output
        "show_info": False,
    },
}


# ─────────────────────────────────────────────────────────────────────────────
# Stage 9 — Intelligence Engine Configuration
# ─────────────────────────────────────────────────────────────────────────────

INTELLIGENCE_CONFIG: dict = {

    # ── Correlation Engine ────────────────────────────────────────────────────
    "correlation": {
        # Minimum confidence to include a correlated finding (0–1)
        "min_confidence":     0.55,
        # Max findings to return (sorted by risk desc)
        "max_findings":       200,
        # Enable subdomain exposure correlation
        "correlate_subdomains": True,
        # Enable auth-gap correlation
        "correlate_auth":     True,
    },

    # ── Risk Scoring ──────────────────────────────────────────────────────────
    "risk_scoring": {
        # Assume target is internet-facing (adds exploitability weight)
        "assume_internet_facing": True,
        # Chain bonus multiplier (1.0 = no change, 1.5 = 50% boost for chains)
        "chain_multiplier": 1.0,
        # Risk thresholds for each level (score out of 100)
        "thresholds": {
            "critical": 71,
            "high":     51,
            "medium":   31,
            "low":      16,
        },
    },

    # ── Confidence Engine ─────────────────────────────────────────────────────
    "confidence": {
        # Drop findings with confidence below this threshold
        "min_confidence":    0.40,
        # Apply corroboration bonus when multiple sources agree
        "corroboration_bonus": True,
    },

    # ── Attack Surface Mapper ─────────────────────────────────────────────────
    "attack_surface": {
        # Max subdomains to add as graph nodes
        "max_subdomain_nodes": 100,
        # Max web endpoints to add as graph nodes
        "max_endpoint_nodes":  50,
        # Max attack paths to compute
        "max_paths":           20,
    },

    # ── Asset Classifier ──────────────────────────────────────────────────────
    "asset_classifier": {
        # Minimum confidence to trust a classification
        "min_classification_confidence": 0.50,
        # Max assets to classify (performance limit)
        "max_assets": 300,
    },

    # ── Anomaly Detector ──────────────────────────────────────────────────────
    "anomaly_detector": {
        # Sensitivity: "low" | "medium" | "high"
        # low = only suspicious_ports and critical banners
        # high = also flags all unusual ports and tech combos
        "sensitivity": "medium",
        # Confidence threshold for anomaly reporting
        "min_confidence": 0.65,
    },

    # ── Relationship Graph ────────────────────────────────────────────────────
    "relationship_graph": {
        # Maximum nodes in graph (prunes low-risk nodes if exceeded)
        "max_nodes":     500,
        # Maximum edges
        "max_edges":     2000,
        # Export formats to generate: "json" | "dot" | "d3"
        "export_formats": ["json"],
    },

    # ── Recommendation Engine ─────────────────────────────────────────────────
    "recommendations": {
        # Max recommendations to generate
        "max_recommendations": 20,
        # Include LOW-effort, LOW-risk hardening recommendations
        "include_hardening": True,
    },

    # ── Output ────────────────────────────────────────────────────────────────
    "output": {
        # Max correlated findings to show in terminal table
        "max_table_rows": 20,
        # Include INFO-level findings
        "show_info": False,
        # Save intelligence report to JSON alongside scan output
        "save_json": True,
    },
}


# ─────────────────────────────────────────────────────────────────────────────
# Stage 10 — Guided Recon & AI-Assisted Decision Engine Configuration
# ─────────────────────────────────────────────────────────────────────────────

GUIDED_RECON_CONFIG: dict = {

    # ── Strategy defaults ─────────────────────────────────────────────────────
    "default_strategy":       "balanced",   # fast|balanced|deep|stealth|web|infrastructure|vulnerability
    "allow_strategy_override": True,        # let --strategy CLI flag override

    # ── Automation ────────────────────────────────────────────────────────────
    # 0 = ask at every step, 1 = ask at key steps, 2 = fully automatic
    "default_automation_level": 1,

    # ── Verbosity ─────────────────────────────────────────────────────────────
    # 1 = quiet (action + result only)
    # 2 = normal (reasoning + methodology notes)
    # 3 = verbose (full chain + alternatives + next-hint)
    "default_verbosity": 2,

    # ── Decision engine ───────────────────────────────────────────────────────
    # Minimum confidence threshold to present a recommendation (0–1)
    "min_recommendation_confidence": 0.70,

    # ── Next-step predictor ───────────────────────────────────────────────────
    # How many next-step suggestions to display after each phase
    "max_next_steps_shown": 3,

    # ── Adaptive orchestrator ─────────────────────────────────────────────────
    # Skip phases automatically when context has enough data
    "adaptive_skip_enabled": True,

    # Pause for confirmation before executing high-noise phases
    "confirm_high_noise_phases": True,

    # ── Explanation depth ─────────────────────────────────────────────────────
    # Whether to show methodology notes inline during execution
    "show_methodology_notes": True,

    # Whether to show reasoning chain detail
    "show_reasoning_chain": True,

    # ── Learning mode ─────────────────────────────────────────────────────────
    # Pause to explain concepts before sensitive phases
    "teach_before_active_scan": True,

    # ── Dry run ───────────────────────────────────────────────────────────────
    # If True, guided recon simulates execution without running tools
    "dry_run": False,

    # ── Output ────────────────────────────────────────────────────────────────
    # Save guided session to JSON report
    "save_session_json": True,
}


# ─────────────────────────────────────────────────────────────────────────────
# Stage 11 — API Reconnaissance & GraphQL Intelligence Configuration
# ─────────────────────────────────────────────────────────────────────────────

API_RECON_CONFIG: dict = {

    # ── Discovery ─────────────────────────────────────────────────────────────
    "swagger_probe_paths": [
        "/swagger.json", "/openapi.json", "/api-docs", "/docs",
        "/swagger/v1/swagger.json", "/v1/api-docs", "/v2/api-docs",
        "/api/swagger.json", "/api/openapi.json",
    ],
    "graphql_probe_paths": [
        "/graphql", "/graphiql", "/playground", "/api/graphql",
        "/v1/graphql", "/v2/graphql", "/query", "/gql",
    ],

    # ── GraphQL ───────────────────────────────────────────────────────────────
    "graphql": {
        "test_introspection":  True,
        "test_batch":          True,
        "test_depth_limit":    True,
        "max_test_depth":      10,
        "timeout_per_req":     8.0,
    },

    # ── Kiterunner ────────────────────────────────────────────────────────────
    "kiterunner": {
        "enabled":     False,   # opt-in (active scanning)
        "threads":     40,
        "timeout_ms":  3000,
        "wordlist":    None,    # auto-detect
    },

    # ── Arjun ─────────────────────────────────────────────────────────────────
    "arjun": {
        "enabled":     False,   # opt-in (active scanning)
        "threads":     10,
        "delay":       0,
        "stable":      True,
        "methods":     ["GET", "POST"],
    },

    # ── Auth Analysis ─────────────────────────────────────────────────────────
    "auth": {
        "probe_endpoints": True,
        "check_cors":      True,
        "check_headers":   True,
        "timeout_per_req": 6.0,
    },

    # ── Risk Scoring ──────────────────────────────────────────────────────────
    "risk": {
        "swagger_exposed_weight":      15,
        "unauth_endpoint_weight":      5,
        "graphql_introspection_weight": 10,
        "critical_auth_weight":        15,
        "sensitive_param_weight":      2,
    },

    # ── Output ────────────────────────────────────────────────────────────────
    "output": {
        "max_endpoint_rows": 25,
        "max_auth_rows":     15,
        "save_json":         True,
    },
}


# ─────────────────────────────────────────────────────────────────────────────
# Stage 12 — Cloud Reconnaissance & Exposure Intelligence Configuration
# ─────────────────────────────────────────────────────────────────────────────

CLOUD_RECON_CONFIG: dict = {

    # ── Provider detection ────────────────────────────────────────────────────
    "fingerprint": {
        "probe_dns":  True,
        "probe_http": True,
        "timeout_per": 6.0,
    },

    # ── Storage scanning ──────────────────────────────────────────────────────
    "storage": {
        "check_aws":     True,
        "check_azure":   True,
        "check_gcp":     True,
        "max_objects":   50,       # max objects to enumerate per bucket
        "timeout_per":   5.0,
        "max_candidates": 20,      # max bucket name candidates to try
    },

    # ── Kubernetes analysis ───────────────────────────────────────────────────
    "kubernetes": {
        "timeout_per":    5.0,
        "probe_nodeports": False,  # skip NodePort range scan by default (slow)
    },

    # ── Container registry ────────────────────────────────────────────────────
    "registry": {
        "timeout_per": 5.0,
    },

    # ── CI/CD ─────────────────────────────────────────────────────────────────
    "cicd": {
        "timeout_per": 5.0,
    },

    # ── Risk scoring thresholds ───────────────────────────────────────────────
    "risk": {
        "public_bucket_pts":     10,
        "listing_bucket_pts":    15,
        "sensitive_file_pts":     5,
        "unauth_k8s_pts":        15,
        "unauth_cicd_pts":       12,
        "critical_misconfig_pts":  8,
    },

    # ── Output ────────────────────────────────────────────────────────────────
    "output": {
        "max_misconfig_rows": 15,
        "save_json":          True,
    },
}
