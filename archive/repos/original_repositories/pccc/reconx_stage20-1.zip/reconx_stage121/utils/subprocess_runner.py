"""
ReconX — Safe subprocess execution wrapper.

Design goals:
  - No shell=True ever (prevents injection)
  - Hard timeout via SIGKILL (not just SIGTERM)
  - Capture both stdout and stderr independently
  - Retry with back-off on transient failures
  - Return structured SubprocessResult, never raise
  - Configurable environment (clean or inherited)
"""
from __future__ import annotations
import logging
import os
import shlex
import signal
import subprocess
import time
from dataclasses import dataclass, field
from typing import Optional

logger = logging.getLogger("reconx.utils.subprocess_runner")


@dataclass
class SubprocessResult:
    """Raw result from a subprocess call before any parsing."""
    stdout:     str   = ""
    stderr:     str   = ""
    returncode: int   = -1
    duration_s: float = 0.0
    timed_out:  bool  = False
    retries_used: int = 0

    @property
    def ok(self) -> bool:
        return self.returncode == 0 and not self.timed_out

    @property
    def has_output(self) -> bool:
        return bool(self.stdout.strip())


def run_subprocess(
    cmd:           list[str],
    timeout_s:     float           = 60.0,
    retries:       int             = 0,
    env:           Optional[dict]  = None,
    cwd:           Optional[str]   = None,
    stdin_data:    Optional[str]   = None,
    expected_codes: tuple[int,...] = (0,),
    capture_stderr: bool           = True,
) -> SubprocessResult:
    """
    Execute cmd safely with a hard timeout and optional retry.

    Args:
        cmd:            Command as list of strings — NEVER pass a string with shell=True.
        timeout_s:      Hard timeout in seconds. Process is SIGKILL'd on expiry.
        retries:        Number of retries on non-zero exit (not on timeout).
        env:            Environment dict. If None, inherits os.environ (safe default).
        cwd:            Working directory.
        stdin_data:     Optional text piped to stdin.
        expected_codes: Return codes considered successful (default: (0,)).
        capture_stderr: If False, stderr goes to /dev/null.

    Returns:
        SubprocessResult — never raises.
    """
    # Safety guard: cmd must be a list
    if isinstance(cmd, str):
        logger.error("run_subprocess received a string cmd — use a list. Splitting.")
        cmd = shlex.split(cmd)

    merged_env = {**os.environ, **(env or {})}
    attempt    = 0

    while attempt <= retries:
        attempt += 1
        t_start  = time.perf_counter()

        proc: Optional[subprocess.Popen] = None

        try:
            stderr_target = subprocess.PIPE if capture_stderr else subprocess.DEVNULL

            proc = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=stderr_target,
                stdin=subprocess.PIPE if stdin_data else subprocess.DEVNULL,
                text=True,
                encoding="utf-8",
                errors="replace",
                env=merged_env,
                cwd=cwd,
                # Platform-specific: start new process group for clean kill
                **_pgroup_kwargs(),
            )

            stdout, stderr = proc.communicate(
                input=stdin_data,
                timeout=timeout_s,
            )

            duration = time.perf_counter() - t_start
            rc       = proc.returncode

            logger.debug(
                "cmd=%s  rc=%d  dur=%.2fs  attempt=%d",
                cmd[0], rc, duration, attempt,
            )

            if rc in expected_codes or attempt > retries:
                return SubprocessResult(
                    stdout=stdout or "",
                    stderr=stderr or "",
                    returncode=rc,
                    duration_s=duration,
                    timed_out=False,
                    retries_used=attempt - 1,
                )

            # Non-zero but retryable
            logger.debug("Non-zero exit %d, retrying (%d/%d)…", rc, attempt, retries)
            time.sleep(0.5 * attempt)   # exponential back-off

        except subprocess.TimeoutExpired:
            duration = time.perf_counter() - t_start
            _kill_process(proc)
            logger.warning("cmd=%s timed out after %.1fs", cmd[0], duration)
            return SubprocessResult(
                returncode=-9,
                duration_s=duration,
                timed_out=True,
                retries_used=attempt - 1,
            )

        except FileNotFoundError:
            duration = time.perf_counter() - t_start
            logger.debug("Binary not found: %s", cmd[0])
            return SubprocessResult(
                stderr=f"Binary not found: {cmd[0]}",
                returncode=127,
                duration_s=duration,
                retries_used=attempt - 1,
            )

        except KeyboardInterrupt:
            _kill_process(proc)
            return SubprocessResult(
                stderr="Interrupted by user",
                returncode=-2,
                duration_s=time.perf_counter() - t_start,
            )

        except Exception as exc:
            duration = time.perf_counter() - t_start
            logger.exception("Unexpected error running %s: %s", cmd[0], exc)
            return SubprocessResult(
                stderr=str(exc),
                returncode=-1,
                duration_s=duration,
                retries_used=attempt - 1,
            )

    # Should never reach here, but satisfy type checker
    return SubprocessResult(returncode=-1, stderr="Max retries exhausted")


def _kill_process(proc: Optional[subprocess.Popen]) -> None:
    """Forcefully kill a process and its children."""
    if proc is None:
        return
    try:
        import os, signal as _sig
        if hasattr(os, "killpg"):
            os.killpg(os.getpgid(proc.pid), _sig.SIGKILL)
        else:
            proc.kill()
        proc.wait(timeout=3)
    except Exception:
        pass


def _pgroup_kwargs() -> dict:
    """Return OS-specific kwargs for new process group (clean kill)."""
    import platform
    if platform.system() == "Windows":
        return {"creationflags": subprocess.CREATE_NEW_PROCESS_GROUP}
    return {"start_new_session": True}


# ── Convenience: check if binary available ────────────────────────────────────

def binary_available(name: str) -> bool:
    import shutil
    return shutil.which(name) is not None
