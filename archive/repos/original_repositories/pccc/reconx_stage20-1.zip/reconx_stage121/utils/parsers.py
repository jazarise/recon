"""
ReconX — Reusable output parser utilities.

All tools import from here. Zero duplication.
Parsers are pure functions: input str → output list/dict/value.
They never raise — they return empty results on bad input.
"""
from __future__ import annotations
import ipaddress
import json
import logging
import re
import xml.etree.ElementTree as ET
from typing import Any, Optional
from urllib.parse import urlparse

logger = logging.getLogger("reconx.utils.parsers")

# ── Compiled regexes (module-level for perf) ──────────────────────────────────

_RE_IPV4       = re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b")
_RE_IPV6       = re.compile(r"(?:[0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{1,4}")
_RE_EMAIL      = re.compile(r"[a-zA-Z0-9_.+\-]+@[a-zA-Z0-9\-]+\.[a-zA-Z0-9.\-]+")
_RE_URL        = re.compile(r"https?://[^\s\"'<>]+")
_RE_DOMAIN     = re.compile(
    r"(?:[a-zA-Z0-9](?:[a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?\.)+"
    r"[a-zA-Z]{2,}"
)
_RE_CIDR       = re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}/\d{1,2}\b")
_RE_CVE        = re.compile(r"CVE-\d{4}-\d{4,7}", re.IGNORECASE)
_RE_PORT_LINE  = re.compile(
    r"(\d{1,5})/(\w+)\s+(\w+)\s+(.+?)(?:\s{2,}(.+))?$"
)   # nmap-style: "22/tcp   open   ssh   OpenSSH 8.9"


# ══════════════════════════════════════════════════════════════════════════════
#  Extraction utilities
# ══════════════════════════════════════════════════════════════════════════════

def extract_ips(text: str, *, include_ipv6: bool = False) -> list[str]:
    """Extract all valid IPv4 (and optionally IPv6) addresses from text."""
    candidates = _RE_IPV4.findall(text)
    if include_ipv6:
        candidates += _RE_IPV6.findall(text)
    result = []
    for ip in candidates:
        try:
            ipaddress.ip_address(ip)
            result.append(ip)
        except ValueError:
            pass
    return list(dict.fromkeys(result))   # deduplicate, preserve order


def extract_domains(text: str) -> list[str]:
    """Extract hostname/domain strings from text."""
    raw = _RE_DOMAIN.findall(text)
    return list(dict.fromkeys(d.lower() for d in raw))


def extract_urls(text: str) -> list[str]:
    """Extract HTTP/HTTPS URLs from text."""
    return list(dict.fromkeys(_RE_URL.findall(text)))


def extract_emails(text: str) -> list[str]:
    """Extract email addresses from text."""
    return list(dict.fromkeys(
        e.lower() for e in _RE_EMAIL.findall(text)
        if "." in e.split("@")[-1]
    ))


def extract_cves(text: str) -> list[str]:
    """Extract CVE IDs from text (case-insensitive)."""
    return list(dict.fromkeys(
        m.upper() for m in _RE_CVE.findall(text)
    ))


def extract_cidrs(text: str) -> list[str]:
    """Extract CIDR notation ranges from text."""
    return list(dict.fromkeys(_RE_CIDR.findall(text)))


# ══════════════════════════════════════════════════════════════════════════════
#  Structured parsers
# ══════════════════════════════════════════════════════════════════════════════

def parse_lines(text: str, *, strip: bool = True,
                skip_empty: bool = True,
                comment_char: str = "#") -> list[str]:
    """
    Split text into clean lines.
    Strips whitespace, removes empty lines and comment lines.
    """
    lines = text.splitlines()
    result = []
    for line in lines:
        if strip:
            line = line.strip()
        if skip_empty and not line:
            continue
        if comment_char and line.startswith(comment_char):
            continue
        result.append(line)
    return result


def parse_json_lines(text: str) -> list[dict]:
    """
    Parse newline-delimited JSON (one JSON object per line).
    Skips malformed lines silently.
    """
    results = []
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            obj = json.loads(line)
            if isinstance(obj, dict):
                results.append(obj)
        except json.JSONDecodeError:
            logger.debug("JSON line parse failed: %.80s", line)
    return results


def parse_json(text: str) -> Optional[Any]:
    """
    Parse full JSON text.
    Returns None if parse fails.
    Handles masscan-style broken JSON (strips trailing comma/brackets).
    """
    text = text.strip()
    if not text:
        return None
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        # Try to fix common masscan-style trailing comma before ]
        fixed = re.sub(r",\s*]", "]", text)
        try:
            return json.loads(fixed)
        except json.JSONDecodeError:
            logger.debug("JSON parse failed after fix attempt")
            return None


def parse_xml(text: str) -> Optional[ET.Element]:
    """
    Parse XML text into an ElementTree root.
    Returns None on parse error.
    """
    try:
        return ET.fromstring(text)
    except ET.ParseError as exc:
        logger.debug("XML parse failed: %s", exc)
        return None


def parse_nmap_port_line(line: str) -> Optional[dict]:
    """
    Parse a single nmap port line:
      '22/tcp   open   ssh   OpenSSH 8.9p1'
    Returns dict or None.
    """
    m = _RE_PORT_LINE.match(line.strip())
    if not m:
        return None
    return {
        "port":     int(m.group(1)),
        "protocol": m.group(2),
        "state":    m.group(3),
        "service":  m.group(4).strip(),
        "version":  (m.group(5) or "").strip(),
    }


def parse_nmap_xml(root: ET.Element) -> dict:
    """
    Parse an nmap XML ElementTree root into structured data.
    Returns {"ports": [Port-like dicts], "os_info": {...}}.
    """
    from ..models.findings import Port
    result: dict = {"ports": [], "os_info": {}}

    for host in root.findall("host"):
        for port_el in host.findall(".//port"):
            state_el = port_el.find("state")
            if state_el is None or state_el.get("state") != "open":
                continue
            svc = port_el.find("service")
            result["ports"].append(Port(
                number=int(port_el.get("portid", 0)),
                protocol=port_el.get("protocol", "tcp"),
                state="open",
                service=svc.get("name", "")    if svc is not None else "",
                version=(
                    f"{svc.get('product','')} {svc.get('version','')}".strip()
                    if svc is not None else ""
                ),
                banner=svc.get("extrainfo", "") if svc is not None else "",
            ))
        for osmatch in host.findall(".//osmatch"):
            result["os_info"] = {
                "os":         osmatch.get("name", "Unknown"),
                "confidence": int(osmatch.get("accuracy", 0)),
            }
            break

    return result


def parse_key_value(text: str, sep: str = ":") -> dict[str, str]:
    """
    Parse 'Key: Value' style text (WHOIS, HTTP headers, etc.)
    Returns dict of lowercase keys → stripped values.
    """
    result: dict[str, str] = {}
    for line in text.splitlines():
        if sep not in line:
            continue
        key, _, val = line.partition(sep)
        key  = key.strip().lower().replace(" ", "_")
        val  = val.strip()
        if key and val and key not in result:
            result[key] = val
    return result


# ══════════════════════════════════════════════════════════════════════════════
#  URL / Host utilities
# ══════════════════════════════════════════════════════════════════════════════

def normalize_url(url: str) -> str:
    """Ensure URL has a scheme; default to https."""
    url = url.strip()
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    return url


def url_to_host(url: str) -> str:
    """Extract hostname from a URL string."""
    try:
        return urlparse(normalize_url(url)).netloc.split(":")[0]
    except Exception:
        return url


def is_valid_url(url: str) -> bool:
    try:
        parsed = urlparse(url)
        return parsed.scheme in ("http", "https") and bool(parsed.netloc)
    except Exception:
        return False


# ══════════════════════════════════════════════════════════════════════════════
#  ANSI stripping
# ══════════════════════════════════════════════════════════════════════════════

_RE_ANSI = re.compile(r"\x1b\[[0-9;]*[A-Za-z]")

def strip_ansi(text: str) -> str:
    """Remove ANSI escape codes from terminal output."""
    return _RE_ANSI.sub("", text)
