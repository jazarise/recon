"""
ReconX — Stage 19: Plugin SDK

Public API for plugin developers.

from reconx.sdk import PluginBaseTool, ToolMetadata, CapabilitySet
from reconx.sdk import CAPABILITIES, COMMON_CAPS, RiskLevel, InstallMethod
from reconx.sdk import ToolMetadataBuilder, make_metadata, PluginPermissions
"""
from .contracts import (
    ToolMetadata, CapabilitySet, Capability, PluginPermissions,
    RiskLevel, InstallMethod, InputType, OutputType,
)
from .base_tool import PluginBaseTool, HealthStatus
from .metadata  import (
    CAPABILITIES, COMMON_CAPS, ToolMetadataBuilder, make_metadata,
)

__all__ = [
    "PluginBaseTool", "HealthStatus",
    "ToolMetadata", "CapabilitySet", "Capability", "PluginPermissions",
    "RiskLevel", "InstallMethod", "InputType", "OutputType",
    "CAPABILITIES", "COMMON_CAPS", "ToolMetadataBuilder", "make_metadata",
]
