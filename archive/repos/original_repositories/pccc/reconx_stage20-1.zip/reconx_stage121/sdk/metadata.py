"""
ReconX — Stage 19: SDK Metadata Helpers

Provides:
  ToolMetadataBuilder  — fluent builder for ToolMetadata
  CAPABILITIES         — standard capability slug constants
  COMMON_CAPS          — pre-built CapabilitySet bundles per tool category
  make_metadata()      — one-shot factory function

Keeps plugin files clean — no need to import enums directly.
"""
from __future__ import annotations

from .contracts import (
    ToolMetadata, CapabilitySet, Capability,
    PluginPermissions, RiskLevel, InstallMethod,
    InputType, OutputType,
)


# ── Standard capability slug constants ───────────────────────────────────────
# Import these in plugin files instead of bare strings for typo safety.

class CAPABILITIES:
    # Network / Port scanning
    PORT_SCAN          = "port_scan"
    UDP_SCAN           = "udp_scan"
    OS_DETECTION       = "os_detection"
    SERVICE_DETECTION  = "service_detection"
    VERSION_DETECTION  = "version_detection"
    HOST_DISCOVERY     = "host_discovery"
    TRACEROUTE         = "traceroute"

    # DNS / Subdomain
    SUBDOMAIN_ENUM     = "subdomain_enumeration"
    DNS_BRUTE          = "dns_bruteforce"
    DNS_RESOLVE        = "dns_resolution"
    DNS_WILDCARD       = "dns_wildcard_detection"
    ZONE_TRANSFER      = "zone_transfer"
    ASN_INTEL          = "asn_intelligence"
    REVERSE_DNS        = "reverse_dns"

    # Web
    WEB_CRAWL          = "web_crawl"
    DIR_BRUTE          = "directory_bruteforce"
    VHOST_ENUM         = "vhost_enumeration"
    PARAM_DISCOVERY    = "parameter_discovery"
    JS_ANALYSIS        = "js_analysis"
    SCREENSHOT         = "screenshot"
    TECH_DETECT        = "technology_detection"
    WAF_DETECT         = "waf_detection"
    HTTP_PROBE         = "http_probe"

    # TLS / Certs
    TLS_SCAN           = "tls_scan"
    CERT_ENUM          = "certificate_enumeration"
    JA3_FINGERPRINT    = "ja3_fingerprint"
    TLS_WEAKNESS       = "tls_weakness_detection"

    # OSINT
    WHOIS              = "whois_lookup"
    EMAIL_ENUM         = "email_enumeration"
    SOCIAL_INTEL       = "social_intelligence"
    ORG_INTEL          = "org_intelligence"

    # API
    API_DISCOVERY      = "api_discovery"
    GRAPHQL_DETECT     = "graphql_detection"
    SWAGGER_PARSE      = "swagger_parsing"
    API_FUZZ           = "api_fuzzing"

    # Secrets / Credentials
    SECRET_SCAN        = "secret_scanning"
    CREDENTIAL_DETECT  = "credential_detection"

    # Traffic / Network analysis
    PCAP_ANALYSIS      = "pcap_analysis"
    LIVE_CAPTURE       = "live_capture"
    PROTOCOL_DETECT    = "protocol_detection"
    ANOMALY_DETECT     = "anomaly_detection"
    DNS_TUNNEL_DETECT  = "dns_tunnel_detection"

    # Burp / Web proxy
    PROXY_CAPTURE      = "proxy_capture"
    SESSION_REPLAY     = "session_replay"
    PASSIVE_FINDINGS   = "passive_findings"

    # Vulnerability
    VULN_SCAN          = "vuln_scan"
    CVE_MATCH          = "cve_matching"
    NUCLEI_SCAN        = "nuclei_scan"

    # Cloud
    CLOUD_ENUM         = "cloud_enumeration"
    BUCKET_SCAN        = "bucket_scan"
    K8S_SCAN           = "kubernetes_scan"


# ── Pre-built CapabilitySet bundles ──────────────────────────────────────────

class COMMON_CAPS:
    """Ready-made CapabilitySet bundles for common tool types."""

    @staticmethod
    def port_scanner() -> CapabilitySet:
        return (CapabilitySet()
            .add(CAPABILITIES.PORT_SCAN,         "TCP/UDP port discovery")
            .add(CAPABILITIES.HOST_DISCOVERY,    "Live host detection")
            .add(CAPABILITIES.SERVICE_DETECTION, "Service banner grabbing"))

    @staticmethod
    def subdomain_enumerator() -> CapabilitySet:
        return (CapabilitySet()
            .add(CAPABILITIES.SUBDOMAIN_ENUM, "Passive subdomain enumeration")
            .add(CAPABILITIES.DNS_RESOLVE,    "DNS resolution and validation"))

    @staticmethod
    def web_crawler() -> CapabilitySet:
        return (CapabilitySet()
            .add(CAPABILITIES.WEB_CRAWL,       "Spider links and endpoints")
            .add(CAPABILITIES.PARAM_DISCOVERY, "Query parameter discovery")
            .add(CAPABILITIES.JS_ANALYSIS,     "JavaScript file analysis"))

    @staticmethod
    def http_prober() -> CapabilitySet:
        return (CapabilitySet()
            .add(CAPABILITIES.HTTP_PROBE,    "HTTP/HTTPS probe and fingerprint")
            .add(CAPABILITIES.TECH_DETECT,   "Web technology detection")
            .add(CAPABILITIES.TLS_SCAN,      "TLS certificate inspection"))

    @staticmethod
    def traffic_analyzer() -> CapabilitySet:
        return (CapabilitySet()
            .add(CAPABILITIES.PCAP_ANALYSIS,     "PCAP/PCAPNG file analysis")
            .add(CAPABILITIES.LIVE_CAPTURE,      "Live interface capture")
            .add(CAPABILITIES.PROTOCOL_DETECT,   "Application protocol detection")
            .add(CAPABILITIES.ANOMALY_DETECT,    "Behavioural anomaly detection")
            .add(CAPABILITIES.CREDENTIAL_DETECT, "Masked credential extraction"))


# ── Fluent metadata builder ───────────────────────────────────────────────────

class ToolMetadataBuilder:
    """
    Fluent builder for ToolMetadata.

    Usage:
        meta = (ToolMetadataBuilder("Nmap", "Network mapper")
            .category("network")
            .binary("nmap")
            .stage(3)
            .priority(10)
            .risk(RiskLevel.HIGH)
            .passive(False)
            .permissions(requires_root=True)
            .capabilities(COMMON_CAPS.port_scanner()
                .add(CAPABILITIES.OS_DETECTION, "OS fingerprinting")
                .add(CAPABILITIES.VERSION_DETECTION, "Service version detection"))
            .inputs(InputType.IP, InputType.DOMAIN, InputType.CIDR)
            .outputs(OutputType.PORTS, OutputType.SERVICES)
            .install(InstallMethod.APT, "sudo apt install nmap")
            .tags("network", "scanning", "active")
            .example("nmap -sV -O 192.168.1.0/24")
            .build())
    """

    def __init__(self, name: str, description: str):
        self._meta = ToolMetadata(name=name, description=description)

    def category(self, cat: str, sub: str = "") -> "ToolMetadataBuilder":
        self._meta.category = cat
        self._meta.sub_category = sub
        return self

    def binary(self, binary: str) -> "ToolMetadataBuilder":
        self._meta.binary = binary
        return self

    def stage(self, s: int) -> "ToolMetadataBuilder":
        self._meta.stage = s
        return self

    def priority(self, p: int) -> "ToolMetadataBuilder":
        self._meta.priority = p
        return self

    def version(self, v: str) -> "ToolMetadataBuilder":
        self._meta.version = v
        return self

    def author(self, a: str) -> "ToolMetadataBuilder":
        self._meta.author = a
        return self

    def risk(self, level: RiskLevel) -> "ToolMetadataBuilder":
        self._meta.risk_level = level
        return self

    def passive(self, p: bool = True) -> "ToolMetadataBuilder":
        self._meta.passive = p
        return self

    def permissions(self, **kw) -> "ToolMetadataBuilder":
        self._meta.permissions = PluginPermissions(**kw)
        return self

    def capabilities(self, caps: CapabilitySet) -> "ToolMetadataBuilder":
        self._meta.capabilities = caps
        return self

    def inputs(self, *types) -> "ToolMetadataBuilder":
        self._meta.supported_inputs = [
            t.value if isinstance(t, InputType) else str(t) for t in types
        ]
        return self

    def outputs(self, *types) -> "ToolMetadataBuilder":
        self._meta.supported_outputs = [
            t.value if isinstance(t, OutputType) else str(t) for t in types
        ]
        return self

    def install(self, method: InstallMethod, cmd: str) -> "ToolMetadataBuilder":
        self._meta.install_method = method
        self._meta.install_cmd    = cmd
        return self

    def tags(self, *tag_list: str) -> "ToolMetadataBuilder":
        self._meta.tags = list(tag_list)
        return self

    def example(self, usage: str) -> "ToolMetadataBuilder":
        self._meta.example_usage = usage
        return self

    def homepage(self, url: str) -> "ToolMetadataBuilder":
        self._meta.homepage = url
        return self

    def timeout(self, seconds: int) -> "ToolMetadataBuilder":
        self._meta.default_timeout = seconds
        return self

    def dependencies(self, *deps: str) -> "ToolMetadataBuilder":
        self._meta.dependencies = list(deps)
        return self

    def build(self) -> ToolMetadata:
        errors = self._meta.validate()
        if errors:
            raise ValueError(f"ToolMetadata validation errors: {errors}")
        return self._meta


def make_metadata(name: str, description: str, **kwargs) -> ToolMetadata:
    """One-shot factory — pass any ToolMetadata field as a keyword arg."""
    m = ToolMetadata(name=name, description=description)
    for key, val in kwargs.items():
        if hasattr(m, key):
            setattr(m, key, val)
    return m
