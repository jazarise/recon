"""
ReconX — Stage 19: SDK BaseTool Extension

Extends the existing BaseTool (tools/base.py) with the full Stage 19
plugin interface:

  metadata()      → ToolMetadata
  capabilities()  → CapabilitySet
  permissions()   → PluginPermissions
  healthcheck()   → HealthStatus
  install()       → bool
  check()         → bool

Every new Stage 19 plugin inherits PluginBaseTool instead of BaseTool.
Existing tools continue using BaseTool directly — zero breakage.

The PluginBaseTool.METADATA class attribute is the single source of truth.
All BaseTool constants (NAME, BINARY, CATEGORY, etc.) are auto-populated
from METADATA so legacy code that reads those constants keeps working.
"""
from __future__ import annotations

import logging
import shutil
import subprocess
import time
from abc import ABC
from dataclasses import dataclass, field
from typing import Optional

from .contracts import (
    ToolMetadata, CapabilitySet, PluginPermissions,
    RiskLevel, InstallMethod,
)

# Import the existing BaseTool — never modify it
try:
    from ..tools.base import BaseTool
except ImportError:
    # Standalone / test context fallback
    from abc import abstractmethod
    class BaseTool(ABC):  # type: ignore[no-redef]
        NAME=""; BINARY=""; CATEGORY=""; STAGE=0; PRIORITY=50
        PASSIVE=False; TIMEOUT=60; DEPENDENCIES=[]; INSTALL_CMD=""
        def __init__(self, **kw): pass
        def _log(self, lvl, msg): logging.getLogger("reconx.sdk").info(msg)
        def is_available(self) -> bool:
            import shutil
            return bool(shutil.which(self.BINARY)) if self.BINARY else True
        @abstractmethod
        def run(self, target, **kwargs): ...
        @abstractmethod
        def parse_output(self, raw, **kwargs): ...
        def safe_run(self, target, **kwargs): return self.run(target, **kwargs)
        def validate_or_fail(self, t): return None
        def skip_if_unavailable(self): return None
        def build_result(self, **kw): return kw
        def fail(self, **kw): return kw

logger = logging.getLogger("reconx.sdk.base_tool")


@dataclass
class HealthStatus:
    """Result of a tool healthcheck."""
    name:      str
    available: bool
    version:   str = ""
    error:     str = ""
    latency_ms: float = 0.0

    @property
    def ok(self) -> bool:
        return self.available and not self.error

    def summary(self) -> str:
        if self.ok:
            return f"✓ {self.name} {self.version} ({self.latency_ms:.0f}ms)"
        return f"✗ {self.name}: {self.error or 'unavailable'}"


class PluginBaseTool(BaseTool):
    """
    Stage 19 extended base class for all new plugin tools.

    Inherits everything from BaseTool and adds:
      - METADATA class attribute (ToolMetadata)
      - Auto-sync of NAME, BINARY, CATEGORY, STAGE, PRIORITY, PASSIVE,
        TIMEOUT, INSTALL_CMD from METADATA
      - metadata() / capabilities() / permissions() accessors
      - healthcheck()
      - install() / check()

    Usage:
        class NmapPlugin(PluginBaseTool):
            METADATA = ToolMetadata(
                name="Nmap",
                description="Network mapper and port scanner",
                category="network",
                binary="nmap",
                stage=3,
                capabilities=CapabilitySet()
                    .add("port_scan", "TCP/UDP port discovery")
                    .add("os_detection", "OS fingerprinting via TTL/TCP window")
                    .add("service_detection", "Banner grabbing and version detection"),
                permissions=PluginPermissions(requires_root=True),
                risk_level=RiskLevel.HIGH,
            )

            def run(self, target, **kwargs):
                ...

            def parse_output(self, raw, **kwargs):
                ...
    """

    # ── METADATA must be overridden in every subclass ─────────────────────────
    METADATA: ToolMetadata = ToolMetadata(
        name="UnnamedPlugin",
        description="Override METADATA in your plugin subclass",
        category="general",
    )

    def __init_subclass__(cls, **kwargs):
        """
        Auto-populate legacy BaseTool constants from METADATA when a
        subclass is defined. This keeps the existing engine/registry/scheduler
        working without any changes.
        """
        super().__init_subclass__(**kwargs)
        if hasattr(cls, "METADATA") and isinstance(cls.METADATA, ToolMetadata):
            m = cls.METADATA
            # Only set if not explicitly overridden in the subclass body
            if not cls.__dict__.get("NAME"):
                cls.NAME = m.name
            if not cls.__dict__.get("BINARY"):
                cls.BINARY = m.binary
            if not cls.__dict__.get("CATEGORY"):
                cls.CATEGORY = m.category
            if not cls.__dict__.get("STAGE"):
                cls.STAGE = m.stage
            if not cls.__dict__.get("PRIORITY"):
                cls.PRIORITY = m.priority
            if not cls.__dict__.get("PASSIVE"):
                cls.PASSIVE = m.passive
            if not cls.__dict__.get("TIMEOUT"):
                cls.TIMEOUT = m.default_timeout
            if not cls.__dict__.get("INSTALL_CMD"):
                cls.INSTALL_CMD = m.install_cmd
            if not cls.__dict__.get("DEPENDENCIES"):
                cls.DEPENDENCIES = m.dependencies

    # ══════════════════════════════════════════════════════════════════════════
    # Stage 19 interface methods
    # ══════════════════════════════════════════════════════════════════════════

    def metadata(self) -> ToolMetadata:
        """Return the full ToolMetadata for this plugin."""
        return self.METADATA

    def capabilities(self) -> CapabilitySet:
        """Return the capabilities this plugin exposes."""
        return self.METADATA.capabilities

    def permissions(self) -> PluginPermissions:
        """Return the system permissions this plugin needs."""
        return self.METADATA.permissions

    def healthcheck(self) -> HealthStatus:
        """
        Check whether the tool binary is available and responsive.
        Tries `<binary> --version` with a 5-second timeout.
        Never raises — returns HealthStatus with error on failure.
        """
        binary = self.METADATA.binary
        name   = self.METADATA.name

        if not binary:
            # Pure-Python plugin — always healthy
            return HealthStatus(name=name, available=True, version="python")

        if not shutil.which(binary):
            return HealthStatus(
                name=name, available=False,
                error=f"'{binary}' not found on PATH. "
                      f"Install: {self.METADATA.install_cmd or 'see docs'}",
            )

        t0 = time.perf_counter()
        try:
            r = subprocess.run(
                [binary, "--version"],
                capture_output=True, text=True,
                timeout=5,
            )
            latency_ms = (time.perf_counter() - t0) * 1000
            version = (r.stdout or r.stderr).strip().splitlines()[0][:60]
            return HealthStatus(
                name=name, available=True,
                version=version, latency_ms=latency_ms,
            )
        except subprocess.TimeoutExpired:
            return HealthStatus(name=name, available=True,
                                error="version check timed out")
        except Exception as exc:
            return HealthStatus(name=name, available=False, error=str(exc))

    def check(self) -> bool:
        """Quick binary availability check. Returns True if ready to run."""
        return self.healthcheck().available

    def install(self) -> bool:
        """
        Attempt to install the tool using its declared install_method.
        Stage 19: runs the install_cmd for apt/pip/go only.
        Returns True on success.
        Never raises.
        """
        m = self.METADATA
        if not m.install_cmd:
            logger.warning("[%s] No install_cmd defined.", m.name)
            return False

        method = m.install_method
        logger.info("[%s] Installing via %s: %s", m.name, method.value, m.install_cmd)

        try:
            if method == InstallMethod.PIP:
                cmd = ["pip", "install", "--break-system-packages"] + m.install_cmd.split()[1:]
            else:
                cmd = m.install_cmd.split()

            result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
            if result.returncode == 0:
                logger.info("[%s] Install succeeded.", m.name)
                return True
            logger.warning("[%s] Install failed: %s", m.name, result.stderr[:200])
            return False
        except Exception as exc:
            logger.warning("[%s] Install exception: %s", m.name, exc)
            return False

    # ══════════════════════════════════════════════════════════════════════════
    # name() / description() / category() — explicit method interface
    # (Stage 19 spec calls for these as methods, not just class attrs)
    # ══════════════════════════════════════════════════════════════════════════

    def name(self) -> str:
        return self.METADATA.name

    def description(self) -> str:
        return self.METADATA.description

    def category(self) -> str:
        return self.METADATA.category

    def validate(self, target: str) -> Optional[object]:
        """Alias for validate_or_fail() — Stage 19 contract name."""
        return self.validate_or_fail(target)
