"""
ReconX — Stage 19: Plugin SDK Contracts

Defines the canonical data contracts all plugins must implement:
  - ToolMetadata        : full metadata schema for every plugin
  - Capability          : single named capability with description
  - CapabilitySet       : collection of capabilities a tool exposes
  - PluginPermissions   : what system resources a plugin needs
  - ToolContract        : the interface every plugin tool must satisfy

Design rules:
  - All fields use primitive types (str, bool, list) — no circular imports
  - Backward compatible with existing PluginManifest (Stage 15)
  - Forward compatible with AI-agent capability routing (Stage 20+)
  - No external dependencies
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


# ── Enumerations ──────────────────────────────────────────────────────────────

class RiskLevel(str, Enum):
    """How noisy / detectable a tool is against a target."""
    PASSIVE   = "passive"    # zero packets sent to target
    LOW       = "low"        # minimal traffic, hard to detect
    MEDIUM    = "medium"     # moderate traffic
    HIGH      = "high"       # noisy, easily detected
    CRITICAL  = "critical"   # highly intrusive, must have permission


class InstallMethod(str, Enum):
    APT      = "apt"
    BREW     = "brew"
    GO       = "go install"
    PIP      = "pip"
    CARGO    = "cargo"
    BINARY   = "binary"      # download pre-built binary
    DOCKER   = "docker"
    MANUAL   = "manual"
    NONE     = "none"        # pure Python, no install needed


class InputType(str, Enum):
    DOMAIN   = "domain"
    IP       = "ip"
    CIDR     = "cidr"
    URL      = "url"
    ASN      = "asn"
    EMAIL    = "email"
    FILE     = "file"
    PCAP     = "pcap"
    ANY      = "any"


class OutputType(str, Enum):
    SUBDOMAINS  = "subdomains"
    PORTS       = "ports"
    SERVICES    = "services"
    URLS        = "urls"
    EMAILS      = "emails"
    CERTS       = "certs"
    HEADERS     = "headers"
    CREDENTIALS = "credentials"
    IPS         = "ips"
    DOMAINS     = "domains"
    FINDINGS    = "findings"
    RAW         = "raw"


# ── Capability ────────────────────────────────────────────────────────────────

@dataclass
class Capability:
    """
    One discrete capability a plugin exposes.

    Used by the CapabilityEngine to match tools to task requirements.
    Example: Capability("port_scan", "Discovers open TCP/UDP ports")
    """
    slug:        str           # machine-readable: "port_scan", "os_detection"
    description: str = ""      # human-readable explanation
    requires_root: bool = False
    requires_network: bool = True

    def __hash__(self) -> int:
        return hash(self.slug)

    def __eq__(self, other) -> bool:
        if isinstance(other, Capability):
            return self.slug == other.slug
        if isinstance(other, str):
            return self.slug == other
        return NotImplemented

    def __str__(self) -> str:
        return self.slug


@dataclass
class CapabilitySet:
    """All capabilities exposed by a single plugin."""
    capabilities: list[Capability] = field(default_factory=list)

    def add(self, slug: str, description: str = "", **kw) -> "CapabilitySet":
        self.capabilities.append(Capability(slug, description, **kw))
        return self

    def slugs(self) -> list[str]:
        return [c.slug for c in self.capabilities]

    def has(self, slug: str) -> bool:
        return any(c.slug == slug for c in self.capabilities)

    def __iter__(self):
        return iter(self.capabilities)

    def __len__(self) -> int:
        return len(self.capabilities)


# ── Permissions ───────────────────────────────────────────────────────────────

@dataclass
class PluginPermissions:
    """
    Declares what system resources a plugin needs.
    Stage 19: declarative only — not enforced yet (enforcement in Stage 20).
    """
    requires_root:    bool = False   # needs sudo / Administrator
    requires_network: bool = True    # sends packets / makes HTTP requests
    requires_browser: bool = False   # needs Chrome/Firefox
    requires_docker:  bool = False   # needs Docker daemon
    requires_disk:    bool = False   # writes files to disk
    read_only:        bool = False   # only reads, never writes or sends

    def summary(self) -> list[str]:
        """Return list of permission labels for display."""
        labels = []
        if self.requires_root:    labels.append("root")
        if self.requires_network: labels.append("network")
        if self.requires_browser: labels.append("browser")
        if self.requires_docker:  labels.append("docker")
        if self.requires_disk:    labels.append("disk-write")
        if self.read_only:        labels.append("read-only")
        return labels


# ── Tool Metadata (full schema) ───────────────────────────────────────────────

@dataclass
class ToolMetadata:
    """
    Complete metadata schema for a Stage 19 plugin tool.

    Required fields: name, description, category, version
    Everything else has a sensible default.

    This is the single source of truth for:
      - CLI display (`reconx tools info <name>`)
      - Capability routing (CapabilityEngine)
      - Registry entries
      - Learning Mode descriptions
      - Future marketplace listings
    """
    # Identity
    name:         str
    description:  str
    version:      str              = "1.0.0"
    author:       str              = "ReconX"

    # Classification
    category:     str              = "general"
    sub_category: str              = ""
    tags:         list[str]        = field(default_factory=list)
    stage:        int              = 3         # execution stage 1–5
    priority:     int              = 50

    # Capabilities
    capabilities: CapabilitySet    = field(default_factory=CapabilitySet)
    permissions:  PluginPermissions = field(default_factory=PluginPermissions)

    # I/O contract
    supported_inputs:  list[str]   = field(default_factory=lambda: ["domain", "ip"])
    supported_outputs: list[str]   = field(default_factory=list)

    # Risk and detectability
    risk_level:   RiskLevel        = RiskLevel.MEDIUM
    passive:      bool             = False

    # Installation
    binary:       str              = ""        # CLI binary name
    install_method: InstallMethod  = InstallMethod.NONE
    install_cmd:  str              = ""
    dependencies: list[str]        = field(default_factory=list)  # pip packages

    # Timing
    default_timeout: int           = 60        # seconds

    # Documentation
    example_usage: str             = ""
    docs_url:      str             = ""
    homepage:      str             = ""

    def to_dict(self) -> dict:
        """Serialise to plain dict for display and caching."""
        return {
            "name":              self.name,
            "description":       self.description,
            "version":           self.version,
            "author":            self.author,
            "category":          self.category,
            "sub_category":      self.sub_category,
            "tags":              self.tags,
            "stage":             self.stage,
            "priority":          self.priority,
            "capabilities":      self.capabilities.slugs(),
            "permissions":       self.permissions.summary(),
            "supported_inputs":  self.supported_inputs,
            "supported_outputs": self.supported_outputs,
            "risk_level":        self.risk_level.value,
            "passive":           self.passive,
            "binary":            self.binary,
            "install_method":    self.install_method.value,
            "install_cmd":       self.install_cmd,
            "dependencies":      self.dependencies,
            "default_timeout":   self.default_timeout,
            "example_usage":     self.example_usage,
            "homepage":          self.homepage,
        }

    def validate(self) -> list[str]:
        """Return list of validation errors (empty = valid)."""
        errors = []
        if not self.name:
            errors.append("'name' is required")
        if not self.description:
            errors.append("'description' is required")
        if not self.category:
            errors.append("'category' is required")
        if self.stage not in range(1, 6):
            errors.append(f"'stage' must be 1–5, got {self.stage}")
        return errors
