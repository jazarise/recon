"""
ReconX — YAML Knowledge Loader.
Loads tool metadata from knowledge/tools/<slug>.yaml into structured dicts.
"""
from __future__ import annotations
import logging
from pathlib import Path
from typing import Optional

import yaml

logger = logging.getLogger("reconx.knowledge")

_TOOLS_DIR = Path(__file__).parent / "tools"

_REQUIRED_KEYS = {"name", "category", "description", "use_cases",
                  "command", "how_it_works", "common_errors"}


def load_tool(slug: str) -> Optional[dict]:
    """Load and validate a single tool YAML by slug (e.g. 'nmap')."""
    path = _TOOLS_DIR / f"{slug}.yaml"
    if not path.exists():
        logger.debug("No knowledge file for '%s' at %s", slug, path)
        return None
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
        if not isinstance(data, dict):
            logger.warning("Invalid YAML structure in %s", path)
            return None
        # Fill optional keys with defaults
        data.setdefault("integrations", [])
        data.setdefault("tips", [])
        data.setdefault("common_errors", [])
        return data
    except yaml.YAMLError as exc:
        logger.error("YAML parse error in %s: %s", path, exc)
        return None


def load_all() -> dict[str, dict]:
    """Load every YAML in the tools directory. Returns {slug: data}."""
    result: dict[str, dict] = {}
    for path in sorted(_TOOLS_DIR.glob("*.yaml")):
        slug = path.stem
        data = load_tool(slug)
        if data:
            result[slug] = data
    return result


def available_slugs() -> list[str]:
    """Return list of tool slugs that have a knowledge file."""
    return [p.stem for p in sorted(_TOOLS_DIR.glob("*.yaml"))]
