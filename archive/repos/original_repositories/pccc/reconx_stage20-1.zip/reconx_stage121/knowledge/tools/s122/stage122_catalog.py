"""
ReconX — Learning Mode Knowledge Catalog (Stage 12.2).

Covers all Stage 12.2 tools across four new categories:
  Attack Surface    — github-subdomains, asnmap, mapcidr, alterx
  Historical Recon  — waymore
  URL Discovery     — gau (enhanced), waybackurls (enhanced), katana, hakrawler
  Parameter Discovery — paramspider, arjun (enhanced), gospider, waymore

Note: gau / waybackurls / katana / hakrawler / arjun already have Stage 11
knowledge entries. These entries extend or document them for the new
Stage 12.2 category structure.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional

# Re-use the ToolKnowledge dataclass from Stage 12.1 catalog
try:
    from reconx.knowledge.tools.stage121_catalog import ToolKnowledge
except ModuleNotFoundError:
    from knowledge.tools.stage121_catalog import ToolKnowledge


# ─────────────────────────────────────────────────────────────────────────────
# ATTACK SURFACE
# ─────────────────────────────────────────────────────────────────────────────

GITHUB_SUBDOMAINS = ToolKnowledge(
    name        = "github-subdomains",
    category    = "Attack Surface",
    passive     = True,
    description = (
        "github-subdomains mines public GitHub repositories for subdomain "
        "and infrastructure assets leaked in code, config files, CI/CD scripts, "
        "and documentation. Finds assets that passive DNS tools miss entirely."
    ),
    how_it_works = (
        "The tool queries the GitHub Code Search API for the target domain string "
        "across specific file types (YAML, JSON, .env, .conf). It extracts any "
        "matching subdomain patterns from file paths, content snippets, and metadata. "
        "When a GitHub token is provided, rate limits increase from 10 to 30 req/min."
    ),
    use_cases = [
        "Discover internal hostnames leaked in public CI/CD configs",
        "Find staging/dev environments referenced in GitHub Actions workflows",
        "Identify API endpoints in public SDK or documentation repos",
        "Expand attack surface beyond what DNS tools find",
    ],
    example_commands = [
        "github-subdomains -d example.com -t 20",
        "github-subdomains -d example.com -token ghp_YOURTOKEN -t 50",
        "# ReconX uses RECONX_GITHUB_TOKEN env var automatically",
        "export RECONX_GITHUB_TOKEN=ghp_xxx && reconx -t example.com",
    ],
    common_errors = [
        {
            "error":    "API rate limit exceeded (403/429)",
            "solution": "Set RECONX_GITHUB_TOKEN env var with a personal access token",
        },
        {
            "error":    "No results found",
            "solution": "Target may have no public GitHub exposure. Normal for private-code orgs.",
        },
    ],
    install          = "go install github.com/gwen001/github-subdomains@latest",
    typical_workflow = ["theHarvester", "github-subdomains", "Sublist3r", "alterx", "DNS Resolution"],
    integrations     = ["alterx", "asnmap", "theHarvester", "Amass"],
    tags             = ["osint", "passive", "github", "subdomain", "code-search"],
    reference_url    = "https://github.com/gwen001/github-subdomains",
)


ASNMAP = ToolKnowledge(
    name        = "asnmap",
    category    = "Attack Surface",
    passive     = True,
    description = (
        "asnmap resolves ASN numbers, organization names, or domains to their "
        "full BGP-announced CIDR ranges. Essential for infrastructure-level attack "
        "surface mapping — shows ALL IP space an organisation owns, not just what "
        "DNS resolves to."
    ),
    how_it_works = (
        "asnmap queries BGP routing tables via the RIPE STAT API, BGPView, or "
        "ProjectDiscovery's ASN database. Given a domain, it first resolves the "
        "domain's IP, looks up its ASN, then retrieves all CIDR prefixes announced "
        "by that ASN. Results are correlated against organisation records."
    ),
    use_cases = [
        "Discover all IP ranges owned by a target organisation",
        "Feed discovered CIDRs into Nmap/masscan for port scanning",
        "Understand infrastructure ownership beyond DNS-visible assets",
        "Identify cloud provider ranges vs self-hosted infrastructure",
    ],
    example_commands = [
        "asnmap -d example.com -json",
        "asnmap -asn AS12345 -silent",
        "asnmap -org 'Example Corp' -json | mapcidr -silent",
        "echo 'AS12345' | asnmap -json",
    ],
    common_errors = [
        {
            "error":    "No CIDR ranges found",
            "solution": "Target may use a shared cloud provider ASN. Try the org name instead of domain.",
        },
        {
            "error":    "asnmap: command not found",
            "solution": "go install github.com/projectdiscovery/asnmap/cmd/asnmap@latest",
        },
    ],
    install          = "go install github.com/projectdiscovery/asnmap/cmd/asnmap@latest",
    typical_workflow = ["WHOIS", "asnmap", "mapcidr", "fping", "Nmap Port Scan"],
    integrations     = ["mapcidr", "fping", "Nmap", "NetdiscoverTool"],
    tags             = ["asn", "cidr", "passive", "infrastructure", "bgp", "ip-range"],
    reference_url    = "https://github.com/projectdiscovery/asnmap",
)


MAPCIDR = ToolKnowledge(
    name        = "mapcidr",
    category    = "Attack Surface",
    passive     = True,
    description = (
        "mapcidr performs mathematical operations on IP CIDR ranges: expansion to "
        "individual IPs, aggregation of overlapping ranges, splitting large ranges, "
        "and filtering bogon/private addresses. Converts ASN CIDR output into "
        "scannable target lists."
    ),
    how_it_works = (
        "mapcidr reads CIDR ranges from stdin and applies the requested operation using "
        "efficient bitwise IP arithmetic. For expansion, it enumerates all host IPs "
        "in the range. For aggregation, it collapses overlapping ranges using the CIDR "
        "supernet algorithm. Output is one IP or CIDR per line — pipe-friendly."
    ),
    use_cases = [
        "Expand ASN CIDRs into individual IPs for Nmap input",
        "Aggregate multiple overlapping ranges into minimal CIDR notation",
        "Split /16 into /24 subnets for distributed scanning",
        "Filter RFC1918 / bogon ranges before scanning",
    ],
    example_commands = [
        "echo '192.168.1.0/24' | mapcidr -silent",
        "cat cidrs.txt | mapcidr -aggregate -silent",
        "asnmap -d example.com | mapcidr -silent | nmap -iL -",
        "cat cidrs.txt | mapcidr -sbc 256 -silent  # split into /24s",
    ],
    common_errors = [
        {
            "error":    "Memory exhaustion on large /8 expansion",
            "solution": "Use -sbc to split first: cat big.txt | mapcidr -sbc 256 | xargs ...",
        },
        {
            "error":    "mapcidr: command not found",
            "solution": "go install github.com/projectdiscovery/mapcidr/cmd/mapcidr@latest",
        },
    ],
    install          = "go install github.com/projectdiscovery/mapcidr/cmd/mapcidr@latest",
    typical_workflow = ["asnmap", "mapcidr", "fping", "Nmap"],
    integrations     = ["asnmap", "fping", "Nmap", "masscan"],
    tags             = ["cidr", "ip-range", "expand", "aggregate", "infrastructure"],
    reference_url    = "https://github.com/projectdiscovery/mapcidr",
)


ALTERX = ToolKnowledge(
    name        = "alterx",
    category    = "Attack Surface",
    passive     = True,
    description = (
        "alterx generates intelligent subdomain permutations from a seed list using "
        "configurable patterns. Instead of brute-forcing from a generic wordlist, it "
        "creates context-aware candidates like 'dev-api', 'api-staging', 'v2-internal' "
        "based on actual subdomains already discovered."
    ),
    how_it_works = (
        "alterx reads known subdomains from stdin, extracts meaningful word components "
        "from each (splitting on dots, dashes, and digits), then applies pattern templates "
        "to generate new candidates. The -enrich flag extracts words from the input list "
        "to use as permutation terms, making the output highly target-specific. Results "
        "should be piped to dnsx/puredns for resolution."
    ),
    use_cases = [
        "Generate targeted subdomain candidates after initial passive enumeration",
        "Discover environment variants: dev, stg, prod, uat versions of known subdomains",
        "Create wordlist-free brute-force list customised to the target's naming scheme",
        "Combine with puredns for fast resolution of permuted candidates",
    ],
    example_commands = [
        "cat subdomains.txt | alterx -enrich -silent",
        "echo 'api.example.com' | alterx -silent | dnsx -silent",
        "cat subs.txt | alterx -pattern '{{sub}}-{{word}}' -en prod,dev,stg",
        "subfinder -d example.com -silent | alterx -enrich | dnsx -silent",
    ],
    common_errors = [
        {
            "error":    "Too many permutations generated (OOM)",
            "solution": "Use -limit flag: cat subs.txt | alterx -limit 10000 -silent",
        },
        {
            "error":    "alterx: command not found",
            "solution": "go install github.com/projectdiscovery/alterx/cmd/alterx@latest",
        },
    ],
    install          = "go install github.com/projectdiscovery/alterx/cmd/alterx@latest",
    typical_workflow = ["Sublist3r", "Amass", "alterx", "puredns/dnsx", "HTTPX"],
    integrations     = ["dnsx", "puredns", "HTTPX", "Amass", "Subfinder"],
    tags             = ["subdomain", "permutation", "wordlist", "passive", "enrichment"],
    reference_url    = "https://github.com/projectdiscovery/alterx",
)


GITHUB_SUBDOMAINS_EXTENDED = ToolKnowledge(
    name        = "github-subdomains",
    category    = "Attack Surface",
    passive     = True,
    description = GITHUB_SUBDOMAINS.description,
    how_it_works = GITHUB_SUBDOMAINS.how_it_works,
    use_cases    = GITHUB_SUBDOMAINS.use_cases,
    example_commands = GITHUB_SUBDOMAINS.example_commands,
    common_errors    = GITHUB_SUBDOMAINS.common_errors,
    install          = GITHUB_SUBDOMAINS.install,
    typical_workflow = GITHUB_SUBDOMAINS.typical_workflow,
    integrations     = GITHUB_SUBDOMAINS.integrations,
    tags             = GITHUB_SUBDOMAINS.tags,
    reference_url    = GITHUB_SUBDOMAINS.reference_url,
)


# ─────────────────────────────────────────────────────────────────────────────
# HISTORICAL RECON
# ─────────────────────────────────────────────────────────────────────────────

WAYMORE = ToolKnowledge(
    name        = "waymore",
    category    = "Historical Recon",
    passive     = True,
    description = (
        "waymore aggregates historical web content from multiple archive sources: "
        "Wayback Machine, Common Crawl, URLScan.io, VirusTotal, and AlienVault OTX. "
        "More thorough than gau — queries all sources simultaneously and optionally "
        "downloads historical response bodies for content analysis."
    ),
    how_it_works = (
        "waymore queries each configured archive source's search API for all indexed "
        "URLs matching the target domain. Results are merged and deduplicated. In "
        "response mode (-mode R), waymore fetches the actual archived response bodies, "
        "enabling analysis of historical page content, leaked secrets, and removed endpoints."
    ),
    use_cases = [
        "Discover all historical endpoints before they were removed/secured",
        "Find backup files, config leaks, and debug endpoints that existed in the past",
        "Build comprehensive URL inventory for parameter discovery",
        "Download old JS files that may contain leaked API keys",
    ],
    example_commands = [
        "waymore -i example.com -mode U -p 10",
        "waymore -i example.com -mode R -oR responses/ -p 5",
        "waymore -i example.com -mode U -fc 200 -ft js,json",
        "waymore -i example.com -mode U | grep '\\.js$' | sort -u",
    ],
    common_errors = [
        {
            "error":    "waymore: command not found",
            "solution": "pip install waymore  or  git clone https://github.com/xnl-h4ck3r/waymore",
        },
        {
            "error":    "Response download mode extremely slow",
            "solution": "Use -mode U (URLs only) unless you specifically need content. Increase -p threads.",
        },
    ],
    install          = "pip install waymore",
    typical_workflow = ["gau", "waymore", "paramspider", "Arjun", "gospider"],
    integrations     = ["gau", "waybackurls", "paramspider", "Arjun", "katana"],
    tags             = ["historical", "passive", "url", "archive", "wayback", "commoncrawl"],
    reference_url    = "https://github.com/xnl-h4ck3r/waymore",
)

GAU_EXTENDED = ToolKnowledge(
    name        = "gau",
    category    = "Historical Recon",
    passive     = True,
    description = (
        "GetAllUrls (gau) fetches known URLs for a domain from multiple web archives: "
        "Wayback Machine, Common Crawl, OTX AlienVault, and URLScan.io. "
        "Fast and simple — the standard starting point for historical URL discovery."
    ),
    how_it_works = (
        "gau queries each archive's public API concurrently, collecting all known "
        "URLs for the target domain and its subdomains. Results are deduplicated and "
        "streamed to stdout. ReconX's CDX API fallback activates when the binary is absent."
    ),
    use_cases = [
        "Seed parameter discovery tools with historical URLs",
        "Find endpoints that no longer appear in sitemaps",
        "Discover old API versions still accessible",
        "Build attack surface inventory from archived history",
    ],
    example_commands = [
        "gau example.com --subs --retries 2",
        "gau example.com | grep '?'  # filter only parameterised URLs",
        "gau example.com | grep '\\.js$' | sort -u",
        "gau example.com --from 20200101 --to 20231231",
    ],
    common_errors = [
        {"error": "gau: command not found",
         "solution": "go install github.com/lc/gau/v2/cmd/gau@latest  (ReconX uses CDX fallback automatically)"},
        {"error": "Rate limited by Wayback Machine",
         "solution": "Use --retries 1 and reduce --threads. ReconX handles this automatically."},
    ],
    install          = "go install github.com/lc/gau/v2/cmd/gau@latest",
    typical_workflow = ["Subdomains", "gau", "waymore", "paramspider", "Arjun"],
    integrations     = ["waymore", "waybackurls", "paramspider", "katana", "gospider"],
    tags             = ["historical", "passive", "url", "archive", "wayback"],
    reference_url    = "https://github.com/lc/gau",
)

WAYBACKURLS_EXTENDED = ToolKnowledge(
    name        = "waybackurls",
    category    = "Historical Recon",
    passive     = True,
    description = (
        "waybackurls fetches all known URLs for a host from the Wayback Machine CDX API. "
        "Simple, focused, and reliable — pure Wayback Machine coverage with CDX API "
        "fallback when the binary is absent."
    ),
    how_it_works = (
        "waybackurls pipes a domain to the binary which queries Wayback's CDX search API "
        "with the wildcard pattern *.domain.com/*. The CDX API returns unique URLs "
        "collapsed by URL key. ReconX's pure-Python fallback uses the same CDX endpoint."
    ),
    use_cases = [
        "Quick historical URL discovery from Wayback Machine",
        "Complement gau with focused Wayback-only coverage",
        "Find historical file uploads and backup files",
        "Discover removed sensitive endpoints",
    ],
    example_commands = [
        "echo 'example.com' | waybackurls",
        "echo 'example.com' | waybackurls | grep '\\.php'",
        "cat domains.txt | waybackurls | sort -u > urls.txt",
    ],
    common_errors = [
        {"error": "waybackurls: command not found",
         "solution": "go install github.com/tomnomnom/waybackurls@latest  (ReconX CDX fallback activates automatically)"},
    ],
    install          = "go install github.com/tomnomnom/waybackurls@latest",
    typical_workflow = ["gau", "waybackurls", "waymore", "paramspider"],
    integrations     = ["gau", "waymore", "paramspider", "gospider"],
    tags             = ["historical", "passive", "url", "wayback", "cdx"],
    reference_url    = "https://github.com/tomnomnom/waybackurls",
)


# ─────────────────────────────────────────────────────────────────────────────
# URL DISCOVERY
# ─────────────────────────────────────────────────────────────────────────────

KATANA_EXTENDED = ToolKnowledge(
    name        = "katana",
    category    = "URL Discovery",
    passive     = False,
    description = (
        "katana is ProjectDiscovery's next-generation web crawler with built-in JavaScript "
        "parsing, headless browser support, and form filling. Discovers endpoints "
        "that static crawlers miss by rendering JS-heavy applications."
    ),
    how_it_works = (
        "katana starts from the seed URL and follows links recursively to the configured "
        "depth. With -jc (JavaScript crawling), it parses JS files for embedded URLs. "
        "With -headless, it uses Chrome to render SPAs and captures XHR requests. "
        "Scope is controlled with -fs (fqdn/rdn/dn/url) to prevent scope creep."
    ),
    use_cases = [
        "Crawl SPAs and React/Vue/Angular applications that static crawlers miss",
        "Extract API endpoints from JavaScript bundles",
        "Discover form action targets and AJAX endpoints",
        "Map authenticated application surfaces with cookie/header auth",
    ],
    example_commands = [
        "katana -u https://example.com -d 3 -jc -silent",
        "katana -u https://example.com -d 2 -headless -silent",
        "katana -u https://example.com -jc -d 5 -rl 100 -c 10",
        "katana -u https://example.com -jc -silent | grep 'api'",
    ],
    common_errors = [
        {"error": "Blank output on JS-heavy sites",
         "solution": "Add -headless flag for Chrome rendering of SPAs"},
        {"error": "katana: command not found",
         "solution": "go install github.com/projectdiscovery/katana/cmd/katana@latest"},
    ],
    install          = "go install github.com/projectdiscovery/katana/cmd/katana@latest",
    typical_workflow = ["gau", "waymore", "katana", "gospider", "paramspider"],
    integrations     = ["gospider", "hakrawler", "paramspider", "Arjun", "HTTPX"],
    tags             = ["url", "active", "crawler", "javascript", "spa", "headless"],
    reference_url    = "https://github.com/projectdiscovery/katana",
)

HAKRAWLER_EXTENDED = ToolKnowledge(
    name        = "hakrawler",
    category    = "URL Discovery",
    passive     = False,
    description = (
        "hakrawler is a fast Go-based web crawler that combines live crawling with "
        "Wayback Machine and Common Crawl archive queries. Extracts URLs, JS files, "
        "and links in a single unified pass."
    ),
    how_it_works = (
        "hakrawler takes a URL via stdin, crawls it recursively, and simultaneously "
        "queries Wayback Machine for additional historical URLs. It extracts links from "
        "HTML (a href, script src, form action) and reports all discovered URLs to stdout. "
        "Output is pipe-friendly: one URL per line."
    ),
    use_cases = [
        "Fast crawl + archive query in a single command",
        "Quick endpoint extraction for large numbers of targets",
        "Pipe output directly to other tools (httpx, nuclei, etc.)",
        "Subdomain link discovery when -subs flag is enabled",
    ],
    example_commands = [
        "echo 'https://example.com' | hakrawler",
        "echo 'https://example.com' | hakrawler -d 3 -subs",
        "cat urls.txt | hakrawler -d 2 | sort -u",
        "echo 'https://example.com' | hakrawler | grep '\\.js$'",
    ],
    common_errors = [
        {"error": "hakrawler: command not found",
         "solution": "go install github.com/hakluke/hakrawler@latest"},
        {"error": "No output for target",
         "solution": "Ensure URL includes scheme (https://). hakrawler requires stdin input."},
    ],
    install          = "go install github.com/hakluke/hakrawler@latest",
    typical_workflow = ["gau", "hakrawler", "katana", "gospider", "paramspider"],
    integrations     = ["katana", "gospider", "paramspider", "HTTPX"],
    tags             = ["url", "active", "crawler", "archive", "fast"],
    reference_url    = "https://github.com/hakluke/hakrawler",
)


# ─────────────────────────────────────────────────────────────────────────────
# PARAMETER DISCOVERY
# ─────────────────────────────────────────────────────────────────────────────

PARAMSPIDER = ToolKnowledge(
    name        = "paramspider",
    category    = "Parameter Discovery",
    passive     = True,
    description = (
        "ParamSpider mines URL parameters from web archives for a target domain, "
        "entirely passively — no traffic to the target. Produces parameterised URL "
        "templates with FUZZ placeholders ready for fuzzing tools."
    ),
    how_it_works = (
        "ParamSpider queries the Wayback Machine CDX API for all archived URLs of the "
        "target domain. It extracts unique parameter names from query strings, "
        "deduplicates them, and outputs URLs with parameter values replaced by FUZZ. "
        "These templates can be directly piped to ffuf or dalfox."
    ),
    use_cases = [
        "Discover hidden GET parameters without active scanning",
        "Generate FUZZ templates for XSS/SQLi testing",
        "Build parameter inventory for attack surface analysis",
        "Feed discovered params to Arjun for deeper parameter mining",
    ],
    example_commands = [
        "paramspider -d example.com --level high",
        "paramspider -d example.com --subs -q",
        "paramspider -d example.com | ffuf -w - -u FUZZ -mr 'error'",
        "paramspider -d example.com | dalfox pipe",
    ],
    common_errors = [
        {"error": "paramspider: command not found",
         "solution": "pip install paramspider  (ReconX uses Wayback CDX fallback automatically)"},
        {"error": "No parameters found",
         "solution": "Target may have minimal web archive history. Use gospider or katana instead."},
    ],
    install          = "pip install paramspider",
    typical_workflow = ["gau", "waymore", "paramspider", "Arjun", "gospider"],
    integrations     = ["Arjun", "gospider", "katana", "waymore", "gau"],
    tags             = ["parameter", "passive", "url", "fuzz", "archive"],
    reference_url    = "https://github.com/devanshbatham/ParamSpider",
)

ARJUN_EXTENDED = ToolKnowledge(
    name        = "Arjun",
    category    = "Parameter Discovery",
    passive     = False,
    description = (
        "Arjun actively discovers hidden HTTP parameters by fuzzing endpoints with "
        "a large built-in wordlist and detecting differences in server responses. "
        "Finds GET, POST, JSON, and XML parameters that passive methods miss."
    ),
    how_it_works = (
        "Arjun sends requests with different parameter combinations and compares "
        "response length, status code, and content to detect which parameters "
        "produce unique server behaviour. Uses a chunked approach (large batches "
        "then bisection) to minimize requests. Supports multiple HTTP methods."
    ),
    use_cases = [
        "Find hidden debug/admin parameters (debug=1, verbose=true, internal=1)",
        "Discover IDOR-vulnerable ID parameters not shown in the UI",
        "Identify undocumented API parameters",
        "Complement passive param discovery with active verification",
    ],
    example_commands = [
        "arjun -u https://example.com/api/users",
        "arjun -u https://example.com/search --stable -m GET,POST",
        "arjun -i urls.txt --stable -t 10",
        "arjun -u https://api.example.com/v1/data -m JSON",
    ],
    common_errors = [
        {"error": "arjun: command not found",
         "solution": "pip install arjun"},
        {"error": "Too many false positives",
         "solution": "Use --stable flag: arjun -u URL --stable"},
    ],
    install          = "pip install arjun",
    typical_workflow = ["paramspider", "gospider", "Arjun", "Report"],
    integrations     = ["paramspider", "gospider", "katana", "waymore"],
    tags             = ["parameter", "active", "fuzzing", "api", "hidden-params"],
    reference_url    = "https://github.com/s0md3v/Arjun",
)

GOSPIDER = ToolKnowledge(
    name        = "gospider",
    category    = "Parameter Discovery",
    passive     = False,
    description = (
        "gospider is a fast recursive web spider that extracts URLs, endpoints, "
        "JS files, and forms from a target application. Combines live crawling with "
        "Wayback Machine integration and JavaScript link extraction."
    ),
    how_it_works = (
        "gospider starts from the seed URL, follows links recursively, and "
        "extracts all URLs from HTML, JavaScript, and comments. It can optionally "
        "pull additional URLs from the Wayback Machine. A linkfinder component "
        "extracts URLs embedded in JS files via regex patterns."
    ),
    use_cases = [
        "Full endpoint discovery including JS-embedded routes",
        "Form action and API endpoint extraction",
        "Feed discovered URLs into Arjun for parameter testing",
        "Build comprehensive URL map for testing scope",
    ],
    example_commands = [
        "gospider -s https://example.com -d 2 --js --sitemap",
        "gospider -s https://example.com -d 3 -c 5 -t 20 --wayback",
        "gospider -s https://example.com --quiet | grep 'api'",
        "gospider -S urls.txt -d 2 --js  # batch mode",
    ],
    common_errors = [
        {"error": "gospider: command not found",
         "solution": "go install github.com/jaeles-project/gospider@latest"},
        {"error": "Scope creep — too many external URLs",
         "solution": "Add --include-subs=false and review --blacklist patterns"},
    ],
    install          = "go install github.com/jaeles-project/gospider@latest",
    typical_workflow = ["katana", "gospider", "hakrawler", "paramspider", "Arjun"],
    integrations     = ["katana", "hakrawler", "paramspider", "Arjun", "HTTPX"],
    tags             = ["url", "active", "crawler", "spider", "javascript", "forms"],
    reference_url    = "https://github.com/jaeles-project/gospider",
)


# ─────────────────────────────────────────────────────────────────────────────
# Registry
# ─────────────────────────────────────────────────────────────────────────────

STAGE122_TOOL_KNOWLEDGE = [
    GITHUB_SUBDOMAINS,
    ASNMAP,
    MAPCIDR,
    ALTERX,
    WAYMORE,
    GAU_EXTENDED,
    WAYBACKURLS_EXTENDED,
    KATANA_EXTENDED,
    HAKRAWLER_EXTENDED,
    PARAMSPIDER,
    ARJUN_EXTENDED,
    GOSPIDER,
]

# New category names for the learning mode UI
STAGE122_CATEGORIES = [
    "Attack Surface",
    "Historical Recon",
    "URL Discovery",
    "Parameter Discovery",
]


def get_stage122_by_category(category: str) -> list[ToolKnowledge]:
    return [t for t in STAGE122_TOOL_KNOWLEDGE if t.category == category]


def search_stage122(query: str) -> list[ToolKnowledge]:
    q = query.lower()
    return [
        t for t in STAGE122_TOOL_KNOWLEDGE
        if q in t.name.lower() or q in t.description.lower()
        or any(q in tag for tag in t.tags)
    ]
