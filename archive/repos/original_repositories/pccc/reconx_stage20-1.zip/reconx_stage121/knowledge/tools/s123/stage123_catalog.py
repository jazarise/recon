"""
ReconX — Learning Mode Knowledge Catalog (Stage 12.3).

Covers all Stage 12.3 tools across 8 categories:
  DNS Intelligence | Screenshot Intelligence | API Recon
  Secret Intelligence | Cloud Recon | Certificate Intelligence
  Fingerprinting | Identity Intelligence
"""
from __future__ import annotations

try:
    from reconx.knowledge.tools.stage121_catalog import ToolKnowledge
except ModuleNotFoundError:
    from knowledge.tools.stage121_catalog import ToolKnowledge


# ── DNS INTELLIGENCE ──────────────────────────────────────────────────────────

MASSDNS = ToolKnowledge(
    name="massdns", category="DNS Intelligence",
    description="High-performance stub DNS resolver that resolves millions of domains per second using a list of public resolvers. Core tool for validating large subdomain lists.",
    how_it_works="massdns sends concurrent DNS queries to hundreds of public resolvers simultaneously using asynchronous I/O. Results are written in multiple formats (simple text, JSON, NDJSON). Handles retries and timeouts per query.",
    use_cases=["Validate 100k+ subdomains in minutes", "Resolve alterx permutation lists", "Extract live hosts from large CIDR ranges", "Feed into shuffledns/puredns pipelines"],
    example_commands=["massdns -r resolvers.txt -t A domains.txt -o S", "cat subs.txt | massdns -r resolvers.txt -t A -o J", "massdns -r resolvers.txt -t A,CNAME subs.txt -o S -w out.txt"],
    common_errors=[
        {"error": "Segfault on large input", "solution": "Reduce --parallel-min or use puredns which wraps massdns more safely"},
        {"error": "massdns: command not found", "solution": "git clone https://github.com/blechschmidt/massdns && cd massdns && make"},
    ],
    install="git clone https://github.com/blechschmidt/massdns && cd massdns && make && sudo cp bin/massdns /usr/local/bin/",
    typical_workflow=["alterx", "massdns", "httpx", "eyewitness"],
    integrations=["shuffledns", "puredns", "alterx", "HTTPX"],
    tags=["dns", "active", "resolution", "mass", "validation"],
    reference_url="https://github.com/blechschmidt/massdns",
)

SHUFFLEDNS = ToolKnowledge(
    name="shuffledns", category="DNS Intelligence",
    description="Wrapper around massdns that adds wildcard detection and filtering. Resolves subdomain lists at scale while automatically removing wildcard false positives.",
    how_it_works="shuffledns generates random subdomains per domain to detect wildcard DNS responses, then filters matching IPs from real results. Uses massdns for the actual resolution with configurable resolver lists and retry logic.",
    use_cases=["Brute-force subdomains with wildcard safety", "Validate and filter enumeration tool output", "Resolve permutation lists from alterx", "Build authoritative subdomain inventory"],
    example_commands=["shuffledns -d example.com -w subs.txt -r resolvers.txt", "shuffledns -d example.com -list known_subs.txt -r resolvers.txt", "cat subs.txt | shuffledns -d example.com -r resolvers.txt -silent"],
    common_errors=[
        {"error": "shuffledns: command not found", "solution": "go install github.com/projectdiscovery/shuffledns/cmd/shuffledns@latest"},
        {"error": "massdns not found", "solution": "shuffledns requires massdns binary — install massdns first"},
    ],
    install="go install github.com/projectdiscovery/shuffledns/cmd/shuffledns@latest",
    typical_workflow=["alterx", "shuffledns", "HTTPX", "gowitness"],
    integrations=["massdns", "puredns", "alterx", "HTTPX"],
    tags=["dns", "active", "wildcard", "validation", "mass"],
    reference_url="https://github.com/projectdiscovery/shuffledns",
)

PUREDNS = ToolKnowledge(
    name="puredns", category="DNS Intelligence",
    description="High-accuracy domain resolver using a two-phase approach: mass resolution via public resolvers, then trusted-resolver verification. Industry-standard for accurate subdomain validation.",
    how_it_works="Phase 1: resolves all domains via a large public resolver list (fast, some inaccuracy). Phase 2: re-resolves hits via trusted resolvers (8.8.8.8, 1.1.1.1) to eliminate false positives. Wildcard detection runs between phases.",
    use_cases=["Final validation step after all enumeration tools", "Bruteforce with highest possible accuracy", "Filter wildcard domains from combined tool output", "Build ground-truth subdomain list"],
    example_commands=["puredns bruteforce wordlist.txt example.com -r resolvers.txt", "puredns resolve subs.txt -r resolvers.txt", "puredns bruteforce best-dns-wordlist.txt example.com --rate-limit 3000"],
    common_errors=[
        {"error": "puredns: command not found", "solution": "go install github.com/d3mondev/puredns/v2@latest"},
        {"error": "massdns not found", "solution": "puredns requires massdns — install massdns first then puredns"},
    ],
    install="go install github.com/d3mondev/puredns/v2@latest  # massdns also required",
    typical_workflow=["Sublist3r", "alterx", "puredns", "HTTPX", "gowitness"],
    integrations=["massdns", "shuffledns", "alterx", "HTTPX"],
    tags=["dns", "active", "validation", "wildcard", "accurate"],
    reference_url="https://github.com/d3mondev/puredns",
)


# ── SCREENSHOT INTELLIGENCE ───────────────────────────────────────────────────

AQUATONE = ToolKnowledge(
    name="aquatone", category="Screenshot Intelligence",
    description="Web screenshot tool that captures pages, clusters visually similar results, and generates an interactive HTML report. Excellent for triaging large numbers of web services by visual similarity.",
    how_it_works="Aquatone pipes URLs through a headless Chrome instance, captures screenshots, extracts page titles and headers, and groups pages by visual fingerprint similarity. Output is a browsable HTML report with clustered results.",
    use_cases=["Triage 1000+ web services from a port scan visually", "Identify login pages and admin panels quickly", "Group similar-looking pages (default creds, custom apps)", "Generate visual reports for pentest clients"],
    example_commands=["cat urls.txt | aquatone -out screenshots/", "cat hosts.txt | aquatone -ports large -out out/", "nmap -oX scan.xml ... && cat scan.xml | aquatone -nmap"],
    common_errors=[
        {"error": "Chrome not found", "solution": "sudo apt install chromium-browser && export CHROMIUM_PATH=$(which chromium-browser)"},
        {"error": "aquatone: command not found", "solution": "Download from: https://github.com/michenriksen/aquatone/releases"},
    ],
    install="Download binary from github.com/michenriksen/aquatone/releases",
    typical_workflow=["Port Scan", "HTTPX", "aquatone", "gowitness", "Report"],
    integrations=["gowitness", "HTTPX", "EyeWitness", "Nmap"],
    tags=["screenshot", "active", "visual", "clustering", "triage"],
    reference_url="https://github.com/michenriksen/aquatone",
)

GOWITNESS = ToolKnowledge(
    name="gowitness", category="Screenshot Intelligence",
    description="Modern Go-based web screenshot tool with SQLite storage, HTML reporting, and support for Nmap/Nessus XML input. Faster and more maintainable than aquatone for large-scale use.",
    how_it_works="gowitness uses Chrome/Chromium in headless mode to render pages and capture screenshots. Results are stored in a SQLite database for querying. Supports concurrent workers and generates searchable HTML reports.",
    use_cases=["Screenshot all HTTP/HTTPS services discovered in a scan", "Build web service inventory with titles and status codes", "Query screenshots by title, technology, or status code", "Import Nmap XML output for automated screenshotting"],
    example_commands=["gowitness file -f urls.txt --screenshot-path shots/", "gowitness single https://example.com", "gowitness nmap -f scan.xml --open --service http", "gowitness report generate --screenshot-path shots/"],
    common_errors=[
        {"error": "gowitness: command not found", "solution": "go install github.com/sensepost/gowitness@latest"},
        {"error": "Chrome/Chromium not found", "solution": "sudo apt install chromium  and ensure it's in PATH"},
    ],
    install="go install github.com/sensepost/gowitness@latest",
    typical_workflow=["Port Scan", "HTTPX", "gowitness", "aquatone", "Report"],
    integrations=["aquatone", "HTTPX", "EyeWitness", "Nmap"],
    tags=["screenshot", "active", "sqlite", "inventory", "visual"],
    reference_url="https://github.com/sensepost/gowitness",
)


# ── API RECON ─────────────────────────────────────────────────────────────────

KITERUNNER = ToolKnowledge(
    name="kiterunner", category="API Recon",
    description="Context-aware API route discovery tool that replays real API requests from Swagger/OpenAPI-derived wordlists. Far more accurate than directory brute-forcing for API endpoints.",
    how_it_works="Kiterunner uses .kite files containing real API routes extracted from public Swagger specs. Unlike generic fuzzers, it sends requests with correct methods, headers, and payloads per route type. Reduces false positives dramatically.",
    use_cases=["Discover undocumented API routes on REST APIs", "Find API versions (v1, v2, v3) and deprecated endpoints", "Map microservice API surfaces", "Identify exposed internal API routes"],
    example_commands=["kr scan https://api.example.com -w routes-large.kite", "kr scan https://api.example.com -w routes-large.kite -x 20 -j", "kr scan file://urls.txt -w routes-small.kite --timeout 3"],
    common_errors=[
        {"error": "kr: command not found", "solution": "go install github.com/assetnote/kiterunner/cmd/kr@latest"},
        {"error": "No .kite routes file", "solution": "Download from: https://github.com/assetnote/kiterunner#wordlists"},
    ],
    install="go install github.com/assetnote/kiterunner/cmd/kr@latest",
    typical_workflow=["Port Scan", "HTTPX", "kiterunner", "Arjun", "Report"],
    integrations=["Arjun", "HTTPX", "gospider", "katana"],
    tags=["api", "active", "routes", "openapi", "swagger"],
    reference_url="https://github.com/assetnote/kiterunner",
)

GRAPHW00F = ToolKnowledge(
    name="graphw00f", category="API Recon",
    description="GraphQL server fingerprinting tool that detects GraphQL endpoints, identifies the underlying implementation (Apollo, Hasura, Graphene, etc.), and checks for dangerous features like introspection.",
    how_it_works="graphw00f probes common GraphQL paths with an introspection query and analyses the response structure, error messages, and headers to fingerprint the server implementation. 17 GraphQL engine fingerprints built-in.",
    use_cases=["Detect GraphQL APIs on discovered web services", "Identify GraphQL engine for targeted testing", "Check if introspection is enabled (schema exposure)", "Find debug/playground interfaces"],
    example_commands=["graphw00f -t https://example.com -f", "graphw00f -t https://api.example.com -d  # detect only", "graphw00f -t https://example.com -f -o json"],
    common_errors=[
        {"error": "graphw00f: command not found", "solution": "pip install graphw00f  (ReconX uses HTTP probe fallback automatically)"},
        {"error": "No GraphQL detected", "solution": "Try non-standard paths: /api, /query, /gql. Use kiterunner for broader route discovery first."},
    ],
    install="pip install graphw00f",
    typical_workflow=["HTTPX", "kiterunner", "graphw00f", "Arjun", "Report"],
    integrations=["kiterunner", "HTTPX", "Arjun"],
    tags=["api", "active", "graphql", "fingerprint", "introspection"],
    reference_url="https://github.com/dolevf/graphw00f",
)


# ── SECRET INTELLIGENCE ───────────────────────────────────────────────────────

TRUFFLEHOG = ToolKnowledge(
    name="trufflehog", category="Secret Intelligence",
    description="Secret scanner with 700+ built-in detectors that finds and verifies credentials in git repos, filesystems, S3, and other sources. v3 actually verifies secrets are live before reporting.",
    how_it_works="TruffleHog scans content using regex detectors for each credential type, then makes authenticated API calls to verify whether found credentials are still valid. Only verified secrets are reported by default, dramatically reducing false positives.",
    use_cases=["Find live AWS/GCP/GitHub credentials in public repos", "Scan target's public GitHub org for leaked secrets", "Audit your own code before it goes public", "Investigate exposed S3 buckets for credential files"],
    example_commands=["trufflehog github --org=targetorg --only-verified", "trufflehog git https://github.com/org/repo --only-verified", "trufflehog filesystem /path/to/code --no-verification", "trufflehog s3 --bucket=bucket-name"],
    common_errors=[
        {"error": "trufflehog: command not found", "solution": "curl -sSfL https://raw.githubusercontent.com/trufflesecurity/trufflehog/main/scripts/install.sh | sh"},
        {"error": "Verification errors / slow", "solution": "Use --no-verification for speed, then manually verify interesting findings"},
    ],
    install="curl -sSfL https://raw.githubusercontent.com/trufflesecurity/trufflehog/main/scripts/install.sh | sh -s -- -b /usr/local/bin",
    typical_workflow=["github-subdomains", "trufflehog", "gitleaks", "Report"],
    integrations=["gitleaks", "github-subdomains", "S3Scanner"],
    tags=["secrets", "passive", "git", "credentials", "verification"],
    reference_url="https://github.com/trufflesecurity/trufflehog",
)

GITLEAKS = ToolKnowledge(
    name="gitleaks", category="Secret Intelligence",
    description="Fast git secret scanner using regex rules and entropy analysis. Scans entire git history, not just the current state. Integrates as a pre-commit hook to prevent secrets from being committed.",
    how_it_works="gitleaks walks the git commit graph, applies regex rules to each blob, and flags matches. Custom rules can be added via TOML config. Unlike TruffleHog, it doesn't verify secrets but scans faster and with configurable rule sets.",
    use_cases=["Scan full git history of a target's public repos", "Pre-commit hook to block secret commits", "Audit internal codebases for credential leaks", "CI/CD integration for continuous secret scanning"],
    example_commands=["gitleaks detect --source . -v", "gitleaks detect --source /path/to/repo --log-opts '--all'", "gitleaks git https://github.com/org/repo", "gitleaks detect -c custom-rules.toml"],
    common_errors=[
        {"error": "gitleaks: command not found", "solution": "go install github.com/gitleaks/gitleaks/v8@latest  or  brew install gitleaks"},
        {"error": "Many false positives", "solution": "Add false_positives to .gitleaks.toml or use --redact and triage manually"},
    ],
    install="go install github.com/gitleaks/gitleaks/v8@latest",
    typical_workflow=["github-subdomains", "gitleaks", "trufflehog", "Report"],
    integrations=["trufflehog", "github-subdomains"],
    tags=["secrets", "passive", "git", "credentials", "regex"],
    reference_url="https://github.com/gitleaks/gitleaks",
)


# ── CLOUD RECON ───────────────────────────────────────────────────────────────

S3SCANNER = ToolKnowledge(
    name="s3scanner", category="Cloud Recon",
    description="Scans S3-compatible storage buckets for public access and misconfiguration. Tests AWS S3, GCP GCS, Azure Blob Storage, DigitalOcean Spaces, and others for listing, read, and write access.",
    how_it_works="s3scanner probes a list of bucket names via HTTP and cloud SDK calls, checking for public/private status, object listing ability, and write access. Generates bucket name candidates from the target domain automatically.",
    use_cases=["Discover publicly accessible cloud storage buckets", "Check for listable or writable bucket misconfigs", "Test common bucket naming patterns for a target org", "Enumerate objects in publicly accessible buckets"],
    example_commands=["s3scanner scan --bucket-file buckets.txt --json", "s3scanner scan --bucket target-company-backup", "echo 'targetcompany' | s3scanner scan --bucket-file /dev/stdin"],
    common_errors=[
        {"error": "s3scanner: command not found", "solution": "pip install s3scanner  (ReconX uses HTTP probe fallback automatically)"},
        {"error": "Access denied on all buckets", "solution": "Buckets exist but are private — still valuable intel. Document the bucket names."},
    ],
    install="pip install s3scanner  # or: go install github.com/sa7mon/s3scanner@latest",
    typical_workflow=["github-subdomains", "s3scanner", "trufflehog", "Report"],
    integrations=["trufflehog", "github-subdomains", "AsnmapTool"],
    tags=["cloud", "passive", "s3", "bucket", "misconfiguration"],
    reference_url="https://github.com/sa7mon/s3scanner",
)


# ── CERTIFICATE INTELLIGENCE ──────────────────────────────────────────────────

CRTSH = ToolKnowledge(
    name="crt.sh", category="Certificate Intelligence",
    passive=True,
    description="Queries the crt.sh certificate transparency log aggregator for all SSL/TLS certificates issued for a domain, discovering subdomains from certificate Subject Alternative Names. Entirely passive.",
    how_it_works="crt.sh indexes certificate transparency logs from all major CAs. ReconX queries its JSON API for wildcard matches (%.domain.com), extracts all SAN entries from returned certificates, and deduplicates the subdomain list.",
    use_cases=["Passive subdomain discovery with zero target traffic", "Find old/expired certificates revealing decommissioned subdomains", "Discover internal names accidentally included in SANs", "Validate subdomain inventory from other tools"],
    example_commands=["curl 'https://crt.sh/?q=%.example.com&output=json' | jq '.[].name_value'", "# ReconX uses this API automatically with deduplication"],
    common_errors=[
        {"error": "crt.sh timeout/rate limit", "solution": "Retry after a few minutes. crt.sh is a free public service."},
        {"error": "Many wildcard entries", "solution": "Filter *.example.com entries — they indicate wildcard certs, not real subdomains"},
    ],
    install="No installation required — uses crt.sh public API",
    typical_workflow=["WHOIS", "crt.sh", "Sublist3r", "puredns", "HTTPX"],
    integrations=["tlsx", "Sublist3r", "puredns", "HTTPX"],
    tags=["certificate", "passive", "subdomain", "ct-logs", "san"],
    reference_url="https://crt.sh/",
)

TLSX = ToolKnowledge(
    name="tlsx", category="Certificate Intelligence",
    description="Fast TLS data extraction tool that grabs certificate info, cipher suites, TLS versions, and JARM fingerprints from live hosts. Discovers additional subdomains from certificate SANs.",
    how_it_works="tlsx connects to target hosts on TLS ports, completes the TLS handshake, and extracts structured data from the server certificate and TLS negotiation. JARM mode generates a unique fingerprint for server TLS configuration.",
    use_cases=["Extract SAN names from live certificates for subdomain discovery", "Identify outdated TLS versions (TLS 1.0/1.1)", "Generate JARM fingerprints for infrastructure correlation", "Audit cipher suite strength across discovered hosts"],
    example_commands=["tlsx -host example.com -json -san -cn", "cat hosts.txt | tlsx -json -silent", "tlsx -host example.com -jarm  # JARM fingerprint", "cat cidrs.txt | tlsx -port 443,8443 -san -silent"],
    common_errors=[
        {"error": "tlsx: command not found", "solution": "go install github.com/projectdiscovery/tlsx/cmd/tlsx@latest  (ReconX uses Python ssl fallback)"},
        {"error": "Connection refused", "solution": "Host may not serve TLS on port 443. Try -port 8443,8080"},
    ],
    install="go install github.com/projectdiscovery/tlsx/cmd/tlsx@latest",
    typical_workflow=["crt.sh", "tlsx", "testssl", "HTTPX", "Report"],
    integrations=["crt.sh", "testssl", "HTTPX", "Nmap"],
    tags=["tls", "active", "certificate", "jarm", "cipher", "san"],
    reference_url="https://github.com/projectdiscovery/tlsx",
)


# ── FINGERPRINTING ────────────────────────────────────────────────────────────

WAFW00F = ToolKnowledge(
    name="wafw00f", category="Fingerprinting",
    description="WAF detection and fingerprinting tool that identifies 160+ Web Application Firewall products by analysing HTTP responses to crafted requests. Essential for understanding target defences.",
    how_it_works="wafw00f sends normal and crafted HTTP requests to the target, then analyses response headers, cookies, body content, and status codes against a database of 160+ WAF signatures. Multiple bypass techniques are tested if initial detection fails.",
    use_cases=["Determine if a WAF is protecting the target", "Identify which WAF product to bypass during testing", "Adjust testing strategy based on WAF presence", "Document security controls for reports"],
    example_commands=["wafw00f https://example.com", "wafw00f https://example.com -a  # test all WAFs", "wafw00f https://example.com -o json -f json"],
    common_errors=[
        {"error": "wafw00f: command not found", "solution": "pip install wafw00f  (ReconX uses HTTP header probe fallback)"},
        {"error": "No WAF detected but site behaves strangely", "solution": "WAF may use custom signatures. Try -a flag for comprehensive testing."},
    ],
    install="pip install wafw00f",
    typical_workflow=["HTTPX", "wafw00f", "testssl", "nikto", "Report"],
    integrations=["testssl", "nikto", "HTTPX"],
    tags=["waf", "active", "fingerprint", "defence", "bypass"],
    reference_url="https://github.com/EnableSecurity/wafw00f",
)

TESTSSL = ToolKnowledge(
    name="testssl.sh", category="Fingerprinting",
    description="Comprehensive TLS/SSL configuration auditor that tests for 100+ vulnerabilities: POODLE, BEAST, HEARTBLEED, weak ciphers, outdated protocols, certificate issues, and HSTS. The industry standard.",
    how_it_works="testssl.sh is a bash script that uses OpenSSL to probe the target's TLS implementation. It tests each protocol version, cipher suite, and known vulnerability by attempting the actual exploit handshake and observing server behaviour.",
    use_cases=["Complete TLS security audit for pentest reports", "Identify outdated protocols (SSLv2/3, TLS 1.0/1.1)", "Find vulnerable cipher suites (RC4, NULL, EXPORT)", "Detect HEARTBLEED, POODLE, ROBOT vulnerabilities"],
    example_commands=["testssl.sh example.com", "testssl.sh --fast --quiet example.com", "testssl.sh --full example.com:8443", "testssl.sh --severity HIGH example.com"],
    common_errors=[
        {"error": "testssl.sh: command not found", "solution": "git clone https://github.com/drwetter/testssl.sh && sudo ln -s $(pwd)/testssl.sh/testssl.sh /usr/local/bin/testssl.sh"},
        {"error": "OpenSSL version too old", "solution": "testssl.sh includes its own OpenSSL binary — use the bundled version"},
    ],
    install="git clone --depth 1 https://github.com/drwetter/testssl.sh.git",
    typical_workflow=["tlsx", "testssl", "wafw00f", "Report"],
    integrations=["tlsx", "wafw00f", "Nmap"],
    tags=["tls", "ssl", "active", "vulnerability", "cipher", "audit"],
    reference_url="https://testssl.sh/",
)


# ── IDENTITY INTELLIGENCE ─────────────────────────────────────────────────────

SHERLOCK = ToolKnowledge(
    name="sherlock", category="Identity Intelligence",
    passive=True,
    description="Hunts usernames across 400+ social networks and platforms. Given a username, finds all accounts registered under that name for identity correlation and OSINT investigations.",
    how_it_works="Sherlock sends HTTP requests to each platform's profile URL pattern and checks whether a profile exists based on response code, redirect behaviour, and page content. Custom response codes and patterns per site are defined in a JSON database.",
    use_cases=["Find all accounts associated with a target username", "Correlate usernames from leaked databases across platforms", "Build a complete social footprint for OSINT reports", "Identify target's online presence and behaviour patterns"],
    example_commands=["sherlock targetusername", "sherlock targetusername --timeout 10 --print-found", "sherlock user1 user2 user3  # batch mode", "sherlock targetusername --site twitter --site github"],
    common_errors=[
        {"error": "sherlock: command not found", "solution": "pip install sherlock-project  (ReconX uses HTTP probe fallback for 15 key platforms)"},
        {"error": "Many false positives", "solution": "Verify manually — some platforms return 200 for non-existent users"},
    ],
    install="pip install sherlock-project",
    typical_workflow=["theHarvester", "OSRFramework", "sherlock", "holehe", "Report"],
    integrations=["holehe", "OSRFramework", "theHarvester"],
    tags=["identity", "passive", "username", "social", "osint"],
    reference_url="https://github.com/sherlock-project/sherlock",
)

HOLEHE = ToolKnowledge(
    name="holehe", category="Identity Intelligence",
    passive=True,
    description="Checks whether an email address is registered on 120+ websites using password-reset flow probing. Maps email addresses to online accounts without triggering logins.",
    how_it_works="holehe uses each site's password reset API endpoint, which reveals whether an email is registered without requiring authentication. It checks the response for email-registered vs not-registered indicators without actually resetting the password.",
    use_cases=["Map an email address to registered accounts", "Correlate discovered emails to social profiles", "Check if a corporate email is registered on risky services", "Build complete identity profile from a single email"],
    example_commands=["holehe target@example.com", "holehe target@example.com --only-used", "holehe target@example.com --timeout 5"],
    common_errors=[
        {"error": "holehe: command not found", "solution": "pip install holehe"},
        {"error": "Rate limited by sites", "solution": "Use --timeout 15 and run at off-peak hours"},
    ],
    install="pip install holehe",
    typical_workflow=["theHarvester", "sherlock", "holehe", "SpiderFoot", "Report"],
    integrations=["sherlock", "theHarvester", "OSRFramework"],
    tags=["identity", "passive", "email", "accounts", "osint"],
    reference_url="https://github.com/megadose/holehe",
)

PHONEINFOGA = ToolKnowledge(
    name="phoneinfoga", category="Identity Intelligence",
    passive=True,
    description="Gathers intelligence about phone numbers including carrier, country, line type, and OSINT lookups across multiple data sources. Useful for correlating phone numbers found during OSINT.",
    how_it_works="PhoneInfoga validates the number format, queries carrier lookup APIs (numverify, etc.), and optionally searches Google/social networks for the number. Results include country, carrier, line type (mobile/landline), and social profile links.",
    use_cases=["Identify carrier and country for discovered phone numbers", "Search for social profiles linked to a phone number", "Validate phone numbers from target profiles", "Corporate recon: map phone extensions to employees"],
    example_commands=["phoneinfoga scan -n +14155552671", "phoneinfoga scan -n +44... --scanner numverify", "phoneinfoga serve  # launch web UI on localhost:5000"],
    common_errors=[
        {"error": "phoneinfoga: command not found", "solution": "go install github.com/sundowndev/phoneinfoga/v2/cmd/phoneinfoga@latest"},
        {"error": "No API key for numverify", "solution": "numverify scanner requires API key. Use --scanner googlesearch for keyless operation"},
    ],
    install="go install github.com/sundowndev/phoneinfoga/v2/cmd/phoneinfoga@latest",
    typical_workflow=["theHarvester", "OSRFramework", "phoneinfoga", "sherlock"],
    integrations=["sherlock", "holehe", "OSRFramework"],
    tags=["identity", "passive", "phone", "carrier", "osint"],
    reference_url="https://github.com/sundowndev/phoneinfoga",
)


# ── Registry ──────────────────────────────────────────────────────────────────

STAGE123_TOOL_KNOWLEDGE = [
    MASSDNS, SHUFFLEDNS, PUREDNS,
    AQUATONE, GOWITNESS,
    KITERUNNER, GRAPHW00F,
    TRUFFLEHOG, GITLEAKS,
    S3SCANNER,
    CRTSH, TLSX,
    WAFW00F, TESTSSL,
    SHERLOCK, HOLEHE, PHONEINFOGA,
]

STAGE123_CATEGORIES = [
    "DNS Intelligence", "Screenshot Intelligence", "API Recon",
    "Secret Intelligence", "Cloud Recon", "Certificate Intelligence",
    "Fingerprinting", "Identity Intelligence",
]


def get_stage123_by_category(category: str) -> list[ToolKnowledge]:
    return [t for t in STAGE123_TOOL_KNOWLEDGE if t.category == category]


def search_stage123(query: str) -> list[ToolKnowledge]:
    q = query.lower()
    return [t for t in STAGE123_TOOL_KNOWLEDGE
            if q in t.name.lower() or q in t.description.lower()
            or any(q in tag for tag in t.tags)]
