"""
ReconX — Learning Mode Knowledge Catalog (Stage 12.1 expansion).

Each entry is a ToolKnowledge dataclass consumed by the LearningMode
engine to render interactive tool lessons, practice mode, and workflows.

Structure mirrors the existing knowledge/ directory pattern.
All 10 new tools from Stage 12.1 are covered here.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class ToolKnowledge:
    name:            str
    category:        str            # maps to LearningMode category tabs
    description:     str
    how_it_works:    str
    use_cases:       list[str]
    example_commands: list[str]
    common_errors:   list[dict]     # [{"error": str, "solution": str}]
    install:         str
    typical_workflow: list[str]     # ordered list of before/after tools
    integrations:    list[str]      # related ReconX tools
    tags:            list[str]      # for search
    passive:         bool = False
    requires_root:   bool = False
    reference_url:   Optional[str] = None


# ─────────────────────────────────────────────────────────────────────────────
# PASSIVE RECON
# ─────────────────────────────────────────────────────────────────────────────

THEHARVESTER = ToolKnowledge(
    name        = "theHarvester",
    category    = "Passive Recon",
    passive     = True,
    description = (
        "theHarvester aggregates public intelligence about a target domain from "
        "search engines, certificate transparency logs, DNS databases, and other "
        "open sources. It finds emails, subdomains, employee names, and IPs without "
        "touching the target directly."
    ),
    how_it_works = (
        "theHarvester sends queries to configured data sources (Google, Bing, Shodan, "
        "VirusTotal, CRT.sh, DNSdumpster, etc.) using their public search APIs or web "
        "scraping. Results are aggregated, deduplicated, and optionally resolved via DNS. "
        "No packets are sent to the target."
    ),
    use_cases = [
        "Discover email addresses for phishing awareness assessments",
        "Find subdomains without active scanning",
        "Map employee names / LinkedIn exposure",
        "Build target asset inventory in early recon phase",
    ],
    example_commands = [
        "theHarvester -d example.com -b google,bing,crtsh -l 500",
        "theHarvester -d example.com -b all -l 200 -f report",
        "theHarvester -d example.com -b dnsdumpster,virustotal -n",  # -n: DNS resolve
    ],
    common_errors = [
        {
            "error":    "Rate limited by Google / Bing",
            "solution": "Use -b bing,crtsh,dnsdumpster instead, or add delays between runs",
        },
        {
            "error":    "API key errors for Shodan/Hunter",
            "solution": "Add API keys to ~/.config/theHarvester/api-keys.yaml",
        },
        {
            "error":    "No results returned",
            "solution": "Target may have low public exposure. Try -b all and increase -l limit",
        },
    ],
    install          = "sudo apt install theharvester  # Kali: pre-installed",
    typical_workflow = ["WHOIS", "theHarvester", "Sublist3r", "DNSRecon", "Port Scan"],
    integrations     = ["Sublist3r", "SpiderFoot", "Amass", "DNSRecon"],
    tags             = ["osint", "passive", "email", "subdomain", "dns"],
    reference_url    = "https://github.com/laramies/theHarvester",
)


SPIDERFOOT = ToolKnowledge(
    name        = "SpiderFoot",
    category    = "Passive Recon",
    passive     = True,
    description = (
        "SpiderFoot is an automated OSINT framework that queries 200+ data sources "
        "to build a comprehensive intelligence picture of a target. It correlates "
        "domains, IPs, emails, breach data, social profiles, and more."
    ),
    how_it_works = (
        "SpiderFoot runs a configurable set of modules (sfp_*) that query public APIs, "
        "search engines, WHOIS services, threat intel feeds, and data brokers. Findings "
        "are linked in a graph where entities (domains, IPs, emails) are connected by "
        "relationships discovered during scanning."
    ),
    use_cases = [
        "Deep OSINT collection against a domain or IP",
        "Breach exposure indicator discovery",
        "Corporate attack surface mapping",
        "Correlated intelligence from 200+ sources in one run",
    ],
    example_commands = [
        "sfcli -s example.com -m sfp_dnsraw,sfp_crt,sfp_hackertarget -o json",
        "python3 sf.py -l 127.0.0.1:5001  # launch web UI",
        "sfcli -s example.com -m all -o json -q",
    ],
    common_errors = [
        {
            "error":    "sfcli: command not found",
            "solution": "Install via: pip install spiderfoot  or  sudo apt install spiderfoot",
        },
        {
            "error":    "Module timeout / no output",
            "solution": "Reduce module set. Use only no-API-key modules for reliability",
        },
    ],
    install          = "sudo apt install spiderfoot  # or: pip install spiderfoot",
    typical_workflow = ["WHOIS", "theHarvester", "SpiderFoot", "Port Scan", "Report"],
    integrations     = ["theHarvester", "Maltego", "Shodan"],
    tags             = ["osint", "passive", "automation", "graph", "breach"],
    reference_url    = "https://www.spiderfoot.net/",
)


OSRFRAMEWORK = ToolKnowledge(
    name        = "OSRFramework",
    category    = "Passive Recon",
    passive     = True,
    description = (
        "OSRFramework provides username intelligence, checking 300+ platforms for "
        "a given username (usufy), email existence (mailfy), and free-text entity "
        "search (searchfy). Ideal for building a target's social footprint."
    ),
    how_it_works = (
        "OSRFramework sends non-intrusive HTTP requests to each platform's public "
        "user existence endpoint (e.g. twitter.com/<username>) and checks the "
        "response code or content to determine if an account exists. No login required."
    ),
    use_cases = [
        "Find all social accounts linked to a username",
        "Email existence verification across platforms",
        "Correlate username variants across sites",
        "Build a person's online footprint for awareness assessments",
    ],
    example_commands = [
        "usufy -n targetuser -p twitter,github,reddit",
        "usufy -n targetuser -o json",
        "mailfy -n target@example.com",
        "searchfy -q 'John Doe example.com'",
    ],
    common_errors = [
        {
            "error":    "Platform detection false positives",
            "solution": "Verify manually — some platforms return 200 for all usernames",
        },
        {
            "error":    "usufy not found",
            "solution": "pip install osrframework",
        },
    ],
    install          = "pip install osrframework",
    typical_workflow = ["theHarvester", "OSRFramework", "SpiderFoot", "Report"],
    integrations     = ["theHarvester", "SpiderFoot", "Maltego"],
    tags             = ["osint", "passive", "username", "social", "email"],
    reference_url    = "https://github.com/i3visio/osrframework",
)


MALTEGO = ToolKnowledge(
    name        = "Maltego",
    category    = "Passive Recon",
    passive     = True,
    description = (
        "Maltego is a graph-based intelligence tool that visualises relationships "
        "between entities (domains, IPs, emails, people, infrastructure). ReconX "
        "generates compatible MTGL entity graph exports from scan findings."
    ),
    how_it_works = (
        "Maltego uses 'transforms' to pivot between entities. ReconX collects raw "
        "findings and exports them as a Maltego MTGL XML graph file, allowing teams "
        "to import discovered relationships directly into the Maltego GUI for "
        "visual analysis and further pivoting."
    ),
    use_cases = [
        "Visual attack surface mapping",
        "Entity relationship analysis across OSINT findings",
        "Briefing and reporting to stakeholders",
        "Identify ownership patterns between IPs, domains, ASNs",
    ],
    example_commands = [
        "# ReconX generates the .mtgl export automatically",
        "# Import into Maltego: File → Import Graph → select .mtgl",
        "maltego --headless --target example.com --output reports/",
    ],
    common_errors = [
        {
            "error":    "Maltego not installed / no license",
            "solution": "ReconX auto-generates an .mtgl file from its own findings that can be imported",
        },
    ],
    install          = "https://www.maltego.com/downloads/ (commercial)",
    typical_workflow = ["theHarvester", "SpiderFoot", "Sublist3r", "Maltego Graph Export"],
    integrations     = ["theHarvester", "SpiderFoot", "OSRFramework"],
    tags             = ["osint", "passive", "graph", "visualization", "entity"],
    reference_url    = "https://www.maltego.com/",
)


# ─────────────────────────────────────────────────────────────────────────────
# DNS
# ─────────────────────────────────────────────────────────────────────────────

DNSENUM = ToolKnowledge(
    name        = "dnsenum",
    category    = "DNS",
    description = (
        "dnsenum performs aggressive DNS enumeration including zone transfer attempts, "
        "wildcard detection, Google scraping for subdomains, and brute-force discovery "
        "using wordlists."
    ),
    how_it_works = (
        "dnsenum queries the target DNS servers for all record types, attempts zone "
        "transfers (AXFR) against each nameserver, scrapes Google for subdomain hints, "
        "and optionally brute-forces using a wordlist. Results are consolidated and "
        "shown with resolved IP addresses."
    ),
    use_cases = [
        "Detect misconfigured zone transfers (AXFR) — HIGH severity",
        "Enumerate all public DNS records for a domain",
        "Brute-force subdomain discovery",
        "Identify wildcard DNS configurations",
    ],
    example_commands = [
        "dnsenum example.com",
        "dnsenum example.com -f /usr/share/wordlists/dnsmap.txt --dnsserver 8.8.8.8",
        "dnsenum --noscrap example.com -t 20",
    ],
    common_errors = [
        {
            "error":    "Zone transfer refused (normal)",
            "solution": "Most targets correctly block AXFR. Record the status for the report",
        },
        {
            "error":    "dnsenum: command not found",
            "solution": "sudo apt install dnsenum",
        },
    ],
    install          = "sudo apt install dnsenum",
    typical_workflow = ["WHOIS", "dnsenum", "dnsrecon", "Sublist3r", "Port Scan"],
    integrations     = ["dnsrecon", "fierce", "Sublist3r"],
    tags             = ["dns", "active", "zone-transfer", "brute-force", "subdomain"],
    reference_url    = "https://github.com/fwaeytens/dnsenum",
)


DNSRECON = ToolKnowledge(
    name        = "dnsrecon",
    category    = "DNS",
    description = (
        "dnsrecon provides comprehensive DNS record enumeration including A, AAAA, MX, "
        "NS, SOA, TXT, SRV records, zone transfers, reverse lookups, and wildcard "
        "detection. Outputs structured JSON for pipeline integration."
    ),
    how_it_works = (
        "dnsrecon queries the target's authoritative DNS servers for all standard record "
        "types using Python's dnspython library. Zone transfers are attempted against "
        "each discovered nameserver. Results can be exported as JSON for direct ingestion "
        "into ReconX's analysis engine."
    ),
    use_cases = [
        "Complete DNS record inventory",
        "Detect SPF/DMARC/DKIM misconfigurations in TXT records",
        "Zone transfer vulnerability assessment",
        "SRV record discovery for service enumeration",
    ],
    example_commands = [
        "dnsrecon -d example.com -t std",
        "dnsrecon -d example.com -t std,axfr,srv -j output.json",
        "dnsrecon -d example.com -t brt -D /usr/share/wordlists/dnsmap.txt --threads 16",
        "dnsrecon -r 192.168.1.0/24 -t rvl",   # reverse lookup on range
    ],
    common_errors = [
        {
            "error":    "No results for -t axfr",
            "solution": "Zone transfer refused — correct and expected behavior. Document finding",
        },
        {
            "error":    "dnsrecon: command not found",
            "solution": "sudo apt install dnsrecon  or  pip install dnsrecon",
        },
    ],
    install          = "sudo apt install dnsrecon",
    typical_workflow = ["dnsenum", "dnsrecon", "fierce", "HTTPX", "Port Scan"],
    integrations     = ["dnsenum", "fierce", "Sublist3r", "Amass"],
    tags             = ["dns", "active", "records", "zone-transfer", "srv", "txt"],
    reference_url    = "https://github.com/darkoperator/dnsrecon",
)


FIERCE = ToolKnowledge(
    name        = "fierce",
    category    = "DNS",
    description = (
        "fierce is a DNS reconnaissance tool designed to find non-contiguous IP space "
        "and hostname ranges not directly linked to the primary domain — ideal for "
        "discovering targets adjacent to the known attack surface."
    ),
    how_it_works = (
        "fierce resolves the target domain, tries a zone transfer, then iterates through "
        "a subdomain wordlist resolving each. When a live host is found, it probes "
        "adjacent IPs via reverse DNS to discover nearby hosts on the same network block. "
        "This 'pivoting' approach finds infrastructure that simpler tools miss."
    ),
    use_cases = [
        "Discover hidden subdomains via DNS resolution",
        "Find adjacent IP infrastructure via reverse DNS pivoting",
        "Detect wildcard DNS configurations",
        "Pre-scan reconnaissance to narrow port scan scope",
    ],
    example_commands = [
        "fierce --domain example.com",
        "fierce --domain example.com --wordlist /usr/share/fierce/hosts.txt",
        "fierce --domain example.com --dns-servers 8.8.8.8 --threads 10",
        "fierce --domain example.com --delay 1",   # stealth mode
    ],
    common_errors = [
        {
            "error":    "fierce: command not found",
            "solution": "sudo apt install fierce  or  pip install fierce",
        },
        {
            "error":    "Wildcard detected — many false positives",
            "solution": "Use --wildcard-ignore flag or post-process results to remove wildcard IPs",
        },
    ],
    install          = "sudo apt install fierce",
    typical_workflow = ["dnsenum", "fierce", "dnsrecon", "Nmap", "Port Scan"],
    integrations     = ["dnsenum", "dnsrecon", "Sublist3r"],
    tags             = ["dns", "active", "subdomain", "adjacent-ip", "pivot"],
    reference_url    = "https://github.com/mschwager/fierce",
)


SUBLIST3R = ToolKnowledge(
    name        = "Sublist3r",
    category    = "DNS",
    passive     = True,
    description = (
        "Sublist3r enumerates subdomains passively using multiple search engines and "
        "OSINT sources including Google, Bing, Baidu, Netcraft, VirusTotal, and "
        "DNSdumpster. Fast, no API keys required for basic usage."
    ),
    how_it_works = (
        "Sublist3r queries each search engine with 'site:*.target.com' dork syntax "
        "and scrapes the results. It also queries threat intel databases and certificate "
        "transparency logs. All results are merged and deduplicated. Optionally, it "
        "integrates subbrute for wordlist-based brute forcing."
    ),
    use_cases = [
        "Fast passive subdomain enumeration without touching the target",
        "Combine multiple sources for broad coverage",
        "Seed active enumeration tools (dnsrecon, fierce) with found subdomains",
        "Pre-scan to define port scan scope",
    ],
    example_commands = [
        "sublist3r -d example.com",
        "sublist3r -d example.com -e google,bing,virustotal -o subs.txt",
        "sublist3r -d example.com -b -w /usr/share/wordlists/dnsmap.txt",
        "sublist3r -d example.com -t 30 -v",
    ],
    common_errors = [
        {
            "error":    "sublist3r: command not found",
            "solution": "sudo apt install sublist3r  or  pip install sublist3r",
        },
        {
            "error":    "No subdomains found",
            "solution": "Enable bruteforce mode (-b) or try Amass for more thorough enumeration",
        },
    ],
    install          = "sudo apt install sublist3r",
    typical_workflow = ["theHarvester", "Sublist3r", "dnsrecon", "HTTPX", "Nmap"],
    integrations     = ["theHarvester", "dnsenum", "dnsrecon", "Amass", "HTTPX"],
    tags             = ["dns", "passive", "subdomain", "search-engine", "osint"],
    reference_url    = "https://github.com/aboul3la/Sublist3r",
)


# ─────────────────────────────────────────────────────────────────────────────
# NETWORK DISCOVERY
# ─────────────────────────────────────────────────────────────────────────────

NETDISCOVER = ToolKnowledge(
    name         = "netdiscover",
    category     = "Network Discovery",
    requires_root = True,
    description = (
        "netdiscover is an ARP reconnaissance tool that finds live hosts on a local "
        "network segment. Reports IP, MAC address, and hardware vendor — no IP-layer "
        "traffic is generated."
    ),
    how_it_works = (
        "netdiscover sends ARP 'Who has X.X.X.X?' broadcast requests across the "
        "target CIDR range. Devices that are alive respond with their MAC address. "
        "This works even when ICMP is blocked, making it highly reliable for LAN recon. "
        "Passive mode sniffs existing ARP traffic without sending probes."
    ),
    use_cases = [
        "Live host discovery on local/internal network",
        "Asset inventory of a LAN segment",
        "MAC address and vendor identification",
        "Detect rogue devices when combined with expected device list",
    ],
    example_commands = [
        "sudo netdiscover -r 192.168.1.0/24",
        "sudo netdiscover -r 10.0.0.0/16 -i eth0",
        "sudo netdiscover -p                    # passive mode — sniff only",
        "sudo netdiscover -r 192.168.1.0/24 -P  # print to stdout (pipeline-friendly)",
    ],
    common_errors = [
        {
            "error":    "Operation not permitted",
            "solution": "netdiscover requires root (sudo) for raw ARP socket access",
        },
        {
            "error":    "No hosts found on /24",
            "solution": "Verify the CIDR range is correct. On VMs, try the gateway IP subnet",
        },
    ],
    install          = "sudo apt install netdiscover",
    typical_workflow = ["netdiscover", "fping", "Nmap", "Service Detection", "Port Scan"],
    integrations     = ["fping", "Nmap", "NetcatWrapper"],
    tags             = ["network", "arp", "lan", "host-discovery", "mac"],
    reference_url    = "https://github.com/netdiscover-scanner/netdiscover",
)


FPING = ToolKnowledge(
    name        = "fping",
    category    = "Network Discovery",
    description = (
        "fping is a high-performance ICMP host sweep tool that probes entire network "
        "ranges simultaneously. Unlike ping, fping is designed for bulk host discovery "
        "and reports per-host latency and packet loss."
    ),
    how_it_works = (
        "fping sends ICMP echo requests to all hosts in a range concurrently using "
        "non-blocking I/O. Replies are collected and correlated. Hosts that respond are "
        "reported as alive with round-trip time. Much faster than sequential ping."
    ),
    use_cases = [
        "Fast ICMP sweep across large IP ranges",
        "Identify live hosts for targeted port scanning",
        "Latency baseline measurement across a network",
        "Filter live targets from CIDR before handing to Nmap",
    ],
    example_commands = [
        "fping -a -g 192.168.1.0/24 2>/dev/null",
        "fping -c 3 -g 192.168.1.0/24",
        "fping -a -g 10.0.0.0/16 -t 200 -r 1",
        "fping -f targets.txt -e",   # -e: show elapsed times
    ],
    common_errors = [
        {
            "error":    "fping: command not found",
            "solution": "sudo apt install fping",
        },
        {
            "error":    "All hosts appear unreachable",
            "solution": "ICMP may be firewalled. Use netdiscover (ARP) or Nmap -sn as alternative",
        },
    ],
    install          = "sudo apt install fping",
    typical_workflow = ["fping", "netdiscover", "Nmap", "Service Detection"],
    integrations     = ["netdiscover", "Nmap", "NetcatWrapper"],
    tags             = ["network", "icmp", "host-discovery", "ping", "sweep"],
    reference_url    = "https://fping.org/",
)


# ─────────────────────────────────────────────────────────────────────────────
# WEB RECON
# ─────────────────────────────────────────────────────────────────────────────

DIRBUSTER = ToolKnowledge(
    name        = "DirBuster / dirb",
    category    = "Web Recon",
    description = (
        "dirb / DirBuster performs HTTP brute-force directory and file discovery, "
        "finding hidden paths, admin panels, backup files, and configuration pages "
        "that are not linked from the application."
    ),
    how_it_works = (
        "dirb sends HTTP GET requests for each word in a wordlist appended to the "
        "base URL. Non-404 responses are reported. Extensions can be appended to each "
        "word to discover files. Results are filtered by response code."
    ),
    use_cases = [
        "Find hidden admin panels and login pages",
        "Discover backup files (.bak, .old, .zip) left on server",
        "Enumerate API endpoints and documentation",
        "Find configuration files exposed to the web",
    ],
    example_commands = [
        "dirb http://example.com /usr/share/dirb/wordlists/common.txt",
        "dirb http://example.com -X .php,.html,.bak -r",
        "dirb http://example.com /usr/share/wordlists/dirbuster/directory-list-2.3-medium.txt",
    ],
    common_errors = [
        {
            "error":    "Too many false positives",
            "solution": "Use -N 302 to ignore redirects, or -N 403 to ignore forbidden pages",
        },
        {
            "error":    "Scan too slow",
            "solution": "Reduce wordlist size or switch to feroxbuster (faster, recursive)",
        },
    ],
    install          = "sudo apt install dirb",
    typical_workflow = ["Port Scan", "DirBuster", "feroxbuster", "EyeWitness", "Report"],
    integrations     = ["feroxbuster", "gobuster", "EyeWitness", "Nikto"],
    tags             = ["web", "active", "directory", "brute-force", "hidden-files"],
    reference_url    = "https://sourceforge.net/projects/dirbuster/",
)


FEROXBUSTER = ToolKnowledge(
    name        = "feroxbuster",
    category    = "Web Recon",
    description = (
        "feroxbuster is a fast, recursive web content discovery tool written in Rust. "
        "It automatically recurses into discovered directories, making it more thorough "
        "than single-pass tools. Supports parallel scans, filters, and rate limiting."
    ),
    how_it_works = (
        "feroxbuster uses an async Rust HTTP engine to send concurrent requests for "
        "each wordlist entry. When a directory is found, it automatically spawns child "
        "scans into that directory up to a configurable depth. Response filtering "
        "removes noise by size, word count, or status code."
    ),
    use_cases = [
        "Recursive content discovery across entire web applications",
        "API endpoint enumeration",
        "Finding deeply nested admin/debug paths",
        "Thorough coverage compared to single-pass dirb",
    ],
    example_commands = [
        "feroxbuster --url http://example.com --depth 3",
        "feroxbuster --url http://example.com -w /usr/share/seclists/Discovery/Web-Content/raft-medium-directories.txt",
        "feroxbuster --url http://example.com --extensions php,html,bak --filter-status 404,500",
        "feroxbuster --url http://example.com --threads 50 --rate-limit 100",
    ],
    common_errors = [
        {
            "error":    "feroxbuster: command not found",
            "solution": "sudo apt install feroxbuster  or download from GitHub releases",
        },
        {
            "error":    "Server returns 200 for all requests (soft 404)",
            "solution": "Use --filter-size or --filter-words to eliminate the soft 404 response size",
        },
    ],
    install          = "sudo apt install feroxbuster",
    typical_workflow = ["Port Scan", "DirBuster", "feroxbuster", "EyeWitness", "Nikto"],
    integrations     = ["DirBuster", "gobuster", "EyeWitness", "Nikto"],
    tags             = ["web", "active", "recursive", "directory", "rust", "fast"],
    reference_url    = "https://github.com/epi052/feroxbuster",
)


EYEWITNESS = ToolKnowledge(
    name        = "EyeWitness",
    category    = "Web Recon",
    description = (
        "EyeWitness takes automated screenshots of web services, captures page titles, "
        "detects login pages, and categorizes targets by risk. Ideal for quickly triaging "
        "large numbers of discovered web services."
    ),
    how_it_works = (
        "EyeWitness uses a headless browser (Selenium/Chrome) to render each target URL "
        "and capture a screenshot. It also reads the HTTP response headers, page title, "
        "and page content to detect login forms, default credentials pages, and "
        "interesting technology indicators."
    ),
    use_cases = [
        "Visual triage of discovered web services without visiting each manually",
        "Login page detection across all web ports",
        "Default credential page identification",
        "Generate visual reports for stakeholders",
    ],
    example_commands = [
        "eyewitness --web -f urls.txt -d screenshots/",
        "eyewitness --web --single http://example.com -d screenshots/",
        "eyewitness --web -f urls.txt --timeout 10 --threads 5",
        "eyewitness --web -f urls.txt --prepend-https",
    ],
    common_errors = [
        {
            "error":    "Chrome/Chromium not found",
            "solution": "sudo apt install chromium  and re-run EyeWitness setup.sh",
        },
        {
            "error":    "Empty screenshots (blank images)",
            "solution": "Increase --timeout. Some applications require JS to render",
        },
    ],
    install          = "sudo apt install eyewitness",
    typical_workflow = ["feroxbuster", "EyeWitness", "Nikto", "Report"],
    integrations     = ["DirBuster", "feroxbuster", "gobuster", "ReconX Report"],
    tags             = ["web", "active", "screenshot", "visual", "login", "triage"],
    reference_url    = "https://github.com/RedSiege/EyeWitness",
)


# ─────────────────────────────────────────────────────────────────────────────
# FRAMEWORKS
# ─────────────────────────────────────────────────────────────────────────────

METASPLOIT_AUX = ToolKnowledge(
    name        = "Metasploit Auxiliary",
    category    = "Frameworks",
    description = (
        "ReconX integrates selected Metasploit auxiliary modules for safe service "
        "enumeration and fingerprinting. Only scanner/* modules are included — no "
        "exploitation modules are accessible through ReconX."
    ),
    how_it_works = (
        "ReconX generates an msfconsole RC script containing only allowlisted auxiliary "
        "modules (http_version, smb_version, ssh_version, ftp_version, anon FTP check). "
        "msfconsole runs the script headlessly and ReconX parses the structured output "
        "into normalized findings."
    ),
    use_cases = [
        "Service version fingerprinting via Metasploit's reliable detectors",
        "SMB share enumeration",
        "Anonymous FTP access verification",
        "HTTP server title and header capture",
    ],
    example_commands = [
        "# ReconX invokes this automatically — or use msfconsole directly:",
        "use auxiliary/scanner/http/http_version; set RHOSTS 192.168.1.1; run",
        "use auxiliary/scanner/smb/smb_version; set RHOSTS 192.168.1.0/24; run",
        "use auxiliary/scanner/ftp/anonymous; set RHOSTS 192.168.1.1; run",
    ],
    common_errors = [
        {
            "error":    "msfconsole: command not found",
            "solution": "sudo apt install metasploit-framework  (Kali: pre-installed)",
        },
        {
            "error":    "Database not connected",
            "solution": "sudo service postgresql start && msfdb init",
        },
    ],
    install          = "sudo apt install metasploit-framework",
    typical_workflow = ["Port Scan", "Service Detection", "Metasploit Auxiliary", "Report"],
    integrations     = ["Nmap", "NetcatWrapper", "ReconX Service Detector"],
    tags             = ["framework", "active", "msf", "version", "smb", "ftp", "ssh"],
    reference_url    = "https://docs.metasploit.com/",
)


# ─────────────────────────────────────────────────────────────────────────────
# UTILITIES
# ─────────────────────────────────────────────────────────────────────────────

NETCAT_WRAPPER = ToolKnowledge(
    name        = "NetcatWrapper",
    category    = "Utilities",
    description = (
        "ReconX's NetcatWrapper provides banner grabbing, TCP connectivity tests, "
        "and manual service interaction using nc/ncat. Falls back to a pure-Python "
        "socket implementation when nc is unavailable."
    ),
    how_it_works = (
        "For each target port, NetcatWrapper opens a TCP connection, optionally sends "
        "a service-specific probe (HTTP HEAD, SMTP EHLO, Redis PING, etc.), and reads "
        "the banner response. Results feed directly into the service fingerprinting pipeline."
    ),
    use_cases = [
        "Quick banner grab from a specific port",
        "Verify port is actually open and responding",
        "Initial service identification before running deeper tools",
        "Test custom TCP probes against services",
    ],
    example_commands = [
        "nc -v example.com 22",
        "nc -w3 example.com 80 <<< 'HEAD / HTTP/1.0\r\n\r\n'",
        "echo 'PING' | nc -w2 example.com 6379",
        "ncat --ssl example.com 443",
    ],
    common_errors = [
        {
            "error":    "nc: command not found",
            "solution": "sudo apt install netcat-openbsd  (ReconX uses Python socket fallback automatically)",
        },
        {
            "error":    "Connection timeout",
            "solution": "Port is filtered or host is unreachable. Verify with fping first",
        },
    ],
    install          = "sudo apt install netcat-openbsd",
    typical_workflow = ["Port Scan", "NetcatWrapper", "Service Detection", "Metasploit Auxiliary"],
    integrations     = ["Nmap", "fping", "Service Detector", "Metasploit Auxiliary"],
    tags             = ["utility", "banner", "tcp", "netcat", "service"],
    reference_url    = "https://nmap.org/ncat/",
)


# ─────────────────────────────────────────────────────────────────────────────
# Registry — consumed by LearningMode engine
# ─────────────────────────────────────────────────────────────────────────────

ALL_TOOL_KNOWLEDGE: list[ToolKnowledge] = [
    THEHARVESTER,
    SPIDERFOOT,
    OSRFRAMEWORK,
    MALTEGO,
    DNSENUM,
    DNSRECON,
    FIERCE,
    SUBLIST3R,
    NETDISCOVER,
    FPING,
    DIRBUSTER,
    FEROXBUSTER,
    EYEWITNESS,
    METASPLOIT_AUX,
    NETCAT_WRAPPER,
]

CATEGORY_ORDER = [
    "Passive Recon",
    "Active Recon",
    "DNS",
    "Network Discovery",
    "Web Recon",
    "Frameworks",
    "Utilities",
]


def get_by_category(category: str) -> list[ToolKnowledge]:
    return [t for t in ALL_TOOL_KNOWLEDGE if t.category == category]


def get_by_name(name: str) -> Optional[ToolKnowledge]:
    name_lower = name.lower()
    for t in ALL_TOOL_KNOWLEDGE:
        if t.name.lower() == name_lower:
            return t
    return None


def search(query: str) -> list[ToolKnowledge]:
    """Full-text search across names, descriptions, and tags."""
    q = query.lower()
    results = []
    for t in ALL_TOOL_KNOWLEDGE:
        if (q in t.name.lower() or q in t.description.lower()
                or any(q in tag for tag in t.tags)):
            results.append(t)
    return results
