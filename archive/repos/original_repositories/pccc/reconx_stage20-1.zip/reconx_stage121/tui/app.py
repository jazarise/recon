"""
ReconX — TUI Application Entry Point (Stage 14).

Launches the full ReconX Cyber Intelligence OS.

Usage:
    python -m reconx         # from package
    python reconx/tui/app.py # direct
    reconx                   # if installed via setup.py

Initialises:
  1. Tool Registry (auto-discover all BaseTool subclasses)
  2. ReconXEngine (orchestration)
  3. Navigator (screen router + theme)
  4. Dashboard (home screen)
"""
from __future__ import annotations

import logging
import sys
from typing import Optional

log = logging.getLogger("reconx.app")


def _setup_logging(verbose: bool = False) -> None:
    level = logging.DEBUG if verbose else logging.WARNING
    logging.basicConfig(
        level=level,
        format="[%(levelname)s] %(name)s: %(message)s",
    )


def _print_startup_error(msg: str) -> None:
    from rich.console import Console
    from rich.panel import Panel
    Console().print(Panel(
        f"[bold red]Startup Error[/]\n\n{msg}\n\n"
        "[dim]Check that ReconX is installed correctly and all "
        "dependencies are present.[/]",
        border_style="red",
    ))


def build_app(
    theme:      str  = "dark",
    verbose:    bool = False,
    base_pkg:   str  = "reconx",
) -> "Navigator":
    """
    Build and return a ready-to-run Navigator instance.

    Args:
        theme:    Colour theme: 'dark'|'neon'|'green'|'light'|'compact'.
        verbose:  Enable debug logging.
        base_pkg: Base Python package name for tool auto-discovery.
    """
    _setup_logging(verbose)

    # ── Tool Registry ──────────────────────────────────────────────────────────
    registry = None
    try:
        try:
            from reconx.orchestration.tool_registry import ToolRegistry
        except ModuleNotFoundError:
            from orchestration.tool_registry import ToolRegistry
        registry = ToolRegistry.build(base_package=base_pkg, instantiate=True)
        log.info(f"Registry: {registry.count()} tools loaded.")
    except Exception as e:
        log.warning(f"Registry init failed: {e} — continuing without registry.")

    # ── Execution Engine ───────────────────────────────────────────────────────
    engine = None
    try:
        try:
            from reconx.orchestration.reconx_engine import ReconXEngine
        except ModuleNotFoundError:
            from orchestration.reconx_engine import ReconXEngine
        engine = ReconXEngine(base_package=base_pkg)
        # Inject registry to avoid double-build
        engine._registry = registry
        log.info("ReconXEngine ready.")
    except Exception as e:
        log.warning(f"Engine init failed: {e} — execution features disabled.")

    # ── Navigator ──────────────────────────────────────────────────────────────
    try:
        try:
            from reconx.tui.navigator import Navigator
        except ModuleNotFoundError:
            from tui.navigator import Navigator
        return Navigator(theme_name=theme, registry=registry, engine=engine)
    except Exception as e:
        _print_startup_error(str(e))
        sys.exit(1)


def main(argv: Optional[list[str]] = None) -> None:
    """
    CLI entry point — parses args and launches TUI.

    Flags:
      --theme   THEME     Colour theme (default: dark)
      --verbose           Enable debug logging
      --health            Show tool health check and exit
      --install-guide     Show missing tool install commands and exit
      --version           Print version and exit
    """
    import argparse
    parser = argparse.ArgumentParser(
        prog="reconx",
        description="ReconX — Cyber Intelligence OS",
    )
    parser.add_argument("--theme",   default="dark",
                        choices=["dark", "neon", "green", "light", "compact"],
                        help="Colour theme (default: dark)")
    parser.add_argument("--verbose", action="store_true",
                        help="Enable debug logging")
    parser.add_argument("--health",  action="store_true",
                        help="Show tool health dashboard and exit")
    parser.add_argument("--install-guide", action="store_true", dest="install",
                        help="Show install commands for missing tools and exit")
    parser.add_argument("--version", action="store_true",
                        help="Print version and exit")
    parser.add_argument("target",    nargs="?", default=None,
                        help="Optional: target to scan immediately (skips menu)")
    parser.add_argument("--mode",    default="balanced",
                        choices=["fast","balanced","deep","passive","ai","custom"],
                        help="Scan mode (default: balanced)")

    args = parser.parse_args(argv)

    if args.version:
        print("ReconX v14.0 — Cyber Intelligence OS")
        return

    nav = build_app(theme=args.theme, verbose=args.verbose)

    if args.health:
        from rich.console import Console
        Console().print(nav.engine.health_check() if nav.engine else
                        "[yellow]No engine — cannot probe health.[/]")
        return

    if args.install:
        from rich.console import Console
        Console().print(nav.engine.install_guide() if nav.engine else
                        "[yellow]No engine.[/]")
        return

    if args.target:
        # Non-interactive: run immediately against target
        exec_view = nav._exec_view()
        exec_view.run_target(args.target, mode=args.mode)
        return

    # Interactive TUI loop
    nav.run()


if __name__ == "__main__":
    main()
