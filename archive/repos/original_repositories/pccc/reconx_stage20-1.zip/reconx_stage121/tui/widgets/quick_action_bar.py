"""
ReconX — TUI Widget: Quick Action Bar (Stage 14, Part 8).

Renders the quick-action shortcut bar at the bottom of any screen.
Supports keyboard shortcuts and displays estimated execution time.

Preset actions:
  QS  Quick Scan       — WHOIS → DNS → Subs → HTTPX → Report
  DS  Deep Scan        — Full asset discovery pipeline
  WS  Web Scan         — HTTP → Crawl → Content → Visual
  PS  Passive Only     — OSINT + archives, zero active traffic
  IS  Internal Scan    — LAN discovery (CIDR → ARP → Ports)
  CS  Cloud Scan       — ASN → S3 → Certs
  CW  Custom Workflow  — User-defined chain
"""
from __future__ import annotations

from typing import Optional

from rich import box
from rich.console import Console, Group
from rich.panel import Panel
from rich.table import Table
from rich.text import Text


# ── Action definitions ────────────────────────────────────────────────────────

QUICK_ACTION_DEFS: list[dict] = [
    {
        "key":   "QS",
        "label": "Quick Scan",
        "time":  "~15m",
        "tools": "WHOIS → DNS → Subs → HTTPX → Report",
        "colour":"cyan",
    },
    {
        "key":   "DS",
        "label": "Deep Scan",
        "time":  "~2h",
        "tools": "Full asset discovery pipeline",
        "colour":"bold cyan",
    },
    {
        "key":   "WS",
        "label": "Web Scan",
        "time":  "~45m",
        "tools": "HTTP → Crawl → Content → Visual",
        "colour":"white",
    },
    {
        "key":   "PS",
        "label": "Passive Only",
        "time":  "~20m",
        "tools": "OSINT + archives — zero active traffic",
        "colour":"green",
    },
    {
        "key":   "IS",
        "label": "Internal Scan",
        "time":  "~30m",
        "tools": "ARP → fping → Nmap → Services",
        "colour":"yellow",
    },
    {
        "key":   "CS",
        "label": "Cloud Scan",
        "time":  "~25m",
        "tools": "ASN → CIDR → S3 → Certs → Report",
        "colour":"magenta",
    },
    {
        "key":   "CW",
        "label": "Custom",
        "time":  "varies",
        "tools": "User-defined tool chain",
        "colour":"dim",
    },
]


class QuickActionBar:
    """
    Renderable quick-action bar.

    Usage:
        bar = QuickActionBar(compact=True)
        console.print(bar.render())

        choice = bar.prompt(console)   # returns action key or None
    """

    def __init__(
        self,
        console:  Optional[Console] = None,
        compact:  bool              = False,
        show_time: bool             = True,
    ):
        self.console    = console or Console()
        self.compact    = compact
        self.show_time  = show_time

    def render(self) -> Panel:
        if self.compact:
            return self._compact_render()
        return self._full_render()

    def prompt(self, prompt_text: str = "Quick action") -> Optional[str]:
        """Show bar and read a key. Returns action key (e.g. 'QS') or None."""
        self.console.print(self.render())
        from rich.prompt import Prompt
        choice = Prompt.ask(
            f"[dim]{prompt_text}[/]",
            console=self.console,
            default="",
        ).strip().upper()
        valid = {a["key"] for a in QUICK_ACTION_DEFS}
        return choice if choice in valid else None

    # ── rendering ─────────────────────────────────────────────────────────────

    def _full_render(self) -> Panel:
        table = Table(box=None, show_header=True, padding=(0, 2),
                      header_style="bold dim", expand=True)
        table.add_column("Key",      style="bold cyan", width=6)
        table.add_column("Action",   style="bold white")
        if self.show_time:
            table.add_column("Est.",  style="dim",  width=8)
        table.add_column("Runs",     style="dim")

        for action in QUICK_ACTION_DEFS:
            row = [
                f"[{action['colour']}][{action['key']}][/{action['colour']}]",
                f"[{action['colour']}]{action['label']}[/{action['colour']}]",
            ]
            if self.show_time:
                row.append(action["time"])
            row.append(action["tools"])
            table.add_row(*row)

        return Panel(
            table,
            title="[bold cyan]Quick Actions[/]",
            subtitle="[dim]Type a key (QS, DS, WS, PS, IS, CS, CW)[/]",
            border_style="dim cyan",
            padding=(0, 1),
        )

    def _compact_render(self) -> Panel:
        """Single-line compact bar for use as a footer."""
        parts = []
        for action in QUICK_ACTION_DEFS:
            parts.append(
                f"[{action['colour']}][{action['key']}][/{action['colour']}]"
                f"[dim]{action['label']}[/]"
            )
        line = "   ".join(parts)
        return Panel(
            Text.from_markup(line),
            border_style="dim",
            padding=(0, 1),
            height=3,
        )


# ── Status indicator widget ────────────────────────────────────────────────────

class StatusBar:
    """
    Compact status row: tool counts + recent activity.
    Rendered as a single-line Panel footer.
    """

    def __init__(self, registry=None):
        self.registry = registry

    def render(self) -> Panel:
        if not self.registry:
            return Panel("[dim]Registry not loaded[/]", height=3, border_style="dim")

        all_t  = self.registry.all()
        avail  = sum(1 for t in all_t if t.is_available)
        total  = len(all_t)
        miss   = total - avail

        line = (
            f"[bold cyan]ReconX[/]  │  "
            f"[green]● {avail} ready[/]  "
            f"[yellow]○ {miss} missing[/]  │  "
            f"[dim]{total} tools registered[/]"
        )
        return Panel(
            Text.from_markup(line),
            border_style="dim",
            padding=(0, 2),
            height=3,
        )
