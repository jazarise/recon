"""
ReconX — TUI: Execution View (Stage 14, Part 6).

Live dashboard for pipeline execution — wraps OperationsCenter with
a higher-level API that the app.py can call cleanly.

Also provides:
  • Quick-action executor (one-line preset workflows)
  • Post-run summary display
  • Report path announcement
"""
from __future__ import annotations

import time
from pathlib import Path
from typing import Optional

from rich.console import Console, Group
from rich.panel import Panel
from rich.prompt import Prompt
from rich.table import Table
from rich import box


# Quick action presets ────────────────────────────────────────────────────────

QUICK_ACTIONS: dict[str, dict] = {
    "qs": {
        "label":   "Quick Scan",
        "mode":    "fast",
        "desc":    "WHOIS → DNS → Subdomains → HTTPX → Report",
        "tools":   ["WhoisTool", "DNSReconTool", "Sublist3rTool",
                    "CrtshTool", "HttpxTool"],
    },
    "ds": {
        "label":   "Deep Scan",
        "mode":    "deep",
        "desc":    "Full asset discovery pipeline",
        "tools":   None,   # use mode=deep full tool list
    },
    "ws": {
        "label":   "Web Scan",
        "mode":    "balanced",
        "desc":    "HTTP → Crawl → Content → Visual",
        "tools":   ["HttpxTool", "WhatWebTool", "Wafw00fTool",
                    "GauTool", "KatanaTool", "FeroxbusterTool",
                    "ParamSpiderTool", "GoWitnessTool"],
    },
    "ps": {
        "label":   "Passive Only",
        "mode":    "passive",
        "desc":    "OSINT + archives — zero active traffic",
        "tools":   None,   # use mode=passive full tool list
    },
    "cs": {
        "label":   "Cloud Scan",
        "mode":    "balanced",
        "desc":    "ASN → S3 → Certs → Cloud assets",
        "tools":   ["AsnmapTool", "MapCIDRTool", "S3ScannerTool",
                    "CrtshTool", "TLSXTool"],
    },
}


class ExecutionView:
    """
    Manages the execution screen lifecycle.

    Usage:
        view = ExecutionView(console, registry, engine)
        view.run_quick_action("qs", target="example.com")
        # or:
        view.run_target(target, mode)
    """

    def __init__(
        self,
        console:  Optional[Console] = None,
        registry  = None,
        engine    = None,
    ):
        self.console  = console or Console()
        self.registry = registry
        self.engine   = engine

    # ── entry points ─────────────────────────────────────────────────────────

    def run_target(self, target: str, mode: str = "balanced") -> None:
        """Full pipeline run for a target with live TUI."""
        self.console.clear()
        self.console.print(Panel(
            f"[bold cyan]Executing:[/] [white]{target}[/]   "
            f"[dim]Mode:[/] [cyan]{mode.upper()}[/]",
            border_style="cyan",
        ))

        if not self.engine:
            self.console.print("[yellow]⚠ No execution engine configured.[/]")
            Prompt.ask("[dim]Press Enter[/]", default="")
            return

        try:
            result = self.engine.run(
                target,
                mode=mode,
                live_tui=True,
                save_report=True,
            )
            self._show_result_summary(result)
        except Exception as e:
            self.console.print(f"[red]Execution error: {e}[/]")
            Prompt.ask("[dim]Press Enter[/]", default="")

    def run_quick_action(self, action_key: str, target: Optional[str] = None) -> None:
        """Run a named quick-action preset."""
        action = QUICK_ACTIONS.get(action_key.lower())
        if not action:
            self.console.print(f"[red]Unknown quick action: {action_key}[/]")
            return

        if not target:
            target = Prompt.ask(
                f"[bold cyan]{action['label']}[/] — Target",
                console=self.console,
            ).strip()

        if not target:
            return

        self.console.clear()
        self.console.print(Panel(
            f"[bold cyan]{action['label']}[/]\n"
            f"[dim]{action['desc']}[/]\n\n"
            f"[white]Target:[/] [yellow]{target}[/]",
            border_style="cyan",
        ))

        if not self.engine:
            self._dry_run_display(action, target)
            return

        custom_tools = action.get("tools")
        try:
            result = self.engine.run(
                target,
                mode=action["mode"],
                live_tui=True,
                save_report=True,
                custom_tools=custom_tools,
            )
            self._show_result_summary(result)
        except Exception as e:
            self.console.print(f"[red]Error: {e}[/]")
            Prompt.ask("[dim]Press Enter[/]", default="")

    def prompt_and_run(self) -> None:
        """Interactive prompt: ask for target then mode, then run."""
        self.console.clear()
        self.console.print(Panel(
            "[bold cyan]Execute Recon[/]\n"
            "[dim]Enter a target to begin reconnaissance.[/]",
            border_style="cyan",
            padding=(1, 4),
        ))

        target = Prompt.ask("[bold cyan]Target[/]",
                             console=self.console).strip()
        if not target:
            return

        # Classify and show type
        ct = self._classify(target)
        self.console.print(
            f"[green]✓[/] [bold]{ct.target_type.upper()}[/] — {ct.normalized}"
        )

        mode_choices = {
            "1": "fast", "2": "balanced", "3": "deep",
            "4": "passive", "5": "ai",
        }
        self.console.print(
            "\n[dim]Mode:[/]  "
            "[1] Fast  [2] Balanced  [3] Deep  [4] Passive  [5] AI"
        )
        mode_key = Prompt.ask(
            "[bold cyan]Mode[/]",
            choices=list(mode_choices.keys()),
            default="2",
            console=self.console,
        )
        mode = mode_choices[mode_key]
        self.run_target(target, mode)

    # ── summary display ───────────────────────────────────────────────────────

    def _show_result_summary(self, result) -> None:
        self.console.print()
        total = getattr(result, "total_findings", 0)
        succ  = getattr(result, "success_count", 0)
        fail  = getattr(result, "failed_count",  0)
        dur   = getattr(result, "duration_s",    0.0)
        rpath = getattr(result, "report_path",   None)

        self.console.print(Panel(
            Group(
                self.console.print(
                    f"[bold white]Total Findings:[/] [bold green]{total}[/]   "
                    f"[bold white]Tools Passed:[/] [green]{succ}[/]   "
                    f"[bold white]Failed:[/] [red]{fail}[/]   "
                    f"[dim]Duration: {dur:.0f}s[/]"
                ),
                *(
                    [self.console.print(
                        f"\n[bold cyan]📄 Report:[/] [white]{rpath}[/]"
                    )]
                    if rpath else []
                ),
            ),
            title="[bold cyan]Scan Complete[/]",
            border_style="green",
        ))
        Prompt.ask("[dim]Press Enter to return[/]", default="",
                    console=self.console)

    def _dry_run_display(self, action: dict, target: str) -> None:
        tools = action.get("tools") or ["(mode default)"]
        table = Table(box=box.SIMPLE, show_header=False, padding=(0, 2))
        for i, tc in enumerate(tools, 1):
            table.add_row(f"[dim]{i}.[/]", f"[white]{tc}[/]")
        self.console.print(Panel(
            table,
            title=f"[bold cyan]{action['label']} — Tool Plan[/]",
            border_style="dim cyan",
        ))
        self.console.print(
            "[yellow]⚠ No execution engine configured — dry run only.[/]"
        )
        Prompt.ask("[dim]Press Enter[/]", default="")

    # ── helpers ───────────────────────────────────────────────────────────────

    def _classify(self, target: str):
        try:
            from reconx.analysis.target_classifier import TargetClassifier
        except ModuleNotFoundError:
            from analysis.target_classifier import TargetClassifier
        return TargetClassifier.classify(target)
