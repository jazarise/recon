"""
ReconX — TUI: Tool Browser (Stage 14, Parts 2 & 3).

Category-driven tool explorer with:
  • Browsable category list
  • Searchable tool index
  • Full tool detail view per tool
  • Install status + dependency check
  • [Run Tool] [Add To Workflow] [Learn] action buttons

No external dependencies beyond Rich.
"""
from __future__ import annotations

from typing import Optional

from rich import box
from rich.align import Align
from rich.console import Console, Group
from rich.panel import Panel
from rich.prompt import Prompt
from rich.rule import Rule
from rich.table import Table
from rich.text import Text


# ── Category definitions ────────────────────────────────────────────────────

CATEGORIES = [
    ("Passive Recon",       "🕵️",  "passive"),
    ("Active Recon",        "🔍",  "active"),
    ("DNS Intelligence",    "🌐",  "dns"),
    ("Subdomain Discovery", "🔀",  "subdomain"),
    ("OSINT",               "👁️",  "osint"),
    ("Web Recon",           "🕸️",  "web"),
    ("API Recon",           "⚡",  "api_recon"),
    ("Cloud Recon",         "☁️",  "cloud"),
    ("Visual Intelligence", "📸",  "screenshot"),
    ("Identity OSINT",      "🪪",  "identity"),
    ("Secret Intelligence", "🔑",  "secrets"),
    ("Certificate Intel",   "📜",  "certs"),
    ("Network Discovery",   "📡",  "network"),
    ("Fingerprinting",      "🧬",  "fingerprint"),
    ("DNS Resolution",      "🔢",  "dns_intel"),
    ("Frameworks",          "🛠️",  "framework"),
    ("Utilities",           "🔧",  "utility"),
]


# ─────────────────────────────────────────────────────────────────────────────
# ToolBrowser
# ─────────────────────────────────────────────────────────────────────────────

class ToolBrowser:
    """
    Interactive tool category explorer.

    Flow:
      browse_categories() → pick number → browse_category(cat) →
      pick number → show_tool_detail(tool_meta) →
      pick action: Run / Workflow / Learn / Back
    """

    def __init__(
        self,
        registry = None,
        console: Optional[Console] = None,
        on_run:       Optional[callable] = None,
        on_learn:     Optional[callable] = None,
        on_add_wf:    Optional[callable] = None,
    ):
        self.registry  = registry
        self.console   = console or Console()
        self.on_run    = on_run
        self.on_learn  = on_learn
        self.on_add_wf = on_add_wf

    # ── category list ─────────────────────────────────────────────────────────

    def browse_categories(self) -> None:
        """Main category browser loop."""
        while True:
            self.console.clear()
            self.console.print(self._category_panel())
            self.console.print()

            choice = Prompt.ask(
                "[cyan]Category number[/] (or [bold]S[/]=Search, [bold]0[/]=Back)",
                console=self.console, default="0"
            ).strip().lower()

            if choice in ("0", "b", "back"):
                break
            if choice == "s":
                self._search_mode()
                continue
            try:
                idx = int(choice) - 1
                if 0 <= idx < len(CATEGORIES):
                    cat_name, icon, cat_key = CATEGORIES[idx]
                    self._browse_category(cat_name, cat_key)
            except ValueError:
                pass

    def _category_panel(self) -> Panel:
        table = Table(box=box.SIMPLE, show_header=False, padding=(0, 1), expand=True)
        table.add_column("#",      style="dim",        width=4)
        table.add_column("Icon",                       width=4)
        table.add_column("Category", style="bold white")
        table.add_column("Tools",  style="cyan", justify="right", width=6)

        for i, (cat_name, icon, cat_key) in enumerate(CATEGORIES, 1):
            count = self._count_in_category(cat_key)
            avail = self._avail_in_category(cat_key)
            count_text = (f"[green]{avail}[/]/[dim]{count}[/]"
                          if count else "[dim]—[/]")
            table.add_row(f"{i}.", icon, cat_name, count_text)

        return Panel(
            table,
            title="[bold cyan]Tool Explorer — Categories[/]",
            subtitle="[dim]S=Search  0=Back[/]",
            border_style="cyan",
            padding=(1, 2),
        )

    # ── category detail ───────────────────────────────────────────────────────

    def _browse_category(self, cat_name: str, cat_key: str) -> None:
        tools = self._tools_for(cat_key)
        if not tools:
            self.console.print(f"[yellow]No tools registered for '{cat_name}'[/]")
            Prompt.ask("[dim]Press Enter[/]", default="")
            return

        while True:
            self.console.clear()
            self.console.print(self._tool_list_panel(cat_name, tools))
            self.console.print()

            choice = Prompt.ask(
                "[cyan]Tool number[/] (or [bold]0[/]=Back)",
                console=self.console, default="0"
            ).strip()

            if choice in ("0", "b"):
                break
            try:
                idx = int(choice) - 1
                if 0 <= idx < len(tools):
                    self.show_tool_detail(tools[idx])
            except ValueError:
                pass

    def _tool_list_panel(self, cat_name: str, tools: list) -> Panel:
        table = Table(box=box.SIMPLE, show_header=True, padding=(0, 1), expand=True)
        table.add_column("#",       style="dim",       width=4)
        table.add_column("Tool",    style="bold white")
        table.add_column("Status",  width=10)
        table.add_column("Stage",   width=7)
        table.add_column("Type",    style="dim", width=10)

        for i, meta in enumerate(tools, 1):
            status = (Text("● OK",       style="green")  if meta.is_available else
                      Text("○ MISSING",  style="yellow"))
            stage  = {1: "[dim]Passive[/]", 2: "[white]Active[/]",
                      3: "[bold]Deep[/]"}.get(meta.stage, "—")
            ptype  = "[dim]Passive[/]" if meta.passive else "[white]Active[/]"
            table.add_row(f"{i}.", meta.name, status, stage, ptype)

        return Panel(
            table,
            title=f"[bold cyan]{cat_name}[/] — {len(tools)} tools",
            subtitle="[dim]0=Back[/]",
            border_style="cyan",
            padding=(1, 2),
        )

    # ── tool detail view ──────────────────────────────────────────────────────

    def show_tool_detail(self, meta) -> None:
        while True:
            self.console.clear()
            self.console.print(self._tool_detail_panel(meta))
            self.console.print()

            self.console.print(
                "[bold cyan][R][/] Run   "
                "[bold green][A][/] Add to Workflow   "
                "[bold blue][L][/] Learn   "
                "[bold dim][0][/] Back"
            )
            choice = Prompt.ask("›", console=self.console, default="0").strip().lower()

            if choice in ("0", "b"):
                break
            elif choice == "r" and self.on_run:
                self.on_run(meta)
            elif choice == "a" and self.on_add_wf:
                self.on_add_wf(meta)
            elif choice == "l" and self.on_learn:
                self.on_learn(meta)
            elif choice == "r":
                self.console.print("[dim]No run handler configured.[/]")
                Prompt.ask("[dim]Press Enter[/]", default="")
            elif choice == "l":
                self._inline_learn(meta)
            elif choice == "a":
                self.console.print("[dim]No workflow handler configured.[/]")
                Prompt.ask("[dim]Press Enter[/]", default="")

    def _tool_detail_panel(self, meta) -> Panel:
        status_text = (Text("● AVAILABLE", style="bold green")
                       if meta.is_available else
                       Text("○ NOT INSTALLED", style="bold yellow"))
        stage_label = {1: "Passive (Stage 1)", 2: "Active (Stage 2)",
                       3: "Deep (Stage 3)"}.get(meta.stage, "Unknown")

        # Header info
        info_table = Table(box=None, show_header=False, padding=(0, 1))
        info_table.add_column("Key",   style="dim",       width=18)
        info_table.add_column("Value", style="bold white")
        info_table.add_row("Binary",    f"[cyan]{meta.binary}[/]")
        info_table.add_row("Category",  meta.category)
        info_table.add_row("Stage",     stage_label)
        info_table.add_row("Type",      "Passive" if meta.passive else "Active")
        info_table.add_row("Status",    status_text)
        info_table.add_row("Timeout",   f"{meta.timeout}s")
        if meta.dependencies:
            info_table.add_row("Deps", ", ".join(meta.dependencies))
        if meta.supported_inputs:
            info_table.add_row("Accepts",  ", ".join(meta.supported_inputs))

        # Description
        desc = meta.description or "No description available."

        # Install command
        install_section = ""
        if not meta.is_available and meta.install_cmd:
            install_section = (
                f"\n[bold yellow]Installation:[/]\n"
                + "\n".join(f"  [dim cyan]{l.strip()}[/]"
                             for l in meta.install_cmd.splitlines() if l.strip())
            )

        # Build content
        content = Group(
            info_table,
            Rule(style="dim cyan"),
            Text(desc, style="white"),
        )

        return Panel(
            content,
            title=f"[bold cyan]{meta.name}[/]",
            subtitle=f"[dim]{meta.module_path}[/]",
            border_style="cyan",
            padding=(1, 2),
        )

    # ── search ────────────────────────────────────────────────────────────────

    def _search_mode(self) -> None:
        self.console.print()
        query = Prompt.ask("[bold cyan]Search tools[/]",
                           console=self.console).strip()
        if not query or not self.registry:
            return

        results = self.registry.search(query)
        if not results:
            self.console.print(f"[yellow]No tools matched '{query}'[/]")
            Prompt.ask("[dim]Press Enter[/]", default="")
            return

        self.console.clear()
        table = Table(box=box.ROUNDED, border_style="cyan", show_header=True,
                      header_style="bold dim")
        table.add_column("#",      width=4)
        table.add_column("Tool",   style="bold white")
        table.add_column("Category", style="cyan")
        table.add_column("Status", width=10)
        table.add_column("Description")

        for i, meta in enumerate(results, 1):
            status = Text("● OK", style="green") if meta.is_available else Text("○", style="yellow")
            table.add_row(
                str(i), meta.name, meta.category, status,
                (meta.description or "")[:60],
            )

        self.console.print(Panel(table, title=f"[cyan]Search: '{query}'[/]",
                                  border_style="cyan"))
        self.console.print()

        choice = Prompt.ask(
            "[dim]Enter number to view, or 0 to cancel[/]",
            console=self.console, default="0"
        ).strip()
        try:
            idx = int(choice) - 1
            if 0 <= idx < len(results):
                self.show_tool_detail(results[idx])
        except ValueError:
            pass

    # ── inline learn ──────────────────────────────────────────────────────────

    def _inline_learn(self, meta) -> None:
        self.console.clear()
        self.console.print(Panel(
            Group(
                Text(f"[bold]{meta.name}[/bold]"),
                Text(""),
                Text(meta.description or "No description.", style="white"),
                Text(""),
                Text(f"Category : {meta.category}",       style="dim"),
                Text(f"Binary   : {meta.binary}",          style="dim"),
                Text(f"Stage    : {meta.stage}",           style="dim"),
                Text(f"Passive  : {'Yes' if meta.passive else 'No'}", style="dim"),
            ),
            title=f"[bold cyan]Learn — {meta.name}[/]",
            border_style="cyan",
        ))
        if meta.install_cmd and not meta.is_available:
            self.console.print(Panel(
                "\n".join(f"  {l}" for l in meta.install_cmd.splitlines()),
                title="[yellow]Installation[/]",
                border_style="yellow",
            ))
        Prompt.ask("\n[dim]Press Enter to continue[/]", default="")

    # ── helpers ───────────────────────────────────────────────────────────────

    def _tools_for(self, cat_key: str) -> list:
        if not self.registry:
            return []
        return sorted(
            self.registry.by_category(cat_key),
            key=lambda m: (m.stage, m.priority),
        )

    def _count_in_category(self, cat_key: str) -> int:
        return len(self._tools_for(cat_key))

    def _avail_in_category(self, cat_key: str) -> int:
        return sum(1 for t in self._tools_for(cat_key) if t.is_available)
