"""
ReconX — TUI: Guided Recon View (Stage 14, Part 5).

Step-by-step guided reconnaissance:
  1. Enter target
  2. Select scope / mode
  3. Review AI-recommended workflow
  4. Confirm or customise
  5. Execute with live status per step
  6. Explain each step as it runs
  7. Save workflow for replay

Designed to teach users WHY each step runs, not just WHAT runs.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from rich import box
from rich.console import Console, Group
from rich.panel import Panel
from rich.progress import (
    BarColumn, MofNCompleteColumn, Progress,
    SpinnerColumn, TextColumn, TimeElapsedColumn,
)
from rich.prompt import Confirm, Prompt
from rich.rule import Rule
from rich.table import Table
from rich.text import Text


# ─────────────────────────────────────────────────────────────────────────────
# Step-level explanations shown during execution
# ─────────────────────────────────────────────────────────────────────────────

STEP_EXPLANATIONS: dict[str, str] = {
    "WhoisTool":          "WHOIS reveals registrar, nameservers, and org details. "
                          "Nameservers often expose internal naming conventions.",
    "CrtshTool":          "Certificate Transparency logs record every SSL cert issued. "
                          "Old certs reveal forgotten subdomains and internal names.",
    "TheHarvesterTool":   "theHarvester queries 20+ OSINT sources simultaneously. "
                          "Emails found here enable phishing simulations and identity correlation.",
    "Sublist3rTool":      "Passive enumeration via search engines — no DNS queries to target. "
                          "Finds subdomains indexed by Google, Bing, and cert databases.",
    "AmassTool":          "Amass combines passive OSINT with active DNS brute-force. "
                          "Finds subdomains that purely passive tools miss.",
    "AlterxTool":         "AlterX generates smart permutations from known subdomains. "
                          "'api.example.com' → 'dev-api', 'api-v2', 'internal-api'.",
    "ShuffleDNSTool":     "Mass DNS validation with wildcard filtering. "
                          "Wildcards (*) inflate results — ShuffleDNS removes them accurately.",
    "PureDNSTool":        "Two-phase validation: public resolvers then trusted resolvers. "
                          "Most accurate subdomain validation available.",
    "NmapTool":           "Port scanning identifies open services on discovered hosts. "
                          "Service version detection enables targeted CVE lookups.",
    "HttpxTool":          "HTTP probing confirms live web services from the subdomain list. "
                          "Captures status, title, and tech stack in one pass.",
    "Wafw00fTool":        "WAF detection before active testing prevents wasted requests. "
                          "Knowing the WAF type informs bypass strategy.",
    "WhatWebTool":        "Technology fingerprinting identifies CMS, frameworks, and servers. "
                          "WordPress → enumerate plugins. PHP → test injection.",
    "GauTool":            "Historical URLs from 4 archive sources. "
                          "Finds endpoints that were removed but may still be accessible.",
    "WaymoreTool":        "Extends GAU with Common Crawl and URLScan.io coverage. "
                          "Particularly good at finding old API versions.",
    "KatanaTool":         "JS-aware crawler that renders SPAs and captures XHR calls. "
                          "Finds routes that static crawlers miss in React/Vue/Angular apps.",
    "FeroxbusterTool":    "Recursive brute-force finds hidden paths not in the HTML. "
                          "Backup files, admin panels, and debug endpoints live here.",
    "ParamSpiderTool":    "Parameter mining from archives reveals what parameters the app accepts. "
                          "Parameters = attack vectors for injection, IDOR, and manipulation.",
    "ArjunTool":          "Active parameter fuzzing — finds hidden params passive tools miss. "
                          "debug=1, verbose=true, internal=yes are common critical findings.",
    "GoWitnessTool":      "Screenshots all discovered services for visual triage. "
                          "Spot login pages, admin panels, and default credentials at a glance.",
    "TrufflehogTool":     "Scans git history for secrets — not just current state. "
                          "Deleted secrets often still live in commit history.",
    "S3ScannerTool":      "Tests common bucket name patterns for public access. "
                          "Company backup buckets are frequently publicly readable.",
    "AsnmapTool":         "Converts the target domain to all IP ranges the org owns. "
                          "Reveals infrastructure beyond what DNS resolves to.",
    "MapCIDRTool":        "Expands CIDR ranges to individual IPs for scanning. "
                          "Safety cap prevents accidental /8 expansion.",
    "FpingTool":          "ICMP sweep to find live hosts before port scanning. "
                          "Avoids wasting Nmap time on dead IPs.",
    "MaltegoTool":        "Exports all findings as a visual entity graph. "
                          "Reveals connections between domains, IPs, emails, and people.",
}


# ─────────────────────────────────────────────────────────────────────────────
# GuidedReconView
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class GuidedSession:
    target:        str
    target_type:   str
    mode:          str
    tool_list:     list[str]
    completed:     list[str] = field(default_factory=list)
    skipped:       list[str] = field(default_factory=list)
    paused_at:     Optional[str] = None
    save_path:     Optional[str] = None
    started_at:    float = field(default_factory=time.time)


class GuidedReconView:
    """
    Interactive guided recon TUI.

    Flow:
      run() → target input → scope selection → workflow preview →
      confirm/customise → execute with step explanations → save
    """

    MODES = [
        ("fast",    "Quick Scan",    "~15 min",  "WHOIS, DNS, Subdomains, HTTPX, Report"),
        ("balanced","Standard",      "~45 min",  "Full recon: passive → active → web"),
        ("deep",    "Deep Recon",    "~2–4 hrs", "All tools, all stages"),
        ("passive", "Passive Only",  "~20 min",  "Zero active traffic, OSINT only"),
        ("ai",      "AI Suggested",  "varies",   "Heuristic-scored tool selection"),
        ("custom",  "Custom",        "varies",   "Choose your own tools"),
    ]

    def __init__(
        self,
        console:   Optional[Console] = None,
        registry   = None,
        engine     = None,       # ReconXEngine instance
    ):
        self.console  = console or Console()
        self.registry = registry
        self.engine   = engine

    # ── main entry ────────────────────────────────────────────────────────────

    def run(self) -> Optional[GuidedSession]:
        """Full guided recon flow. Returns completed GuidedSession or None."""
        self.console.clear()
        self.console.print(Panel(
            "[bold cyan]Guided Recon Mode[/]\n"
            "[dim]ReconX will suggest, explain, and execute a complete "
            "reconnaissance workflow step by step.[/]",
            border_style="cyan", padding=(1, 4),
        ))

        # ── Step 1: Target ────────────────────────────────────────────────────
        target = self._prompt_target()
        if not target:
            return None

        ct = self._classify(target)
        self.console.print(f"\n[green]✓[/] Target identified: "
                           f"[bold cyan]{ct.target_type.upper()}[/] — {ct.normalized}\n")

        # ── Step 2: Mode ──────────────────────────────────────────────────────
        mode = self._prompt_mode()

        # ── Step 3: Workflow recommendation ───────────────────────────────────
        rec = self._recommend(ct, mode)
        if not rec:
            return None

        self._show_workflow_preview(rec, ct.target_type)

        # ── Step 4: Confirm / customise ───────────────────────────────────────
        final_tools = self._confirm_or_customise(rec.tool_list)
        if final_tools is None:
            return None

        session = GuidedSession(
            target      = ct.normalized,
            target_type = ct.target_type,
            mode        = mode,
            tool_list   = final_tools,
        )

        # ── Step 5: Execute ───────────────────────────────────────────────────
        if Confirm.ask("\n[bold cyan]Start reconnaissance?[/]", default=True,
                       console=self.console):
            self._execute_guided(session)
            self._save_prompt(session)

        return session

    # ── target prompt ─────────────────────────────────────────────────────────

    def _prompt_target(self) -> Optional[str]:
        self.console.print("\n[bold]Step 1:[/] Enter your target\n")
        self.console.print("  [dim]Examples:[/]")
        examples = [
            ("Domain",   "example.com"),
            ("IP",       "192.168.1.1"),
            ("CIDR",     "10.0.0.0/16"),
            ("URL",      "https://api.example.com"),
            ("ASN",      "AS13335"),
            ("Email",    "user@example.com"),
            ("GitHub",   "https://github.com/org/repo"),
        ]
        for label, ex in examples:
            self.console.print(f"  [dim]{label:<10}[/] [cyan]{ex}[/]")

        self.console.print()
        target = Prompt.ask("[bold cyan]Target[/]", console=self.console).strip()
        return target if target else None

    # ── mode prompt ───────────────────────────────────────────────────────────

    def _prompt_mode(self) -> str:
        self.console.print("\n[bold]Step 2:[/] Select scan scope\n")
        table = Table(box=None, show_header=False, padding=(0, 2))
        table.add_column("#",     style="cyan",       width=4)
        table.add_column("Mode",  style="bold white")
        table.add_column("Time",  style="dim",        width=10)
        table.add_column("Description", style="dim")

        for i, (key, label, time_est, desc) in enumerate(self.MODES, 1):
            table.add_row(f"[{i}]", label, time_est, desc)

        self.console.print(table)
        self.console.print()

        valid_choices = {str(i): m[0] for i, m in enumerate(self.MODES, 1)}
        choice = Prompt.ask(
            "[bold cyan]Mode[/]",
            choices=list(valid_choices.keys()),
            default="2",
            console=self.console,
        )
        return valid_choices[choice]

    # ── workflow preview ──────────────────────────────────────────────────────

    def _show_workflow_preview(self, rec, target_type: str) -> None:
        self.console.print(f"\n[bold]Step 3:[/] Recommended workflow "
                           f"[dim]({rec.estimated_min} min estimated)[/]\n")

        table = Table(box=box.SIMPLE_HEAVY, border_style="dim cyan",
                      show_header=True, header_style="bold dim")
        table.add_column("#",           width=4)
        table.add_column("Tool",        style="bold white", min_width=24)
        table.add_column("Why",         style="dim")
        table.add_column("Status",      width=10)

        for i, tc in enumerate(rec.tool_list, 1):
            meta   = self.registry.get(tc) if self.registry else None
            why    = STEP_EXPLANATIONS.get(tc, "")[:60]
            status = (Text("● Ready", style="green") if (meta and meta.is_available)
                      else Text("○ Missing", style="yellow"))
            table.add_row(str(i), tc, why, status)

        self.console.print(table)

        if rec.skipped_unavailable:
            self.console.print(
                f"\n[yellow]⚠ {len(rec.skipped_unavailable)} tools excluded "
                f"(not installed):[/] "
                + ", ".join(rec.skipped_unavailable[:5])
            )

    # ── confirm / customise ───────────────────────────────────────────────────

    def _confirm_or_customise(self, tool_list: list[str]) -> Optional[list[str]]:
        self.console.print()
        choice = Prompt.ask(
            "[bold]Step 4:[/] Proceed?  "
            "[cyan][Y][/]=Yes  [yellow][C][/]=Customise  [red][N][/]=Cancel",
            choices=["y", "c", "n"], default="y",
            console=self.console,
        ).lower()

        if choice == "n":
            return None
        if choice == "y":
            return tool_list
        return self._customise_tools(tool_list)

    def _customise_tools(self, tool_list: list[str]) -> list[str]:
        self.console.print("\n[dim]Enter tool numbers to SKIP (comma-separated), or Enter to keep all:[/]")
        for i, tc in enumerate(tool_list, 1):
            self.console.print(f"  [{i}] {tc}")

        raw = Prompt.ask("[dim]Skip (e.g. 3,5,7)[/]", default="",
                         console=self.console).strip()
        if not raw:
            return tool_list

        try:
            skip_indices = {int(x.strip()) - 1 for x in raw.split(",") if x.strip()}
            return [tc for i, tc in enumerate(tool_list) if i not in skip_indices]
        except ValueError:
            return tool_list

    # ── guided execution ──────────────────────────────────────────────────────

    def _execute_guided(self, session: GuidedSession) -> None:
        progress = Progress(
            SpinnerColumn("dots", style="cyan"),
            TextColumn("[cyan]{task.description}"),
            BarColumn(bar_width=28, style="cyan", complete_style="green"),
            MofNCompleteColumn(),
            TimeElapsedColumn(),
            console=self.console,
        )

        total = len(session.tool_list)
        task  = progress.add_task("Running recon", total=total)

        self.console.print("\n[bold]Step 5:[/] Executing reconnaissance\n")

        with progress:
            for i, tool_class in enumerate(session.tool_list, 1):
                # Show explanation before running
                explanation = STEP_EXPLANATIONS.get(tool_class, "")
                if explanation:
                    self.console.print(
                        f"\n[dim cyan]Step {i}/{total}:[/] [bold white]{tool_class}[/]"
                    )
                    self.console.print(f"[dim]{explanation}[/]\n")

                progress.update(task, description=tool_class)
                t0 = time.perf_counter()

                if self.engine and self.registry:
                    meta = self.registry.get(tool_class)
                    if meta and meta.instance:
                        try:
                            result = meta.instance.safe_run(session.target)
                            status = getattr(result, "status", "unknown")
                            findings = len(getattr(result, "findings", []))
                            dur = time.perf_counter() - t0
                            icon = "✓" if status in ("success", "no_output") else "✗"
                            colour = "green" if icon == "✓" else "red"
                            self.console.print(
                                f"  [{colour}]{icon}[/{colour}] {tool_class} "
                                f"[dim]— {findings} findings in {dur:.1f}s[/]"
                            )
                            session.completed.append(tool_class)
                        except Exception as e:
                            self.console.print(
                                f"  [red]✗[/] {tool_class} [dim red]— {e}[/]"
                            )
                    else:
                        self.console.print(
                            f"  [yellow]○[/] {tool_class} [dim]— not available[/]"
                        )
                        session.skipped.append(tool_class)
                else:
                    # Dry-run / no engine
                    time.sleep(0.1)
                    session.completed.append(tool_class)
                    self.console.print(
                        f"  [dim]○ {tool_class} (dry-run)[/]"
                    )

                progress.advance(task)

        # Summary
        dur = time.time() - session.started_at
        self.console.print(Panel(
            f"[green]✓ Completed:[/] {len(session.completed)}   "
            f"[yellow]○ Skipped:[/] {len(session.skipped)}   "
            f"[dim]Time: {dur:.0f}s[/]",
            title="[bold cyan]Guided Recon Complete[/]",
            border_style="green",
        ))

    # ── save prompt ───────────────────────────────────────────────────────────

    def _save_prompt(self, session: GuidedSession) -> None:
        self.console.print()
        if Confirm.ask("[dim]Save workflow for replay?[/]", default=False,
                       console=self.console):
            import json, datetime
            ts   = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            safe = session.target.replace(".", "_")
            path = f"workflows/guided_{safe}_{ts}.json"
            Path("workflows").mkdir(exist_ok=True)
            Path(path).write_text(json.dumps({
                "target":    session.target,
                "type":      session.target_type,
                "mode":      session.mode,
                "tools":     session.tool_list,
                "completed": session.completed,
                "skipped":   session.skipped,
                "timestamp": ts,
            }, indent=2))
            session.save_path = path
            self.console.print(f"[green]✓[/] Workflow saved to [cyan]{path}[/]")

    # ── helpers ───────────────────────────────────────────────────────────────

    def _classify(self, target: str):
        try:
            from reconx.analysis.target_classifier import TargetClassifier
        except ModuleNotFoundError:
            from analysis.target_classifier import TargetClassifier
        return TargetClassifier.classify(target)

    def _recommend(self, ct, mode: str):
        try:
            from reconx.workflow.recommendation_engine import RecommendationEngine
        except ModuleNotFoundError:
            from workflow.recommendation_engine import RecommendationEngine
        engine = RecommendationEngine(self.registry)
        return engine.recommend(ct, mode, filter_unavailable=True)
