"""
ReconX — Web Intelligence TUI Panel (Stage 18.1)

Renders a rich Web Intelligence panel in the ReconX terminal UI.
Displays live Burp Suite proxy data including:

  ┌─ Web Intelligence ──────────────────────────────────────────────┐
  │ Status:  ✓ active  ⚡ capturing   Proxy: 127.0.0.1:8080        │
  │ Session: a1b2c3d4  Project: reconx_example_com_20250501_143022  │
  ├─────────────────────────────────────────────────────────────────┤
  │  CAPTURED REQUESTS │ ENDPOINTS │ COOKIES │ SESSIONS │ ISSUES    │
  ├─────────────────────────────────────────────────────────────────┤
  │ [live table content]                                            │
  └─────────────────────────────────────────────────────────────────┘

Integrates with:
  - BurpIntelligenceLayer.get_status()
  - Session traffic summaries
  - Burp passive findings

Rendering: Rich only (no Textual dependency).
"""
from __future__ import annotations

import logging
from typing import Optional

from rich import box
from rich.columns import Columns
from rich.console import Console
from rich.panel import Panel
from rich.rule import Rule
from rich.table import Table
from rich.text import Text

logger = logging.getLogger("reconx.tui.web_intelligence")

# ── Status icon helpers ───────────────────────────────────────────────────────

def _api_icon(reachable: bool) -> Text:
    return Text("✓ active", style="bold green") if reachable else Text("✗ failed", style="bold red")

def _proxy_icon(running: bool) -> Text:
    return Text("⚡ capturing", style="bold cyan") if running else Text("⏸ idle", style="dim")

def _session_icon(state: str) -> Text:
    icons = {
        "active":  Text("▶ active",  style="green"),
        "resumed": Text("▶ resumed", style="cyan"),
        "paused":  Text("⏸ paused",  style="yellow"),
        "stopped": Text("■ stopped", style="dim"),
        "none":    Text("— none",    style="dim"),
    }
    return icons.get(state, Text(state, style="dim"))


class WebIntelligencePanel:
    """
    Renders the Web Intelligence panel for the ReconX TUI.

    Designed to be called from Dashboard or Navigator:
        panel = WebIntelligencePanel(burp_layer)
        panel.render(console)
    """

    def __init__(self, burp_layer=None):
        """
        Args:
            burp_layer: BurpIntelligenceLayer instance (optional).
                        If None, renders a 'not connected' placeholder.
        """
        self._burp = burp_layer

    # ══════════════════════════════════════════════════════════════════════════
    # Main render
    # ══════════════════════════════════════════════════════════════════════════

    def render(self, console: Console, data: Optional[dict] = None) -> None:
        """
        Render the complete Web Intelligence panel to the console.

        Args:
            console: Rich Console instance.
            data:    Pre-fetched burp data dict (from BurpIntelligenceLayer.get_status()
                     merged with session traffic_summary). If None, fetches live.
        """
        if data is None:
            data = self._fetch_status()

        console.print(Rule("[bold cyan]Web Intelligence[/bold cyan]", style="cyan"))
        console.print()

        # ── Status bar ────────────────────────────────────────────────────────
        self._render_status_bar(console, data)
        console.print()

        # ── Stats row ─────────────────────────────────────────────────────────
        self._render_stats_row(console, data)
        console.print()

        # ── Content tabs ──────────────────────────────────────────────────────
        traffic = data.get("traffic", {})

        self._render_endpoints_table(console, traffic.get("endpoints", []))
        console.print()

        self._render_auth_table(console, traffic.get("auth_tokens", []))
        console.print()

        self._render_cookies_table(console, traffic.get("cookies", []))
        console.print()

        self._render_issues_table(console, traffic.get("security_issues", []))
        console.print()

        self._render_discovery_section(console, traffic)
        console.print()

    # ══════════════════════════════════════════════════════════════════════════
    # Sub-renders
    # ══════════════════════════════════════════════════════════════════════════

    def _render_status_bar(self, console: Console, data: dict) -> None:
        """Render the top status bar (API, proxy, session)."""
        session_id    = data.get("current_session") or "—"
        session_state = data.get("session_state", "none")
        proxy_url     = data.get("proxy_url", "127.0.0.1:8080")
        project       = data.get("current_project") or "—"
        burp_ver      = data.get("burp_version", "unknown")

        status_text = Text()
        status_text.append("API: ")
        status_text.append_text(_api_icon(data.get("api_reachable", False)))
        status_text.append("   Proxy: ")
        status_text.append_text(_proxy_icon(data.get("proxy_running", False)))
        status_text.append(f"   {proxy_url}", style="cyan")
        status_text.append(f"   v{burp_ver}", style="dim")

        console.print(Panel(
            status_text,
            title="[bold cyan]Burp Suite Integration[/bold cyan]",
            subtitle=f"[dim]Session: {session_id}  |  Project: {project[:50]}[/dim]",
            border_style="cyan",
            padding=(0, 2),
        ))

        # Session state pill
        console.print(
            Text("  Session state: ") + _session_icon(session_state),
            end="\n",
        )

    def _render_stats_row(self, console: Console, data: dict) -> None:
        """Render the summary stat cards in a horizontal row."""
        traffic = data.get("traffic", {})
        issues  = data.get("issues", {})

        stats = [
            ("Requests",    str(traffic.get("total_requests", 0)),   "cyan"),
            ("Endpoints",   str(len(traffic.get("endpoints", []))),  "green"),
            ("API Routes",  str(len(traffic.get("api_routes", []))), "yellow"),
            ("Auth Tokens", str(len(traffic.get("auth_tokens", []))), "magenta"),
            ("Cookies",     str(len(traffic.get("cookies", []))),    "blue"),
            ("Issues",      str(issues.get("total", 0)),             "red"),
            ("Site Map",    str(data.get("site_map", {}).get("url_count", 0)), "white"),
        ]

        panels = []
        for label, value, colour in stats:
            t = Text(justify="center")
            t.append(f"{value}\n", style=f"bold {colour}")
            t.append(label, style="dim")
            panels.append(Panel(t, border_style=colour, padding=(0, 2), expand=True))

        console.print(Columns(panels, equal=True))

    def _render_endpoints_table(self, console: Console, endpoints: list[dict]) -> None:
        """Render captured endpoints table."""
        tbl = Table(
            title="🛰️  Captured Endpoints",
            border_style="cyan",
            box=box.SIMPLE_HEAVY,
            show_lines=False,
        )
        tbl.add_column("Method", style="bold yellow", width=8, no_wrap=True)
        tbl.add_column("URL",    style="white",        max_width=80)
        tbl.add_column("Status", style="cyan",         width=7, justify="center")
        tbl.add_column("Type",   style="green",        width=14)

        if not endpoints:
            tbl.add_row("—", "[dim]No endpoints captured yet[/dim]", "—", "—")
        else:
            for ep in endpoints[:25]:
                status     = ep.get("status", 0)
                status_str = str(status)
                status_sty = (
                    "bold green"  if 200 <= status < 300 else
                    "yellow"      if 300 <= status < 400 else
                    "bold red"    if status >= 400        else
                    "dim"
                )
                cats  = ep.get("categories", [])
                ttype = ", ".join(cats[:2]) if cats else "general"
                tbl.add_row(
                    ep.get("method", "GET"),
                    ep.get("url", "")[:80],
                    Text(status_str, style=status_sty),
                    ttype,
                )
            if len(endpoints) > 25:
                tbl.add_row(
                    "…",
                    f"[dim]+{len(endpoints) - 25} more endpoints[/dim]",
                    "—", "—",
                )

        console.print(tbl)

    def _render_auth_table(self, console: Console, tokens: list[dict]) -> None:
        """Render extracted authentication tokens."""
        tbl = Table(
            title="🔑  Auth Tokens & Credentials",
            border_style="magenta",
            box=box.SIMPLE_HEAVY,
        )
        tbl.add_column("Type",  style="bold magenta", width=12)
        tbl.add_column("Value", style="white",        max_width=50)
        tbl.add_column("URL",   style="dim",          max_width=50)

        if not tokens:
            tbl.add_row("—", "[dim]No auth tokens captured[/dim]", "—")
        else:
            for tok in tokens[:15]:
                tbl.add_row(
                    tok.get("type", "unknown"),
                    tok.get("value", "")[:50],
                    tok.get("url",   "")[:50],
                )

        console.print(tbl)

    def _render_cookies_table(self, console: Console, cookies: list[dict]) -> None:
        """Render captured cookies with security attribute flags."""
        tbl = Table(
            title="🍪  Session Cookies",
            border_style="blue",
            box=box.SIMPLE_HEAVY,
        )
        tbl.add_column("Name",      style="bold cyan",  max_width=25)
        tbl.add_column("Host",      style="dim",        max_width=30)
        tbl.add_column("Secure",    style="green",      width=8,  justify="center")
        tbl.add_column("HttpOnly",  style="green",      width=10, justify="center")
        tbl.add_column("SameSite",  style="yellow",     width=10, justify="center")

        seen = set()
        if not cookies:
            tbl.add_row("—", "[dim]No cookies captured[/dim]", "—", "—", "—")
        else:
            for ck in cookies:
                key = f"{ck.get('name')}@{ck.get('host')}"
                if key in seen:
                    continue
                seen.add(key)
                tbl.add_row(
                    ck.get("name",      "—")[:25],
                    ck.get("host",      "—")[:30],
                    "✓" if ck.get("secure")    else "[red]✗[/red]",
                    "✓" if ck.get("http_only") else "[red]✗[/red]",
                    ck.get("same_site", "—") or "—",
                )

        console.print(tbl)

    def _render_issues_table(self, console: Console, issues: list[dict]) -> None:
        """Render Burp passive security findings."""
        tbl = Table(
            title="⚠️  Passive Security Issues",
            border_style="red",
            box=box.SIMPLE_HEAVY,
        )
        tbl.add_column("Type",   style="bold red", width=16)
        tbl.add_column("Detail", style="white",    max_width=55)
        tbl.add_column("URL",    style="dim",       max_width=40)

        if not issues:
            tbl.add_row("—", "[dim green]No passive issues detected[/dim green]", "—")
        else:
            for issue in issues[:20]:
                tbl.add_row(
                    issue.get("type",   "—")[:16],
                    issue.get("detail", issue.get("header", "—"))[:55],
                    issue.get("url",    "—")[:40],
                )

        console.print(tbl)

    def _render_discovery_section(self, console: Console, traffic: dict) -> None:
        """Render web discovery summary (login pages, admin portals, OAuth, etc.)."""
        sections = [
            ("Login Pages",    traffic.get("login_pages",    []), "yellow"),
            ("Admin Portals",  traffic.get("admin_portals",  []), "red"),
            ("Upload Forms",   traffic.get("upload_forms",   []), "magenta"),
            ("OAuth Flows",    traffic.get("oauth_flows",    []), "cyan"),
            ("SSO Pages",      traffic.get("sso_pages",      []), "blue"),
            ("GraphQL",        traffic.get("graphql_endpoints", []), "green"),
            ("SPA Routes",     traffic.get("spa_routes",     []), "white"),
        ]

        panels = []
        for label, items, colour in sections:
            if not items:
                content = Text(f"None", style="dim")
            else:
                content = Text()
                for url in items[:3]:
                    content.append(f"• {url[:45]}\n", style=colour)
                if len(items) > 3:
                    content.append(f"  +{len(items) - 3} more…", style="dim")

            panels.append(Panel(
                content,
                title=f"[{colour}]{label}[/{colour}]",
                border_style=colour,
                padding=(0, 1),
                expand=True,
            ))

        console.print(Rule("[dim]Web Discovery[/dim]", style="dim"))
        console.print(Columns(panels[:4], equal=True))
        console.print(Columns(panels[4:], equal=True))

    # ══════════════════════════════════════════════════════════════════════════
    # Data fetch
    # ══════════════════════════════════════════════════════════════════════════

    def _fetch_status(self) -> dict:
        """Fetch live status from BurpIntelligenceLayer."""
        if self._burp is None:
            return {"api_reachable": False, "session_state": "none"}
        try:
            status  = self._burp.get_status()
            session = self._burp._current_session
            traffic = session.traffic_summary if session else {}
            return {**status, "traffic": traffic}
        except Exception as exc:
            logger.debug("[WebIntelligencePanel] Status fetch failed: %s", exc)
            return {"api_reachable": False, "session_state": "none"}


# ── Convenience render function ───────────────────────────────────────────────

def render_web_intelligence(
    console:    Console,
    burp_layer: Optional[object] = None,
    data:       Optional[dict]   = None,
) -> None:
    """
    Standalone render helper — can be called from any TUI view.

        from reconx.tui.views.web_intelligence_view import render_web_intelligence
        render_web_intelligence(console, burp_layer=layer)
    """
    WebIntelligencePanel(burp_layer).render(console, data=data)
