"""
ReconX — Traffic Intelligence TUI Panel (Stage 18.2)

Rich-rendered Traffic Intelligence panel for the ReconX TUI.

Shows:
  ┌─ Traffic Intelligence ─────────────────────────────────────────┐
  │ Status: ✓ running  ⚡ analyzing   Interface: eth0             │
  │ Duration: 30s   Packets: 1,247   Packets/sec: 41.6            │
  ├─────────────────────────────────────────────────────────────────┤
  │  PROTOCOLS │ TOP TALKERS │ HOSTS │ CREDENTIALS │ ALERTS        │
  ├─────────────────────────────────────────────────────────────────┤
  │ [live table content]                                            │
  └─────────────────────────────────────────────────────────────────┘
"""
from __future__ import annotations

import logging
from typing import Optional

from rich import box
from rich.columns import Columns
from rich.console import Console
from rich.panel import Panel
from rich.rule import Rule
from rich.table import Table
from rich.text import Text

from ..network.models import TrafficSummary, Severity

logger = logging.getLogger("reconx.tui.traffic_view")


def _sev_style(sev: str) -> str:
    return {"HIGH": "bold red", "CRITICAL": "bold red",
            "MEDIUM": "yellow", "LOW": "green"}.get(sev.upper(), "white")


def _status_icon(state: str) -> Text:
    icons = {
        "capturing": Text("⚡ capturing", style="bold cyan"),
        "analyzing": Text("⚡ analyzing", style="bold yellow"),
        "complete":  Text("✓ complete",  style="bold green"),
        "error":     Text("✗ failed",    style="bold red"),
        "idle":      Text("⏸ idle",      style="dim"),
    }
    return icons.get(state, Text(state, style="dim"))


class TrafficIntelligencePanel:
    """
    Renders the Traffic Intelligence panel in the ReconX TUI.

    Usage:
        panel = TrafficIntelligencePanel()
        panel.render(console, summary=summary, state="complete", interface="eth0")
    """

    def render(
        self,
        console:   Console,
        summary:   Optional[TrafficSummary] = None,
        state:     str = "idle",
        interface: str = "",
        duration_s: int = 0,
    ) -> None:
        summary = summary or TrafficSummary()
        console.print(Rule("[bold cyan]Traffic Intelligence[/bold cyan]", style="cyan"))
        console.print()

        self._render_status_bar(console, summary, state, interface, duration_s)
        console.print()
        self._render_stats_row(console, summary)
        console.print()
        self._render_protocols_table(console, summary)
        console.print()
        self._render_top_talkers_table(console, summary)
        console.print()
        self._render_credentials_table(console, summary)
        console.print()
        self._render_anomalies_table(console, summary)
        console.print()
        self._render_dns_section(console, summary)
        console.print()
        self._render_tls_section(console, summary)
        console.print()
        self._render_discovery_grid(console, summary)
        console.print()

    # ── Status bar ────────────────────────────────────────────────────────────
    def _render_status_bar(self, console, summary, state, iface, duration):
        t = Text()
        t.append("Status: ")
        t.append_text(_status_icon(state))
        t.append(f"   Interface: ")
        t.append(iface or "—", style="cyan")
        t.append(f"   Duration: ")
        t.append(f"{duration}s", style="yellow")
        t.append(f"   Packets: ")
        t.append(f"{summary.total_packets:,}", style="white")
        if summary.packets_per_sec:
            t.append(f"   Pkt/s: ")
            t.append(f"{summary.packets_per_sec:.1f}", style="cyan")

        console.print(Panel(t, title="[bold cyan]Traffic Intelligence[/bold cyan]",
                            border_style="cyan", padding=(0, 2)))

    # ── Stats row ─────────────────────────────────────────────────────────────
    def _render_stats_row(self, console, summary):
        def stat(n, label, colour):
            t = Text(justify="center")
            t.append(f"{n}\n", style=f"bold {colour}")
            t.append(label, style="dim")
            return Panel(t, border_style=colour, padding=(0, 2), expand=True)

        panels = [
            stat(f"{summary.total_packets:,}", "Packets",     "cyan"),
            stat(len(summary.protocols),        "Protocols",   "green"),
            stat(len(summary.ips),              "IPs",         "yellow"),
            stat(len(summary.hosts),            "Hosts",       "blue"),
            stat(len(summary.dns_entries),      "DNS Queries", "magenta"),
            stat(len(summary.http_records),     "HTTP Records","white"),
            stat(len(summary.tls_records),      "TLS Sessions","cyan"),
            stat(len(summary.credentials),      "Credentials", "red"),
            stat(len(summary.anomalies),        "Anomalies",   "red"),
        ]
        console.print(Columns(panels, equal=True))

    # ── Protocol table ────────────────────────────────────────────────────────
    def _render_protocols_table(self, console, summary):
        tbl = Table(title="📡  Protocol Inventory", border_style="cyan",
                    box=box.SIMPLE_HEAVY)
        tbl.add_column("Protocol",   style="bold cyan",  width=16)
        tbl.add_column("Confidence", style="green",      width=12, justify="right")
        tbl.add_column("Port",       style="yellow",     width=8)
        tbl.add_column("Detail",     style="dim",        max_width=50)

        if not summary.protocols:
            tbl.add_row("—", "[dim]No protocols detected[/dim]", "—", "—")
        else:
            for p in summary.protocols[:20]:
                tbl.add_row(p.protocol, p.confidence_pct,
                            str(p.port) if p.port else "—", p.detail or "—")
        console.print(tbl)

    # ── Top talkers ───────────────────────────────────────────────────────────
    def _render_top_talkers_table(self, console, summary):
        tbl = Table(title="📊  Top Talkers", border_style="green", box=box.SIMPLE_HEAVY)
        tbl.add_column("IP",      style="bold yellow",  max_width=18)
        tbl.add_column("Packets", style="cyan",         width=10, justify="right")
        tbl.add_column("Bytes",   style="white",        width=12, justify="right")
        tbl.add_column("Type",    style="dim",          width=10)

        if not summary.top_talkers:
            tbl.add_row("—", "—", "—", "—")
        else:
            for t in summary.top_talkers[:10]:
                ip   = t.get("ip", "—")
                kind = "internal" if ip in summary.internal_ips else "external"
                tbl.add_row(ip, f"{t.get('packets', 0):,}",
                            _human_bytes(t.get("bytes", 0)), kind)
        console.print(tbl)

    # ── Credentials ───────────────────────────────────────────────────────────
    def _render_credentials_table(self, console, summary):
        tbl = Table(title="🔑  Credential Findings", border_style="red",
                    box=box.SIMPLE_HEAVY)
        tbl.add_column("Tag",      style="bold red",  width=12)
        tbl.add_column("Protocol", style="cyan",      width=10)
        tbl.add_column("Value",    style="white",     max_width=40)
        tbl.add_column("Route",    style="dim",       max_width=30)
        tbl.add_column("Severity", style="yellow",    width=10)

        if not summary.credentials:
            tbl.add_row("—", "—", "[dim green]No credentials found[/dim green]", "—", "—")
        else:
            for c in summary.credentials[:15]:
                tbl.add_row(
                    f"[{c.tag.value}]",
                    c.source_proto,
                    c.masked_value,
                    f"{c.src_ip}→{c.dst_ip}"[:30],
                    Text(c.severity.value, style=_sev_style(c.severity.value)),
                )
        console.print(tbl)

    # ── Anomalies ─────────────────────────────────────────────────────────────
    def _render_anomalies_table(self, console, summary):
        tbl = Table(title="⚠️  Anomaly Alerts", border_style="yellow",
                    box=box.SIMPLE_HEAVY)
        tbl.add_column("Type",       style="bold yellow", width=18)
        tbl.add_column("Severity",   style="red",         width=9)
        tbl.add_column("Confidence", style="cyan",        width=11)
        tbl.add_column("Description", style="white",      max_width=55)

        if not summary.anomalies:
            tbl.add_row("—", "—", "—", "[dim green]No anomalies detected[/dim green]")
        else:
            for a in sorted(summary.anomalies,
                            key=lambda x: x.severity.value + x.confidence_pct,
                            reverse=True)[:15]:
                tbl.add_row(
                    a.alert_type.replace("_", " "),
                    Text(a.severity.value, style=_sev_style(a.severity.value)),
                    a.confidence_pct,
                    a.description[:55],
                )
        console.print(tbl)

    # ── DNS ───────────────────────────────────────────────────────────────────
    def _render_dns_section(self, console, summary):
        suspicious = [e for e in summary.dns_entries if e.is_tunnel_suspect]
        tbl = Table(title="🌐  DNS Intelligence", border_style="magenta",
                    box=box.SIMPLE_HEAVY)
        tbl.add_column("Query",      style="cyan",       max_width=45)
        tbl.add_column("Type",       style="yellow",     width=7)
        tbl.add_column("Answers",    style="white",      max_width=30)
        tbl.add_column("Flag",       style="red",        width=10)

        if not summary.dns_entries:
            tbl.add_row("[dim]No DNS data[/dim]", "—", "—", "—")
        else:
            shown = set()
            count = 0
            for e in summary.dns_entries:
                if e.query_name in shown or count >= 20:
                    continue
                shown.add(e.query_name)
                count += 1
                flag = "⚠ TUNNEL" if e.is_tunnel_suspect else ("↑ FREQ" if e.is_high_freq else "")
                tbl.add_row(e.query_name[:45], e.record_type,
                            ", ".join(e.answers[:2])[:30], flag)
        console.print(tbl)
        if suspicious:
            console.print(
                f"  [bold red]⚠ {len(suspicious)} DNS tunneling suspects detected[/bold red] "
                f"— run [cyan]reconx traffic analyze[/cyan] for detail"
            )

    # ── TLS ───────────────────────────────────────────────────────────────────
    def _render_tls_section(self, console, summary):
        tbl = Table(title="🔒  TLS Analysis", border_style="blue", box=box.SIMPLE_HEAVY)
        tbl.add_column("SNI / Host",  style="cyan",    max_width=35)
        tbl.add_column("TLS Ver",     style="yellow",  width=10)
        tbl.add_column("JA3",         style="dim",     max_width=20)
        tbl.add_column("Risks",       style="red",     max_width=30)

        if not summary.tls_records:
            tbl.add_row("[dim]No TLS sessions[/dim]", "—", "—", "—")
        else:
            for r in summary.tls_records[:15]:
                risks = []
                if r.is_legacy_tls:   risks.append("Legacy TLS")
                if r.is_weak_cipher:  risks.append("Weak cipher")
                if r.is_expired:      risks.append("Expired cert")
                if r.is_self_signed:  risks.append("Self-signed")
                risk_str = ", ".join(risks) if risks else "✓ OK"
                risk_sty = "red" if risks else "green"
                tbl.add_row(
                    r.sni or r.dst_ip,
                    r.tls_version or "—",
                    r.ja3[:18] + "…" if len(r.ja3) > 18 else r.ja3 or "—",
                    Text(risk_str, style=risk_sty),
                )
        console.print(tbl)

    # ── Web discovery grid ────────────────────────────────────────────────────
    def _render_discovery_grid(self, console, summary):
        from .web_intelligence_view import _disc_card
        http = summary.http_records

        def _urls(pred):
            return list(dict.fromkeys(r.url for r in http if pred(r)))

        cards_data = [
            ("API Endpoints",   _urls(lambda r: r.is_api),    "#00d4ff"),
            ("Auth Routes",     _urls(lambda r: r.is_auth),   "#ffd60a"),
            ("Admin Panels",    _urls(lambda r: r.is_admin),  "#ff2d55"),
            ("Upload Forms",    _urls(lambda r: r.is_upload), "#ff6b35"),
            ("External IPs",    summary.external_ips[:5],     "#30d158"),
            ("Internal Hosts",  summary.internal_ips[:5],     "#00ffcc"),
        ]

        console.print(Rule("[dim]Web Discovery from Traffic[/dim]", style="dim"))
        panels = []
        for label, items, colour in cards_data:
            if not items:
                body = Text("None detected", style="dim")
            else:
                body = Text()
                for item in items[:4]:
                    body.append(f"• {str(item)[:45]}\n", style=colour)
                if len(items) > 4:
                    body.append(f"  +{len(items)-4} more…", style="dim")
            panels.append(Panel(body, title=f"[{colour}]{label}[/{colour}]",
                                border_style=colour, padding=(0,1), expand=True))

        console.print(Columns(panels[:3], equal=True))
        console.print(Columns(panels[3:], equal=True))


def _human_bytes(b: int) -> str:
    for unit in ("B", "KB", "MB", "GB"):
        if b < 1024:
            return f"{b:.0f}{unit}"
        b //= 1024
    return f"{b:.0f}TB"


def render_traffic_intelligence(
    console:    Console,
    summary:    Optional[TrafficSummary] = None,
    state:      str = "idle",
    interface:  str = "",
    duration_s: int = 0,
) -> None:
    """Standalone render helper called from any TUI view."""
    TrafficIntelligencePanel().render(
        console, summary=summary, state=state,
        interface=interface, duration_s=duration_s,
    )
