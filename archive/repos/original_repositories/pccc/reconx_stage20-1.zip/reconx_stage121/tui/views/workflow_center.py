"""
ReconX — Stage 16: TUI Workflow Center.

Interactive terminal interface for the workflow system.

Menu:
  [1] Fast Recon          — run fast_scan template immediately
  [2] Deep Recon          — run deep_scan template
  [3] Passive Recon       — run passive_recon template
  [4] Cloud Recon         — run cloud_recon template
  [5] Guided Recon        — launch interactive GuidedRecon assistant
  [6] Replay Session      — browse and replay a past session
  [7] Resume Interrupted  — recover an interrupted scan
  [8] Workflow Library    — browse all 11 templates
  [9] Custom Template     — run any template by name
  [0] Back

Integrates with:
  workflow.engine      — WorkflowEngine
  workflow.templates   — WorkflowTemplates
  workflow.recorder    — WorkflowRecorder
  workflow.replay      — WorkflowReplayer
  workflow.checkpoint  — CheckpointManager
  workflow.guided      — GuidedRecon
"""
from __future__ import annotations

import logging
import time
from typing import Optional

from rich import box
from rich.columns import Columns
from rich.console import Console
from rich.panel import Panel
from rich.prompt import IntPrompt, Prompt
from rich.rule import Rule
from rich.table import Table
from rich.text import Text

log = logging.getLogger("reconx.tui.workflow_center")


class WorkflowCenter:
    """
    Full-feature TUI for ReconX workflow management.

    Replaces the Stage 15 stub _workflow_center() in Navigator.
    """

    def __init__(
        self,
        console:  Optional[Console] = None,
        registry: Optional[object]  = None,
        engine:   Optional[object]  = None,
    ):
        self.console  = console  or Console()
        self.registry = registry
        self.engine   = engine
        self._wf_engine   = None
        self._recorder    = None
        self._replayer    = None
        self._checkpoints = None

    # ── Entry ─────────────────────────────────────────────────────────────────

    def run(self) -> None:
        """Main workflow centre loop."""
        while True:
            choice = self._main_menu()
            if choice in ("0", "q", "back", ""):
                break
            self._route(choice)

    # ── Menu ──────────────────────────────────────────────────────────────────

    def _main_menu(self) -> str:
        self.console.clear()
        self._print_header()

        # Interrupted scan badge
        interrupted = self._get_checkpoints().list_interrupted()
        if interrupted:
            self.console.print(
                f"[bold yellow]⚠  {len(interrupted)} interrupted scan(s) detected. "
                f"Select [7] to resume.[/]\n"
            )

        table = Table(box=box.SIMPLE, show_header=False, border_style="dim cyan",
                      padding=(0, 2))
        table.add_column("key",   style="bold cyan",  width=4, no_wrap=True)
        table.add_column("name",  style="bold white",  width=22)
        table.add_column("desc",  style="dim")

        rows = [
            ("1", "⚡  Fast Recon",       "Quick 5-minute scan — top-yield tools only"),
            ("2", "🔍  Deep Recon",        "Maximum coverage, all phases, all tools"),
            ("3", "🕵️   Passive Recon",    "Zero-traffic OSINT — no active probes"),
            ("4", "☁️   Cloud Recon",       "S3 buckets, cloud hosts, storage exposure"),
            ("─", "─────────────────────", "────────────────────────────────────────"),
            ("5", "🧭  Guided Recon",       "Interactive senior analyst assistant"),
            ("─", "─────────────────────", "────────────────────────────────────────"),
            ("6", "▶   Replay Session",     "Re-run or clone a past session"),
            ("7", "⏯   Resume Interrupted", "Continue an interrupted scan from checkpoint"),
            ("─", "─────────────────────", "────────────────────────────────────────"),
            ("8", "📚  Workflow Library",   "Browse all 11 built-in templates"),
            ("9", "✏️   Custom Template",    "Run any template by name"),
            ("0", "←   Back",               "Return to main menu"),
        ]

        for key, name, desc in rows:
            if key == "─":
                table.add_row("[dim]─[/]", f"[dim]{name}[/]", f"[dim]{desc}[/]")
            else:
                table.add_row(key, name, desc)

        self.console.print(table)
        self.console.print()

        try:
            return Prompt.ask("[bold cyan]Choice[/]", default="0").strip()
        except (KeyboardInterrupt, EOFError):
            return "0"

    def _route(self, choice: str) -> None:
        routes = {
            "1": lambda: self._run_template("fast_scan"),
            "2": lambda: self._run_template("deep_scan"),
            "3": lambda: self._run_template("passive_recon"),
            "4": lambda: self._run_template("cloud_recon"),
            "5": self._guided_recon,
            "6": self._replay_session,
            "7": self._resume_interrupted,
            "8": self._workflow_library,
            "9": self._custom_template,
        }
        handler = routes.get(choice)
        if handler:
            handler()

    # ── Quick-launch templates ────────────────────────────────────────────────

    def _run_template(self, name: str) -> None:
        """Prompt for target then run named template."""
        try:
            from reconx.workflow.templates import WorkflowTemplates
        except ModuleNotFoundError:
            from workflow.templates import WorkflowTemplates

        wf = WorkflowTemplates.get(name)
        if not wf:
            self.console.print(f"[red]Template '{name}' not found.[/]")
            self._pause()
            return

        self.console.clear()
        self._print_workflow_detail(wf)

        target = self._prompt_target()
        if not target:
            return

        self._execute_workflow(wf, target)

    # ── Guided Recon ──────────────────────────────────────────────────────────

    def _guided_recon(self) -> None:
        self.console.clear()
        try:
            from reconx.workflow.guided import GuidedRecon
        except ModuleNotFoundError:
            from workflow.guided import GuidedRecon

        guided = GuidedRecon(
            engine   = self._get_wf_engine(),
            recorder = self._get_recorder(),
        )
        guided.run()
        self._pause()

    # ── Replay ────────────────────────────────────────────────────────────────

    def _replay_session(self) -> None:
        self.console.clear()
        self.console.print(Rule("[bold cyan]Replay Session[/]", style="cyan"))

        sessions = self._get_recorder().list_sessions()
        if not sessions:
            self.console.print("[dim]No sessions found in sessions/ directory.[/]")
            self._pause()
            return

        self._print_session_list(sessions)

        try:
            raw = Prompt.ask("\n[cyan]Session ID or # to replay[/]", default="").strip()
        except (KeyboardInterrupt, EOFError):
            return

        if not raw:
            return

        session_id = self._resolve_session_id(raw, sessions)
        if not session_id:
            self.console.print("[red]Session not found.[/]")
            self._pause()
            return

        # Options: replay same target, or clone to new target
        try:
            mode = Prompt.ask(
                "[cyan]Mode[/] — (r)eplay same target / (c)lone to new target",
                default="r",
            ).lower()
        except (KeyboardInterrupt, EOFError):
            return

        try:
            replayer = self._get_replayer()
            if mode == "c":
                new_target = Prompt.ask("[cyan]New target[/]", default="").strip()
                session = replayer.clone(session_id, new_target=new_target or None)
            else:
                session = replayer.replay(session_id)

            if session:
                self.console.print(
                    f"\n[green]✓[/] Replay complete — "
                    f"{session.total_findings} findings in {session.duration_s:.1f}s"
                )
        except Exception as exc:
            self.console.print(f"[red]Replay failed: {exc}[/]")

        self._pause()

    # ── Resume ────────────────────────────────────────────────────────────────

    def _resume_interrupted(self) -> None:
        self.console.clear()
        self.console.print(Rule("[bold yellow]Resume Interrupted Scans[/]", style="yellow"))

        interrupted = self._get_checkpoints().list_interrupted()
        if not interrupted:
            self.console.print("[dim]No interrupted sessions found.[/]")
            self._pause()
            return

        table = Table(box=box.SIMPLE_HEAD, border_style="yellow")
        table.add_column("#",          style="dim cyan",  width=4)
        table.add_column("Session",    style="bold white")
        table.add_column("Workflow",   style="cyan")
        table.add_column("Target",     style="green")
        table.add_column("Progress",   style="yellow")

        for i, s in enumerate(interrupted, 1):
            prog = f"{s['completed_steps']}/{s['total_steps']} steps"
            table.add_row(str(i), s["session_id"][-20:], s["workflow_name"],
                          s["target"], prog)
        self.console.print(table)
        self.console.print()

        try:
            raw = Prompt.ask("[yellow]# to resume (or Enter to cancel)[/]",
                             default="").strip()
        except (KeyboardInterrupt, EOFError):
            return

        if not raw:
            return

        try:
            idx = int(raw) - 1
            if 0 <= idx < len(interrupted):
                session_id = interrupted[idx]["session_id"]
                replayer = self._get_replayer()
                session = replayer.resume(session_id)
                if session:
                    self.console.print(
                        f"\n[green]✓[/] Resume complete — "
                        f"{session.total_findings} findings"
                    )
            else:
                self.console.print("[red]Invalid selection.[/]")
        except (ValueError, Exception) as exc:
            self.console.print(f"[red]Resume failed: {exc}[/]")

        self._pause()

    # ── Workflow Library ──────────────────────────────────────────────────────

    def _workflow_library(self) -> None:
        self.console.clear()
        self.console.print(Rule("[bold cyan]Workflow Library[/]", style="cyan"))

        try:
            from reconx.workflow.templates import WorkflowTemplates
        except ModuleNotFoundError:
            from workflow.templates import WorkflowTemplates

        templates = WorkflowTemplates.list_all()

        # Summary table
        table = Table(
            title="Built-in Workflow Templates",
            box=box.SIMPLE_HEAD,
            border_style="cyan",
        )
        table.add_column("#",        style="dim cyan",   width=4)
        table.add_column("Name",     style="bold white", width=24)
        table.add_column("Category", style="cyan",       width=12)
        table.add_column("Steps",    style="dim",        width=7)
        table.add_column("Est.",     style="dim",        width=7)
        table.add_column("Description", style="dim")

        for i, wf in enumerate(templates, 1):
            desc = wf.description[:55] + "…" if len(wf.description) > 55 else wf.description
            table.add_row(
                str(i), wf.name, wf.category,
                str(wf.step_count),
                f"{wf.estimated_min}m",
                desc,
            )
        self.console.print(table)
        self.console.print()

        try:
            raw = Prompt.ask(
                "[cyan]# to view details and run / Enter to go back[/]",
                default="",
            ).strip()
        except (KeyboardInterrupt, EOFError):
            return

        if not raw:
            return

        try:
            idx = int(raw) - 1
            if 0 <= idx < len(templates):
                self._run_template(templates[idx].name)
            else:
                self.console.print("[red]Invalid selection.[/]")
                self._pause()
        except ValueError:
            self.console.print("[red]Invalid input.[/]")
            self._pause()

    # ── Custom template ───────────────────────────────────────────────────────

    def _custom_template(self) -> None:
        self.console.clear()
        self.console.print(Rule("[bold cyan]Custom Template[/]", style="cyan"))

        try:
            from reconx.workflow.templates import WorkflowTemplates
        except ModuleNotFoundError:
            from workflow.templates import WorkflowTemplates

        names = WorkflowTemplates.list_names()
        self.console.print(
            "[dim]Available: [/]" +
            "  ".join(f"[cyan]{n}[/]" for n in names) + "\n"
        )

        try:
            name = Prompt.ask("[cyan]Template name[/]", default="").strip()
        except (KeyboardInterrupt, EOFError):
            return

        if name:
            self._run_template(name)

    # ── Execution ─────────────────────────────────────────────────────────────

    def _execute_workflow(self, wf, target: str) -> None:
        """Run a workflow with live step-status display."""
        self.console.clear()
        self.console.print(Rule(
            f"[bold cyan]{wf.name}[/] → [yellow]{target}[/]",
            style="cyan",
        ))

        from rich.progress import (
            BarColumn, Progress, SpinnerColumn,
            TaskProgressColumn, TextColumn, TimeElapsedColumn,
        )

        wf_engine  = self._get_wf_engine()
        recorder   = self._get_recorder()
        checkpoint = self._get_checkpoints()

        step_statuses: dict[str, str] = {}

        def on_start(step, session):
            step_statuses[step.tool_class] = "RUNNING"

        def on_done(step, session):
            step_statuses[step.tool_class] = step.status.value.upper()
            try:
                checkpoint.save(session)
            except Exception:
                pass

        wf_engine.on_step_start = on_start
        wf_engine.on_step_done  = on_done

        total_steps = len(wf.steps)
        started = time.time()

        with Progress(
            SpinnerColumn(style="cyan"),
            TextColumn("[cyan]{task.description}[/]"),
            BarColumn(bar_width=30, style="cyan", complete_style="bright_cyan"),
            TaskProgressColumn(),
            TimeElapsedColumn(),
            transient=False,
            console=self.console,
        ) as progress:
            task = progress.add_task(
                f"[bold]{wf.name}[/]",
                total=total_steps,
            )

            def _step_done_progress(step, session):
                on_done(step, session)
                progress.advance(task)

            wf_engine.on_step_done = _step_done_progress

            session = wf_engine.execute(wf, target)

        elapsed = time.time() - started

        # Save session
        try:
            path = recorder.save(session)
            checkpoint.delete(session.session_id)
        except Exception as exc:
            path = "save failed"
            log.warning(f"Session save error: {exc}")

        # Summary
        self.console.print()
        success = session.success_count
        failed  = session.failed_count
        total   = len(session.steps)

        self.console.print(Panel(
            f"[bold green]Workflow Complete[/]   {elapsed:.1f}s\n\n"
            f"Steps:    [green]{success}[/] success   [red]{failed}[/] failed   {total} total\n"
            f"Findings: [bold cyan]{session.total_findings}[/]\n"
            f"Session:  [dim]{path}[/]",
            title=f"[bold]{wf.name}[/]",
            border_style="green" if not failed else "yellow",
        ))

        if session.failed_steps:
            self.console.print(
                "[red]Failed steps:[/] " +
                "  ".join(f"[dim]{t}[/]" for t in session.failed_steps)
            )

        self._pause()

    # ── Print helpers ─────────────────────────────────────────────────────────

    def _print_header(self) -> None:
        self.console.print(Panel(
            "[bold cyan]ReconX Workflow Center[/]\n"
            "[dim]Automate, record, replay, and orchestrate reconnaissance workflows.[/]",
            border_style="cyan",
            padding=(0, 2),
        ))
        self.console.print()

    def _print_workflow_detail(self, wf) -> None:
        """Show step list for a template before running."""
        self.console.print(Panel(
            f"[bold white]{wf.description}[/]\n\n"
            f"[dim]Steps: {wf.step_count}  ·  "
            f"Est: {wf.estimated_min}m  ·  "
            f"Category: {wf.category}  ·  "
            f"Root: {'yes' if wf.requires_root else 'no'}[/]",
            title=f"[bold cyan]{wf.name}[/]",
            border_style="cyan",
        ))
        self.console.print()

        table = Table(box=box.SIMPLE, show_header=True, border_style="dim")
        table.add_column("#",       style="dim cyan", width=4)
        table.add_column("Tool",    style="bold white")
        table.add_column("Stage",   style="dim", width=7)
        table.add_column("Group",   style="dim green", width=18)
        table.add_column("Condition", style="dim yellow")

        for i, step in enumerate(wf.steps, 1):
            table.add_row(
                str(i),
                step.tool_class,
                f"Stage {step.stage}",
                step.parallel_group or "—",
                step.condition or "—",
            )
        self.console.print(table)
        self.console.print()

    def _print_session_list(self, sessions: list[dict]) -> None:
        table = Table(box=box.SIMPLE_HEAD, border_style="cyan")
        table.add_column("#",        style="dim cyan", width=4)
        table.add_column("Session",  style="dim white", width=28)
        table.add_column("Workflow", style="cyan", width=22)
        table.add_column("Target",   style="green")
        table.add_column("Status",   style="dim")
        table.add_column("Findings", style="bold yellow", width=9)
        table.add_column("Duration", style="dim", width=9)

        for i, s in enumerate(sessions[:15], 1):
            dur = f"{s['duration_s']:.0f}s" if s["duration_s"] > 0 else "—"
            table.add_row(
                str(i),
                s["session_id"][-24:],
                s["workflow_name"][:20],
                s["target"][:22],
                s["status"],
                str(s["total_findings"]),
                dur,
            )
        self.console.print(table)

    def _prompt_target(self) -> Optional[str]:
        self.console.print()
        try:
            target = Prompt.ask("[bold cyan]Target[/]  (domain / IP / CIDR / URL)",
                                console=self.console).strip()
        except (KeyboardInterrupt, EOFError):
            return None
        if not target:
            self.console.print("[red]No target entered.[/]")
            return None
        return target

    def _resolve_session_id(self, raw: str, sessions: list[dict]) -> Optional[str]:
        """Accept either a numeric index or direct session_id string."""
        try:
            idx = int(raw) - 1
            if 0 <= idx < len(sessions):
                return sessions[idx]["session_id"]
        except ValueError:
            pass
        # Direct match
        for s in sessions:
            if s["session_id"] == raw or s["session_id"].endswith(raw):
                return s["session_id"]
        return None

    def _pause(self) -> None:
        try:
            Prompt.ask("\n[dim]Press Enter to continue[/]",
                       default="", console=self.console)
        except (KeyboardInterrupt, EOFError):
            pass

    # ── Lazy init ─────────────────────────────────────────────────────────────

    def _get_wf_engine(self):
        if not self._wf_engine:
            try:
                from reconx.workflow.engine import WorkflowEngine
            except ModuleNotFoundError:
                from workflow.engine import WorkflowEngine
            self._wf_engine = WorkflowEngine(registry=self.registry)
        return self._wf_engine

    def _get_recorder(self):
        if not self._recorder:
            try:
                from reconx.workflow.recorder import WorkflowRecorder
            except ModuleNotFoundError:
                from workflow.recorder import WorkflowRecorder
            self._recorder = WorkflowRecorder()
        return self._recorder

    def _get_replayer(self):
        if not self._replayer:
            try:
                from reconx.workflow.replay import WorkflowReplayer
            except ModuleNotFoundError:
                from workflow.replay import WorkflowReplayer
            self._replayer = WorkflowReplayer(
                engine=self._get_wf_engine(),
                recorder=self._get_recorder(),
                checkpoints=self._get_checkpoints(),
            )
        return self._replayer

    def _get_checkpoints(self):
        if not self._checkpoints:
            try:
                from reconx.workflow.checkpoint import CheckpointManager
            except ModuleNotFoundError:
                from workflow.checkpoint import CheckpointManager
            self._checkpoints = CheckpointManager()
        return self._checkpoints
