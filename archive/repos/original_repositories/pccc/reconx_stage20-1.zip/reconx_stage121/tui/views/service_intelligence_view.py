"""
ReconX — Stage 20: Service Intelligence TUI Panel

Rich-rendered panel showing the Stage 20 service analysis results.

Layout:
  ┌─ Service Intelligence ─────────────────────────────────────────┐
  │  Target: 10.0.0.1  │  Services: 12  │  Critical: 2  │  High: 3 │
  ├─────────────────────────────────────────────────────────────────┤
  │  SERVICES │ RISK SIGNALS │ AI ANALYSIS │ NEXT STEPS             │
  └─────────────────────────────────────────────────────────────────┘
"""
from __future__ import annotations

import logging
from typing import Optional

from rich import box
from rich.columns import Columns
from rich.console import Console
from rich.panel import Panel
from rich.rule import Rule
from rich.table import Table
from rich.text import Text

from .models import ServiceRecord, ServiceIntelligenceReport, ServiceRisk

log = logging.getLogger("reconx.tui.service_intelligence")

# ── Style helpers ─────────────────────────────────────────────────────────────

def _risk_style(risk: str) -> str:
    return {
        "critical": "bold red",
        "high":     "red",
        "medium":   "yellow",
        "low":      "green",
        "info":     "dim",
    }.get(risk.lower(), "white")


def _risk_badge(risk: str) -> Text:
    styles = {
        "critical": ("CRIT", "bold white on red"),
        "high":     ("HIGH", "bold red"),
        "medium":   ("MED",  "yellow"),
        "low":      ("LOW",  "green"),
        "info":     ("INFO", "dim"),
    }
    label, style = styles.get(risk.lower(), (risk.upper(), "white"))
    return Text(f" {label} ", style=style)


def _score_bar(score: float) -> str:
    filled = int(score)
    bar    = "█" * filled + "░" * (10 - filled)
    return f"{bar} {score:.1f}"


class ServiceIntelligencePanel:
    """
    Renders the Stage 20 Service Intelligence panel.

    Usage:
        panel = ServiceIntelligencePanel()
        panel.render(console, report)
    """

    def render(
        self,
        console: Console,
        report:  Optional[ServiceIntelligenceReport] = None,
    ) -> None:
        report = report or ServiceIntelligenceReport(target="—")
        report.compute_counts()

        console.print(Rule("[bold red]Service Intelligence[/bold red]", style="red"))
        console.print()
        self._render_header(console, report)
        console.print()
        self._render_stats_row(console, report)
        console.print()
        self._render_services_table(console, report)
        console.print()
        self._render_risk_panel(console, report)
        console.print()
        self._render_analysis_panel(console, report)
        console.print()
        self._render_next_steps(console, report)
        console.print()

    # ── Header ─────────────────────────────────────────────────────────────────
    def _render_header(self, console: Console, r: ServiceIntelligenceReport):
        t = Text()
        t.append("Target: ", style="dim")
        t.append(r.target or "—", style="bold white")
        if r.executive_summary:
            t.append("\n")
            t.append(r.executive_summary, style="dim")
        console.print(Panel(t, border_style="red", title="[bold red]Service Intelligence[/bold red]",
                            padding=(0, 2)))

    # ── Stats row ───────────────────────────────────────────────────────────────
    def _render_stats_row(self, console: Console, r: ServiceIntelligenceReport):
        def stat(n, label, colour):
            t = Text(justify="center")
            t.append(f"{n}\n", style=f"bold {colour}")
            t.append(label, style="dim")
            return Panel(t, border_style=colour, padding=(0, 2), expand=True)

        console.print(Columns([
            stat(r.total_services,  "Services",  "white"),
            stat(r.critical_count,  "Critical",  "bold red"),
            stat(r.high_count,      "High",      "red"),
            stat(r.medium_count,    "Medium",    "yellow"),
            stat(r.low_count,       "Low",       "green"),
            stat(len(r.database_services), "Databases", "magenta"),
            stat(len(r.cloud_services),    "Cloud APIs", "cyan"),
        ], equal=True))

    # ── Services table ───────────────────────────────────────────────────────────
    def _render_services_table(self, console: Console, r: ServiceIntelligenceReport):
        tbl = Table(title="🔍  Services Detected", border_style="red",
                    box=box.SIMPLE_HEAVY, show_lines=False)
        tbl.add_column("Risk",     width=7,  justify="center")
        tbl.add_column("Host",     style="yellow",    max_width=18)
        tbl.add_column("Port",     style="cyan",      width=7,  justify="right")
        tbl.add_column("Protocol", style="bold white", max_width=16)
        tbl.add_column("Family",   style="blue",      width=12)
        tbl.add_column("Version",  style="dim",       max_width=25)
        tbl.add_column("Score",    style="red",       width=14)
        tbl.add_column("AI Notes", style="dim",       max_width=40)

        sorted_svcs = sorted(
            r.services,
            key=lambda s: {
                ServiceRisk.CRITICAL: 0, ServiceRisk.HIGH: 1,
                ServiceRisk.MEDIUM: 2, ServiceRisk.LOW: 3, ServiceRisk.INFO: 4,
            }.get(s.risk_level, 5)
        )

        for svc in sorted_svcs[:40]:
            family  = svc.classification.family.value if svc.classification else "unknown"
            conf    = f"{svc.classification.confidence * 100:.0f}%" if svc.classification else "—"
            ai_note = ""
            if svc.ai_analysis:
                ai_note = svc.ai_analysis.beginner_summary[:40]
            score_bar = _score_bar(svc.ai_analysis.risk_score if svc.ai_analysis else 0)

            tbl.add_row(
                _risk_badge(svc.risk_level.value),
                svc.host,
                f"{svc.port}/{svc.protocol}",
                svc.protocol_name,
                family,
                (svc.service_version or "—")[:25],
                score_bar,
                ai_note,
            )

        if len(r.services) > 40:
            tbl.add_row("…", "…", "…",
                        f"[dim]+{len(r.services) - 40} more[/dim]",
                        "…", "…", "…", "…")

        console.print(tbl)

    # ── Risk signals panel ───────────────────────────────────────────────────────
    def _render_risk_panel(self, console: Console, r: ServiceIntelligenceReport):
        all_signals = []
        for svc in r.services:
            for sig in svc.risk_signals:
                all_signals.append((svc, sig))

        tbl = Table(title="⚠️  Risk Signals", border_style="yellow",
                    box=box.SIMPLE_HEAVY)
        tbl.add_column("Severity", width=10, justify="center")
        tbl.add_column("Service",  style="cyan", width=14)
        tbl.add_column("Signal",   style="yellow", width=22)
        tbl.add_column("Detail",   style="white",  max_width=55)

        if not all_signals:
            tbl.add_row("—", "—", "—", "[dim green]No risk signals detected[/dim green]")
        else:
            # Sort by severity
            sev_order = {ServiceRisk.CRITICAL: 0, ServiceRisk.HIGH: 1,
                         ServiceRisk.MEDIUM: 2, ServiceRisk.LOW: 3}
            all_signals.sort(key=lambda x: sev_order.get(x[1].severity, 4))
            for svc, sig in all_signals[:20]:
                tbl.add_row(
                    _risk_badge(sig.severity.value),
                    svc.protocol_name[:14],
                    sig.signal_type.replace("_", " ")[:22],
                    sig.description[:55],
                )

        console.print(tbl)

    # ── AI analysis panel ────────────────────────────────────────────────────────
    def _render_analysis_panel(self, console: Console, r: ServiceIntelligenceReport):
        high_risk = [s for s in r.services
                     if s.risk_level in (ServiceRisk.CRITICAL, ServiceRisk.HIGH)
                     and s.ai_analysis][:5]

        if not high_risk:
            return

        console.print(Rule("[dim]AI Analysis Highlights[/dim]", style="dim"))
        for svc in high_risk:
            a = svc.ai_analysis
            console.print(Panel(
                f"[bold]{svc.protocol_name}[/bold] on [cyan]{svc.address}[/cyan]  "
                f"Risk: [{_risk_style(a.risk_level.value)}]{a.risk_score:.1f}/10 "
                f"{a.risk_level.value.upper()}[/{_risk_style(a.risk_level.value)}]\n\n"
                f"[dim]{a.beginner_summary}[/dim]\n\n"
                f"[yellow]Attack vectors:[/yellow]\n"
                + "\n".join(f"  • {v[:80]}" for v in a.attack_vectors[:3]) +
                (f"\n\n[red]Misconfigurations:[/red]\n"
                 + "\n".join(f"  • {m[:80]}" for m in a.misconfig_patterns[:3])
                 if a.misconfig_patterns else ""),
                border_style=_risk_style(a.risk_level.value),
                padding=(0, 2),
            ))

    # ── Next steps ───────────────────────────────────────────────────────────────
    def _render_next_steps(self, console: Console, r: ServiceIntelligenceReport):
        all_steps = []
        for svc in r.services:
            if svc.ai_analysis:
                for step in svc.ai_analysis.enumeration_paths:
                    all_steps.append((svc, step))

        if not all_steps:
            return

        tbl = Table(title="🗺️  Suggested Enumeration Paths",
                    border_style="green", box=box.SIMPLE_HEAVY)
        tbl.add_column("Tool",    style="cyan",  width=12)
        tbl.add_column("Service", style="white", width=14)
        tbl.add_column("Command", style="green", max_width=60)
        tbl.add_column("Purpose", style="dim",   max_width=40)

        # Sort by priority
        all_steps.sort(key=lambda x: x[1].priority)
        for svc, step in all_steps[:15]:
            tbl.add_row(step.tool, svc.protocol_name, step.command[:60], step.purpose[:40])

        console.print(tbl)
        if r.suggested_actions:
            console.print()
            console.print("  [bold yellow]Suggested Actions:[/bold yellow]")
            for action in r.suggested_actions[:5]:
                console.print(f"  [dim]→[/dim] {action}")


def render_service_intelligence(
    console: Console,
    report:  Optional[ServiceIntelligenceReport] = None,
) -> None:
    """Standalone render helper for any TUI view."""
    ServiceIntelligencePanel().render(console, report)
