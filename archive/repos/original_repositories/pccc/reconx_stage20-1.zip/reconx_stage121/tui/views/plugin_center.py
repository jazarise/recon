"""
ReconX — TUI: Plugin Center (Stage 15, Part 8).

Interactive terminal UI for the plugin ecosystem:
  [1] Marketplace Browser  — search/install community packs
  [2] Installed Plugins    — list, enable/disable, remove
  [3] Workflow Packs       — browse and activate workflow packs
  [4] Plugin Health        — per-plugin run stats, errors
  [5] Install from File    — load a local .py plugin
"""
from __future__ import annotations

from pathlib import Path
from typing import Optional

from rich import box
from rich.console import Console, Group
from rich.panel import Panel
from rich.prompt import Confirm, Prompt
from rich.rule import Rule
from rich.table import Table
from rich.text import Text


class PluginCenter:
    """
    Plugin marketplace and management TUI.

    Usage:
        center = PluginCenter(manager=pm, marketplace=mp, console=console)
        center.run()
    """

    def __init__(
        self,
        manager    = None,    # PluginManager
        marketplace= None,    # Marketplace
        loader     = None,    # PluginLoader
        console: Optional[Console] = None,
    ):
        self.manager     = manager
        self.marketplace = marketplace
        self.loader      = loader
        self.console     = console or Console()

    # ── main loop ─────────────────────────────────────────────────────────────

    def run(self) -> None:
        while True:
            self.console.clear()
            self.console.print(self._main_panel())
            self.console.print()

            choice = Prompt.ask(
                "[bold cyan]Plugin Center[/] ›",
                console=self.console,
                default="0",
            ).strip().lower()

            if choice in ("0", "q", "back"):
                break
            elif choice == "1":
                self._marketplace_browser()
            elif choice == "2":
                self._installed_plugins()
            elif choice == "3":
                self._workflow_packs()
            elif choice == "4":
                self._plugin_health()
            elif choice == "5":
                self._install_from_file()

    # ── main panel ────────────────────────────────────────────────────────────

    def _main_panel(self) -> Panel:
        table = Table(box=None, show_header=False, padding=(0, 2), expand=True)
        table.add_column("Key",   style="bold cyan", width=4)
        table.add_column("Label", style="bold white")
        table.add_column("Info",  style="dim")

        # Stats
        installed_count = len(self.manager.all_records()) if self.manager else 0
        mp_count        = len(self.marketplace.all_packs()) if self.marketplace else 0
        active_count    = len(self.manager.active_records()) if self.manager else 0

        items = [
            ("1", "Marketplace Browser",
             f"{mp_count} packs available"),
            ("2", "Installed Plugins",
             f"{installed_count} installed, {active_count} active"),
            ("3", "Workflow Packs",
             "5 built-in workflow templates"),
            ("4", "Plugin Health",
             "Runtime stats and error rates"),
            ("5", "Install from File",
             "Load a local .py plugin directly"),
            ("0", "Back",
             "Return to main menu"),
        ]
        for key, label, info in items:
            table.add_row(f"[{key}]", label, info)

        return Panel(
            table,
            title="[bold cyan]Plugin Center[/]",
            border_style="cyan",
            padding=(1, 2),
        )

    # ── marketplace browser ───────────────────────────────────────────────────

    def _marketplace_browser(self) -> None:
        if not self.marketplace:
            self._no_component("Marketplace")
            return

        while True:
            self.console.clear()
            packs = self.marketplace.all_packs()
            self.console.print(self._pack_list_panel(packs, "All Packs"))
            self.console.print()

            self.console.print(
                "[dim]Enter pack number to view details, "
                "[bold]S[/]=Search, [bold]C[/]=by Category, [bold]0[/]=Back[/]"
            )
            choice = Prompt.ask("›", console=self.console, default="0").strip().lower()

            if choice in ("0", "back"):
                break
            elif choice == "s":
                query = Prompt.ask("[cyan]Search[/]", console=self.console)
                results = self.marketplace.search(query)
                self.console.clear()
                self.console.print(self._pack_list_panel(results, f"Search: {query!r}"))
                choice2 = Prompt.ask("[dim]Pack number or Enter to go back[/]",
                                      default="", console=self.console)
                if choice2.isdigit():
                    idx = int(choice2) - 1
                    if 0 <= idx < len(results):
                        self._pack_detail(results[idx])
            elif choice == "c":
                self._category_browser()
            elif choice.isdigit():
                idx = int(choice) - 1
                if 0 <= idx < len(packs):
                    self._pack_detail(packs[idx])

    def _pack_list_panel(self, packs: list, title: str) -> Panel:
        table = Table(box=box.SIMPLE, show_header=True,
                      header_style="bold dim", padding=(0, 1), expand=True)
        table.add_column("#",      width=4, style="dim")
        table.add_column("Pack",   style="bold white", min_width=24)
        table.add_column("Cat.",   style="cyan",   width=12)
        table.add_column("★",      width=5)
        table.add_column("Status", width=10)
        table.add_column("Description")

        for i, pack in enumerate(packs, 1):
            stars   = f"{pack.rating:.1f}"
            status  = (Text("● Installed", style="green")
                       if pack.installed else Text("○ Available", style="dim"))
            table.add_row(
                str(i), pack.name, pack.category,
                stars, status,
                pack.description[:55] + "…" if len(pack.description) > 55
                else pack.description,
            )

        return Panel(
            table,
            title=f"[bold cyan]Marketplace — {title}[/]",
            border_style="cyan",
            padding=(0, 1),
        )

    def _pack_detail(self, pack) -> None:
        self.console.clear()

        stars = "★" * int(pack.rating) + "☆" * (5 - int(pack.rating))
        info  = Table(box=None, show_header=False, padding=(0, 1))
        info.add_column("Key",   style="dim",       width=16)
        info.add_column("Value", style="bold white")
        info.add_row("Version",    pack.version)
        info.add_row("Author",     pack.author)
        info.add_row("Category",   pack.category)
        info.add_row("Rating",     f"{stars} ({pack.rating}/5)")
        info.add_row("Installs",   str(pack.installs))
        info.add_row("Status",     "Installed" if pack.installed else "Not installed")
        if pack.requires_pip:
            info.add_row("Pip deps", ", ".join(pack.requires_pip))
        if pack.homepage:
            info.add_row("Homepage",  pack.homepage)

        tools_text = ", ".join(pack.tools[:8])
        if len(pack.tools) > 8:
            tools_text += f" … (+{len(pack.tools) - 8})"

        self.console.print(Panel(
            Group(
                info,
                Rule(style="dim cyan"),
                Text(pack.description, style="white"),
                Rule("[dim]Tools included[/]", style="dim"),
                Text(tools_text, style="cyan"),
            ),
            title=f"[bold cyan]{pack.name}[/] v{pack.version}",
            border_style="cyan",
            padding=(1, 2),
        ))

        # Changelog
        if pack.changelog:
            self.console.print(Rule("[dim]Changelog[/]", style="dim"))
            for ver, notes in sorted(pack.changelog.items(), reverse=True):
                self.console.print(f"  [dim]{ver}:[/] {notes}")

        self.console.print()
        if pack.installed:
            action = Prompt.ask(
                "[bold red][U][/]=Uninstall  [bold dim][0][/]=Back",
                choices=["u", "0"], default="0",
                console=self.console,
            ).lower()
            if action == "u":
                ok, msg = self.marketplace.uninstall(pack.id)
                self.console.print(f"[{'green' if ok else 'red'}]{msg}[/]")
                Prompt.ask("[dim]Press Enter[/]", default="")
        else:
            action = Prompt.ask(
                "[bold green][I][/]=Install  [bold dim][0][/]=Back",
                choices=["i", "0"], default="0",
                console=self.console,
            ).lower()
            if action == "i":
                self.console.print("[dim]Installing…[/]")
                ok, msg = self.marketplace.install(pack.id)
                self.console.print(f"[{'green' if ok else 'red'}]{msg}[/]")
                Prompt.ask("[dim]Press Enter[/]", default="")

    def _category_browser(self) -> None:
        from reconx.plugins.marketplace import MARKETPLACE_CATEGORIES
        self.console.print("\n[dim]Categories:[/]")
        for i, cat in enumerate(MARKETPLACE_CATEGORIES, 1):
            self.console.print(f"  [{i}] {cat}")
        choice = Prompt.ask("[dim]Category number[/]", default="1",
                             console=self.console)
        try:
            idx = int(choice) - 1
            cat = MARKETPLACE_CATEGORIES[idx]
            packs = self.marketplace.by_category(cat)
            self.console.clear()
            self.console.print(self._pack_list_panel(packs, cat))
            Prompt.ask("[dim]Press Enter[/]", default="")
        except (ValueError, IndexError):
            pass

    # ── installed plugins ─────────────────────────────────────────────────────

    def _installed_plugins(self) -> None:
        if not self.manager:
            self._no_component("Plugin Manager")
            return

        while True:
            self.console.clear()
            records = self.manager.all_records()
            if not records:
                self.console.print(
                    Panel("[dim]No plugins installed yet.[/]\n\n"
                          "Use [bold]Marketplace[/] or [bold]Install from File[/] to add plugins.",
                          border_style="dim")
                )
                Prompt.ask("[dim]Press Enter[/]", default="")
                break

            table = Table(box=box.ROUNDED, border_style="cyan",
                          show_header=True, header_style="bold dim")
            table.add_column("#",      width=4)
            table.add_column("Plugin", style="bold white", min_width=20)
            table.add_column("Type",   style="cyan",  width=12)
            table.add_column("Ver.",   width=8)
            table.add_column("Status", width=10)
            table.add_column("Runs",   justify="right", width=6)
            table.add_column("Errors", justify="right", width=7)

            for i, rec in enumerate(records, 1):
                status = (Text("● ACTIVE",   style="green")  if rec.enabled   else
                          Text("○ DISABLED", style="yellow") if not rec.load_error else
                          Text("✗ ERROR",    style="red"))
                table.add_row(
                    str(i), rec.name, rec.plugin_type, rec.version,
                    status, str(rec.run_count), str(rec.error_count),
                )

            self.console.print(Panel(table, title="[bold cyan]Installed Plugins[/]",
                                      border_style="cyan"))
            self.console.print()
            self.console.print(
                "[dim]Enter number to manage, or [bold]0[/] to go back[/]"
            )
            choice = Prompt.ask("›", default="0", console=self.console).strip()
            if choice in ("0", "back"):
                break
            try:
                idx = int(choice) - 1
                if 0 <= idx < len(records):
                    self._manage_plugin(records[idx])
            except ValueError:
                pass

    def _manage_plugin(self, rec) -> None:
        self.console.clear()
        self.console.print(Panel(
            f"[bold white]{rec.name}[/] v{rec.version}  [{rec.status}]\n"
            f"[dim]{rec.description}[/]\n\n"
            f"Type: {rec.plugin_type}  |  Author: {rec.author}\n"
            f"Runs: {rec.run_count}  |  Errors: {rec.error_count}\n"
            + (f"[red]Error: {rec.load_error}[/]" if rec.load_error else ""),
            title=f"[bold cyan]{rec.name}[/]",
            border_style="cyan",
            padding=(1, 2),
        ))
        opts = []
        if rec.enabled:
            opts.append("[bold yellow][D][/]=Disable")
        else:
            opts.append("[bold green][E][/]=Enable")
        opts.append("[bold red][R][/]=Remove  [bold dim][0][/]=Back")
        action = Prompt.ask("  ".join(opts), default="0",
                             console=self.console).lower()
        if action == "d" and self.manager:
            self.manager.disable(rec.name)
            self.console.print(f"[yellow]Disabled {rec.name}[/]")
        elif action == "e" and self.manager:
            self.manager.enable(rec.name)
            self.console.print(f"[green]Enabled {rec.name}[/]")
        elif action == "r" and self.manager:
            if Confirm.ask(f"[red]Remove {rec.name}?[/]", default=False,
                           console=self.console):
                self.manager.remove(rec.name)
                self.console.print(f"[red]Removed {rec.name}[/]")
        Prompt.ask("[dim]Press Enter[/]", default="")

    # ── workflow packs ────────────────────────────────────────────────────────

    def _workflow_packs(self) -> None:
        from reconx.plugins.schemas import BUILTIN_WORKFLOW_PACKS
        self.console.clear()
        self.console.print("[bold cyan]Built-in Workflow Packs[/]\n")
        for i, pack in enumerate(BUILTIN_WORKFLOW_PACKS, 1):
            n_steps = len(pack.get("steps", []))
            targets = ", ".join(pack.get("target_types", ["any"]))
            self.console.print(
                f"  [cyan][{i}][/] [bold white]{pack['name']}[/]  "
                f"[dim]{pack['version']}[/]  "
                f"[dim]{n_steps} steps  targets: {targets}[/]"
            )
            self.console.print(f"      [dim]{pack['description']}[/]")
            self.console.print()

        self.console.print("[dim]Enter number to view steps, or 0 to go back[/]")
        choice = Prompt.ask("›", default="0", console=self.console).strip()
        if choice.isdigit() and int(choice) > 0:
            idx = int(choice) - 1
            if 0 <= idx < len(BUILTIN_WORKFLOW_PACKS):
                self._show_workflow_pack(BUILTIN_WORKFLOW_PACKS[idx])

    def _show_workflow_pack(self, pack: dict) -> None:
        self.console.clear()
        steps = pack.get("steps", [])
        table = Table(box=box.SIMPLE, show_header=True, header_style="bold dim")
        table.add_column("#",     width=4, style="dim")
        table.add_column("Tool",  style="bold white", min_width=22)
        table.add_column("Desc",  style="dim")
        table.add_column("Opt?",  width=6)
        for i, step in enumerate(steps, 1):
            table.add_row(
                str(i),
                step.get("tool", "—"),
                step.get("description", ""),
                "yes" if step.get("optional") else "",
            )
        self.console.print(Panel(
            table,
            title=f"[bold cyan]{pack['name']}[/]  [dim]{pack['description']}[/]",
            border_style="cyan",
        ))
        Prompt.ask("[dim]Press Enter[/]", default="")

    # ── plugin health ─────────────────────────────────────────────────────────

    def _plugin_health(self) -> None:
        if not self.manager:
            self._no_component("Plugin Manager")
            return
        self.console.clear()
        self.console.print(self.manager.health_report())
        self.console.print()
        Prompt.ask("[dim]Press Enter[/]", default="")

    # ── install from file ─────────────────────────────────────────────────────

    def _install_from_file(self) -> None:
        self.console.clear()
        self.console.print(Panel(
            "[bold]Install Plugin from File[/]\n\n"
            "[dim]Enter the path to a .py file containing a BaseReconPlugin subclass.\n"
            "The plugin will be copied to plugins/community/ and registered.[/]",
            border_style="cyan",
        ))
        path = Prompt.ask("[bold cyan]File path[/]", console=self.console).strip()
        if not path:
            return
        if not self.manager:
            self._no_component("Plugin Manager")
            return
        rec = self.manager.install_from_file(path)
        if rec:
            self.console.print(
                f"\n[green]✓ Installed:[/] [bold]{rec.name}[/] v{rec.version} "
                f"({rec.plugin_type})"
            )
        else:
            self.console.print("[red]✗ Installation failed — check the file path and plugin format.[/]")
        Prompt.ask("[dim]Press Enter[/]", default="")

    # ── helpers ───────────────────────────────────────────────────────────────

    def _no_component(self, name: str) -> None:
        self.console.print(f"[yellow]⚠ {name} not configured.[/]")
        Prompt.ask("[dim]Press Enter[/]", default="")
