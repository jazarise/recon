"""
ReconX — Stage 17: Infrastructure Intelligence TUI View.

Rich terminal display for correlated infrastructure data.

Panels:
  • Asset Tree View        — hierarchical host → IP → service → tech tree
  • Service Intelligence   — tagged service panels with risk indicators
  • Relationship Map       — shared infra, TLS clusters, subdomain groups
  • Live Counters          — hosts / subdomains / ports / techs / relationships
  • Learning Context       — inline service education (expandable)

Usage:
    from reconx.tui.views.infrastructure_view import InfrastructureView

    view = InfrastructureView(console=console)
    view.display(correlation_report, relationship_map, tagged_result)
"""
from __future__ import annotations

import logging
from typing import Optional

from rich import box
from rich.columns import Columns
from rich.console import Console, Group
from rich.panel import Panel
from rich.prompt import IntPrompt, Prompt
from rich.rule import Rule
from rich.table import Table
from rich.text import Text
from rich.tree import Tree

log = logging.getLogger("reconx.tui.infrastructure_view")


class InfrastructureView:
    """
    Rich TUI for infrastructure correlation intelligence.

    Accepts output from:
      ServiceCorrelator.correlate()   → CorrelationReport
      RelationshipMapper.map()        → RelationshipMap
      TagEngine.tag()                 → TaggedResult
    """

    def __init__(self, console: Optional[Console] = None):
        self.console = console or Console()

    # ── Main entry point ──────────────────────────────────────────────────────

    def display(
        self,
        correlation = None,   # CorrelationReport
        relationships = None,  # RelationshipMap
        tagged = None,         # TaggedResult
        result = None,         # ReconResult (for learning context)
    ) -> None:
        """
        Display the full infrastructure intelligence dashboard.
        Shows all panels then offers an interactive prompt.
        """
        self.console.clear()
        self._print_header(correlation)
        self._print_live_counters(correlation, relationships, tagged, result)

        if correlation and correlation.nodes:
            self._print_asset_tree(correlation)

        if tagged:
            self._print_service_panels(tagged)

        if relationships:
            self._print_relationship_map(relationships)

        if correlation and correlation.cdn_detected:
            self._print_cdn_notice(correlation.cdn_detected)

        self._print_warnings(correlation, relationships, tagged)
        self._interactive_loop(result)

    # ── Live counters ─────────────────────────────────────────────────────────

    def _print_live_counters(self, corr, rels, tagged, result) -> None:
        stats: list[tuple[str, str, str]] = []

        if result:
            stats.extend([
                ("🌐", "Subdomains",    str(len(getattr(result, "subdomains", [])))),
                ("🖥️",  "IPs",           str(len(getattr(result, "ip_addresses", [])))),
                ("🔌", "Open Ports",    str(sum(1 for p in getattr(result, "ports", [])
                                                if p.state == "open"))),
                ("⚙️",  "Technologies",  str(len(getattr(result, "technologies", [])))),
            ])
        if corr:
            stats.append(("🔗", "Correlations",  str(corr.edge_count())))
        if rels:
            stats.append(("🗂️",  "Rel. Groups",   str(rels.total_groups)))
        if tagged:
            crit = len(tagged.critical_assets())
            stats.append(("⚠️",  "Critical Tags",
                           f"[bold red]{crit}[/]" if crit else "0"))

        if not stats:
            return

        columns_data = []
        for icon, label, value in stats:
            columns_data.append(Panel(
                f"[bold white]{value}[/]\n[dim]{icon} {label}[/]",
                border_style="cyan",
                padding=(0, 2),
            ))

        self.console.print(Columns(columns_data, equal=True, expand=True))
        self.console.print()

    # ── Asset Tree ────────────────────────────────────────────────────────────

    def _print_asset_tree(self, corr) -> None:
        self.console.print(Rule("[bold cyan]Infrastructure Asset Tree[/]", style="cyan"))
        self.console.print()

        if not corr.nodes:
            self.console.print("[dim]  No correlated assets.[/]\n")
            return

        # Find root node (first host/target node)
        root_node = corr.nodes[0]
        tree = Tree(
            f"[bold cyan]{root_node.label}[/]  "
            + ("  ".join(f"[{t}]" for t in root_node.tags) if root_node.tags else ""),
            guide_style="dim cyan",
        )

        for child in root_node.children:
            child_label = self._format_node_label(child)
            child_branch = tree.add(child_label)
            for grandchild in child.children:
                gc_label = self._format_node_label(grandchild)
                gc_branch = child_branch.add(gc_label)
                for great in grandchild.children:
                    gc_branch.add(self._format_node_label(great))

        self.console.print(tree)
        self.console.print()

        # ASN nodes
        asn_nodes = [n for n in corr.nodes if n.node_type == "asn"]
        if asn_nodes:
            self.console.print("[dim]ASN Infrastructure:[/]")
            for asn in asn_nodes:
                self.console.print(f"  [cyan]{asn.label}[/]  "
                                   f"[dim]{asn.metadata.get('org', '')}[/]")
                for ip_child in asn.children[:6]:
                    self.console.print(f"    └─ [dim]{ip_child.label}[/]")
                if len(asn.children) > 6:
                    self.console.print(f"    └─ [dim]… {len(asn.children)-6} more[/]")
            self.console.print()

    def _format_node_label(self, node) -> str:
        """Rich-formatted label for a tree node."""
        style_map = {
            "ip":         "yellow",
            "service":    "white",
            "technology": "green",
            "cdn":        "cyan",
            "asn":        "magenta",
        }
        style = style_map.get(node.node_type, "white")

        label = f"[{style}]{node.label}[/]"

        if node.tags:
            # Colour critical tags
            tag_parts = []
            for tag in node.tags:
                from ..analysis.tag_engine import TAG_STYLES
                ts = TAG_STYLES.get(tag, "dim")
                tag_parts.append(f"[{ts}][{tag}][/]")
            label += "  " + " ".join(tag_parts)

        if node.risk_hint:
            risk_style = {
                "CRITICAL": "bold red",
                "HIGH":     "bold orange3",
                "MEDIUM":   "bold yellow",
            }.get(node.risk_hint, "dim")
            label += f"  [{risk_style}]⚠ {node.risk_hint}[/]"

        return label

    # ── Service Panels ────────────────────────────────────────────────────────

    def _print_service_panels(self, tagged) -> None:
        self.console.print(Rule("[bold cyan]Service Intelligence[/]", style="cyan"))
        self.console.print()

        # Group assets by highest-risk tag
        priority_order = [
            "CRITICAL", "EXPOSED", "ADMIN", "DATABASE", "RDP",
            "SMB", "DEVTOOLS", "LOGIN", "API", "VPN", "MAIL",
            "SSH", "FTP", "CDN", "K8S", "TLS-WEAK", "LEGACY",
        ]

        # Build tag → assets index
        tag_assets: dict[str, list] = {}
        for asset in tagged.tagged_assets:
            for tag in asset.tags:
                if tag in priority_order:
                    tag_assets.setdefault(tag, []).append(asset)

        if not tag_assets:
            self.console.print("[dim]  No tagged services found.[/]\n")
            return

        # Display grouped panels
        for tag in priority_order:
            assets = tag_assets.get(tag)
            if not assets:
                continue

            from ..analysis.tag_engine import TAG_STYLES, TAG_DESCRIPTIONS, tag_style
            border = _tag_border_style(tag)
            desc   = TAG_DESCRIPTIONS.get(tag, "")

            rows = []
            for asset in assets[:8]:
                ver = asset.metadata.get("version", "")
                rows.append(
                    f"  [bold white]{asset.label}[/]"
                    + (f"  [dim]{ver}[/]" if ver else "")
                )

            more = f"  [dim]… {len(assets)-8} more[/]" if len(assets) > 8 else ""

            content = "\n".join(rows) + (f"\n{more}" if more else "")
            if desc:
                content = f"[dim italic]{desc}[/]\n\n" + content

            self.console.print(Panel(
                content,
                title=f"[{tag_style(tag)}][{tag}][/]  {len(assets)} asset(s)",
                border_style=border,
                padding=(0, 1),
            ))

        self.console.print()

    # ── Relationship Map ──────────────────────────────────────────────────────

    def _print_relationship_map(self, rels) -> None:
        if rels.total_groups == 0:
            return

        self.console.print(Rule("[bold cyan]Asset Relationships[/]", style="cyan"))
        self.console.print()

        group_sections = [
            ("Shared IP Ownership",    rels.shared_ip_groups,    "yellow"),
            ("TLS Certificate Match",  rels.tls_match_groups,    "cyan"),
            ("Shared Server Banner",   rels.banner_match_groups,  "white"),
            ("Technology Overlap",     rels.tech_overlap_groups,  "green"),
            ("Subdomain Clusters",     rels.subdomain_clusters,   "magenta"),
        ]

        for section_title, groups, colour in group_sections:
            if not groups:
                continue
            self.console.print(f"[bold {colour}]{section_title}[/]")

            for grp in groups[:5]:
                conf_pct = f"{grp.confidence:.0%}"
                members  = ", ".join(grp.members[:4])
                more     = f" +{len(grp.members)-4}" if len(grp.members) > 4 else ""
                evidence = "  ".join(grp.evidence[:2])

                self.console.print(
                    f"  [dim]{conf_pct}[/]  [white]{grp.relationship}[/]"
                )
                self.console.print(
                    f"  [dim]Members:[/] [{colour}]{members}{more}[/]"
                )
                if evidence:
                    self.console.print(f"  [dim]Evidence: {evidence}[/]")
                self.console.print()

            if len(groups) > 5:
                self.console.print(
                    f"  [dim]… {len(groups)-5} more {section_title.lower()} groups[/]\n"
                )

    # ── CDN Notice ────────────────────────────────────────────────────────────

    def _print_cdn_notice(self, cdn_list: list[str]) -> None:
        cdn_str = ", ".join(cdn_list)
        self.console.print(Panel(
            f"[bold white]CDN / WAF Detected:[/] [cyan]{cdn_str}[/]\n\n"
            "[dim]Real origin IP may differ from DNS resolution.\n"
            "Direct scanning bypasses WAF — use passive techniques first.[/]",
            title="[bold cyan][CDN][/] Infrastructure Notice",
            border_style="cyan",
            padding=(0, 2),
        ))
        self.console.print()

    # ── Warnings ──────────────────────────────────────────────────────────────

    def _print_warnings(self, *components) -> None:
        warnings: list[str] = []
        for c in components:
            if c and hasattr(c, "warnings"):
                warnings.extend(c.warnings)
        if warnings:
            self.console.print(
                "[bold yellow]⚠  Correlation Warnings:[/]"
            )
            for w in warnings:
                self.console.print(f"  [yellow]! {w}[/]")
            self.console.print()

    # ── Interactive loop ──────────────────────────────────────────────────────

    def _interactive_loop(self, result) -> None:
        """Offer inline service learning for discovered services."""
        self.console.print(Panel(
            "[cyan][1][/] Learn about a service   "
            "[cyan][2][/] Show full tag list   "
            "[cyan][Enter][/] Back",
            border_style="dim",
            padding=(0, 1),
        ))

        try:
            choice = Prompt.ask("[cyan]Action[/]", default="").strip()
        except (KeyboardInterrupt, EOFError):
            return

        if choice == "1" and result:
            self._show_service_learning(result)
        elif choice == "2":
            self._show_tag_list()

    def _show_service_learning(self, result) -> None:
        """Inline learning for a port / service the operator selects."""
        try:
            from ..analysis.service_learning import ServiceLearning
        except ImportError:
            from reconx.analysis.service_learning import ServiceLearning

        sl   = ServiceLearning()
        open_ports = [p for p in getattr(result, "ports", []) if p.state == "open"]

        if not open_ports:
            self.console.print("[dim]No open ports to learn about.[/]")
            self._pause()
            return

        # Show port menu
        table = Table(box=box.SIMPLE, show_header=False, border_style="dim")
        for i, p in enumerate(open_ports[:15], 1):
            ctx = sl.get_context(port=p.number)
            risk = f"  [{ctx.risk_level}]" if ctx else ""
            table.add_row(
                f"[cyan]{i}[/]",
                f":{p.number}",
                p.service or "?",
                f"[dim]{risk}[/]",
            )
        self.console.print(table)

        try:
            choice = IntPrompt.ask("[cyan]Port #[/]", default=1)
            if 1 <= choice <= len(open_ports):
                port = open_ports[choice - 1]
                ctx  = sl.get_context(port=port.number, service=port.service)
                if ctx:
                    self.console.print(Panel(
                        ctx.render(),
                        title=f"[bold cyan]{ctx.service_name}[/]",
                        border_style="yellow",
                        padding=(1, 2),
                    ))
                else:
                    self.console.print(
                        f"[dim]No learning context available for port {port.number}.[/]"
                    )
        except (ValueError, KeyboardInterrupt, EOFError):
            pass

        self._pause()

    def _show_tag_list(self) -> None:
        try:
            from ..analysis.tag_engine import TAG_DESCRIPTIONS, TAG_STYLES
        except ImportError:
            from reconx.analysis.tag_engine import TAG_DESCRIPTIONS, TAG_STYLES

        table = Table(
            title="Infrastructure Tag Reference",
            box=box.SIMPLE_HEAD,
            border_style="cyan",
        )
        table.add_column("Tag",         style="bold white", width=14, no_wrap=True)
        table.add_column("Description", style="dim")

        for tag, desc in TAG_DESCRIPTIONS.items():
            style = TAG_STYLES.get(tag, "white")
            table.add_row(f"[{style}][{tag}][/]", desc)

        self.console.print(table)
        self._pause()

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _print_header(self, corr) -> None:
        target = corr.target if corr else "unknown"
        self.console.print()
        self.console.print(Panel(
            f"[bold cyan]Infrastructure Intelligence[/]  →  "
            f"[bold white]{target}[/]\n"
            "[dim]Correlated asset view — service topology, relationships, and risk tagging.[/]",
            border_style="cyan",
            padding=(0, 2),
        ))
        self.console.print()

    def _pause(self) -> None:
        try:
            Prompt.ask("\n[dim]Press Enter to continue[/]", default="",
                       console=self.console)
        except (KeyboardInterrupt, EOFError):
            pass


def _tag_border_style(tag: str) -> str:
    """Return a Rich border colour string for a given tag."""
    return {
        "CRITICAL": "red",
        "EXPOSED":  "red",
        "ADMIN":    "red",
        "DATABASE": "red",
        "RDP":      "red",
        "SMB":      "red",
        "DEVTOOLS": "yellow",
        "LOGIN":    "yellow",
        "TLS-WEAK": "yellow",
        "LEGACY":   "yellow",
        "API":      "blue",
        "VPN":      "magenta",
        "CDN":      "cyan",
        "MAIL":     "white",
        "SSH":      "green",
        "K8S":      "blue",
    }.get(tag, "dim")
