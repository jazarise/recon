"""
ReconX — TUI: Home Dashboard (Stage 14, Part 1).

Main entry screen for the ReconX Cyber Intelligence OS.
Rendered with Rich Live — no Textual dependency required.

Layout:
  ┌── Banner ─────────────────────────────────────────────────────────┐
  │  RECONX  ·  Cyber Intelligence OS                                 │
  ├── Menu ──────────────────┬── System Status ───────────────────────┤
  │  [1] Execute Recon       │  Installed Tools : 42                  │
  │  [2] Learning Mode       │  Available       : 31                  │
  │  [3] Guided Recon        │  Missing         : 11                  │
  │  [4] Workflow Center     │  Last Scan       : 14 min ago          │
  │  [5] Tool Explorer       │  CPU             : 12%                 │
  │  [6] Reports             │  RAM             : 1.4 GB              │
  │  [7] Telemetry           ├───────────────────────────────────────┤
  │  [8] Settings            │  Recent Scans                         │
  │  [Q] Quit                │  example.com      balanced  14min ago │
  └──────────────────────────┴───────────────────────────────────────┘
"""
from __future__ import annotations

import platform
import time
from pathlib import Path
from typing import Callable, Optional

from rich import box
from rich.align import Align
from rich.columns import Columns
from rich.console import Console, Group
from rich.live import Live
from rich.panel import Panel
from rich.prompt import Prompt
from rich.rule import Rule
from rich.table import Table
from rich.text import Text


# ── Menu items ─────────────────────────────────────────────────────────────

MENU_ITEMS = [
    ("1", "Execute Recon",    "cyan",    "Run full recon pipeline against a target"),
    ("2", "Learning Mode",    "green",   "Teach tool concepts interactively"),
    ("3", "Guided Recon",     "blue",    "Step-by-step guided reconnaissance"),
    ("4", "Workflow Center",  "magenta", "Build, save, and replay workflows"),
    ("5", "Tool Explorer",    "yellow",  "Browse, search, and configure tools"),
    ("6", "Reports",          "white",   "View and export previous scan reports"),
    ("7", "Telemetry",        "dim",     "Tool health, runtime stats, failure rates"),
    ("8", "Settings",         "dim",     "Configure ReconX preferences"),
    ("Q", "Quit",             "dim red", "Exit ReconX"),
]

QUICK_ACTIONS = [
    ("QS", "Quick Scan",    "WHOIS → DNS → Subs → HTTPX → Report"),
    ("DS", "Deep Scan",     "Full asset discovery pipeline"),
    ("WS", "Web Scan",      "HTTP → Crawl → Content → Visual"),
    ("PS", "Passive Only",  "OSINT + archives — zero active traffic"),
    ("CS", "Cloud Scan",    "ASN → S3 → Certs → Cloud assets"),
]


# ─────────────────────────────────────────────────────────────────────────────
# System metrics collector (stdlib only)
# ─────────────────────────────────────────────────────────────────────────────

def _get_cpu_pct() -> str:
    try:
        import subprocess, re
        out = subprocess.run(
            ["top", "-bn1"], capture_output=True, text=True, timeout=3
        ).stdout
        m = re.search(r"(\d+\.\d+)\s*(?:us|id)", out)
        if m:
            return f"{float(m.group(1)):.0f}%"
    except Exception:
        pass
    return "—"


def _get_ram_gb() -> str:
    try:
        mem = Path("/proc/meminfo").read_text()
        total = int(next(l for l in mem.splitlines() if "MemTotal" in l).split()[1])
        avail = int(next(l for l in mem.splitlines() if "MemAvailable" in l).split()[1])
        used  = (total - avail) / 1024 / 1024
        return f"{used:.1f} GB"
    except Exception:
        pass
    return "—"


def _get_health_counts(registry=None) -> tuple[int, int, int]:
    """Return (total, available, missing) tool counts."""
    if registry is None:
        try:
            from reconx.orchestration.tool_registry import ToolRegistry
        except ModuleNotFoundError:
            try:
                from orchestration.tool_registry import ToolRegistry
            except Exception:
                return 0, 0, 0
        registry = ToolRegistry.build()
    all_tools = registry.all()
    avail = sum(1 for t in all_tools if t.is_available)
    return len(all_tools), avail, len(all_tools) - avail


def _load_recent_scans(limit: int = 5) -> list[dict]:
    """Load recent scan metadata from reports/ directory."""
    reports = []
    report_dir = Path("reports")
    if report_dir.is_dir():
        for f in sorted(report_dir.glob("reconx_*.html"), reverse=True)[:limit]:
            parts = f.stem.split("_")
            target = "_".join(parts[1:-2]).replace("_", ".")
            ts_str = "_".join(parts[-2:])
            try:
                import datetime
                dt = datetime.datetime.strptime(ts_str, "%Y%m%d_%H%M%S")
                age = datetime.datetime.now() - dt
                age_str = (f"{age.seconds // 60}min ago"
                           if age.total_seconds() < 3600 else
                           f"{age.days}d ago" if age.days else
                           f"{age.seconds // 3600}hr ago")
            except Exception:
                age_str = "—"
            reports.append({"target": target, "age": age_str, "path": str(f)})
    return reports


# ─────────────────────────────────────────────────────────────────────────────
# Dashboard renderer
# ─────────────────────────────────────────────────────────────────────────────

class Dashboard:
    """
    Static-render home dashboard. Call render() to get a Rich renderable,
    or run() to display it interactively and return the user's choice.
    """

    BANNER = r"""
[bold cyan]██████╗ ███████╗ ██████╗ ██████╗ ███╗   ██╗██╗  ██╗[/]
[cyan]██╔══██╗██╔════╝██╔════╝██╔═══██╗████╗  ██║╚██╗██╔╝[/]
[bold cyan]██████╔╝█████╗  ██║     ██║   ██║██╔██╗ ██║ ╚███╔╝ [/]
[dim cyan]██╔══██╗██╔══╝  ██║     ██║   ██║██║╚██╗██║ ██╔██╗ [/]
[dim cyan]██║  ██║███████╗╚██████╗╚██████╔╝██║ ╚████║██╔╝ ██╗[/]
[dim cyan]╚═╝  ╚═╝╚══════╝ ╚═════╝ ╚═════╝ ╚═╝  ╚═══╝╚═╝  ╚═╝[/]
"""

    def __init__(
        self,
        console:  Optional[Console] = None,
        registry = None,
    ):
        self.console  = console or Console()
        self.registry = registry
        self._cached_counts: Optional[tuple] = None
        self._last_cache_t  = 0.0

    # ── public ────────────────────────────────────────────────────────────────

    def render(self) -> Group:
        total, avail, missing = self._tool_counts()
        recents = _load_recent_scans()
        return Group(
            self._banner_panel(),
            Columns(
                [self._menu_panel(), self._status_panel(total, avail, missing, recents)],
                equal=False, expand=True,
            ),
            self._quick_actions_panel(),
        )

    def run(self) -> str:
        """
        Display dashboard and return the user's choice string (e.g. "1", "q").
        Uses a one-shot Rich render + Prompt.ask (no Live loop needed for static menu).
        """
        self.console.clear()
        self.console.print(self.render())
        self.console.print()

        valid = {k.lower() for k, *_ in MENU_ITEMS} | {k.upper() for k, *_ in MENU_ITEMS}
        valid |= {k.lower() for k, *_ in QUICK_ACTIONS}

        choice = Prompt.ask(
            "[bold cyan]ReconX[/] ›",
            console=self.console,
            default="",
        ).strip().lower()
        return choice

    # ── panels ────────────────────────────────────────────────────────────────

    def _banner_panel(self) -> Panel:
        subtitle = Text("Cyber Intelligence OS  ·  v14.0  ·  Kali-native", style="dim cyan")
        content  = Group(
            Align.center(Text.from_markup(self.BANNER)),
            Align.center(subtitle),
        )
        return Panel(content, border_style="cyan", padding=(0, 2))

    def _menu_panel(self) -> Panel:
        table = Table(box=None, show_header=False, padding=(0, 1), expand=True)
        table.add_column("Key",   style="bold cyan",  width=4)
        table.add_column("Label", style="bold white")
        table.add_column("Desc",  style="dim")

        for key, label, colour, desc in MENU_ITEMS:
            table.add_row(
                f"[{colour}][{key}][/{colour}]",
                f"[{colour}]{label}[/{colour}]",
                desc,
            )

        return Panel(
            table,
            title="[bold cyan]Main Menu[/]",
            border_style="cyan",
            padding=(1, 2),
        )

    def _status_panel(
        self, total: int, avail: int, missing: int, recents: list
    ) -> Panel:
        status_table = Table(box=None, show_header=False, padding=(0, 1), expand=True)
        status_table.add_column("Key",   style="dim", width=20)
        status_table.add_column("Value", style="bold white")

        status_table.add_row("Registered Tools", f"[cyan]{total}[/]")
        status_table.add_row("Available",         f"[green]{avail}[/]")
        status_table.add_row("Missing",           f"[yellow]{missing}[/]")
        status_table.add_row("Platform",          platform.system())
        status_table.add_row("RAM Used",          _get_ram_gb())

        content_rows: list = [status_table]

        if recents:
            content_rows.append(Rule("[dim]Recent Scans[/]", style="dim cyan"))
            scan_table = Table(box=None, show_header=False, padding=(0, 1))
            scan_table.add_column("Target", style="cyan",  max_width=22)
            scan_table.add_column("Age",    style="dim",   width=10)
            for r in recents[:4]:
                scan_table.add_row(r["target"], r["age"])
            content_rows.append(scan_table)

        return Panel(
            Group(*content_rows),
            title="[bold cyan]System Status[/]",
            border_style="dim cyan",
            padding=(1, 2),
        )

    def _quick_actions_panel(self) -> Panel:
        table = Table(box=None, show_header=False, padding=(0, 2), expand=True)
        for key, label, desc in QUICK_ACTIONS:
            table.add_row(
                f"[bold cyan][{key}][/]",
                f"[white]{label}[/]",
                f"[dim]{desc}[/]",
            )
        return Panel(
            table,
            title="[bold cyan]Quick Actions[/]",
            border_style="dim cyan",
            padding=(0, 1),
            height=len(QUICK_ACTIONS) + 2,
        )

    # ── internal ──────────────────────────────────────────────────────────────

    def _tool_counts(self) -> tuple[int, int, int]:
        now = time.time()
        if self._cached_counts and now - self._last_cache_t < 60:
            return self._cached_counts
        counts = _get_health_counts(self.registry)
        self._cached_counts = counts
        self._last_cache_t  = now
        return counts
