"""
ReconX — TUI: Navigator + Visual Theme System (Stage 14, Part 7).

Manages screen routing and visual enhancement:
  • Route between dashboard, browser, learning, guided, execution views
  • Theme system: dark (default), light, compact, neon
  • Animated spinners and status indicators
  • ASCII banner variants
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from rich.console import Console
from rich.style import Style
from rich.theme import Theme


# ─────────────────────────────────────────────────────────────────────────────
# Theme definitions
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class ReconXTheme:
    name:        str
    accent:      str   # primary highlight colour
    accent2:     str   # secondary
    danger:      str   # errors/critical
    warn:        str   # warnings/missing
    success:     str   # ok/found
    dim_colour:  str   # de-emphasised text
    border:      str   # panel borders
    bg_style:    str   # background hint (Rich doesn't control terminal BG but used for panels)

    def to_rich_theme(self) -> Theme:
        return Theme({
            "reconx.accent":   self.accent,
            "reconx.accent2":  self.accent2,
            "reconx.danger":   self.danger,
            "reconx.warn":     self.warn,
            "reconx.success":  self.success,
            "reconx.dim":      self.dim_colour,
            "reconx.border":   self.border,
            "status.running":  f"bold {self.accent}",
            "status.success":  f"bold {self.success}",
            "status.failed":   f"bold {self.danger}",
            "status.missing":  f"bold {self.warn}",
            "status.skipped":  self.dim_colour,
            "status.retrying": "bold orange3",
        })


THEMES: dict[str, ReconXTheme] = {
    "dark": ReconXTheme(
        name        = "Dark (default)",
        accent      = "cyan",
        accent2     = "bright_cyan",
        danger      = "red",
        warn        = "yellow",
        success     = "green",
        dim_colour  = "dim",
        border      = "cyan",
        bg_style    = "",
    ),
    "neon": ReconXTheme(
        name        = "Neon",
        accent      = "bright_magenta",
        accent2     = "bright_cyan",
        danger      = "bright_red",
        warn        = "bright_yellow",
        success     = "bright_green",
        dim_colour  = "dim white",
        border      = "bright_magenta",
        bg_style    = "",
    ),
    "green": ReconXTheme(
        name        = "Matrix Green",
        accent      = "green",
        accent2     = "bright_green",
        danger      = "red",
        warn        = "yellow",
        success     = "bright_green",
        dim_colour  = "dim green",
        border      = "green",
        bg_style    = "",
    ),
    "light": ReconXTheme(
        name        = "Light",
        accent      = "blue",
        accent2     = "cyan",
        danger      = "red",
        warn        = "dark_orange",
        success     = "dark_green",
        dim_colour  = "grey50",
        border      = "blue",
        bg_style    = "",
    ),
    "compact": ReconXTheme(
        name        = "Compact (minimal colour)",
        accent      = "white",
        accent2     = "bright_white",
        danger      = "red",
        warn        = "yellow",
        success     = "green",
        dim_colour  = "dim",
        border      = "white",
        bg_style    = "",
    ),
}


# ─────────────────────────────────────────────────────────────────────────────
# Status icon helpers
# ─────────────────────────────────────────────────────────────────────────────

STATUS_ICONS: dict[str, tuple[str, str]] = {
    "RUNNING":   ("▶ [RUNNING]",   "status.running"),
    "SUCCESS":   ("✓ [SUCCESS]",   "status.success"),
    "FAILED":    ("✗ [FAILED]",    "status.failed"),
    "MISSING":   ("○ [MISSING]",   "status.missing"),
    "SKIPPED":   ("– [SKIPPED]",   "status.skipped"),
    "RETRYING":  ("↺ [RETRYING]",  "status.retrying"),
    "PENDING":   ("· [PENDING]",   "dim"),
    "CANCELLED": ("✕ [CANCEL]",    "dim red"),
    "OK":        ("● OK",          "status.success"),
    "DEP_ERROR": ("⚠ DEP_ERR",     "status.failed"),
    "DEGRADED":  ("⬇ DEGRADED",    "status.retrying"),
}

ASCII_BANNERS: dict[str, str] = {
    "full": r"""
██████╗ ███████╗ ██████╗ ██████╗ ███╗   ██╗██╗  ██╗
██╔══██╗██╔════╝██╔════╝██╔═══██╗████╗  ██║╚██╗██╔╝
██████╔╝█████╗  ██║     ██║   ██║██╔██╗ ██║ ╚███╔╝
██╔══██╗██╔══╝  ██║     ██║   ██║██║╚██╗██║ ██╔██╗
██║  ██║███████╗╚██████╗╚██████╔╝██║ ╚████║██╔╝ ██╗
╚═╝  ╚═╝╚══════╝ ╚═════╝ ╚═════╝ ╚═╝  ╚═══╝╚═╝  ╚═╝""",
    "compact": "[ RECONX ]  Cyber Intelligence OS",
    "mini":    "■ RECONX",
}

SPINNER_STYLES: dict[str, str] = {
    "default": "dots",
    "neon":    "dots2",
    "matrix":  "line",
    "cyber":   "dots12",
}


# ─────────────────────────────────────────────────────────────────────────────
# Navigator — top-level screen router
# ─────────────────────────────────────────────────────────────────────────────

class Navigator:
    """
    Routes user choices from the Dashboard to the correct view.

    All views are lazy-imported and instantiated on first access,
    keeping startup fast.
    """

    def __init__(
        self,
        theme_name: str = "dark",
        registry    = None,
        engine      = None,
    ):
        self.theme_name = theme_name
        self.theme      = THEMES.get(theme_name, THEMES["dark"])
        self.registry   = registry
        self.engine     = engine
        self.console    = Console(theme=self.theme.to_rich_theme())

        # Lazy view instances
        self._dashboard:     Optional[object] = None
        self._tool_browser:  Optional[object] = None
        self._guided:        Optional[object] = None
        self._execution:     Optional[object] = None
        self._learning:      Optional[object] = None
        self._health_mon:    Optional[object] = None
        self._workflow_view: Optional[object] = None

    # ── main loop ─────────────────────────────────────────────────────────────

    def run(self) -> None:
        """Start the ReconX TUI application loop."""
        while True:
            choice = self._dashboard_view().run()
            if choice in ("q", "quit", "exit", "8"):
                self._farewell()
                break
            self._route(choice)

    # ── routing ───────────────────────────────────────────────────────────────

    def _route(self, choice: str) -> None:
        routes = {
            "1":  self._exec_view().prompt_and_run,
            "2":  self._learning_view().browse_lessons,
            "3":  self._guided_recon18,          # Stage 18 Guided Recon
            "4":  self._workflow_center,
            "4b": self._workflow_builder18,       # Stage 18 Workflow Builder
            "5":  self._tool_browser_view().browse_categories,
            "6":  self._reports_view,
            "7":  self._telemetry_view,
            "8":  self._settings_view,
            "qs": lambda: self._exec_view().run_quick_action("qs"),
            "ds": lambda: self._exec_view().run_quick_action("ds"),
            "ws": lambda: self._exec_view().run_quick_action("ws"),
            "ps": lambda: self._exec_view().run_quick_action("ps"),
            "cs": lambda: self._exec_view().run_quick_action("cs"),
        }
        handler = routes.get(choice.lower())
        if handler:
            handler()

    def _guided_recon18(self) -> None:
        """Launch Stage 18 Guided Recon Assistant."""
        try:
            from reconx.workflows.guided_recon import GuidedRecon18
        except ModuleNotFoundError:
            from workflows.guided_recon import GuidedRecon18
        GuidedRecon18(
            console  = self.console,
            registry = self.registry,
        ).run()

    def _workflow_builder18(self) -> None:
        """Launch Stage 18 interactive Workflow Builder."""
        try:
            from reconx.workflows.workflow_builder import WorkflowBuilder18
        except ModuleNotFoundError:
            from workflows.workflow_builder import WorkflowBuilder18
        WorkflowBuilder18(
            console  = self.console,
            registry = self.registry,
        ).run()

    # ── lazy view builders ────────────────────────────────────────────────────

    def _dashboard_view(self):
        if not self._dashboard:
            from reconx.tui.dashboard import Dashboard
            self._dashboard = Dashboard(
                console=self.console, registry=self.registry
            )
        return self._dashboard

    def _tool_browser_view(self):
        if not self._tool_browser:
            from reconx.tui.tool_browser import ToolBrowser
            self._tool_browser = ToolBrowser(
                registry    = self.registry,
                console     = self.console,
                on_run      = self._on_run_tool,
                on_learn    = self._on_learn_tool,
                on_add_wf   = self._on_add_to_workflow,
            )
        return self._tool_browser

    def _guided_view(self):
        if not self._guided:
            from reconx.tui.guided_view import GuidedReconView
            self._guided = GuidedReconView(
                console=self.console, registry=self.registry, engine=self.engine
            )
        return self._guided

    def _exec_view(self):
        if not self._execution:
            from reconx.tui.execution_view import ExecutionView
            self._execution = ExecutionView(
                console=self.console, registry=self.registry, engine=self.engine
            )
        return self._execution

    def _learning_view(self):
        if not self._learning:
            from reconx.learning.tool_lessons import LearningMode
            self._learning = LearningMode(
                console=self.console, registry=self.registry
            )
        return self._learning

    # ── stub views ────────────────────────────────────────────────────────────

    def _workflow_center(self) -> None:
        if not self._workflow_view:
            try:
                from reconx.tui.views.workflow_center import WorkflowCenter
            except ModuleNotFoundError:
                from tui.views.workflow_center import WorkflowCenter
            self._workflow_view = WorkflowCenter(
                console  = self.console,
                registry = self.registry,
                engine   = self.engine,
            )
        self._workflow_view.run()

    def _reports_view(self) -> None:
        from rich.prompt import Prompt
        from rich.table import Table
        self.console.clear()
        self.console.print("[bold cyan]Reports[/]\n")
        rdir = __import__("pathlib").Path("reports")
        if rdir.is_dir():
            files = sorted(rdir.glob("reconx_*.html"), reverse=True)[:10]
            t = Table(show_header=False, box=None, padding=(0, 2))
            for f in files:
                t.add_row(f"[cyan]•[/]", f.name, f"[dim]{f.stat().st_size // 1024} KB[/]")
            self.console.print(t)
        else:
            self.console.print("[dim]No reports found.[/]")
        Prompt.ask("\n[dim]Press Enter[/]", default="")

    def _telemetry_view(self) -> None:
        from rich.prompt import Prompt
        self.console.clear()
        try:
            from reconx.telemetry.tool_health import ToolHealthMonitor
        except ModuleNotFoundError:
            from telemetry.tool_health import ToolHealthMonitor
        monitor = ToolHealthMonitor.load()
        if self.registry:
            monitor.probe_all(self.registry)
        self.console.print(monitor.dashboard_text())
        Prompt.ask("\n[dim]Press Enter[/]", default="")

    def _settings_view(self) -> None:
        from rich.prompt import Prompt
        self.console.clear()
        self.console.print("[bold cyan]Settings[/]\n")
        self.console.print(
            "[dim]Current theme:[/] "
            f"[cyan]{self.theme.name}[/]\n"
        )
        available_themes = list(THEMES.keys())
        self.console.print("Available themes: " +
                           "  ".join(f"[cyan]{t}[/]" for t in available_themes))
        choice = Prompt.ask("\nTheme (or Enter to keep)",
                             default="", console=self.console).strip().lower()
        if choice in THEMES:
            self.theme_name = choice
            self.theme      = THEMES[choice]
            self.console    = Console(theme=self.theme.to_rich_theme())
            # Reset lazy views so they pick up new console
            self._dashboard = self._tool_browser = self._guided = None
            self._execution = self._learning = self._workflow_view = None
            self.console.print(f"[green]✓ Theme set to '{choice}'[/]")
        Prompt.ask("[dim]Press Enter[/]", default="")

    # ── tool action callbacks ─────────────────────────────────────────────────

    def _on_run_tool(self, meta) -> None:
        from rich.prompt import Prompt
        target = Prompt.ask(f"[cyan]Run {meta.name} against[/]",
                             console=self.console).strip()
        if not target:
            return
        if meta.instance:
            try:
                result = meta.instance.safe_run(target)
                findings = getattr(result, "findings", [])
                self.console.print(
                    f"\n[green]✓[/] {len(findings)} findings from {meta.name}"
                )
            except Exception as e:
                self.console.print(f"[red]Error: {e}[/]")
        else:
            self.console.print("[yellow]Tool instance not available.[/]")
        Prompt.ask("[dim]Press Enter[/]", default="")

    def _on_learn_tool(self, meta) -> None:
        from reconx.learning.tool_lessons import LearningMode, ToolLesson, LESSONS
        lesson = LESSONS.get(meta.name)
        if not lesson:
            # Build a minimal lesson from metadata
            lesson = ToolLesson(
                name=meta.name, tagline=meta.description[:80],
                problem_solved=meta.description, how_it_works=meta.description,
                use_cases=[], examples=[], output_sample="",
                common_mistakes=[], comparisons=[],
                workflow_before=[], workflow_after=[], install=meta.install_cmd,
            )
        lm = LearningMode(console=self.console, registry=self.registry)
        lm._show_lesson(lesson)

    def _on_add_to_workflow(self, meta) -> None:
        from rich.prompt import Prompt
        self.console.print(
            f"[green]✓[/] {meta.name} added to workflow queue. "
            "[dim](Workflow Center → Edit to review)[/]"
        )
        Prompt.ask("[dim]Press Enter[/]", default="")

    # ── farewell ──────────────────────────────────────────────────────────────

    def _farewell(self) -> None:
        self.console.print(
            "\n[bold cyan]ReconX[/] — session ended. Stay sharp. 🔍\n"
        )
