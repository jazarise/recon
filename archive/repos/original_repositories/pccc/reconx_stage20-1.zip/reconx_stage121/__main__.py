"""
ReconX v2.0 — CLI Entry Point.
Red-dark theme. Subcommands: scan | learn | tools | version

Usage:
  reconx scan  -t <target> [--mode fast|balanced|deep] [--output json,html,txt]
  reconx learn
  reconx tools [--category <cat>]
  reconx version
"""
from __future__ import annotations
import argparse
import ipaddress
import logging
import os
import re
import sys
from typing import Optional

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from rich import box

VERSION = "2.0.0"

# ── palette ───────────────────────────────────────────────────────────────────
C      = "red"
CB     = "bold red"
CD     = "dim red"
CMUTED = "dim"

console = Console()

# ── validators ────────────────────────────────────────────────────────────────
_HOST_RE = re.compile(
    r"^(?:[a-zA-Z0-9](?:[a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$"
)

def _validate_target(v: str) -> str:
    v = v.strip()
    try:
        ipaddress.ip_address(v); return v
    except ValueError:
        pass
    if _HOST_RE.match(v):
        return v
    raise argparse.ArgumentTypeError(f"'{v}' is not a valid IP or hostname.")

def _parse_formats(v: str) -> list[str]:
    allowed = {"txt", "json", "html"}
    fmts = [f.strip().lower() for f in v.split(",") if f.strip()]
    bad  = [f for f in fmts if f not in allowed]
    if bad:
        raise argparse.ArgumentTypeError(
            f"Unknown format(s): {', '.join(bad)}. Allowed: txt, json, html")
    return fmts

# ── argument parser ───────────────────────────────────────────────────────────

def _build_parser() -> argparse.ArgumentParser:
    root = argparse.ArgumentParser(
        prog="reconx",
        description=f"ReconX v{VERSION} — AI-Powered Reconnaissance Orchestrator",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Examples:\n"
            "  reconx scan -t example.com\n"
            "  reconx scan -t 192.168.1.1 --mode fast --output json,html\n"
            "  reconx scan -t example.com --mode deep --threads 100\n"
            "  reconx learn\n"
            "  reconx tools --category scanning\n"
        ),
    )
    root.add_argument("--version", action="version", version=f"ReconX {VERSION}")
    root.add_argument("--log-level", choices=["DEBUG","INFO","WARNING","ERROR"],
                      default="WARNING")

    sub = root.add_subparsers(dest="command", metavar="COMMAND")

    # ── scan ──────────────────────────────────────────────────────────────────
    sp = sub.add_parser("scan", help="Run a full reconnaissance scan")
    sp.add_argument("-t", "--target", type=_validate_target, required=True,
                    help="Target IP or hostname")
    sp.add_argument("--mode", choices=["fast","balanced","deep"],
                    default="balanced", help="Scan depth (default: balanced)")
    sp.add_argument("--output", type=_parse_formats, default=["html"],
                    metavar="FMT[,FMT]",
                    help="Export formats: txt, json, html (default: html)")
    sp.add_argument("--threads", type=int, default=None, metavar="N")
    sp.add_argument("--silent", action="store_true",
                    help="Suppress progress bars")
    sp.add_argument("--no-reports", action="store_true",
                    help="Terminal summary only; skip file export")

    # ── Stage 8 — Vulnerability Analysis flags ────────────────────────────────
    sp.add_argument("--vuln", action="store_true",
                    help="Run Stage 8 vulnerability analysis (Nuclei + Nikto)")
    sp.add_argument("--vuln-profile",
                    choices=["fast", "balanced", "deep", "web", "cloud", "network"],
                    default="balanced",
                    help="Vulnerability scan depth profile (default: balanced)")
    sp.add_argument("--vuln-tech", nargs="*", default=[], metavar="TECH",
                    help="Known technologies to guide template selection")
    sp.add_argument("--no-nuclei", action="store_true",
                    help="Skip Nuclei (run Nikto only)")
    sp.add_argument("--no-nikto", action="store_true",
                    help="Skip Nikto (run Nuclei only)")
    sp.add_argument("--vuln-update-templates", action="store_true",
                    help="Update Nuclei templates before scanning")

    # ── Stage 9 — Intelligence Analysis flag ──────────────────────────────────
    sp.add_argument("--intel", action="store_true",
                    help="Run Stage 9 intelligence analysis (correlation, risk scoring, graph)")

    # ── learn ─────────────────────────────────────────────────────────────────
    sub.add_parser("learn", help="Interactive tool learning & guided recon mode")

    # ── guide ──────────────────────────────────────────────────────────────────
    gp = sub.add_parser("guide", help="AI-guided recon with methodology explanations")
    gp.add_argument("target", nargs="?", default=None,
                    help="Target domain or IP to recon")
    gp.add_argument("--strategy", "-s",
                    choices=["fast", "balanced", "deep", "stealth",
                             "web", "infrastructure", "vulnerability"],
                    default=None, help="Recon strategy profile (default: auto-select)")
    gp.add_argument("--verbosity", "-v", type=int, choices=[1, 2, 3], default=2,
                    help="Explanation verbosity: 1=quiet, 2=normal, 3=verbose")
    gp.add_argument("--auto", action="store_true",
                    help="Fully automatic execution — no confirmation prompts")
    gp.add_argument("--dry-run", action="store_true",
                    help="Plan and explain without running any tools")
    gp.add_argument("--plan", action="store_true",
                    help="Show workflow plan only — do not execute")
    gp.add_argument("--explain", metavar="TOPIC",
                    help="Explain a recon methodology topic (e.g. 'passive recon', 'cve')")
    gp.add_argument("--strategies", action="store_true",
                    help="Show all available strategy profiles")

    # ── api ────────────────────────────────────────────────────────────────────
    ap = sub.add_parser("api", help="API reconnaissance & GraphQL intelligence")
    ap.add_argument("target", help="Target URL (e.g. https://api.example.com)")
    ap.add_argument("--swagger",    action="store_true", help="Probe for Swagger/OpenAPI specs")
    ap.add_argument("--graphql",    action="store_true", help="Analyse GraphQL endpoints")
    ap.add_argument("--fingerprint", action="store_true", help="Fingerprint API technologies")
    ap.add_argument("--auth",       action="store_true", help="Analyse authentication mechanisms")
    ap.add_argument("--kiterunner", action="store_true", help="Run Kiterunner route discovery (active)")
    ap.add_argument("--arjun",      action="store_true", help="Run Arjun parameter discovery (active)")
    ap.add_argument("--all",        action="store_true", help="Run all passive API modules")
    ap.add_argument("--spec",       metavar="URL",       help="Direct Swagger/OpenAPI spec URL")
    ap.add_argument("--postman",    metavar="FILE",      help="Parse a Postman collection JSON file")
    ap.add_argument("--header", "-H", action="append",  dest="headers", default=[],
                    metavar="K:V",    help="Custom header (repeatable)")

    # ── cloud ──────────────────────────────────────────────────────────────────
    cp = sub.add_parser("cloud", help="Cloud reconnaissance & exposure intelligence")
    cp.add_argument("target", help="Target domain or URL (e.g. example.com)")
    cp.add_argument("--fingerprint", action="store_true", help="Fingerprint cloud providers")
    cp.add_argument("--storage",     action="store_true", help="Scan for exposed cloud storage")
    cp.add_argument("--k8s",         action="store_true", help="Analyse Kubernetes exposure")
    cp.add_argument("--cicd",        action="store_true", help="Map CI/CD cloud infrastructure")
    cp.add_argument("--registry",    action="store_true", help="Analyse container registries")
    cp.add_argument("--all",         action="store_true", help="Run all cloud modules")
    cp.add_argument("--buckets", nargs="*", default=None, metavar="NAME",
                    help="Specific bucket name(s) to probe")
    cp.add_argument("--header", "-H", action="append", dest="headers", default=[],
                    metavar="K:V",    help="Custom header (repeatable)")

    # ── tools ─────────────────────────────────────────────────────────────────
    tp = sub.add_parser("tools", help="List all available tool knowledge files")
    tp.add_argument("--category", default=None,
                    help="Filter by category (passive, dns, subdomain, scanning, web, url, vuln, cloud)")

    return root


# ══════════════════════════════════════════════════════════════════════════════
#  Scan command
# ══════════════════════════════════════════════════════════════════════════════

def _cmd_scan(args: argparse.Namespace) -> int:
    from .cli.banner import print_banner
    from .engine.executor import ExecutionEngine
    from .output.exporter import OutputEngine

    print_banner(console, show_tools=False)

    engine = ExecutionEngine(
        mode=args.mode,
        threads=args.threads,
        silent=args.silent,
        console=console,
    )

    try:
        result = engine.run(args.target)
    except KeyboardInterrupt:
        console.print(f"\n[{CB}]Scan interrupted.[/{CB}]")
        return 130
    except Exception as exc:
        console.print(f"\n[bold red]Fatal error:[/bold red] {exc}")
        logging.exception("Engine error")
        return 1

    _print_scan_summary(result)

    if not args.no_reports:
        out = OutputEngine()
        out.export(result, formats=args.output, console=console)

    # ── Stage 8: Vulnerability Analysis (opt-in via --vuln) ──────────────────
    if getattr(args, "vuln", False):
        _cmd_vuln_analysis(args, result)

    # ── Stage 9: Intelligence analysis (opt-in via --intel) ──────────────────
    if getattr(args, "intel", False):
        _cmd_intelligence(args, result)

    return 0



# ══════════════════════════════════════════════════════════════════════════════
#  Stage 8 — Vulnerability Analysis
# ══════════════════════════════════════════════════════════════════════════════

def _cmd_vuln_analysis(args: argparse.Namespace, recon_result=None) -> None:
    """
    Invoke the Stage 8 VulnPipeline on the scan target.
    Called after the main recon scan when --vuln flag is provided.
    """
    from .tools.vuln.vuln_pipeline import VulnPipeline, VulnPipelineConfig

    target = args.target

    # Extract context from recon result if available
    open_ports:   list[int] = []
    technologies: list[str] = []

    if recon_result is not None:
        # Pull open ports from recon
        open_ports = [
            p.port for p in getattr(recon_result, "ports", [])
            if getattr(p, "state", "") in ("open", "open|filtered")
        ]
        # Pull detected technologies
        technologies = list(getattr(recon_result, "technologies", []))

    # Merge CLI-supplied technologies
    cli_tech = getattr(args, "vuln_tech", []) or []
    technologies = list(dict.fromkeys(technologies + cli_tech))

    cfg = VulnPipelineConfig(
        profile            = getattr(args, "vuln_profile", "balanced"),
        technologies       = technologies,
        open_ports         = open_ports,
        run_nuclei         = not getattr(args, "no_nuclei", False),
        run_nikto          = not getattr(args, "no_nikto", False),
        update_templates   = getattr(args, "vuln_update_templates", False),
        suppress_info      = True,   # keep terminal clean by default
    )

    pipeline = VulnPipeline(console=console)
    vuln_result = pipeline.run(target=target, config=cfg)

    # Export vuln findings to JSON if JSON output is requested
    if not getattr(args, "no_reports", False) and "json" in getattr(args, "output", []):
        _export_vuln_json(vuln_result, args.target)


def _export_vuln_json(vuln_result, target: str) -> None:
    """Serialize VulnPipelineResult to JSON alongside other reports."""
    import json
    import os
    from datetime import datetime

    os.makedirs("reports", exist_ok=True)
    ts       = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"reports/reconx_vuln_{target.replace('.', '_')}_{ts}.json"

    corr   = vuln_result.correlation
    risk   = vuln_result.risk_report
    exposures = vuln_result.exposures

    data = {
        "target":   target,
        "timestamp": ts,
        "stage":    8,
        "summary": {
            "total_findings":    len(vuln_result.scored_findings),
            "suppressed":        vuln_result.suppressed_count,
            "overall_risk":      risk.overall_risk_tier if risk else "N/A",
            "overall_score":     risk.overall_risk_score if risk else 0.0,
            "attack_chains":     len(corr.chains) if corr else 0,
            "unique_cves":       len(corr.cve_index) if corr else 0,
        },
        "correlated_findings": [
            {
                "id":           cf.finding_id,
                "title":        cf.title,
                "severity":     cf.severity.value,
                "score":        cf.adjusted_score,
                "sources":      cf.sources,
                "matched_at":   cf.matched_at,
                "cves":         cf.cves,
                "description":  cf.description,
                "remediation":  cf.remediation,
                "confidence":   cf.confidence,
                "is_amplified": cf.is_amplified,
                "chain":        cf.chain,
            }
            for cf in (corr.findings if corr else [])
        ],
        "exposures": [
            {
                "url":      exp.url,
                "category": exp.category,
                "label":    exp.label,
                "severity": exp.severity,
                "title":    exp.title,
            }
            for exp in exposures
        ],
        "remediation_queue": [
            {
                "priority":    item.priority,
                "risk_tier":   item.risk_tier,
                "title":       item.title,
                "effort":      item.effort,
                "severity":    item.severity,
                "cves":        item.cves,
            }
            for item in (risk.remediation_queue[:20] if risk else [])
        ],
        "executive_summary": risk.executive_summary if risk else "",
        "errors": vuln_result.errors,
    }

    with open(filename, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)

    console.print(f"[bold green]📦 Vuln JSON:[/bold green] {filename}")



# ══════════════════════════════════════════════════════════════════════════════
#  Stage 9 — Intelligence Analysis
# ══════════════════════════════════════════════════════════════════════════════

def _cmd_intelligence(args: argparse.Namespace, result) -> None:
    """
    Invoke the Stage 9 IntelligencePipeline after a completed scan.
    Triggered by --intel flag.
    """
    from .analysis.intelligence.intelligence_pipeline import IntelligencePipeline
    import json, os
    from datetime import datetime

    pipeline = IntelligencePipeline(console=console)
    report   = pipeline.run(result)

    if not getattr(args, "no_reports", False):
        _export_intel_json(report, result.target)


def _export_intel_json(report, target: str) -> None:
    """Serialize IntelligenceReport to JSON."""
    import json, os
    from datetime import datetime

    os.makedirs("reports", exist_ok=True)
    ts       = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"reports/reconx_intel_{target.replace('.', '_')}_{ts}.json"

    try:
        with open(filename, "w", encoding="utf-8") as f:
            json.dump(report.to_dict(), f, indent=2, default=str)
        console.print(f"[bold green]🧠 Intel JSON:[/bold green]  {filename}")
    except Exception as exc:
        console.print(f"[yellow]⚠ Intel JSON export failed: {exc}[/yellow]")



# ══════════════════════════════════════════════════════════════════════════════
#  Stage 10 — Guided Recon Command
# ══════════════════════════════════════════════════════════════════════════════

def _cmd_guide(args: argparse.Namespace) -> int:
    """
    Launch the Stage 10 AI-guided recon mode.

    Subcommand: reconx guide [target] [--strategy] [--verbosity] [--auto] [--dry-run]
    """
    from .ai.guided_recon import (
        launch_guided_recon, plan_recon, explain_methodology,
        show_strategy_comparison,
    )
    from .cli.banner import print_banner
    print_banner(console, show_tools=False)

    # --strategies: show profile comparison and exit
    if getattr(args, "strategies", False):
        show_strategy_comparison(console)
        return 0

    # --explain TOPIC: educational output and exit
    explain_topic = getattr(args, "explain", None)
    if explain_topic:
        explain_methodology(explain_topic, console)
        return 0

    # Target is required for guide/plan modes
    target = getattr(args, "target", None)
    if not target:
        console.print("[red]Error:[/red] target is required. Usage: reconx guide <target>")
        console.print("[dim]  Example: reconx guide example.com --strategy balanced[/dim]")
        console.print("[dim]  Help:    reconx guide --strategies[/dim]")
        return 1

    # --plan: show workflow plan without executing
    if getattr(args, "plan", False):
        plan_recon(
            target   = target,
            strategy = getattr(args, "strategy", None) or "balanced",
            console  = console,
        )
        return 0

    # Full guided recon session
    automation = 2 if getattr(args, "auto", False) else 1
    dry_run    = getattr(args, "dry_run", False)

    ctx = launch_guided_recon(
        target           = target,
        console          = console,
        strategy         = getattr(args, "strategy", None),
        verbosity        = getattr(args, "verbosity", 2),
        automation_level = automation,
        dry_run          = dry_run,
    )

    # Export session JSON if findings were accumulated
    if ctx.total_findings() > 0 and not dry_run:
        _export_guided_session(ctx)

    return 0


def _export_guided_session(ctx) -> None:
    """Serialize guided recon session to JSON report."""
    import json, os
    from datetime import datetime

    os.makedirs("reports", exist_ok=True)
    ts       = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"reports/reconx_guided_{ctx.target.replace('.', '_')}_{ts}.json"

    data = {
        "target":    ctx.target,
        "strategy":  ctx.strategy.value,
        "timestamp": ts,
        "summary":   ctx.summary(),
        "findings": {
            "subdomains":    ctx.subdomains,
            "open_ports":    ctx.open_ports,
            "technologies":  ctx.technologies,
            "web_endpoints": ctx.web_endpoints[:50],
            "emails":        ctx.emails,
            "cves":          ctx.cves,
            "sensitive_files": ctx.sensitive_files,
            "admin_panels":  ctx.admin_panels,
            "takeover_candidates": ctx.takeover_candidates,
        },
        "executed_steps": [
            {
                "phase":    s.phase.value,
                "action":   s.action,
                "tool":     s.tool,
                "findings": s.findings_count,
                "duration": s.duration_s,
                "skipped":  s.skipped,
            }
            for s in ctx.executed_steps
        ],
        "decisions": [
            {
                "phase":    d.phase.value,
                "decision": d.decision,
                "reason":   d.reasoning,
                "confidence": d.confidence,
            }
            for d in ctx.decision_history
        ],
        "methodology_notes": ctx.methodology_notes,
    }

    try:
        with open(filename, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, default=str)
        console.print(f"[bold green]📋 Session JSON:[/bold green] {filename}")
    except Exception as exc:
        console.print(f"[yellow]⚠ Session export failed: {exc}[/yellow]")



# ══════════════════════════════════════════════════════════════════════════════
#  Stage 11 — API Intelligence Command
# ══════════════════════════════════════════════════════════════════════════════

def _cmd_api(args: argparse.Namespace) -> int:
    """
    Launch Stage 11 API Reconnaissance & GraphQL Intelligence.

    Subcommand: reconx api <target> [--swagger] [--graphql] [--all] [--spec URL]
    """
    from .analysis.api.api_pipeline import APIPipeline, APIPipelineConfig
    from .tools.api.postman_parser import PostmanParser
    from .cli.banner import print_banner
    import json, os
    from datetime import datetime

    print_banner(console, show_tools=False)

    target = args.target

    # Parse custom headers
    custom_headers: dict = {}
    for hdr in getattr(args, "headers", []):
        if ":" in hdr:
            k, _, v = hdr.partition(":")
            custom_headers[k.strip()] = v.strip()

    # Postman collection parse (standalone mode)
    postman_file = getattr(args, "postman", None)
    if postman_file:
        parser = PostmanParser()
        res    = parser.run("postman", collection_path=postman_file)
        if res.ok:
            console.print(f"[bold green]Postman:[/bold green] {res.data.get('total', 0)} endpoints")
            if not getattr(args, "no_reports", False):
                os.makedirs("reports", exist_ok=True)
                ts = datetime.now().strftime("%Y%m%d_%H%M%S")
                fn = f"reports/reconx_postman_{ts}.json"
                with open(fn, "w") as f:
                    json.dump(res.data, f, indent=2)
                console.print(f"[bold green]📦 Postman JSON:[/bold green] {fn}")
        return 0

    run_all = getattr(args, "all", False)

    cfg = APIPipelineConfig(
        run_fingerprint    = run_all or getattr(args, "fingerprint", False),
        run_swagger        = run_all or getattr(args, "swagger", False) or True,
        run_graphql        = run_all or getattr(args, "graphql", False) or True,
        run_kiterunner     = getattr(args, "kiterunner", False),
        run_arjun          = getattr(args, "arjun", False),
        run_auth           = run_all or getattr(args, "auth", False) or True,
        swagger_spec_url   = getattr(args, "spec", None),
        custom_headers     = custom_headers,
    )

    pipeline = APIPipeline(console=console)
    report   = pipeline.run(target, config=cfg)

    # Export JSON report
    if not getattr(args, "no_reports", False):
        try:
            filename = pipeline.export_json(report)
            console.print(f"[bold green]📦 API JSON:[/bold green]  {filename}")
        except Exception as exc:
            console.print(f"[yellow]⚠ JSON export failed: {exc}[/yellow]")

    return 0



# ══════════════════════════════════════════════════════════════════════════════
#  Stage 12 — Cloud Intelligence Command
# ══════════════════════════════════════════════════════════════════════════════

def _cmd_cloud(args: argparse.Namespace) -> int:
    """
    Launch Stage 12 Cloud Reconnaissance & Exposure Intelligence.

    Subcommand: reconx cloud <target> [--storage] [--k8s] [--all]
    """
    from .analysis.cloud.cloud_pipeline import CloudPipeline, CloudPipelineConfig
    from .cli.banner import print_banner

    print_banner(console, show_tools=False)

    target = args.target
    run_all = getattr(args, "all", False)

    # Parse custom headers
    custom_headers: dict = {}
    for hdr in getattr(args, "headers", []):
        if ":" in hdr:
            k, _, v = hdr.partition(":")
            custom_headers[k.strip()] = v.strip()

    cfg = CloudPipelineConfig(
        run_fingerprint = run_all or getattr(args, "fingerprint", False) or True,
        run_aws         = run_all or True,
        run_azure       = run_all or True,
        run_gcp         = run_all or True,
        run_s3          = run_all or getattr(args, "storage", False) or True,
        run_k8s         = run_all or getattr(args, "k8s", False),
        run_cicd        = run_all or getattr(args, "cicd", False),
        run_registry    = run_all or getattr(args, "registry", False),
        bucket_names    = getattr(args, "buckets", None),
        custom_headers  = custom_headers,
    )

    pipeline = CloudPipeline(console=console)
    report   = pipeline.run(target, config=cfg)

    # Export JSON report
    if not getattr(args, "no_reports", False):
        try:
            filename = pipeline.export_json(report)
            console.print(f"[bold green]📦 Cloud JSON:[/bold green] {filename}")
        except Exception as exc:
            console.print(f"[yellow]⚠ Cloud JSON export failed: {exc}[/yellow]")

    return 0


def _print_scan_summary(result) -> None:
    """Rich-formatted scan summary in red/dark theme."""
    from rich.rule import Rule

    console.print()
    console.print(Rule(f"[{CB}]  RECONX REPORT — {result.target}  [/{CB}]",
                       style=C))
    console.print()

    # ── Stat cards ────────────────────────────────────────────────────────────
    def _card(label: str, value: str, color: str = C) -> Panel:
        return Panel(
            f"[{color}]{value}[/{color}]\n[{CMUTED}]{label}[/{CMUTED}]",
            border_style=color, padding=(0, 2), expand=True,
        )

    rs = result.risk_score
    grade_color = {"A": "green", "B": "green", "C": "yellow",
                   "D": "orange3", "F": "bold red"}.get(
                       rs.grade if rs else "A", "white")

    from rich.columns import Columns
    console.print(Columns([
        _card("IPs",         str(len(result.ip_addresses)),   C),
        _card("Subdomains",  str(len(result.subdomains)),      C),
        _card("Open Ports",  str(len(result.ports)),           CB),
        _card("CVEs",        str(len(result.cve_matches)),     "bold red"),
        _card("Takeovers",   str(len(result.takeover_candidates)), "bold red"),
        _card(f"Risk Score", f"{rs.total}/100  {rs.grade}" if rs else "—",
              grade_color),
    ], equal=True, expand=True))
    console.print()

    # ── OS ────────────────────────────────────────────────────────────────────
    if result.os_info:
        console.print(f"  [{CD}]OS:[/{CD}]  {result.os_info.get('os','?')}  "
                      f"[{CMUTED}]({result.os_info.get('confidence',0)}% confidence)[/{CMUTED}]")

    # ── Ports ─────────────────────────────────────────────────────────────────
    if result.ports:
        t = Table(title=f"[{CB}]Open Ports[/{CB}]", box=box.SIMPLE_HEAD,
                  show_edge=False, border_style=CD,
                  header_style=CB, padding=(0, 2))
        t.add_column("PORT",     style=C,      width=8,  no_wrap=True)
        t.add_column("PROTO",    style=CMUTED, width=8)
        t.add_column("SERVICE",  style="white",width=14)
        t.add_column("VERSION",  style=CMUTED)
        for p in result.ports:
            t.add_row(str(p.number), p.protocol, p.service, p.version or "—")
        console.print(t)

    # ── Subdomains ────────────────────────────────────────────────────────────
    if result.subdomains:
        console.print(f"\n  [{CB}]Subdomains[/{CB}] [{CD}]({len(result.subdomains)})[/{CD}]")
        for s in result.subdomains[:20]:
            console.print(f"  [{CD}]▸[/{CD}] [{CMUTED}]{s}[/{CMUTED}]")
        if len(result.subdomains) > 20:
            console.print(f"  [{CMUTED}]… and {len(result.subdomains)-20} more[/{CMUTED}]")

    # ── TLS ───────────────────────────────────────────────────────────────────
    if result.tls_info:
        tls = result.tls_info
        exp_color = "bold red" if tls.is_expired else (
            "yellow" if 0 <= tls.days_remaining <= 30 else "green")
        self_color = "bold red" if tls.is_self_signed else "green"
        console.print(Panel(
            f"[{CMUTED}]Subject:[/{CMUTED}]  {tls.subject}\n"
            f"[{CMUTED}]Issuer:[/{CMUTED}]   {tls.issuer}\n"
            f"[{CMUTED}]Expires:[/{CMUTED}]  [{exp_color}]{tls.valid_until}"
            f"  ({tls.days_remaining}d remaining)[/{exp_color}]\n"
            f"[{CMUTED}]Self-signed:[/{CMUTED}] [{self_color}]{'YES ⚠' if tls.is_self_signed else 'No'}[/{self_color}]\n"
            f"[{CMUTED}]Protocol:[/{CMUTED}]  {tls.protocol}  [{CMUTED}]Cipher:[/{CMUTED}]  {tls.cipher}",
            title=f"[{CB}]TLS Certificate[/{CB}]",
            border_style=exp_color, padding=(1, 2),
        ))

    # ── HTTP Headers ──────────────────────────────────────────────────────────
    if result.header_findings:
        ht = Table(title=f"[{CB}]HTTP Security Headers[/{CB}]",
                   box=box.SIMPLE_HEAD, show_edge=False,
                   border_style=CD, header_style=CB, padding=(0, 2))
        ht.add_column("HEADER",         style=C,      width=36, no_wrap=True)
        ht.add_column("STATUS",                        width=12)
        ht.add_column("DETAIL",         style=CMUTED)
        status_style = {"present": "green", "missing": "bold red", "weak": "yellow"}
        for h in result.header_findings:
            st_color = status_style.get(h.status, "white")
            detail = h.value if h.status == "present" else h.risk
            ht.add_row(h.header,
                       Text(h.status.upper(), style=st_color),
                       (detail or "")[:80])
        console.print(ht)

    # ── CVEs ──────────────────────────────────────────────────────────────────
    if result.cve_matches:
        ct = Table(title=f"[{CB}]CVE Matches[/{CB}]",
                   box=box.SIMPLE_HEAD, show_edge=False,
                   border_style="red", header_style=CB, padding=(0, 2))
        ct.add_column("CVE ID",    style="bold red", width=18, no_wrap=True)
        ct.add_column("SEV",                          width=10)
        ct.add_column("CVSS",     style=CMUTED,       width=6)
        ct.add_column("SERVICE",  style=C,            width=12)
        ct.add_column("DESCRIPTION", style=CMUTED)
        sev_style = {"CRITICAL": "bold red", "HIGH": "red",
                     "MEDIUM": "yellow", "LOW": "green"}
        for cve in result.cve_matches:
            ct.add_row(
                cve.cve_id,
                Text(cve.severity, style=sev_style.get(cve.severity.upper(), "white")),
                str(cve.cvss),
                f"{cve.service}:{cve.port}" if cve.port else cve.service,
                cve.description[:70],
            )
        console.print(ct)

    # ── Takeover candidates ───────────────────────────────────────────────────
    if result.takeover_candidates:
        tt = Table(title=f"[{CB}]⚠  Subdomain Takeover Candidates[/{CB}]",
                   box=box.SIMPLE_HEAD, show_edge=False,
                   border_style="bold red", header_style=CB, padding=(0, 2))
        tt.add_column("SUBDOMAIN",   style="bold red", width=30)
        tt.add_column("SERVICE",     style=C,          width=18)
        tt.add_column("CONFIDENCE",                    width=12)
        tt.add_column("DETAIL",      style=CMUTED)
        for tc in result.takeover_candidates:
            conf_color = "bold red" if tc.confidence == "HIGH" else "yellow"
            tt.add_row(
                tc.subdomain,
                tc.service,
                Text(tc.confidence, style=conf_color),
                tc.detail[:60],
            )
        console.print(tt)

    # ── Sensitive findings ────────────────────────────────────────────────────
    if result.sensitive_findings:
        st = Table(title=f"[{CB}]Sensitive Findings[/{CB}]",
                   box=box.SIMPLE_HEAD, show_edge=False,
                   border_style=CD, header_style=CB, padding=(0, 2))
        st.add_column("SEV",      width=10)
        st.add_column("CATEGORY", style=C,      width=20)
        st.add_column("DETAIL",   style=CMUTED)
        sev_style = {"CRITICAL": "bold red", "HIGH": "red",
                     "MEDIUM": "yellow", "LOW": "green"}
        for f in result.sensitive_findings:
            st.add_row(
                Text(f.severity, style=sev_style.get(f.severity.upper(), "white")),
                f.category,
                (f.detail + (f"\n{f.url}" if f.url else ""))[:80],
            )
        console.print(st)

    # ── Risk score breakdown ──────────────────────────────────────────────────
    if result.risk_score and result.risk_score.breakdown:
        rs = result.risk_score
        grade_color = {"A": "green", "B": "green", "C": "yellow",
                       "D": "orange3", "F": "bold red"}.get(rs.grade, "white")
        bk_text = "\n".join(
            f"  [{CD}]{k}:[/{CD}]  [{grade_color}]{v} pts[/{grade_color}]"
            for k, v in rs.breakdown.items()
        )
        console.print(Panel(
            bk_text,
            title=f"[{CB}]Risk Score: [{grade_color}]{rs.total}/100 — Grade {rs.grade}[/{grade_color}][/{CB}]",
            border_style=grade_color, padding=(1, 2),
        ))

    # ── Suggestions ───────────────────────────────────────────────────────────
    if result.suggestions:
        st2 = Table(title=f"[{CB}]Security Suggestions[/{CB}]",
                    box=box.SIMPLE_HEAD, show_edge=False,
                    border_style="yellow", header_style=CB, padding=(0, 2))
        st2.add_column("SEV",   width=10)
        st2.add_column("RISK",  style=C,      width=30)
        st2.add_column("RECOMMENDATION", style=CMUTED)
        sev_style = {"CRITICAL": "bold red", "HIGH": "red",
                     "MEDIUM": "yellow", "LOW": "green"}
        for s in result.suggestions:
            st2.add_row(
                Text(s.severity, style=sev_style.get(s.severity.upper(), "white")),
                s.risk,
                s.recommendation,
            )
        console.print(st2)

    console.print()
    console.rule(style=C)
    console.print(f"  [{CMUTED}]⚠  Authorized security testing and educational use only.[/{CMUTED}]\n")


# ══════════════════════════════════════════════════════════════════════════════
#  Learn command
# ══════════════════════════════════════════════════════════════════════════════

def _cmd_learn(_args: argparse.Namespace) -> int:
    from .cli.banner import print_banner
    from .cli.interactive import launch_learn_mode
    print_banner(console, show_tools=False)
    launch_learn_mode()
    return 0


# ══════════════════════════════════════════════════════════════════════════════
#  Tools command
# ══════════════════════════════════════════════════════════════════════════════

def _cmd_tools(args: argparse.Namespace) -> int:
    from .cli.banner import print_banner
    from .cli.categories import CATEGORIES
    from .knowledge.loader import load_all

    print_banner(console, show_tools=False)

    all_tools = load_all()
    cat_filter = args.category

    t = Table(
        title=f"[{CB}]ReconX Tool Knowledge Base[/{CB}]",
        box=box.SIMPLE_HEAD, show_edge=False,
        border_style=CD, header_style=CB, padding=(0, 2),
    )
    t.add_column("TOOL",     style=C,      width=16, no_wrap=True)
    t.add_column("CATEGORY", style=CMUTED, width=14)
    t.add_column("COMMAND",  style="green",width=48)
    t.add_column("STATUS",                 width=12)

    for slug, data in sorted(all_tools.items()):
        cat = data.get("category", "")
        if cat_filter and cat != cat_filter:
            continue
        t.add_row(
            slug,
            cat,
            (data.get("command") or "")[:46],
            Text("● docs", style="bold green"),
        )

    console.print(t)
    console.print(f"\n  [{CMUTED}]Use [bold]reconx learn[/bold] to explore tools interactively.[/{CMUTED}]\n")
    return 0


# ══════════════════════════════════════════════════════════════════════════════
#  Entry point
# ══════════════════════════════════════════════════════════════════════════════

def main() -> int:
    parser = _build_parser()
    args   = parser.parse_args()

    logging.basicConfig(
        level=getattr(logging, args.log_level),
        format="%(levelname)-8s  %(name)s — %(message)s",
    )

    if not args.command:
        # No subcommand — show banner + help
        from .cli.banner import print_banner
        print_banner(console, show_tools=True)
        parser.print_help()
        return 0

    dispatch = {
        "scan":    _cmd_scan,
        "learn":   _cmd_learn,
        "tools":   _cmd_tools,
        "guide":   _cmd_guide,
        "api":     _cmd_api,
        "cloud":   _cmd_cloud,
    }

    handler = dispatch.get(args.command)
    if not handler:
        console.print(f"[red]Unknown command: {args.command}[/red]")
        return 1

    return handler(args)


if __name__ == "__main__":
    sys.exit(main())
