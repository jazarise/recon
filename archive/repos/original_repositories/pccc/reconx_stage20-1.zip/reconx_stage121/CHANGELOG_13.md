# ReconX — Stage 13 Changelog

## Overview

Stage 13 transforms ReconX from a collection of tools into an **intelligent
orchestration platform**. The focus is not new tools but making all 40+ existing
tools work together efficiently through a unified execution layer.

---

## New Files

### `orchestration/` — Core Orchestration Layer

| File | Class | Role |
|---|---|---|
| `tool_registry.py` | `ToolRegistry` | Auto-discovers every BaseTool subclass via `pkgutil.walk_packages`. Indexes by class name with metadata: category, stage, passive, inputs, tags. Exposes `filter()`, `search()`, `by_category()`, `by_input()`. |
| `tool_chains.py` | `ChainRunner`, `ChainStep` | 10 pre-built chains (ASSET_DISCOVERY, DNS_PIPELINE, WEB_RECON, API_RECON, SECRETS, CLOUD, CERTIFICATE, IDENTITY, NETWORK, FULL_RECON). Context propagates findings between steps automatically. Conditional execution via `condition_fn`. |
| `pipeline_engine.py` | `PipelineEngine`, `PipelineTask` | Parallel staged execution (ThreadPoolExecutor). Stage 1→2→3 order enforced. Dependency graph within stages. Per-task retry with exponential backoff. Failure isolation — one crash never halts the pipeline. |
| `reconx_engine.py` | `ReconXEngine` | Top-level entry point. Wires all Stage 13 components: classify → recommend → execute → TUI → telemetry → report. |
| `__init__.py` | — | Package exports. |

### `analysis/target_classifier.py` — `TargetClassifier`

Auto-detects 12 target types:
`ip` · `cidr` · `domain` · `subdomain` · `url` · `asn` · `email` · `phone` · `github_repo` · `github_org` · `cloud_bucket` · `git_url`

Detector pipeline (ordered, first match wins):
1. CIDR → `ip_network()` validation
2. IP → `ip_address()` validation
3. ASN → `AS\d+` regex
4. Email → RFC-5321 regex
5. GitHub repo/org → URL pattern match
6. Git URL → git://, .git suffix, known hosts
7. Cloud bucket → S3/GCS/Azure URL patterns
8. URL → scheme prefix
9. Phone → digit/format heuristic
10. Subdomain → 3+ labels + common-prefix heuristic
11. Domain → 2-label domain regex
12. Resolvable → DNS lookup fallback

Each `ClassifiedTarget` carries:
- `target_type`, `normalized`, `confidence`
- `recommended_workflows` — full recon workflow list
- `passive_workflows` — zero-traffic alternative
- `is_passive_friendly` flag
- `metadata` dict (provider, TLD, version, etc.)

### `workflow/recommendation_engine.py` — `RecommendationEngine`

Generates ordered tool lists per `(target_type, mode)` combination.

Six scan modes:

| Mode | Description | Domain tools |
|---|---|---|
| `fast` | 5–15 min, passive + quick active | 8 tools |
| `balanced` | 30–60 min, standard | 19 tools |
| `deep` | 1–4 hrs, all tools | 35 tools |
| `passive` | zero active traffic | 11 tools |
| `custom` | user-defined list | user-specified |
| `ai` | heuristic-scored balanced list | scored by relevance |

`WorkflowRecommendation` output:
- Ordered `tool_list` (installed tools only when `filter_unavailable=True`)
- `estimated_min` (per-tool time lookup table)
- `skipped_unavailable` list with install commands
- `summary()` human-readable text
- `to_pipeline_tasks()` direct PipelineEngine integration

### `telemetry/tool_health.py` — `ToolHealthMonitor`

Tracks per-tool health across sessions, persisted to `cache/tool_health.json`.

Per-tool `ToolHealthRecord`:
- `available` — binary on PATH
- `version` — parsed from `--version` output
- `deps_ok` / `missing_deps`
- `total_runs`, `failed_runs`, `total_time_s`
- Derived: `failure_rate`, `avg_runtime_s`, `status_label`

Status labels: `OK` · `MISSING` · `DEP_ERROR` · `DEGRADED`

Key methods:
- `probe_all(registry)` — probe all tools, skip if checked < 1hr ago
- `record_run(class_name, duration_s, failed)` — called by pipeline
- `dashboard_text()` — formatted ASCII health dashboard
- `install_guide()` — install commands for all missing tools

### `output/operations_center.py` — `OperationsCenter`

Live Rich TUI context manager for pipeline execution.

Four panels rendered simultaneously:
- **Header** — target, mode, elapsed time, task count
- **Pipeline** — per-tool status table (status icon + duration + finding count)
- **Findings** — live count by finding type
- **System** — success rate, pass/fail counts, custom metrics

Colour system:
- `[RUNNING]` → cyan spinner
- `[SUCCESS]` → green ✓
- `[FAILED]`  → red ✗
- `[MISSING]` → yellow ?
- `[SKIPPED]` → dim –
- `[RETRYING]` → orange ↺

Methods: `set_status()`, `add_finding()`, `add_findings_bulk()`, `update_system()`, `log()`, `print_final_summary()`

### `tests/test_stage13_orchestration.py` — 6 test classes, 35+ tests

| Class | Coverage |
|---|---|
| `TestTargetClassifier` | All 12 target types + batch + passive_friendly flag |
| `TestChainRunner` | Success, failure isolation, missing tool, conditional skip, BUILTIN_CHAINS |
| `TestPipelineEngine` | Parallel success, failure isolation, missing tool, findings in result |
| `TestRecommendationEngine` | All modes, all major target types, time estimates, summary string |
| `TestToolHealthMonitor` | Record runs, failure rate, status labels, dashboard, install guide |
| `TestReconXEngine` | Dry-run for domain, IP, CIDR — end-to-end wiring |

---

## Architecture: Full Execution Flow

```
User Input: "example.com"
    │
    ▼
TargetClassifier.classify()
    │  → ClassifiedTarget(type="domain", confidence=0.95)
    │
    ▼
RecommendationEngine.recommend(ct, mode="balanced")
    │  → WorkflowRecommendation(tool_list=[19 tools], estimated_min=47)
    │
    ▼
rec.to_pipeline_tasks(target)
    │  → [PipelineTask(tool_class="WhoisTool"), ...]
    │
    ▼
PipelineEngine.execute(tasks, target)
    ├── Stage 1 (Passive): WhoisTool, CrtshTool, TheHarvesterTool  ──→ parallel
    ├── Stage 2 (Active):  HttpxTool, DNSReconTool, NmapTool       ──→ parallel
    └── Stage 3 (Deep):    KatanaTool, FeroxbusterTool, GoWitness  ──→ parallel
    │
    │  Each task: run → retry(×1) → record health → propagate findings to ctx
    │
    ▼
OperationsCenter (Live TUI)
    │  Four panels: pipeline status · findings · system · log
    │
    ▼
ToolHealthMonitor.record_run() × N
    │  Persisted to cache/tool_health.json
    │
    ▼
generate_stage121_report()
    │  reports/reconx_example_com_20250517_142201.html
    │
    ▼
ReconXRunResult(
    total_findings=342, success_count=16, failed_count=3,
    duration_s=287.4, report_path="reports/..."
)
```

---

## Tool Chaining — Context Propagation

Findings from each tool are automatically extracted and stored by type in a
shared context dict. Subsequent tools receive relevant context as kwargs:

```python
# After TheHarvesterTool finds subdomains:
ctx["subdomain"] = ["api.example.com", "dev.example.com", ...]

# ShuffleDNSTool receives them automatically:
ShuffleDNSTool.run(target, subdomains=ctx["subdomain"])

# After NmapTool finds open ports:
ctx["open_port"] = [80, 443, 8080]

# MetasploitAuxTool and KatanaTool receive live hosts:
KatanaTool.run(target, urls=ctx["url"])
```

Context keys: `subdomain`, `live_host`, `open_port`, `url`, `historical_url`,
`email`, `cidr_range`, `ip`, `api_endpoint`, `secret`, `web_screenshot`

---

## Guided Recon Modes (Part 10)

`RecommendationEngine` powers four guided workflow modes:

```
Fast Mode   ──→ 8 tools, ~15 min, triage
Balanced    ──→ 19 tools, ~47 min, standard assessment
Deep Mode   ──→ 35 tools, ~2.5 hrs, thorough
Passive     ──→ 11 tools, zero active traffic
Custom      ──→ user selects tools
AI Mode     ──→ heuristic-scored recommendation
```

Each recommendation includes:
- Rationale explaining why this tool set was chosen
- Time estimate per tool
- Skip list of unavailable tools with install commands
- Direct `to_pipeline_tasks()` conversion for immediate execution
