"""
ReconX — Stage 18.1 Test Suite: Burp Intelligence Layer

Tests cover:
  1. BurpClient  — request building, diagnostics, graceful error handling
  2. TrafficParser — parse_history with synthetic traffic items
  3. ProjectManager — CRUD, cache read/write
  4. SessionManager — start/stop/resume lifecycle
  5. IssueImporter — normalise Burp issue dicts
  6. ReplayEngine — report construction, error handling
  7. ProxyController — config helpers, env vars
  8. ReportInjector — HTML injection
  9. WebIntelligencePanel — render without crash
 10. CLI dispatcher — command routing
 11. Registry — catalog metadata integrity

All tests run offline (no real Burp instance required).
Network calls are mocked with unittest.mock.
"""
from __future__ import annotations

import json
import sys
import tempfile
import time
import unittest
import uuid
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

# ── Ensure package root is on path ───────────────────────────────────────────
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


# ══════════════════════════════════════════════════════════════════════════════
# 1. BurpClient
# ══════════════════════════════════════════════════════════════════════════════

class TestBurpClient(unittest.TestCase):

    def _make_client(self):
        from integrations.burp.burp_client import BurpClient
        return BurpClient(host="127.0.0.1", port=1337, api_key="test-key")

    def test_base_url_formed_correctly(self):
        c = self._make_client()
        self.assertEqual(c.base_url, "http://127.0.0.1:1337/v0.1/")

    def test_tls_base_url(self):
        from integrations.burp.burp_client import BurpClient
        c = BurpClient(tls=True)
        self.assertTrue(c.base_url.startswith("https://"))

    def test_headers_include_api_key(self):
        c = self._make_client()
        h = c._headers()
        self.assertEqual(h["X-Burp-Key"], "test-key")
        self.assertEqual(h["Content-Type"], "application/json")

    def test_headers_no_api_key(self):
        from integrations.burp.burp_client import BurpClient
        c = BurpClient(api_key="")
        h = c._headers()
        self.assertNotIn("X-Burp-Key", h)

    def test_ping_failure_returns_false(self):
        c = self._make_client()
        ok, err = c.ping()          # real connection attempt to non-existent Burp
        self.assertFalse(ok)
        self.assertIsInstance(err, str)
        self.assertGreater(len(err), 0)

    def test_get_returns_empty_on_error(self):
        c = self._make_client()
        data, err = c._get("nonexistent/path")
        self.assertEqual(data, {})
        self.assertIsInstance(err, str)

    def test_diagnostics_never_raises(self):
        c = self._make_client()
        d = c.get_diagnostics()
        self.assertIn("reachable", d)
        self.assertIn("base_url", d)
        self.assertFalse(d["reachable"])    # Burp not running

    def test_get_proxy_history_returns_list_on_error(self):
        c = self._make_client()
        items, err = c.get_proxy_history()
        self.assertIsInstance(items, list)

    def test_get_scan_issues_returns_list_on_error(self):
        c = self._make_client()
        issues, err = c.get_scan_issues()
        self.assertIsInstance(issues, list)


# ══════════════════════════════════════════════════════════════════════════════
# 2. TrafficParser
# ══════════════════════════════════════════════════════════════════════════════

class TestTrafficParser(unittest.TestCase):

    def _make_parser(self):
        from integrations.burp.traffic_parser import TrafficParser
        return TrafficParser()

    def _raw_item(self, url="https://example.com/api/v1/users",
                  method="GET", status=200,
                  req_headers=None, resp_headers=None, body=""):
        import base64
        req_head = req_headers or {}
        resp_head = resp_headers or {"content-type": "text/html", "server": "nginx"}
        req_raw  = f"{method} {url} HTTP/1.1\r\n"
        req_raw += "".join(f"{k}: {v}\r\n" for k, v in req_head.items())
        req_raw += f"\r\n{body}"
        resp_raw = f"HTTP/1.1 {status} OK\r\n"
        resp_raw += "".join(f"{k}: {v}\r\n" for k, v in resp_head.items())
        resp_raw += f"\r\n{body}"
        from urllib.parse import urlparse
        p = urlparse(url)
        return {
            "host":     p.netloc,
            "protocol": p.scheme,
            "method":   method,
            "path":     p.path + (f"?{p.query}" if p.query else ""),
            "request":  base64.b64encode(req_raw.encode()).decode(),
            "response": base64.b64encode(resp_raw.encode()).decode(),
            "status":   status,
        }

    def test_parse_empty_returns_zero_requests(self):
        p = self._make_parser()
        s = p.parse_history([])
        self.assertEqual(s.total_requests, 0)
        self.assertEqual(s.endpoints, [])

    def test_parse_single_api_route(self):
        p = self._make_parser()
        item = self._raw_item("https://example.com/api/v1/users")
        s = p.parse_history([item])
        self.assertEqual(s.total_requests, 1)
        self.assertIn("api", [e.get("categories", [""])[0] for e in s.endpoints if e.get("categories")])
        self.assertTrue(len(s.api_routes) >= 1)

    def test_detect_graphql_endpoint(self):
        p = self._make_parser()
        item = self._raw_item("https://example.com/graphql", method="POST")
        s = p.parse_history([item])
        self.assertTrue(len(s.graphql_endpoints) >= 1)

    def test_detect_admin_portal(self):
        p = self._make_parser()
        item = self._raw_item("https://example.com/admin/dashboard")
        s = p.parse_history([item])
        self.assertIn("https://example.com/admin/dashboard", s.admin_portals)

    def test_detect_login_page(self):
        p = self._make_parser()
        item = self._raw_item("https://example.com/login")
        s = p.parse_history([item])
        self.assertIn("https://example.com/login", s.login_pages)

    def test_detect_jwt_in_request(self):
        import base64, json as _json
        header  = base64.urlsafe_b64encode(b'{"alg":"HS256"}').decode().rstrip("=")
        payload = base64.urlsafe_b64encode(b'{"sub":"1234","name":"test"}').decode().rstrip("=")
        sig     = "fakesignatureXXX"
        jwt_val = f"{header}.{payload}.{sig}"

        p    = self._make_parser()
        item = self._raw_item(req_headers={"Authorization": f"Bearer {jwt_val}"})
        s    = p.parse_history([item])
        jwt_tokens = [t for t in s.auth_tokens if t.get("type") == "jwt"]
        self.assertTrue(len(jwt_tokens) >= 1)

    def test_detect_missing_security_headers(self):
        p    = self._make_parser()
        item = self._raw_item(
            resp_headers={"content-type": "text/html"},  # no security headers
        )
        s = p.parse_history([item])
        header_names = [i["header"] for i in s.security_issues if i.get("type") == "missing_header"]
        self.assertIn("strict-transport-security", header_names)

    def test_detect_cors_wildcard(self):
        p    = self._make_parser()
        item = self._raw_item(
            resp_headers={
                "content-type": "text/html",
                "access-control-allow-origin": "*",
            },
        )
        s = p.parse_history([item])
        cors_issues = [i for i in s.security_issues if i.get("type") == "cors"]
        self.assertTrue(len(cors_issues) >= 1)

    def test_server_banner_info_disclosure(self):
        p    = self._make_parser()
        item = self._raw_item(resp_headers={"server": "Apache/2.4.51", "content-type": "text/html"})
        s    = p.parse_history([item])
        server_disc = [i for i in s.info_disclosure if i.get("header") == "server"]
        self.assertTrue(len(server_disc) >= 1)

    def test_extract_cookies(self):
        p    = self._make_parser()
        item = self._raw_item(
            resp_headers={
                "content-type": "text/html",
                "set-cookie": "session=abc123; HttpOnly; Secure; SameSite=Strict",
            }
        )
        s = p.parse_history([item])
        self.assertTrue(len(s.cookies) >= 1)
        ck = s.cookies[0]
        self.assertTrue(ck["http_only"])
        self.assertTrue(ck["secure"])

    def test_to_dict_is_serialisable(self):
        p = self._make_parser()
        s = p.parse_history([self._raw_item()])
        d = s.to_dict()
        # Must be JSON-serialisable
        json.dumps(d)

    def test_unique_hosts_tracked(self):
        p = self._make_parser()
        items = [
            self._raw_item("https://example.com/page1"),
            self._raw_item("https://api.example.com/v1"),
        ]
        s = p.parse_history(items)
        self.assertIn("example.com", s.unique_hosts)
        self.assertIn("api.example.com", s.unique_hosts)


# ══════════════════════════════════════════════════════════════════════════════
# 3. BurpProject & ProjectManager
# ══════════════════════════════════════════════════════════════════════════════

class TestProjectManager(unittest.TestCase):

    def _make_mock_client(self):
        client = MagicMock()
        client.ping.return_value = (True, "")
        client.create_project.return_value = ({"id": "proj-abc123", "name": "reconx_test"}, "")
        client.load_project.return_value   = ({"id": "proj-abc123", "name": "reconx_test"}, "")
        client.list_projects.return_value  = ([], "")
        return client

    def _make_manager(self, client=None):
        from integrations.burp.project_manager import ProjectManager
        return ProjectManager(client or self._make_mock_client())

    def test_create_for_target_returns_project(self):
        pm = self._make_manager()
        proj, err = pm.create_for_target("example.com")
        self.assertEqual(err, "")          # empty string = no error
        self.assertIsNotNone(proj)
        self.assertEqual(proj.target, "example.com")
        self.assertIn("reconx_example.com", proj.name)

    def test_create_failure_returns_none_and_error(self):
        client = MagicMock()
        client.create_project.return_value = ({}, "Connection refused")
        pm = self._make_manager(client)
        proj, err = pm.create_for_target("example.com")
        self.assertIsNone(proj)
        self.assertIn("Connection refused", err)

    def test_list_cached_empty(self):
        pm = self._make_manager()
        sessions = pm.list_cached()
        self.assertIsInstance(sessions, list)

    def test_cache_roundtrip(self):
        from integrations.burp.project_manager import BurpProject
        pm = self._make_manager()
        proj, _ = pm.create_for_target("roundtrip.com")
        if proj:
            pm.save(proj)
            loaded, _ = pm.load(proj.project_id)
            if loaded:
                self.assertEqual(loaded.project_id, proj.project_id)

    def test_find_for_target(self):
        pm = self._make_manager()
        proj, _ = pm.create_for_target("findme.io")
        if proj:
            found = pm.find_for_target("findme.io")
            self.assertTrue(any(p.target == "findme.io" for p in found))


# ══════════════════════════════════════════════════════════════════════════════
# 4. BurpSession & SessionManager
# ══════════════════════════════════════════════════════════════════════════════

class TestSessionManager(unittest.TestCase):

    def _make_mock_client(self):
        client = MagicMock()
        client.get_proxy_history.return_value = ([], "")
        return client

    def _make_project(self):
        from integrations.burp.project_manager import BurpProject
        return BurpProject(
            project_id=uuid.uuid4().hex,
            name="reconx_test",
            target="example.com",
        )

    def _make_manager(self):
        from integrations.burp.session_manager import SessionManager
        return SessionManager(self._make_mock_client())

    def test_start_creates_active_session(self):
        sm   = self._make_manager()
        proj = self._make_project()
        sess, err = sm.start(proj, target="example.com")
        self.assertEqual(err, "")
        self.assertIsNotNone(sess)
        self.assertTrue(sess.is_active)
        self.assertEqual(sess.target, "example.com")

    def test_stop_changes_state(self):
        sm   = self._make_manager()
        proj = self._make_project()
        sess, _  = sm.start(proj)
        sess, err = sm.stop(sess)
        from integrations.burp.session_manager import SessionState
        self.assertEqual(sess.state, SessionState.STOPPED)
        self.assertGreater(sess.stopped_at, 0)

    def test_pause_changes_state(self):
        sm   = self._make_manager()
        proj = self._make_project()
        sess, _ = sm.start(proj)
        err = sm.pause(sess)
        from integrations.burp.session_manager import SessionState
        self.assertEqual(err, "")
        self.assertEqual(sess.state, SessionState.PAUSED)

    def test_short_id_is_8_chars(self):
        sm   = self._make_manager()
        proj = self._make_project()
        sess, _ = sm.start(proj)
        self.assertEqual(len(sess.short_id), 8)

    def test_duration_increases_after_stop(self):
        sm   = self._make_manager()
        proj = self._make_project()
        sess, _ = sm.start(proj)
        time.sleep(0.05)
        sess, _ = sm.stop(sess)
        self.assertGreater(sess.duration_s, 0)

    def test_list_sessions_returns_list(self):
        sm = self._make_manager()
        sessions = sm.list_sessions()
        self.assertIsInstance(sessions, list)

    def test_find_by_short_id(self):
        sm   = self._make_manager()
        proj = self._make_project()
        sess, _ = sm.start(proj)
        sm.stop(sess)
        found = sm.get_session(sess.short_id)
        if found:   # may not persist if cache dir not writable in test env
            self.assertEqual(found.session_id, sess.session_id)


# ══════════════════════════════════════════════════════════════════════════════
# 5. IssueImporter
# ══════════════════════════════════════════════════════════════════════════════

class TestIssueImporter(unittest.TestCase):

    def _make_mock_client(self, issues=None, site_map=None):
        client = MagicMock()
        client.get_scan_issues.return_value  = (issues or [], "")
        client.get_site_map.return_value     = (site_map or [], "")
        return client

    def _make_importer(self, issues=None, site_map=None):
        from integrations.burp.issue_importer import IssueImporter
        return IssueImporter(self._make_mock_client(issues=issues, site_map=site_map))

    def test_empty_issues_returns_empty_findings(self):
        imp = self._make_importer()
        f   = imp.import_findings()
        self.assertEqual(f.total, 0)
        self.assertEqual(f.headers, [])
        self.assertEqual(f.sensitive, [])
        self.assertEqual(f.error, "")

    def test_hsts_issue_becomes_header_finding(self):
        issues = [{
            "name":        "Strict transport security not enforced",
            "severity":    "high",
            "host":        "example.com",
            "path":        "/",
            "detail":      "HSTS header missing",
            "remediation": "Add Strict-Transport-Security header.",
        }]
        imp = self._make_importer(issues=issues)
        f   = imp.import_findings()
        self.assertEqual(f.total, 1)
        self.assertTrue(len(f.headers) >= 1)
        self.assertEqual(f.headers[0].header, "strict-transport-security")

    def test_cors_issue_becomes_sensitive_finding(self):
        issues = [{
            "name":     "CORS misconfiguration",
            "severity": "high",
            "host":     "api.example.com",
            "path":     "/api/data",
            "detail":   "Wildcard CORS origin",
        }]
        imp = self._make_importer(issues=issues)
        f   = imp.import_findings()
        cors_f = [s for s in f.sensitive if s.category == "cors"]
        self.assertTrue(len(cors_f) >= 1)

    def test_severity_normalisation(self):
        issues = [
            {"name": "Information disclosure", "severity": "information",
             "host": "x.com", "path": "/", "detail": "Banner exposed"},
        ]
        imp = self._make_importer(issues=issues)
        f   = imp.import_findings()
        info_f = [s for s in f.sensitive if s.severity == "INFO"]
        self.assertTrue(len(info_f) >= 1)

    def test_site_map_returns_urls(self):
        site_map = [{"url": "https://example.com/hidden"}, {"url": "https://example.com/api"}]
        imp  = self._make_importer(site_map=site_map)
        urls = imp.import_site_map_findings()
        self.assertIn("https://example.com/hidden", urls)

    def test_to_parsed_findings_returns_list(self):
        imp = self._make_importer()
        f   = imp.import_findings()
        pf  = f.to_parsed_findings()
        self.assertIsInstance(pf, list)

    def test_api_error_returns_error_string(self):
        client = MagicMock()
        client.get_scan_issues.return_value = ([], "Connection refused")
        from integrations.burp.issue_importer import IssueImporter
        imp = IssueImporter(client)
        f   = imp.import_findings()
        self.assertIn("Connection refused", f.error)


# ══════════════════════════════════════════════════════════════════════════════
# 6. ReplayEngine
# ══════════════════════════════════════════════════════════════════════════════

class TestReplayEngine(unittest.TestCase):

    def _make_engine(self, replay_response=None):
        client = MagicMock()
        client.replay_request.return_value = (
            replay_response or {"statusCode": 200, "responseLength": 512, "method": "GET", "url": "https://example.com/api"},
            "",
        )
        session_mgr = MagicMock()
        from integrations.burp.replay_engine import ReplayEngine
        return ReplayEngine(client, session_mgr)

    def _make_session(self):
        from integrations.burp.session_manager import BurpSession, SessionState
        return BurpSession(
            session_id=uuid.uuid4().hex,
            target="example.com",
            project_id="proj-1",
            state=SessionState.STOPPED,
            item_ids=[uuid.uuid4().hex for _ in range(3)],
        )

    def test_replay_single_success(self):
        engine  = self._make_engine()
        session = self._make_session()
        report  = engine.replay_single(session, session.item_ids[0])
        self.assertEqual(report.total, 1)
        self.assertEqual(report.succeeded, 1)
        self.assertEqual(report.failed, 0)
        self.assertEqual(report.mode, "single")

    def test_replay_sequence_success(self):
        engine  = self._make_engine()
        session = self._make_session()
        report  = engine.replay_sequence(session, session.item_ids, delay_s=0)
        self.assertEqual(report.total, len(session.item_ids))
        self.assertEqual(report.succeeded, len(session.item_ids))

    def test_replay_error_does_not_raise(self):
        client = MagicMock()
        client.replay_request.return_value = ({}, "Connection reset")
        session_mgr = MagicMock()
        from integrations.burp.replay_engine import ReplayEngine
        engine  = ReplayEngine(client, session_mgr)
        session = self._make_session()
        report  = engine.replay_sequence(session, session.item_ids[:1], delay_s=0)
        self.assertEqual(report.failed, 1)
        self.assertEqual(report.succeeded, 0)

    def test_replay_session_no_items_returns_error(self):
        engine  = self._make_engine()
        from integrations.burp.session_manager import BurpSession, SessionState
        session = BurpSession(
            session_id=uuid.uuid4().hex,
            target="example.com",
            project_id="proj-1",
            state=SessionState.STOPPED,
            item_ids=[],
        )
        report = engine.replay_session(session)
        self.assertNotEqual(report.error, "")

    def test_report_to_dict_serialisable(self):
        engine  = self._make_engine()
        session = self._make_session()
        report  = engine.replay_single(session, session.item_ids[0])
        json.dumps(report.to_dict())

    def test_success_rate_calculation(self):
        from integrations.burp.replay_engine import ReplayReport
        r = ReplayReport(session_id="abc", mode="test", total=10, succeeded=7, failed=3)
        self.assertAlmostEqual(r.success_rate, 70.0)

    def test_cli_entry_missing_session_returns_error(self):
        client = MagicMock()
        sm     = MagicMock()
        sm.get_session.return_value = None
        from integrations.burp.replay_engine import ReplayEngine
        engine = ReplayEngine(client, sm)
        report = engine.run_from_cli("nonexistent")
        self.assertNotEqual(report.error, "")


# ══════════════════════════════════════════════════════════════════════════════
# 7. ProxyController config helpers
# ══════════════════════════════════════════════════════════════════════════════

class TestProxyController(unittest.TestCase):

    def test_proxy_url_formed(self):
        from integrations.burp.proxy_controller import ProxyConfig
        cfg = ProxyConfig(host="127.0.0.1", port=8080)
        self.assertEqual(cfg.proxy_url, "http://127.0.0.1:8080")

    def test_playwright_proxy(self):
        from integrations.burp.proxy_controller import ProxyConfig
        cfg = ProxyConfig()
        self.assertEqual(cfg.playwright_proxy, {"server": "http://127.0.0.1:8080"})

    def test_httpx_proxy(self):
        from integrations.burp.proxy_controller import ProxyConfig
        cfg = ProxyConfig()
        d   = cfg.httpx_proxy
        self.assertIn("proxy", d)
        self.assertIn("8080", d["proxy"])

    def test_env_vars_set(self):
        from integrations.burp.proxy_controller import ProxyConfig
        cfg  = ProxyConfig(port=8181)
        envs = cfg.env_vars
        self.assertIn("HTTP_PROXY", envs)
        self.assertIn("8181", envs["HTTP_PROXY"])

    def test_stop_when_not_started_does_not_raise(self):
        client = MagicMock()
        client.ping.return_value = (False, "not running")
        from integrations.burp.proxy_controller import ProxyController
        ctrl = ProxyController(client)
        ctrl.stop()   # should be a no-op

    def test_is_running_false_when_api_down(self):
        client = MagicMock()
        client.ping.return_value = (False, "down")
        from integrations.burp.proxy_controller import ProxyController
        ctrl = ProxyController(client)
        self.assertFalse(ctrl.is_running())


# ══════════════════════════════════════════════════════════════════════════════
# 8. ReportInjector
# ══════════════════════════════════════════════════════════════════════════════

class TestReportInjector(unittest.TestCase):

    def _minimal_html(self) -> str:
        return """<!DOCTYPE html>
<html><head><style>:root{--bg2:#0c1420;--border:#1a3050;--dim:#5a7a9a;--text:#c8d8e8;}</style></head>
<body><div class="container"><p>existing content</p></div></body></html>"""

    def _sample_burp_data(self) -> dict:
        return {
            "session": {"session_id": "abc123", "short_id": "abc123ab",
                        "target": "example.com", "state": "stopped",
                        "duration_s": 12.3, "item_count": 42},
            "proxy":   {"running": False, "url": "http://127.0.0.1:8080", "error": ""},
            "traffic": {
                "total_requests": 42,
                "endpoints": [
                    {"url": "https://example.com/api/users", "method": "GET",
                     "status": 200, "categories": ["api"]},
                ],
                "auth_tokens":    [{"type": "jwt", "value": "eyJ...", "url": "https://example.com"}],
                "cookies":        [{"name": "session", "host": "example.com",
                                    "secure": True, "http_only": True, "same_site": "Strict"}],
                "security_issues": [{"type": "missing_header", "header": "strict-transport-security",
                                     "detail": "HSTS missing", "url": "https://example.com"}],
                "api_routes":     ["https://example.com/api/users"],
                "login_pages":    ["https://example.com/login"],
                "admin_portals":  [],
            },
            "issues":   {"total": 1, "headers": 1, "sensitive": 0, "suggestions": 1},
            "site_map": {"url_count": 5, "urls": ["https://example.com/page1"]},
        }

    def test_inject_returns_true_on_valid_file(self):
        from integrations.burp.report_injector import inject_burp_section
        with tempfile.NamedTemporaryFile(mode="w", suffix=".html",
                                         delete=False, encoding="utf-8") as f:
            f.write(self._minimal_html())
            path = f.name
        result = inject_burp_section(path, self._sample_burp_data())
        self.assertTrue(result)
        content = Path(path).read_text()
        self.assertIn("Web Intelligence", content)
        self.assertIn("burp-section", content)

    def test_inject_includes_endpoints(self):
        from integrations.burp.report_injector import inject_burp_section
        with tempfile.NamedTemporaryFile(mode="w", suffix=".html",
                                         delete=False, encoding="utf-8") as f:
            f.write(self._minimal_html())
            path = f.name
        inject_burp_section(path, self._sample_burp_data())
        content = Path(path).read_text()
        self.assertIn("api/users", content)

    def test_inject_false_on_missing_file(self):
        from integrations.burp.report_injector import inject_burp_section
        result = inject_burp_section("/nonexistent/path/report.html", {})
        self.assertFalse(result)

    def test_inject_idempotent_css(self):
        from integrations.burp.report_injector import inject_burp_section
        with tempfile.NamedTemporaryFile(mode="w", suffix=".html",
                                         delete=False, encoding="utf-8") as f:
            f.write(self._minimal_html())
            path = f.name
        inject_burp_section(path, self._sample_burp_data())
        inject_burp_section(path, self._sample_burp_data())
        content = Path(path).read_text()
        # CSS class should appear only once (idempotent guard)
        self.assertEqual(content.count(".burp-section {"), 1)


# ══════════════════════════════════════════════════════════════════════════════
# 9. WebIntelligencePanel
# ══════════════════════════════════════════════════════════════════════════════

class TestWebIntelligencePanel(unittest.TestCase):

    def test_render_without_burp_layer_does_not_raise(self):
        from tui.views.web_intelligence_view import WebIntelligencePanel
        from rich.console import Console
        import io
        console = Console(file=io.StringIO(), width=120, highlight=False)
        panel = WebIntelligencePanel(burp_layer=None)
        panel.render(console, data={"api_reachable": False, "session_state": "none",
                                     "traffic": {}, "issues": {}, "site_map": {}})

    def test_render_with_full_data_does_not_raise(self):
        from tui.views.web_intelligence_view import WebIntelligencePanel, render_web_intelligence
        from rich.console import Console
        import io
        console = Console(file=io.StringIO(), width=140, highlight=False)
        data = {
            "api_reachable": True, "session_state": "active",
            "proxy_running": True, "proxy_url": "http://127.0.0.1:8080",
            "intercept_on": False, "proxy_error": "",
            "current_session": "abc12345",
            "current_project": "reconx_example_com_20250501",
            "burp_version": "2024.12.1",
            "issues": {"total": 3, "headers": 2, "sensitive": 1, "suggestions": 3},
            "site_map": {"url_count": 55},
            "traffic": {
                "total_requests": 88,
                "endpoints": [{"url": "https://example.com/api", "method": "GET",
                                "status": 200, "categories": ["api"]}],
                "auth_tokens": [{"type": "jwt", "value": "eyJ...", "url": "https://example.com"}],
                "cookies":     [{"name": "sid", "host": "example.com",
                                  "secure": True, "http_only": False, "same_site": "Lax"}],
                "security_issues": [{"type": "missing_header", "header": "csp",
                                      "detail": "Content-Security-Policy missing",
                                      "url": "https://example.com"}],
                "api_routes":    ["https://example.com/api/v1"],
                "login_pages":   ["https://example.com/login"],
                "admin_portals": [],
                "oauth_flows":   [],
                "sso_pages":     [],
                "graphql_endpoints": [],
                "spa_routes":    [],
                "upload_forms":  [],
            },
        }
        render_web_intelligence(console, data=data)


# ══════════════════════════════════════════════════════════════════════════════
# 10. CLI dispatcher
# ══════════════════════════════════════════════════════════════════════════════

class TestBurpCLI(unittest.TestCase):

    def _console(self):
        from rich.console import Console
        import io
        return Console(file=io.StringIO(), width=120)

    def test_status_command_no_crash(self):
        from cli.burp_commands import dispatch_burp_command
        dispatch_burp_command(["status"], self._console())

    def test_sessions_command_no_crash(self):
        from cli.burp_commands import dispatch_burp_command
        dispatch_burp_command(["sessions"], self._console())

    def test_start_missing_target_prints_usage(self):
        from cli.burp_commands import dispatch_burp_command
        import io
        buf = io.StringIO()
        from rich.console import Console
        console = Console(file=buf, width=120)
        dispatch_burp_command(["start"], console)
        output = buf.getvalue()
        self.assertIn("Usage", output)

    def test_unknown_command_prints_help(self):
        from cli.burp_commands import dispatch_burp_command
        import io
        buf = io.StringIO()
        from rich.console import Console
        console = Console(file=buf, width=120)
        dispatch_burp_command(["doesnotexist"], console)
        output = buf.getvalue()
        self.assertIn("burp", output.lower())

    def test_no_args_prints_help(self):
        from cli.burp_commands import dispatch_burp_command
        import io
        buf = io.StringIO()
        from rich.console import Console
        console = Console(file=buf, width=120)
        dispatch_burp_command([], console)
        output = buf.getvalue()
        self.assertIn("burp", output.lower())

    def test_replay_missing_session_id_prints_usage(self):
        from cli.burp_commands import dispatch_burp_command
        import io
        buf = io.StringIO()
        from rich.console import Console
        console = Console(file=buf, width=120)
        dispatch_burp_command(["replay"], console)
        output = buf.getvalue()
        self.assertIn("Usage", output)


# ══════════════════════════════════════════════════════════════════════════════
# 11. Registry — catalog metadata
# ══════════════════════════════════════════════════════════════════════════════

class TestRegistry181(unittest.TestCase):

    def test_catalog_returns_list(self):
        from tools.registry_181 import get_stage181_catalog
        cat = get_stage181_catalog()
        self.assertIsInstance(cat, list)
        self.assertEqual(len(cat), 1)

    def test_catalog_entry_has_required_fields(self):
        from tools.registry_181 import get_stage181_catalog
        entry = get_stage181_catalog()[0]
        for field in ("name", "class", "module", "category",
                       "stage", "passive", "description", "capabilities", "tags"):
            self.assertIn(field, entry, f"Missing field: {field}")

    def test_catalog_capabilities_is_list(self):
        from tools.registry_181 import get_stage181_catalog
        entry = get_stage181_catalog()[0]
        self.assertIsInstance(entry["capabilities"], list)
        self.assertGreater(len(entry["capabilities"]), 0)

    def test_catalog_tags_include_burp(self):
        from tools.registry_181 import get_stage181_catalog
        entry = get_stage181_catalog()[0]
        self.assertIn("burp", entry["tags"])

    def test_tool_chains_returns_list(self):
        from tools.registry_181 import get_stage181_tool_chains
        chains = get_stage181_tool_chains()
        self.assertIsInstance(chains, list)
        self.assertGreater(len(chains), 0)

    def test_tool_chains_have_steps(self):
        from tools.registry_181 import get_stage181_tool_chains
        for chain in get_stage181_tool_chains():
            self.assertIn("steps", chain)
            self.assertGreater(len(chain["steps"]), 0)

    def test_registry_load_graceful_without_reconx_package(self):
        from tools.registry_181 import get_stage181_registry
        registry = get_stage181_registry()
        self.assertIsInstance(registry, dict)
        # Either loaded or gracefully empty — both valid


# ══════════════════════════════════════════════════════════════════════════════
# 12. Integration smoke — BurpIntelligenceLayer (offline)
# ══════════════════════════════════════════════════════════════════════════════

class TestBurpIntelligenceLayerOffline(unittest.TestCase):

    def _make_layer(self):
        from integrations.burp import BurpIntelligenceLayer
        return BurpIntelligenceLayer()

    def test_get_status_returns_dict(self):
        layer = self._make_layer()
        status = layer.get_status()
        self.assertIsInstance(status, dict)
        self.assertIn("api_reachable", status)
        self.assertFalse(status["api_reachable"])   # Burp not running

    def test_get_proxy_config_returns_config(self):
        from integrations.burp.proxy_controller import ProxyConfig
        layer = self._make_layer()
        cfg   = layer.get_proxy_config()
        self.assertIsInstance(cfg, ProxyConfig)
        self.assertEqual(cfg.port, 8080)

    def test_run_returns_skipped_when_burp_unreachable(self):
        layer  = self._make_layer()
        result = layer.safe_run("example.com")
        # Either skipped or a valid result object (BaseTool contract)
        # The important thing is it doesn't raise
        self.assertIsNotNone(result)

    def test_list_sessions_returns_list(self):
        layer    = self._make_layer()
        sessions = layer.list_sessions()
        self.assertIsInstance(sessions, list)

    def test_stop_session_without_start_returns_error(self):
        layer    = self._make_layer()
        sess, err = layer.stop_session()
        self.assertIsNone(sess)
        self.assertNotEqual(err, "")


if __name__ == "__main__":
    unittest.main(verbosity=2)
