"""
ReconX Stage 12.2 — Integration smoke tests.

Covers:
  1. All new tool modules import and instantiate cleanly
  2. Required BaseTool attributes present
  3. parse_output("") never raises, always returns dict
  4. is_available() always returns bool
  5. Knowledge catalog loads, 12 entries, 4 new categories
  6. Guided workflow 12.2 has ≥24 steps and consistent dep graph
  7. Registry loads and merges with 12.1
  8. parse_output correctness for 7 new tools
  9. Pure-Python fallback logic for tools with API fallbacks
"""
from __future__ import annotations
import importlib
import sys
import types
import unittest
from unittest.mock import patch, MagicMock


# ── stub heavy deps so tests run without full install ─────────────────────────

def _stub(name: str) -> types.ModuleType:
    mod = types.ModuleType(name)
    sys.modules[name] = mod
    return mod

for _dep in ("scapy", "scapy.all", "rich", "rich.console", "rich.progress",
             "rich.table", "rich.panel", "rich.live", "rich.prompt",
             "rich.rule", "rich.text", "rich.markdown", "rich.columns"):
    if _dep not in sys.modules:
        _stub(_dep)

_rc = sys.modules.get("rich.console") or _stub("rich.console")
if not hasattr(_rc, "Console"):
    _rc.Console = MagicMock

_rp = sys.modules.get("rich.progress") or _stub("rich.progress")
for _cls in ("Progress", "SpinnerColumn", "BarColumn", "TaskProgressColumn",
             "TextColumn", "TimeElapsedColumn", "MofNCompleteColumn"):
    if not hasattr(_rp, _cls):
        setattr(_rp, _cls, MagicMock)


# ─────────────────────────────────────────────────────────────────────────────
# Tool import matrix
# ─────────────────────────────────────────────────────────────────────────────

NEW_TOOLS_122 = [
    ("tools.asset.github_subdomains", "GitHubSubdomainsTool"),
    ("tools.asset.asnmap",            "AsnmapTool"),
    ("tools.asset.mapcidr",           "MapCIDRTool"),
    ("tools.asset.alterx",            "AlterxTool"),
    ("tools.param.paramspider",       "ParamSpiderTool"),
    ("tools.param.gospider",          "GospiderTool"),
    ("tools.param.waymore",           "WaymoreTool"),
]

REQUIRED_ATTRS = ["NAME", "BINARY", "CATEGORY", "STAGE", "TIMEOUT", "INSTALL_CMD"]


def _import(module_path: str, class_name: str):
    try:
        mod = importlib.import_module(f"reconx.{module_path}")
    except ModuleNotFoundError:
        mod = importlib.import_module(module_path)
    return getattr(mod, class_name)()


# ─────────────────────────────────────────────────────────────────────────────
# 1. Imports & instantiation
# ─────────────────────────────────────────────────────────────────────────────

class TestStage122Imports(unittest.TestCase):

    def test_all_tools_import(self):
        for mp, cn in NEW_TOOLS_122:
            with self.subTest(tool=cn):
                inst = _import(mp, cn)
                self.assertIsNotNone(inst)

    def test_all_tools_have_name(self):
        for mp, cn in NEW_TOOLS_122:
            with self.subTest(tool=cn):
                inst = _import(mp, cn)
                self.assertIsInstance(inst.NAME, str)
                self.assertTrue(len(inst.NAME) > 0)

    def test_required_attributes(self):
        for mp, cn in NEW_TOOLS_122:
            with self.subTest(tool=cn):
                inst = _import(mp, cn)
                for attr in REQUIRED_ATTRS:
                    self.assertTrue(hasattr(inst, attr),
                                    f"{cn} missing: {attr}")

    def test_parse_output_empty_safe(self):
        for mp, cn in NEW_TOOLS_122:
            with self.subTest(tool=cn):
                inst = _import(mp, cn)
                result = inst.parse_output("")
                self.assertIsInstance(result, dict,
                                      f"{cn}.parse_output('') must return dict")

    def test_is_available_returns_bool(self):
        for mp, cn in NEW_TOOLS_122:
            with self.subTest(tool=cn):
                inst = _import(mp, cn)
                with patch("shutil.which", return_value=None):
                    result = inst.is_available()
                self.assertIsInstance(result, bool)

    def test_passive_attribute_is_bool(self):
        for mp, cn in NEW_TOOLS_122:
            with self.subTest(tool=cn):
                inst = _import(mp, cn)
                self.assertIsInstance(inst.PASSIVE, bool)

    def test_seven_new_tools_registered(self):
        self.assertEqual(len(NEW_TOOLS_122), 7)


# ─────────────────────────────────────────────────────────────────────────────
# 2. parse_output correctness
# ─────────────────────────────────────────────────────────────────────────────

class TestStage122ParseOutput(unittest.TestCase):

    def test_github_subdomains_parse(self):
        from tools.asset.github_subdomains import GitHubSubdomainsTool
        tool = GitHubSubdomainsTool()
        raw  = "api.example.com\ndev.example.com\nstg.example.com\n"
        data = tool.parse_output(raw, root="example.com")
        self.assertGreater(len(data["subdomains"]), 0)
        self.assertIn("api.example.com", data["subdomains"])

    def test_asnmap_json_parse(self):
        from tools.asset.asnmap import AsnmapTool
        tool = AsnmapTool()
        raw  = '{"asn":"AS12345","org":"Example Corp","cidr":"203.0.113.0/24"}\n'
        data = tool.parse_output(raw)
        self.assertIn("203.0.113.0/24", data["cidrs"])
        self.assertIn("AS12345", data["asns"])

    def test_asnmap_cidr_fallback_parse(self):
        from tools.asset.asnmap import AsnmapTool
        tool = AsnmapTool()
        raw  = "203.0.113.0/24\n198.51.100.0/22\n"
        data = tool.parse_output(raw)
        self.assertEqual(len(data["cidrs"]), 2)

    def test_mapcidr_parse_ips(self):
        from tools.asset.mapcidr import MapCIDRTool
        tool = MapCIDRTool()
        raw  = "192.0.2.1\n192.0.2.2\n192.0.2.3\n"
        data = tool.parse_output(raw, mode="expand")
        self.assertEqual(len(data["items"]), 3)

    def test_mapcidr_python_expand(self):
        from tools.asset.mapcidr import MapCIDRTool
        tool = MapCIDRTool()
        data, err = tool._python_process(
            ["192.0.2.0/30"], "expand", 0, 65536
        )
        self.assertFalse(err)
        # /30 has 2 host addresses
        self.assertEqual(len(data["items"]), 2)

    def test_mapcidr_bogon_filter(self):
        from tools.asset.mapcidr import MapCIDRTool
        tool = MapCIDRTool()
        self.assertTrue(tool._is_bogon("10.0.0.0/8"))
        self.assertTrue(tool._is_bogon("192.168.1.0/24"))
        self.assertFalse(tool._is_bogon("203.0.113.0/24"))

    def test_alterx_parse(self):
        from tools.asset.alterx import AlterxTool
        tool = AlterxTool()
        raw  = "dev.example.com\napi-dev.example.com\nstaging.example.com\n"
        data = tool.parse_output(raw, root="example.com")
        self.assertGreater(data["count"], 0)
        self.assertIn("dev.example.com", data["permutations"])

    def test_alterx_python_permute(self):
        from tools.asset.alterx import AlterxTool
        tool  = AlterxTool()
        seeds = ["api.example.com"]
        data  = tool._python_permute(seeds, "example.com", [], limit=100)
        self.assertGreater(data["count"], 0)
        # Should generate at least some permutations
        perms = data["permutations"]
        self.assertTrue(any("api" in p for p in perms))

    def test_alterx_valid_subdomain(self):
        from tools.asset.alterx import AlterxTool
        self.assertTrue(AlterxTool._valid_subdomain("dev-api.example.com"))
        self.assertFalse(AlterxTool._valid_subdomain("dev..example.com"))
        self.assertFalse(AlterxTool._valid_subdomain("-invalid.example.com"))

    def test_paramspider_fuzz_url_parse(self):
        from tools.param.paramspider import ParamSpiderTool
        tool = ParamSpiderTool()
        raw  = (
            "https://example.com/search?q=FUZZ&page=FUZZ\n"
            "https://example.com/api/users?id=FUZZ&format=FUZZ\n"
        )
        data = tool.parse_output(raw)
        self.assertIn("q", data["params"])
        self.assertIn("id", data["params"])
        self.assertEqual(len(data["urls"]), 2)

    def test_paramspider_empty(self):
        from tools.param.paramspider import ParamSpiderTool
        data = ParamSpiderTool().parse_output("")
        self.assertEqual(data["params"], [])
        self.assertEqual(data["urls"], [])

    def test_gospider_url_parse(self):
        from tools.param.gospider import GospiderTool
        tool = GospiderTool()
        raw  = (
            "[url] - [200] - https://example.com/path?q=1\n"
            "[javascript] - [200] - https://example.com/app.js\n"
            "[form] - https://example.com/login\n"
            "[linkfinder] - https://example.com/app.js - https://api.example.com/v1/users\n"
        )
        data = tool.parse_output(raw)
        self.assertTrue(len(data["urls"]) > 0)
        self.assertTrue(len(data["js_files"]) > 0)
        self.assertTrue(len(data["forms"]) > 0)
        self.assertIn("q", data["params"])

    def test_gospider_empty(self):
        from tools.param.gospider import GospiderTool
        data = GospiderTool().parse_output("")
        self.assertEqual(data["urls"], [])

    def test_waymore_url_parse(self):
        from tools.param.waymore import WaymoreTool
        tool = WaymoreTool()
        raw  = (
            "https://example.com/old-page?debug=1\n"
            "https://example.com/assets/app.js\n"
            "https://example.com/api/v1/users?id=123\n"
        )
        data = tool.parse_output(raw)
        self.assertEqual(data["count"], 3)
        self.assertIn("debug", data["params"])
        self.assertIn("id", data["params"])
        self.assertGreater(len(data["js_files"]), 0)

    def test_waymore_ext_categorisation(self):
        from tools.param.waymore import WaymoreTool
        tool = WaymoreTool()
        raw  = "https://example.com/file.php\nhttps://example.com/script.js\n"
        data = tool.parse_output(raw)
        self.assertIn("js", data.get("by_ext", {}))


# ─────────────────────────────────────────────────────────────────────────────
# 3. Knowledge catalog
# ─────────────────────────────────────────────────────────────────────────────

class TestStage122Catalog(unittest.TestCase):

    def _load(self):
        try:
            from reconx.knowledge.tools.s122.stage122_catalog import (
                STAGE122_TOOL_KNOWLEDGE, STAGE122_CATEGORIES,
                get_stage122_by_category, search_stage122,
            )
        except ModuleNotFoundError:
            from knowledge.tools.s122.stage122_catalog import (
                STAGE122_TOOL_KNOWLEDGE, STAGE122_CATEGORIES,
                get_stage122_by_category, search_stage122,
            )
        return STAGE122_TOOL_KNOWLEDGE, STAGE122_CATEGORIES, get_stage122_by_category, search_stage122

    def test_catalog_loads(self):
        catalog, *_ = self._load()
        self.assertGreater(len(catalog), 0)

    def test_12_entries(self):
        catalog, *_ = self._load()
        self.assertGreaterEqual(len(catalog), 12)

    def test_four_new_categories(self):
        _, cats, *_ = self._load()
        expected = {"Attack Surface", "Historical Recon", "URL Discovery", "Parameter Discovery"}
        self.assertEqual(set(cats), expected)

    def test_category_populated(self):
        _, _, get_by_cat, _ = self._load()
        for cat in ["Attack Surface", "Historical Recon", "URL Discovery", "Parameter Discovery"]:
            tools = get_by_cat(cat)
            self.assertGreater(len(tools), 0, f"No tools in category: {cat}")

    def test_search_works(self):
        _, _, _, search = self._load()
        results = search("asn")
        self.assertGreater(len(results), 0)

    def test_all_entries_have_example_commands(self):
        catalog, *_ = self._load()
        for t in catalog:
            self.assertTrue(len(t.example_commands) > 0,
                            f"{t.name} has no example_commands")

    def test_all_entries_have_install(self):
        catalog, *_ = self._load()
        for t in catalog:
            self.assertTrue(t.install, f"{t.name} has no install command")


# ─────────────────────────────────────────────────────────────────────────────
# 4. Guided workflow
# ─────────────────────────────────────────────────────────────────────────────

class TestStage122Workflow(unittest.TestCase):

    def _load(self):
        try:
            from reconx.workflow.guided_recon_122 import GUIDED_STEPS_122, STEP_MAP_122
        except ModuleNotFoundError:
            from workflow.guided_recon_122 import GUIDED_STEPS_122, STEP_MAP_122
        return GUIDED_STEPS_122, STEP_MAP_122

    def test_workflow_loads(self):
        steps, _ = self._load()
        self.assertGreater(len(steps), 0)

    def test_at_least_24_steps(self):
        steps, _ = self._load()
        self.assertGreaterEqual(len(steps), 24,
                                f"Expected ≥24 steps, got {len(steps)}")

    def test_unique_step_ids(self):
        steps, _ = self._load()
        ids = [s.id for s in steps]
        self.assertEqual(len(ids), len(set(ids)), "Duplicate step IDs in 12.2 workflow")

    def test_new_steps_present(self):
        _, step_map = self._load()
        for sid in ("github_recon", "asn_mapping", "cidr_expansion", "permutation",
                    "historical_urls", "active_crawl", "param_discovery"):
            self.assertIn(sid, step_map, f"Missing step: {sid}")

    def test_dependencies_reference_valid_ids(self):
        steps, step_map = self._load()
        for step in steps:
            for dep in step.requires:
                self.assertIn(dep, step_map,
                              f"Step '{step.id}' requires unknown step: '{dep}'")

    def test_param_discovery_requires_crawl(self):
        _, step_map = self._load()
        if "param_discovery" in step_map:
            reqs = step_map["param_discovery"].requires
            # Should depend on either historical_urls or active_crawl
            self.assertTrue(
                any(r in ("historical_urls", "active_crawl") for r in reqs),
                "param_discovery should require historical_urls or active_crawl"
            )

    def test_report_still_present(self):
        _, step_map = self._load()
        self.assertIn("report", step_map)

    def test_port_scan_still_not_skippable(self):
        _, step_map = self._load()
        if "port_scan" in step_map:
            self.assertFalse(step_map["port_scan"].skippable)


# ─────────────────────────────────────────────────────────────────────────────
# 5. Registry
# ─────────────────────────────────────────────────────────────────────────────

class TestStage122Registry(unittest.TestCase):

    def test_registry_loads(self):
        try:
            from reconx.tools.registry_122 import get_122_additions
        except ModuleNotFoundError:
            from tools.registry_122 import get_122_additions
        reg = get_122_additions()
        self.assertGreater(len(reg), 0)

    def test_new_tools_in_registry(self):
        try:
            from reconx.tools.registry_122 import get_122_additions
        except ModuleNotFoundError:
            from tools.registry_122 import get_122_additions
        reg = get_122_additions()
        expected = ["GitHubSubdomainsTool", "AsnmapTool", "MapCIDRTool",
                    "AlterxTool", "ParamSpiderTool", "GospiderTool", "WaymoreTool"]
        for name in expected:
            self.assertIn(name, reg, f"Missing from registry: {name}")

    def test_no_registry_crash_on_missing_dep(self):
        """Registry must never raise even if tools can't import."""
        try:
            from reconx.tools.registry_122 import get_122_additions, _NullTool
        except ModuleNotFoundError:
            from tools.registry_122 import get_122_additions, _NullTool

        # Even if something breaks, the registry returns a dict
        reg = get_122_additions()
        self.assertIsInstance(reg, dict)
        for tool in reg.values():
            # Every tool (real or null) must have .run() and .is_available()
            self.assertTrue(hasattr(tool, "run"))
            self.assertTrue(hasattr(tool, "is_available"))


# ─────────────────────────────────────────────────────────────────────────────
# Runner
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import os
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    unittest.main(verbosity=2)
