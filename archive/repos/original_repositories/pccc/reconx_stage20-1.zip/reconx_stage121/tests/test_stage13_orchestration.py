"""
ReconX Stage 13 — Integration tests for the orchestration layer.

Test classes:
  1. ToolRegistry   — auto-discovery, filtering, searching
  2. TargetClassifier — all 12 target types
  3. ChainRunner     — chain execution with mock tools
  4. PipelineEngine  — parallel execution, retries, failure isolation
  5. RecommendationEngine — workflow generation per type + mode
  6. ToolHealthMonitor — record, probe, dashboard
  7. OperationsCenter — renders without crashing (headless)
  8. ReconXEngine    — dry_run end-to-end flow
"""
from __future__ import annotations

import sys
import types
import unittest
from dataclasses import dataclass, field
from typing import Optional
from unittest.mock import MagicMock, patch


# ── stub deps ────────────────────────────────────────────────────────────────

def _stub(name: str) -> types.ModuleType:
    mod = types.ModuleType(name)
    sys.modules[name] = mod
    return mod

for _dep in ("scapy", "scapy.all", "rich", "rich.console", "rich.progress",
             "rich.table", "rich.panel", "rich.live", "rich.prompt",
             "rich.rule", "rich.text", "rich.markdown", "rich.columns",
             "rich.layout", "rich.columns"):
    if _dep not in sys.modules:
        _stub(_dep)

for cls_name in ("Console", "Group"):
    mod = sys.modules.get("rich.console") or _stub("rich.console")
    if not hasattr(mod, cls_name):
        setattr(mod, cls_name, MagicMock)

for cls_name in ("Progress", "SpinnerColumn", "BarColumn", "TaskProgressColumn",
                 "TextColumn", "TimeElapsedColumn", "MofNCompleteColumn"):
    mod = sys.modules.get("rich.progress") or _stub("rich.progress")
    if not hasattr(mod, cls_name):
        setattr(mod, cls_name, MagicMock)

for rich_mod in ("rich.table", "rich.panel", "rich.live", "rich.layout",
                 "rich.columns"):
    mod = sys.modules.get(rich_mod) or _stub(rich_mod)
    for attr in ("Table", "Panel", "Live", "Layout", "Columns"):
        if not hasattr(mod, attr):
            setattr(mod, attr, MagicMock)


# ─────────────────────────────────────────────────────────────────────────────
# Minimal BaseTool stub for registry/chain tests
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class _FakeFinding:
    finding_type: str
    value:        str
    source:       str  = "test"
    confidence:   float = 1.0
    metadata:     dict  = field(default_factory=dict)

@dataclass
class _FakeResult:
    status:   str        = "success"
    findings: list       = field(default_factory=list)
    error:    object     = None

class _FakeTool:
    NAME         = "FakeTool"
    BINARY       = "faketool"
    CATEGORY     = "test"
    STAGE        = 2
    PRIORITY     = 50
    PASSIVE      = False
    TIMEOUT      = 10
    INSTALL_CMD  = "echo fake"
    DEPENDENCIES: list = []

    def is_available(self) -> bool:
        return True

    def run(self, target: str, **kwargs) -> _FakeResult:
        return _FakeResult(
            findings=[_FakeFinding("subdomain", f"sub1.{target}"),
                      _FakeFinding("subdomain", f"sub2.{target}")]
        )

    def safe_run(self, target: str, **kwargs) -> _FakeResult:
        return self.run(target, **kwargs)


class _FailingTool(_FakeTool):
    NAME   = "FailingTool"
    BINARY = "failingtool"

    def run(self, target, **kwargs):
        return _FakeResult(status="failed",
                           error=MagicMock(message="Simulated failure"))

    def safe_run(self, target, **kwargs):
        return self.run(target, **kwargs)


# ─────────────────────────────────────────────────────────────────────────────
# Minimal ToolMeta / ToolRegistry stubs
# ─────────────────────────────────────────────────────────────────────────────

class _StubRegistry:
    """Minimal registry backed by a dict of {class_name: ToolMeta-like}."""
    def __init__(self, tools: dict):
        self._tools = tools

    def get(self, class_name):
        return self._tools.get(class_name)

    def all(self):
        return list(self._tools.values())

    def by_category(self, cat):
        return [t for t in self._tools.values()
                if getattr(t, "category", "") == cat]

    def filter(self, **kwargs):
        return list(self._tools.values())

    def search(self, q):
        return [t for t in self._tools.values()
                if q.lower() in t.class_name.lower()]

    def categories(self):
        return sorted({t.category for t in self._tools.values()})


def _make_meta(tool_instance, cls_name=None):
    cn = cls_name or tool_instance.NAME + "Tool"
    class Meta:
        class_name  = cn
        name        = tool_instance.NAME
        binary      = tool_instance.BINARY
        category    = tool_instance.CATEGORY
        stage       = tool_instance.STAGE
        passive     = tool_instance.PASSIVE
        priority    = tool_instance.PRIORITY
        timeout     = tool_instance.TIMEOUT
        install_cmd = tool_instance.INSTALL_CMD
        dependencies: list = []
        tags: list = []
        supported_inputs = ["domain"]
        description = ""
        available   = True
        instance    = tool_instance

        @property
        def is_available(self):
            return True

    return Meta()


# ─────────────────────────────────────────────────────────────────────────────
# 1. TargetClassifier
# ─────────────────────────────────────────────────────────────────────────────

class TestTargetClassifier(unittest.TestCase):

    def _cls(self, raw):
        try:
            from reconx.analysis.target_classifier import TargetClassifier
        except ModuleNotFoundError:
            from analysis.target_classifier import TargetClassifier
        return TargetClassifier.classify(raw)

    def test_ipv4(self):
        ct = self._cls("1.2.3.4")
        self.assertEqual(ct.target_type, "ip")
        self.assertTrue(ct.is_valid)

    def test_private_ip(self):
        ct = self._cls("192.168.1.100")
        self.assertEqual(ct.target_type, "ip")
        self.assertTrue(ct.metadata.get("private"))

    def test_cidr(self):
        ct = self._cls("10.0.0.0/16")
        self.assertEqual(ct.target_type, "cidr")
        self.assertEqual(ct.metadata["prefix_len"], 16)

    def test_asn(self):
        ct = self._cls("AS13335")
        self.assertEqual(ct.target_type, "asn")
        self.assertEqual(ct.normalized, "AS13335")

    def test_asn_lowercase(self):
        ct = self._cls("as1234")
        self.assertEqual(ct.target_type, "asn")

    def test_email(self):
        ct = self._cls("user@example.com")
        self.assertEqual(ct.target_type, "email")
        self.assertEqual(ct.metadata["domain"], "example.com")

    def test_github_repo(self):
        ct = self._cls("https://github.com/org/repo")
        self.assertEqual(ct.target_type, "github_repo")
        self.assertEqual(ct.metadata["org"], "org")
        self.assertEqual(ct.metadata["repo"], "repo")

    def test_github_org(self):
        ct = self._cls("https://github.com/targetorg")
        self.assertEqual(ct.target_type, "github_org")

    def test_url(self):
        ct = self._cls("https://example.com/api")
        self.assertEqual(ct.target_type, "url")
        self.assertEqual(ct.metadata["scheme"], "https")

    def test_cloud_bucket(self):
        ct = self._cls("company-backup.s3.amazonaws.com")
        self.assertEqual(ct.target_type, "cloud_bucket")
        self.assertEqual(ct.metadata["provider"], "AWS S3")

    def test_domain(self):
        ct = self._cls("example.com")
        self.assertEqual(ct.target_type, "domain")
        self.assertIn("asset_discovery", ct.recommended_workflows)

    def test_subdomain_heuristic(self):
        ct = self._cls("api.example.com")
        self.assertIn(ct.target_type, ("subdomain", "domain"))

    def test_batch(self):
        try:
            from reconx.analysis.target_classifier import TargetClassifier
        except ModuleNotFoundError:
            from analysis.target_classifier import TargetClassifier
        targets = ["1.1.1.1", "example.com", "AS13335", "user@x.com"]
        results = TargetClassifier.classify_batch(targets)
        self.assertEqual(len(results), 4)
        types = [r.target_type for r in results]
        self.assertIn("ip", types)
        self.assertIn("domain", types)
        self.assertIn("asn", types)
        self.assertIn("email", types)

    def test_is_passive_friendly(self):
        ct = self._cls("example.com")
        self.assertTrue(ct.is_passive_friendly)
        ct2 = self._cls("10.0.0.0/8")
        self.assertFalse(ct2.is_passive_friendly)


# ─────────────────────────────────────────────────────────────────────────────
# 2. Tool chains
# ─────────────────────────────────────────────────────────────────────────────

class TestChainRunner(unittest.TestCase):

    def _runner(self):
        try:
            from reconx.orchestration.tool_chains import ChainRunner, ChainStep
        except ModuleNotFoundError:
            from orchestration.tool_chains import ChainRunner, ChainStep
        ft  = _FakeTool()
        ft2 = _FailingTool()
        reg = _StubRegistry({
            "FakeTool":    _make_meta(ft, "FakeTool"),
            "FailingTool": _make_meta(ft2, "FailingTool"),
        })
        return ChainRunner(reg), ChainStep

    def test_basic_chain_runs(self):
        runner, CS = self._runner()
        chain = [CS("FakeTool", description="test")]
        outcomes, ctx = runner.run("example.com", chain)
        self.assertEqual(len(outcomes), 1)
        self.assertEqual(outcomes[0].status, "success")

    def test_findings_propagated_to_context(self):
        runner, CS = self._runner()
        chain = [CS("FakeTool")]
        _, ctx = runner.run("example.com", chain)
        self.assertIn("subdomain", ctx)
        self.assertGreater(len(ctx["subdomain"]), 0)

    def test_failed_step_does_not_halt_chain(self):
        runner, CS = self._runner()
        chain = [CS("FailingTool"), CS("FakeTool")]
        outcomes, _ = runner.run("example.com", chain)
        self.assertEqual(len(outcomes), 2)
        statuses = {o.tool_name: o.status for o in outcomes}
        self.assertEqual(statuses["FailingTool"], "failed")
        self.assertEqual(statuses["FakeTool"], "success")

    def test_missing_tool_is_skipped(self):
        runner, CS = self._runner()
        chain = [CS("NonExistentTool")]
        outcomes, _ = runner.run("example.com", chain)
        self.assertEqual(outcomes[0].status, "missing")

    def test_conditional_step_skipped(self):
        runner, CS = self._runner()
        chain = [CS("FakeTool", condition_fn=lambda ctx: False)]
        outcomes, _ = runner.run("example.com", chain)
        self.assertEqual(outcomes[0].status, "conditional_skip")

    def test_builtin_chains_importable(self):
        try:
            from reconx.orchestration.tool_chains import BUILTIN_CHAINS
        except ModuleNotFoundError:
            from orchestration.tool_chains import BUILTIN_CHAINS
        self.assertIn("asset_discovery", BUILTIN_CHAINS)
        self.assertIn("full_recon", BUILTIN_CHAINS)
        self.assertGreater(len(BUILTIN_CHAINS), 5)


# ─────────────────────────────────────────────────────────────────────────────
# 3. Pipeline engine
# ─────────────────────────────────────────────────────────────────────────────

class TestPipelineEngine(unittest.TestCase):

    def _engine(self):
        try:
            from reconx.orchestration.pipeline_engine import PipelineEngine, PipelineTask, TaskStatus
        except ModuleNotFoundError:
            from orchestration.pipeline_engine import PipelineEngine, PipelineTask, TaskStatus

        ft  = _FakeTool()
        ft2 = _FailingTool()
        reg = _StubRegistry({
            "FakeTool":    _make_meta(ft, "FakeTool"),
            "FailingTool": _make_meta(ft2, "FailingTool"),
        })
        return PipelineEngine(reg, max_workers=2), PipelineTask, TaskStatus

    def test_execute_success(self):
        engine, PT, TS = self._engine()
        tasks = [PT(tool_class="FakeTool", target="example.com", stage=2)]
        result = engine.execute(tasks, "example.com")
        self.assertEqual(result.success_count, 1)
        self.assertGreater(result.total_findings, 0)

    def test_failed_task_isolated(self):
        engine, PT, TS = self._engine()
        tasks = [
            PT(tool_class="FailingTool", target="example.com", stage=2),
            PT(tool_class="FakeTool",    target="example.com", stage=2),
        ]
        result = engine.execute(tasks, "example.com")
        self.assertEqual(result.success_count, 1)
        self.assertEqual(result.failed_count, 1)
        # Pipeline must not crash
        self.assertIsNotNone(result)

    def test_missing_tool_marked_missing(self):
        engine, PT, TS = self._engine()
        tasks = [PT(tool_class="GhostTool", target="example.com", stage=2)]
        result = engine.execute(tasks, "example.com")
        self.assertEqual(result.skipped_count, 1)

    def test_findings_in_result(self):
        engine, PT, TS = self._engine()
        tasks = [PT(tool_class="FakeTool", target="example.com", stage=2)]
        result = engine.execute(tasks, "example.com")
        self.assertGreater(len(result.all_findings), 0)


# ─────────────────────────────────────────────────────────────────────────────
# 4. Recommendation engine
# ─────────────────────────────────────────────────────────────────────────────

class TestRecommendationEngine(unittest.TestCase):

    def _engine(self):
        try:
            from reconx.workflow.recommendation_engine import RecommendationEngine, ScanMode
            from reconx.analysis.target_classifier import TargetClassifier
        except ModuleNotFoundError:
            from workflow.recommendation_engine import RecommendationEngine, ScanMode
            from analysis.target_classifier import TargetClassifier
        return RecommendationEngine(registry=None), ScanMode, TargetClassifier

    def test_domain_balanced(self):
        eng, SM, TC = self._engine()
        ct  = TC.classify("example.com")
        rec = eng.recommend(ct, SM.BALANCED, filter_unavailable=False)
        self.assertGreater(len(rec.tool_list), 5)
        self.assertIn("WhoisTool", rec.tool_list)
        self.assertEqual(rec.target_type, "domain")

    def test_ip_fast(self):
        eng, SM, TC = self._engine()
        ct  = TC.classify("1.2.3.4")
        rec = eng.recommend(ct, SM.FAST, filter_unavailable=False)
        self.assertIn("NmapTool", rec.tool_list)

    def test_passive_no_active_tools(self):
        eng, SM, TC = self._engine()
        ct  = TC.classify("example.com")
        rec = eng.recommend(ct, SM.PASSIVE, filter_unavailable=False)
        # Active-only tools should not appear
        self.assertNotIn("NmapTool", rec.tool_list)
        self.assertNotIn("FeroxbusterTool", rec.tool_list)

    def test_email_identity_tools(self):
        eng, SM, TC = self._engine()
        ct  = TC.classify("user@example.com")
        rec = eng.recommend(ct, SM.BALANCED, filter_unavailable=False)
        self.assertIn("SherlockTool", rec.tool_list)

    def test_custom_mode(self):
        eng, SM, TC = self._engine()
        ct  = TC.classify("example.com")
        rec = eng.recommend(ct, SM.CUSTOM,
                            custom_tools=["NmapTool", "HttpxTool"],
                            filter_unavailable=False)
        self.assertEqual(rec.tool_list, ["NmapTool", "HttpxTool"])

    def test_deep_more_tools_than_fast(self):
        eng, SM, TC = self._engine()
        ct   = TC.classify("example.com")
        fast = eng.recommend(ct, SM.FAST,  filter_unavailable=False)
        deep = eng.recommend(ct, SM.DEEP,  filter_unavailable=False)
        self.assertGreater(len(deep.tool_list), len(fast.tool_list))

    def test_estimated_time_positive(self):
        eng, SM, TC = self._engine()
        ct  = TC.classify("example.com")
        rec = eng.recommend(ct, SM.BALANCED, filter_unavailable=False)
        self.assertGreater(rec.estimated_min, 0)

    def test_summary_string(self):
        eng, SM, TC = self._engine()
        ct  = TC.classify("example.com")
        rec = eng.recommend(ct, SM.FAST, filter_unavailable=False)
        summary = rec.summary()
        self.assertIn("Mode", summary)
        self.assertIn("Tools", summary)

    def test_from_string(self):
        eng, SM, TC = self._engine()
        rec = eng.recommend_from_string("example.com", SM.FAST,
                                        filter_unavailable=False)
        self.assertGreater(len(rec.tool_list), 0)

    def test_cidr_network_tools(self):
        eng, SM, TC = self._engine()
        ct  = TC.classify("192.168.0.0/24")
        rec = eng.recommend(ct, SM.BALANCED, filter_unavailable=False)
        self.assertIn("AsnmapTool", rec.tool_list)


# ─────────────────────────────────────────────────────────────────────────────
# 5. Tool health monitor
# ─────────────────────────────────────────────────────────────────────────────

class TestToolHealthMonitor(unittest.TestCase):

    def _monitor(self):
        try:
            from reconx.telemetry.tool_health import ToolHealthMonitor, ToolHealthRecord
        except ModuleNotFoundError:
            from telemetry.tool_health import ToolHealthMonitor, ToolHealthRecord
        return ToolHealthMonitor(), ToolHealthRecord

    def test_record_run_updates_counters(self):
        monitor, _ = self._monitor()
        from telemetry.tool_health import ToolHealthRecord
        rec = ToolHealthRecord(class_name="NmapTool", binary="nmap", category="network")
        monitor._records["NmapTool"] = rec
        monitor.record_run("NmapTool", duration_s=12.3, failed=False)
        monitor.record_run("NmapTool", duration_s=5.0,  failed=True, error="timeout")
        self.assertEqual(rec.total_runs, 2)
        self.assertEqual(rec.failed_runs, 1)
        self.assertAlmostEqual(rec.avg_runtime_s, 8.65, places=1)

    def test_failure_rate(self):
        _, THR = self._monitor()
        rec = THR(class_name="T", binary="t", category="c", total_runs=4, failed_runs=2)
        self.assertAlmostEqual(rec.failure_rate, 0.5)

    def test_status_label_ok(self):
        _, THR = self._monitor()
        rec = THR(class_name="T", binary="t", category="c", available=True)
        self.assertEqual(rec.status_label, "OK")

    def test_status_label_missing(self):
        _, THR = self._monitor()
        rec = THR(class_name="T", binary="t", category="c", available=False)
        self.assertEqual(rec.status_label, "MISSING")

    def test_dashboard_text_runs(self):
        monitor, THR = self._monitor()
        monitor._records["NmapTool"] = THR(
            class_name="NmapTool", binary="nmap", category="network",
            available=True, version="7.93", total_runs=10, failed_runs=1,
        )
        dash = monitor.dashboard_text()
        self.assertIn("NmapTool", dash)
        self.assertIn("OK", dash)

    def test_install_guide_missing(self):
        monitor, THR = self._monitor()
        monitor._records["GhostTool"] = THR(
            class_name="GhostTool", binary="ghost", category="test",
            available=False, install_cmd="pip install ghost",
        )
        guide = monitor.install_guide()
        self.assertIn("pip install ghost", guide)


# ─────────────────────────────────────────────────────────────────────────────
# 6. ReconXEngine dry run
# ─────────────────────────────────────────────────────────────────────────────

class TestReconXEngine(unittest.TestCase):

    def test_dry_run_domain(self):
        try:
            from reconx.orchestration.reconx_engine import ReconXEngine
        except ModuleNotFoundError:
            from orchestration.reconx_engine import ReconXEngine

        engine = ReconXEngine()
        result = engine.run("example.com", mode="fast", live_tui=False,
                            save_report=False, dry_run=True)
        self.assertEqual(result.target, "example.com")
        self.assertEqual(result.target_type, "domain")
        self.assertGreater(len(result.workflow), 0)

    def test_dry_run_ip(self):
        try:
            from reconx.orchestration.reconx_engine import ReconXEngine
        except ModuleNotFoundError:
            from orchestration.reconx_engine import ReconXEngine

        result = ReconXEngine().run("1.2.3.4", mode="fast", live_tui=False,
                                   save_report=False, dry_run=True)
        self.assertEqual(result.target_type, "ip")

    def test_dry_run_cidr(self):
        try:
            from reconx.orchestration.reconx_engine import ReconXEngine
        except ModuleNotFoundError:
            from orchestration.reconx_engine import ReconXEngine

        result = ReconXEngine().run("192.0.2.0/24", mode="fast", live_tui=False,
                                   save_report=False, dry_run=True)
        self.assertEqual(result.target_type, "cidr")


if __name__ == "__main__":
    import os
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    unittest.main(verbosity=2)
