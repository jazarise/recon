"""
ReconX — Stage 19 Test Suite: Plugin SDK Foundation

Tests: 85 across 9 classes. All offline — no binaries required.
Covers:
  1. SDK contracts (ToolMetadata, CapabilitySet, PluginPermissions)
  2. SDK base_tool (PluginBaseTool metaclass sync, healthcheck)
  3. SDK metadata helpers (builder, CAPABILITIES, COMMON_CAPS)
  4. Core capability engine (register, search, map)
  5. Core registry (register, query, legacy wrap)
  6. Core plugin loader (discovery, import, error handling)
  7. Core plugin manager (bootstrap, list, search, stats)
  8. Plugin files (Nmap, Amass, Subfinder, HTTPX, Whois, DNS metadata)
  9. CLI tools commands (dispatch, help, no crash)
"""
from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import MagicMock, patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


# ══════════════════════════════════════════════════════════════════════════════
# 1. SDK Contracts
# ══════════════════════════════════════════════════════════════════════════════

class TestContracts(unittest.TestCase):

    def test_tool_metadata_defaults(self):
        from sdk.contracts import ToolMetadata
        m = ToolMetadata(name="TestTool", description="A test tool", category="test")
        self.assertEqual(m.name, "TestTool")
        self.assertEqual(m.version, "1.0.0")
        self.assertEqual(m.stage, 3)
        self.assertTrue(m.default_timeout > 0)

    def test_tool_metadata_validate_ok(self):
        from sdk.contracts import ToolMetadata
        m = ToolMetadata(name="TestTool", description="desc", category="test", stage=2)
        self.assertEqual(m.validate(), [])

    def test_tool_metadata_validate_missing_name(self):
        from sdk.contracts import ToolMetadata
        m = ToolMetadata(name="", description="desc", category="test")
        errors = m.validate()
        self.assertTrue(any("name" in e for e in errors))

    def test_tool_metadata_validate_bad_stage(self):
        from sdk.contracts import ToolMetadata
        m = ToolMetadata(name="x", description="d", category="c", stage=9)
        errors = m.validate()
        self.assertTrue(any("stage" in e for e in errors))

    def test_tool_metadata_to_dict_serialisable(self):
        import json
        from sdk.contracts import ToolMetadata
        m = ToolMetadata(name="T", description="D", category="c")
        d = m.to_dict()
        json.dumps(d)  # must not raise
        self.assertIn("name", d)
        self.assertIn("capabilities", d)

    def test_capability_set_add_and_has(self):
        from sdk.contracts import CapabilitySet
        cs = CapabilitySet()
        cs.add("port_scan", "Scan ports")
        self.assertTrue(cs.has("port_scan"))
        self.assertFalse(cs.has("nonexistent"))
        self.assertEqual(len(cs), 1)

    def test_capability_set_slugs(self):
        from sdk.contracts import CapabilitySet
        cs = CapabilitySet().add("a").add("b").add("c")
        self.assertEqual(sorted(cs.slugs()), ["a", "b", "c"])

    def test_capability_set_iter(self):
        from sdk.contracts import CapabilitySet
        cs = CapabilitySet().add("x").add("y")
        slugs = [str(c) for c in cs]
        self.assertIn("x", slugs)

    def test_capability_equality(self):
        from sdk.contracts import Capability
        c = Capability("port_scan")
        self.assertEqual(c, "port_scan")
        self.assertNotEqual(c, "other")

    def test_plugin_permissions_summary(self):
        from sdk.contracts import PluginPermissions
        p = PluginPermissions(requires_root=True, requires_network=True)
        s = p.summary()
        self.assertIn("root", s)
        self.assertIn("network", s)

    def test_risk_level_values(self):
        from sdk.contracts import RiskLevel
        self.assertEqual(RiskLevel.PASSIVE.value, "passive")
        self.assertEqual(RiskLevel.HIGH.value, "high")

    def test_install_method_values(self):
        from sdk.contracts import InstallMethod
        self.assertEqual(InstallMethod.APT.value, "apt")
        self.assertEqual(InstallMethod.GO.value, "go install")


# ══════════════════════════════════════════════════════════════════════════════
# 2. SDK BaseTool (PluginBaseTool)
# ══════════════════════════════════════════════════════════════════════════════

class TestPluginBaseTool(unittest.TestCase):

    def _make_plugin(self, binary="", name="TestPlugin"):
        from sdk.contracts import ToolMetadata, CapabilitySet, RiskLevel
        from sdk.base_tool import PluginBaseTool

        class ConcretePlugin(PluginBaseTool):
            METADATA = ToolMetadata(
                name=name,
                description="Test plugin",
                category="test",
                binary=binary,
            )
            def run(self, target, **kwargs):
                return self.build_result(data={"ok": True}, findings=[])
            def parse_output(self, raw, **kwargs):
                return {}

        return ConcretePlugin()

    def test_metadata_method_returns_metadata(self):
        p = self._make_plugin()
        from sdk.contracts import ToolMetadata
        self.assertIsInstance(p.metadata(), ToolMetadata)

    def test_capabilities_method_returns_capset(self):
        p = self._make_plugin()
        from sdk.contracts import CapabilitySet
        self.assertIsInstance(p.capabilities(), CapabilitySet)

    def test_permissions_method_returns_permissions(self):
        p = self._make_plugin()
        from sdk.contracts import PluginPermissions
        self.assertIsInstance(p.permissions(), PluginPermissions)

    def test_name_method(self):
        p = self._make_plugin(name="MyTool")
        self.assertEqual(p.name(), "MyTool")

    def test_description_method(self):
        p = self._make_plugin()
        self.assertIsInstance(p.description(), str)

    def test_category_method(self):
        p = self._make_plugin()
        self.assertEqual(p.category(), "test")

    def test_check_returns_bool(self):
        p = self._make_plugin()
        self.assertIsInstance(p.check(), bool)

    def test_healthcheck_no_binary(self):
        p = self._make_plugin(binary="")
        h = p.healthcheck()
        self.assertTrue(h.available)
        self.assertEqual(h.version, "python")

    def test_healthcheck_missing_binary(self):
        p = self._make_plugin(binary="/nonexistent/tool_xyz123")
        h = p.healthcheck()
        self.assertFalse(h.available)
        self.assertIn("PATH", h.error)

    def test_legacy_constants_auto_synced(self):
        """NAME, BINARY, CATEGORY are auto-populated from METADATA."""
        from sdk.contracts import ToolMetadata
        from sdk.base_tool import PluginBaseTool

        class AutoSync(PluginBaseTool):
            METADATA = ToolMetadata(name="AutoSync", description="d",
                                    category="auto", stage=2, binary="autosync")
            def run(self, t, **kw): return {}
            def parse_output(self, r, **kw): return {}

        self.assertEqual(AutoSync.NAME, "AutoSync")
        self.assertEqual(AutoSync.BINARY, "autosync")
        self.assertEqual(AutoSync.CATEGORY, "auto")
        self.assertEqual(AutoSync.STAGE, 2)

    def test_install_no_cmd_returns_false(self):
        p = self._make_plugin()
        self.assertFalse(p.install())


# ══════════════════════════════════════════════════════════════════════════════
# 3. SDK Metadata helpers
# ══════════════════════════════════════════════════════════════════════════════

class TestMetadataHelpers(unittest.TestCase):

    def test_capabilities_constants_exist(self):
        from sdk.metadata import CAPABILITIES
        self.assertEqual(CAPABILITIES.PORT_SCAN, "port_scan")
        self.assertEqual(CAPABILITIES.SUBDOMAIN_ENUM, "subdomain_enumeration")
        self.assertEqual(CAPABILITIES.HTTP_PROBE, "http_probe")

    def test_common_caps_port_scanner(self):
        from sdk.metadata import COMMON_CAPS, CAPABILITIES
        cs = COMMON_CAPS.port_scanner()
        self.assertTrue(cs.has(CAPABILITIES.PORT_SCAN))
        self.assertTrue(cs.has(CAPABILITIES.SERVICE_DETECTION))

    def test_common_caps_subdomain(self):
        from sdk.metadata import COMMON_CAPS, CAPABILITIES
        cs = COMMON_CAPS.subdomain_enumerator()
        self.assertTrue(cs.has(CAPABILITIES.SUBDOMAIN_ENUM))

    def test_builder_builds_valid(self):
        from sdk.metadata import ToolMetadataBuilder, CAPABILITIES, COMMON_CAPS
        from sdk.contracts import InstallMethod, RiskLevel
        meta = (ToolMetadataBuilder("TestB", "A builder test tool")
                .category("network")
                .binary("testb")
                .stage(3)
                .priority(20)
                .risk(RiskLevel.LOW)
                .passive(False)
                .capabilities(COMMON_CAPS.port_scanner())
                .install(InstallMethod.APT, "sudo apt install testb")
                .tags("test", "network")
                .example("testb -h")
                .timeout(45)
                .build())
        self.assertEqual(meta.name, "TestB")
        self.assertEqual(meta.stage, 3)
        self.assertEqual(meta.binary, "testb")
        self.assertTrue(meta.capabilities.has("port_scan"))

    def test_builder_raises_on_invalid(self):
        from sdk.metadata import ToolMetadataBuilder
        builder = ToolMetadataBuilder("", "no name")
        with self.assertRaises(ValueError):
            builder.build()

    def test_make_metadata_factory(self):
        from sdk.metadata import make_metadata
        m = make_metadata("QuickTool", "Quick factory test", stage=2, binary="qt")
        self.assertEqual(m.name, "QuickTool")
        self.assertEqual(m.stage, 2)
        self.assertEqual(m.binary, "qt")


# ══════════════════════════════════════════════════════════════════════════════
# 4. Capability Engine
# ══════════════════════════════════════════════════════════════════════════════

class TestCapabilityEngine(unittest.TestCase):

    def _engine(self):
        from core.capability_map import CapabilityEngine
        return CapabilityEngine()

    def _make_tool(self, name, caps):
        from sdk.contracts import ToolMetadata, CapabilitySet
        from sdk.base_tool import PluginBaseTool

        cap_set = CapabilitySet()
        for c in caps:
            cap_set.add(c)

        class T(PluginBaseTool):
            METADATA = ToolMetadata(name=name, description="d", category="t",
                                    capabilities=cap_set)
            def run(self, t, **kw): return {}
            def parse_output(self, r, **kw): return {}

        return T()

    def test_register_and_find(self):
        e    = self._engine()
        tool = self._make_tool("Alpha", ["port_scan", "os_detection"])
        e.register(tool)
        self.assertIn("Alpha", e.tools_for("port_scan"))
        self.assertIn("Alpha", e.tools_for("os_detection"))

    def test_tools_for_all(self):
        e = self._engine()
        e.register(self._make_tool("ToolA", ["port_scan", "os_detection"]))
        e.register(self._make_tool("ToolB", ["port_scan"]))
        result = e.tools_for_all(["port_scan", "os_detection"])
        self.assertIn("ToolA", result)
        self.assertNotIn("ToolB", result)

    def test_tools_for_any(self):
        e = self._engine()
        e.register(self._make_tool("X", ["a"]))
        e.register(self._make_tool("Y", ["b"]))
        result = e.tools_for_any(["a", "b"])
        self.assertIn("X", result)
        self.assertIn("Y", result)

    def test_unknown_capability_empty(self):
        e = self._engine()
        self.assertEqual(e.tools_for("nonexistent_cap"), [])

    def test_all_capabilities_sorted(self):
        e = self._engine()
        e.register(self._make_tool("T", ["b_cap", "a_cap"]))
        caps = e.all_capabilities()
        self.assertEqual(caps, sorted(caps))

    def test_capability_map_structure(self):
        e    = self._engine()
        tool = self._make_tool("MapTool", ["cap1", "cap2"])
        e.register(tool)
        cmap = e.capability_map()
        self.assertIn("cap1", cmap)
        self.assertIn("MapTool", cmap["cap1"])

    def test_summary_returns_dict(self):
        e = self._engine()
        s = e.summary()
        self.assertIn("total_tools", s)
        self.assertIn("total_capabilities", s)

    def test_register_from_metadata(self):
        from sdk.contracts import CapabilitySet
        e  = self._engine()
        cs = CapabilitySet().add("meta_cap")
        e.register_from_metadata("MetaTool", cs)
        self.assertIn("MetaTool", e.tools_for("meta_cap"))


# ══════════════════════════════════════════════════════════════════════════════
# 5. Core Registry
# ══════════════════════════════════════════════════════════════════════════════

class TestPluginRegistry(unittest.TestCase):

    def _registry(self):
        from core.registry import PluginRegistry
        return PluginRegistry()

    def _make_instance(self, name="RegTool", cat="test", stage=3):
        from sdk.contracts import ToolMetadata
        from sdk.base_tool import PluginBaseTool

        class R(PluginBaseTool):
            METADATA = ToolMetadata(name=name, description="d", category=cat, stage=stage)
            def run(self, t, **kw): return {}
            def parse_output(self, r, **kw): return {}

        return R()

    def test_register_instance_and_get(self):
        reg = self._registry()
        reg.register_instance(self._make_instance("Tool1"))
        r = reg.get("Tool1")
        self.assertIsNotNone(r)
        self.assertEqual(r.name, "Tool1")

    def test_list_returns_sorted(self):
        reg = self._registry()
        reg.register_instance(self._make_instance("B", stage=3, cat="net"))
        reg.register_instance(self._make_instance("A", stage=2, cat="dns"))
        lst = reg.list()
        self.assertTrue(len(lst) >= 2)

    def test_category_filter(self):
        reg = self._registry()
        reg.register_instance(self._make_instance("WebTool",  cat="web"))
        reg.register_instance(self._make_instance("DnsTool",  cat="dns"))
        web = reg.category("web")
        self.assertTrue(all(r.metadata.category == "web" for r in web))

    def test_search_by_capability(self):
        from sdk.contracts import ToolMetadata, CapabilitySet
        from sdk.base_tool import PluginBaseTool
        reg = self._registry()

        class CapTool(PluginBaseTool):
            METADATA = ToolMetadata(
                name="CapTool", description="d", category="t",
                capabilities=CapabilitySet().add("special_cap")
            )
            def run(self, t, **kw): return {}
            def parse_output(self, r, **kw): return {}

        reg.register_instance(CapTool())
        results = reg.search("special_cap")
        self.assertTrue(any(r.name == "CapTool" for r in results))

    def test_info_returns_dict(self):
        reg = self._registry()
        reg.register_instance(self._make_instance("InfoTool"))
        info = reg.info("InfoTool")
        self.assertIsNotNone(info)
        self.assertEqual(info.name, "InfoTool")

    def test_get_unknown_returns_none(self):
        reg = self._registry()
        self.assertIsNone(reg.get("DoesNotExist"))

    def test_stats_structure(self):
        reg = self._registry()
        s   = reg.stats()
        self.assertIn("total", s)
        self.assertIn("available", s)
        self.assertIn("categories", s)

    def test_all_categories(self):
        reg = self._registry()
        reg.register_instance(self._make_instance("T1", cat="net"))
        reg.register_instance(self._make_instance("T2", cat="dns"))
        cats = reg.all_categories()
        self.assertIn("net", cats)
        self.assertIn("dns", cats)

    def test_plugin_record_to_row(self):
        reg = self._registry()
        reg.register_instance(self._make_instance("RowTool"))
        r = reg.get("RowTool")
        row = r.to_row()
        self.assertIn("name", row)
        self.assertIn("category", row)
        self.assertIn("installed", row)


# ══════════════════════════════════════════════════════════════════════════════
# 6. Plugin Loader
# ══════════════════════════════════════════════════════════════════════════════

class TestPluginLoader(unittest.TestCase):

    def test_load_empty_dir_no_crash(self):
        from core.plugin_loader import PluginLoader
        from core.registry     import PluginRegistry
        with tempfile.TemporaryDirectory() as tmpdir:
            reg    = PluginRegistry()
            loader = PluginLoader(registry=reg, plugin_dirs=[Path(tmpdir)])
            result = loader.load_all()
            self.assertIsInstance(result.loaded, list)
            self.assertIsInstance(result.failed, list)

    def test_load_valid_plugin_file(self):
        from core.plugin_loader import PluginLoader
        from core.registry      import PluginRegistry

        plugin_code = '''
from reconx.sdk import PluginBaseTool, ToolMetadata

class ValidPlugin(PluginBaseTool):
    METADATA = ToolMetadata(name="ValidTest", description="Valid plugin",
                             category="test", binary="")
    def run(self, target, **kwargs):
        return self.build_result(data={}, findings=[])
    def parse_output(self, raw, **kwargs):
        return {}
'''
        with tempfile.TemporaryDirectory() as tmpdir:
            pdir = Path(tmpdir) / "valid_plugin"
            pdir.mkdir()
            (pdir / "plugin.py").write_text(plugin_code)

            reg    = PluginRegistry()
            loader = PluginLoader(registry=reg, plugin_dirs=[Path(tmpdir)])
            result = loader.load_all()
            # Either loaded (if reconx package importable) or skipped
            self.assertIsInstance(result.summary(), str)

    def test_load_broken_plugin_isolated(self):
        from core.plugin_loader import PluginLoader
        from core.registry      import PluginRegistry

        broken_code = "raise RuntimeError('Intentional break')"
        with tempfile.TemporaryDirectory() as tmpdir:
            pdir = Path(tmpdir) / "broken_plugin"
            pdir.mkdir()
            (pdir / "plugin.py").write_text(broken_code)

            reg    = PluginRegistry()
            loader = PluginLoader(registry=reg, plugin_dirs=[Path(tmpdir)])
            result = loader.load_all()
            # A broken plugin should be in failed, not crash ReconX
            self.assertIsInstance(result.failed, list)

    def test_error_classes_importable(self):
        from core.plugin_loader import (
            PluginLoadError, DependencyError,
            ToolValidationError, RegistryError,
        )
        e1 = PluginLoadError("path", "reason")
        e2 = DependencyError("plugin", ["dep1", "dep2"])
        e3 = ToolValidationError("plugin", ["err1"])
        self.assertIn("path", str(e1))
        self.assertIn("dep1", str(e2))
        self.assertIn("err1", str(e3))

    def test_load_result_summary(self):
        from core.plugin_loader import PluginLoadResult
        r = PluginLoadResult(loaded=["a", "b"], failed=["c"], skipped=["d"])
        s = r.summary()
        self.assertIn("Loaded: 2", s)
        self.assertIn("Failed: 1", s)

    def test_load_result_ok_property(self):
        from core.plugin_loader import PluginLoadResult
        r_ok  = PluginLoadResult(loaded=["a"])
        r_bad = PluginLoadResult(failed=["b"])
        self.assertTrue(r_ok.ok)
        self.assertFalse(r_bad.ok)


# ══════════════════════════════════════════════════════════════════════════════
# 7. Plugin Manager
# ══════════════════════════════════════════════════════════════════════════════

class TestPluginManager(unittest.TestCase):

    def _manager(self):
        from core.registry      import PluginRegistry
        from core.plugin_loader import PluginLoader
        from core.plugin_manager import PluginManager
        reg    = PluginRegistry()
        loader = PluginLoader(registry=reg, plugin_dirs=[])
        return PluginManager(registry=reg, loader=loader)

    def test_bootstrap_returns_result(self):
        from core.plugin_loader import PluginLoadResult
        pm = self._manager()
        result = pm.bootstrap(backfill_legacy=False)
        self.assertIsInstance(result, PluginLoadResult)
        self.assertTrue(pm._bootstrapped)

    def test_bootstrap_idempotent(self):
        pm      = self._manager()
        result1 = pm.bootstrap(backfill_legacy=False)
        result2 = pm.bootstrap(backfill_legacy=False)
        self.assertIs(result1, result2)

    def test_list_returns_list(self):
        pm = self._manager()
        pm.bootstrap(backfill_legacy=False)
        lst = pm.list()
        self.assertIsInstance(lst, list)

    def test_search_empty_registry(self):
        pm = self._manager()
        pm.bootstrap(backfill_legacy=False)
        results = pm.search("nonexistent_cap")
        self.assertEqual(results, [])

    def test_stats_returns_dict(self):
        pm = self._manager()
        pm.bootstrap(backfill_legacy=False)
        s = pm.stats()
        self.assertIn("total", s)
        self.assertIn("bootstrapped", s)
        self.assertTrue(s["bootstrapped"])

    def test_capabilities_returns_dict(self):
        pm = self._manager()
        pm.bootstrap(backfill_legacy=False)
        caps = pm.capabilities()
        self.assertIsInstance(caps, dict)

    def test_get_nonexistent_returns_none(self):
        pm = self._manager()
        pm.bootstrap(backfill_legacy=False)
        self.assertIsNone(pm.get("DoesNotExist"))

    def test_healthcheck_returns_list(self):
        pm = self._manager()
        pm.bootstrap(backfill_legacy=False)
        h = pm.healthcheck()
        self.assertIsInstance(h, list)


# ══════════════════════════════════════════════════════════════════════════════
# 8. Plugin files — metadata correctness
# ══════════════════════════════════════════════════════════════════════════════

class TestPluginMetadata(unittest.TestCase):

    def _load_plugin(self, module_path, class_name):
        import importlib
        try:
            mod = importlib.import_module(module_path)
            cls = getattr(mod, class_name)
            return cls()
        except Exception as exc:
            self.skipTest(f"Cannot import {module_path}: {exc}")

    def _validate_plugin(self, instance):
        from sdk.contracts import ToolMetadata
        meta = instance.METADATA
        self.assertIsInstance(meta, ToolMetadata)
        errors = meta.validate()
        self.assertEqual(errors, [], f"Metadata errors for {meta.name}: {errors}")
        self.assertGreater(len(meta.capabilities), 0, f"{meta.name} has no capabilities")
        self.assertNotEqual(meta.binary, "", f"{meta.name} has no binary")
        self.assertNotEqual(meta.install_cmd, "", f"{meta.name} has no install_cmd")

    def test_nmap_plugin_metadata(self):
        p = self._load_plugin("plugins.nmap.plugin", "NmapPlugin")
        self._validate_plugin(p)
        self.assertTrue(p.METADATA.permissions.requires_root)

    def test_amass_plugin_metadata(self):
        p = self._load_plugin("plugins.amass.plugin", "AmassPlugin")
        self._validate_plugin(p)
        self.assertTrue(p.METADATA.passive)

    def test_subfinder_plugin_metadata(self):
        p = self._load_plugin("plugins.subfinder.plugin", "SubfinderPlugin")
        self._validate_plugin(p)
        self.assertTrue(p.METADATA.passive)

    def test_httpx_plugin_metadata(self):
        p = self._load_plugin("plugins.httpx.plugin", "HTTPXPlugin")
        self._validate_plugin(p)
        self.assertFalse(p.METADATA.passive)

    def test_whois_plugin_metadata(self):
        p = self._load_plugin("plugins.whois.plugin", "WhoisPlugin")
        self._validate_plugin(p)
        self.assertTrue(p.METADATA.passive)

    def test_dns_plugin_metadata(self):
        p = self._load_plugin("plugins.dns.plugin", "DNSPlugin")
        self._validate_plugin(p)

    def test_nmap_capabilities_include_port_scan(self):
        p = self._load_plugin("plugins.nmap.plugin", "NmapPlugin")
        from sdk.metadata import CAPABILITIES
        self.assertTrue(p.METADATA.capabilities.has(CAPABILITIES.PORT_SCAN))

    def test_amass_capabilities_include_subdomain(self):
        p = self._load_plugin("plugins.amass.plugin", "AmassPlugin")
        from sdk.metadata import CAPABILITIES
        self.assertTrue(p.METADATA.capabilities.has(CAPABILITIES.SUBDOMAIN_ENUM))

    def test_nmap_name_constant_synced(self):
        p = self._load_plugin("plugins.nmap.plugin", "NmapPlugin")
        self.assertEqual(p.NAME, p.METADATA.name)

    def test_nmap_binary_constant_synced(self):
        p = self._load_plugin("plugins.nmap.plugin", "NmapPlugin")
        self.assertEqual(p.BINARY, p.METADATA.binary)

    def test_all_plugins_to_dict_serialisable(self):
        import json
        plugins = [
            ("plugins.nmap.plugin",      "NmapPlugin"),
            ("plugins.amass.plugin",     "AmassPlugin"),
            ("plugins.subfinder.plugin", "SubfinderPlugin"),
            ("plugins.httpx.plugin",     "HTTPXPlugin"),
            ("plugins.whois.plugin",     "WhoisPlugin"),
            ("plugins.dns.plugin",       "DNSPlugin"),
        ]
        for mod_path, cls_name in plugins:
            p = self._load_plugin(mod_path, cls_name)
            d = p.METADATA.to_dict()
            try:
                json.dumps(d)
            except Exception as exc:
                self.fail(f"{cls_name} to_dict not serialisable: {exc}")


# ══════════════════════════════════════════════════════════════════════════════
# 9. CLI tools commands
# ══════════════════════════════════════════════════════════════════════════════

class TestCLIToolsCommands(unittest.TestCase):

    def _console(self):
        from rich.console import Console
        import io
        return Console(file=io.StringIO(), width=120, highlight=False)

    def _manager_with_plugins(self):
        from core.registry       import PluginRegistry
        from core.plugin_loader  import PluginLoader
        from core.plugin_manager import PluginManager
        from sdk.contracts       import ToolMetadata, CapabilitySet
        from sdk.base_tool       import PluginBaseTool

        reg = PluginRegistry()

        for name, cat in [("ToolA", "network"), ("ToolB", "web"), ("ToolC", "dns")]:
            class T(PluginBaseTool):
                METADATA = ToolMetadata(name=name, description=f"Tool {name}",
                                        category=cat,
                                        capabilities=CapabilitySet().add("port_scan"))
                def run(self, t, **kw): return {}
                def parse_output(self, r, **kw): return {}
            T.METADATA = ToolMetadata(name=name, description=f"Tool {name}",
                                      category=cat,
                                      capabilities=CapabilitySet().add("port_scan"))
            t_instance = T()
            reg.register_instance(t_instance)

        loader = PluginLoader(registry=reg, plugin_dirs=[])
        pm     = PluginManager(registry=reg, loader=loader)
        pm.bootstrap(backfill_legacy=False)
        return pm

    def test_dispatch_no_args_prints_help(self):
        from cli.tools_commands import dispatch_tools_command
        import io
        from rich.console import Console
        buf = io.StringIO()
        console = Console(file=buf, width=120)
        dispatch_tools_command([], console)
        self.assertIn("reconx tools", buf.getvalue())

    def test_dispatch_unknown_cmd_returns_1(self):
        from cli.tools_commands import dispatch_tools_command
        result = dispatch_tools_command(["xyz_unknown"], self._console())
        self.assertEqual(result, 1)

    def test_dispatch_info_missing_name_returns_1(self):
        from cli.tools_commands import dispatch_tools_command
        result = dispatch_tools_command(["info"], self._console())
        self.assertEqual(result, 1)

    def test_dispatch_search_missing_arg_returns_1(self):
        from cli.tools_commands import dispatch_tools_command
        result = dispatch_tools_command(["search"], self._console())
        self.assertEqual(result, 1)

    def test_cmd_tools_list_no_crash(self):
        from cli.tools_commands import cmd_tools_list
        with patch("cli.tools_commands._get_manager", return_value=self._manager_with_plugins()):
            cmd_tools_list(self._console())

    def test_cmd_tools_info_missing_no_crash(self):
        from cli.tools_commands import cmd_tools_info
        with patch("cli.tools_commands._get_manager", return_value=self._manager_with_plugins()):
            cmd_tools_info(self._console(), "NonExistentTool")

    def test_cmd_tools_category_no_crash(self):
        from cli.tools_commands import cmd_tools_category
        with patch("cli.tools_commands._get_manager", return_value=self._manager_with_plugins()):
            cmd_tools_category(self._console())

    def test_cmd_tools_capabilities_no_crash(self):
        from cli.tools_commands import cmd_tools_capabilities
        with patch("cli.tools_commands._get_manager", return_value=self._manager_with_plugins()):
            cmd_tools_capabilities(self._console())

    def test_cmd_tools_search_no_crash(self):
        from cli.tools_commands import cmd_tools_search
        with patch("cli.tools_commands._get_manager", return_value=self._manager_with_plugins()):
            cmd_tools_search(self._console(), "port_scan")

    def test_cmd_tools_health_no_crash(self):
        from cli.tools_commands import cmd_tools_health
        with patch("cli.tools_commands._get_manager", return_value=self._manager_with_plugins()):
            cmd_tools_health(self._console())


if __name__ == "__main__":
    unittest.main(verbosity=2)
