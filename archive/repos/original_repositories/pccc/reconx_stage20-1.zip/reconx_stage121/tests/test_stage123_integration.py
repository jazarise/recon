"""
ReconX Stage 12.3 — Integration smoke tests.

Covers all 17 new tools across 8 categories:
  DNS Intel (3) | Screenshot (2) | API Recon (2) | Secrets (2)
  Cloud (1) | Certs (2) | Fingerprint (2) | Identity (3)

Test classes:
  1. Imports & attributes
  2. parse_output safety (empty string → dict, never raises)
  3. parse_output correctness (realistic output samples)
  4. Pure-Python fallback logic
  5. Knowledge catalog (17 entries, 8 categories)
  6. Registry (17 tools, no crash)
"""
from __future__ import annotations
import importlib
import sys
import types
import unittest
from unittest.mock import MagicMock, patch


# ── stub heavy optional deps ──────────────────────────────────────────────────

def _stub(name: str) -> types.ModuleType:
    mod = types.ModuleType(name)
    sys.modules[name] = mod
    return mod

for _dep in ("scapy", "scapy.all", "rich", "rich.console", "rich.progress",
             "rich.table", "rich.panel", "rich.live", "rich.prompt",
             "rich.rule", "rich.text", "rich.markdown", "rich.columns"):
    if _dep not in sys.modules:
        _stub(_dep)

_rc = sys.modules.get("rich.console") or _stub("rich.console")
if not hasattr(_rc, "Console"):
    _rc.Console = MagicMock
_rp = sys.modules.get("rich.progress") or _stub("rich.progress")
for _cls in ("Progress","SpinnerColumn","BarColumn","TaskProgressColumn",
             "TextColumn","TimeElapsedColumn","MofNCompleteColumn"):
    if not hasattr(_rp, _cls):
        setattr(_rp, _cls, MagicMock)


# ─────────────────────────────────────────────────────────────────────────────
# Tool matrix
# ─────────────────────────────────────────────────────────────────────────────

NEW_TOOLS_123 = [
    ("tools.dns_intel.massdns",    "MassDNSTool"),
    ("tools.dns_intel.shuffledns", "ShuffleDNSTool"),
    ("tools.dns_intel.puredns",    "PureDNSTool"),
    ("tools.screenshot.aquatone",  "AquatoneTool"),
    ("tools.screenshot.gowitness", "GoWitnessTool"),
    ("tools.api_recon.kiterunner", "KiterunnerTool"),
    ("tools.api_recon.graphw00f",  "Graphw00fTool"),
    ("tools.secrets.trufflehog",   "TrufflehogTool"),
    ("tools.secrets.gitleaks",     "GitleaksTool"),
    ("tools.cloud.s3scanner",      "S3ScannerTool"),
    ("tools.certs.crtsh",          "CrtshTool"),
    ("tools.certs.tlsx",           "TLSXTool"),
    ("tools.fingerprint.wafw00f",  "Wafw00fTool"),
    ("tools.fingerprint.testssl",  "TestSSLTool"),
    ("tools.identity.sherlock",    "SherlockTool"),
    ("tools.identity.holehe",      "HoleheTool"),
    ("tools.identity.phoneinfoga", "PhoneInfogaTool"),
]

REQUIRED_ATTRS = ["NAME", "BINARY", "CATEGORY", "STAGE", "TIMEOUT", "INSTALL_CMD"]


def _get(mp: str, cn: str):
    for prefix in ("reconx.", ""):
        try:
            mod = importlib.import_module(f"{prefix}{mp}")
            return getattr(mod, cn)()
        except ModuleNotFoundError:
            continue
    raise ImportError(f"Cannot import {cn} from {mp}")


# ─────────────────────────────────────────────────────────────────────────────
# 1. Imports & attributes
# ─────────────────────────────────────────────────────────────────────────────

class TestStage123Imports(unittest.TestCase):

    def test_all_17_tools_import(self):
        self.assertEqual(len(NEW_TOOLS_123), 17)
        for mp, cn in NEW_TOOLS_123:
            with self.subTest(tool=cn):
                inst = _get(mp, cn)
                self.assertIsNotNone(inst)

    def test_required_attributes(self):
        for mp, cn in NEW_TOOLS_123:
            with self.subTest(tool=cn):
                inst = _get(mp, cn)
                for attr in REQUIRED_ATTRS:
                    self.assertTrue(hasattr(inst, attr), f"{cn} missing: {attr}")

    def test_parse_output_empty_returns_dict(self):
        for mp, cn in NEW_TOOLS_123:
            with self.subTest(tool=cn):
                inst = _get(mp, cn)
                result = inst.parse_output("")
                self.assertIsInstance(result, dict, f"{cn}.parse_output('') must return dict")

    def test_is_available_returns_bool(self):
        for mp, cn in NEW_TOOLS_123:
            with self.subTest(tool=cn):
                inst = _get(mp, cn)
                with patch("shutil.which", return_value=None):
                    result = inst.is_available()
                self.assertIsInstance(result, bool)

    def test_passive_is_bool(self):
        for mp, cn in NEW_TOOLS_123:
            with self.subTest(tool=cn):
                inst = _get(mp, cn)
                self.assertIsInstance(inst.PASSIVE, bool)


# ─────────────────────────────────────────────────────────────────────────────
# 2. parse_output correctness
# ─────────────────────────────────────────────────────────────────────────────

class TestStage123ParseOutput(unittest.TestCase):

    # DNS Intel
    def test_massdns_simple_parse(self):
        from tools.dns_intel.massdns import MassDNSTool
        raw = "www.example.com. A 1.2.3.4\nmail.example.com. A 5.6.7.8\nnx.example.com. -- NXDOMAIN\n"
        d = MassDNSTool().parse_output(raw)
        self.assertEqual(d["count"], 2)
        self.assertIn("nx.example.com", d["nxdomain"])
        fqdns = [r["fqdn"] for r in d["resolved"]]
        self.assertIn("www.example.com", fqdns)

    def test_massdns_cname_parse(self):
        from tools.dns_intel.massdns import MassDNSTool
        raw = "cdn.example.com. CNAME target.cloudfront.net.\n"
        d = MassDNSTool().parse_output(raw)
        self.assertEqual(d["resolved"][0]["type"], "CNAME")

    def test_shuffledns_parse(self):
        from tools.dns_intel.shuffledns import ShuffleDNSTool
        raw = "api.example.com\ndev.example.com\nstaging.example.com\n"
        d = ShuffleDNSTool().parse_output(raw)
        self.assertEqual(d["count"], 3)
        self.assertIn("api.example.com", d["subdomains"])

    def test_puredns_parse(self):
        from tools.dns_intel.puredns import PureDNSTool
        raw = "api.example.com\nwww.example.com\n[INFO] processed 2 results\n"
        d = PureDNSTool().parse_output(raw)
        self.assertGreaterEqual(d["count"], 2)

    # Screenshot
    def test_aquatone_parse_text(self):
        from tools.screenshot.aquatone import AquatoneTool
        raw = "Taking screenshot of https://example.com\nhttps://example.com screenshot saved"
        d = AquatoneTool().parse_output(raw)
        self.assertIsInstance(d["screenshots"], list)

    def test_gowitness_parse(self):
        from tools.screenshot.gowitness import GoWitnessTool
        raw = "screenshot stored for https://example.com\nscreenshot stored for https://dev.example.com"
        d = GoWitnessTool().parse_output(raw)
        self.assertIsInstance(d["screenshots"], list)

    # API Recon
    def test_kiterunner_json_parse(self):
        import json
        from tools.api_recon.kiterunner import KiterunnerTool
        line = json.dumps({"url": "https://api.example.com/v1/users",
                           "path": "/v1/users", "method": "GET", "status": 200,
                           "content-length": 512, "words": 30})
        d = KiterunnerTool().parse_output(line)
        self.assertEqual(d["count"], 1)
        self.assertEqual(d["routes"][0]["method"], "GET")

    def test_kiterunner_text_parse(self):
        from tools.api_recon.kiterunner import KiterunnerTool
        raw = "[200] 512 GET /api/v1/users (example.com)\n[404] 0 POST /api/v2/admin"
        d = KiterunnerTool().parse_output(raw)
        self.assertGreaterEqual(d["count"], 1)

    def test_graphw00f_json_parse(self):
        import json
        from tools.api_recon.graphw00f import Graphw00fTool
        data = json.dumps([{"url": "https://api.example.com/graphql",
                            "engine": "Apollo Server", "introspection": True, "debug": False}])
        d = Graphw00fTool().parse_output(data)
        self.assertEqual(d["count"], 1)
        self.assertEqual(d["endpoints"][0]["engine"], "Apollo Server")
        self.assertTrue(d["endpoints"][0]["introspection"])

    def test_graphw00f_introspection_fingerprint(self):
        from tools.api_recon.graphw00f import Graphw00fTool
        body = '{"data":{"__schema":{"types":[{"name":"Query"}]}}} cf-ray: xxx apollo'
        engine = Graphw00fTool._fingerprint_response(body, {})
        self.assertEqual(engine, "Apollo Server")

    # Secrets
    def test_trufflehog_json_parse(self):
        import json
        from tools.secrets.trufflehog import TrufflehogTool
        line = json.dumps({"DetectorName": "AWS", "Verified": True,
                           "Raw": "AKIAIOSFODNN7EXAMPLE",
                           "SourceMetadata": {"Data": {"Git": {"file": "config.yml", "commit": "abc123"}}}})
        d = TrufflehogTool().parse_output(line)
        self.assertEqual(d["count"], 1)
        self.assertEqual(d["verified"], 1)
        self.assertEqual(d["secrets"][0]["severity"], "CRITICAL")

    def test_trufflehog_redact(self):
        from tools.secrets.trufflehog import TrufflehogTool
        redacted = TrufflehogTool._redact("AKIAIOSFODNN7EXAMPLE")
        self.assertIn("...", redacted)
        self.assertNotEqual(redacted, "AKIAIOSFODNN7EXAMPLE")

    def test_gitleaks_json_parse(self):
        import json
        from tools.secrets.gitleaks import GitleaksTool
        data = json.dumps([{"RuleID": "github-pat", "File": "main.py",
                            "Commit": "deadbeef1234", "StartLine": 42, "Secret": "ghp_xxx"}])
        d = GitleaksTool().parse_output(data)
        self.assertEqual(d["count"], 1)
        self.assertEqual(d["secrets"][0]["file"], "main.py")

    # Cloud
    def test_s3scanner_json_parse(self):
        import json
        from tools.cloud.s3scanner import S3ScannerTool
        line = json.dumps({"name": "company-backup", "provider": "aws",
                           "url": "https://company-backup.s3.amazonaws.com",
                           "exists": True, "public": True, "listable": True, "writable": False})
        d = S3ScannerTool().parse_output(line)
        self.assertEqual(d["count"], 1)
        self.assertTrue(d["buckets"][0]["listable"])

    def test_s3scanner_bogon_detect(self):
        from tools.cloud.s3scanner import S3ScannerTool
        # Provider detection
        self.assertEqual(S3ScannerTool._detect_provider("https://x.s3.amazonaws.com"), "AWS S3")
        self.assertEqual(S3ScannerTool._detect_provider("https://storage.googleapis.com/x"), "GCP GCS")

    def test_s3scanner_bucket_names(self):
        from tools.cloud.s3scanner import _bucket_names
        names = _bucket_names("example.com")
        self.assertIn("example", names)
        self.assertIn("example-backup", names)
        self.assertGreater(len(names), 5)

    # Certs
    def test_crtsh_process_json(self):
        from tools.certs.crtsh import CrtshTool
        data = [
            {"name_value": "api.example.com\ndev.example.com", "issuer_name": "Let's Encrypt",
             "not_before": "2024-01-01", "not_after": "2024-04-01", "id": 123},
        ]
        d = CrtshTool._process_crtsh_json(data, True, 5000)
        self.assertIn("api.example.com", d["subdomains"])
        self.assertIn("dev.example.com", d["subdomains"])

    def test_crtsh_wildcard_strip(self):
        from tools.certs.crtsh import CrtshTool
        data = [{"name_value": "*.example.com", "issuer_name": "", "id": 1,
                 "not_before": "", "not_after": ""}]
        d = CrtshTool._process_crtsh_json(data, True, 5000)
        # Wildcard stripped to example.com
        self.assertIn("example.com", d["subdomains"])

    def test_tlsx_json_parse(self):
        import json
        from tools.certs.tlsx import TLSXTool
        line = json.dumps({"host": "example.com", "cn": "example.com",
                           "san": ["www.example.com", "api.example.com"],
                           "issuer_cn": "Let's Encrypt", "tls_version": "TLSv1.3",
                           "not_before": "2024-01-01", "not_after": "2024-04-01"})
        d = TLSXTool().parse_output(line)
        self.assertEqual(d["count"], 1)
        self.assertIn("www.example.com", d["subdomains"])
        self.assertIn("api.example.com", d["subdomains"])

    # Fingerprint
    def test_wafw00f_parse_text(self):
        from tools.fingerprint.wafw00f import Wafw00fTool
        raw = "[+] The site https://example.com is behind Cloudflare WAF"
        d = Wafw00fTool().parse_output(raw)
        self.assertTrue(d["detected"])
        self.assertIn("Cloudflare", d["wafs"])

    def test_wafw00f_signature_match(self):
        from tools.fingerprint.wafw00f import _WAF_SIGNATURES
        import re
        headers = "cf-ray: 12345abc-LHR"
        for waf_name, itype, pattern in _WAF_SIGNATURES:
            if waf_name == "Cloudflare" and itype == "header":
                self.assertTrue(re.search(pattern, headers, re.I))

    def test_testssl_json_parse_severity_filter(self):
        from tools.fingerprint.testssl import TestSSLTool
        data = [
            {"id": "heartbleed", "severity": "CRITICAL",
             "finding": "VULNERABLE (NOT ok), uses TLS payload length"},
            {"id": "tls1", "severity": "WARN",
             "finding": "TLS 1 is offered"},
            {"id": "cert_trust", "severity": "OK", "finding": "OK"},
        ]
        d = TestSSLTool()._parse_json(data, severity="MEDIUM")
        # OK should be filtered; WARN and CRITICAL should appear
        severities = [i["severity"] for i in d["issues"]]
        self.assertIn("CRITICAL", severities)
        self.assertNotIn("INFO", severities)

    # Identity
    def test_sherlock_parse(self):
        from tools.identity.sherlock import SherlockTool
        raw = "[+] GitHub: https://github.com/targetuser\n[+] Twitter: https://twitter.com/targetuser\n[-] Facebook: Not Found"
        d = SherlockTool().parse_output(raw)
        self.assertEqual(d["count"], 2)
        urls = [p["url"] for p in d["profiles"]]
        self.assertIn("https://github.com/targetuser", urls)
        self.assertIn("facebook", d["not_found"][0].lower() if d["not_found"] else "")

    def test_holehe_parse(self):
        from tools.identity.holehe import HoleheTool
        raw = "[+] twitter.com        Email used\n[-] facebook.com       Email not used\n[x] linkedin.com       Error"
        d = HoleheTool().parse_output(raw)
        self.assertEqual(d["count"], 1)
        self.assertGreater(len(d["not_found"]), 0)
        self.assertGreater(len(d["errors"]), 0)

    def test_phoneinfoga_json_parse(self):
        import json
        from tools.identity.phoneinfoga import PhoneInfogaTool
        data = json.dumps({"rawLocal": "4155552671", "country": "US",
                           "carrier": "AT&T", "lineType": "mobile", "valid": True,
                           "local": "4155552671", "international": "+14155552671"})
        d = PhoneInfogaTool().parse_output(data)
        self.assertEqual(d["country"], "US")
        self.assertEqual(d["carrier"], "AT&T")
        self.assertTrue(d["valid"])


# ─────────────────────────────────────────────────────────────────────────────
# 3. Knowledge catalog
# ─────────────────────────────────────────────────────────────────────────────

class TestStage123Catalog(unittest.TestCase):

    def _load(self):
        for prefix in ("reconx.", ""):
            try:
                mod = importlib.import_module(
                    f"{prefix}knowledge.tools.s123.stage123_catalog"
                )
                return (mod.STAGE123_TOOL_KNOWLEDGE, mod.STAGE123_CATEGORIES,
                        mod.get_stage123_by_category, mod.search_stage123)
            except ModuleNotFoundError:
                continue
        self.fail("Cannot import stage123_catalog")

    def test_17_entries(self):
        catalog, *_ = self._load()
        self.assertGreaterEqual(len(catalog), 17)

    def test_8_categories(self):
        _, cats, *_ = self._load()
        self.assertEqual(len(cats), 8)
        expected = {"DNS Intelligence", "Screenshot Intelligence", "API Recon",
                    "Secret Intelligence", "Cloud Recon", "Certificate Intelligence",
                    "Fingerprinting", "Identity Intelligence"}
        self.assertEqual(set(cats), expected)

    def test_all_categories_populated(self):
        _, cats, get_by_cat, _ = self._load()
        for cat in cats:
            tools = get_by_cat(cat)
            self.assertGreater(len(tools), 0, f"No tools in category: {cat}")

    def test_all_tools_have_install(self):
        catalog, *_ = self._load()
        for t in catalog:
            self.assertTrue(t.install, f"{t.name} missing install command")

    def test_search_works(self):
        _, _, _, search = self._load()
        self.assertGreater(len(search("graphql")), 0)
        self.assertGreater(len(search("secret")), 0)
        self.assertGreater(len(search("username")), 0)

    def test_passive_tools_marked_correctly(self):
        catalog, *_ = self._load()
        passive_names = {t.name for t in catalog if t.passive}
        self.assertIn("crt.sh", passive_names)
        self.assertIn("sherlock", passive_names)
        self.assertIn("trufflehog", passive_names)

    def test_active_tools_not_passive(self):
        catalog, *_ = self._load()
        active = {t.name for t in catalog if not t.passive}
        self.assertIn("massdns", active)
        self.assertIn("kiterunner", active)
        self.assertIn("testssl.sh", active)


# ─────────────────────────────────────────────────────────────────────────────
# 4. Registry
# ─────────────────────────────────────────────────────────────────────────────

class TestStage123Registry(unittest.TestCase):

    def _load(self):
        for prefix in ("reconx.", ""):
            try:
                mod = importlib.import_module(f"{prefix}tools.registry_123")
                return mod.get_123_additions, mod._NullTool
            except ModuleNotFoundError:
                continue
        self.fail("Cannot import registry_123")

    def test_registry_loads(self):
        get_reg, _ = self._load()
        reg = get_reg()
        self.assertIsInstance(reg, dict)
        self.assertGreater(len(reg), 0)

    def test_all_17_tools_present(self):
        get_reg, _ = self._load()
        reg = get_reg()
        expected = [
            "MassDNSTool", "ShuffleDNSTool", "PureDNSTool",
            "AquatoneTool", "GoWitnessTool",
            "KiterunnerTool", "Graphw00fTool",
            "TrufflehogTool", "GitleaksTool",
            "S3ScannerTool",
            "CrtshTool", "TLSXTool",
            "Wafw00fTool", "TestSSLTool",
            "SherlockTool", "HoleheTool", "PhoneInfogaTool",
        ]
        for name in expected:
            self.assertIn(name, reg, f"Missing: {name}")

    def test_no_crash_missing_deps(self):
        get_reg, NullTool = self._load()
        reg = get_reg()
        for tool in reg.values():
            self.assertTrue(hasattr(tool, "run"))
            self.assertTrue(hasattr(tool, "is_available"))

    def test_null_tool_run_returns_safely(self):
        _, NullTool = self._load()
        null = NullTool("TestTool", "not installed")
        result = null.run("example.com")
        self.assertEqual(result.status, "skipped")


if __name__ == "__main__":
    import os
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    unittest.main(verbosity=2)
