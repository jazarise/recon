"""
ReconX Stage 12.1 — Integration smoke test.

Verifies:
  1. Every new tool module imports without error
  2. Every tool class can be instantiated
  3. parse_output() handles empty/None input without crashing
  4. is_available() returns a bool (never raises)
  5. Knowledge catalog loads correctly
  6. Guided recon step definitions are internally consistent
  7. Tool registry loads without errors

Run with:
    python -m pytest tests/test_stage121_integration.py -v
  or:
    python tests/test_stage121_integration.py
"""
from __future__ import annotations
import sys
import types
import importlib
import unittest
from unittest.mock import MagicMock, patch


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _make_stub_module(name: str) -> types.ModuleType:
    """Return a minimal stub for an optional dependency."""
    mod = types.ModuleType(name)
    sys.modules[name] = mod
    return mod


def _stub_optional_deps() -> None:
    """Stub heavy third-party deps so tests run without full install."""
    for dep in ("scapy", "scapy.all", "rich", "rich.console", "rich.progress",
                "rich.table", "rich.panel", "rich.live", "rich.columns",
                "rich.prompt", "rich.rule", "rich.text", "rich.markdown",
                "rich.columns", "rich"):
        if dep not in sys.modules:
            _make_stub_module(dep)

    # rich stubs need real-ish objects
    rich_mod = sys.modules.get("rich.console") or _make_stub_module("rich.console")
    if not hasattr(rich_mod, "Console"):
        rich_mod.Console = MagicMock
    rich_prog = sys.modules.get("rich.progress") or _make_stub_module("rich.progress")
    for cls in ("Progress", "SpinnerColumn", "BarColumn", "TaskProgressColumn",
                "TextColumn", "TimeElapsedColumn", "MofNCompleteColumn"):
        if not hasattr(rich_prog, cls):
            setattr(rich_prog, cls, MagicMock)


_stub_optional_deps()


# ─────────────────────────────────────────────────────────────────────────────
# Tool import / instantiation matrix
# ─────────────────────────────────────────────────────────────────────────────

NEW_TOOLS = [
    # (module_path,                        class_name)
    ("reconx.tools.osint.theharvester",    "TheHarvesterTool"),
    ("reconx.tools.osint.spiderfoot",      "SpiderFootTool"),
    ("reconx.tools.osint.osrframework",    "OSRFrameworkTool"),
    ("reconx.tools.osint.maltego",         "MaltegoTool"),
    ("reconx.tools.dns_extra.dnsenum_tool",   "DNSEnumTool"),
    ("reconx.tools.dns_extra.dnsrecon_tool",  "DNSReconTool"),
    ("reconx.tools.dns_extra.fierce_tool",    "FierceTool"),
    ("reconx.tools.dns_extra.sublist3r_tool", "Sublist3rTool"),
    ("reconx.tools.network.netdiscover_tool", "NetdiscoverTool"),
    ("reconx.tools.network.fping_tool",       "FpingTool"),
    ("reconx.tools.web.dirbuster",         "DirbusterTool"),
    ("reconx.tools.web.feroxbuster",       "FeroxbusterTool"),
    ("reconx.tools.web.eyewitness",        "EyeWitnessTool"),
    ("reconx.tools.frameworks.metasploit_aux", "MetasploitAuxTool"),
    ("reconx.tools.utilities.netcat_wrapper",  "NetcatWrapperTool"),
]


class TestToolImports(unittest.TestCase):
    """Every new tool must import and instantiate cleanly."""

    def _get_tool_instance(self, module_path: str, class_name: str):
        """Import module and return an instance of the tool class."""
        try:
            mod = importlib.import_module(module_path)
        except ModuleNotFoundError as e:
            # Strip package prefix for standalone test execution
            short = ".".join(module_path.split(".")[1:])
            mod   = importlib.import_module(short)
        cls  = getattr(mod, class_name)
        return cls()

    def test_all_tools_import(self):
        for module_path, class_name in NEW_TOOLS:
            with self.subTest(tool=class_name):
                inst = self._get_tool_instance(module_path, class_name)
                self.assertIsNotNone(inst, f"{class_name} instantiation returned None")

    def test_all_tools_have_name(self):
        for module_path, class_name in NEW_TOOLS:
            with self.subTest(tool=class_name):
                inst = self._get_tool_instance(module_path, class_name)
                self.assertTrue(hasattr(inst, "NAME"), f"{class_name} missing NAME attribute")
                self.assertIsInstance(inst.NAME, str)
                self.assertTrue(len(inst.NAME) > 0)

    def test_parse_output_handles_empty(self):
        """parse_output("") must never raise — must return a dict."""
        for module_path, class_name in NEW_TOOLS:
            with self.subTest(tool=class_name):
                inst = self._get_tool_instance(module_path, class_name)
                if hasattr(inst, "parse_output"):
                    result = inst.parse_output("")
                    self.assertIsInstance(result, dict,
                                         f"{class_name}.parse_output('') did not return dict")

    def test_is_available_returns_bool(self):
        """is_available() must return bool, never raise."""
        for module_path, class_name in NEW_TOOLS:
            with self.subTest(tool=class_name):
                inst = self._get_tool_instance(module_path, class_name)
                if hasattr(inst, "is_available"):
                    with patch("shutil.which", return_value=None):
                        result = inst.is_available()
                    self.assertIsInstance(result, bool,
                                         f"{class_name}.is_available() did not return bool")

    def test_tool_attributes_present(self):
        """Required BaseTool attributes must exist on every tool."""
        required = ["NAME", "BINARY", "CATEGORY", "STAGE", "TIMEOUT", "INSTALL_CMD"]
        for module_path, class_name in NEW_TOOLS:
            with self.subTest(tool=class_name):
                inst = self._get_tool_instance(module_path, class_name)
                for attr in required:
                    self.assertTrue(
                        hasattr(inst, attr),
                        f"{class_name} missing required attribute: {attr}",
                    )


# ─────────────────────────────────────────────────────────────────────────────
# Knowledge catalog tests
# ─────────────────────────────────────────────────────────────────────────────

class TestKnowledgeCatalog(unittest.TestCase):

    def _import_catalog(self):
        try:
            from reconx.knowledge.tools.stage121_catalog import (
                ALL_TOOL_KNOWLEDGE, CATEGORY_ORDER, get_by_category, get_by_name, search
            )
        except ModuleNotFoundError:
            from knowledge.tools.stage121_catalog import (
                ALL_TOOL_KNOWLEDGE, CATEGORY_ORDER, get_by_category, get_by_name, search
            )
        return ALL_TOOL_KNOWLEDGE, CATEGORY_ORDER, get_by_category, get_by_name, search

    def test_catalog_loads(self):
        catalog, *_ = self._import_catalog()
        self.assertGreater(len(catalog), 0, "Catalog is empty")

    def test_all_15_tools_present(self):
        catalog, *_ = self._import_catalog()
        self.assertGreaterEqual(len(catalog), 15,
                                f"Expected ≥15 tool entries, got {len(catalog)}")

    def test_every_tool_has_required_fields(self):
        catalog, *_ = self._import_catalog()
        required = ["name", "category", "description", "how_it_works",
                    "use_cases", "example_commands", "common_errors", "install"]
        for tool in catalog:
            for field in required:
                self.assertTrue(
                    hasattr(tool, field) and getattr(tool, field),
                    f"Tool '{tool.name}' missing or empty field: {field}",
                )

    def test_category_coverage(self):
        catalog, CATEGORY_ORDER, get_by_category, *_ = self._import_catalog()
        expected_categories = {
            "Passive Recon", "DNS", "Network Discovery", "Web Recon",
            "Frameworks", "Utilities",
        }
        actual = {t.category for t in catalog}
        for cat in expected_categories:
            self.assertIn(cat, actual, f"No tools found for category: {cat}")

    def test_search_returns_results(self):
        catalog, _, _, _, search_fn = self._import_catalog()
        results = search_fn("subdomain")
        self.assertGreater(len(results), 0, "Search for 'subdomain' returned no results")

    def test_get_by_name(self):
        _, _, _, get_by_name, _ = self._import_catalog()
        tool = get_by_name("dnsenum")
        self.assertIsNotNone(tool, "get_by_name('dnsenum') returned None")
        self.assertEqual(tool.name, "dnsenum")


# ─────────────────────────────────────────────────────────────────────────────
# Guided recon workflow tests
# ─────────────────────────────────────────────────────────────────────────────

class TestGuidedReconWorkflow(unittest.TestCase):

    def _import_workflow(self):
        try:
            from reconx.workflow.guided_recon_121 import GUIDED_STEPS, STEP_MAP
        except ModuleNotFoundError:
            from workflow.guided_recon_121 import GUIDED_STEPS, STEP_MAP
        return GUIDED_STEPS, STEP_MAP

    def test_steps_load(self):
        steps, _ = self._import_workflow()
        self.assertGreater(len(steps), 0, "No workflow steps defined")

    def test_16_or_more_steps(self):
        steps, _ = self._import_workflow()
        self.assertGreaterEqual(len(steps), 16,
                                f"Expected ≥16 guided steps, got {len(steps)}")

    def test_step_ids_unique(self):
        steps, _ = self._import_workflow()
        ids = [s.id for s in steps]
        self.assertEqual(len(ids), len(set(ids)), "Duplicate step IDs found")

    def test_step_dependencies_reference_valid_ids(self):
        steps, step_map = self._import_workflow()
        for step in steps:
            for dep in step.requires:
                self.assertIn(dep, step_map,
                              f"Step '{step.id}' requires unknown step: '{dep}'")

    def test_report_step_exists(self):
        _, step_map = self._import_workflow()
        self.assertIn("report", step_map, "Workflow missing 'report' step")

    def test_port_scan_not_skippable(self):
        _, step_map = self._import_workflow()
        if "port_scan" in step_map:
            self.assertFalse(step_map["port_scan"].skippable,
                             "port_scan should not be skippable")


# ─────────────────────────────────────────────────────────────────────────────
# parse_output correctness tests
# ─────────────────────────────────────────────────────────────────────────────

class TestParseOutputCorrectness(unittest.TestCase):
    """Spot-check parse_output() against known output samples."""

    def test_theharvester_email_parse(self):
        from tools.osint.theharvester import TheHarvesterTool
        tool   = TheHarvesterTool()
        sample = "[*] Emails found:\nadmin@example.com\ninfo@example.com\n"
        result = tool.parse_output(sample)
        self.assertIn("admin@example.com", result["emails"])

    def test_sublist3r_subdomain_parse(self):
        from tools.dns_extra.sublist3r_tool import Sublist3rTool
        tool   = Sublist3rTool()
        sample = "www.example.com\nmail.example.com\ndev.example.com\n"
        result = tool.parse_output(sample)
        self.assertIn("www.example.com", result["subdomains"])

    def test_fping_alive_parse(self):
        from tools.network.fping_tool import FpingTool
        tool   = FpingTool()
        sample = "192.168.1.1 is alive (2.45 ms)\n192.168.1.5 is unreachable\n"
        result = tool.parse_output(sample)
        self.assertEqual(len(result["hosts"]), 1)
        self.assertEqual(result["hosts"][0]["ip"], "192.168.1.1")
        self.assertIn("192.168.1.5", result["unreachable"])

    def test_netdiscover_parse(self):
        from tools.network.netdiscover_tool import NetdiscoverTool
        tool   = NetdiscoverTool()
        sample = " 192.168.1.1    00:11:22:33:44:55      1      60  ASUS\n"
        result = tool.parse_output(sample)
        self.assertEqual(len(result["hosts"]), 1)
        self.assertEqual(result["hosts"][0]["mac"], "00:11:22:33:44:55")

    def test_dnsrecon_zone_transfer_flag(self):
        from tools.dns_extra.dnsrecon_tool import DNSReconTool
        tool   = DNSReconTool()
        sample = "[+] Zone transfer successful for ns1.example.com\nsub.example.com A 1.2.3.4"
        result = tool.parse_output(sample)
        self.assertTrue(result["zone_transfer_vulnerable"])

    def test_feroxbuster_path_parse(self):
        from tools.web.feroxbuster import FeroxbusterTool
        tool   = FeroxbusterTool()
        sample = "200      GET   http://example.com/admin/ [Size: 1234]\n"
        result = tool.parse_output(sample)
        self.assertEqual(len(result["paths"]), 1)
        self.assertIn("admin", result["paths"][0]["url"])

    def test_fierce_wildcard_parse(self):
        from tools.dns_extra.fierce_tool import FierceTool
        tool   = FierceTool()
        sample = "Wildcard: *.example.com\nFound: www.example.com (93.184.216.34)\n"
        result = tool.parse_output(sample)
        self.assertIsNotNone(result["wildcard"])
        self.assertIn("www.example.com", result["subdomains"])


# ─────────────────────────────────────────────────────────────────────────────
# Runner
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    # Add parent dir to path for direct execution
    import os
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    unittest.main(verbosity=2)
