"""
ReconX — Stage 18.2 Test Suite: Traffic Intelligence Layer

Tests: 85 across 11 classes. All offline — no tshark binary required.
Network calls are mocked. TShark availability checks are patched out.
"""
from __future__ import annotations

import json
import sys
import tempfile
import time
import unittest
import uuid
from pathlib import Path
from unittest.mock import MagicMock, patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


# ══════════════════════════════════════════════════════════════════════════════
# 1. Shared models
# ══════════════════════════════════════════════════════════════════════════════

class TestModels(unittest.TestCase):

    def test_traffic_summary_to_dict_serialisable(self):
        from network.models import TrafficSummary, ProtocolHit, Severity
        s = TrafficSummary(source_file="test.pcap", total_packets=1000)
        s.protocols = [ProtocolHit(protocol="HTTP", confidence=0.98, port=80)]
        d = s.to_dict()
        json.dumps(d)   # must not raise

    def test_add_ip_classifies_private(self):
        from network.models import TrafficSummary
        s = TrafficSummary()
        s.add_ip("192.168.1.1")
        s.add_ip("8.8.8.8")
        self.assertIn("192.168.1.1", s.internal_ips)
        self.assertIn("8.8.8.8",    s.external_ips)

    def test_add_ip_deduplication(self):
        from network.models import TrafficSummary
        s = TrafficSummary()
        s.add_ip("10.0.0.1")
        s.add_ip("10.0.0.1")
        self.assertEqual(s.ips.count("10.0.0.1"), 1)

    def test_credential_hit_mask(self):
        from network.models import CredentialHit
        masked = CredentialHit.mask("supersecrettoken", keep=4)
        self.assertTrue(masked.startswith("supe"))
        self.assertIn("*", masked)
        self.assertNotIn("secret", masked)

    def test_credential_hit_display_safe(self):
        from network.models import CredentialHit, CredentialTag, Severity
        c = CredentialHit(tag=CredentialTag.JWT, masked_value="eyJh****",
                          source_proto="HTTP", src_ip="1.2.3.4", dst_ip="5.6.7.8")
        display = c.display()
        self.assertIn("[JWT]", display)
        self.assertNotIn("supersecret", display)

    def test_anomaly_alert_summary(self):
        from network.models import AnomalyAlert, Severity
        a = AnomalyAlert(alert_type="beaconing", description="30s interval",
                         src_ip="10.0.0.1", dst_ip="91.2.3.4",
                         severity=Severity.HIGH, confidence=0.88)
        summary = a.summary()
        self.assertIn("[HIGH]", summary)
        self.assertIn("beaconing", summary)
        self.assertIn("88%", summary)

    def test_tls_record_risk_level(self):
        from network.models import TLSRecord, Severity
        r = TLSRecord(src_ip="1.2.3.4", dst_ip="5.6.7.8", is_legacy_tls=True)
        self.assertEqual(r.risk_level, Severity.HIGH)

    def test_tls_record_ok_is_low(self):
        from network.models import TLSRecord, Severity
        r = TLSRecord(src_ip="1.2.3.4", dst_ip="5.6.7.8", tls_version="TLSv1.3")
        self.assertEqual(r.risk_level, Severity.LOW)

    def test_http_record_is_api(self):
        from network.models import HTTPRecord
        r = HTTPRecord(src_ip="1.2.3.4", dst_ip="5.6.7.8",
                       method="GET", host="api.example.com", path="/api/v1/users")
        self.assertTrue(r.is_api)

    def test_http_record_is_admin(self):
        from network.models import HTTPRecord
        r = HTTPRecord(src_ip="1.2.3.4", dst_ip="5.6.7.8",
                       method="GET", host="example.com", path="/admin/dashboard")
        self.assertTrue(r.is_admin)

    def test_flow_record_duration(self):
        from network.models import FlowRecord
        f = FlowRecord(src_ip="10.0.0.1", dst_ip="8.8.8.8",
                       src_port=54321, dst_port=53, protocol="UDP",
                       start_time=1000.0, end_time=1030.0)
        self.assertAlmostEqual(f.duration_s, 30.0)

    def test_traffic_summary_duration(self):
        from network.models import TrafficSummary
        s = TrafficSummary(start_time=1000.0, end_time=1060.0)
        self.assertAlmostEqual(s.duration_s, 60.0)

    def test_traffic_summary_high_severity_anomalies_filter(self):
        from network.models import TrafficSummary, AnomalyAlert, Severity
        s = TrafficSummary()
        s.anomalies = [
            AnomalyAlert(alert_type="beaconing", description="x", severity=Severity.HIGH, confidence=0.9),
            AnomalyAlert(alert_type="dns_tunnel", description="y", severity=Severity.LOW,  confidence=0.6),
        ]
        high = s.high_severity_anomalies
        self.assertEqual(len(high), 1)
        self.assertEqual(high[0].alert_type, "beaconing")


# ══════════════════════════════════════════════════════════════════════════════
# 2. TShark engine (mocked subprocess)
# ══════════════════════════════════════════════════════════════════════════════

class TestTSharkEngine(unittest.TestCase):

    def _mock_result(self, stdout="", ok=True):
        r = MagicMock()
        r.stdout = stdout; r.stderr = ""; r.ok = ok
        return r

    def test_available_false_when_not_on_path(self):
        from network.tshark_engine import TSharkEngine
        ts = TSharkEngine(binary="/nonexistent/tshark")
        self.assertFalse(ts.available())

    def test_install_hint_contains_apt(self):
        from network.tshark_engine import TSharkEngine
        self.assertIn("apt", TSharkEngine().install_hint())

    def test_decode_pcap_file_not_found(self):
        from network.tshark_engine import TSharkEngine
        ts = TSharkEngine()
        pkts, err = ts.decode_pcap("/nonexistent/file.pcap")
        self.assertEqual(pkts, [])
        self.assertIn("not found", err)

    def test_extract_fields_file_not_found(self):
        from network.tshark_engine import TSharkEngine
        ts = TSharkEngine()
        rows, err = ts.extract_fields("/nonexistent/file.pcap", ["ip.src"])
        self.assertEqual(rows, [])
        self.assertIn("not found", err)

    @patch("network.tshark_engine.run_subprocess")
    def test_protocol_stats_parse(self, mock_run):
        mock_run.return_value = self._mock_result(
            stdout=(
                "===================================================================\n"
                "Protocol Hierarchy Statistics\n"
                "Filter: \n"
                "\n"
                "  http                             1234  56789\n"
                "  dns                               400   8000\n"
            )
        )
        from network.tshark_engine import TSharkEngine
        import os
        with patch("os.path.exists", return_value=True):
            ts = TSharkEngine()
            stats, err = ts.protocol_stats("fake.pcap")
        self.assertIn("http", stats)
        self.assertEqual(stats["http"]["packets"], 1234)
        self.assertIn("dns", stats)

    @patch("network.tshark_engine.run_subprocess")
    def test_extract_fields_parse(self, mock_run):
        mock_run.return_value = self._mock_result(
            stdout='"192.168.1.1"|"8.8.8.8"|"google.com"\n'
        )
        from network.tshark_engine import TSharkEngine
        fields = ["ip.src", "ip.dst", "dns.qry.name"]
        with patch("os.path.exists", return_value=True):
            ts   = TSharkEngine()
            rows, err = ts.extract_fields("fake.pcap", fields)
        self.assertTrue(len(rows) >= 1)
        self.assertEqual(rows[0].get("ip.src"), "192.168.1.1")

    @patch("network.tshark_engine.run_subprocess")
    def test_decode_pcap_json_parse(self, mock_run):
        mock_run.return_value = self._mock_result(
            stdout='[{"_source": {"layers": {"ip": {"ip.src": "10.0.0.1"}}}}]'
        )
        from network.tshark_engine import TSharkEngine
        with patch("os.path.exists", return_value=True):
            ts   = TSharkEngine()
            pkts, err = ts.decode_pcap("fake.pcap")
        self.assertEqual(len(pkts), 1)
        self.assertEqual(err, "")

    @patch("network.tshark_engine.run_subprocess")
    def test_list_interfaces_parse(self, mock_run):
        mock_run.return_value = self._mock_result(
            stdout="1. eth0\n2. lo (Loopback)\n3. wlan0\n"
        )
        from network.tshark_engine import TSharkEngine
        ts = TSharkEngine()
        ifaces, err = ts.list_interfaces()
        self.assertEqual(err, "")
        self.assertTrue(len(ifaces) >= 2)
        self.assertEqual(ifaces[0]["index"], 1)
        self.assertEqual(ifaces[0]["name"], "eth0")


# ══════════════════════════════════════════════════════════════════════════════
# 3. Protocol detector
# ══════════════════════════════════════════════════════════════════════════════

class TestProtocolDetector(unittest.TestCase):

    def _det(self):
        from network.protocol_detector import ProtocolDetector
        return ProtocolDetector()

    def test_from_stats_http(self):
        d = self._det()
        hits = d.from_stats({"http": {"packets": 500, "bytes": 10000}})
        self.assertTrue(any(h.protocol == "HTTP" for h in hits))

    def test_from_stats_confidence(self):
        d = self._det()
        hits = d.from_stats({"dns": {"packets": 100, "bytes": 2000}})
        dns_hits = [h for h in hits if h.protocol == "DNS"]
        self.assertTrue(len(dns_hits) > 0)
        self.assertAlmostEqual(dns_hits[0].confidence, 1.00)

    def test_from_port_port_80(self):
        d = self._det()
        hit = d.from_port(dst_port=80, src_port=54321, proto="TCP")
        self.assertIsNotNone(hit)
        self.assertEqual(hit.protocol, "HTTP")

    def test_from_port_port_443(self):
        d = self._det()
        hit = d.from_port(dst_port=443, src_port=54321, proto="TCP")
        self.assertIsNotNone(hit)
        self.assertIn("TLS", hit.protocol)

    def test_from_port_unknown_port(self):
        d = self._det()
        hit = d.from_port(dst_port=54999, src_port=80, proto="TCP")
        self.assertIsNone(hit)

    def test_from_payload_http(self):
        d = self._det()
        payload = b"GET /index.html HTTP/1.1\r\nHost: example.com\r\n\r\n"
        hit = d.from_payload(payload, src_port=54321, dst_port=80)
        self.assertIsNotNone(hit)
        self.assertEqual(hit.protocol, "HTTP")

    def test_from_payload_ssh(self):
        d = self._det()
        payload = b"SSH-2.0-OpenSSH_8.9\r\n"
        hit = d.from_payload(payload, src_port=22, dst_port=54321)
        self.assertIsNotNone(hit)
        self.assertEqual(hit.protocol, "SSH")

    def test_from_stats_empty_returns_empty(self):
        d = self._det()
        hits = d.from_stats({})
        self.assertEqual(hits, [])

    def test_sorted_by_confidence_desc(self):
        d = self._det()
        hits = d.from_stats({
            "dns": {"packets": 100, "bytes": 2000},
            "http": {"packets": 500, "bytes": 10000},
        })
        confidences = [h.confidence for h in hits]
        self.assertEqual(confidences, sorted(confidences, reverse=True))

    def test_get_all_known_contains_core_protos(self):
        d = self._det()
        known = d.get_all_known()
        for p in ["HTTP", "DNS", "SSH", "FTP", "SMTP", "SMB", "RDP"]:
            self.assertIn(p, known)


# ══════════════════════════════════════════════════════════════════════════════
# 4. Credential detector
# ══════════════════════════════════════════════════════════════════════════════

class TestCredentialDetector(unittest.TestCase):

    def _det(self):
        from network.credential_detector import CredentialDetector
        return CredentialDetector()

    def _make_jwt(self):
        import base64, json as _json
        h = base64.urlsafe_b64encode(b'{"alg":"HS256"}').decode().rstrip("=")
        p = base64.urlsafe_b64encode(b'{"sub":"1234"}').decode().rstrip("=")
        return f"{h}.{p}.fakesignatureXXXXX"

    def test_scan_text_detects_jwt(self):
        d   = self._det()
        jwt = self._make_jwt()
        hits = d.scan_text(f"Authorization: Bearer {jwt}", "1.2.3.4", "5.6.7.8", "HTTP")
        self.assertTrue(any(h.tag.value == "JWT" for h in hits))

    def test_scan_text_detects_bearer(self):
        d    = self._det()
        hits = d.scan_text("Authorization: Bearer abcdefghijklmnop1234567890", "1.2.3.4", "5.6.7.8")
        self.assertTrue(any(h.tag.value in ("TOKEN", "JWT") for h in hits))

    def test_scan_text_detects_api_key(self):
        d    = self._det()
        hits = d.scan_text("X-API-Key: MyS3cur3ApiKey1234567890", "1.2.3.4", "5.6.7.8")
        self.assertTrue(any(h.tag.value == "API_KEY" for h in hits))

    def test_basic_auth_detected(self):
        import base64
        d       = self._det()
        encoded = base64.b64encode(b"admin:password123").decode()
        hits    = d.scan_text(f"Authorization: Basic {encoded}", "1.2.3.4", "5.6.7.8")
        self.assertTrue(any(h.tag.value == "BASIC_AUTH" for h in hits))

    def test_masked_value_hides_secret(self):
        import base64
        d       = self._det()
        encoded = base64.b64encode(b"admin:password123").decode()
        hits    = d.scan_text(f"Authorization: Basic {encoded}", "1.2.3.4", "5.6.7.8")
        for h in hits:
            self.assertNotIn("password123", h.masked_value)
            self.assertIn("*", h.masked_value)

    def test_scan_rows_empty(self):
        d    = self._det()
        hits = d.scan_rows([])
        self.assertEqual(hits, [])

    def test_scan_rows_with_auth_row(self):
        import base64
        d   = self._det()
        enc = base64.b64encode(b"user:secret").decode()
        rows = [{"http.authorization": f"Basic {enc}", "ip.src": "10.0.0.1", "ip.dst": "1.2.3.4"}]
        hits = d.scan_rows(rows)
        self.assertTrue(len(hits) >= 1)

    def test_ftp_pass_detected(self):
        d = self._det()
        hit = d._check_ftp("PASS supersecretpassword", "10.0.0.1", "10.0.0.2")
        self.assertIsNotNone(hit)
        self.assertNotIn("supersecretpassword", hit.masked_value)

    def test_deduplication_in_scan_rows(self):
        import base64
        d   = self._det()
        enc = base64.b64encode(b"user:pass").decode()
        # Same auth header repeated 5 times
        rows = [{"http.authorization": f"Basic {enc}", "ip.src": "10.0.0.1", "ip.dst": "1.1.1.1"}] * 5
        hits = d.scan_rows(rows)
        # Should be deduplicated
        basic_hits = [h for h in hits if h.tag.value == "BASIC_AUTH"]
        self.assertEqual(len(basic_hits), 1)


# ══════════════════════════════════════════════════════════════════════════════
# 5. DNS extractor
# ══════════════════════════════════════════════════════════════════════════════

class TestDNSExtractor(unittest.TestCase):

    def _ext(self):
        from network.dns_extractor import DNSExtractor
        return DNSExtractor()

    def _row(self, name, qtype="A", answers="", src="10.0.0.1", dst="8.8.8.8"):
        return {"dns.qry.name": name, "dns.qry.type": qtype,
                "dns.a": answers, "ip.src": src, "ip.dst": dst}

    def test_parse_basic_query(self):
        ext = self._ext()
        rows = [self._row("example.com", "A", "93.184.216.34")]
        entries = ext.parse_rows(rows)
        self.assertEqual(len(entries), 1)
        self.assertEqual(entries[0].query_name, "example.com")
        self.assertEqual(entries[0].record_type, "A")

    def test_parse_multiple_answers(self):
        ext = self._ext()
        rows = [self._row("example.com", "A", "1.2.3.4,5.6.7.8")]
        entries = ext.parse_rows(rows)
        self.assertEqual(len(entries[0].answers), 2)

    def test_detect_tunnel_long_name(self):
        ext = self._ext()
        long_name = "a" * 55 + ".evil.com"
        rows = [self._row(long_name)]
        entries = ext.parse_rows(rows)
        self.assertTrue(entries[0].is_tunnel_suspect)
        self.assertIn("long name", entries[0].tunnel_reason)

    def test_detect_high_frequency(self):
        ext = self._ext()
        rows = [self._row("data.evil.com")] * 110
        entries = ext.parse_rows(rows)
        self.assertTrue(any(e.is_high_freq for e in entries))

    def test_no_tunnel_for_common_domains(self):
        ext = self._ext()
        rows = [self._row("www.google.com"), self._row("api.microsoft.com")]
        entries = ext.parse_rows(rows)
        self.assertFalse(any(e.is_tunnel_suspect for e in entries))

    def test_get_unique_domains(self):
        ext = self._ext()
        rows = [self._row("a.example.com"), self._row("b.example.com"), self._row("test.org")]
        entries = ext.parse_rows(rows)
        domains  = ext.get_unique_domains(entries)
        self.assertIn("example.com", domains)

    def test_get_resolved_ips(self):
        ext = self._ext()
        rows = [self._row("example.com", answers="93.184.216.34")]
        entries = ext.parse_rows(rows)
        ips = ext.get_resolved_ips(entries)
        self.assertIn("93.184.216.34", ips)

    def test_get_subdomains(self):
        ext = self._ext()
        rows = [self._row("api.example.com"), self._row("www.example.com"), self._row("other.org")]
        entries = ext.parse_rows(rows)
        subs = ext.get_subdomains(entries, "example.com")
        self.assertIn("api.example.com", subs)
        self.assertNotIn("other.org", subs)


# ══════════════════════════════════════════════════════════════════════════════
# 6. HTTP extractor
# ══════════════════════════════════════════════════════════════════════════════

class TestHTTPExtractor(unittest.TestCase):

    def _ext(self):
        from network.http_extractor import HTTPExtractor
        return HTTPExtractor()

    def _row(self, method="GET", host="example.com", path="/", status="200", ua="curl/7.0"):
        return {"http.request.method": method, "http.host": host,
                "http.request.uri": path, "http.response.code": status,
                "http.user_agent": ua, "ip.src": "10.0.0.1", "ip.dst": "1.2.3.4"}

    def test_parse_basic_record(self):
        ext = self._ext()
        rows = [self._row("GET", "example.com", "/index.html", "200")]
        records = ext.parse_rows(rows)
        self.assertEqual(len(records), 1)
        self.assertEqual(records[0].method, "GET")
        self.assertEqual(records[0].host, "example.com")

    def test_deduplication(self):
        ext = self._ext()
        rows = [self._row()] * 5
        records = ext.parse_rows(rows)
        self.assertEqual(len(records), 1)

    def test_api_detection(self):
        ext = self._ext()
        rows = [self._row(path="/api/v1/users")]
        records = ext.parse_rows(rows)
        self.assertTrue(records[0].is_api)

    def test_admin_detection(self):
        ext = self._ext()
        rows = [self._row(path="/admin/settings")]
        records = ext.parse_rows(rows)
        self.assertTrue(records[0].is_admin)

    def test_auth_route_detection(self):
        ext = self._ext()
        rows = [self._row(path="/login")]
        records = ext.parse_rows(rows)
        self.assertTrue(records[0].is_auth)

    def test_upload_detection(self):
        ext = self._ext()
        rows = [self._row(path="/upload/file")]
        records = ext.parse_rows(rows)
        self.assertTrue(records[0].is_upload)

    def test_get_api_endpoints(self):
        ext = self._ext()
        rows = [self._row(path="/api/users"), self._row(path="/home")]
        records = ext.parse_rows(rows)
        apis = ext.get_api_endpoints(records)
        self.assertTrue(len(apis) >= 1)
        self.assertTrue(any("/api/users" in u for u in apis))

    def test_get_redirect_chains(self):
        ext = self._ext()
        rows = [self._row(status="301"), self._row(path="/about", status="200")]
        records = ext.parse_rows(rows)
        chains = ext.get_redirect_chains(records)
        self.assertTrue(len(chains) >= 1)


# ══════════════════════════════════════════════════════════════════════════════
# 7. TLS fingerprinter
# ══════════════════════════════════════════════════════════════════════════════

class TestTLSFingerprinter(unittest.TestCase):

    def _fp(self):
        from network.tls_fingerprint import TLSFingerprinter
        return TLSFingerprinter()

    def _row(self, sni="example.com", ver="0x0303", ja3="abc123"):
        return {"tls.handshake.extensions_server_name": sni,
                "tls.record.version": ver,
                "tls.handshake.ja3": ja3,
                "ip.src": "10.0.0.1", "ip.dst": "1.2.3.4"}

    def test_parse_basic_tls(self):
        fp = self._fp()
        rows = [self._row()]
        records = fp.parse_rows(rows)
        self.assertEqual(len(records), 1)
        self.assertEqual(records[0].sni, "example.com")

    def test_tls_version_normalised(self):
        fp = self._fp()
        rows = [self._row(ver="0x0303")]
        records = fp.parse_rows(rows)
        self.assertEqual(records[0].tls_version, "TLSv1.2")

    def test_legacy_tls_flagged(self):
        fp = self._fp()
        rows = [self._row(ver="0x0301")]   # TLSv1.0
        records = fp.parse_rows(rows)
        self.assertTrue(records[0].is_legacy_tls)

    def test_tls_13_not_legacy(self):
        fp = self._fp()
        rows = [self._row(ver="0x0304")]   # TLSv1.3
        records = fp.parse_rows(rows)
        self.assertFalse(records[0].is_legacy_tls)

    def test_deduplication_by_sni_src(self):
        fp = self._fp()
        rows = [self._row()] * 3
        records = fp.parse_rows(rows)
        self.assertEqual(len(records), 1)

    def test_get_unique_snis(self):
        fp = self._fp()
        rows = [self._row("a.com"), self._row("b.com")]
        records = fp.parse_rows(rows)
        snis = fp.get_unique_snis(records)
        self.assertIn("a.com", snis)
        self.assertIn("b.com", snis)

    def test_get_weak_records(self):
        fp = self._fp()
        rows = [self._row(ver="0x0301"), self._row(ver="0x0304")]
        records = fp.parse_rows(rows)
        weak = fp.get_weak_records(records)
        self.assertEqual(len(weak), 1)

    def test_risk_summary_counts(self):
        fp = self._fp()
        rows = [self._row(ver="0x0301", sni="a.com"),
                self._row(ver="0x0302", sni="b.com"),
                self._row(ver="0x0304", sni="safe.com")]
        records = fp.parse_rows(rows)
        summary = fp.risk_summary(records)
        self.assertEqual(summary["total"], 3)
        self.assertGreaterEqual(summary["legacy_tls"], 2)


# ══════════════════════════════════════════════════════════════════════════════
# 8. Anomaly engine
# ══════════════════════════════════════════════════════════════════════════════

class TestAnomalyEngine(unittest.TestCase):

    def _engine(self):
        from network.anomaly_engine import AnomalyEngine
        return AnomalyEngine()

    def _summary_with_flows(self, flows):
        from network.models import TrafficSummary
        s = TrafficSummary()
        s.flows = flows
        return s

    def _make_flow(self, src, dst, dport=80, start=None, bytes_sent=0):
        from network.models import FlowRecord
        return FlowRecord(src_ip=src, dst_ip=dst, src_port=54321,
                          dst_port=dport, protocol="TCP",
                          start_time=start or time.time(),
                          bytes_sent=bytes_sent)

    def test_analyze_empty_summary_no_crash(self):
        from network.models import TrafficSummary
        engine = self._engine()
        alerts = engine.analyze(TrafficSummary())
        self.assertIsInstance(alerts, list)

    def test_detect_beaconing(self):
        engine = self._engine()
        # Create 10 flows exactly 30 seconds apart (very regular = beaconing)
        base = 1000.0
        flows = [self._make_flow("10.0.0.50", "91.2.3.4", start=base + i * 30.0)
                 for i in range(10)]
        summary = self._summary_with_flows(flows)
        alerts  = engine._detect_beaconing(summary)
        self.assertTrue(len(alerts) >= 1)
        self.assertEqual(alerts[0].alert_type, "beaconing")

    def test_no_beaconing_for_irregular(self):
        engine = self._engine()
        import random
        random.seed(42)
        # Highly irregular intervals — not beaconing
        flows = [self._make_flow("10.0.0.1", "8.8.8.8",
                                  start=1000.0 + random.uniform(0, 300))
                 for _ in range(10)]
        summary = self._summary_with_flows(flows)
        alerts  = engine._detect_beaconing(summary)
        self.assertEqual(len(alerts), 0)

    def test_detect_high_frequency(self):
        engine = self._engine()
        flows   = [self._make_flow("10.0.0.1", "192.168.1.2", dport=80)
                   for _ in range(60)]
        summary = self._summary_with_flows(flows)
        alerts  = engine._detect_high_frequency(summary)
        self.assertTrue(len(alerts) >= 1)
        self.assertEqual(alerts[0].alert_type, "high_frequency")

    def test_detect_protocol_misuse(self):
        from network.models import TrafficSummary, ProtocolHit
        engine = self._engine()
        summary = TrafficSummary()
        summary.protocols = [ProtocolHit(protocol="SSH", confidence=0.98, port=4444)]
        alerts = engine._detect_protocol_misuse(summary)
        self.assertTrue(len(alerts) >= 1)
        self.assertEqual(alerts[0].alert_type, "protocol_misuse")

    def test_dns_tunnel_alert_promoted(self):
        from network.models import TrafficSummary, DNSEntry
        engine = self._engine()
        summary = TrafficSummary()
        entry   = DNSEntry(query_name="aaaaaa.evil.com", record_type="A")
        entry.is_tunnel_suspect = True
        entry.tunnel_reason     = "long name"
        entry.src_ip            = "10.0.0.1"
        summary.dns_entries = [entry]
        alerts = engine._import_dns_tunnel_alerts(summary)
        self.assertEqual(len(alerts), 1)
        self.assertEqual(alerts[0].alert_type, "dns_tunneling")

    def test_exfil_signal_large_outbound(self):
        from network.models import TrafficSummary
        engine = self._engine()
        summary = TrafficSummary()
        summary.internal_ips = ["10.0.0.1"]
        summary.external_ips = ["91.2.3.4"]
        flow = self._make_flow("10.0.0.1", "91.2.3.4", bytes_sent=15_000_000)
        summary.flows = [flow]
        alerts = engine._detect_exfil_signal(summary)
        self.assertTrue(len(alerts) >= 1)
        self.assertEqual(alerts[0].alert_type, "exfil_signal")


# ══════════════════════════════════════════════════════════════════════════════
# 9. PyShark engine (no pyshark installed)
# ══════════════════════════════════════════════════════════════════════════════

class TestPySharkEngine(unittest.TestCase):

    def test_available_false_when_not_installed(self):
        from network.pyshark_engine import PySharkEngine
        ps = PySharkEngine()
        # Either True (if pyshark installed) or False — both valid
        self.assertIsInstance(ps.available(), bool)

    def test_read_pcap_returns_empty_when_unavailable(self):
        from network.pyshark_engine import PySharkEngine
        ps = PySharkEngine()
        if not ps.available():
            pkts, err = ps.read_pcap("fake.pcap")
            self.assertEqual(pkts, [])
            self.assertIn("pyshark", err.lower())

    def test_deep_credential_scan_no_crash_when_unavailable(self):
        from network.pyshark_engine import PySharkEngine
        ps = PySharkEngine()
        if not ps.available():
            hits = ps.deep_credential_scan("fake.pcap")
            self.assertEqual(hits, [])

    def test_reconstruct_flows_empty(self):
        from network.pyshark_engine import PySharkEngine
        ps    = PySharkEngine()
        flows = ps.reconstruct_flows([])
        self.assertEqual(flows, [])

    def test_install_hint_contains_pyshark(self):
        from network.pyshark_engine import PySharkEngine
        hint = PySharkEngine().install_hint()
        self.assertIn("pyshark", hint)


# ══════════════════════════════════════════════════════════════════════════════
# 10. Report injector
# ══════════════════════════════════════════════════════════════════════════════

class TestNetworkReportInjector(unittest.TestCase):

    def _minimal_html(self):
        return ("<!DOCTYPE html><html><head>"
                "<style>:root{--bg2:#0c1420;--border:#1a3050;--dim:#5a7a9a;}</style>"
                "</head><body><div>existing</div></body></html>")

    def _sample_data(self):
        return {
            "source_file": "capture.pcap",
            "total_packets": 1500,
            "packets_per_sec": 50.0,
            "protocols": [{"protocol": "HTTP", "confidence": 0.98, "port": 80, "detail": ""}],
            "ips": ["10.0.0.1", "8.8.8.8"],
            "hosts": ["example.com"],
            "domains": ["example.com"],
            "dns_entries": [{"query_name": "example.com", "record_type": "A",
                              "answers": ["1.2.3.4"], "is_tunnel_suspect": False}],
            "http_records": [{"method": "GET", "host": "example.com", "path": "/api",
                               "status_code": 200}],
            "tls_records": [{"sni": "example.com", "tls_version": "TLSv1.3",
                              "ja3": "abc123", "is_legacy_tls": False}],
            "credentials": [],
            "anomalies": [],
            "top_talkers": [{"ip": "10.0.0.1", "packets": 1000, "bytes": 500000}],
        }

    def test_inject_returns_true(self):
        from network.report_injector import inject_traffic_section
        with tempfile.NamedTemporaryFile(mode="w", suffix=".html",
                                         delete=False, encoding="utf-8") as f:
            f.write(self._minimal_html())
            path = f.name
        result = inject_traffic_section(path, self._sample_data())
        self.assertTrue(result)

    def test_inject_adds_traffic_section(self):
        from network.report_injector import inject_traffic_section
        with tempfile.NamedTemporaryFile(mode="w", suffix=".html",
                                         delete=False, encoding="utf-8") as f:
            f.write(self._minimal_html())
            path = f.name
        inject_traffic_section(path, self._sample_data())
        content = Path(path).read_text()
        self.assertIn("traffic-section", content)
        self.assertIn("Traffic Intelligence", content)
        self.assertIn("Protocol Inventory", content)

    def test_inject_false_on_missing_file(self):
        from network.report_injector import inject_traffic_section
        result = inject_traffic_section("/nonexistent/report.html", {})
        self.assertFalse(result)

    def test_inject_idempotent_css(self):
        from network.report_injector import inject_traffic_section
        with tempfile.NamedTemporaryFile(mode="w", suffix=".html",
                                         delete=False, encoding="utf-8") as f:
            f.write(self._minimal_html())
            path = f.name
        inject_traffic_section(path, self._sample_data())
        inject_traffic_section(path, self._sample_data())
        content = Path(path).read_text()
        self.assertEqual(content.count(".traffic-section {"), 1)

    def test_credential_table_empty_shows_safe_message(self):
        from network.report_injector import inject_traffic_section
        with tempfile.NamedTemporaryFile(mode="w", suffix=".html",
                                         delete=False, encoding="utf-8") as f:
            f.write(self._minimal_html())
            path = f.name
        inject_traffic_section(path, self._sample_data())
        content = Path(path).read_text()
        self.assertIn("No credentials detected", content)


# ══════════════════════════════════════════════════════════════════════════════
# 11. Registry
# ══════════════════════════════════════════════════════════════════════════════

class TestRegistry182(unittest.TestCase):

    def test_catalog_returns_list(self):
        from tools.registry_182 import get_stage182_catalog
        cat = get_stage182_catalog()
        self.assertIsInstance(cat, list)
        self.assertEqual(len(cat), 1)

    def test_catalog_has_required_fields(self):
        from tools.registry_182 import get_stage182_catalog
        entry = get_stage182_catalog()[0]
        for field in ("name", "class", "module", "category", "stage",
                      "passive", "description", "capabilities", "tags"):
            self.assertIn(field, entry)

    def test_catalog_passive_true(self):
        from tools.registry_182 import get_stage182_catalog
        self.assertTrue(get_stage182_catalog()[0]["passive"])

    def test_catalog_capabilities_list(self):
        from tools.registry_182 import get_stage182_catalog
        caps = get_stage182_catalog()[0]["capabilities"]
        self.assertIsInstance(caps, list)
        self.assertIn("pcap_analysis", caps)
        self.assertIn("anomaly_detection", caps)

    def test_tool_chains_have_steps(self):
        from tools.registry_182 import get_stage182_tool_chains
        for chain in get_stage182_tool_chains():
            self.assertIn("steps", chain)
            self.assertGreater(len(chain["steps"]), 0)

    def test_registry_load_graceful(self):
        from tools.registry_182 import get_stage182_registry
        registry = get_stage182_registry()
        self.assertIsInstance(registry, dict)


if __name__ == "__main__":
    unittest.main(verbosity=2)
