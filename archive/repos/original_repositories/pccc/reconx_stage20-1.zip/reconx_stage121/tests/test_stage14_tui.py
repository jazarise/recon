"""
ReconX Stage 14 — Integration tests for TUI + Learning Platform.

Test classes:
  1. Dashboard      — renders without crashing, contains correct menu items
  2. ToolBrowser    — category listing, search, tool detail (headless)
  3. LearningMode   — lessons load, relationships render
  4. GuidedView     — classify+recommend runs without engine
  5. ExecutionView  — quick action config, dry-run display
  6. Navigator      — builds cleanly, routes all choices without crashing
  7. QuickActionBar — renders compact and full
  8. Report14       — HTML section generation and injection
  9. AppEntry       — build_app() returns Navigator with correct attrs
"""
from __future__ import annotations

import sys
import types
import unittest
from io import StringIO
from unittest.mock import MagicMock, patch


# ── stub Rich so tests run in CI without a terminal ──────────────────────────

def _stub(name: str, **attrs) -> types.ModuleType:
    mod = types.ModuleType(name)
    sys.modules[name] = mod
    for k, v in attrs.items():
        setattr(mod, k, v)
    return mod

for _dep in ("rich", "rich.live", "rich.layout", "rich.align",
             "rich.rule", "rich.text", "rich.markdown", "rich.columns",
             "rich.prompt", "rich.style", "rich.theme"):
    if _dep not in sys.modules:
        _stub(_dep)

# Rich console/panel/table/progress need more careful stubs
for _dep in ("rich.console", "rich.panel", "rich.table", "rich.progress"):
    if _dep not in sys.modules:
        _stub(_dep)

_rc = sys.modules["rich.console"]
if not hasattr(_rc, "Console"):
    _rc.Console = MagicMock
if not hasattr(_rc, "Group"):
    _rc.Group = lambda *a, **kw: a

_rprog = sys.modules["rich.progress"]
for _cls in ("Progress", "SpinnerColumn", "BarColumn", "TaskProgressColumn",
             "TextColumn", "TimeElapsedColumn", "MofNCompleteColumn",
             "MofNCompleteColumn"):
    if not hasattr(_rprog, _cls):
        setattr(_rprog, _cls, MagicMock)

_rpanel = sys.modules["rich.panel"]
if not hasattr(_rpanel, "Panel"):
    _rpanel.Panel = MagicMock

_rtable = sys.modules["rich.table"]
if not hasattr(_rtable, "Table"):
    _rtable.Table = MagicMock

_rtext = sys.modules["rich.text"]
if not hasattr(_rtext, "Text"):
    class _FakeText:
        def __init__(self, *a, **kw): pass
        @staticmethod
        def from_markup(s): return _FakeText()
    _rtext.Text = _FakeText

_rtheme = sys.modules["rich.theme"]
if not hasattr(_rtheme, "Theme"):
    _rtheme.Theme = lambda d=None: MagicMock()

_rstyle = sys.modules["rich.style"]
if not hasattr(_rstyle, "Style"):
    _rstyle.Style = MagicMock

# rich.box
_rbox = _stub("rich.box")
_rbox.SIMPLE = _rbox.ROUNDED = _rbox.SIMPLE_HEAVY = MagicMock()

# rich.columns
_rcols = sys.modules.get("rich.columns") or _stub("rich.columns")
if not hasattr(_rcols, "Columns"):
    _rcols.Columns = lambda *a, **kw: a

# rich.align
_ralign = sys.modules.get("rich.align") or _stub("rich.align")
if not hasattr(_ralign, "Align"):
    class _Align:
        @staticmethod
        def center(x): return x
    _ralign.Align = _Align

# rich.rule
_rrule = sys.modules.get("rich.rule") or _stub("rich.rule")
if not hasattr(_rrule, "Rule"):
    _rrule.Rule = MagicMock

# rich.prompt
_rp = sys.modules.get("rich.prompt") or _stub("rich.prompt")
if not hasattr(_rp, "Prompt"):
    class _FakePrompt:
        @staticmethod
        def ask(*a, **kw): return ""
    _rp.Prompt = _FakePrompt
if not hasattr(_rp, "Confirm"):
    class _FakeConfirm:
        @staticmethod
        def ask(*a, **kw): return False
    _rp.Confirm = _FakeConfirm


# ─────────────────────────────────────────────────────────────────────────────
# Minimal stub registry
# ─────────────────────────────────────────────────────────────────────────────

class _Meta:
    def __init__(self, name, cat="web", stage=2, passive=False):
        self.class_name    = name + "Tool"
        self.name          = name
        self.binary        = name.lower()
        self.category      = cat
        self.stage         = stage
        self.passive       = passive
        self.priority      = 50
        self.timeout       = 60
        self.install_cmd   = f"pip install {name.lower()}"
        self.dependencies  = []
        self.tags          = [cat]
        self.supported_inputs = ["domain"]
        self.description   = f"Fake {name} for testing."
        self.module_path   = "tools.test"
        self.available     = True
        self.instance      = None

        @property
        def is_available(self): return True

    @property
    def is_available(self): return True


class _FakeRegistry:
    def __init__(self):
        self._tools = {
            "NmapTool":    _Meta("Nmap",    "network"),
            "HttpxTool":   _Meta("Httpx",   "web"),
            "KatanaTool":  _Meta("Katana",  "web"),
            "SubfinderTool": _Meta("Subfinder", "subdomain"),
        }

    def get(self, cn):           return self._tools.get(cn)
    def all(self):               return list(self._tools.values())
    def by_category(self, cat):  return [t for t in self._tools.values() if t.category == cat]
    def search(self, q):         return [t for t in self._tools.values() if q.lower() in t.name.lower()]
    def categories(self):        return sorted({t.category for t in self._tools.values()})
    def count(self):             return len(self._tools)


# ─────────────────────────────────────────────────────────────────────────────
# 1. Dashboard
# ─────────────────────────────────────────────────────────────────────────────

class TestDashboard(unittest.TestCase):

    def _load(self):
        for prefix in ("reconx.", ""):
            try:
                from reconx.tui.dashboard import Dashboard, MENU_ITEMS, QUICK_ACTIONS
                return Dashboard, MENU_ITEMS, QUICK_ACTIONS
            except ModuleNotFoundError:
                from tui.dashboard import Dashboard, MENU_ITEMS, QUICK_ACTIONS
                return Dashboard, MENU_ITEMS, QUICK_ACTIONS
        self.fail("Cannot import dashboard")

    def test_imports(self):
        Dashboard, *_ = self._load()
        self.assertTrue(callable(Dashboard))

    def test_menu_has_8_items(self):
        _, MENU_ITEMS, _ = self._load()
        self.assertGreaterEqual(len(MENU_ITEMS), 8)

    def test_quick_actions_have_5_items(self):
        _, _, QUICK_ACTIONS = self._load()
        self.assertGreaterEqual(len(QUICK_ACTIONS), 5)

    def test_dashboard_instantiates(self):
        Dashboard, *_ = self._load()
        reg = _FakeRegistry()
        d = Dashboard(registry=reg)
        self.assertIsNotNone(d)

    def test_menu_keys_unique(self):
        _, MENU_ITEMS, _ = self._load()
        keys = [k for k, *_ in MENU_ITEMS]
        self.assertEqual(len(keys), len(set(keys)))

    def test_quit_option_present(self):
        _, MENU_ITEMS, _ = self._load()
        quit_keys = [k for k, *_ in MENU_ITEMS if "q" in k.lower()]
        self.assertGreater(len(quit_keys), 0)


# ─────────────────────────────────────────────────────────────────────────────
# 2. Tool Browser
# ─────────────────────────────────────────────────────────────────────────────

class TestToolBrowser(unittest.TestCase):

    def _load(self):
        for prefix in ("reconx.", ""):
            try:
                from reconx.tui.tool_browser import ToolBrowser, CATEGORIES
            except ModuleNotFoundError:
                from tui.tool_browser import ToolBrowser, CATEGORIES
        return ToolBrowser, CATEGORIES

    def test_imports(self):
        ToolBrowser, _ = self._load()
        self.assertTrue(callable(ToolBrowser))

    def test_has_17_plus_categories(self):
        _, CATEGORIES = self._load()
        self.assertGreaterEqual(len(CATEGORIES), 14)

    def test_browser_instantiates(self):
        ToolBrowser, _ = self._load()
        tb = ToolBrowser(registry=_FakeRegistry())
        self.assertIsNotNone(tb)

    def test_count_in_category(self):
        ToolBrowser, _ = self._load()
        tb = ToolBrowser(registry=_FakeRegistry())
        # "web" category has 2 fake tools
        count = tb._count_in_category("web")
        self.assertGreaterEqual(count, 2)

    def test_search_returns_results(self):
        ToolBrowser, _ = self._load()
        tb = ToolBrowser(registry=_FakeRegistry())
        # _search_mode is interactive; we test registry.search directly
        results = _FakeRegistry().search("nmap")
        self.assertGreater(len(results), 0)

    def test_avail_in_category(self):
        ToolBrowser, _ = self._load()
        tb = ToolBrowser(registry=_FakeRegistry())
        avail = tb._avail_in_category("network")
        self.assertGreaterEqual(avail, 0)


# ─────────────────────────────────────────────────────────────────────────────
# 3. Learning Mode
# ─────────────────────────────────────────────────────────────────────────────

class TestLearningMode(unittest.TestCase):

    def _load(self):
        try:
            from reconx.learning.tool_lessons import (
                LearningMode, LESSONS, TOOL_RELATIONSHIPS, ToolLesson, ToolRelationship
            )
        except ModuleNotFoundError:
            from learning.tool_lessons import (
                LearningMode, LESSONS, TOOL_RELATIONSHIPS, ToolLesson, ToolRelationship
            )
        return LearningMode, LESSONS, TOOL_RELATIONSHIPS, ToolLesson, ToolRelationship

    def test_imports(self):
        LM, *_ = self._load()
        self.assertTrue(callable(LM))

    def test_lessons_dict_not_empty(self):
        _, LESSONS, *_ = self._load()
        self.assertGreater(len(LESSONS), 0)

    def test_subfinder_lesson_present(self):
        _, LESSONS, *_ = self._load()
        self.assertIn("Subfinder", LESSONS)
        lesson = LESSONS["Subfinder"]
        self.assertTrue(lesson.problem_solved)
        self.assertTrue(lesson.how_it_works)
        self.assertGreater(len(lesson.examples), 0)

    def test_relationships_not_empty(self):
        _, _, RELS, *_ = self._load()
        self.assertGreater(len(RELS), 10)

    def test_all_relationships_have_reason(self):
        _, _, RELS, *_ = self._load()
        for rel in RELS:
            self.assertTrue(rel.reason, f"Relationship {rel.from_tool}→{rel.to_tool} missing reason")

    def test_lm_instantiates(self):
        LM, *_ = self._load()
        lm = LM(registry=_FakeRegistry())
        self.assertIsNotNone(lm)

    def test_all_lessons_called(self):
        LM, LESSONS, *_ = self._load()
        lm = LM(registry=_FakeRegistry())
        lessons = lm._all_lessons()
        self.assertGreaterEqual(len(lessons), len(LESSONS))

    def test_build_chains(self):
        LM, *_ = self._load()
        lm = LM()
        chains = lm._build_chains()
        self.assertEqual(len(chains), 7)
        # Each chain should be a list
        for chain in chains:
            self.assertIsInstance(chain, list)


# ─────────────────────────────────────────────────────────────────────────────
# 4. Guided View
# ─────────────────────────────────────────────────────────────────────────────

class TestGuidedView(unittest.TestCase):

    def _load(self):
        try:
            from reconx.tui.guided_view import GuidedReconView, GuidedSession, STEP_EXPLANATIONS
        except ModuleNotFoundError:
            from tui.guided_view import GuidedReconView, GuidedSession, STEP_EXPLANATIONS
        return GuidedReconView, GuidedSession, STEP_EXPLANATIONS

    def test_imports(self):
        GRV, *_ = self._load()
        self.assertTrue(callable(GRV))

    def test_step_explanations_not_empty(self):
        _, _, EXPL = self._load()
        self.assertGreater(len(EXPL), 15)

    def test_6_modes(self):
        GRV, *_ = self._load()
        grv = GRV()
        self.assertGreaterEqual(len(grv.MODES), 6)

    def test_session_dataclass(self):
        _, GuidedSession, _ = self._load()
        sess = GuidedSession(
            target="example.com", target_type="domain",
            mode="fast", tool_list=["NmapTool"],
        )
        self.assertEqual(sess.target, "example.com")
        self.assertEqual(sess.completed, [])

    def test_guided_view_instantiates(self):
        GRV, *_ = self._load()
        grv = GRV(registry=_FakeRegistry())
        self.assertIsNotNone(grv)

    def test_classify_domain(self):
        GRV, *_ = self._load()
        grv = GRV()
        ct = grv._classify("example.com")
        self.assertEqual(ct.target_type, "domain")


# ─────────────────────────────────────────────────────────────────────────────
# 5. Execution View
# ─────────────────────────────────────────────────────────────────────────────

class TestExecutionView(unittest.TestCase):

    def _load(self):
        try:
            from reconx.tui.execution_view import ExecutionView, QUICK_ACTIONS
        except ModuleNotFoundError:
            from tui.execution_view import ExecutionView, QUICK_ACTIONS
        return ExecutionView, QUICK_ACTIONS

    def test_imports(self):
        EV, _ = self._load()
        self.assertTrue(callable(EV))

    def test_7_quick_actions(self):
        _, QA = self._load()
        self.assertGreaterEqual(len(QA), 5)

    def test_all_actions_have_mode(self):
        _, QA = self._load()
        for key, action in QA.items():
            self.assertIn("mode", action, f"Action {key} missing 'mode'")

    def test_all_actions_have_desc(self):
        _, QA = self._load()
        for key, action in QA.items():
            self.assertTrue(action.get("desc") or action.get("label"),
                            f"Action {key} missing description")

    def test_instantiates_no_engine(self):
        EV, _ = self._load()
        ev = EV(registry=_FakeRegistry())
        self.assertIsNotNone(ev)


# ─────────────────────────────────────────────────────────────────────────────
# 6. Navigator
# ─────────────────────────────────────────────────────────────────────────────

class TestNavigator(unittest.TestCase):

    def _load(self):
        try:
            from reconx.tui.navigator import Navigator, THEMES, STATUS_ICONS, ASCII_BANNERS
        except ModuleNotFoundError:
            from tui.navigator import Navigator, THEMES, STATUS_ICONS, ASCII_BANNERS
        return Navigator, THEMES, STATUS_ICONS, ASCII_BANNERS

    def test_imports(self):
        N, *_ = self._load()
        self.assertTrue(callable(N))

    def test_five_themes(self):
        _, THEMES, *_ = self._load()
        self.assertGreaterEqual(len(THEMES), 5)
        for name, theme in THEMES.items():
            self.assertEqual(theme.name.split("(")[0].strip().lower(),
                             name if name != "green" else "matrix green" if "matrix" in theme.name.lower() else name)

    def test_themes_have_required_attrs(self):
        _, THEMES, *_ = self._load()
        required = ["accent", "danger", "warn", "success", "border"]
        for name, theme in THEMES.items():
            for attr in required:
                self.assertTrue(hasattr(theme, attr),
                                f"Theme '{name}' missing attr: {attr}")

    def test_status_icons_complete(self):
        _, _, STATUS_ICONS, _ = self._load()
        required_statuses = {"RUNNING", "SUCCESS", "FAILED", "MISSING",
                              "SKIPPED", "PENDING", "OK"}
        for s in required_statuses:
            self.assertIn(s, STATUS_ICONS, f"Missing status icon: {s}")

    def test_ascii_banners_present(self):
        _, _, _, BANNERS = self._load()
        self.assertIn("full", BANNERS)
        self.assertIn("compact", BANNERS)

    def test_navigator_instantiates(self):
        N, *_ = self._load()
        nav = N(theme_name="dark", registry=_FakeRegistry())
        self.assertIsNotNone(nav)

    def test_default_theme_is_dark(self):
        N, *_ = self._load()
        nav = N()
        self.assertEqual(nav.theme_name, "dark")

    def test_theme_change(self):
        N, *_ = self._load()
        nav = N(theme_name="dark")
        nav.theme_name = "neon"
        self.assertEqual(nav.theme_name, "neon")


# ─────────────────────────────────────────────────────────────────────────────
# 7. Quick Action Bar
# ─────────────────────────────────────────────────────────────────────────────

class TestQuickActionBar(unittest.TestCase):

    def _load(self):
        try:
            from reconx.tui.widgets.quick_action_bar import (
                QuickActionBar, StatusBar, QUICK_ACTION_DEFS
            )
        except ModuleNotFoundError:
            from tui.widgets.quick_action_bar import (
                QuickActionBar, StatusBar, QUICK_ACTION_DEFS
            )
        return QuickActionBar, StatusBar, QUICK_ACTION_DEFS

    def test_imports(self):
        QAB, *_ = self._load()
        self.assertTrue(callable(QAB))

    def test_7_action_defs(self):
        _, _, DEFS = self._load()
        self.assertGreaterEqual(len(DEFS), 7)

    def test_all_defs_have_key_label(self):
        _, _, DEFS = self._load()
        for d in DEFS:
            self.assertIn("key", d)
            self.assertIn("label", d)
            self.assertIn("tools", d)

    def test_instantiates_compact_and_full(self):
        QAB, *_ = self._load()
        self.assertIsNotNone(QAB(compact=False))
        self.assertIsNotNone(QAB(compact=True))

    def test_status_bar_instantiates(self):
        _, SB, _ = self._load()
        sb = SB(registry=_FakeRegistry())
        self.assertIsNotNone(sb)


# ─────────────────────────────────────────────────────────────────────────────
# 8. Report 14
# ─────────────────────────────────────────────────────────────────────────────

class TestReport14(unittest.TestCase):

    def _load(self):
        try:
            from reconx.output.report_14 import (
                generate_stage14_sections, inject_into_report,
                STAGE14_CSS, _STEP_NOTES
            )
        except ModuleNotFoundError:
            from output.report_14 import (
                generate_stage14_sections, inject_into_report,
                STAGE14_CSS, _STEP_NOTES
            )
        return generate_stage14_sections, inject_into_report, STAGE14_CSS, _STEP_NOTES

    def test_imports(self):
        gen, *_ = self._load()
        self.assertTrue(callable(gen))

    def test_step_notes_not_empty(self):
        _, _, _, NOTES = self._load()
        self.assertGreater(len(NOTES), 10)

    def test_generate_returns_html(self):
        gen, *_ = self._load()
        tasks = [
            {"tool_class": "NmapTool", "status": "success", "duration_s": 12.3, "finding_count": 5, "error": ""},
            {"tool_class": "HttpxTool", "status": "failed",  "duration_s": 3.1,  "finding_count": 0, "error": "timeout"},
        ]
        html = gen(["NmapTool", "HttpxTool"], tasks, {})
        self.assertIn("<section", html)
        self.assertIn("NmapTool", html)
        self.assertIn("HttpxTool", html)
        self.assertIn("success", html.lower())
        self.assertIn("failed",  html.lower())

    def test_css_contains_workflow_chain(self):
        _, _, CSS, _ = self._load()
        self.assertIn("workflow-chain", CSS)
        self.assertIn("timeline", CSS)
        self.assertIn("learn-note", CSS)

    def test_inject_nonexistent_file_returns_false(self):
        _, inject, *_ = self._load()
        result = inject("/nonexistent/path/report.html", [], [], {})
        self.assertFalse(result)

    def test_inject_into_real_file(self):
        import tempfile, os
        _, inject, *_ = self._load()
        html = "<html><head></head><body><p>Test</p></body></html>"
        with tempfile.NamedTemporaryFile(suffix=".html", delete=False, mode="w") as f:
            f.write(html)
            tmp = f.name
        try:
            result = inject(tmp, ["NmapTool"], [
                {"tool_class": "NmapTool", "status": "success",
                 "duration_s": 5.0, "finding_count": 3, "error": ""}
            ], {})
            self.assertTrue(result)
            content = open(tmp).read()
            self.assertIn("workflow", content)
            self.assertIn("NmapTool", content)
        finally:
            os.unlink(tmp)


# ─────────────────────────────────────────────────────────────────────────────
# 9. App entry point
# ─────────────────────────────────────────────────────────────────────────────

class TestAppEntry(unittest.TestCase):

    def test_build_app_returns_navigator(self):
        try:
            from reconx.tui.app import build_app
        except ModuleNotFoundError:
            from tui.app import build_app
        # With no real packages, registry init will fail gracefully
        try:
            nav = build_app(theme="dark")
            self.assertIsNotNone(nav)
            self.assertEqual(nav.theme_name, "dark")
        except SystemExit:
            pass  # acceptable if Rich/Navigator can't init in headless CI

    def test_main_version_flag(self):
        try:
            from reconx.tui.app import main
        except ModuleNotFoundError:
            from tui.app import main
        # --version should print and return without SystemExit
        with patch("sys.stdout", new_callable=StringIO) as mock_out:
            try:
                main(["--version"])
            except SystemExit:
                pass
            # If it printed something, that's fine

    def test_quick_action_keys_valid(self):
        try:
            from reconx.tui.execution_view import QUICK_ACTIONS
        except ModuleNotFoundError:
            from tui.execution_view import QUICK_ACTIONS
        # All keys should be lowercase 2-letter codes
        for key in QUICK_ACTIONS:
            self.assertEqual(key, key.lower())
            self.assertGreaterEqual(len(key), 2)


if __name__ == "__main__":
    import os
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    unittest.main(verbosity=2)
