# ReconX — Stage 19 Changelog: Plugin SDK Foundation

## Overview

Stage 19 transforms ReconX from a collection of hardcoded tool calls into a
**universal plugin ecosystem**. Every tool now has a formal identity, a typed
capability declaration, and a standard interface. The execution engine and
all existing tools continue working identically — Stage 19 is purely additive.

**Before Stage 19:**
```python
if tool == "nmap":
    run_nmap()
```

**After Stage 19:**
```python
tool = registry.get("Nmap")
tool.run(target)              # same behaviour, universal interface
tool.metadata()               # who am I?
tool.capabilities()           # what can I do?
tool.healthcheck()            # am I ready?
```

---

## New Files (18)

### `sdk/contracts.py` — Typed Data Contracts

The single source of truth for all plugin data structures.

| Type | Purpose |
|---|---|
| `ToolMetadata` | Full 20-field schema for every plugin |
| `Capability` | One named ability with slug + description |
| `CapabilitySet` | Typed collection of a tool's capabilities |
| `PluginPermissions` | System resource requirements (root, network, docker) |
| `RiskLevel` | PASSIVE → LOW → MEDIUM → HIGH → CRITICAL |
| `InstallMethod` | apt / brew / go / pip / cargo / binary / docker / manual |
| `InputType` | domain / ip / cidr / url / asn / email / file / pcap |
| `OutputType` | subdomains / ports / services / urls / credentials / findings |

`ToolMetadata.validate()` — returns list of errors, empty = valid.
`ToolMetadata.to_dict()` — JSON-serialisable, used by CLI and registry.

---

### `sdk/base_tool.py` — `PluginBaseTool`

Extends the existing `BaseTool` (never modifies it) with the full Stage 19
interface:

| Method | Purpose |
|---|---|
| `metadata()` | Return full `ToolMetadata` |
| `capabilities()` | Return `CapabilitySet` |
| `permissions()` | Return `PluginPermissions` |
| `healthcheck()` | Check binary availability + version, return `HealthStatus` |
| `check()` | Quick bool availability check |
| `install()` | Run install_cmd via subprocess |
| `name()` / `description()` / `category()` | Explicit method interface |
| `validate(target)` | Alias for `validate_or_fail()` |

**Auto-sync magic (`__init_subclass__`):** When a subclass defines `METADATA`,
the legacy `BaseTool` class constants (`NAME`, `BINARY`, `CATEGORY`, `STAGE`,
`PRIORITY`, `PASSIVE`, `TIMEOUT`, `INSTALL_CMD`) are automatically populated
from `METADATA`. Existing engine code that reads `tool.NAME` keeps working.

**`HealthStatus`:** `name`, `available`, `version`, `error`, `latency_ms` — `.ok`, `.summary()`.

---

### `sdk/metadata.py` — Metadata Helpers

| Export | Purpose |
|---|---|
| `CAPABILITIES` | 40+ standard capability slug constants |
| `COMMON_CAPS` | Pre-built `CapabilitySet` bundles per tool type |
| `ToolMetadataBuilder` | Fluent builder for `ToolMetadata` |
| `make_metadata()` | One-shot factory function |

**`CAPABILITIES` constants (selected):**
`PORT_SCAN`, `UDP_SCAN`, `OS_DETECTION`, `SERVICE_DETECTION`, `SUBDOMAIN_ENUM`,
`DNS_BRUTE`, `ASN_INTEL`, `WEB_CRAWL`, `HTTP_PROBE`, `TLS_SCAN`, `CERT_ENUM`,
`JA3_FINGERPRINT`, `WHOIS`, `SECRET_SCAN`, `CREDENTIAL_DETECT`, `PCAP_ANALYSIS`,
`LIVE_CAPTURE`, `ANOMALY_DETECT`, `DNS_TUNNEL_DETECT`, `PROXY_CAPTURE`,
`SESSION_REPLAY`, `VULN_SCAN`, `API_DISCOVERY`, `GRAPHQL_DETECT` + 16 more.

**`COMMON_CAPS` bundles:**
`port_scanner()`, `subdomain_enumerator()`, `web_crawler()`, `http_prober()`, `traffic_analyzer()`

**`ToolMetadataBuilder` fluent API:**
```python
meta = (ToolMetadataBuilder("Nmap", "Network mapper")
    .category("network")
    .binary("nmap")
    .stage(3)
    .risk(RiskLevel.HIGH)
    .permissions(requires_root=True)
    .capabilities(COMMON_CAPS.port_scanner()
        .add(CAPABILITIES.OS_DETECTION, "OS fingerprinting"))
    .install(InstallMethod.APT, "sudo apt install nmap")
    .tags("network", "active")
    .example("nmap -sV -O 192.168.1.0/24")
    .build())
```

---

### `core/capability_map.py` — `CapabilityEngine`

Central capability → tool index.

| Method | Purpose |
|---|---|
| `register(tool)` | Index all capabilities from a `PluginBaseTool` instance |
| `register_from_metadata(name, caps)` | Index from metadata (no live instance needed) |
| `tools_for(capability)` | All tool names with a given capability slug |
| `tools_for_all(capabilities)` | Tool names with ALL listed capabilities |
| `tools_for_any(capabilities)` | Tool names with ANY listed capability |
| `caps_for_tool(name)` | Capabilities of a given tool |
| `capability_map()` | Full `{cap_slug: [tool_names]}` dict |
| `tool_capability_matrix()` | List of `{tool, capabilities, category}` rows |
| `summary()` | `{total_tools, total_capabilities, ...}` |

Designed for AI-agent tool selection in Stage 20+.

---

### `core/registry.py` — `PluginRegistry`

Stage 19 central registry wrapping the existing `ToolRegistry`.

| Method | Purpose |
|---|---|
| `register_plugin(cls)` | Register a `PluginBaseTool` class |
| `register_instance(tool)` | Register a live instance |
| `register_legacy(descriptor)` | Wrap legacy `ToolDescriptor` as `PluginRecord` |
| `get(name)` | Return `PluginRecord` by name |
| `info(name)` | Return `ToolMetadata` by name |
| `list(category?)` | All records, optionally filtered, sorted by stage+priority |
| `search(capability)` | Records that have a capability |
| `category(cat)` | Records in a category |
| `all_categories()` | Sorted list of categories |
| `capability_map()` | Delegate to `CapabilityEngine` |
| `stats()` | `{total, available, legacy, plugins, categories, capabilities, errors}` |

**`PluginRecord`** holds: `metadata`, `plugin_cls`, `instance`, `is_legacy`, `enabled`, `load_error`. Plus `available`, `installed`, `status_icon()`, `to_row()`.

**Singleton:** `get_plugin_registry()` returns the global instance.

---

### `core/plugin_loader.py` — `PluginLoader`

Auto-discovery and dynamic loading of `PluginBaseTool` subclasses.

**Discovery algorithm per directory:**
```
plugins/
  nmap/         → scan for plugin.py or __init__.py
  amass/        → scan for plugin.py or __init__.py
  ...
```

**Load sequence per file:**
1. `importlib.util.spec_from_file_location()` — dynamic import
2. `inspect.getmembers(module, inspect.isclass)` — find classes
3. `issubclass(cls, PluginBaseTool)` — filter to plugins
4. `meta.validate()` — validate `ToolMetadata`
5. `_check_dependencies(meta.dependencies)` — verify pip packages
6. `cls()` — instantiate
7. `registry.register_instance(instance)` — register

**Error isolation:** Every step is independently try-caught. A broken plugin
never crashes ReconX — it appears in `result.failed` with its error message.

**Error types:** `PluginLoadError`, `DependencyError`, `ToolValidationError`, `RegistryError`

**`PluginLoadResult`:** `discovered`, `loaded`, `failed`, `skipped`, `errors`, `.ok`, `.summary()`

---

### `core/plugin_manager.py` — `PluginManager`

Top-level orchestrator — the single public interface for Stage 19 operations.

**Bootstrap sequence:**
```
bootstrap()
  ↓ PluginLoader.load_all()     (scan plugins/ directories)
  ↓ _backfill_legacy()          (wrap existing ToolDescriptors)
  ↓ marked bootstrapped=True
```

Bootstrap is idempotent — safe to call multiple times.

| Method | Purpose |
|---|---|
| `bootstrap(backfill_legacy?)` | Full startup sequence |
| `reload()` | Force full reload |
| `list(category?)` | Delegate to registry |
| `info(name)` | Full metadata dict |
| `search(capability)` | Capability-based tool lookup |
| `category(cat)` | Category filter |
| `capabilities()` | Full capability map |
| `healthcheck(name?)` | Health check one or all tools |
| `stats()` | Registry stats + `bootstrapped`, `boot_duration_s` |

**Singleton:** `get_plugin_manager()` returns the global instance.

---

### `plugins/nmap/plugin.py` — `NmapPlugin`

```
category: network/port_scanning | stage: 3 | risk: HIGH | passive: False
binary:   nmap                  | requires_root: True
capabilities: port_scan, udp_scan, os_detection, service_detection,
              version_detection, host_discovery, traceroute, vuln_scan
inputs:  ip, domain, cidr       | outputs: ports, services, ips
```

Wraps `tools/scanning/nmap_tool.py` — `NmapTool.safe_run()` unchanged.

---

### `plugins/amass/plugin.py` — `AmassPlugin`

```
category: subdomain/passive_enum | stage: 2 | risk: PASSIVE | passive: True
binary:   amass
capabilities: subdomain_enumeration, dns_resolution, asn_intelligence,
              reverse_dns, certificate_enumeration
inputs: domain | outputs: subdomains, ips, domains
```

Wraps `tools/amass.py` — `AmassTool.run()` unchanged.

---

### `plugins/subfinder/plugin.py` — `SubfinderPlugin`

```
category: subdomain/passive_enum | stage: 2 | risk: PASSIVE | passive: True
binary:   subfinder
capabilities: subdomain_enumeration, dns_resolution, dns_wildcard_detection
inputs: domain | outputs: subdomains, domains
```

Tries existing tool wrappers first, falls back to direct subprocess.

---

### `plugins/httpx/plugin.py` — `HTTPXPlugin`

```
category: web/http_probe | stage: 3 | risk: LOW | passive: False
binary:   httpx
capabilities: http_probe, technology_detection, tls_scan, waf_detection, screenshot
inputs: domain, ip, url | outputs: urls, headers, findings
```

Wraps `tools/httpx_tool.py` — `HTTPXTool.safe_run()` unchanged.

---

### `plugins/whois/plugin.py` — `WhoisPlugin`

```
category: osint/domain_intel | stage: 1 | risk: PASSIVE | passive: True
binary:   whois
capabilities: whois_lookup, asn_intelligence, org_intelligence, reverse_dns
inputs: domain, ip | outputs: findings, domains
```

Wraps `tools/whois_tool.py` — `WhoisTool.safe_run()` unchanged.

---

### `plugins/dns/plugin.py` — `DNSPlugin`

```
category: dns/dns_intel | stage: 2 | risk: LOW | passive: False
binary:   dnsx (fallback: massdns → dig)
capabilities: dns_resolution, dns_bruteforce, dns_wildcard_detection,
              zone_transfer, reverse_dns
inputs: domain, ip, cidr | outputs: subdomains, ips, domains
```

Tries DNSX → MassDNS → system dig in priority order.

---

### `cli/tools_commands.py` — Stage 19 CLI

```bash
reconx tools list                        # All plugins with status table
reconx tools list --category network     # Filter by category
reconx tools info nmap                   # Full metadata panel
reconx tools category                    # Category → tool-count table
reconx tools capabilities                # Capability → tool map
reconx tools search port_scan            # Find tools by capability
reconx tools health                      # Check all tool binaries
reconx tools health nmap                 # Single tool healthcheck
```

All commands produce Rich-formatted terminal output matching the existing
ReconX colour scheme (bold red borders, cyan/yellow accents).

---

## Test Suite

### `tests/test_stage19_plugins.py` — 70 passed, 11 skipped

**Results: 70/70 passing (0 failures) in 0.21s**
*(11 skipped = plugin files load fine but underlying tool binaries not installed in test env)*

| Class | Tests | Coverage |
|---|---|---|
| `TestContracts` | 12 | ToolMetadata defaults, validate, to_dict, CapabilitySet ops, Capability equality, PluginPermissions, enums |
| `TestPluginBaseTool` | 11 | metadata/capabilities/permissions methods, name/description/category, check, healthcheck (no binary, missing binary), auto-sync, install |
| `TestMetadataHelpers` | 6 | CAPABILITIES constants, COMMON_CAPS bundles, builder valid, builder invalid, make_metadata factory |
| `TestCapabilityEngine` | 8 | register + find, tools_for_all, tools_for_any, unknown cap, sorted caps, map structure, summary, from_metadata |
| `TestPluginRegistry` | 9 | register instance, list, category filter, search by cap, info, get unknown, stats, all_categories, to_row |
| `TestPluginLoader` | 6 | empty dir, valid plugin file, broken plugin isolated, error classes, load_result summary, ok property |
| `TestPluginManager` | 8 | bootstrap result, idempotent, list, search empty, stats, capabilities, get nonexistent, healthcheck |
| `TestPluginMetadata` | 11 | metadata valid per plugin, capabilities present, legacy constants synced, to_dict serialisable |
| `TestCLIToolsCommands` | 10 | dispatch routing, missing args, all commands no-crash |

---

## Combined Results: Stages 18 + 18.1 + 18.2 + 19

| Stage | Tests | Status |
|---|---|---|
| Stage 18 / 18.1 — Burp Intelligence | 77 | ✓ all pass |
| Stage 18.2 — Traffic Intelligence | 87 | ✓ all pass |
| Stage 19 — Plugin SDK | 70 | ✓ all pass, 11 skipped (no binary) |
| **Total** | **234 passed** | **0 failures** |

---

## Architecture

```
reconx/
│
├── sdk/                          ← Plugin developer API
│   ├── contracts.py              ← ToolMetadata, CapabilitySet, etc.
│   ├── base_tool.py              ← PluginBaseTool (extends BaseTool)
│   ├── metadata.py               ← CAPABILITIES, COMMON_CAPS, Builder
│   └── __init__.py               ← Public exports
│
├── core/                         ← Plugin system infrastructure
│   ├── capability_map.py         ← CapabilityEngine
│   ├── registry.py               ← PluginRegistry + PluginRecord
│   ├── plugin_loader.py          ← Auto-discovery + dynamic import
│   ├── plugin_manager.py         ← Orchestrator + bootstrap
│   └── __init__.py               ← Public exports + error types
│
├── plugins/                      ← Plugin directory (auto-scanned)
│   ├── nmap/plugin.py            ← NmapPlugin
│   ├── amass/plugin.py           ← AmassPlugin
│   ├── subfinder/plugin.py       ← SubfinderPlugin
│   ├── httpx/plugin.py           ← HTTPXPlugin
│   ├── whois/plugin.py           ← WhoisPlugin
│   └── dns/plugin.py             ← DNSPlugin
│
└── cli/tools_commands.py         ← reconx tools list/info/category/capabilities/search/health
```

---

## Backward Compatibility

Stage 19 is **100% additive** — zero existing files modified.

| Existing component | Status |
|---|---|
| `tools/base.py` — `BaseTool` | Unchanged |
| `engine/registry.py` — `ToolRegistry` | Unchanged |
| `plugins/manager.py` — `PluginManager` | Unchanged (Stage 15) |
| `plugins/sdk.py` — existing SDK | Unchanged |
| `ExecutionEngine` | Unchanged |
| All existing tool classes | Unchanged |
| All existing scan workflows | Unchanged |

Legacy tools appear in Stage 19 registry as `is_legacy=True` entries via
`_backfill_legacy()` — they get a synthetic `ToolMetadata` and show up in
`reconx tools list` alongside new Stage 19 plugins.

---

## Drop-in Plugin Guide

Adding a new tool in Stage 20+ requires only:

```
plugins/
  mytool/
    plugin.py          ← One file
```

```python
# plugins/mytool/plugin.py
from reconx.sdk import PluginBaseTool, ToolMetadataBuilder, CAPABILITIES, COMMON_CAPS

class MyTool(PluginBaseTool):
    METADATA = (
        ToolMetadataBuilder("MyTool", "Does something useful")
        .category("network")
        .binary("mytool")
        .stage(3)
        .capabilities(COMMON_CAPS.port_scanner())
        .install(InstallMethod.APT, "sudo apt install mytool")
        .build()
    )

    def run(self, target, **kwargs):
        # ... subprocess call ...
        return self.build_result(data={...}, findings=[...])

    def parse_output(self, raw, **kwargs):
        return {...}
```

ReconX discovers it automatically at next startup. No imports, no
registration calls, no config file changes required.
