"""
ReconX — Telemetry: Tool Health Monitor (Stage 13).

Tracks per-tool health metrics across ReconX sessions:
  • Availability (binary present / absent)
  • Version string (parsed from --version output)
  • Dependency satisfaction
  • Average runtime
  • Failure rate
  • Last-seen timestamps

Persists state to JSON on disk between sessions.
Exposes a formatted dashboard for the TUI.
"""
from __future__ import annotations

import json
import logging
import shutil
import subprocess
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Optional

log = logging.getLogger("reconx.telemetry.health")

_HEALTH_FILE = Path("cache/tool_health.json")

# Version flag to try per binary (first match wins)
_VERSION_FLAGS: list[str] = ["--version", "-version", "version", "-v", "--v"]


# ─────────────────────────────────────────────────────────────────────────────
# ToolHealthRecord
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class ToolHealthRecord:
    class_name:    str
    binary:        str
    category:      str
    available:     bool        = False
    version:       str         = ""
    install_cmd:   str         = ""
    deps_ok:       bool        = True
    missing_deps:  list[str]   = field(default_factory=list)
    total_runs:    int         = 0
    failed_runs:   int         = 0
    total_time_s:  float       = 0.0
    last_run_at:   float       = 0.0
    last_checked:  float       = 0.0
    last_error:    str         = ""

    # ── derived properties ────────────────────────────────────────────────────

    @property
    def failure_rate(self) -> float:
        if not self.total_runs:
            return 0.0
        return self.failed_runs / self.total_runs

    @property
    def avg_runtime_s(self) -> float:
        if not self.total_runs:
            return 0.0
        return self.total_time_s / self.total_runs

    @property
    def status_label(self) -> str:
        if not self.available:
            return "MISSING"
        if not self.deps_ok:
            return "DEP_ERROR"
        if self.failure_rate > 0.5:
            return "DEGRADED"
        return "OK"

    @property
    def status_colour(self) -> str:
        return {
            "OK":        "green",
            "MISSING":   "yellow",
            "DEP_ERROR": "red",
            "DEGRADED":  "orange3",
        }.get(self.status_label, "white")

    def record_run(self, duration_s: float, failed: bool, error: str = "") -> None:
        self.total_runs   += 1
        self.total_time_s += duration_s
        self.last_run_at   = time.time()
        if failed:
            self.failed_runs += 1
            self.last_error   = error[:200]

    def to_dict(self) -> dict:
        return asdict(self)


# ─────────────────────────────────────────────────────────────────────────────
# ToolHealthMonitor
# ─────────────────────────────────────────────────────────────────────────────

class ToolHealthMonitor:
    """
    Maintains a health record for every registered tool.

    Usage:
        monitor = ToolHealthMonitor.load()
        monitor.probe_all(registry)
        monitor.record_run("NmapTool", duration_s=12.3, failed=False)
        monitor.save()
        print(monitor.dashboard_text())
    """

    def __init__(self, records: Optional[dict[str, ToolHealthRecord]] = None):
        self._records: dict[str, ToolHealthRecord] = records or {}

    # ── persistence ───────────────────────────────────────────────────────────

    @classmethod
    def load(cls, path: Path = _HEALTH_FILE) -> "ToolHealthMonitor":
        if path.exists():
            try:
                raw = json.loads(path.read_text())
                records = {k: ToolHealthRecord(**v) for k, v in raw.items()}
                return cls(records)
            except Exception as e:
                log.warning(f"Health file corrupted — starting fresh: {e}")
        return cls()

    def save(self, path: Path = _HEALTH_FILE) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        try:
            path.write_text(
                json.dumps({k: v.to_dict() for k, v in self._records.items()}, indent=2)
            )
        except Exception as e:
            log.warning(f"Could not save health file: {e}")

    # ── probing ───────────────────────────────────────────────────────────────

    def probe_all(self, registry, force: bool = False) -> dict[str, ToolHealthRecord]:
        """
        Probe every tool in the registry.
        Skips tools checked within the last hour unless force=True.
        """
        for meta in registry.all():
            rec = self._ensure_record(meta)
            age = time.time() - rec.last_checked
            if not force and age < 3600:
                continue
            self._probe_one(rec, meta)
        self.save()
        return dict(self._records)

    def probe_tool(self, class_name: str, registry) -> Optional[ToolHealthRecord]:
        meta = registry.get(class_name)
        if not meta:
            return None
        rec = self._ensure_record(meta)
        self._probe_one(rec, meta)
        self.save()
        return rec

    def _probe_one(self, rec: ToolHealthRecord, meta) -> None:
        rec.last_checked = time.time()

        # Check binary on PATH
        binary_path = shutil.which(rec.binary)
        rec.available = bool(binary_path)

        if rec.available:
            rec.version = self._get_version(rec.binary)

        # Check declared dependencies
        missing = []
        for dep in getattr(meta, "dependencies", []):
            if dep and not shutil.which(dep):
                missing.append(dep)
        rec.missing_deps = missing
        rec.deps_ok      = not missing

        log.debug(f"Probed {rec.class_name}: available={rec.available} version={rec.version!r}")

    @staticmethod
    def _get_version(binary: str) -> str:
        for flag in _VERSION_FLAGS:
            try:
                result = subprocess.run(
                    [binary, flag],
                    capture_output=True, text=True, timeout=5,
                )
                output = (result.stdout + result.stderr).strip()
                # Extract first version-like token
                import re
                m = re.search(r"(\d+\.\d+[\.\d]*)", output)
                if m:
                    return m.group(1)
            except Exception:
                continue
        return ""

    # ── telemetry recording ───────────────────────────────────────────────────

    def record_run(
        self,
        class_name: str,
        duration_s: float,
        failed:     bool,
        error:      str = "",
    ) -> None:
        rec = self._records.get(class_name)
        if not rec:
            log.debug(f"record_run: no health record for {class_name}")
            return
        rec.record_run(duration_s, failed, error)

    # ── accessors ─────────────────────────────────────────────────────────────

    def get(self, class_name: str) -> Optional[ToolHealthRecord]:
        return self._records.get(class_name)

    def all_records(self) -> list[ToolHealthRecord]:
        return list(self._records.values())

    def available_tools(self) -> list[ToolHealthRecord]:
        return [r for r in self._records.values() if r.available]

    def missing_tools(self) -> list[ToolHealthRecord]:
        return [r for r in self._records.values() if not r.available]

    def degraded_tools(self) -> list[ToolHealthRecord]:
        return [r for r in self._records.values() if r.failure_rate > 0.3]

    # ── dashboard ─────────────────────────────────────────────────────────────

    def dashboard_text(self, max_rows: int = 60) -> str:
        """Return a formatted plain-text health dashboard."""
        rows = sorted(self._records.values(), key=lambda r: (r.category, r.class_name))
        width_name   = max((len(r.class_name) for r in rows), default=20)
        width_status = 10

        lines = [
            "╔══ ReconX Tool Health Dashboard ══════════════════════════════╗",
            f"  {'Tool':<{width_name}}  {'Status':<{width_status}}  {'Version':<12}  "
            f"{'Runs':>5}  {'Fail%':>5}  {'Avg(s)':>6}",
            "  " + "─" * (width_name + 45),
        ]

        current_cat = ""
        for rec in rows[:max_rows]:
            if rec.category != current_cat:
                current_cat = rec.category
                lines.append(f"\n  ── {current_cat.upper()} ──")

            pct  = f"{rec.failure_rate * 100:.0f}%" if rec.total_runs else "—"
            avg  = f"{rec.avg_runtime_s:.1f}"        if rec.total_runs else "—"
            ver  = rec.version[:10] if rec.version else "—"
            runs = str(rec.total_runs) if rec.total_runs else "—"
            lines.append(
                f"  {rec.class_name:<{width_name}}  {rec.status_label:<{width_status}}  "
                f"{ver:<12}  {runs:>5}  {pct:>5}  {avg:>6}"
            )

        ok_count   = sum(1 for r in rows if r.status_label == "OK")
        miss_count = sum(1 for r in rows if r.status_label == "MISSING")
        lines.extend([
            "",
            f"  Total: {len(rows)} tools  |  OK: {ok_count}  |  Missing: {miss_count}",
            "╚══════════════════════════════════════════════════════════════╝",
        ])
        return "\n".join(lines)

    def install_guide(self) -> str:
        """Return install commands for all missing tools."""
        missing = self.missing_tools()
        if not missing:
            return "All registered tools are installed."
        lines = ["Missing tools — install commands:", ""]
        for rec in sorted(missing, key=lambda r: r.category):
            lines.append(f"  [{rec.category}] {rec.class_name}")
            if rec.install_cmd:
                for cmd_line in rec.install_cmd.splitlines():
                    if cmd_line.strip():
                        lines.append(f"    {cmd_line.strip()}")
            lines.append("")
        return "\n".join(lines)

    # ── internal ──────────────────────────────────────────────────────────────

    def _ensure_record(self, meta) -> ToolHealthRecord:
        cn = meta.class_name
        if cn not in self._records:
            self._records[cn] = ToolHealthRecord(
                class_name  = cn,
                binary      = meta.binary,
                category    = meta.category,
                install_cmd = meta.install_cmd,
            )
        return self._records[cn]
