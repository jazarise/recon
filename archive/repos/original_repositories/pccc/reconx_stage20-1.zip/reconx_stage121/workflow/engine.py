"""
ReconX — Stage 16: Workflow Execution Engine.

Orchestrates complete reconnaissance workflows with:
  • Sequential execution    — ordered tool chains
  • Parallel execution      — concurrent tool groups
  • Conditional execution   — context-evaluated step guards
  • Dependency resolution   — topological sort of depends_on
  • Failure isolation       — one tool crash never kills the workflow
  • Per-step retries        — configurable retry with back-off
  • Pause / Resume          — via CheckpointManager integration
  • Progress callbacks      — TUI and recorder integration hooks

Usage:
    from reconx.workflow.engine import WorkflowEngine
    from reconx.workflow.templates import WorkflowTemplates

    engine  = WorkflowEngine()
    wf_def  = WorkflowTemplates.get("passive_recon")
    session = engine.execute(wf_def, "example.com")
"""
from __future__ import annotations

import logging
import time
import uuid
from collections import defaultdict, deque
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Callable, Optional

from .schemas import (
    ExecutionMode,
    StepStatus,
    WorkflowDefinition,
    WorkflowSession,
    WorkflowStatus,
    WorkflowStep,
)

log = logging.getLogger("reconx.workflow.engine")

# Condition evaluators — map condition string → predicate over session context
_CONDITIONS: dict[str, Callable[[dict], bool]] = {
    "has_subdomains":  lambda ctx: bool(ctx.get("subdomains")),
    "has_live_hosts":  lambda ctx: bool(ctx.get("live_hosts")),
    "has_open_ports":  lambda ctx: bool(ctx.get("open_ports")),
    "has_urls":        lambda ctx: bool(ctx.get("urls")),
    "has_emails":      lambda ctx: bool(ctx.get("emails")),
    "has_findings":    lambda ctx: ctx.get("_total_findings", 0) > 0,
    "always":          lambda ctx: True,
    "never":           lambda ctx: False,
}


# ─────────────────────────────────────────────────────────────────────────────
# Workflow Engine
# ─────────────────────────────────────────────────────────────────────────────

class WorkflowEngine:
    """
    Core orchestration engine for Stage 16 workflows.

    Design principles:
      - Never raises an exception to the caller; all errors are captured
        inside the session's step records.
      - Steps grouped by parallel_group run concurrently; all other steps
        run sequentially in dependency order.
      - Registry look-up is best-effort; missing tools are marked SKIPPED
        rather than causing a crash.
    """

    def __init__(
        self,
        registry:      Any                     = None,
        max_workers:   int                     = 8,
        on_step_start: Optional[Callable]      = None,
        on_step_done:  Optional[Callable]      = None,
        on_paused:     Optional[Callable]      = None,
    ):
        """
        Args:
            registry:      ToolRegistry instance (optional — degrades gracefully).
            max_workers:   Thread pool size for parallel step groups.
            on_step_start: callback(step: WorkflowStep, session: WorkflowSession)
            on_step_done:  callback(step: WorkflowStep, session: WorkflowSession)
            on_paused:     callback(session: WorkflowSession)
        """
        self._registry      = registry
        self._max_workers   = max_workers
        self.on_step_start  = on_step_start
        self.on_step_done   = on_step_done
        self.on_paused      = on_paused
        self._pause_flag    = False   # set to True externally to pause between steps

    # ── Public API ────────────────────────────────────────────────────────────

    def execute(
        self,
        workflow:    WorkflowDefinition,
        target:      str,
        session_id:  Optional[str]   = None,
        resume_from: Optional[WorkflowSession] = None,
    ) -> WorkflowSession:
        """
        Execute a full workflow against target.

        If resume_from is provided, steps already marked SUCCESS are skipped
        and execution continues from the first non-completed step.

        Returns a fully populated WorkflowSession.
        """
        sid = session_id or f"session_{int(time.time())}_{uuid.uuid4().hex[:6]}"

        # Build session — clone from resume if present, else fresh
        if resume_from:
            session = resume_from
            session.status = WorkflowStatus.RUNNING
            log.info(f"[{sid}] Resuming workflow '{workflow.name}' for {target!r}")
        else:
            session = WorkflowSession(
                session_id    = sid,
                workflow_name = workflow.name,
                target        = target,
                steps         = [self._clone_step(s) for s in workflow.steps],
                workflow_def  = workflow.to_dict(),
                started_at    = time.time(),
                status        = WorkflowStatus.RUNNING,
            )
            log.info(f"[{sid}] Starting workflow '{workflow.name}' for {target!r} "
                     f"({len(session.steps)} steps)")

        session.add_event("workflow_start", workflow.name,
                          f"target={target}")

        try:
            self._run_session(session, target)
        except Exception as exc:
            log.exception(f"[{sid}] Unhandled engine error: {exc}")
            session.status = WorkflowStatus.FAILED

        session.finished_at = time.time()
        if session.status == WorkflowStatus.RUNNING:
            session.status = WorkflowStatus.COMPLETED

        session.add_event("workflow_end", workflow.name,
                          f"status={session.status.value} "
                          f"findings={session.total_findings}")
        log.info(f"[{sid}] Done — {session.status.value}, "
                 f"{session.total_findings} findings, "
                 f"{session.duration_s:.1f}s")
        return session

    def pause(self) -> None:
        """Signal the engine to pause after the current step finishes."""
        self._pause_flag = True

    def resume(self) -> None:
        """Clear the pause flag so execution continues."""
        self._pause_flag = False

    # ── Internal execution flow ───────────────────────────────────────────────

    def _run_session(self, session: WorkflowSession, target: str) -> None:
        """Main execution loop: resolves groups and runs steps in order."""
        execution_plan = self._build_execution_plan(session.steps)

        for group in execution_plan:
            # Honour pause between groups
            if self._pause_flag:
                session.status = WorkflowStatus.PAUSED
                session.paused_at = time.time()
                if self.on_paused:
                    try:
                        self.on_paused(session)
                    except Exception:
                        pass
                log.info(f"[{session.session_id}] Paused before group {[s.tool_class for s in group]}")
                # Block until resumed or cancelled
                while self._pause_flag:
                    time.sleep(0.2)
                session.status = WorkflowStatus.RUNNING

            if len(group) == 1:
                self._run_step(group[0], session, target)
            else:
                self._run_parallel_group(group, session, target)

    def _build_execution_plan(
        self,
        steps: list[WorkflowStep],
    ) -> list[list[WorkflowStep]]:
        """
        Topological sort respecting depends_on + parallel_group clustering.

        Returns a list of batches. Each batch is either a single-step list
        (sequential) or a multi-step list (parallel group).
        """
        # Group parallel steps by their group name
        parallel_groups: dict[str, list[WorkflowStep]] = defaultdict(list)
        sequential: list[WorkflowStep] = []

        for step in steps:
            if step.parallel_group:
                parallel_groups[step.parallel_group].append(step)
            else:
                sequential.append(step)

        # Build dependency-ordered plan for sequential steps
        name_to_step = {s.tool_class: s for s in steps}
        in_degree: dict[str, int] = {s.tool_class: 0 for s in steps}
        adj: dict[str, list[str]] = defaultdict(list)

        for step in steps:
            for dep in step.depends_on:
                if dep in name_to_step:
                    adj[dep].append(step.tool_class)
                    in_degree[step.tool_class] += 1

        queue: deque[str] = deque(
            tc for tc, deg in in_degree.items() if deg == 0
        )
        plan: list[list[WorkflowStep]] = []
        seen_groups: set[str] = set()

        while queue:
            tool_class = queue.popleft()
            step = name_to_step.get(tool_class)
            if not step:
                continue

            if step.parallel_group:
                if step.parallel_group not in seen_groups:
                    seen_groups.add(step.parallel_group)
                    plan.append(parallel_groups[step.parallel_group])
            else:
                plan.append([step])

            for neighbour in adj[tool_class]:
                in_degree[neighbour] -= 1
                if in_degree[neighbour] == 0:
                    queue.append(neighbour)

        # Append any unresolved (dependency cycles / missing deps) as fallback
        resolved = {s.tool_class for batch in plan for s in batch}
        for step in steps:
            if step.tool_class not in resolved:
                if step.parallel_group and step.parallel_group not in seen_groups:
                    seen_groups.add(step.parallel_group)
                    plan.append(parallel_groups[step.parallel_group])
                elif not step.parallel_group:
                    plan.append([step])

        return plan

    def _run_parallel_group(
        self,
        group:   list[WorkflowStep],
        session: WorkflowSession,
        target:  str,
    ) -> None:
        """Run a set of steps concurrently via ThreadPoolExecutor."""
        workers = min(self._max_workers, len(group))
        with ThreadPoolExecutor(max_workers=workers) as pool:
            futures = {
                pool.submit(self._run_step, step, session, target): step
                for step in group
            }
            for fut in as_completed(futures):
                try:
                    fut.result()
                except Exception as exc:
                    step = futures[fut]
                    log.error(f"Parallel step {step.tool_class} raised: {exc}")

    def _run_step(
        self,
        step:    WorkflowStep,
        session: WorkflowSession,
        target:  str,
    ) -> None:
        """Execute one step with retry logic and error isolation."""
        # Skip already-completed steps (resume support)
        if step.status == StepStatus.SUCCESS:
            return

        # Evaluate condition guard
        if not self._evaluate_condition(step, session.context):
            step.status = StepStatus.SKIPPED
            session.skipped_steps.append(step.tool_class)
            session.add_event("step_skipped", step.tool_class,
                              f"condition={step.condition!r} not met")
            log.debug(f"Skipped {step.tool_class}: condition {step.condition!r}")
            return

        # Check dependencies succeeded
        for dep in step.depends_on:
            dep_step = next((s for s in session.steps if s.tool_class == dep), None)
            if dep_step and dep_step.status == StepStatus.FAILED and step.required:
                step.status = StepStatus.SKIPPED
                session.skipped_steps.append(step.tool_class)
                session.add_event("step_skipped", step.tool_class,
                                  f"required dep {dep} failed")
                return

        # Notify start
        step.status     = StepStatus.RUNNING
        step.started_at = time.time()
        session.add_event("step_start", step.tool_class)
        if self.on_step_start:
            try:
                self.on_step_start(step, session)
            except Exception:
                pass

        # Execute with retries
        last_error = ""
        for attempt in range(step.max_retries + 1):
            step.attempts = attempt + 1
            if attempt > 0:
                step.status = StepStatus.RETRYING
                time.sleep(min(2 ** attempt, 10))

            try:
                result = self._invoke_tool(step, target, session.context)
                step.result = result
                step.status = StepStatus.SUCCESS
                step.finished_at = time.time()
                self._merge_context(result, session)
                step.finding_count = self._count_findings(result)
                session.total_findings += step.finding_count
                last_error = ""
                break

            except Exception as exc:
                last_error = str(exc)
                log.warning(f"Step {step.tool_class} attempt {attempt + 1} failed: {exc}")

        if last_error:
            step.status      = StepStatus.FAILED
            step.error       = last_error
            step.finished_at = time.time()
            session.failed_steps.append(step.tool_class)
            session.add_event("step_failed", step.tool_class, last_error[:120])
            log.error(f"Step {step.tool_class} failed after {step.attempts} attempt(s)")

            if step.required:
                # Mark remaining steps as cancelled and abort
                for remaining in session.steps:
                    if remaining.status == StepStatus.PENDING:
                        remaining.status = StepStatus.CANCELLED
                session.status = WorkflowStatus.FAILED
        else:
            session.add_event("step_done", step.tool_class,
                              f"findings={step.finding_count}")

        if self.on_step_done:
            try:
                self.on_step_done(step, session)
            except Exception:
                pass

    # ── Tool invocation ───────────────────────────────────────────────────────

    def _invoke_tool(
        self,
        step:    WorkflowStep,
        target:  str,
        context: dict,
    ) -> Any:
        """
        Look up the tool in the registry and call run().
        Falls back gracefully when registry is unavailable.
        """
        if not self._registry:
            raise RuntimeError("No ToolRegistry — cannot execute tools.")

        tool_cls = None
        for name in [step.tool_class, step.tool_class.replace("Tool", ""),
                     step.tool_class + "Tool"]:
            tool_cls = self._registry.get(name)
            if tool_cls:
                break

        if not tool_cls:
            raise RuntimeError(f"Tool '{step.tool_class}' not found in registry.")

        kwargs = dict(step.kwargs)
        # Inject context-derived extra kwargs
        if context.get("subdomains"):
            kwargs.setdefault("subdomains", context["subdomains"])
        if context.get("live_hosts"):
            kwargs.setdefault("hosts", context["live_hosts"])

        tool_instance = tool_cls() if isinstance(tool_cls, type) else tool_cls
        return tool_instance.run(target, **kwargs)

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _evaluate_condition(self, step: WorkflowStep, context: dict) -> bool:
        if not step.condition:
            return True
        evaluator = _CONDITIONS.get(step.condition)
        if evaluator:
            return evaluator(context)
        log.debug(f"Unknown condition '{step.condition}' — defaulting to True")
        return True

    def _merge_context(self, result: Any, session: WorkflowSession) -> None:
        """Extract findings from a tool result and accumulate into session context."""
        if not result or not hasattr(result, "findings"):
            return
        ctx = session.context
        for finding in result.findings:
            ftype = getattr(finding, "finding_type", None)
            value = getattr(finding, "value", None)
            if isinstance(finding, dict):
                ftype = finding.get("finding_type")
                value = finding.get("value")
            if not ftype or not value:
                continue
            ctx.setdefault(ftype, [])
            if value not in ctx[ftype]:
                ctx[ftype].append(value)

        # Convenience aliases consumed by condition evaluators
        ctx["subdomains"] = (ctx.get("subdomain", [])
                             + ctx.get("subdomain_permutation", []))
        ctx["live_hosts"] = ctx.get("live_host", [])
        ctx["open_ports"] = ctx.get("open_port", [])
        ctx["urls"]       = ctx.get("url", []) + ctx.get("historical_url", [])
        ctx["emails"]     = ctx.get("email", [])
        ctx["_total_findings"] = session.total_findings

    def _count_findings(self, result: Any) -> int:
        if not result:
            return 0
        if hasattr(result, "findings"):
            return len(result.findings)
        if isinstance(result, list):
            return len(result)
        return 0

    @staticmethod
    def _clone_step(step: WorkflowStep) -> WorkflowStep:
        """Create a fresh copy of a step with PENDING status."""
        return WorkflowStep.from_dict({
            **step.to_dict(),
            "status":       "pending",
            "error":        "",
            "attempts":     0,
            "started_at":   0.0,
            "finished_at":  0.0,
            "finding_count": 0,
        })
