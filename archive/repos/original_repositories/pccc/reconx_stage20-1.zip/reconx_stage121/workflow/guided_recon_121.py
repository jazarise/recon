"""
ReconX — Guided Recon Mode (Stage 12.1).

Defines the complete reconnaissance workflow graph for guided mode.
Each step knows which tools to run, what data it produces, what it
consumes from prior steps, and whether it can be skipped.

The WorkflowRunner executes steps sequentially, persists state to disk
for resume support, and passes structured findings between steps.
"""
from __future__ import annotations
import json
import logging
import os
import time
from dataclasses import dataclass, field, asdict
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Optional

log = logging.getLogger("reconx.guided_recon")


# ─────────────────────────────────────────────────────────────────────────────
# Data structures
# ─────────────────────────────────────────────────────────────────────────────

class StepStatus(str, Enum):
    PENDING   = "pending"
    RUNNING   = "running"
    SUCCESS   = "success"
    SKIPPED   = "skipped"
    FAILED    = "failed"
    MISSING   = "missing"     # tool not installed


@dataclass
class WorkflowStep:
    id:          str
    name:        str
    description: str
    tools:       list[str]             # tool class names to invoke
    category:    str                   # display grouping
    skippable:   bool         = True
    requires:    list[str]    = field(default_factory=list)   # step IDs that must run first
    produces:    list[str]    = field(default_factory=list)   # finding types this step adds
    status:      StepStatus   = StepStatus.PENDING
    duration_s:  float        = 0.0
    findings:    list[dict]   = field(default_factory=list)
    error:       Optional[str] = None
    notes:       Optional[str] = None


@dataclass
class WorkflowState:
    target:        str
    started_at:    float                = field(default_factory=time.time)
    current_step:  Optional[str]        = None
    completed:     list[str]            = field(default_factory=list)
    skipped:       list[str]            = field(default_factory=list)
    failed:        list[str]            = field(default_factory=list)
    all_findings:  list[dict]           = field(default_factory=list)
    step_results:  dict[str, list[dict]] = field(default_factory=dict)
    report_path:   Optional[str]        = None
    finished_at:   Optional[float]      = None


# ─────────────────────────────────────────────────────────────────────────────
# Step definitions — the full Stage 12.1 workflow
# ─────────────────────────────────────────────────────────────────────────────

GUIDED_STEPS: list[WorkflowStep] = [

    WorkflowStep(
        id          = "whois",
        name        = "WHOIS Lookup",
        description = "Retrieve domain registration data, registrar, nameservers, and contact info.",
        tools       = ["WhoisTool"],
        category    = "Passive Recon",
        skippable   = True,
        produces    = ["whois_data", "nameserver", "registrar"],
    ),

    WorkflowStep(
        id          = "theharvester",
        name        = "theHarvester — OSINT",
        description = "Collect emails, subdomains, IPs, and employee names from public sources.",
        tools       = ["TheHarvesterTool"],
        category    = "Passive Recon",
        skippable   = True,
        produces    = ["email", "subdomain", "ip"],
    ),

    WorkflowStep(
        id          = "spiderfoot",
        name        = "SpiderFoot — OSINT Enrichment",
        description = "Run automated OSINT across 200+ sources for domain enrichment.",
        tools       = ["SpiderFootTool"],
        category    = "Passive Recon",
        skippable   = True,
        produces    = ["subdomain", "email", "ip", "breach_indicator"],
    ),

    WorkflowStep(
        id          = "subdomains",
        name        = "Subdomain Enumeration",
        description = "Passive subdomain discovery via Sublist3r, Amass, and certificate transparency.",
        tools       = ["Sublist3rTool", "AmassTool"],
        category    = "DNS",
        skippable   = True,
        produces    = ["subdomain"],
    ),

    WorkflowStep(
        id          = "dns",
        name        = "DNS Enumeration",
        description = "Full DNS record enumeration, zone transfer test, and reverse lookups.",
        tools       = ["DNSReconTool", "DNSEnumTool", "FierceTool"],
        category    = "DNS",
        skippable   = True,
        requires    = ["subdomains"],
        produces    = ["subdomain", "ip", "dns_record", "zone_transfer_vuln"],
    ),

    WorkflowStep(
        id          = "host_discovery",
        name        = "Host Discovery",
        description = "Discover live hosts via ICMP sweep (fping) and ARP scan (netdiscover).",
        tools       = ["FpingTool", "NetdiscoverTool"],
        category    = "Network Discovery",
        skippable   = True,
        produces    = ["live_host"],
    ),

    WorkflowStep(
        id          = "port_scan",
        name        = "Port Scanning",
        description = "Multi-mode port scan: fast TCP connect + stealth SYN scan.",
        tools       = ["NmapTool"],
        category    = "Active Recon",
        skippable   = False,       # core step — not skippable
        requires    = ["host_discovery"],
        produces    = ["open_port", "service"],
    ),

    WorkflowStep(
        id          = "banner_grab",
        name        = "Banner Grabbing",
        description = "Grab service banners from open ports via Netcat wrapper.",
        tools       = ["NetcatWrapperTool"],
        category    = "Active Recon",
        skippable   = True,
        requires    = ["port_scan"],
        produces    = ["banner", "version_info"],
    ),

    WorkflowStep(
        id          = "service_fingerprint",
        name        = "Service Fingerprinting",
        description = "Deep service fingerprinting via Metasploit auxiliary modules.",
        tools       = ["MetasploitAuxTool"],
        category    = "Frameworks",
        skippable   = True,
        requires    = ["port_scan"],
        produces    = ["version_info", "smb_share", "anonymous_access"],
    ),

    WorkflowStep(
        id          = "web_discovery",
        name        = "Web Content Discovery",
        description = "Recursive directory brute-force with dirb and feroxbuster.",
        tools       = ["DirbusterTool", "FeroxbusterTool"],
        category    = "Web Recon",
        skippable   = True,
        requires    = ["port_scan"],
        produces    = ["web_path", "admin_panel", "login_page", "backup_file"],
    ),

    WorkflowStep(
        id          = "tech_detect",
        name        = "Technology Detection",
        description = "Detect web frameworks, CMS, servers, and libraries via WhatWeb/Wappalyzer.",
        tools       = ["WhatWebTool"],
        category    = "Web Recon",
        skippable   = True,
        requires    = ["port_scan"],
        produces    = ["technology", "cms", "framework"],
    ),

    WorkflowStep(
        id          = "visual_recon",
        name        = "Visual Web Reconnaissance",
        description = "Screenshot all discovered web services for visual triage via EyeWitness.",
        tools       = ["EyeWitnessTool"],
        category    = "Web Recon",
        skippable   = True,
        requires    = ["web_discovery"],
        produces    = ["web_screenshot", "login_page"],
    ),

    WorkflowStep(
        id          = "osint_social",
        name        = "Social Footprint Analysis",
        description = "Username and email intelligence across 300+ platforms via OSRFramework.",
        tools       = ["OSRFrameworkTool"],
        category    = "Passive Recon",
        skippable   = True,
        requires    = ["theharvester"],
        produces    = ["social_profile", "email"],
    ),

    WorkflowStep(
        id          = "graph_export",
        name        = "Entity Graph Export",
        description = "Export all findings as a Maltego MTGL entity graph for visual analysis.",
        tools       = ["MaltegoTool"],
        category    = "Passive Recon",
        skippable   = True,
        requires    = [],
        produces    = ["graph_file"],
    ),

    WorkflowStep(
        id          = "risk_analysis",
        name        = "Risk Analysis",
        description = "Correlate all findings against known CVEs and generate risk scores.",
        tools       = ["RiskAnalyzer"],
        category    = "Analysis",
        skippable   = False,
        requires    = ["port_scan"],
        produces    = ["risk_finding", "cve"],
    ),

    WorkflowStep(
        id          = "report",
        name        = "Report Generation",
        description = "Generate HTML/JSON reports with all findings, screenshots, and timelines.",
        tools       = ["ReportGenerator"],
        category    = "Output",
        skippable   = False,
        requires    = ["risk_analysis"],
        produces    = ["report"],
    ),
]

# Build lookup by ID
STEP_MAP: dict[str, WorkflowStep] = {s.id: s for s in GUIDED_STEPS}


# ─────────────────────────────────────────────────────────────────────────────
# WorkflowRunner
# ─────────────────────────────────────────────────────────────────────────────

class WorkflowRunner:
    """
    Executes the guided recon workflow with:
      - Step dependency resolution
      - Skip support (skippable steps)
      - State persistence (resume after interruption)
      - Finding propagation between steps
      - Per-step status reporting
    """

    STATE_FILE_TEMPLATE = "reports/workflow_{target}_{ts}.json"

    def __init__(
        self,
        target:     str,
        tool_registry: dict,            # name → tool instance
        skip_steps: Optional[list[str]] = None,
        state_file: Optional[str]       = None,
        on_step_start:  Optional[Callable] = None,
        on_step_finish: Optional[Callable] = None,
    ):
        self.target         = target
        self.tool_registry  = tool_registry
        self.skip_steps     = set(skip_steps or [])
        self.on_step_start  = on_step_start
        self.on_step_finish = on_step_finish

        # Load or create workflow state
        self.state_file = state_file or self._default_state_file()
        self.state      = self._load_state() or WorkflowState(target=target)

        # Work on fresh step list (status may be restored from file)
        self.steps = [WorkflowStep(**{**asdict(s)}) for s in GUIDED_STEPS]
        self._restore_step_statuses()

    # ── public API ────────────────────────────────────────────────────────────

    def run(self) -> WorkflowState:
        """Execute all pending workflow steps in dependency order."""
        log.info(f"Starting guided recon: target={self.target}")
        Path("reports").mkdir(exist_ok=True)

        for step in self.steps:
            if step.status in (StepStatus.SUCCESS, StepStatus.SKIPPED):
                log.info(f"[SKIP-RESUME] {step.name} (already complete)")
                continue

            if not self._deps_satisfied(step):
                log.warning(f"[SKIP-DEPS] {step.name} — dependencies not met")
                step.status = StepStatus.SKIPPED
                self.state.skipped.append(step.id)
                continue

            if step.id in self.skip_steps and step.skippable:
                log.info(f"[SKIPPED] {step.name}")
                step.status = StepStatus.SKIPPED
                self.state.skipped.append(step.id)
                self._save_state()
                if self.on_step_finish:
                    self.on_step_finish(step)
                continue

            self._execute_step(step)

        self.state.finished_at = time.time()
        self._save_state()
        log.info("Guided recon workflow complete.")
        return self.state

    def skip(self, step_id: str) -> None:
        """Mark a step as skipped at runtime."""
        if step_id in STEP_MAP:
            self.skip_steps.add(step_id)

    def resume(self) -> WorkflowState:
        """Resume from last saved state."""
        log.info(f"Resuming workflow for {self.target}")
        return self.run()

    # ── step execution ────────────────────────────────────────────────────────

    def _execute_step(self, step: WorkflowStep) -> None:
        step.status = StepStatus.RUNNING
        self.state.current_step = step.id
        log.info(f"[RUNNING] {step.name}")

        if self.on_step_start:
            self.on_step_start(step)

        t0 = time.perf_counter()
        all_findings: list[dict] = []
        any_success  = False
        any_missing  = False

        for tool_name in step.tools:
            tool = self.tool_registry.get(tool_name)
            if tool is None:
                log.warning(f"[MISSING] Tool not registered: {tool_name}")
                any_missing = True
                continue

            try:
                # Pass findings from prior steps as context
                prior_context = self._build_context_for_tool(tool_name)
                result = tool.run(self.target, **prior_context)

                if result.status in ("success", "partial"):
                    any_success = True
                    for f in result.findings:
                        fd = f if isinstance(f, dict) else f.__dict__
                        all_findings.append(fd)
                elif result.status == "skipped":
                    any_missing = True
                    log.info(f"[SKIPPED] {tool_name} — tool unavailable")
                else:
                    log.warning(f"[FAILED] {tool_name}: {result.error}")

            except Exception as exc:
                log.exception(f"Tool error [{tool_name}]: {exc}")
                step.error = str(exc)

        step.duration_s = time.perf_counter() - t0
        step.findings   = all_findings

        # Merge into global state
        self.state.all_findings.extend(all_findings)
        self.state.step_results[step.id] = all_findings

        if any_success or all_findings:
            step.status = StepStatus.SUCCESS
            self.state.completed.append(step.id)
            log.info(f"[SUCCESS] {step.name} — {len(all_findings)} findings in {step.duration_s:.1f}s")
        elif any_missing:
            step.status = StepStatus.MISSING
            self.state.skipped.append(step.id)
            log.info(f"[MISSING] {step.name} — no tools available")
        else:
            step.status = StepStatus.FAILED
            self.state.failed.append(step.id)
            log.warning(f"[FAILED] {step.name}")

        self._save_state()
        if self.on_step_finish:
            self.on_step_finish(step)

    # ── dependency resolution ─────────────────────────────────────────────────

    def _deps_satisfied(self, step: WorkflowStep) -> bool:
        for req_id in step.requires:
            if req_id not in self.state.completed and req_id not in self.state.skipped:
                return False
        return True

    # ── context passing ───────────────────────────────────────────────────────

    def _build_context_for_tool(self, tool_name: str) -> dict[str, Any]:
        """Build kwargs from prior step findings for tool consumption."""
        ctx: dict[str, Any] = {}

        subdomains = [
            f["value"] for f in self.state.all_findings
            if f.get("finding_type") == "subdomain"
        ]
        emails = [
            f["value"] for f in self.state.all_findings
            if f.get("finding_type") == "email"
        ]
        live_hosts = [
            f["value"] for f in self.state.all_findings
            if f.get("finding_type") == "live_host"
        ]
        open_ports = [
            f.get("metadata", {}).get("port")
            for f in self.state.all_findings
            if f.get("finding_type") == "open_port"
        ]

        # Pass consolidated findings to tools that accept them
        if subdomains:
            ctx["known_subdomains"] = subdomains
        if emails:
            ctx["known_emails"] = emails
        if live_hosts:
            ctx["live_hosts"] = live_hosts
        if open_ports:
            ctx["known_ports"] = [p for p in open_ports if p]

        # Graph export gets everything
        if tool_name == "MaltegoTool":
            ctx["findings"] = {
                "subdomains": subdomains,
                "emails":     emails,
                "ips":        live_hosts,
                "open_ports": open_ports,
            }

        return ctx

    # ── state persistence ─────────────────────────────────────────────────────

    def _save_state(self) -> None:
        try:
            Path(self.state_file).write_text(json.dumps(asdict(self.state), indent=2))
        except Exception as e:
            log.warning(f"Could not save workflow state: {e}")

    def _load_state(self) -> Optional[WorkflowState]:
        try:
            if os.path.exists(self.state_file):
                raw = json.loads(Path(self.state_file).read_text())
                return WorkflowState(**raw)
        except Exception:
            pass
        return None

    def _restore_step_statuses(self) -> None:
        for step in self.steps:
            if step.id in self.state.completed:
                step.status = StepStatus.SUCCESS
            elif step.id in self.state.skipped:
                step.status = StepStatus.SKIPPED
            elif step.id in self.state.failed:
                step.status = StepStatus.FAILED

    def _default_state_file(self) -> str:
        ts = int(time.time())
        safe = self.target.replace(".", "_").replace("/", "_")
        return f"reports/workflow_{safe}_{ts}.json"
