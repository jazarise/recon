"""
ReconX — Stage 16: Guided Recon Mode.

An interactive, step-by-step reconnaissance assistant that acts as a
senior analyst guiding the user through a structured recon engagement.

Flow:
  Step 1 — Select target
  Step 2 — Choose objective (from curated list)
  Step 3 — ReconX recommends tools with rationale
  Step 4 — User selects: [Run Now] | [Learn First] | [Customise] | [Back]
  Step 5 — If Learn First: show tool education then offer to run
  Step 6 — Execute and display live results

Integrates with:
  • WorkflowPlanner    — generates tool recommendations
  • WorkflowEngine     — executes chosen workflow
  • WorkflowRecorder   — saves the session
  • LearningMode       — powers the Learn First path

Usage:
    from reconx.workflow.guided import GuidedRecon
    guided = GuidedRecon()
    guided.run()
"""
from __future__ import annotations

import logging
import time
from typing import Optional

from rich import box
from rich.columns import Columns
from rich.console import Console
from rich.panel import Panel
from rich.prompt import Prompt, IntPrompt
from rich.rule import Rule
from rich.table import Table
from rich.text import Text

from .engine import WorkflowEngine
from .planner import WorkflowPlanner
from .recorder import WorkflowRecorder
from .schemas import WorkflowSession

log = logging.getLogger("reconx.workflow.guided")

console = Console()


# ─────────────────────────────────────────────────────────────────────────────
# Curated objectives catalogue
# ─────────────────────────────────────────────────────────────────────────────

OBJECTIVES: list[dict] = [
    {
        "id":          "find_subdomains",
        "label":       "Find Subdomains",
        "description": "Discover all subdomains using passive CT logs, active brute-force, and DNS enumeration.",
        "icon":        "🌐",
        "goal":        "find all subdomains passive active",
        "risk":        "medium",
    },
    {
        "id":          "map_attack_surface",
        "label":       "Map Attack Surface",
        "description": "Build a complete external attack surface: hosts, ports, services, and technologies.",
        "icon":        "🗺️",
        "goal":        "full attack surface map",
        "risk":        "high",
    },
    {
        "id":          "find_login_panels",
        "label":       "Find Login Panels",
        "description": "Locate administrative and login interfaces via crawling and content discovery.",
        "icon":        "🔐",
        "goal":        "find login panel web http directory",
        "risk":        "medium",
    },
    {
        "id":          "discover_apis",
        "label":       "Discover APIs",
        "description": "Identify REST, GraphQL, and OpenAPI endpoints exposed by the target.",
        "icon":        "⚙️",
        "goal":        "discover api graphql rest openapi",
        "risk":        "medium",
    },
    {
        "id":          "cloud_assets",
        "label":       "Cloud Asset Discovery",
        "description": "Enumerate cloud infrastructure: S3 buckets, cloud hosts, and storage exposure.",
        "icon":        "☁️",
        "goal":        "cloud s3 bucket azure gcp aws",
        "risk":        "medium",
    },
    {
        "id":          "passive_osint",
        "label":       "Passive OSINT (No Traffic)",
        "description": "Zero-traffic intelligence gathering from public sources only.",
        "icon":        "🕵️",
        "goal":        "passive osint stealth silent",
        "risk":        "low",
    },
    {
        "id":          "hidden_endpoints",
        "label":       "Find Hidden Endpoints",
        "description": "Discover undocumented paths via JS analysis, crawling, and fuzzing.",
        "icon":        "🔍",
        "goal":        "find hidden endpoint web directory javascript",
        "risk":        "medium",
    },
    {
        "id":          "bug_bounty",
        "label":       "Bug Bounty Recon",
        "description": "Modern bug bounty chain: subdomain takeover, CORS, secrets, screenshots.",
        "icon":        "🐛",
        "goal":        "bug bounty takeover cors secrets",
        "risk":        "high",
    },
    {
        "id":          "internal_assets",
        "label":       "Internal Network Assets",
        "description": "Discover internal hosts, open services, SMB shares, and vulnerable services.",
        "icon":        "🏢",
        "goal":        "internal lan network smb active directory",
        "risk":        "high",
    },
    {
        "id":          "quick_overview",
        "label":       "Quick Overview (5 min)",
        "description": "High-speed scan to get a basic picture of the target in under 5 minutes.",
        "icon":        "⚡",
        "goal":        "fast quick rapid",
        "risk":        "medium",
    },
]

# ── Tool learning summaries (inline — full depth via LearningMode) ─────────

_TOOL_BLURBS: dict[str, dict] = {
    "WhoisTool":       {"desc": "Queries registration info: registrar, org, ASN, contact emails.",
                        "use":  "First step — identifies who owns the target.",
                        "common_errors": "Rate-limited by registrars. Use with --no-cache flag to bypass."},
    "SubfinderTool":   {"desc": "Passive subdomain discovery via certificate transparency and APIs.",
                        "use":  "Finds subdomains without sending packets to the target.",
                        "common_errors": "Missing API keys reduce coverage significantly."},
    "AmassActiveTool": {"desc": "Comprehensive subdomain enumeration with active DNS brute-force.",
                        "use":  "Most thorough subdomain tool; slower than Subfinder.",
                        "common_errors": "Requires significant RAM for large targets."},
    "HttpxTool":       {"desc": "Probes a list of hosts/subdomains for live HTTP services.",
                        "use":  "Filters the subdomain list to only live, responding hosts.",
                        "common_errors": "False negatives behind WAF with non-standard ports."},
    "NmapTool":        {"desc": "Port scanner: discovers open TCP/UDP ports and service versions.",
                        "use":  "Essential for understanding what services are exposed.",
                        "common_errors": "Requires root for SYN scan (-sS). Firewalls may drop packets."},
    "GoSpiderTool":    {"desc": "Crawls a web target and extracts links, forms, and JS files.",
                        "use":  "Feeds URL lists to LinkFinder and SecretFinder.",
                        "common_errors": "Can trigger WAF rate limits. Use --delay flag."},
    "NucleiTool":      {"desc": "Runs vulnerability templates against live hosts.",
                        "use":  "Identifies known CVEs, misconfigs, and exposed panels.",
                        "common_errors": "Template database needs regular updating: nuclei -update-templates."},
    "SecretFinderTool":{"desc": "Scans JavaScript files for exposed API keys and credentials.",
                        "use":  "High-value passive finding — secrets left in JS bundles.",
                        "common_errors": "Many false positives. Review results manually."},
    "S3ScannerTool":   {"desc": "Discovers and tests access to S3-compatible cloud storage buckets.",
                        "use":  "Finds publicly readable/writable buckets.",
                        "common_errors": "AWS rate-limits aggressive scans. Use --threads 5."},
}


# ─────────────────────────────────────────────────────────────────────────────
# GuidedRecon
# ─────────────────────────────────────────────────────────────────────────────

class GuidedRecon:
    """
    Interactive guided reconnaissance assistant.

    Provides a structured, educational interface that walks operators
    through target selection, objective definition, tool recommendation,
    and optional in-line learning before execution.
    """

    def __init__(
        self,
        engine:   Optional[WorkflowEngine]  = None,
        planner:  Optional[WorkflowPlanner] = None,
        recorder: Optional[WorkflowRecorder] = None,
    ):
        self._engine   = engine   or WorkflowEngine()
        self._planner  = planner  or WorkflowPlanner()
        self._recorder = recorder or WorkflowRecorder()

    # ── Entry point ───────────────────────────────────────────────────────────

    def run(self) -> Optional[WorkflowSession]:
        """Launch the full guided recon flow. Returns the session if executed."""
        self._print_header()

        # Step 1 — Target
        target = self._prompt_target()
        if not target:
            return None

        # Step 2 — Objective
        objective = self._prompt_objective()
        if not objective:
            return None

        # Step 3 — Plan and display recommendations
        workflow = self._planner.plan(
            goal        = objective["goal"],
            risk_profile = objective["risk"],
        )
        self._display_recommendations(workflow, objective)

        # Step 4 — User choice
        choice = self._prompt_action()

        if choice == "back":
            return self.run()

        if choice == "learn":
            self._run_learn_first(workflow)
            if not self._confirm_run_after_learn():
                return None

        if choice == "customise":
            workflow = self._customise_workflow(workflow)

        if choice in ("run", "learn", "customise"):
            return self._execute(workflow, target)

        return None

    # ── Prompts ───────────────────────────────────────────────────────────────

    def _prompt_target(self) -> Optional[str]:
        console.print()
        console.print(Rule("[bold cyan]Step 1 — Target[/]", style="cyan"))
        console.print(
            "[dim]Enter any domain, IP, CIDR range, or URL.\n"
            "Examples: example.com · 192.168.1.0/24 · https://app.example.com[/]\n"
        )
        target = Prompt.ask("[bold cyan]Target[/]").strip()
        if not target:
            console.print("[red]No target entered. Aborting.[/]")
            return None
        return target

    def _prompt_objective(self) -> Optional[dict]:
        console.print()
        console.print(Rule("[bold cyan]Step 2 — Objective[/]", style="cyan"))
        console.print("[dim]What are you trying to accomplish?[/]\n")

        table = Table(box=box.SIMPLE_HEAD, show_header=True, border_style="dim cyan")
        table.add_column("#",           style="cyan dim",  width=4, no_wrap=True)
        table.add_column("Objective",   style="bold white", width=28)
        table.add_column("Description", style="dim")

        for i, obj in enumerate(OBJECTIVES, 1):
            table.add_row(str(i), f"{obj['icon']}  {obj['label']}", obj["description"])

        console.print(table)
        console.print()

        try:
            choice = IntPrompt.ask(
                "[bold cyan]Select objective[/]",
                default=1,
            )
            if 1 <= choice <= len(OBJECTIVES):
                return OBJECTIVES[choice - 1]
        except (KeyboardInterrupt, EOFError):
            pass

        console.print("[red]Invalid selection.[/]")
        return None

    def _prompt_action(self) -> str:
        console.print()
        console.print(Rule("[bold cyan]Step 4 — Action[/]", style="cyan"))

        options = Table(box=box.SIMPLE, show_header=False, border_style="dim")
        options.add_row("[bold cyan][1][/] [bold]Run Now[/]",
                        "Execute the recommended workflow immediately.")
        options.add_row("[bold yellow][2][/] [bold]Learn First[/]",
                        "Read about each tool before running.")
        options.add_row("[bold green][3][/] [bold]Customise[/]",
                        "Add or remove tools from the workflow.")
        options.add_row("[bold dim][4][/] [dim]Back[/]",
                        "Return to objective selection.")
        console.print(options)
        console.print()

        try:
            raw = Prompt.ask("[bold cyan]Choice[/]", default="1").strip()
        except (KeyboardInterrupt, EOFError):
            return "back"

        return {"1": "run", "2": "learn", "3": "customise", "4": "back"}.get(raw, "run")

    def _confirm_run_after_learn(self) -> bool:
        console.print()
        try:
            ans = Prompt.ask(
                "[bold cyan]Run the workflow now?[/] (y/n)",
                default="y",
            ).lower()
        except (KeyboardInterrupt, EOFError):
            return False
        return ans == "y"

    # ── Learn First path ──────────────────────────────────────────────────────

    def _run_learn_first(self, workflow) -> None:
        """Show inline tool education for each step in the workflow."""
        console.print()
        console.print(Rule("[bold yellow]Learn First — Tool Reference[/]", style="yellow"))
        console.print(
            f"[dim]Showing educational summaries for {len(workflow.steps)} tools "
            f"in '{workflow.name}'.[/]\n"
        )

        for i, step in enumerate(workflow.steps, 1):
            blurb = _TOOL_BLURBS.get(step.tool_class, {})
            if not blurb:
                blurb = {
                    "desc":          "Tool documentation not yet available.",
                    "use":           "Refer to the tool's --help flag.",
                    "common_errors": "Check tool installation: reconx health",
                }

            panel = Panel(
                f"[bold white]{blurb.get('desc', '')}[/]\n\n"
                f"[cyan]When to use:[/] {blurb.get('use', '—')}\n"
                f"[yellow]Common errors:[/] {blurb.get('common_errors', '—')}",
                title=f"[bold cyan][{i}/{len(workflow.steps)}] {step.tool_class}[/]",
                subtitle=f"Stage {step.stage} · Priority {step.priority}",
                border_style="yellow",
                padding=(1, 2),
            )
            console.print(panel)
            console.print()

            try:
                Prompt.ask("[dim]Press Enter for next →[/]", default="")
            except (KeyboardInterrupt, EOFError):
                break

    # ── Customise path ────────────────────────────────────────────────────────

    def _customise_workflow(self, workflow) -> "WorkflowDefinition":
        """Let the user remove steps from the workflow interactively."""
        from .schemas import WorkflowDefinition
        console.print()
        console.print(Rule("[bold green]Customise Workflow[/]", style="green"))

        table = Table(box=box.SIMPLE_HEAD, show_header=True, border_style="dim green")
        table.add_column("#",      style="cyan dim", width=4)
        table.add_column("Tool",   style="bold white")
        table.add_column("Stage",  style="dim", width=7)
        table.add_column("Group",  style="dim", width=15)

        for i, step in enumerate(workflow.steps, 1):
            table.add_row(
                str(i), step.tool_class,
                str(step.stage),
                step.parallel_group or "—",
            )
        console.print(table)
        console.print()

        console.print("[dim]Enter step numbers to remove (comma-separated), or press Enter to keep all.[/]")
        try:
            raw = Prompt.ask("[bold green]Remove steps[/]", default="").strip()
        except (KeyboardInterrupt, EOFError):
            return workflow

        if not raw:
            return workflow

        to_remove: set[int] = set()
        for part in raw.split(","):
            try:
                to_remove.add(int(part.strip()))
            except ValueError:
                pass

        new_steps = [
            step for i, step in enumerate(workflow.steps, 1)
            if i not in to_remove
        ]

        if not new_steps:
            console.print("[red]All steps removed — using original workflow.[/]")
            return workflow

        workflow.steps = new_steps
        console.print(
            f"[green]✓[/] Workflow updated: {len(new_steps)} steps remaining."
        )
        return workflow

    # ── Execute ───────────────────────────────────────────────────────────────

    def _execute(self, workflow, target: str) -> WorkflowSession:
        """Run the workflow and save the session."""
        console.print()
        console.print(Rule("[bold cyan]Executing Workflow[/]", style="cyan"))
        console.print(
            f"[dim]Running [bold]{workflow.name}[/] against "
            f"[bold cyan]{target}[/] "
            f"({len(workflow.steps)} steps)[/]\n"
        )

        started = time.time()
        session = self._engine.execute(workflow, target)
        elapsed = time.time() - started

        # Save session
        try:
            path = self._recorder.save(session)
            console.print(f"\n[bold green]📁 Session saved:[/] {path}")
        except Exception as exc:
            log.warning(f"Session save failed: {exc}")

        self._print_summary(session, elapsed)
        return session

    # ── Display helpers ───────────────────────────────────────────────────────

    def _print_header(self) -> None:
        console.print()
        console.print(Panel(
            "[bold cyan]ReconX Guided Recon[/]\n"
            "[dim]Your senior analyst assistant — step-by-step reconnaissance guidance.[/]\n\n"
            "[white]This mode will:[/]\n"
            "  • Help you define your objective\n"
            "  • Recommend the right tools for the job\n"
            "  • Offer to explain each tool before running\n"
            "  • Execute and record the full session",
            border_style="cyan",
            title="[bold]ReconX OS — Guided Mode[/]",
        ))

    def _display_recommendations(self, workflow, objective: dict) -> None:
        """Display the planned workflow with rationale before execution."""
        console.print()
        console.print(Rule("[bold cyan]Step 3 — Recommended Workflow[/]", style="cyan"))

        console.print(Panel(
            f"[bold white]{objective['icon']}  {objective['label']}[/]\n"
            f"[dim]{objective['description']}[/]",
            border_style="dim cyan",
            title="Objective",
        ))
        console.print()

        table = Table(
            title=f"[bold cyan]{workflow.name}[/] — {len(workflow.steps)} Steps",
            box=box.SIMPLE_HEAD,
            border_style="cyan",
        )
        table.add_column("#",            style="dim cyan",  width=4)
        table.add_column("Tool",         style="bold white")
        table.add_column("Purpose",      style="dim")
        table.add_column("Stage",        style="dim cyan",  width=7)
        table.add_column("Parallel",     style="dim green", width=15)

        for i, step in enumerate(workflow.steps, 1):
            blurb = _TOOL_BLURBS.get(step.tool_class, {})
            purpose = blurb.get("use", step.description or "—")[:60]
            table.add_row(
                str(i),
                step.tool_class,
                purpose,
                str(step.stage),
                step.parallel_group or "—",
            )
        console.print(table)
        console.print(
            f"\n[dim]Estimated time:[/] [bold]{workflow.estimated_min or '?'}[/] minutes"
        )

    def _print_summary(self, session: WorkflowSession, elapsed: float) -> None:
        """Print a compact post-execution summary."""
        success = session.success_count
        failed  = session.failed_count
        total   = len(session.steps)

        console.print()
        console.print(Panel(
            f"[bold green]Completed[/] — {elapsed:.1f}s\n\n"
            f"Steps:    {success}/{total} succeeded   "
            f"[red]{failed} failed[/]\n"
            f"Findings: [bold cyan]{session.total_findings}[/]",
            title="[bold]Session Summary[/]",
            border_style="green" if not failed else "yellow",
        ))
