"""
ReconX — Stage 16: Workflow Replayer.

Enables replaying, cloning, editing, and resuming past workflow sessions.

Capabilities:
  • Replay   — re-run a complete past session against the same or new target
  • Clone    — duplicate a session blueprint and edit before running
  • Edit     — modify step parameters, add/remove steps, change target
  • Resume   — continue an interrupted session from the last checkpoint
  • Diff     — compare two sessions side-by-side

Usage:
    reconx replay session_20250101_120000_abc123
    reconx replay --clone session_001 --target new.example.com
    reconx replay --resume session_001

Python API:
    from reconx.workflow.replay import WorkflowReplayer

    replayer = WorkflowReplayer()
    # Replay against same target
    new_session = replayer.replay("session_001")
    # Clone to new target
    new_session = replayer.clone("session_001", new_target="other.com")
    # Resume interrupted
    new_session = replayer.resume("session_001")
"""
from __future__ import annotations

import copy
import logging
import time
import uuid
from typing import Optional

from .checkpoint import CheckpointManager
from .engine import WorkflowEngine
from .recorder import WorkflowRecorder
from .schemas import (
    StepStatus,
    WorkflowDefinition,
    WorkflowSession,
    WorkflowStatus,
)

log = logging.getLogger("reconx.workflow.replay")


class WorkflowReplayer:
    """
    Orchestrates session replay, cloning, editing, and resumption.

    All replay operations go through WorkflowEngine so they share the
    same execution guarantees (retries, isolation, callbacks).
    """

    def __init__(
        self,
        recorder:    Optional[WorkflowRecorder]    = None,
        checkpoints: Optional[CheckpointManager]   = None,
        engine:      Optional[WorkflowEngine]       = None,
    ):
        self._recorder  = recorder    or WorkflowRecorder()
        self._ckpts     = checkpoints or CheckpointManager()
        self._engine    = engine      or WorkflowEngine()

    # ── Replay ────────────────────────────────────────────────────────────────

    def replay(
        self,
        session_id:  str,
        new_target:  Optional[str] = None,
        skip_failed: bool          = False,
    ) -> Optional[WorkflowSession]:
        """
        Replay a complete past session.

        Args:
            session_id:  ID or path of the session to replay.
            new_target:  Override target (defaults to original target).
            skip_failed: If True, skip steps that failed in the original run.

        Returns a fresh WorkflowSession with the replay results.
        """
        original = self._recorder.load(session_id)
        if not original:
            log.error(f"Cannot replay — session not found: {session_id}")
            return None

        target = new_target or original.target
        wf_def = self._session_to_definition(original, skip_failed)
        new_id = f"replay_{int(time.time())}_{uuid.uuid4().hex[:6]}"

        log.info(f"Replaying '{original.workflow_name}' "
                 f"({len(wf_def.steps)} steps) against {target!r}")

        session = self._engine.execute(wf_def, target, session_id=new_id)
        session.workflow_name = f"{original.workflow_name} [replay]"
        self._recorder.save(session)
        return session

    # ── Clone ─────────────────────────────────────────────────────────────────

    def clone(
        self,
        session_id: str,
        new_target: Optional[str] = None,
        edits:      Optional[dict] = None,
    ) -> Optional[WorkflowSession]:
        """
        Clone a session and optionally apply edits before running.

        Args:
            session_id: Source session to clone.
            new_target: Target for the new session.
            edits: Dict of overrides applied to the WorkflowDefinition:
                   {"name": "...", "steps_to_add": [...], "steps_to_remove": [...]}

        Returns the new session.
        """
        original = self._recorder.load(session_id)
        if not original:
            log.error(f"Cannot clone — session not found: {session_id}")
            return None

        target = new_target or original.target
        wf_def = self._session_to_definition(original)

        if edits:
            self._apply_edits(wf_def, edits)

        wf_def.name = f"{wf_def.name}_clone"
        new_id = f"clone_{int(time.time())}_{uuid.uuid4().hex[:6]}"

        log.info(f"Cloning '{original.workflow_name}' → {target!r}")
        session = self._engine.execute(wf_def, target, session_id=new_id)
        session.workflow_name = f"{original.workflow_name} [clone]"
        self._recorder.save(session)
        return session

    # ── Resume ────────────────────────────────────────────────────────────────

    def resume(self, session_id: str) -> Optional[WorkflowSession]:
        """
        Resume an interrupted session from its last checkpoint.

        Looks for checkpoint first, then falls back to session file
        with completed steps preserved.

        Returns the resumed session.
        """
        # Try checkpoint first (most up-to-date partial state)
        session = self._ckpts.load(session_id)

        if not session:
            # Fall back to saved session file
            session = self._recorder.load(session_id)
            if not session:
                log.error(f"Cannot resume — session not found: {session_id}")
                return None
            # Reset non-completed steps
            session = self._prepare_for_resume(session)

        wf_def = self._session_to_definition_from_steps(
            workflow_name = session.workflow_name,
            steps         = session.steps,
        )

        log.info(f"Resuming '{session.workflow_name}' for {session.target!r} — "
                 f"{session.success_count}/{len(session.steps)} steps already done")

        resumed = self._engine.execute(
            wf_def,
            session.target,
            session_id  = session.session_id,
            resume_from = session,
        )
        self._recorder.save(resumed)
        self._ckpts.delete(session_id)   # Clean checkpoint on clean completion
        return resumed

    # ── Rerun failed ──────────────────────────────────────────────────────────

    def rerun_failed(self, session_id: str) -> Optional[WorkflowSession]:
        """
        Re-run only the steps that failed in a previous session.

        Useful after fixing a tool installation or network issue.
        """
        original = self._recorder.load(session_id)
        if not original:
            log.error(f"Cannot rerun-failed — session not found: {session_id}")
            return None

        failed_steps = [s for s in original.steps
                        if s.status == StepStatus.FAILED]
        if not failed_steps:
            log.info(f"No failed steps in session {session_id}.")
            return None

        wf_def = self._session_to_definition_from_steps(
            workflow_name = f"{original.workflow_name}_retry",
            steps         = failed_steps,
        )
        new_id = f"retry_{int(time.time())}_{uuid.uuid4().hex[:6]}"

        log.info(f"Retrying {len(failed_steps)} failed steps for {original.target!r}")
        session = self._engine.execute(wf_def, original.target, session_id=new_id)
        session.workflow_name = f"{original.workflow_name} [retry]"
        self._recorder.save(session)
        return session

    # ── Diff ──────────────────────────────────────────────────────────────────

    def diff(self, session_id_a: str, session_id_b: str) -> dict:
        """
        Compare two sessions and return a summary of differences.

        Returns a dict with:
          new_findings, removed_findings, duration_delta, status_changes
        """
        a = self._recorder.load(session_id_a)
        b = self._recorder.load(session_id_b)
        if not a or not b:
            return {"error": "One or both sessions not found."}

        tools_a = {s.tool_class: s.status.value for s in a.steps}
        tools_b = {s.tool_class: s.status.value for s in b.steps}

        status_changes = []
        for tool in set(list(tools_a.keys()) + list(tools_b.keys())):
            sa = tools_a.get(tool, "absent")
            sb = tools_b.get(tool, "absent")
            if sa != sb:
                status_changes.append({"tool": tool, "from": sa, "to": sb})

        return {
            "session_a":       session_id_a,
            "session_b":       session_id_b,
            "target_a":        a.target,
            "target_b":        b.target,
            "findings_a":      a.total_findings,
            "findings_b":      b.total_findings,
            "findings_delta":  b.total_findings - a.total_findings,
            "duration_a_s":    a.duration_s,
            "duration_b_s":    b.duration_s,
            "duration_delta_s": b.duration_s - a.duration_s,
            "status_changes":  status_changes,
            "new_tools":       [t for t in tools_b if t not in tools_a],
            "removed_tools":   [t for t in tools_a if t not in tools_b],
        }

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _session_to_definition(
        self,
        session:     WorkflowSession,
        skip_failed: bool = False,
    ) -> WorkflowDefinition:
        steps = session.steps
        if skip_failed:
            steps = [s for s in steps if s.status != StepStatus.FAILED]
        return self._session_to_definition_from_steps(session.workflow_name, steps)

    def _session_to_definition_from_steps(
        self,
        workflow_name: str,
        steps:         list,
    ) -> WorkflowDefinition:
        from .schemas import WorkflowStep
        # Clone steps with PENDING status for fresh execution
        fresh_steps = [
            WorkflowStep.from_dict({
                **s.to_dict(),
                "status":       "pending",
                "error":        "",
                "attempts":     0,
                "started_at":   0.0,
                "finished_at":  0.0,
                "finding_count": 0,
            })
            for s in steps
        ]
        return WorkflowDefinition(
            name        = workflow_name,
            description = f"Replayed from session",
            steps       = fresh_steps,
        )

    def _prepare_for_resume(self, session: WorkflowSession) -> WorkflowSession:
        """Mark non-successful steps as PENDING for resume."""
        for step in session.steps:
            if step.status not in (StepStatus.SUCCESS,):
                step.status      = StepStatus.PENDING
                step.error       = ""
                step.attempts    = 0
                step.started_at  = 0.0
                step.finished_at = 0.0
        session.status = WorkflowStatus.RUNNING
        session.failed_steps.clear()
        return session

    def _apply_edits(self, wf_def: WorkflowDefinition, edits: dict) -> None:
        """Apply edit overrides to a WorkflowDefinition in-place."""
        if "name" in edits:
            wf_def.name = edits["name"]
        if "description" in edits:
            wf_def.description = edits["description"]
        if "steps_to_remove" in edits:
            remove_set = set(edits["steps_to_remove"])
            wf_def.steps = [s for s in wf_def.steps
                            if s.tool_class not in remove_set]
        if "steps_to_add" in edits:
            from .schemas import WorkflowStep
            for step_dict in edits["steps_to_add"]:
                wf_def.steps.append(WorkflowStep.from_dict(step_dict))
