"""
ReconX — Stage 16: Checkpoint Manager.

Provides crash-resistant workflow resumption by saving incremental
state checkpoints during execution. If a scan is interrupted (crash,
Ctrl-C, network failure, machine restart), ReconX can continue from
the last saved step instead of starting over.

Checkpoint files are stored in: sessions/checkpoints/<session_id>.ckpt.json

Usage:
    from reconx.workflow.checkpoint import CheckpointManager

    # Save after each step
    ckpt = CheckpointManager()
    ckpt.save(session)

    # Resume on next run
    session = ckpt.load("session_20250101_120000_abc123")
    if session:
        engine.execute(workflow, target, resume_from=session)
"""
from __future__ import annotations

import json
import logging
import time
from pathlib import Path
from typing import Optional

from .schemas import StepStatus, WorkflowSession, WorkflowStatus

log = logging.getLogger("reconx.workflow.checkpoint")

_CHECKPOINT_DIR = "sessions/checkpoints"


class CheckpointManager:
    """
    Incremental checkpoint writer and reader.

    Design:
      - Writes atomically (write to .tmp then rename) to prevent
        corrupted checkpoints from crash mid-write.
      - Keeps only the latest checkpoint per session (overwrites).
      - Detects interrupted sessions automatically on startup.
    """

    def __init__(self, checkpoint_dir: str = _CHECKPOINT_DIR):
        self.ckpt_dir = Path(checkpoint_dir)
        self.ckpt_dir.mkdir(parents=True, exist_ok=True)

    # ── Save ──────────────────────────────────────────────────────────────────

    def save(self, session: WorkflowSession) -> str:
        """
        Atomically write a checkpoint for session.

        Returns the checkpoint path. Safe to call from a callback
        after every step — uses tmp-then-rename to avoid corruption.
        """
        path = self._ckpt_path(session.session_id)
        tmp  = path.with_suffix(".tmp")

        try:
            data = session.to_dict()
            data["_checkpoint_ts"] = time.time()
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump(data, fh, indent=2, default=str)
            tmp.rename(path)
            session.checkpoint_path = str(path)
            log.debug(f"Checkpoint saved: {path}")
        except Exception as exc:
            log.warning(f"Checkpoint write failed for {session.session_id}: {exc}")
            if tmp.exists():
                tmp.unlink(missing_ok=True)
            raise

        return str(path)

    # ── Load ──────────────────────────────────────────────────────────────────

    def load(self, session_id: str) -> Optional[WorkflowSession]:
        """
        Load checkpoint for session_id.

        Returns None if no checkpoint exists or file is corrupted.
        On load, the session status is reset to RUNNING so the engine
        can continue execution from the first incomplete step.
        """
        path = self._ckpt_path(session_id)
        if not path.exists():
            log.debug(f"No checkpoint for: {session_id}")
            return None

        try:
            with open(path, encoding="utf-8") as fh:
                data = json.load(fh)
            session = WorkflowSession.from_dict(data)
            # Reset state for resumption
            session.status = WorkflowStatus.RUNNING
            # Reset failed/pending steps to allow retry
            for step in session.steps:
                if step.status in (StepStatus.FAILED, StepStatus.RETRYING,
                                   StepStatus.RUNNING, StepStatus.CANCELLED):
                    step.status      = StepStatus.PENDING
                    step.error       = ""
                    step.attempts    = 0
                    step.started_at  = 0.0
                    step.finished_at = 0.0
            log.info(f"Checkpoint loaded for {session_id}: "
                     f"{session.success_count} steps already completed")
            return session
        except Exception as exc:
            log.error(f"Checkpoint load failed for {session_id}: {exc}")
            return None

    # ── Management ────────────────────────────────────────────────────────────

    def exists(self, session_id: str) -> bool:
        return self._ckpt_path(session_id).exists()

    def delete(self, session_id: str) -> None:
        path = self._ckpt_path(session_id)
        if path.exists():
            path.unlink()
            log.debug(f"Checkpoint deleted: {session_id}")

    def list_interrupted(self) -> list[dict]:
        """
        Scan checkpoint directory and return sessions that were
        interrupted before completion (not in COMPLETED state).
        """
        interrupted = []
        for p in self.ckpt_dir.glob("*.ckpt.json"):
            try:
                with open(p, encoding="utf-8") as fh:
                    d = json.load(fh)
                status = d.get("status", "unknown")
                if status not in ("completed",):
                    completed_steps = sum(
                        1 for s in d.get("steps", [])
                        if s.get("status") == "success"
                    )
                    total_steps = len(d.get("steps", []))
                    interrupted.append({
                        "session_id":      d.get("session_id", p.stem),
                        "workflow_name":   d.get("workflow_name", "unknown"),
                        "target":          d.get("target", "?"),
                        "status":          status,
                        "completed_steps": completed_steps,
                        "total_steps":     total_steps,
                        "checkpoint_ts":   d.get("_checkpoint_ts", 0),
                        "path":            str(p),
                    })
            except Exception:
                pass
        return sorted(interrupted, key=lambda x: x["checkpoint_ts"], reverse=True)

    # ── Callback factory ──────────────────────────────────────────────────────

    def make_step_callback(self, session: WorkflowSession):
        """
        Return an on_step_done callback that saves a checkpoint after
        every successful step. Suitable for passing to WorkflowEngine.
        """
        ckpt = self

        def _on_step_done(step, _session):
            if step.status.value in ("success", "failed"):
                try:
                    ckpt.save(_session)
                except Exception:
                    pass  # Non-fatal — do not disrupt execution

        return _on_step_done

    # ── Internal ──────────────────────────────────────────────────────────────

    def _ckpt_path(self, session_id: str) -> Path:
        safe = session_id.replace("/", "_").replace("\\", "_")
        return self.ckpt_dir / f"{safe}.ckpt.json"
