"""
ReconX — Stage 16: Workflow Schemas & Data Models.

Defines the core data structures used by every component of the
workflow engine: definitions, steps, sessions, checkpoints, and
execution events.

All models use dataclasses for lightweight, serialisable state.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional


# ─────────────────────────────────────────────────────────────────────────────
# Enumerations
# ─────────────────────────────────────────────────────────────────────────────

class StepStatus(str, Enum):
    PENDING   = "pending"
    RUNNING   = "running"
    SUCCESS   = "success"
    FAILED    = "failed"
    SKIPPED   = "skipped"
    RETRYING  = "retrying"
    CANCELLED = "cancelled"


class WorkflowStatus(str, Enum):
    CREATED      = "created"
    RUNNING      = "running"
    PAUSED       = "paused"
    COMPLETED    = "completed"
    FAILED       = "failed"
    INTERRUPTED  = "interrupted"


class ExecutionMode(str, Enum):
    SEQUENTIAL = "sequential"
    PARALLEL   = "parallel"
    CONDITIONAL = "conditional"


# ─────────────────────────────────────────────────────────────────────────────
# Workflow Step
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class WorkflowStep:
    """
    One execution step inside a workflow.

    A step maps 1-to-1 with a tool class name from the ToolRegistry.
    It carries static kwargs, dependency information, and runtime state.
    """
    tool_class:   str                             # ToolRegistry class name
    description:  str          = ""
    stage:        int          = 2                # 1=passive 2=active 3=deep
    priority:     int          = 50               # lower runs first in parallel groups
    required:     bool         = False            # failure halts workflow if True
    depends_on:   list[str]    = field(default_factory=list)   # other tool_class names
    parallel_group: Optional[str] = None          # steps with same group run in parallel
    max_retries:  int          = 1
    timeout_s:    Optional[int] = None
    kwargs:       dict         = field(default_factory=dict)
    condition:    Optional[str] = None            # e.g. "has_subdomains" — evaluated at runtime

    # Runtime state (populated during execution)
    status:       StepStatus   = StepStatus.PENDING
    result:       Optional[Any] = field(default=None, repr=False)
    error:        str          = ""
    attempts:     int          = 0
    started_at:   float        = 0.0
    finished_at:  float        = 0.0
    finding_count: int         = 0

    @property
    def duration_s(self) -> float:
        if self.started_at and self.finished_at:
            return self.finished_at - self.started_at
        return 0.0

    def to_dict(self) -> dict:
        return {
            "tool_class":     self.tool_class,
            "description":    self.description,
            "stage":          self.stage,
            "priority":       self.priority,
            "required":       self.required,
            "depends_on":     self.depends_on,
            "parallel_group": self.parallel_group,
            "max_retries":    self.max_retries,
            "timeout_s":      self.timeout_s,
            "kwargs":         self.kwargs,
            "condition":      self.condition,
            "status":         self.status.value,
            "error":          self.error,
            "attempts":       self.attempts,
            "started_at":     self.started_at,
            "finished_at":    self.finished_at,
            "duration_s":     self.duration_s,
            "finding_count":  self.finding_count,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "WorkflowStep":
        step = cls(
            tool_class     = d["tool_class"],
            description    = d.get("description", ""),
            stage          = d.get("stage", 2),
            priority       = d.get("priority", 50),
            required       = d.get("required", False),
            depends_on     = d.get("depends_on", []),
            parallel_group = d.get("parallel_group"),
            max_retries    = d.get("max_retries", 1),
            timeout_s      = d.get("timeout_s"),
            kwargs         = d.get("kwargs", {}),
            condition      = d.get("condition"),
        )
        step.status        = StepStatus(d.get("status", "pending"))
        step.error         = d.get("error", "")
        step.attempts      = d.get("attempts", 0)
        step.started_at    = d.get("started_at", 0.0)
        step.finished_at   = d.get("finished_at", 0.0)
        step.finding_count = d.get("finding_count", 0)
        return step


# ─────────────────────────────────────────────────────────────────────────────
# Workflow Definition
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class WorkflowDefinition:
    """
    Blueprint for a recon workflow.

    Defines which tools run, in what order, with what parallelism,
    and under what conditions. Serialisable to/from JSON for
    storage in templates and session files.
    """
    name:          str
    description:   str
    category:      str           = "general"     # passive|active|web|cloud|etc.
    steps:         list[WorkflowStep] = field(default_factory=list)
    target_types:  list[str]     = field(default_factory=list)  # domain|ip|cidr|url|email
    tags:          list[str]     = field(default_factory=list)
    author:        str           = "ReconX"
    version:       str           = "1.0.0"
    estimated_min: int           = 0
    requires_root: bool          = False

    # Computed metadata
    @property
    def step_count(self) -> int:
        return len(self.steps)

    @property
    def parallel_groups(self) -> set[str]:
        return {s.parallel_group for s in self.steps if s.parallel_group}

    def tool_sequence(self) -> list[str]:
        """Return ordered list of tool class names."""
        return [s.tool_class for s in self.steps]

    def to_dict(self) -> dict:
        return {
            "name":          self.name,
            "description":   self.description,
            "category":      self.category,
            "steps":         [s.to_dict() for s in self.steps],
            "target_types":  self.target_types,
            "tags":          self.tags,
            "author":        self.author,
            "version":       self.version,
            "estimated_min": self.estimated_min,
            "requires_root": self.requires_root,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "WorkflowDefinition":
        wf = cls(
            name          = d["name"],
            description   = d.get("description", ""),
            category      = d.get("category", "general"),
            target_types  = d.get("target_types", []),
            tags          = d.get("tags", []),
            author        = d.get("author", "ReconX"),
            version       = d.get("version", "1.0.0"),
            estimated_min = d.get("estimated_min", 0),
            requires_root = d.get("requires_root", False),
        )
        wf.steps = [WorkflowStep.from_dict(s) for s in d.get("steps", [])]
        return wf


# ─────────────────────────────────────────────────────────────────────────────
# Workflow Session  (one live execution of a WorkflowDefinition)
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class WorkflowSession:
    """
    Records the full lifecycle of a workflow execution.

    Created by WorkflowEngine.execute() and persisted by WorkflowRecorder.
    Can be replayed, cloned, or resumed via WorkflowReplayer.
    """
    session_id:     str
    workflow_name:  str
    target:         str
    status:         WorkflowStatus      = WorkflowStatus.CREATED
    steps:          list[WorkflowStep]  = field(default_factory=list)
    context:        dict                = field(default_factory=dict)  # accumulated findings
    events:         list[dict]          = field(default_factory=list)  # timeline events

    # Timing
    started_at:     float               = field(default_factory=time.time)
    finished_at:    float               = 0.0
    paused_at:      float               = 0.0

    # Summary
    total_findings: int                 = 0
    failed_steps:   list[str]           = field(default_factory=list)
    skipped_steps:  list[str]           = field(default_factory=list)

    # Metadata
    workflow_def:   Optional[dict]      = field(default=None, repr=False)
    checkpoint_path: Optional[str]      = None
    learning_resources: list[str]       = field(default_factory=list)

    @property
    def duration_s(self) -> float:
        end = self.finished_at or time.time()
        return end - self.started_at

    @property
    def success_count(self) -> int:
        return sum(1 for s in self.steps if s.status == StepStatus.SUCCESS)

    @property
    def failed_count(self) -> int:
        return len(self.failed_steps)

    def add_event(self, event_type: str, tool: str, detail: str = "") -> None:
        self.events.append({
            "ts":    time.time(),
            "type":  event_type,
            "tool":  tool,
            "detail": detail,
        })

    def to_dict(self) -> dict:
        return {
            "session_id":         self.session_id,
            "workflow_name":      self.workflow_name,
            "target":             self.target,
            "status":             self.status.value,
            "steps":              [s.to_dict() for s in self.steps],
            "context":            {k: v for k, v in self.context.items()
                                   if isinstance(v, (str, int, float, list, dict, bool))},
            "events":             self.events,
            "started_at":         self.started_at,
            "finished_at":        self.finished_at,
            "total_findings":     self.total_findings,
            "failed_steps":       self.failed_steps,
            "skipped_steps":      self.skipped_steps,
            "workflow_def":       self.workflow_def,
            "checkpoint_path":    self.checkpoint_path,
            "learning_resources": self.learning_resources,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "WorkflowSession":
        sess = cls(
            session_id         = d["session_id"],
            workflow_name      = d["workflow_name"],
            target             = d["target"],
            started_at         = d.get("started_at", 0.0),
        )
        sess.status             = WorkflowStatus(d.get("status", "created"))
        sess.steps              = [WorkflowStep.from_dict(s) for s in d.get("steps", [])]
        sess.context            = d.get("context", {})
        sess.events             = d.get("events", [])
        sess.finished_at        = d.get("finished_at", 0.0)
        sess.total_findings     = d.get("total_findings", 0)
        sess.failed_steps       = d.get("failed_steps", [])
        sess.skipped_steps      = d.get("skipped_steps", [])
        sess.workflow_def       = d.get("workflow_def")
        sess.checkpoint_path    = d.get("checkpoint_path")
        sess.learning_resources = d.get("learning_resources", [])
        return sess
