"""
ReconX — Stage 16: Workflow Planner.

Translates high-level reconnaissance goals into concrete, ordered
workflow definitions. Currently implemented as an expert rule-based
system; the interface is intentionally designed for future LLM
augmentation without breaking changes.

Inputs:
  goal         — natural language objective string
  target_type  — classified target type (domain | ip | cidr | url | email | asn)
  risk_profile — low | medium | high  (controls tool selection depth)
  constraints  — dict of optional constraints (e.g. {"passive_only": True})

Outputs:
  WorkflowDefinition — a ready-to-execute workflow

Usage:
    from reconx.workflow.planner import WorkflowPlanner

    planner = WorkflowPlanner()
    workflow = planner.plan(
        goal="Find attack surface of target org",
        target_type="domain",
        risk_profile="high",
    )
    print(workflow.name, [s.tool_class for s in workflow.steps])
"""
from __future__ import annotations

import logging
import re
from typing import Optional

from .schemas import WorkflowDefinition, WorkflowStep
from .templates import WorkflowTemplates

log = logging.getLogger("reconx.workflow.planner")


# ─────────────────────────────────────────────────────────────────────────────
# Goal keyword mappings
# ─────────────────────────────────────────────────────────────────────────────

# Maps keyword patterns → recommended template name
_KEYWORD_TEMPLATES: list[tuple[list[str], str]] = [
    # Passive / OSINT
    (["passive", "osint", "stealth", "silent", "no traffic"],    "passive_recon"),
    # Fast / quick
    (["fast", "quick", "rapid", "speed", "5 min"],               "fast_scan"),
    # Web / HTTP
    (["web", "http", "website", "login", "endpoint", "waf",
      "panel", "directory", "hidden page"],                       "web_application"),
    # API
    (["api", "graphql", "rest", "openapi", "swagger",
      "endpoint", "grpc"],                                        "api_recon"),
    # Cloud
    (["cloud", "s3", "bucket", "aws", "gcp", "azure",
      "storage", "blob"],                                         "cloud_recon"),
    # Bug bounty
    (["bug bounty", "bug-bounty", "takeover", "cors",
      "ssrf", "idor", "hacker"],                                  "bug_bounty"),
    # Internal / LAN
    (["internal", "lan", "smb", "intranet", "vpn",
      "network", "corporate", "active directory"],                "internal_network"),
    # Enterprise
    (["enterprise", "assessment", "audit", "pentest",
      "penetration", "professional"],                             "enterprise_assessment"),
    # Full / complete
    (["full", "complete", "everything", "attack surface",
      "map all", "comprehensive"],                                "full_attack_surface"),
    # Deep
    (["deep", "thorough", "detailed", "maximum"],                 "deep_scan"),
    # Default active
    (["active", "scan", "enumerate", "discover", "find"],         "active_recon"),
]

# Maps target type → suggested baseline template (used when no goal keywords match)
_TARGET_DEFAULT_TEMPLATE: dict[str, str] = {
    "domain": "active_recon",
    "ip":     "active_recon",
    "cidr":   "internal_network",
    "url":    "web_application",
    "email":  "passive_recon",
    "asn":    "passive_recon",
}


# ─────────────────────────────────────────────────────────────────────────────
# Planner
# ─────────────────────────────────────────────────────────────────────────────

class WorkflowPlanner:
    """
    Expert rule-based workflow planner with LLM-ready interface.

    The plan() method returns a WorkflowDefinition that is immediately
    executable by WorkflowEngine without further modification.

    Future: replace _select_template() with an LLM call that receives
    target classification, available tools, and risk context.
    """

    def plan(
        self,
        goal:         str,
        target_type:  str              = "domain",
        risk_profile: str              = "medium",     # low | medium | high
        constraints:  Optional[dict]   = None,
    ) -> WorkflowDefinition:
        """
        Generate a WorkflowDefinition from a natural-language goal.

        Args:
            goal:         Plain-English reconnaissance objective.
            target_type:  Classified target type from TargetClassifier.
            risk_profile: Controls depth — 'low'=passive, 'medium'=balanced,
                          'high'=full active.
            constraints:  Optional dict:
                            passive_only  (bool)  — exclude active tools
                            fast          (bool)  — limit to top-3 tools
                            exclude_tools (list)  — tool class names to skip
                            max_steps     (int)   — cap step count

        Returns:
            WorkflowDefinition ready for WorkflowEngine.execute().
        """
        constraints = constraints or {}
        goal_lower  = goal.lower().strip()

        log.info(f"Planning workflow: goal={goal_lower!r} "
                 f"target_type={target_type} risk={risk_profile}")

        # Force passive if risk is low or constraint set
        if risk_profile == "low" or constraints.get("passive_only"):
            template_name = "passive_recon"
        elif constraints.get("fast"):
            template_name = "fast_scan"
        else:
            template_name = self._select_template(goal_lower, target_type)

        base_wf = WorkflowTemplates.get(template_name)
        if not base_wf:
            log.warning(f"Template '{template_name}' not found — using active_recon")
            base_wf = WorkflowTemplates.get("active_recon")

        # Clone to avoid mutating the global template
        wf = WorkflowDefinition.from_dict(base_wf.to_dict())
        wf.name = f"planned_{template_name}"
        wf.description = (
            f"Auto-planned for goal: \"{goal[:80]}\"\n"
            f"Base: {base_wf.name} | Target: {target_type} | Risk: {risk_profile}"
        )

        # Apply depth adjustments
        self._apply_risk_profile(wf, risk_profile)

        # Apply constraints
        self._apply_constraints(wf, constraints)

        log.info(f"Plan complete: '{wf.name}' ({wf.step_count} steps) "
                 f"from template '{template_name}'")
        return wf

    def explain(
        self,
        goal:        str,
        target_type: str = "domain",
    ) -> dict:
        """
        Return a human-readable explanation of how a goal would be planned.

        Useful for the Guided Recon "why?" display before execution.
        """
        goal_lower    = goal.lower().strip()
        template_name = self._select_template(goal_lower, target_type)
        wf            = WorkflowTemplates.get(template_name)

        if not wf:
            return {"template": "unknown", "reason": "No matching template found."}

        matched_kw = self._matched_keywords(goal_lower)

        return {
            "goal":         goal,
            "template":     template_name,
            "matched_on":   matched_kw,
            "description":  wf.description,
            "steps":        [
                {"tool": s.tool_class, "stage": s.stage,
                 "parallel_group": s.parallel_group}
                for s in wf.steps
            ],
            "estimated_min": wf.estimated_min,
            "requires_root": wf.requires_root,
            "reasoning": (
                f"Goal keywords matched '{', '.join(matched_kw)}' → "
                f"selected template '{template_name}'."
                if matched_kw
                else f"No strong keyword match; defaulting to "
                     f"'{template_name}' for target type '{target_type}'."
            ),
        }

    def recommend_for_objective(self, objective: str) -> list[dict]:
        """
        Given an objective string, return ranked template suggestions.

        Suitable for the Guided Recon objective picker.
        """
        objective_lower = objective.lower()
        scored: list[tuple[float, WorkflowDefinition]] = []

        for wf in WorkflowTemplates.list_all():
            score = 0.0
            for kw in wf.tags:
                if kw.replace("-", " ") in objective_lower:
                    score += 1.0
            for kw in wf.name.split("_"):
                if kw in objective_lower:
                    score += 0.5
            if score > 0:
                scored.append((score, wf))

        scored.sort(key=lambda x: -x[0])
        return [
            {
                "name":          wf.name,
                "description":   wf.description,
                "category":      wf.category,
                "steps":         wf.step_count,
                "estimated_min": wf.estimated_min,
                "score":         sc,
            }
            for sc, wf in scored[:5]
        ]

    # ── Internal ──────────────────────────────────────────────────────────────

    def _select_template(self, goal_lower: str, target_type: str) -> str:
        """Match goal text against keyword table; fall back to target default."""
        for keywords, template in _KEYWORD_TEMPLATES:
            for kw in keywords:
                if kw in goal_lower:
                    return template
        return _TARGET_DEFAULT_TEMPLATE.get(target_type, "active_recon")

    def _matched_keywords(self, goal_lower: str) -> list[str]:
        """Return first set of matching keywords from the table."""
        for keywords, _ in _KEYWORD_TEMPLATES:
            matched = [kw for kw in keywords if kw in goal_lower]
            if matched:
                return matched
        return []

    def _apply_risk_profile(self, wf: WorkflowDefinition, risk: str) -> None:
        """
        Adjust step selection based on risk profile.

        low    — keep only stage 1 (passive) steps
        medium — keep stages 1-2
        high   — keep all stages (default — no change)
        """
        if risk == "low":
            wf.steps = [s for s in wf.steps if s.stage <= 1]
        elif risk == "medium":
            wf.steps = [s for s in wf.steps if s.stage <= 2]
        # high: no filtering

    def _apply_constraints(self, wf: WorkflowDefinition, constraints: dict) -> None:
        """Apply caller-specified constraints to the workflow."""
        if constraints.get("passive_only"):
            wf.steps = [s for s in wf.steps if s.stage == 1]

        if "exclude_tools" in constraints:
            exclude = set(constraints["exclude_tools"])
            wf.steps = [s for s in wf.steps if s.tool_class not in exclude]

        if "max_steps" in constraints:
            cap = int(constraints["max_steps"])
            wf.steps = wf.steps[:cap]

        if constraints.get("fast"):
            # Keep only top-priority step per stage
            seen_stages: set[int] = set()
            filtered = []
            for step in sorted(wf.steps, key=lambda s: (s.stage, s.priority)):
                if step.stage not in seen_stages:
                    filtered.append(step)
                    seen_stages.add(step.stage)
            wf.steps = filtered
