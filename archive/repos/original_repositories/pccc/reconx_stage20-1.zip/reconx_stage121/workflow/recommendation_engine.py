"""
ReconX — Workflow: Recommendation Engine (Stage 13).

Given a classified target and a scan mode, generates an ordered,
optimised list of tool class names ready for PipelineEngine execution.

Scan modes:
  fast     — passive + quick active (5–15 min)
  balanced — standard recon (30–60 min)
  deep     — thorough, all tools (1–4 hrs)
  passive  — zero active scanning
  custom   — user-specified tool list
  ai       — heuristic scoring (simulates AI recommendation)

Each mode trims, re-orders, and configures the tool list based on:
  • target type (domain, IP, CIDR, email, …)
  • available tools (only includes installed binaries)
  • time budget
  • user preferences
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Optional

from .guided_recon_122 import GUIDED_STEPS_122, STEP_MAP_122

log = logging.getLogger("reconx.workflow.recommendation")


# ─────────────────────────────────────────────────────────────────────────────
# Mode definitions
# ─────────────────────────────────────────────────────────────────────────────

class ScanMode:
    FAST    = "fast"
    BALANCED = "balanced"
    DEEP    = "deep"
    PASSIVE = "passive"
    CUSTOM  = "custom"
    AI      = "ai"

    ALL = [FAST, BALANCED, DEEP, PASSIVE, CUSTOM, AI]


MODE_DESCRIPTIONS: dict[str, str] = {
    ScanMode.FAST:     "Passive + quick active (5–15 min). Ideal for initial triage.",
    ScanMode.BALANCED: "Standard recon covering all key areas (30–60 min). Recommended for most assessments.",
    ScanMode.DEEP:     "Thorough multi-stage scan using all available tools (1–4 hrs).",
    ScanMode.PASSIVE:  "Zero active traffic. OSINT and archive-based only.",
    ScanMode.CUSTOM:   "User-defined tool list and order.",
    ScanMode.AI:       "Heuristic-scored recommendation based on target profile.",
}


# ── Tool lists per target type and mode ──────────────────────────────────────

_DOMAIN_FAST = [
    "WhoisTool", "CrtshTool", "TheHarvesterTool", "Sublist3rTool",
    "HttpxTool", "WhatWebTool", "Wafw00fTool", "GoWitnessTool",
]

_DOMAIN_BALANCED = [
    "WhoisTool", "CrtshTool", "TheHarvesterTool", "GitHubSubdomainsTool",
    "Sublist3rTool", "AmassTool", "DNSReconTool", "AlterxTool",
    "ShuffleDNSTool", "TLSXTool", "HttpxTool", "WhatWebTool",
    "Wafw00fTool", "GauTool", "WaymoreTool", "FeroxbusterTool",
    "ParamSpiderTool", "GoWitnessTool", "S3ScannerTool",
]

_DOMAIN_DEEP = [
    "WhoisTool", "CrtshTool", "TheHarvesterTool", "SpiderFootTool",
    "GitHubSubdomainsTool", "OSRFrameworkTool", "Sublist3rTool",
    "AmassTool", "DNSReconTool", "DNSEnumTool", "FierceTool",
    "AsnmapTool", "AlterxTool", "PureDNSTool", "MassDNSTool",
    "TLSXTool", "TestSSLTool", "HttpxTool", "WhatWebTool",
    "Wafw00fTool", "NmapTool", "GauTool", "WaymoreTool", "WaybackurlsTool",
    "KatanaTool", "HakrawlerTool", "GospiderTool", "FeroxbusterTool",
    "DirbusterTool", "ParamSpiderTool", "ArjunTool", "KiterunnerTool",
    "Graphw00fTool", "GoWitnessTool", "AquatoneTool",
    "S3ScannerTool", "TrufflehogTool", "MaltegoTool",
]

_DOMAIN_PASSIVE = [
    "WhoisTool", "CrtshTool", "TheHarvesterTool", "Sublist3rTool",
    "GauTool", "WaybackurlsTool", "WaymoreTool", "S3ScannerTool",
    "GitHubSubdomainsTool", "SpiderFootTool", "MaltegoTool",
]

_IP_FAST = [
    "NmapTool", "NetcatWrapperTool", "TLSXTool", "Wafw00fTool",
]

_IP_BALANCED = [
    "NmapTool", "NetcatWrapperTool", "TLSXTool", "TestSSLTool",
    "Wafw00fTool", "HttpxTool", "WhatWebTool", "GoWitnessTool",
]

_IP_DEEP = [
    "NmapTool", "MetasploitAuxTool", "NetcatWrapperTool", "TLSXTool",
    "TestSSLTool", "Wafw00fTool", "HttpxTool", "WhatWebTool",
    "FeroxbusterTool", "KiterunnerTool", "GoWitnessTool", "AquatoneTool",
]

_CIDR_ANY = [
    "AsnmapTool", "MapCIDRTool", "FpingTool", "NetdiscoverTool", "NmapTool",
]

_ASN_ANY = [
    "AsnmapTool", "MapCIDRTool", "FpingTool", "NmapTool",
]

_EMAIL_ANY = [
    "TheHarvesterTool", "OSRFrameworkTool", "HoleheTool",
    "SherlockTool", "SpiderFootTool",
]

_PHONE_ANY = [
    "PhoneInfogaTool",
]

_URL_FAST = [
    "HttpxTool", "WhatWebTool", "Wafw00fTool", "GauTool",
]

_URL_DEEP = [
    "HttpxTool", "WhatWebTool", "Wafw00fTool", "GauTool", "WaymoreTool",
    "KatanaTool", "GospiderTool", "FeroxbusterTool", "ParamSpiderTool",
    "ArjunTool", "KiterunnerTool", "Graphw00fTool", "GoWitnessTool",
]

_GITHUB_ANY = [
    "GitHubSubdomainsTool", "TrufflehogTool", "GitleaksTool",
]

_CLOUD_ANY = [
    "AsnmapTool", "S3ScannerTool", "TrufflehogTool", "CrtshTool",
]

# Master map: (target_type, mode) → tool list
_TOOL_MAP: dict[tuple[str, str], list[str]] = {
    ("domain",    ScanMode.FAST):    _DOMAIN_FAST,
    ("domain",    ScanMode.BALANCED): _DOMAIN_BALANCED,
    ("domain",    ScanMode.DEEP):    _DOMAIN_DEEP,
    ("domain",    ScanMode.PASSIVE): _DOMAIN_PASSIVE,
    ("domain",    ScanMode.AI):      _DOMAIN_BALANCED,   # AI uses balanced as base
    ("subdomain", ScanMode.FAST):    _IP_FAST + ["TLSXTool"],
    ("subdomain", ScanMode.BALANCED): _DOMAIN_BALANCED,
    ("subdomain", ScanMode.DEEP):    _DOMAIN_DEEP,
    ("ip",        ScanMode.FAST):    _IP_FAST,
    ("ip",        ScanMode.BALANCED): _IP_BALANCED,
    ("ip",        ScanMode.DEEP):    _IP_DEEP,
    ("ip",        ScanMode.PASSIVE): ["CrtshTool"],
    ("cidr",      ScanMode.FAST):    _CIDR_ANY[:3],
    ("cidr",      ScanMode.BALANCED): _CIDR_ANY,
    ("cidr",      ScanMode.DEEP):    _CIDR_ANY + _IP_DEEP,
    ("asn",       ScanMode.FAST):    _ASN_ANY[:2],
    ("asn",       ScanMode.BALANCED): _ASN_ANY,
    ("asn",       ScanMode.DEEP):    _ASN_ANY + _IP_DEEP,
    ("url",       ScanMode.FAST):    _URL_FAST,
    ("url",       ScanMode.BALANCED): _URL_FAST + ["GauTool", "KatanaTool", "FeroxbusterTool"],
    ("url",       ScanMode.DEEP):    _URL_DEEP,
    ("email",     ScanMode.FAST):    _EMAIL_ANY[:2],
    ("email",     ScanMode.BALANCED): _EMAIL_ANY,
    ("email",     ScanMode.DEEP):    _EMAIL_ANY,
    ("phone",     ScanMode.FAST):    _PHONE_ANY,
    ("phone",     ScanMode.BALANCED): _PHONE_ANY,
    ("phone",     ScanMode.DEEP):    _PHONE_ANY,
    ("github_repo", ScanMode.FAST):  _GITHUB_ANY[:2],
    ("github_repo", ScanMode.DEEP):  _GITHUB_ANY,
    ("github_org",  ScanMode.FAST):  _GITHUB_ANY[:1],
    ("github_org",  ScanMode.DEEP):  _GITHUB_ANY + _DOMAIN_PASSIVE,
    ("cloud_bucket", ScanMode.FAST): ["S3ScannerTool"],
    ("cloud_bucket", ScanMode.DEEP): _CLOUD_ANY,
}


# ─────────────────────────────────────────────────────────────────────────────
# Recommendation result
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class WorkflowRecommendation:
    target:       str
    target_type:  str
    mode:         str
    tool_list:    list[str]
    estimated_min: int
    description:  str
    steps:        list[dict]    = field(default_factory=list)
    skipped_unavailable: list[str] = field(default_factory=list)
    rationale:    str           = ""

    def to_pipeline_tasks(self, target: str):
        """Convert to PipelineTask list for PipelineEngine."""
        try:
            from reconx.orchestration.pipeline_engine import PipelineTask
        except ModuleNotFoundError:
            from orchestration.pipeline_engine import PipelineTask
        return [PipelineTask(tool_class=tc, target=target) for tc in self.tool_list]

    def summary(self) -> str:
        lines = [
            f"Mode       : {self.mode.upper()} — {self.description}",
            f"Target     : {self.target} ({self.target_type})",
            f"Tools      : {len(self.tool_list)}",
            f"Est. time  : ~{self.estimated_min} minutes",
            "",
            "Tool execution order:",
        ]
        for i, tc in enumerate(self.tool_list, 1):
            lines.append(f"  {i:>2}. {tc}")
        if self.skipped_unavailable:
            lines += ["", "⚠ Not available (install to enable):"]
            for tc in self.skipped_unavailable:
                lines.append(f"     – {tc}")
        return "\n".join(lines)


# ─────────────────────────────────────────────────────────────────────────────
# Recommendation engine
# ─────────────────────────────────────────────────────────────────────────────

class RecommendationEngine:
    """
    Generates workflow recommendations from a ClassifiedTarget + ScanMode.

    Usage:
        engine = RecommendationEngine(registry)
        rec    = engine.recommend(classified_target, ScanMode.BALANCED)
        tasks  = rec.to_pipeline_tasks(target)
    """

    # Estimated minutes per tool class (rough)
    _TOOL_TIMES: dict[str, int] = {
        "WhoisTool": 1, "CrtshTool": 1, "TheHarvesterTool": 3,
        "Sublist3rTool": 5, "AmassTool": 10, "DNSReconTool": 3,
        "DNSEnumTool": 5, "FierceTool": 5, "AlterxTool": 2,
        "MassDNSTool": 5, "ShuffleDNSTool": 5, "PureDNSTool": 8,
        "NmapTool": 10, "FpingTool": 2, "NetdiscoverTool": 3,
        "HttpxTool": 3, "WhatWebTool": 2, "Wafw00fTool": 2,
        "GauTool": 3, "WaymoreTool": 5, "KatanaTool": 10,
        "GospiderTool": 8, "FeroxbusterTool": 15, "ParamSpiderTool": 3,
        "ArjunTool": 5, "KiterunnerTool": 10, "GoWitnessTool": 5,
        "AquatoneTool": 8, "TrufflehogTool": 10, "GitleaksTool": 5,
        "S3ScannerTool": 3, "TestSSLTool": 5, "TLSXTool": 2,
        "SpiderFootTool": 15, "MaltegoTool": 3,
    }

    def __init__(self, registry=None):
        self.registry = registry

    def recommend(
        self,
        classified_target,           # ClassifiedTarget instance
        mode:      str = ScanMode.BALANCED,
        custom_tools: Optional[list[str]] = None,
        filter_unavailable: bool = True,
    ) -> WorkflowRecommendation:
        ttype = classified_target.target_type
        target = classified_target.normalized or classified_target.raw

        if mode == ScanMode.CUSTOM:
            tool_list = list(custom_tools or [])
        elif mode == ScanMode.PASSIVE:
            tool_list = _TOOL_MAP.get((ttype, ScanMode.PASSIVE),
                        _TOOL_MAP.get(("domain", ScanMode.PASSIVE), []))
        elif mode == ScanMode.AI:
            tool_list = self._ai_recommend(ttype, classified_target)
        else:
            key = (ttype, mode)
            fallback_key = ("domain", mode)
            tool_list = list(_TOOL_MAP.get(key, _TOOL_MAP.get(fallback_key, _DOMAIN_BALANCED)))

        # Deduplicate preserving order
        tool_list = list(dict.fromkeys(tool_list))

        # Filter unavailable
        skipped: list[str] = []
        if filter_unavailable and self.registry:
            available = []
            for tc in tool_list:
                meta = self.registry.get(tc)
                if meta and meta.is_available:
                    available.append(tc)
                elif meta:
                    skipped.append(tc)
                else:
                    skipped.append(tc)   # not in registry at all
            tool_list = available

        # Estimate time
        est_min = sum(self._TOOL_TIMES.get(tc, 3) for tc in tool_list)

        # Build step descriptions
        steps = [
            {"order": i + 1, "tool": tc,
             "description": self._step_desc(tc)}
            for i, tc in enumerate(tool_list)
        ]

        return WorkflowRecommendation(
            target       = target,
            target_type  = ttype,
            mode         = mode,
            tool_list    = tool_list,
            estimated_min = est_min,
            description  = MODE_DESCRIPTIONS.get(mode, ""),
            steps        = steps,
            skipped_unavailable = skipped,
            rationale    = self._rationale(ttype, mode),
        )

    def recommend_from_string(self, raw: str, mode: str = ScanMode.BALANCED,
                              **kwargs) -> WorkflowRecommendation:
        try:
            from reconx.analysis.target_classifier import TargetClassifier
        except ModuleNotFoundError:
            from analysis.target_classifier import TargetClassifier
        ct = TargetClassifier.classify(raw)
        return self.recommend(ct, mode, **kwargs)

    # ── AI recommendation ─────────────────────────────────────────────────────

    def _ai_recommend(self, ttype: str, ct) -> list[str]:
        """
        Heuristic-scored recommendation. Scores each tool by:
          - relevance to target type
          - stage appropriateness
          - whether the tool tends to surface high-value findings
        Then sorts and returns top-N.
        """
        # Start from balanced list and score adjustments
        base = list(_TOOL_MAP.get((ttype, ScanMode.BALANCED),
                    _DOMAIN_BALANCED))

        scores: dict[str, int] = {}
        for tc in base:
            score = 50
            if tc in ("CrtshTool", "TheHarvesterTool", "Sublist3rTool"):
                score += 20   # high passive value
            if ttype == "domain" and tc in ("AlterxTool", "PureDNSTool"):
                score += 15
            if ttype in ("ip", "cidr") and tc == "NmapTool":
                score += 25
            if tc in ("TrufflehogTool", "GitleaksTool"):
                score += 10 if ttype in ("domain", "github_repo") else 0
            scores[tc] = score

        return sorted(base, key=lambda tc: -scores.get(tc, 50))

    @staticmethod
    def _step_desc(tool_class: str) -> str:
        _descs = {
            "WhoisTool":          "Domain registration + nameserver discovery",
            "CrtshTool":          "Certificate transparency log mining",
            "TheHarvesterTool":   "Email, subdomain, IP harvesting from OSINT",
            "Sublist3rTool":      "Passive subdomain enumeration",
            "AmassTool":          "Active + passive subdomain enumeration",
            "DNSReconTool":       "Full DNS record enumeration",
            "AlterxTool":         "Subdomain permutation generation",
            "PureDNSTool":        "High-accuracy subdomain validation",
            "NmapTool":           "Port scan + service/version detection",
            "HttpxTool":          "HTTP probing + technology detection",
            "Wafw00fTool":        "WAF fingerprinting",
            "GauTool":            "Historical URL collection",
            "KatanaTool":         "JS-aware web crawling",
            "FeroxbusterTool":    "Recursive content discovery",
            "ParamSpiderTool":    "URL parameter mining from archives",
            "GoWitnessTool":      "Visual web reconnaissance",
            "TrufflehogTool":     "Secret and credential detection",
            "S3ScannerTool":      "Cloud bucket exposure detection",
            "TestSSLTool":        "TLS vulnerability audit",
        }
        return _descs.get(tool_class, tool_class.replace("Tool", ""))

    @staticmethod
    def _rationale(ttype: str, mode: str) -> str:
        rationales: dict[tuple, str] = {
            ("domain", ScanMode.FAST):
                "Fast passive + basic active scan. Covers subdomains, tech, and visual recon.",
            ("domain", ScanMode.BALANCED):
                "Comprehensive domain recon: OSINT → DNS → web → params → visual. "
                "Best for bug-bounty initial assessment.",
            ("domain", ScanMode.DEEP):
                "Full Kali-style recon covering all vectors. Use for thorough assessments.",
            ("ip",    ScanMode.BALANCED):
                "Port scan → service fingerprint → TLS audit → web recon.",
            ("cidr",  ScanMode.BALANCED):
                "ASN mapping → CIDR expansion → host discovery → port scan.",
            ("email", ScanMode.BALANCED):
                "Identity-focused: harvest social profiles, check account existence.",
        }
        return rationales.get((ttype, mode), f"Optimised {mode} workflow for {ttype} targets.")
