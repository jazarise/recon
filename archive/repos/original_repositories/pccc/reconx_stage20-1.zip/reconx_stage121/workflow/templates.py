"""
ReconX — Stage 16: Workflow Templates.

11 pre-built reconnaissance workflow templates covering the most
common professional use-cases.  Each template is a WorkflowDefinition
with well-defined steps, parallelism, ordering, and conditions.

Templates:
  1.  passive_recon          — Zero-traffic OSINT gathering
  2.  active_recon           — Full active enumeration
  3.  fast_scan              — Speed-optimised quick assessment
  4.  deep_scan              — Maximum coverage, all phases
  5.  web_application        — Web app focused reconnaissance
  6.  api_recon              — API surface discovery
  7.  cloud_recon            — Cloud asset and bucket enumeration
  8.  internal_network       — Internal / LAN recon (requires root)
  9.  bug_bounty             — Modern bug bounty chain
 10.  full_attack_surface    — Complete enterprise attack surface map
 11.  enterprise_assessment  — Enterprise security assessment

Usage:
    from reconx.workflow.templates import WorkflowTemplates

    wf = WorkflowTemplates.get("passive_recon")
    all_names = WorkflowTemplates.list_names()
"""
from __future__ import annotations

from typing import Optional

from .schemas import WorkflowDefinition, WorkflowStep


# ─────────────────────────────────────────────────────────────────────────────
# Step builder helpers
# ─────────────────────────────────────────────────────────────────────────────

def _step(
    tool_class:    str,
    description:   str  = "",
    stage:         int  = 2,
    priority:      int  = 50,
    required:      bool = False,
    depends_on:    Optional[list[str]] = None,
    parallel_group: Optional[str] = None,
    max_retries:   int  = 1,
    condition:     Optional[str] = None,
    **kwargs,
) -> WorkflowStep:
    return WorkflowStep(
        tool_class     = tool_class,
        description    = description,
        stage          = stage,
        priority       = priority,
        required       = required,
        depends_on     = depends_on or [],
        parallel_group = parallel_group,
        max_retries    = max_retries,
        condition      = condition,
        kwargs         = kwargs,
    )


# ─────────────────────────────────────────────────────────────────────────────
# Template definitions
# ─────────────────────────────────────────────────────────────────────────────

def _passive_recon() -> WorkflowDefinition:
    """
    Zero-traffic passive recon.
    No active probes — pure OSINT from public sources.
    """
    return WorkflowDefinition(
        name          = "passive_recon",
        description   = "Zero-traffic OSINT reconnaissance using only public data sources. "
                        "Safe for pre-engagement discovery.",
        category      = "passive",
        target_types  = ["domain", "email", "asn"],
        tags          = ["passive", "osint", "safe", "stealth"],
        estimated_min = 10,
        requires_root = False,
        steps=[
            _step("WhoisTool",        "WHOIS registration lookup",     stage=1, priority=10, required=True),
            _step("DNSReconTool",     "DNS record enumeration",         stage=1, priority=20, depends_on=["WhoisTool"]),
            _step("SubfinderTool",    "Passive subdomain discovery",    stage=1, priority=30, parallel_group="passive_subs"),
            _step("AmassPassiveTool", "Amass passive enumeration",      stage=1, priority=30, parallel_group="passive_subs"),
            _step("CrtshTool",        "Certificate transparency logs",  stage=1, priority=30, parallel_group="passive_subs"),
            _step("TheHarvesterTool", "Email/domain OSINT harvesting",  stage=1, priority=40, depends_on=["WhoisTool"]),
            _step("WaybackTool",      "Wayback Machine URL discovery",  stage=1, priority=50, depends_on=["WhoisTool"]),
            _step("ShodanTool",       "Shodan passive host lookup",     stage=1, priority=60),
        ],
    )


def _active_recon() -> WorkflowDefinition:
    """
    Full active recon — port scanning, service detection, OS fingerprinting.
    """
    return WorkflowDefinition(
        name          = "active_recon",
        description   = "Full active reconnaissance with port scanning, service detection, "
                        "OS fingerprinting, and vulnerability identification.",
        category      = "active",
        target_types  = ["domain", "ip", "cidr", "url"],
        tags          = ["active", "scanning", "ports", "services"],
        estimated_min = 20,
        requires_root = False,
        steps=[
            _step("WhoisTool",          "WHOIS lookup",               stage=1, priority=10, required=True),
            _step("DNSReconTool",       "DNS enumeration",            stage=1, priority=20),
            _step("SubfinderTool",      "Subdomain discovery",        stage=1, priority=30, parallel_group="enum"),
            _step("AmassActiveTool",    "Amass active enum",          stage=1, priority=30, parallel_group="enum"),
            _step("HttpxTool",          "HTTP probe live hosts",       stage=2, priority=10,
                  depends_on=["SubfinderTool", "AmassActiveTool"]),
            _step("NmapTool",           "TCP port scan",              stage=2, priority=20,
                  depends_on=["HttpxTool"]),
            _step("ServiceDetectTool",  "Service/version detection",  stage=2, priority=30,
                  depends_on=["NmapTool"]),
            _step("WafDetectTool",      "WAF identification",         stage=2, priority=40,
                  depends_on=["HttpxTool"]),
            _step("NucleiTool",         "Vulnerability templates",    stage=3, priority=10,
                  depends_on=["ServiceDetectTool"], condition="has_live_hosts"),
        ],
    )


def _fast_scan() -> WorkflowDefinition:
    """
    Speed-first: minimal tools, high parallelism, short timeouts.
    """
    return WorkflowDefinition(
        name          = "fast_scan",
        description   = "Speed-optimised quick assessment. Runs only the highest-yield tools "
                        "in parallel to deliver results in under 5 minutes.",
        category      = "active",
        target_types  = ["domain", "ip", "url"],
        tags          = ["fast", "quick", "parallel"],
        estimated_min = 5,
        requires_root = False,
        steps=[
            _step("WhoisTool",       "WHOIS",             stage=1, priority=10, parallel_group="fast_passive"),
            _step("DNSReconTool",    "DNS records",        stage=1, priority=10, parallel_group="fast_passive"),
            _step("SubfinderTool",   "Subdomains",         stage=1, priority=10, parallel_group="fast_passive"),
            _step("HttpxTool",       "HTTP probe",         stage=2, priority=10,
                  depends_on=["SubfinderTool"]),
            _step("NmapFastTool",    "Fast Nmap top-1000", stage=2, priority=20, max_retries=0),
        ],
    )


def _deep_scan() -> WorkflowDefinition:
    """
    Maximum coverage — all phases, all tools, full depth.
    """
    return WorkflowDefinition(
        name          = "deep_scan",
        description   = "Maximum coverage reconnaissance. All passive and active phases, "
                        "full port range, secret scanning, screenshot capture, and reporting.",
        category      = "active",
        target_types  = ["domain", "url"],
        tags          = ["deep", "comprehensive", "all-tools"],
        estimated_min = 60,
        requires_root = False,
        steps=[
            # Phase 1 — Passive
            _step("WhoisTool",          "WHOIS",                 stage=1, priority=10, required=True),
            _step("DNSReconTool",       "DNS enumeration",        stage=1, priority=20),
            _step("SubfinderTool",      "Subfinder passive",      stage=1, priority=30, parallel_group="p1_subs"),
            _step("AmassPassiveTool",   "Amass passive",          stage=1, priority=30, parallel_group="p1_subs"),
            _step("AmassActiveTool",    "Amass active",           stage=1, priority=30, parallel_group="p1_subs"),
            _step("CrtshTool",          "Certificate logs",       stage=1, priority=30, parallel_group="p1_subs"),
            _step("TheHarvesterTool",   "OSINT harvester",        stage=1, priority=40),
            _step("WaybackTool",        "Wayback URLs",           stage=1, priority=50),
            # Phase 2 — Active
            _step("HttpxTool",          "HTTP probe",             stage=2, priority=10,
                  depends_on=["SubfinderTool"]),
            _step("NmapFullTool",       "Full port scan",         stage=2, priority=20,
                  depends_on=["HttpxTool"]),
            _step("ServiceDetectTool",  "Service detection",      stage=2, priority=30,
                  depends_on=["NmapFullTool"]),
            _step("WafDetectTool",      "WAF detection",          stage=2, priority=40,
                  depends_on=["HttpxTool"]),
            _step("GoSpiderTool",       "Web crawler",            stage=2, priority=50,
                  depends_on=["HttpxTool"], condition="has_live_hosts"),
            # Phase 3 — Deep
            _step("SecretFinderTool",   "JS secret scanning",     stage=3, priority=10,
                  depends_on=["GoSpiderTool"], condition="has_urls"),
            _step("LinkFinderTool",     "Endpoint extraction",    stage=3, priority=10,
                  depends_on=["GoSpiderTool"], condition="has_urls"),
            _step("FeroxbusterTool",    "Directory brute-force",  stage=3, priority=20,
                  depends_on=["HttpxTool"], condition="has_live_hosts"),
            _step("NucleiTool",         "Vulnerability scan",     stage=3, priority=30,
                  depends_on=["ServiceDetectTool"], condition="has_live_hosts"),
            _step("GoWitnessTool",      "Screenshot capture",     stage=3, priority=40,
                  depends_on=["HttpxTool"], condition="has_live_hosts"),
        ],
    )


def _web_application() -> WorkflowDefinition:
    """
    Web application recon chain.
    """
    return WorkflowDefinition(
        name          = "web_application",
        description   = "Web application reconnaissance: WAF, crawl, endpoint discovery, "
                        "JavaScript analysis, screenshot capture, and vulnerability templates.",
        category      = "web",
        target_types  = ["domain", "url"],
        tags          = ["web", "http", "endpoints", "javascript"],
        estimated_min = 25,
        requires_root = False,
        steps=[
            _step("WhoisTool",         "WHOIS lookup",          stage=1, priority=10),
            _step("HttpxTool",         "HTTP probe",            stage=1, priority=20, required=True),
            _step("WafDetectTool",     "WAF detection",         stage=1, priority=30,
                  depends_on=["HttpxTool"]),
            _step("GoSpiderTool",      "Web crawler",           stage=2, priority=10,
                  depends_on=["HttpxTool"]),
            _step("KatanaTool",        "Katana crawler",        stage=2, priority=10,
                  depends_on=["HttpxTool"], parallel_group="crawl"),
            _step("LinkFinderTool",    "Endpoint extraction",   stage=2, priority=20,
                  depends_on=["GoSpiderTool"], condition="has_urls"),
            _step("SecretFinderTool",  "JS secret scanning",    stage=2, priority=20,
                  depends_on=["GoSpiderTool"], condition="has_urls"),
            _step("FeroxbusterTool",   "Content discovery",     stage=2, priority=30,
                  depends_on=["HttpxTool"]),
            _step("NucleiWebTool",     "Web vuln templates",    stage=3, priority=10,
                  depends_on=["FeroxbusterTool"], condition="has_live_hosts"),
            _step("GoWitnessTool",     "Screenshot capture",    stage=3, priority=20,
                  depends_on=["HttpxTool"]),
        ],
    )


def _api_recon() -> WorkflowDefinition:
    """
    API surface discovery and analysis.
    """
    return WorkflowDefinition(
        name          = "api_recon",
        description   = "API reconnaissance: endpoint discovery, GraphQL introspection, "
                        "OpenAPI schema extraction, and auth header analysis.",
        category      = "api",
        target_types  = ["domain", "url"],
        tags          = ["api", "graphql", "openapi", "rest"],
        estimated_min = 20,
        requires_root = False,
        steps=[
            _step("HttpxTool",        "HTTP probe",              stage=1, priority=10, required=True),
            _step("GoSpiderTool",     "Crawl for API paths",     stage=1, priority=20,
                  depends_on=["HttpxTool"]),
            _step("LinkFinderTool",   "Extract API endpoints",   stage=2, priority=10,
                  depends_on=["GoSpiderTool"], condition="has_urls"),
            _step("GraphQLTool",      "GraphQL introspection",   stage=2, priority=20,
                  depends_on=["HttpxTool"]),
            _step("OpenAPITool",      "OpenAPI schema fetch",    stage=2, priority=20,
                  depends_on=["HttpxTool"]),
            _step("FfufApiTool",      "API endpoint fuzzing",    stage=2, priority=30,
                  depends_on=["HttpxTool"], condition="has_live_hosts"),
            _step("SecretFinderTool", "API key scanning in JS",  stage=3, priority=10,
                  depends_on=["GoSpiderTool"], condition="has_urls"),
        ],
    )


def _cloud_recon() -> WorkflowDefinition:
    """
    Cloud asset and bucket enumeration.
    """
    return WorkflowDefinition(
        name          = "cloud_recon",
        description   = "Cloud reconnaissance: ASN discovery, S3 bucket enumeration, "
                        "cloud host mapping, certificate analysis, and storage exposure.",
        category      = "cloud",
        target_types  = ["domain", "asn", "cidr"],
        tags          = ["cloud", "aws", "s3", "azure", "gcp", "buckets"],
        estimated_min = 30,
        requires_root = False,
        steps=[
            _step("WhoisTool",       "WHOIS ASN lookup",       stage=1, priority=10),
            _step("ASNMapTool",      "ASN IP range mapping",   stage=1, priority=20,
                  depends_on=["WhoisTool"]),
            _step("CrtshTool",       "Certificate logs",       stage=1, priority=20, parallel_group="cloud_passive"),
            _step("SubfinderTool",   "Cloud subdomain enum",   stage=1, priority=20, parallel_group="cloud_passive"),
            _step("HttpxTool",       "HTTP probe cloud hosts", stage=2, priority=10,
                  depends_on=["SubfinderTool"]),
            _step("S3ScannerTool",   "S3 bucket discovery",    stage=2, priority=20),
            _step("CloudFoxTool",    "Cloud asset enum",       stage=2, priority=20, parallel_group="cloud_enum"),
            _step("GrayhatWarfareTool", "Storage bucket search", stage=2, priority=30, parallel_group="cloud_enum"),
            _step("NucleiCloudTool", "Cloud misconfig templates", stage=3, priority=10,
                  depends_on=["HttpxTool"], condition="has_live_hosts"),
        ],
    )


def _internal_network() -> WorkflowDefinition:
    """
    Internal / LAN reconnaissance (requires elevated privileges).
    """
    return WorkflowDefinition(
        name          = "internal_network",
        description   = "Internal network reconnaissance: host discovery, service mapping, "
                        "SMB enumeration, SNMP, and vulnerability identification.",
        category      = "internal",
        target_types  = ["cidr", "ip"],
        tags          = ["internal", "lan", "smb", "snmp", "network"],
        estimated_min = 25,
        requires_root = True,
        steps=[
            _step("ArpScanTool",      "ARP host discovery",    stage=1, priority=10, required=True),
            _step("NmapHostTool",     "ICMP host discovery",   stage=1, priority=10, parallel_group="discovery"),
            _step("NmapFullTool",     "Full TCP port scan",    stage=2, priority=10,
                  depends_on=["ArpScanTool"], condition="has_live_hosts"),
            _step("ServiceDetectTool","Service detection",     stage=2, priority=20,
                  depends_on=["NmapFullTool"]),
            _step("SmbMapTool",       "SMB share enumeration", stage=2, priority=30,
                  depends_on=["ServiceDetectTool"], condition="has_open_ports"),
            _step("SNMPTool",         "SNMP community string", stage=2, priority=30,
                  depends_on=["NmapFullTool"], condition="has_open_ports"),
            _step("TLSScanTool",      "TLS certificate audit", stage=2, priority=40,
                  depends_on=["ServiceDetectTool"]),
            _step("NucleiTool",       "Vulnerability templates", stage=3, priority=10,
                  depends_on=["ServiceDetectTool"], condition="has_live_hosts"),
        ],
    )


def _bug_bounty() -> WorkflowDefinition:
    """
    Modern bug bounty recon chain.
    """
    return WorkflowDefinition(
        name          = "bug_bounty",
        description   = "Complete modern bug bounty reconnaissance chain: subdomain takeover, "
                        "JS secrets, CORS, open redirect, SSRF, and IDOR surface mapping.",
        category      = "bug_bounty",
        target_types  = ["domain"],
        tags          = ["bug-bounty", "takeover", "cors", "ssrf", "secrets"],
        estimated_min = 45,
        requires_root = False,
        steps=[
            # Passive phase
            _step("WhoisTool",          "WHOIS",                   stage=1, priority=10),
            _step("SubfinderTool",      "Subfinder",               stage=1, priority=20, parallel_group="bb_subs"),
            _step("AmassActiveTool",    "Amass active",            stage=1, priority=20, parallel_group="bb_subs"),
            _step("CrtshTool",          "CT logs",                 stage=1, priority=20, parallel_group="bb_subs"),
            _step("AssetfinderTool",    "Assetfinder",             stage=1, priority=20, parallel_group="bb_subs"),
            _step("WaybackTool",        "Wayback URLs",            stage=1, priority=30),
            # Validation
            _step("HttpxTool",          "HTTP probe",              stage=2, priority=10, required=True,
                  depends_on=["SubfinderTool", "AmassActiveTool"]),
            _step("SubTakeoverTool",    "Subdomain takeover check", stage=2, priority=20,
                  depends_on=["HttpxTool"], condition="has_subdomains"),
            # Web recon
            _step("GoSpiderTool",       "Web crawler",             stage=2, priority=30,
                  depends_on=["HttpxTool"], parallel_group="bb_crawl"),
            _step("KatanaTool",         "Katana crawler",          stage=2, priority=30,
                  depends_on=["HttpxTool"], parallel_group="bb_crawl"),
            _step("FeroxbusterTool",    "Content discovery",       stage=2, priority=40,
                  depends_on=["HttpxTool"]),
            # Analysis
            _step("SecretFinderTool",   "JS secrets",              stage=3, priority=10,
                  depends_on=["GoSpiderTool"], condition="has_urls"),
            _step("LinkFinderTool",     "Endpoint extraction",     stage=3, priority=10,
                  depends_on=["GoSpiderTool"], condition="has_urls"),
            _step("CORScanTool",        "CORS misconfiguration",   stage=3, priority=20,
                  depends_on=["HttpxTool"], condition="has_live_hosts"),
            _step("NucleiTool",         "Nuclei templates",        stage=3, priority=30,
                  depends_on=["ServiceDetectTool"], condition="has_live_hosts"),
            _step("GoWitnessTool",      "Screenshots",             stage=3, priority=40,
                  depends_on=["HttpxTool"]),
        ],
    )


def _full_attack_surface() -> WorkflowDefinition:
    """
    Full enterprise attack surface mapping — all vectors.
    """
    return WorkflowDefinition(
        name          = "full_attack_surface",
        description   = "Complete enterprise attack surface mapping across all vectors: "
                        "domains, ASN, cloud, email, social, code repositories, and APIs.",
        category      = "enterprise",
        target_types  = ["domain", "asn", "email"],
        tags          = ["attack-surface", "enterprise", "comprehensive", "full"],
        estimated_min = 90,
        requires_root = False,
        steps=[
            # Discovery
            _step("WhoisTool",          "WHOIS",              stage=1, priority=10, required=True),
            _step("ASNMapTool",         "ASN mapping",        stage=1, priority=15),
            _step("SubfinderTool",      "Subfinder",          stage=1, priority=20, parallel_group="asm_subs"),
            _step("AmassActiveTool",    "Amass active",       stage=1, priority=20, parallel_group="asm_subs"),
            _step("AmassPassiveTool",   "Amass passive",      stage=1, priority=20, parallel_group="asm_subs"),
            _step("CrtshTool",          "CT logs",            stage=1, priority=20, parallel_group="asm_subs"),
            _step("AssetfinderTool",    "Assetfinder",        stage=1, priority=20, parallel_group="asm_subs"),
            _step("TheHarvesterTool",   "Email/OSINT",        stage=1, priority=30),
            _step("GitLeaksTool",       "GitHub leaks",       stage=1, priority=30),
            _step("WaybackTool",        "Wayback URLs",       stage=1, priority=40),
            # Active
            _step("HttpxTool",          "HTTP probe",         stage=2, priority=10,
                  depends_on=["SubfinderTool"], condition="has_subdomains"),
            _step("NmapFullTool",       "Port scan",          stage=2, priority=20,
                  depends_on=["HttpxTool"]),
            _step("ServiceDetectTool",  "Service detection",  stage=2, priority=30,
                  depends_on=["NmapFullTool"]),
            _step("S3ScannerTool",      "S3 buckets",         stage=2, priority=30),
            _step("CloudFoxTool",       "Cloud assets",       stage=2, priority=30, parallel_group="asm_cloud"),
            _step("GoSpiderTool",       "Crawl",              stage=2, priority=40,
                  depends_on=["HttpxTool"], condition="has_live_hosts"),
            _step("FeroxbusterTool",    "Content discovery",  stage=2, priority=50,
                  depends_on=["HttpxTool"], condition="has_live_hosts"),
            # Analysis
            _step("SecretFinderTool",   "JS secrets",         stage=3, priority=10,
                  depends_on=["GoSpiderTool"], condition="has_urls"),
            _step("NucleiTool",         "Vuln templates",     stage=3, priority=20,
                  depends_on=["ServiceDetectTool"], condition="has_live_hosts"),
            _step("GoWitnessTool",      "Screenshots",        stage=3, priority=30,
                  depends_on=["HttpxTool"], condition="has_live_hosts"),
        ],
    )


def _enterprise_assessment() -> WorkflowDefinition:
    """
    Structured enterprise security assessment workflow.
    """
    return WorkflowDefinition(
        name          = "enterprise_assessment",
        description   = "Structured enterprise security assessment: passive discovery, "
                        "active enumeration, internal services, cloud exposure, and reporting.",
        category      = "enterprise",
        target_types  = ["domain", "cidr", "asn"],
        tags          = ["enterprise", "assessment", "structured", "professional"],
        estimated_min = 75,
        requires_root = False,
        steps=[
            _step("WhoisTool",          "WHOIS",                 stage=1, priority=10, required=True),
            _step("ASNMapTool",         "ASN mapping",           stage=1, priority=15),
            _step("DNSReconTool",       "DNS enumeration",       stage=1, priority=20),
            _step("SubfinderTool",      "Subdomain discovery",   stage=1, priority=30, parallel_group="ea_subs"),
            _step("AmassActiveTool",    "Active subdomain enum", stage=1, priority=30, parallel_group="ea_subs"),
            _step("CrtshTool",          "CT logs",               stage=1, priority=30, parallel_group="ea_subs"),
            _step("ShodanTool",         "Shodan lookup",         stage=1, priority=40),
            _step("HttpxTool",          "HTTP probe",            stage=2, priority=10,
                  depends_on=["SubfinderTool"]),
            _step("WafDetectTool",      "WAF detection",         stage=2, priority=20,
                  depends_on=["HttpxTool"]),
            _step("NmapFullTool",       "Port scan",             stage=2, priority=20,
                  depends_on=["HttpxTool"]),
            _step("ServiceDetectTool",  "Service detection",     stage=2, priority=30,
                  depends_on=["NmapFullTool"]),
            _step("TLSScanTool",        "TLS audit",             stage=2, priority=40,
                  depends_on=["ServiceDetectTool"]),
            _step("S3ScannerTool",      "Cloud storage scan",    stage=2, priority=40),
            _step("GoSpiderTool",       "Web crawl",             stage=2, priority=50,
                  depends_on=["HttpxTool"], condition="has_live_hosts"),
            _step("NucleiTool",         "Vuln templates",        stage=3, priority=10,
                  depends_on=["ServiceDetectTool"], condition="has_live_hosts"),
            _step("GoWitnessTool",      "Screenshots",           stage=3, priority=20,
                  depends_on=["HttpxTool"]),
        ],
    )


# ─────────────────────────────────────────────────────────────────────────────
# Template Registry
# ─────────────────────────────────────────────────────────────────────────────

_REGISTRY: dict[str, WorkflowDefinition] = {}


def _register_all() -> None:
    for builder in [
        _passive_recon,
        _active_recon,
        _fast_scan,
        _deep_scan,
        _web_application,
        _api_recon,
        _cloud_recon,
        _internal_network,
        _bug_bounty,
        _full_attack_surface,
        _enterprise_assessment,
    ]:
        wf = builder()
        _REGISTRY[wf.name] = wf


_register_all()


class WorkflowTemplates:
    """
    Static registry of all built-in workflow templates.

    CLI usage:
        reconx workflow run passive_recon
        reconx workflow run web_application
        reconx workflow run deep_scan
    """

    @staticmethod
    def get(name: str) -> Optional[WorkflowDefinition]:
        """Return template by name or None if not found."""
        return _REGISTRY.get(name)

    @staticmethod
    def list_names() -> list[str]:
        """Return all template names."""
        return list(_REGISTRY.keys())

    @staticmethod
    def list_all() -> list[WorkflowDefinition]:
        """Return all template definitions."""
        return list(_REGISTRY.values())

    @staticmethod
    def by_category(category: str) -> list[WorkflowDefinition]:
        """Filter templates by category."""
        return [wf for wf in _REGISTRY.values() if wf.category == category]

    @staticmethod
    def for_target_type(target_type: str) -> list[WorkflowDefinition]:
        """Return templates compatible with a target type."""
        return [wf for wf in _REGISTRY.values()
                if not wf.target_types or target_type in wf.target_types]

    @staticmethod
    def summary_table() -> list[dict]:
        """Return a list of dicts suitable for table rendering."""
        return [
            {
                "name":          wf.name,
                "description":   wf.description[:70] + "…"
                                 if len(wf.description) > 70 else wf.description,
                "category":      wf.category,
                "steps":         wf.step_count,
                "est_min":       wf.estimated_min,
                "target_types":  ", ".join(wf.target_types),
                "requires_root": wf.requires_root,
            }
            for wf in _REGISTRY.values()
        ]

    @staticmethod
    def register(workflow: WorkflowDefinition) -> None:
        """Register a custom workflow template at runtime."""
        _REGISTRY[workflow.name] = workflow
