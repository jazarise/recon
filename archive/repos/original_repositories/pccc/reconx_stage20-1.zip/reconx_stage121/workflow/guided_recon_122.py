"""
ReconX — Guided Recon Workflow (Stage 12.2).

Full modern bug-bounty and attack-surface reconnaissance chain.
Adds 8 new steps to the Stage 12.1 workflow covering:
  - Asset discovery intelligence (github, ASN, CIDR, alterx)
  - Historical URL aggregation (gau, waymore, waybackurls)
  - Active crawling (katana, hakrawler, gospider)
  - Parameter discovery (paramspider, arjun)

The WorkflowRunner from guided_recon_121.py is reused directly —
this module provides the extended GUIDED_STEPS_122 list.
"""
from __future__ import annotations

try:
    from reconx.workflow.guided_recon_121 import (
        WorkflowStep, GUIDED_STEPS, STEP_MAP, WorkflowRunner, WorkflowState, StepStatus
    )
except ModuleNotFoundError:
    from workflow.guided_recon_121 import (
        WorkflowStep, GUIDED_STEPS, STEP_MAP, WorkflowRunner, WorkflowState, StepStatus
    )


# ─────────────────────────────────────────────────────────────────────────────
# New steps to insert into the Stage 12.1 workflow
# ─────────────────────────────────────────────────────────────────────────────

_NEW_STEPS: list[WorkflowStep] = [

    WorkflowStep(
        id          = "github_recon",
        name        = "GitHub Intelligence",
        description = "Mine public GitHub repositories for leaked subdomains, configs, and tokens.",
        tools       = ["GitHubSubdomainsTool"],
        category    = "Attack Surface",
        skippable   = True,
        requires    = [],
        produces    = ["subdomain", "leaked_secret"],
        notes       = "Set RECONX_GITHUB_TOKEN for higher rate limits.",
    ),

    WorkflowStep(
        id          = "asn_mapping",
        name        = "ASN & Infrastructure Mapping",
        description = "Resolve ASN ownership and retrieve all CIDR ranges for the target org.",
        tools       = ["AsnmapTool"],
        category    = "Attack Surface",
        skippable   = True,
        requires    = ["whois"],
        produces    = ["cidr_range", "asn"],
    ),

    WorkflowStep(
        id          = "cidr_expansion",
        name        = "CIDR Expansion",
        description = "Expand ASN CIDR ranges into scannable IP lists, filtering bogons.",
        tools       = ["MapCIDRTool"],
        category    = "Attack Surface",
        skippable   = True,
        requires    = ["asn_mapping"],
        produces    = ["ip"],
    ),

    WorkflowStep(
        id          = "permutation",
        name        = "Subdomain Permutation",
        description = "Generate intelligent subdomain permutations from discovered assets.",
        tools       = ["AlterxTool"],
        category    = "Attack Surface",
        skippable   = True,
        requires    = ["subdomains"],
        produces    = ["subdomain_permutation"],
        notes       = "Pipe results to DNS resolution step for confirmation.",
    ),

    WorkflowStep(
        id          = "historical_urls",
        name        = "Historical URL Discovery",
        description = "Collect archived URLs from Wayback, Common Crawl, URLScan, and OTX.",
        tools       = ["GauTool", "WaybackurlsTool", "WaymoreTool"],
        category    = "Historical Recon",
        skippable   = True,
        requires    = ["subdomains"],
        produces    = ["historical_url", "url", "endpoint"],
        notes       = "Feeds directly into parameter discovery and JS analysis.",
    ),

    WorkflowStep(
        id          = "active_crawl",
        name        = "Active Web Crawling",
        description = "Recursive crawl with JavaScript rendering to extract all live endpoints.",
        tools       = ["KatanaTool", "HakrawlerTool", "GospiderTool"],
        category    = "URL Discovery",
        skippable   = True,
        requires    = ["port_scan"],
        produces    = ["url", "endpoint", "js_file", "form"],
        notes       = "Run after port scan to know which ports serve HTTP.",
    ),

    WorkflowStep(
        id          = "param_discovery",
        name        = "Parameter Discovery",
        description = "Mine parameters from archives (passive) and fuzz endpoints (active).",
        tools       = ["ParamSpiderTool", "ArjunTool"],
        category    = "Parameter Discovery",
        skippable   = True,
        requires    = ["historical_urls", "active_crawl"],
        produces    = ["url_parameter"],
        notes       = "Passive first (paramspider), then active verification (arjun).",
    ),

    WorkflowStep(
        id          = "js_analysis",
        name        = "JavaScript Analysis",
        description = "Extract secrets, endpoints, and API routes from discovered JS files.",
        tools       = ["SecretfinderTool"],
        category    = "URL Discovery",
        skippable   = True,
        requires    = ["active_crawl"],
        produces    = ["secret", "api_key", "endpoint"],
        notes       = "Requires secretfinder: pip install secretfinder",
    ),

]

# ─────────────────────────────────────────────────────────────────────────────
# Merge into the full workflow with correct ordering
# ─────────────────────────────────────────────────────────────────────────────

# Insertion map: insert new step after the step with this ID
_INSERT_AFTER: dict[str, list[WorkflowStep]] = {
    "theharvester": [
        _find("github_recon"),
    ],
    "whois": [
        _find("asn_mapping"),
        _find("cidr_expansion"),
    ],
    "subdomains": [
        _find("permutation"),
    ],
    "port_scan": [
        _find("historical_urls"),
        _find("active_crawl"),
        _find("param_discovery"),
        _find("js_analysis"),
    ],
}


def _find(step_id: str) -> WorkflowStep:
    """Look up a new step by ID."""
    for s in _NEW_STEPS:
        if s.id == step_id:
            return s
    raise KeyError(f"Step not found: {step_id}")


def build_122_workflow() -> list[WorkflowStep]:
    """
    Build the full Stage 12.2 workflow by inserting new steps into
    the Stage 12.1 step list at the correct positions.

    Returns the complete ordered list ready for WorkflowRunner.
    """
    base   = list(GUIDED_STEPS)          # copy Stage 12.1 steps
    result: list[WorkflowStep] = []
    inserted: set[str] = set()

    for step in base:
        result.append(step)
        # Insert any new steps that should follow this one
        for new_step in _new_steps_after(step.id):
            if new_step.id not in inserted:
                result.append(new_step)
                inserted.add(new_step.id)

    # Append any new steps that weren't inserted (fallback)
    for new_step in _NEW_STEPS:
        if new_step.id not in inserted:
            # Insert before 'risk_analysis'
            idx = next(
                (i for i, s in enumerate(result) if s.id == "risk_analysis"),
                len(result) - 1,
            )
            result.insert(idx, new_step)

    return result


def _new_steps_after(step_id: str) -> list[WorkflowStep]:
    """Return new steps that should be inserted after `step_id`."""
    if step_id == "theharvester":
        return [s for s in _NEW_STEPS if s.id == "github_recon"]
    if step_id == "whois":
        return [s for s in _NEW_STEPS if s.id in ("asn_mapping", "cidr_expansion")]
    if step_id == "subdomains":
        return [s for s in _NEW_STEPS if s.id == "permutation"]
    if step_id == "port_scan":
        return [s for s in _NEW_STEPS if s.id in (
            "historical_urls", "active_crawl", "param_discovery", "js_analysis"
        )]
    return []


# ─────────────────────────────────────────────────────────────────────────────
# Export
# ─────────────────────────────────────────────────────────────────────────────

GUIDED_STEPS_122 = build_122_workflow()
STEP_MAP_122     = {s.id: s for s in GUIDED_STEPS_122}

__all__ = [
    "GUIDED_STEPS_122",
    "STEP_MAP_122",
    "WorkflowRunner",       # re-export for consumer convenience
    "WorkflowState",
    "StepStatus",
    "build_122_workflow",
]
