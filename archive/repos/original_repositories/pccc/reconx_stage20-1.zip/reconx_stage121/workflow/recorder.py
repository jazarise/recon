"""
ReconX — Stage 16: Workflow Recorder.

Records complete workflow execution sessions to disk as JSON.
Each session file captures tools run, order, parameters, durations,
outputs, errors, and a full event timeline.

Session files are stored in: sessions/session_<id>.json

Usage:
    from reconx.workflow.recorder import WorkflowRecorder
    from reconx.workflow.engine import WorkflowEngine
    from reconx.workflow.templates import WorkflowTemplates

    engine   = WorkflowEngine()
    recorder = WorkflowRecorder()
    wf       = WorkflowTemplates.get("passive_recon")
    session  = engine.execute(wf, "example.com")
    path     = recorder.save(session)
    print(f"Session saved: {path}")
"""
from __future__ import annotations

import json
import logging
import os
import time
from pathlib import Path
from typing import Optional

from .schemas import WorkflowSession

log = logging.getLogger("reconx.workflow.recorder")

_DEFAULT_DIR = "sessions"


class WorkflowRecorder:
    """
    Persists WorkflowSessions to disk and provides session management.

    Session naming convention:
        sessions/session_<session_id>.json
    """

    def __init__(self, sessions_dir: str = _DEFAULT_DIR):
        self.sessions_dir = Path(sessions_dir)
        self.sessions_dir.mkdir(parents=True, exist_ok=True)

    # ── Save ──────────────────────────────────────────────────────────────────

    def save(self, session: WorkflowSession) -> str:
        """
        Serialise a WorkflowSession to disk.

        Returns the absolute path of the saved file.
        Raises OSError only if the target directory cannot be written.
        """
        path = self._session_path(session.session_id)
        try:
            data = session.to_dict()
            data["_reconx_version"] = "16.0"
            data["_saved_at"]       = time.time()
            with open(path, "w", encoding="utf-8") as fh:
                json.dump(data, fh, indent=2, default=str)
            log.info(f"Session saved: {path}")
        except Exception as exc:
            log.error(f"Failed to save session {session.session_id}: {exc}")
            raise
        return str(path)

    # ── Load ──────────────────────────────────────────────────────────────────

    def load(self, session_id: str) -> Optional[WorkflowSession]:
        """
        Load a session from disk by session_id.

        Returns None if the file does not exist or is corrupted.
        """
        path = self._session_path(session_id)
        if not path.exists():
            # Try raw path in case user passed a full path
            alt = Path(session_id)
            if alt.exists():
                path = alt
            else:
                log.warning(f"Session not found: {session_id}")
                return None

        try:
            with open(path, encoding="utf-8") as fh:
                data = json.load(fh)
            session = WorkflowSession.from_dict(data)
            log.info(f"Session loaded: {path}")
            return session
        except Exception as exc:
            log.error(f"Failed to load session {session_id}: {exc}")
            return None

    def load_path(self, path: str) -> Optional[WorkflowSession]:
        """Load a session from an explicit file path."""
        try:
            with open(path, encoding="utf-8") as fh:
                data = json.load(fh)
            return WorkflowSession.from_dict(data)
        except Exception as exc:
            log.error(f"Failed to load session from {path}: {exc}")
            return None

    # ── List ──────────────────────────────────────────────────────────────────

    def list_sessions(self) -> list[dict]:
        """
        Return metadata for all saved sessions, newest first.

        Each entry: session_id, workflow_name, target, status, duration_s,
                    total_findings, saved_at, path.
        """
        sessions = []
        for p in sorted(self.sessions_dir.glob("session_*.json"),
                        key=lambda x: x.stat().st_mtime, reverse=True):
            try:
                with open(p, encoding="utf-8") as fh:
                    d = json.load(fh)
                sessions.append({
                    "session_id":    d.get("session_id", p.stem),
                    "workflow_name": d.get("workflow_name", "unknown"),
                    "target":        d.get("target", "?"),
                    "status":        d.get("status", "?"),
                    "duration_s":    d.get("finished_at", 0) - d.get("started_at", 0),
                    "total_findings": d.get("total_findings", 0),
                    "step_count":    len(d.get("steps", [])),
                    "saved_at":      d.get("_saved_at", 0),
                    "path":          str(p),
                })
            except Exception:
                pass
        return sessions

    def delete(self, session_id: str) -> bool:
        """Delete a session file. Returns True if deleted."""
        path = self._session_path(session_id)
        if path.exists():
            path.unlink()
            log.info(f"Deleted session: {session_id}")
            return True
        return False

    # ── Auto-save hook ────────────────────────────────────────────────────────

    def make_step_callback(
        self,
        session: WorkflowSession,
        autosave: bool = True,
    ):
        """
        Return an on_step_done callback suitable for WorkflowEngine.

        When autosave=True, session is persisted after every completed step,
        ensuring partial progress is never lost.
        """
        recorder = self

        def _on_step_done(step, _session):
            if autosave:
                try:
                    recorder.save(_session)
                except Exception as exc:
                    log.warning(f"Auto-save failed: {exc}")

        return _on_step_done

    # ── Internal ──────────────────────────────────────────────────────────────

    def _session_path(self, session_id: str) -> Path:
        safe_id = session_id.replace("/", "_").replace("\\", "_")
        return self.sessions_dir / f"{safe_id}.json"
