from __future__ import annotations
import logging
import shutil
from dataclasses import dataclass, field
from typing import Optional

try:
    from ..sdk.contracts import ToolMetadata, CapabilitySet, RiskLevel, InstallMethod
except ImportError:
    from sdk.contracts import ToolMetadata, CapabilitySet, RiskLevel, InstallMethod

try:
    from .capability_map import CapabilityEngine
except ImportError:
    from core.capability_map import CapabilityEngine

logger = logging.getLogger("reconx.core.registry")


# ── Plugin registry record ────────────────────────────────────────────────────

@dataclass
class PluginRecord:
    """
    One entry in the Stage 19 plugin registry.

    Holds both the new ToolMetadata and enough legacy info to keep
    the existing execution engine running unchanged.
    """
    metadata:    ToolMetadata
    plugin_cls:  Optional[type]  = None    # PluginBaseTool subclass (if loaded)
    instance:    Optional[object] = None   # live instance
    is_legacy:   bool            = False   # came from ToolDescriptor, not PluginBaseTool
    enabled:     bool            = True
    load_error:  str             = ""

    @property
    def name(self) -> str:
        return self.metadata.name

    @property
    def available(self) -> bool:
        binary = self.metadata.binary
        if not binary:
            return True
        return bool(shutil.which(binary))

    @property
    def installed(self) -> bool:
        return self.available and not self.load_error

    def status_icon(self) -> str:
        if self.load_error:    return "✗"
        if not self.available: return "⚠"
        return "✓"

    def to_row(self) -> dict:
        m = self.metadata
        return {
            "status":       self.status_icon(),
            "name":         m.name,
            "category":     m.category,
            "stage":        str(m.stage),
            "passive":      "✓" if m.passive else "—",
            "risk":         m.risk_level.value,
            "capabilities": ", ".join(m.capabilities.slugs()[:4]),
            "installed":    "✓" if self.available else "✗",
            "legacy":       "✓" if self.is_legacy else "—",
        }


# ── Plugin Registry ───────────────────────────────────────────────────────────

class PluginRegistry:
    """
    Stage 19 central plugin registry.

    Wraps and extends the existing ToolRegistry with:
    - ToolMetadata storage per tool
    - CapabilityEngine for capability-based lookup
    - info() / search() / list() for CLI display
    - Auto-wrapping of legacy ToolDescriptors

    Singleton: one instance, built by build_plugin_registry().
    """

    def __init__(self) -> None:
        self._records:   dict[str, PluginRecord] = {}
        self._caps:      CapabilityEngine         = CapabilityEngine()

    # ══════════════════════════════════════════════════════════════════════════
    # Registration
    # ══════════════════════════════════════════════════════════════════════════

    def register_plugin(
        self,
        plugin_cls:   type,
        instance:     Optional[object] = None,
    ) -> None:
        """
        Register a PluginBaseTool class.
        Auto-creates the PluginRecord from the class METADATA.
        """
        meta = getattr(plugin_cls, "METADATA", None)
        if not meta or not isinstance(meta, ToolMetadata):
            logger.warning("[PluginRegistry] %s has no METADATA — skipping", plugin_cls.__name__)
            return

        record = PluginRecord(
            metadata=meta,
            plugin_cls=plugin_cls,
            instance=instance,
            is_legacy=False,
        )
        self._records[meta.name] = record
        self._caps.register_from_metadata(meta.name, meta.capabilities)
        logger.debug("[PluginRegistry] Registered plugin: %s", meta.name)

    def register_instance(self, tool_instance) -> None:
        """Register a live PluginBaseTool instance."""
        meta = getattr(tool_instance, "METADATA", None)
        if not meta:
            return
        record = PluginRecord(
            metadata=meta,
            plugin_cls=type(tool_instance),
            instance=tool_instance,
            is_legacy=False,
        )
        self._records[meta.name] = record
        self._caps.register_from_metadata(meta.name, meta.capabilities)

    def register_legacy(self, descriptor) -> None:
        """
        Wrap a legacy ToolDescriptor (engine/registry.py) as a PluginRecord.
        Called during bootstrap to backfill legacy tools into Stage 19 registry.
        """

        meta = ToolMetadata(
            name=descriptor.name,
            description=getattr(descriptor, "description", ""),
            category=descriptor.category,
            stage=descriptor.stage,
            priority=descriptor.priority,
            passive=descriptor.passive,
            binary=getattr(descriptor, "binary", ""),
            risk_level=RiskLevel.LOW if descriptor.passive else RiskLevel.MEDIUM,
        )
        record = PluginRecord(metadata=meta, is_legacy=True)
        self._records[descriptor.name] = record
        logger.debug("[PluginRegistry] Wrapped legacy: %s", descriptor.name)

    # ══════════════════════════════════════════════════════════════════════════
    # Query interface
    # ══════════════════════════════════════════════════════════════════════════

    def get(self, name: str) -> Optional[PluginRecord]:
        """Return a PluginRecord by tool name, or None."""
        return self._records.get(name)

    def info(self, name: str) -> Optional[ToolMetadata]:
        """Return full ToolMetadata for a tool by name."""
        r = self._records.get(name)
        return r.metadata if r else None

    def list(self, category: Optional[str] = None) -> list[PluginRecord]:
        """List all records, optionally filtered by category."""
        records = list(self._records.values())
        if category:
            records = [r for r in records if r.metadata.category == category]
        return sorted(records, key=lambda r: (r.metadata.stage, r.metadata.priority))

    def search(self, capability: str) -> list[PluginRecord]:
        """Return all plugins that have a given capability slug."""
        names = self._caps.tools_for(capability)
        return [self._records[n] for n in names if n in self._records]

    def category(self, cat: str) -> list[PluginRecord]:
        """Return all plugins in a category."""
        return self.list(category=cat)

    def all_categories(self) -> list[str]:
        return sorted(set(r.metadata.category for r in self._records.values()))

    def all_capabilities(self) -> list[str]:
        return self._caps.all_capabilities()

    def capability_map(self) -> dict[str, list[str]]:
        return self._caps.capability_map()

    def capability_engine(self) -> CapabilityEngine:
        return self._caps

    # ══════════════════════════════════════════════════════════════════════════
    # Stats
    # ══════════════════════════════════════════════════════════════════════════

    def stats(self) -> dict:
        records = list(self._records.values())
        return {
            "total":       len(records),
            "available":   sum(1 for r in records if r.available),
            "legacy":      sum(1 for r in records if r.is_legacy),
            "plugins":     sum(1 for r in records if not r.is_legacy),
            "categories":  len(self.all_categories()),
            "capabilities": len(self.all_capabilities()),
            "errors":      sum(1 for r in records if r.load_error),
        }


# ── Singleton ─────────────────────────────────────────────────────────────────

_registry: Optional[PluginRegistry] = None


def get_plugin_registry() -> PluginRegistry:
    """Return the global PluginRegistry singleton (lazy init)."""
    global _registry
    if _registry is None:
        _registry = PluginRegistry()
    return _registry
