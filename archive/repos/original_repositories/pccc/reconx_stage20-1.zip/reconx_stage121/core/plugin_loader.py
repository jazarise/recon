from __future__ import annotations
import importlib.util
import inspect
import logging
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

try:
    from .registry import PluginRegistry, get_plugin_registry
except ImportError:
    from core.registry import PluginRegistry, get_plugin_registry

logger = logging.getLogger("reconx.core.plugin_loader")

# Directories to scan for plugins (relative to the reconx package root)
_PLUGIN_DIRS: list[str] = [
    "plugins",
]

# Filename inside each plugin subfolder to look for
_PLUGIN_FILENAMES = ("plugin.py", "__init__.py")


# ── Load result ────────────────────────────────────────────────────────────────

@dataclass
class PluginLoadResult:
    """Summary of a plugin discovery + load run."""
    discovered:  list[str] = field(default_factory=list)
    loaded:      list[str] = field(default_factory=list)
    failed:      list[str] = field(default_factory=list)
    skipped:     list[str] = field(default_factory=list)
    errors:      dict[str, str] = field(default_factory=dict)

    @property
    def ok(self) -> bool:
        return len(self.failed) == 0

    def summary(self) -> str:
        return (f"Discovered: {len(self.discovered)}  "
                f"Loaded: {len(self.loaded)}  "
                f"Failed: {len(self.failed)}  "
                f"Skipped: {len(self.skipped)}")


# ── Errors ────────────────────────────────────────────────────────────────────

class PluginLoadError(Exception):
    """Raised when a plugin cannot be loaded (caught by loader, not propagated)."""
    def __init__(self, plugin_path: str, reason: str):
        self.plugin_path = plugin_path
        self.reason      = reason
        super().__init__(f"Plugin load failed [{plugin_path}]: {reason}")


class DependencyError(Exception):
    """Raised when a plugin's pip dependencies are not installed."""
    def __init__(self, plugin_name: str, missing: list[str]):
        self.plugin_name = plugin_name
        self.missing     = missing
        super().__init__(
            f"Plugin '{plugin_name}' missing dependencies: {', '.join(missing)}"
        )


class ToolValidationError(Exception):
    """Raised when ToolMetadata validation fails."""
    def __init__(self, plugin_name: str, errors: list[str]):
        self.plugin_name = plugin_name
        self.errors      = errors
        super().__init__(
            f"Plugin '{plugin_name}' metadata invalid: {'; '.join(errors)}"
        )


class RegistryError(Exception):
    """Raised on a fatal registry operation failure."""


# ── Plugin loader ─────────────────────────────────────────────────────────────

class PluginLoader:
    """
    Scans plugin directories and loads PluginBaseTool subclasses.

    Usage:
        loader = PluginLoader()
        result = loader.load_all()
        print(result.summary())
    """

    def __init__(
        self,
        registry:     Optional[PluginRegistry] = None,
        plugin_dirs:  Optional[list[Path]]     = None,
        package_root: Optional[Path]           = None,
    ):
        self._registry    = registry or get_plugin_registry()
        self._package_root = package_root or self._find_package_root()
        self._plugin_dirs  = plugin_dirs or self._default_dirs()

    # ══════════════════════════════════════════════════════════════════════════
    # Public API
    # ══════════════════════════════════════════════════════════════════════════

    def load_all(self) -> PluginLoadResult:
        """
        Scan all configured plugin directories and load discovered plugins.
        Returns a PluginLoadResult with full details.
        """
        result = PluginLoadResult()

        for plugin_dir in self._plugin_dirs:
            if not plugin_dir.exists():
                logger.debug("[PluginLoader] Dir not found: %s", plugin_dir)
                continue
            self._scan_directory(plugin_dir, result)

        logger.info("[PluginLoader] %s", result.summary())
        return result

    def load_directory(self, path: Path) -> PluginLoadResult:
        """Load plugins from a single directory."""
        result = PluginLoadResult()
        if path.exists():
            self._scan_directory(path, result)
        return result

    def load_file(self, path: Path) -> PluginLoadResult:
        """Load a single plugin file directly."""
        result = PluginLoadResult()
        self._load_plugin_file(path, result)
        return result

    # ══════════════════════════════════════════════════════════════════════════
    # Scanning
    # ══════════════════════════════════════════════════════════════════════════

    def _scan_directory(self, plugin_dir: Path, result: PluginLoadResult) -> None:
        """Scan a directory for plugin subdirectories and files."""
        # Direct plugin.py files in the directory
        for fname in _PLUGIN_FILENAMES:
            direct = plugin_dir / fname
            if direct.exists() and fname == "plugin.py":
                result.discovered.append(str(direct))
                self._load_plugin_file(direct, result)

        # Plugin subdirectories
        for subdir in sorted(plugin_dir.iterdir()):
            if not subdir.is_dir() or subdir.name.startswith(("_", ".")):
                continue
            for fname in _PLUGIN_FILENAMES:
                plugin_file = subdir / fname
                if plugin_file.exists():
                    result.discovered.append(str(plugin_file))
                    self._load_plugin_file(plugin_file, result)
                    break   # only load the first matching file per subdir

    def _load_plugin_file(self, path: Path, result: PluginLoadResult) -> None:
        """Import a single plugin file and register all PluginBaseTool subclasses."""
        module_name = f"reconx_plugin_{path.stem}_{abs(hash(str(path)))}"

        try:
            # Import the module dynamically
            spec   = importlib.util.spec_from_file_location(module_name, path)
            if spec is None or spec.loader is None:
                result.skipped.append(str(path))
                return

            module = importlib.util.module_from_spec(spec)
            sys.modules[module_name] = module
            spec.loader.exec_module(module)

        except Exception as exc:
            err_msg = f"{type(exc).__name__}: {exc}"
            result.failed.append(str(path))
            result.errors[str(path)] = err_msg
            logger.warning("[PluginLoader] Import failed %s: %s", path.name, err_msg)
            return

        # Find all PluginBaseTool subclasses in the module
        found_any = False
        for obj_name, obj in inspect.getmembers(module, inspect.isclass):
            if not self._is_plugin_class(obj, module):
                continue

            found_any = True
            plugin_name = getattr(obj, "METADATA", None) and obj.METADATA.name or obj_name

            try:
                self._register_plugin_class(obj, result)
            except (PluginLoadError, ToolValidationError, DependencyError) as exc:
                result.failed.append(plugin_name)
                result.errors[plugin_name] = str(exc)
                logger.warning("[PluginLoader] Register failed %s: %s", plugin_name, exc)
            except Exception as exc:
                result.failed.append(plugin_name)
                result.errors[plugin_name] = str(exc)
                logger.warning("[PluginLoader] Unexpected error %s: %s", plugin_name, exc)

        if not found_any:
            result.skipped.append(str(path))

    def _is_plugin_class(self, cls: type, module) -> bool:
        """Return True if cls is a PluginBaseTool subclass defined in this module."""
        try:
            from ..sdk.base_tool import PluginBaseTool
        except ImportError:
            from sdk.base_tool import PluginBaseTool
            return False

        return (
            inspect.isclass(cls)
            and cls is not PluginBaseTool
            and issubclass(cls, PluginBaseTool)
            and cls.__module__ == module.__name__
            and hasattr(cls, "METADATA")
        )

    def _register_plugin_class(self, cls: type, result: PluginLoadResult) -> None:
        """Validate, instantiate, and register a plugin class."""
        try:
            from ..sdk.contracts import ToolMetadata
        except ImportError:
            from sdk.contracts import ToolMetadata

        meta = getattr(cls, "METADATA", None)
        if not isinstance(meta, ToolMetadata):
            raise PluginLoadError(cls.__name__, "METADATA must be a ToolMetadata instance")

        # Validate metadata
        errors = meta.validate()
        if errors:
            raise ToolValidationError(meta.name, errors)

        # Check pip dependencies
        missing = self._check_dependencies(meta.dependencies)
        if missing:
            raise DependencyError(meta.name, missing)

        # Instantiate
        try:
            instance = cls()
        except Exception as exc:
            raise PluginLoadError(meta.name, f"Instantiation failed: {exc}") from exc

        # Register
        self._registry.register_instance(instance)
        result.loaded.append(meta.name)
        logger.info("[PluginLoader] ✓ Loaded: %s (%s)", meta.name, meta.category)

    @staticmethod
    def _check_dependencies(deps: list[str]) -> list[str]:
        """Return list of missing pip packages. Empty = all present."""
        missing = []
        for dep in deps:
            try:
                importlib.import_module(dep.replace("-", "_"))
            except ImportError:
                missing.append(dep)
        return missing

    # ══════════════════════════════════════════════════════════════════════════
    # Helpers
    # ══════════════════════════════════════════════════════════════════════════

    def _find_package_root(self) -> Path:
        """Find the reconx package root directory."""
        return Path(__file__).resolve().parents[1]

    def _default_dirs(self) -> list[Path]:
        root = self._package_root
        return [root / d for d in _PLUGIN_DIRS]
