from __future__ import annotations
import logging
from collections import defaultdict
from typing import TYPE_CHECKING

try:
    from ..sdk.contracts import CapabilitySet, Capability
except ImportError:
    from sdk.contracts import CapabilitySet, Capability

if TYPE_CHECKING:
    from ..sdk.base_tool import PluginBaseTool

logger = logging.getLogger("reconx.core.capability_map")


class CapabilityEngine:
    """
    Central capability registry.

    Stores the mapping of capability_slug → list[tool_name].
    Also stores the reverse: tool_name → list[capability_slug].

    Designed to be extended in Stage 20+ for AI-driven tool selection.
    """

    def __init__(self) -> None:
        # cap_slug → [tool_name, ...]
        self._cap_to_tools: dict[str, list[str]] = defaultdict(list)
        # tool_name → [cap_slug, ...]
        self._tool_to_caps: dict[str, list[str]] = {}
        # tool_name → PluginBaseTool instance
        self._tools: dict[str, object] = {}

    # ══════════════════════════════════════════════════════════════════════════
    # Registration
    # ══════════════════════════════════════════════════════════════════════════

    def register(self, tool: "PluginBaseTool") -> None:
        """Register a PluginBaseTool and index all its capabilities."""
        name = tool.METADATA.name
        caps = tool.capabilities()

        self._tools[name] = tool
        self._tool_to_caps[name] = caps.slugs()

        for cap in caps:
            slug = str(cap)
            if name not in self._cap_to_tools[slug]:
                self._cap_to_tools[slug].append(name)

        logger.debug("[CapabilityEngine] Registered: %s → %s", name, caps.slugs())

    def register_many(self, tools: list) -> None:
        for tool in tools:
            try:
                self.register(tool)
            except Exception as exc:
                logger.debug("[CapabilityEngine] Skip %s: %s", type(tool).__name__, exc)

    def register_from_metadata(self, name: str, caps: CapabilitySet) -> None:
        """
        Register from metadata directly (no live tool instance needed).
        Used by PluginLoader when discovering plugins from disk.
        """
        self._tool_to_caps[name] = caps.slugs()
        for cap in caps:
            slug = str(cap)
            if name not in self._cap_to_tools[slug]:
                self._cap_to_tools[slug].append(name)

    # ══════════════════════════════════════════════════════════════════════════
    # Lookup
    # ══════════════════════════════════════════════════════════════════════════

    def tools_for(self, capability: str) -> list[str]:
        """Return tool names that have a given capability slug."""
        return list(self._cap_to_tools.get(capability, []))

    def tools_for_all(self, capabilities: list[str]) -> list[str]:
        """Return tool names that have ALL listed capability slugs."""
        if not capabilities:
            return []
        sets = [set(self._cap_to_tools.get(c, [])) for c in capabilities]
        result = sets[0]
        for s in sets[1:]:
            result = result & s
        return sorted(result)

    def tools_for_any(self, capabilities: list[str]) -> list[str]:
        """Return tool names that have ANY of the listed capability slugs."""
        result: set[str] = set()
        for cap in capabilities:
            result |= set(self._cap_to_tools.get(cap, []))
        return sorted(result)

    def caps_for_tool(self, tool_name: str) -> list[str]:
        """Return capability slugs for a given tool name."""
        return list(self._tool_to_caps.get(tool_name, []))

    def get_tool(self, name: str) -> object:
        """Return the registered tool instance, or None."""
        return self._tools.get(name)

    # ══════════════════════════════════════════════════════════════════════════
    # Inventory
    # ══════════════════════════════════════════════════════════════════════════

    def all_capabilities(self) -> list[str]:
        """Return sorted list of all registered capability slugs."""
        return sorted(self._cap_to_tools.keys())

    def all_tools(self) -> list[str]:
        """Return sorted list of all registered tool names."""
        return sorted(self._tool_to_caps.keys())

    def capability_map(self) -> dict[str, list[str]]:
        """
        Return full mapping of capability → [tool_names].
        Used by `reconx tools capabilities` CLI command and TUI display.
        """
        return {cap: list(tools) for cap, tools in sorted(self._cap_to_tools.items())}

    def tool_capability_matrix(self) -> list[dict]:
        """
        Return list of {tool, capabilities, category} dicts for table display.
        """
        rows = []
        for name, caps in sorted(self._tool_to_caps.items()):
            tool = self._tools.get(name)
            category = ""
            if tool and hasattr(tool, "METADATA"):
                category = tool.METADATA.category
            rows.append({
                "tool":         name,
                "capabilities": caps,
                "category":     category,
                "cap_count":    len(caps),
            })
        return rows

    def summary(self) -> dict:
        """Return stats dict for healthcheck/status display."""
        return {
            "total_tools":        len(self._tool_to_caps),
            "total_capabilities": len(self._cap_to_tools),
            "tools":              self.all_tools(),
            "capabilities":       self.all_capabilities(),
        }
