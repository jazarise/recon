from __future__ import annotations
import logging
import time
from typing import Optional

try:
    from .registry      import PluginRegistry, PluginRecord, get_plugin_registry
except ImportError:
    from core.registry  import PluginRegistry, PluginRecord, get_plugin_registry

try:
    from .plugin_loader import PluginLoader, PluginLoadResult
except ImportError:
    from core.plugin_loader import PluginLoader, PluginLoadResult

try:
    from .capability_map import CapabilityEngine
except ImportError:
    from core.capability_map import CapabilityEngine

logger = logging.getLogger("reconx.core.plugin_manager")


class PluginManager:
    """
    Stage 19 Plugin Manager — the public orchestration layer.

    Usage:
        pm = PluginManager()
        pm.bootstrap()              # load all plugins at startup

        pm.list()                   # all plugins
        pm.info("nmap")             # full metadata
        pm.search("port_scan")      # capability search
        pm.category("network")      # category filter
        pm.capabilities()           # full capability map
        pm.healthcheck()            # all tools health
    """

    def __init__(
        self,
        registry: Optional[PluginRegistry] = None,
        loader:   Optional[PluginLoader]   = None,
    ):
        self._registry = registry or get_plugin_registry()
        self._loader   = loader   or PluginLoader(registry=self._registry)
        self._bootstrapped  = False
        self._load_result:  Optional[PluginLoadResult] = None
        self._boot_duration: float = 0.0

    # ══════════════════════════════════════════════════════════════════════════
    # Lifecycle
    # ══════════════════════════════════════════════════════════════════════════

    def bootstrap(self, backfill_legacy: bool = True) -> PluginLoadResult:
        """
        Full startup sequence:
          1. Load all plugins from plugins/ directories
          2. Optionally backfill legacy ToolDescriptors
          3. Mark bootstrapped

        Safe to call multiple times — idempotent.
        """
        if self._bootstrapped:
            return self._load_result or PluginLoadResult()

        t0 = time.perf_counter()

        # Step 1: auto-discover and load Stage 19 plugins
        result = self._loader.load_all()

        # Step 2: backfill legacy tools into the new registry
        if backfill_legacy:
            self._backfill_legacy(result)

        self._bootstrapped  = True
        self._load_result   = result
        self._boot_duration = time.perf_counter() - t0

        logger.info(
            "[PluginManager] Bootstrap complete in %.1fs — %s",
            self._boot_duration,
            result.summary(),
        )
        return result

    def reload(self) -> PluginLoadResult:
        """Force a full reload of all plugins."""
        self._bootstrapped = False
        return self.bootstrap()

    # ══════════════════════════════════════════════════════════════════════════
    # Query (delegates to registry)
    # ══════════════════════════════════════════════════════════════════════════

    def list(self, category: Optional[str] = None) -> list[PluginRecord]:
        """List all registered plugins, optionally filtered by category."""
        return self._registry.list(category=category)

    def info(self, name: str) -> Optional[dict]:
        """Return full metadata dict for a plugin by name."""
        meta = self._registry.info(name)
        return meta.to_dict() if meta else None

    def search(self, capability: str) -> list[PluginRecord]:
        """Find all plugins with a given capability slug."""
        return self._registry.search(capability)

    def category(self, cat: str) -> list[PluginRecord]:
        """Return all plugins in a category."""
        return self._registry.category(cat)

    def get(self, name: str) -> Optional[PluginRecord]:
        """Return a PluginRecord by name."""
        return self._registry.get(name)

    def capabilities(self) -> dict[str, list[str]]:
        """Return full capability → [tool_names] map."""
        return self._registry.capability_map()

    def all_categories(self) -> list[str]:
        return self._registry.all_categories()

    def stats(self) -> dict:
        stats = self._registry.stats()
        stats["bootstrapped"]   = self._bootstrapped
        stats["boot_duration_s"] = round(self._boot_duration, 3)
        return stats

    # ══════════════════════════════════════════════════════════════════════════
    # Healthcheck
    # ══════════════════════════════════════════════════════════════════════════

    def healthcheck(self, name: Optional[str] = None) -> list[dict]:
        """
        Run healthcheck on one or all plugins.
        Returns list of {name, available, version, error} dicts.
        """
        records = [self._registry.get(name)] if name else self._registry.list()
        results = []

        for record in records:
            if record is None:
                continue
            instance = getattr(record, "instance", None)
            if instance and hasattr(instance, "healthcheck"):
                try:
                    h = instance.healthcheck()
                    results.append({
                        "name":      h.name,
                        "available": h.available,
                        "version":   h.version,
                        "error":     h.error,
                        "latency_ms": h.latency_ms,
                    })
                    continue
                except Exception:
                    pass
            # Fallback for legacy tools
            results.append({
                "name":      record.metadata.name,
                "available": record.available,
                "version":   "",
                "error":     record.load_error,
                "latency_ms": 0,
            })

        return results

    # ══════════════════════════════════════════════════════════════════════════
    # Internal helpers
    # ══════════════════════════════════════════════════════════════════════════

    def _backfill_legacy(self, result: PluginLoadResult) -> None:
        """
        Import legacy ToolDescriptors from engine/registry.py and wrap them
        into the Stage 19 PluginRegistry as is_legacy=True entries.
        Never raises — failure is logged and skipped.
        """
        try:
            from ..engine.registry import build_registry

            reg  = build_registry()
            n    = 0
            for descriptor in reg.all():
                # Don't overwrite a freshly loaded Stage 19 plugin
                if self._registry.get(descriptor.name) is None:
                    self._registry.register_legacy(descriptor)
                    n += 1
            logger.debug("[PluginManager] Backfilled %d legacy tools", n)
        except Exception as exc:
            logger.debug("[PluginManager] Legacy backfill skipped: %s", exc)


# ── Module-level convenience singleton ───────────────────────────────────────

_manager: Optional[PluginManager] = None


def get_plugin_manager() -> PluginManager:
    """Return the global PluginManager singleton."""
    global _manager
    if _manager is None:
        _manager = PluginManager()
    return _manager
