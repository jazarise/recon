"""
ReconX — Stage 19: Core Plugin System

Public API for the Stage 19 plugin ecosystem.

    from reconx.core import PluginManager, PluginRegistry, PluginLoader
    from reconx.core import get_plugin_manager, get_plugin_registry
    from reconx.core import CapabilityEngine
    from reconx.core.plugin_loader import PluginLoadError, DependencyError, ToolValidationError, RegistryError
"""
from .plugin_manager  import PluginManager, get_plugin_manager
from .registry        import PluginRegistry, PluginRecord, get_plugin_registry
from .plugin_loader   import (
    PluginLoader, PluginLoadResult,
    PluginLoadError, DependencyError, ToolValidationError, RegistryError,
)
from .capability_map  import CapabilityEngine

__all__ = [
    "PluginManager",    "get_plugin_manager",
    "PluginRegistry",   "PluginRecord",       "get_plugin_registry",
    "PluginLoader",     "PluginLoadResult",
    "PluginLoadError",  "DependencyError",
    "ToolValidationError", "RegistryError",
    "CapabilityEngine",
]
