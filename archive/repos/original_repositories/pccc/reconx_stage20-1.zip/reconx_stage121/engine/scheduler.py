"""
ReconX — Batch Scheduler  (Stage 2 core module).

Execution model:
  ┌─ Stage N ────────────────────────────────────────────────┐
  │  Batch 0: [tool_a, tool_b, tool_c]  ← parallel          │
  │  Batch 1: [tool_d, tool_e]          ← parallel           │
  │  …                                                        │
  └──────────────────────────────────────────────────────────┘
  Batches within a stage run sequentially.
  Tools within a batch run in parallel (ThreadPoolExecutor).
  Stages run sequentially (later stages depend on earlier output).

Key features:
  - Auto-skips unavailable binaries
  - Respects inter-tool dependencies
  - Hard per-tool timeout with retry
  - Deduplication (won't re-run completed tools)
  - Full Rich terminal UI: spinners, live status, batch summary
  - engine.run_tools([names], target) API for learn/guided mode
"""
from __future__ import annotations
import logging
import math
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from typing import Optional

from rich import box
from rich.columns import Columns
from rich.console import Console
from rich.live import Live
from rich.panel import Panel
from rich.progress import (
    BarColumn, Progress, SpinnerColumn,
    TaskProgressColumn, TextColumn, TimeElapsedColumn,
)
from rich.rule import Rule
from rich.table import Table
from rich.text import Text

from ..config.settings import SCHEDULER_DEFAULTS, SCHEDULER_MODE_OVERRIDES
from ..engine.registry import ToolDescriptor, ToolRegistry, build_default_registry
from ..engine.executor_helpers import (
    collect_discovered_ports, ingest_output, run_with_timeout,
)
from ..models.execution import (
    BatchResult, ExecutionSummary, FailureReason,
    ToolExecutionResult, ToolStatus,
)
from ..models.findings import ReconResult

logger = logging.getLogger("reconx.engine.scheduler")

# ── Palette ───────────────────────────────────────────────────────────────────
_R  = "red"
_RB = "bold red"
_RD = "dim red"
_G  = "bold green"
_Y  = "yellow"
_D  = "dim"
_W  = "white"


class BatchScheduler:
    """
    Orchestrates all tool execution for a ReconX scan run.

    Usage:
        scheduler = BatchScheduler(mode="balanced")
        summary   = scheduler.run(target, result)
    """

    def __init__(
        self,
        mode:      str              = "balanced",
        console:   Optional[Console]= None,
        silent:    bool             = False,
        registry:  Optional[ToolRegistry] = None,
        # Override config defaults if needed
        batch_size:   Optional[int] = None,
        thread_count: Optional[int] = None,
        timeout:      Optional[int] = None,
        retry_limit:  Optional[int] = None,
    ):
        # ── Merge config ──────────────────────────────────────────────────────
        cfg = {**SCHEDULER_DEFAULTS, **SCHEDULER_MODE_OVERRIDES.get(mode, {})}
        self.batch_size   = batch_size   or cfg["batch_size"]
        self.thread_count = thread_count or cfg["thread_count"]
        self.timeout      = timeout      or cfg["timeout"]
        self.retry_limit  = retry_limit  or cfg["retry_limit"]
        self.inter_batch_delay = cfg.get("inter_batch_delay", 0.3)

        self.mode    = mode
        self.console = console or Console()
        self.silent  = silent
        self.registry = registry or build_default_registry()

        # Runtime state
        self._completed: set[str] = set()  # tool names that finished (any status)
        self._succeeded: set[str] = set()  # tool names that succeeded

    # ══════════════════════════════════════════════════════════════════════════
    #  Public API
    # ══════════════════════════════════════════════════════════════════════════

    def run(self, target: str, result: ReconResult,
            profile: Optional[dict] = None) -> ExecutionSummary:
        """
        Execute all registered tools against target, in stage/batch order.
        Mutates result in-place with ingested outputs.
        Returns ExecutionSummary.
        """
        from ..config.settings import PROFILES
        profile = profile or PROFILES.get(self.mode, PROFILES["balanced"])

        summary = ExecutionSummary(target=target, mode=self.mode)
        run_start = time.perf_counter()

        stages = self.registry.stages()
        self._print_run_header(target, stages)

        for stage_num in stages:
            stage_tools = self.registry.by_stage(stage_num)
            if not stage_tools:
                continue

            # Special handling: if stage 3 (scanning) and masscan available,
            # skip tcp_scan.  If masscan NOT available, skip masscan.
            stage_tools = self._resolve_scan_fallback(stage_tools)

            # Skip tools that don't apply to this mode
            stage_tools = self._filter_by_mode(stage_tools, profile)

            if not stage_tools:
                continue

            stage_label = _STAGE_LABELS.get(stage_num, f"Stage {stage_num}")
            batch_results = self._run_stage(
                stage_num, stage_label, stage_tools, target, profile, result
            )
            summary.batches.extend(batch_results)

        summary.total_time_s = time.perf_counter() - run_start
        self._print_run_summary(summary)
        return summary

    def run_tools(
        self,
        tool_names: list[str],
        target:     str,
        result:     ReconResult,
        profile:    Optional[dict] = None,
    ) -> ExecutionSummary:
        """
        Run a specific list of tools by name (used by learn/guided mode).
        Tools run in a single batch (parallel).
        """
        from ..config.settings import PROFILES
        profile = profile or PROFILES.get(self.mode, PROFILES["balanced"])

        descriptors = self.registry.by_names(tool_names)
        if not descriptors:
            self._p(f"[{_Y}]No matching tools found for: {tool_names}[/{_Y}]")
            return ExecutionSummary(target=target, mode=self.mode)

        summary   = ExecutionSummary(target=target, mode=self.mode)
        run_start = time.perf_counter()

        batch = self._execute_batch(
            batch_index=0,
            batch_label="On-Demand",
            stage=0,
            tools=descriptors,
            target=target,
            profile=profile,
            result=result,
        )
        summary.batches.append(batch)
        summary.total_time_s = time.perf_counter() - run_start
        self._print_run_summary(summary)
        return summary

    # ══════════════════════════════════════════════════════════════════════════
    #  Stage runner
    # ══════════════════════════════════════════════════════════════════════════

    def _run_stage(
        self,
        stage_num:   int,
        stage_label: str,
        tools:       list[ToolDescriptor],
        target:      str,
        profile:     dict,
        result:      ReconResult,
    ) -> list[BatchResult]:
        """Slice tools into batches; run batches sequentially."""
        if not self.silent:
            self.console.print()
            self.console.print(Rule(
                f"[{_RB}]  {stage_label.upper()}  [/{_RB}]",
                style=_R,
            ))

        batch_results: list[BatchResult] = []
        batches = _chunk(tools, self.batch_size)

        for idx, batch_tools in enumerate(batches):
            # Dependency resolution within the stage
            ready, blocked = self.registry.resolve_dependencies(
                batch_tools, self._succeeded
            )
            # Blocked tools are auto-skipped this pass
            if blocked:
                skipped_batch = BatchResult(
                    batch_index=idx, batch_label="blocked-deps", stage=stage_num
                )
                for bt in blocked:
                    skipped_batch.tools.append(ToolExecutionResult(
                        tool_name=bt.name,
                        status=ToolStatus.SKIPPED,
                        failure_reason=FailureReason.DEPENDENCY_MISSING,
                        error_detail=f"Unmet deps: {bt.dependencies}",
                    ))
                batch_results.append(skipped_batch)

            if not ready:
                continue

            batch = self._execute_batch(
                batch_index=idx,
                batch_label=f"Batch {idx+1}/{len(batches)}",
                stage=stage_num,
                tools=ready,
                target=target,
                profile=profile,
                result=result,
            )
            batch_results.append(batch)

            if idx < len(batches) - 1:
                time.sleep(self.inter_batch_delay)

        return batch_results

    # ══════════════════════════════════════════════════════════════════════════
    #  Batch executor  (parallel inside batch, rich live display)
    # ══════════════════════════════════════════════════════════════════════════

    def _execute_batch(
        self,
        batch_index: int,
        batch_label: str,
        stage:       int,
        tools:       list[ToolDescriptor],
        target:      str,
        profile:     dict,
        result:      ReconResult,
    ) -> BatchResult:

        batch = BatchResult(
            batch_index=batch_index,
            batch_label=batch_label,
            stage=stage,
            started_at=time.perf_counter(),
        )

        # ── Classify tools before running ─────────────────────────────────────
        tool_results: dict[str, ToolExecutionResult] = {}
        runnable: list[ToolDescriptor] = []

        for td in tools:
            if td.name in self._completed:
                tr = ToolExecutionResult(tool_name=td.name, status=ToolStatus.DUPLICATE)
                tool_results[td.name] = tr
                batch.tools.append(tr)
                continue
            if not td.available:
                tr = ToolExecutionResult(
                    tool_name=td.name,
                    status=ToolStatus.SKIPPED,
                    failure_reason=FailureReason.NOT_INSTALLED,
                    error_detail=f"Binary '{td.binary}' not found on PATH",
                )
                tool_results[td.name] = tr
                batch.tools.append(tr)
                self._completed.add(td.name)
                continue
            tr = ToolExecutionResult(tool_name=td.name, status=ToolStatus.RUNNING)
            tool_results[td.name] = tr
            runnable.append(td)

        if not runnable:
            batch.finished_at = time.perf_counter()
            if not self.silent:
                self._print_batch_table(batch_label, tool_results)
            return batch

        # ── Live progress UI ──────────────────────────────────────────────────
        if self.silent:
            self._run_parallel_silent(
                runnable, tool_results, target, profile, result
            )
        else:
            self._run_parallel_live(
                batch_label, runnable, tool_results, target, profile, result
            )

        # ── Flush results into batch ──────────────────────────────────────────
        for td in runnable:
            tr = tool_results[td.name]
            batch.tools.append(tr)
            self._completed.add(td.name)
            if tr.status == ToolStatus.SUCCESS:
                self._succeeded.add(td.name)
                ingest_output(td.name, tr.output, result)

        batch.finished_at = time.perf_counter()
        return batch

    # ── Parallel runners ──────────────────────────────────────────────────────

    def _run_parallel_silent(
        self,
        runnable:     list[ToolDescriptor],
        tool_results: dict[str, ToolExecutionResult],
        target:       str,
        profile:      dict,
        result:       ReconResult,
    ) -> None:
        workers = min(len(runnable), self.thread_count)
        with ThreadPoolExecutor(max_workers=workers) as pool:
            futures = {
                pool.submit(
                    self._run_single_tool, td, target, profile, result
                ): td
                for td in runnable
            }
            for future in as_completed(futures):
                td = futures[future]
                try:
                    tool_results[td.name] = future.result()
                except Exception as exc:
                    tool_results[td.name] = ToolExecutionResult(
                        tool_name=td.name,
                        status=ToolStatus.FAILED,
                        failure_reason=FailureReason.EXCEPTION,
                        error_detail=str(exc),
                    )

    def _run_parallel_live(
        self,
        batch_label:  str,
        runnable:     list[ToolDescriptor],
        tool_results: dict[str, ToolExecutionResult],
        target:       str,
        profile:      dict,
        result:       ReconResult,
    ) -> None:
        """Run tools in parallel with a Rich Live table updating in real-time."""
        workers = min(len(runnable), self.thread_count)

        # Build the live table reference (updated from main thread after futures complete)
        with Live(
            self._make_live_table(batch_label, tool_results),
            console=self.console,
            refresh_per_second=8,
            transient=False,
        ) as live:
            with ThreadPoolExecutor(max_workers=workers) as pool:
                futures = {
                    pool.submit(
                        self._run_single_tool, td, target, profile, result
                    ): td
                    for td in runnable
                }
                for future in as_completed(futures):
                    td = futures[future]
                    try:
                        tool_results[td.name] = future.result()
                    except Exception as exc:
                        tool_results[td.name] = ToolExecutionResult(
                            tool_name=td.name,
                            status=ToolStatus.FAILED,
                            failure_reason=FailureReason.EXCEPTION,
                            error_detail=str(exc),
                        )
                    # Refresh the live table with updated status
                    live.update(self._make_live_table(batch_label, tool_results))

        # Final static summary row
        self._print_batch_summary_row(batch_label, tool_results)

    def _run_single_tool(
        self,
        td:      ToolDescriptor,
        target:  str,
        profile: dict,
        result:  ReconResult,
    ) -> ToolExecutionResult:
        """Execute one tool with timeout + retry; return ToolExecutionResult."""
        if td.runner is None:
            return ToolExecutionResult(
                tool_name=td.name,
                status=ToolStatus.SKIPPED,
                failure_reason=FailureReason.NOT_INSTALLED,
                error_detail="No runner registered",
            )

        output, duration, failure, detail = run_with_timeout(
            fn=lambda: td.runner(target, profile, result),
            timeout_s=float(self.timeout),
            retries=self.retry_limit,
        )

        if failure == FailureReason.TIMEOUT:
            return ToolExecutionResult(
                tool_name=td.name,
                status=ToolStatus.TIMEOUT,
                duration_s=duration,
                failure_reason=failure,
                error_detail=detail,
            )
        if failure is not None:
            return ToolExecutionResult(
                tool_name=td.name,
                status=ToolStatus.FAILED,
                duration_s=duration,
                failure_reason=failure,
                error_detail=detail,
            )
        if output is None:
            # Tool ran but returned None (condition not met, e.g. no port 443)
            return ToolExecutionResult(
                tool_name=td.name,
                status=ToolStatus.SKIPPED,
                duration_s=duration,
                error_detail="Runner returned None (condition not met)",
            )
        return ToolExecutionResult(
            tool_name=td.name,
            status=ToolStatus.SUCCESS,
            duration_s=duration,
            output=output,
        )

    # ══════════════════════════════════════════════════════════════════════════
    #  Rich UI builders
    # ══════════════════════════════════════════════════════════════════════════

    def _make_live_table(
        self,
        batch_label: str,
        tool_results: dict[str, ToolExecutionResult],
    ) -> Table:
        t = Table(
            box=box.SIMPLE,
            show_header=True,
            show_edge=False,
            border_style=_RD,
            header_style=_RB,
            padding=(0, 2),
            title=f"[{_RD}]{batch_label}[/{_RD}]",
        )
        t.add_column("",       width=4,  no_wrap=True)  # icon
        t.add_column("TOOL",   style=_R, width=16, no_wrap=True)
        t.add_column("STATUS",           width=12, no_wrap=True)
        t.add_column("TIME",   style=_D, width=8,  no_wrap=True)
        t.add_column("DETAIL", style=_D)

        for name, tr in tool_results.items():
            icon   = Text(tr.icon, style=tr.style)
            status = Text(tr.status.value.upper(), style=tr.style)
            dur    = f"{tr.duration_s:.1f}s" if tr.duration_s > 0 else "—"
            detail = tr.error_detail[:60] if tr.error_detail else ""

            if tr.status == ToolStatus.RUNNING:
                status = Text("●  running", style="bold cyan")

            t.add_row(icon, name, status, dur, detail)

        return t

    def _print_batch_table(
        self,
        batch_label: str,
        tool_results: dict[str, ToolExecutionResult],
    ) -> None:
        if not self.silent:
            self.console.print(self._make_live_table(batch_label, tool_results))

    def _print_batch_summary_row(
        self,
        batch_label: str,
        tool_results: dict[str, ToolExecutionResult],
    ) -> None:
        ok   = sum(1 for tr in tool_results.values() if tr.status == ToolStatus.SUCCESS)
        fail = sum(1 for tr in tool_results.values() if tr.status in
                   (ToolStatus.FAILED, ToolStatus.TIMEOUT))
        skip = sum(1 for tr in tool_results.values() if tr.status in
                   (ToolStatus.SKIPPED, ToolStatus.DUPLICATE))
        total_t = sum(tr.duration_s for tr in tool_results.values())

        parts = []
        if ok:   parts.append(f"[{_G}]✔ {ok} ok[/{_G}]")
        if fail: parts.append(f"[{_RB}]✖ {fail} failed[/{_RB}]")
        if skip: parts.append(f"[{_D}]○ {skip} skipped[/{_D}]")
        parts.append(f"[{_D}]{total_t:.1f}s[/{_D}]")

        self.console.print(
            f"  [{_RD}]↳ {batch_label}:[/{_RD}]  " + "  ".join(parts)
        )

    def _print_run_header(self, target: str, stages: list[int]) -> None:
        if self.silent:
            return
        self.console.print(Panel(
            f"[{_RB}]TARGET[/{_RB}]  [{_W}]{target}[/{_W}]   "
            f"[{_RD}]mode:[/{_RD}] [{_W}]{self.mode}[/{_W}]   "
            f"[{_RD}]stages:[/{_RD}] [{_W}]{len(stages)}[/{_W}]   "
            f"[{_RD}]batch_size:[/{_RD}] [{_W}]{self.batch_size}[/{_W}]   "
            f"[{_RD}]threads:[/{_RD}] [{_W}]{self.thread_count}[/{_W}]   "
            f"[{_RD}]timeout:[/{_RD}] [{_W}]{self.timeout}s[/{_W}]",
            border_style=_R, padding=(0, 2),
        ))

    def _print_run_summary(self, summary: ExecutionSummary) -> None:
        if self.silent:
            return
        self.console.print()
        self.console.print(Rule(f"[{_RB}]  EXECUTION SUMMARY  [/{_RB}]", style=_R))
        self.console.print()

        # Stat cards
        grade_col = "bold green" if summary.failed == 0 else (
            "yellow" if summary.failed <= 2 else "bold red"
        )
        from rich.columns import Columns
        self.console.print(Columns([
            Panel(f"[{_RB}]{summary.total}[/{_RB}]\n[{_D}]TOTAL[/{_D}]",
                  border_style=_R,   padding=(0, 3), expand=True),
            Panel(f"[bold green]{summary.succeeded}[/bold green]\n[{_D}]SUCCESS[/{_D}]",
                  border_style="green", padding=(0, 3), expand=True),
            Panel(f"[{_RB}]{summary.failed}[/{_RB}]\n[{_D}]FAILED[/{_D}]",
                  border_style=_R,   padding=(0, 3), expand=True),
            Panel(f"[yellow]{summary.timed_out}[/yellow]\n[{_D}]TIMEOUT[/{_D}]",
                  border_style="yellow", padding=(0, 3), expand=True),
            Panel(f"[{_D}]{summary.skipped}[/{_D}]\n[{_D}]SKIPPED[/{_D}]",
                  border_style="dim",  padding=(0, 3), expand=True),
            Panel(f"[{_W}]{summary.total_time_s:.1f}s[/{_W}]\n[{_D}]TOTAL TIME[/{_D}]",
                  border_style=_RD,  padding=(0, 3), expand=True),
        ], equal=True, expand=True))

        # Per-tool breakdown
        self.console.print()
        t = Table(box=box.SIMPLE_HEAD, show_edge=False,
                  border_style=_RD, header_style=_RB, padding=(0, 2))
        t.add_column("",      width=4)
        t.add_column("TOOL",  style=_R,  width=16)
        t.add_column("STATUS",           width=12)
        t.add_column("TIME",  style=_D,  width=8)
        t.add_column("INFO",  style=_D)

        for tr in summary.all_results():
            if tr.status == ToolStatus.DUPLICATE:
                continue
            t.add_row(
                Text(tr.icon, style=tr.style),
                tr.tool_name,
                Text(tr.status.value.upper(), style=tr.style),
                f"{tr.duration_s:.1f}s" if tr.duration_s > 0 else "—",
                (tr.error_detail or "")[:60],
            )
        self.console.print(t)
        self.console.print()

    # ══════════════════════════════════════════════════════════════════════════
    #  Helpers
    # ══════════════════════════════════════════════════════════════════════════

    def _p(self, msg: str) -> None:
        if not self.silent:
            self.console.print(msg)

    @staticmethod
    def _resolve_scan_fallback(
        tools: list[ToolDescriptor],
    ) -> list[ToolDescriptor]:
        """
        If masscan is available → remove tcp_scan.
        If masscan is not available → remove masscan.
        Both can't run for the same target (would double-scan).
        """
        import shutil
        has_masscan = shutil.which("masscan") is not None
        if has_masscan:
            return [t for t in tools if t.name != "tcp_scan"]
        return [t for t in tools if t.name != "masscan"]

    @staticmethod
    def _filter_by_mode(
        tools:   list[ToolDescriptor],
        profile: dict,
    ) -> list[ToolDescriptor]:
        """Drop tools that the current profile doesn't want."""
        out = []
        for t in tools:
            # amass only in deep mode
            if t.name == "amass" and not profile.get("amass_passive", False):
                continue
            # web analysis tools only when web_analysis=True
            if t.category == "web" and t.stage in (4, 5) \
               and not profile.get("web_analysis", True):
                continue
            out.append(t)
        return out


# ── Stage label map ───────────────────────────────────────────────────────────
_STAGE_LABELS: dict[int, str] = {
    0: "On-Demand Execution",
    1: "Stage 1 — Basic Recon",
    2: "Stage 2 — Subdomain Discovery",
    3: "Stage 3 — Port Scanning",
    4: "Stage 4 — Web Analysis",
    5: "Stage 5 — Security Analysis",
    8: "Stage 8 — Vulnerability Detection & Exposure Analysis",
}


# ── Utility ───────────────────────────────────────────────────────────────────
def _chunk(lst: list, size: int) -> list[list]:
    """Split list into chunks of at most `size`."""
    return [lst[i:i + size] for i in range(0, max(1, len(lst)), size)]
