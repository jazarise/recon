"""
ReconX — Tool Registry.

Each registered tool descriptor contains:
  name         unique slug
  category     matches cli/categories.py keys
  stage        execution order (1=basic, 2=discovery, 3=scan, 4=web, 5=security)
  priority     lower = runs first inside a stage
  passive      True = no packets sent to target
  dependencies list of OTHER tool slugs that must succeed first
  binary       system binary name (for availability check)
  runner       callable: (target, profile, result) -> dict | None

The registry is the single source of truth for what runs and when.
Tools with missing binaries are auto-marked SKIPPED.
"""
from __future__ import annotations
import logging
import shutil
from dataclasses import dataclass, field
from typing import Callable, Optional

logger = logging.getLogger("reconx.engine.registry")


@dataclass
class ToolDescriptor:
    name:         str
    category:     str
    stage:        int                     # 1–5
    priority:     int                     = 50    # 0 = highest
    passive:      bool                    = False
    binary:       str                     = ""    # empty = pure-Python, always available
    dependencies: list[str]               = field(default_factory=list)
    runner:       Optional[Callable]      = field(default=None, repr=False)
    description:  str                     = ""

    @property
    def available(self) -> bool:
        """True if the tool binary exists on PATH (or needs no binary)."""
        if not self.binary:
            return True
        return shutil.which(self.binary) is not None


class ToolRegistry:
    """Central registry. Instantiate once; share across the engine."""

    def __init__(self) -> None:
        self._tools: dict[str, ToolDescriptor] = {}

    # ── Registration ──────────────────────────────────────────────────────────

    def register(self, descriptor: ToolDescriptor) -> None:
        if descriptor.name in self._tools:
            logger.debug("Re-registering tool: %s", descriptor.name)
        self._tools[descriptor.name] = descriptor

    def register_all(self, descriptors: list[ToolDescriptor]) -> None:
        for d in descriptors:
            self.register(d)

    # ── Lookup ────────────────────────────────────────────────────────────────

    def get(self, name: str) -> Optional[ToolDescriptor]:
        return self._tools.get(name)

    def all(self) -> list[ToolDescriptor]:
        return list(self._tools.values())

    def by_stage(self, stage: int) -> list[ToolDescriptor]:
        tools = [t for t in self._tools.values() if t.stage == stage]
        return sorted(tools, key=lambda t: t.priority)

    def by_category(self, category: str) -> list[ToolDescriptor]:
        return [t for t in self._tools.values() if t.category == category]

    def by_names(self, names: list[str]) -> list[ToolDescriptor]:
        found, missing = [], []
        for name in names:
            td = self._tools.get(name)
            if td:
                found.append(td)
            else:
                missing.append(name)
        if missing:
            logger.warning("Unknown tool(s) requested: %s", ", ".join(missing))
        return found

    def stages(self) -> list[int]:
        return sorted({t.stage for t in self._tools.values()})

    # ── Dependency resolution ─────────────────────────────────────────────────

    def resolve_dependencies(
        self,
        tools: list[ToolDescriptor],
        completed: set[str],
    ) -> tuple[list[ToolDescriptor], list[ToolDescriptor]]:
        """
        Split tools into (ready, blocked).
        A tool is blocked if any dependency is NOT in completed set.
        """
        ready, blocked = [], []
        for t in tools:
            unmet = [d for d in t.dependencies if d not in completed]
            if unmet:
                logger.debug("Tool '%s' blocked by: %s", t.name, unmet)
                blocked.append(t)
            else:
                ready.append(t)
        return ready, blocked

    def summary(self) -> str:
        lines = [f"ToolRegistry — {len(self._tools)} tools registered"]
        for stage in self.stages():
            stage_tools = self.by_stage(stage)
            avail = sum(1 for t in stage_tools if t.available)
            lines.append(
                f"  Stage {stage}: {len(stage_tools)} tools "
                f"({avail} available, {len(stage_tools)-avail} missing)"
            )
        return "\n".join(lines)


# ══════════════════════════════════════════════════════════════════════════════
#  Default registry builder
# ══════════════════════════════════════════════════════════════════════════════

def build_default_registry() -> ToolRegistry:
    """
    Builds and returns the default ReconX tool registry.
    Runner callables accept (target: str, profile: dict, result: ReconResult)
    and return a dict of raw tool output (or None on failure).
    """
    from ..tools.whois_tool        import WhoisTool
    from ..tools.dns_tool          import DNSTool
    from ..tools.subfinder         import SubfinderTool
    from ..tools.amass             import AmassTool
    from ..tools.masscan           import MasscanTool
    from ..tools.tcp_scanner       import TCPScanner
    from ..tools.nmap_tool         import NmapTool
    from ..tools.httpx_tool        import HttpxTool
    from ..tools.whatweb           import WhatwebTool
    from ..tools.ssl_checker       import SSLChecker
    from ..tools.header_checker    import HeaderChecker
    from ..tools.takeover_detector import TakeoverDetector

    reg = ToolRegistry()

    # ── Stage 1: Basic Recon (passive, no binary needed for DNS) ──────────────
    reg.register(ToolDescriptor(
        name="whois", category="passive", stage=1, priority=10,
        passive=True, binary="whois",
        description="Domain registration info, registrant org, name servers",
        runner=lambda t, p, r: WhoisTool().run(t),
    ))
    reg.register(ToolDescriptor(
        name="dns", category="dns", stage=1, priority=20,
        passive=True, binary="",          # pure Python
        description="DNS A/MX/NS/TXT/CNAME records via dnspython",
        runner=lambda t, p, r: DNSTool().run(t),
    ))

    # ── Stage 2: Subdomain Discovery ──────────────────────────────────────────
    reg.register(ToolDescriptor(
        name="subfinder", category="subdomain", stage=2, priority=10,
        passive=True, binary="subfinder",
        description="Passive subdomain enumeration from 40+ OSINT sources",
        runner=lambda t, p, r: SubfinderTool().run(t),
    ))
    reg.register(ToolDescriptor(
        name="amass", category="subdomain", stage=2, priority=20,
        passive=True, binary="amass",
        description="Deep passive+active subdomain graph enumeration",
        runner=lambda t, p, r: AmassTool().run(t),
    ))

    # ── Stage 3: Port Scanning ────────────────────────────────────────────────
    reg.register(ToolDescriptor(
        name="masscan", category="scanning", stage=3, priority=10,
        passive=False, binary="masscan",
        description="Ultra-fast SYN port discovery across full range",
        runner=lambda t, p, r: MasscanTool().run(
            t,
            port_range=p.get("port_range", "1-1000"),
            rate=p.get("masscan_rate", 2000),
        ),
    ))
    reg.register(ToolDescriptor(
        name="tcp_scan", category="scanning", stage=3, priority=15,
        passive=False, binary="",         # pure Python fallback
        description="Python TCP connect scanner (masscan fallback)",
        runner=lambda t, p, r: TCPScanner(
            threads=p.get("threads", 80),
            timeout=p.get("timeout", 2),
        ).run(t, port_range=p.get("port_range", "1-1000")),
    ))
    reg.register(ToolDescriptor(
        name="nmap", category="scanning", stage=3, priority=30,
        passive=False, binary="nmap",
        dependencies=[],                  # runs after masscan/tcp via scheduler
        description="Service/version detection and OS fingerprinting",
        runner=lambda t, p, r: NmapTool().run(
            t,
            ports=[port.number for port in r.ports] or None,
            port_range=p.get("port_range", "1-1000"),
            os_detect=True,
            timeout=180,
        ),
    ))

    # ── Stage 4: Web Analysis ─────────────────────────────────────────────────
    reg.register(ToolDescriptor(
        name="httpx", category="web", stage=4, priority=10,
        passive=False, binary="httpx",
        description="HTTP probing: status, title, tech stack, redirects",
        runner=lambda t, p, r: HttpxTool().run(
            [t] + r.subdomains[:50]
        ),
    ))
    reg.register(ToolDescriptor(
        name="whatweb", category="web", stage=4, priority=20,
        passive=False, binary="whatweb",
        description="Web technology fingerprinting via 1800+ plugins",
        runner=lambda t, p, r: WhatwebTool().run(f"http://{t}"),
    ))

    # ── Stage 5: Security Analysis ────────────────────────────────────────────
    reg.register(ToolDescriptor(
        name="ssl_check", category="web", stage=5, priority=10,
        passive=False, binary="",
        description="TLS certificate inspection: expiry, issuer, self-signed",
        runner=lambda t, p, r: {
            "tls": SSLChecker().check(
                t,
                next((port.number for port in r.ports if port.number == 443), 443)
            )
        } if any(port.number == 443 for port in r.ports) else None,
    ))
    reg.register(ToolDescriptor(
        name="header_check", category="web", stage=5, priority=20,
        passive=False, binary="",
        description="HTTP security header gap analysis (CSP, HSTS, XFO…)",
        runner=lambda t, p, r: {
            "headers": HeaderChecker().check(
                f"https://{t}"
                if any(port.number == 443 for port in r.ports)
                else f"http://{t}"
            )
        } if r.ports else None,
    ))
    reg.register(ToolDescriptor(
        name="takeover", category="subdomain", stage=5, priority=30,
        passive=True, binary="",
        description="Subdomain takeover detection via dangling CNAME analysis",
        runner=lambda t, p, r: {
            "takeover": TakeoverDetector().detect(r.subdomains[:40])
        } if r.subdomains else None,
    ))

    extend_registry_passive(reg)
    extend_registry_dns(reg)
    extend_registry_scanning(reg)
    extend_registry_web(reg)
    return reg


def extend_registry_passive(reg: ToolRegistry) -> ToolRegistry:
    """
    Add Stage 2 passive tools to an existing registry.
    Called by build_default_registry() automatically.
    """
    from ..tools.passive.assetfinder  import AssetfinderTool
    from ..tools.passive.findomain    import FindomainTool
    from ..tools.passive.crtsh        import CrtshTool
    from ..tools.passive.chaos        import ChaosTool
    from ..tools.passive.gau          import GauTool
    from ..tools.passive.waybackurls  import WaybackurlsTool

    reg.register(ToolDescriptor(
        name="assetfinder", category="subdomain", stage=2, priority=15,
        passive=True, binary="assetfinder",
        description="Passive subdomain enumeration via crt.sh, Facebook, VirusTotal",
        runner=lambda t, p, r: AssetfinderTool().safe_run(t).data,
    ))
    reg.register(ToolDescriptor(
        name="findomain", category="subdomain", stage=2, priority=20,
        passive=True, binary="findomain",
        description="Fast subdomain discovery from 16+ passive sources",
        runner=lambda t, p, r: FindomainTool().safe_run(t).data,
    ))
    reg.register(ToolDescriptor(
        name="crtsh", category="subdomain", stage=2, priority=25,
        passive=True, binary="",   # pure-Python, always available
        description="Certificate transparency log subdomain enumeration",
        runner=lambda t, p, r: CrtshTool().safe_run(t).data,
    ))
    reg.register(ToolDescriptor(
        name="chaos", category="subdomain", stage=2, priority=30,
        passive=True, binary="",
        description="ProjectDiscovery Chaos dataset — pre-collected subdomains",
        runner=lambda t, p, r: ChaosTool().safe_run(t).data,
    ))
    reg.register(ToolDescriptor(
        name="gau", category="url", stage=2, priority=40,
        passive=True, binary="gau",
        description="Historical URL collection from Wayback, CommonCrawl, OTX, URLScan",
        runner=lambda t, p, r: GauTool().safe_run(t).data,
    ))
    reg.register(ToolDescriptor(
        name="waybackurls", category="url", stage=2, priority=45,
        passive=True, binary="waybackurls",
        description="Wayback Machine CDX URL archive (fallback: pure-Python)",
        runner=lambda t, p, r: WaybackurlsTool().safe_run(t).data,
    ))

    return reg


def extend_registry_dns(reg: ToolRegistry) -> ToolRegistry:
    """Add Stage 3 DNS tools to an existing registry."""
    from ..tools.dns.dnsx_tool       import DnsxTool
    from ..tools.dns.shuffledns_tool import ShuffleDNSTool
    from ..tools.dns.massdns_tool    import MassDNSTool
    from ..tools.dns.puredns_tool    import PureDNSTool

    reg.register(ToolDescriptor(
        name="dnsx", category="dns", stage=3, priority=5,
        passive=False, binary="dnsx",
        description="DNS resolution, record enrichment, wildcard filtering",
        runner=lambda t, p, r: DnsxTool().safe_run(
            t, subdomains=r.subdomains[:2000],
            threads=p.get("threads", 50),
        ).data,
    ))
    reg.register(ToolDescriptor(
        name="puredns", category="dns", stage=3, priority=15,
        passive=False, binary="puredns",
        description="Accurate DNS brute-force with wildcard elimination",
        runner=lambda t, p, r: PureDNSTool().safe_run(
            t, mode="bruteforce",
            threads=p.get("threads", 100),
        ).data,
    ))
    reg.register(ToolDescriptor(
        name="shuffledns", category="dns", stage=3, priority=20,
        passive=False, binary="shuffledns",
        description="Mass DNS brute-force via shuffled wordlists",
        runner=lambda t, p, r: ShuffleDNSTool().safe_run(
            t, mode="bruteforce",
            threads=p.get("threads", 1000),
        ).data,
    ))
    reg.register(ToolDescriptor(
        name="massdns", category="dns", stage=3, priority=25,
        passive=False, binary="massdns",
        description="Ultra-fast bulk DNS resolution",
        runner=lambda t, p, r: MassDNSTool().safe_run(
            t, subdomains=r.subdomains[:5000],
            threads=p.get("threads", 100),
        ).data if r.subdomains else None,
    ))
    return reg


def extend_registry_scanning(reg: ToolRegistry) -> ToolRegistry:
    """Add Stage 3 scanning tools (naabu, rustscan) to the registry."""
    from ..tools.scanning.naabu_tool    import NaabuTool
    from ..tools.scanning.rustscan_tool import RustScanTool
    from ..tools.scanning.nmap_tool     import NmapTool as ScanNmapTool

    reg.register(ToolDescriptor(
        name="rustscan", category="scanning", stage=3, priority=6,
        passive=False, binary="rustscan",
        description="Ultra-fast Rust port scanner — discovers all 65535 ports in seconds",
        runner=lambda t, p, r: RustScanTool().safe_run(
            t, port_range=p.get("port_range", "1-10000"),
        ).data,
    ))
    reg.register(ToolDescriptor(
        name="naabu", category="scanning", stage=3, priority=8,
        passive=False, binary="naabu",
        description="Go-based fast port scanner with CDN exclusion",
        runner=lambda t, p, r: NaabuTool().safe_run(
            t, port_range=p.get("port_range", "1-10000"),
            rate=p.get("naabu_rate", 1000),
        ).data,
    ))
    return reg


def extend_registry_web(reg: ToolRegistry) -> ToolRegistry:
    """Add Stage 4 web recon tools to the registry."""
    from ..tools.web.katana_tool    import KatanaTool
    from ..tools.web.hakrawler_tool import HakrawlerTool
    from ..tools.web.ffuf_tool      import FfufTool
    from ..tools.web.gobuster_tool  import GobusterTool
    from ..tools.web.dirsearch_tool import DirsearchTool

    reg.register(ToolDescriptor(
        name="katana", category="web", stage=4, priority=5,
        passive=False, binary="katana",
        description="Next-gen web crawler — JS rendering, form submission, scope control",
        runner=lambda t, p, r: KatanaTool().safe_run(t).data,
    ))
    reg.register(ToolDescriptor(
        name="hakrawler", category="web", stage=4, priority=10,
        passive=False, binary="hakrawler",
        description="Fast crawler combining live crawl + Wayback Machine historical data",
        runner=lambda t, p, r: HakrawlerTool().safe_run(t).data,
    ))
    reg.register(ToolDescriptor(
        name="ffuf", category="web", stage=4, priority=20,
        passive=False, binary="ffuf",
        description="Fastest web fuzzer — directory/file discovery with auto-calibration",
        runner=lambda t, p, r: FfufTool().safe_run(t).data,
    ))
    reg.register(ToolDescriptor(
        name="gobuster", category="web", stage=4, priority=25,
        passive=False, binary="gobuster",
        description="Multi-mode brute-forcer: dir, dns, vhost modes",
        runner=lambda t, p, r: GobusterTool().safe_run(t).data,
    ))
    reg.register(ToolDescriptor(
        name="dirsearch", category="web", stage=4, priority=30,
        passive=False, binary="dirsearch",
        description="Python directory scanner with built-in wordlist and recursive discovery",
        runner=lambda t, p, r: DirsearchTool().safe_run(t).data,
    ))
    return reg
