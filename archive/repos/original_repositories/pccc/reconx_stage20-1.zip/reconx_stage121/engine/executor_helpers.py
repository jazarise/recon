"""
ReconX — Executor Helpers v2.
Handles both legacy dict output AND new ToolRunResult from standardized tools.
Ingests tool output into the shared ReconResult.
"""
from __future__ import annotations
import logging
import time
from concurrent.futures import Future, ThreadPoolExecutor, TimeoutError as FutureTimeout
from typing import Any, Callable, Optional, Union

from ..models.execution import FailureReason, ToolExecutionResult, ToolStatus
from ..models.tool_result import ToolRunResult, RunStatus
from ..models.findings import (
    DNSRecord, Port, ReconResult, Technology,
)

logger = logging.getLogger("reconx.engine.helpers")


# ══════════════════════════════════════════════════════════════════════════════
#  Timeout-safe runner (for registry lambdas that return plain dicts)
# ══════════════════════════════════════════════════════════════════════════════

def run_with_timeout(
    fn: Callable,
    timeout_s: float,
    retries: int = 0,
) -> tuple[Any, float, Optional[FailureReason], str]:
    attempt = 0
    while attempt <= retries:
        attempt += 1
        t0 = time.perf_counter()
        with ThreadPoolExecutor(max_workers=1) as pool:
            future: Future = pool.submit(fn)
            try:
                result = future.result(timeout=timeout_s)
                return result, time.perf_counter() - t0, None, ""
            except FutureTimeout:
                future.cancel()
                dur = time.perf_counter() - t0
                return None, dur, FailureReason.TIMEOUT, f"Exceeded {timeout_s}s"
            except KeyboardInterrupt:
                dur = time.perf_counter() - t0
                return None, dur, FailureReason.INTERRUPTED, "Interrupted"
            except Exception as exc:
                dur = time.perf_counter() - t0
                if attempt > retries:
                    return None, dur, FailureReason.EXCEPTION, f"{type(exc).__name__}: {exc}"
                time.sleep(0.4 * attempt)
    return None, 0.0, FailureReason.EXCEPTION, "Max retries exhausted"


# ══════════════════════════════════════════════════════════════════════════════
#  Output ingestion  — handles both ToolRunResult and plain dicts
# ══════════════════════════════════════════════════════════════════════════════

def ingest_output(
    tool_name: str,
    output: Union[dict, ToolRunResult, None],
    result: ReconResult,
) -> None:
    """
    Merge tool output into the shared ReconResult.
    Accepts both new ToolRunResult objects and legacy plain dicts.
    """
    if output is None:
        return

    # Unwrap ToolRunResult → get .data dict
    if isinstance(output, ToolRunResult):
        if not output.ok:
            logger.debug("Skipping ingest for failed tool '%s': %s", tool_name, output.status)
            return
        data = output.data
    else:
        data = output

    if not data:
        return

    try:
        ingestor = _INGESTORS.get(tool_name, _ingest_generic)
        ingestor(data, result)
        result.raw[tool_name] = data
    except Exception as exc:
        logger.warning("Ingest error for '%s': %s", tool_name, exc)


# ── Per-tool ingestors ────────────────────────────────────────────────────────

def _ingest_whois(out: dict, r: ReconResult) -> None:
    r.whois = {k: v for k, v in out.items() if k != "raw"}
    r.emails.extend(out.get("emails", []))
    r.raw["whois_raw"] = out.get("raw", "")


def _ingest_dns(out: dict, r: ReconResult) -> None:
    r.ip_addresses.extend(out.get("ip_addresses", []))
    for rtype, vals in out.get("records", {}).items():
        for v in vals:
            r.dns_records.append(DNSRecord(record_type=rtype, value=v))


def _ingest_subfinder(out: dict, r: ReconResult) -> None:
    r.subdomains.extend(out.get("subdomains", []))


def _ingest_amass(out: dict, r: ReconResult) -> None:
    r.subdomains.extend(out.get("subdomains", []))


def _ingest_masscan(out: dict, r: ReconResult) -> None:
    r.raw["masscan_ports"] = out.get("open_ports", [])


def _ingest_tcp_scan(out: dict, r: ReconResult) -> None:
    r.raw["tcp_ports"] = out.get("open_ports", [])


def _ingest_nmap(out: dict, r: ReconResult) -> None:
    r.ports.extend(out.get("ports", []))
    if out.get("os_info"):
        r.os_info = out["os_info"]


def _ingest_httpx(out: dict, r: ReconResult) -> None:
    for ep in out.get("endpoints", []):
        if ep.get("url"):
            r.web_endpoints.append(ep["url"])
    for tech in out.get("technologies", []):
        r.technologies.append(Technology(name=tech))


def _ingest_whatweb(out: dict, r: ReconResult) -> None:
    for tech in out.get("technologies", []):
        r.technologies.append(Technology(name=tech))


def _ingest_ssl_check(out: dict, r: ReconResult) -> None:
    tls = out.get("tls")
    if tls:
        r.tls_info = tls


def _ingest_header_check(out: dict, r: ReconResult) -> None:
    r.header_findings.extend(out.get("headers") or [])


def _ingest_takeover(out: dict, r: ReconResult) -> None:
    r.takeover_candidates.extend(out.get("takeover") or [])


def _ingest_generic(out: dict, r: ReconResult) -> None:
    pass



def _ingest_assetfinder(out: dict, r: ReconResult) -> None:
    r.subdomains.extend(out.get("subdomains", []))

def _ingest_findomain(out: dict, r: ReconResult) -> None:
    r.subdomains.extend(out.get("subdomains", []))

def _ingest_crtsh(out: dict, r: ReconResult) -> None:
    r.subdomains.extend(out.get("subdomains", []))

def _ingest_chaos(out: dict, r: ReconResult) -> None:
    r.subdomains.extend(out.get("subdomains", []))

def _ingest_gau(out: dict, r: ReconResult) -> None:
    r.web_endpoints.extend(out.get("urls", []))
    r.raw.setdefault("params", set())
    r.raw["params"].update(out.get("params", []))

def _ingest_waybackurls(out: dict, r: ReconResult) -> None:
    r.web_endpoints.extend(out.get("urls", []))
    r.raw.setdefault("params", set())
    r.raw["params"].update(out.get("params", []))


def _ingest_dnsx(out: dict, r: ReconResult) -> None:
    r.subdomains.extend(out.get("resolved", []))
    for ips in out.get("ip_map", {}).values():
        r.ip_addresses.extend(ips)
    for host, recs in out.get("record_map", {}).items():
        for rtype, vals in recs.items():
            for v in (vals or []):
                r.dns_records.append(DNSRecord(record_type=rtype.upper(), value=v))

def _ingest_massdns(out: dict, r: ReconResult) -> None:
    r.subdomains.extend(out.get("resolved", []))
    for ips in out.get("ip_map", {}).values():
        r.ip_addresses.extend(ips)

def _ingest_shuffledns(out: dict, r: ReconResult) -> None:
    r.subdomains.extend(out.get("subdomains", []))

def _ingest_puredns(out: dict, r: ReconResult) -> None:
    r.subdomains.extend(out.get("subdomains", []))


def _ingest_naabu(out: dict, r: ReconResult) -> None:
    r.raw.setdefault("discovered_ports", [])
    r.raw["discovered_ports"].extend(out.get("open_ports", []))

def _ingest_rustscan(out: dict, r: ReconResult) -> None:
    r.raw.setdefault("discovered_ports", [])
    r.raw["discovered_ports"].extend(out.get("open_ports", []))

def _ingest_scan_nmap(out: dict, r: ReconResult) -> None:
    r.ports.extend(out.get("ports", []))
    if out.get("os_info"):
        r.os_info = out["os_info"]
    r.raw["nmap_scripts"] = out.get("scripts", {})


def _ingest_katana(out: dict, r: ReconResult) -> None:
    r.web_endpoints.extend(out.get("urls", []))
    r.raw.setdefault("js_files", []).extend(out.get("js_files", []))

def _ingest_hakrawler(out: dict, r: ReconResult) -> None:
    r.web_endpoints.extend(out.get("urls", []))
    r.raw.setdefault("js_files", []).extend(out.get("js_files", []))

def _ingest_ffuf(out: dict, r: ReconResult) -> None:
    for entry in out.get("found", []):
        if entry.get("url"):
            r.web_endpoints.append(entry["url"])

def _ingest_gobuster(out: dict, r: ReconResult) -> None:
    for entry in out.get("found", []):
        if entry.get("url"):
            r.web_endpoints.append(entry["url"])

def _ingest_dirsearch(out: dict, r: ReconResult) -> None:
    for entry in out.get("found", []):
        if entry.get("url"):
            r.web_endpoints.append(entry["url"])

_INGESTORS: dict[str, Any] = {
    "whois":        _ingest_whois,
    "dns":          _ingest_dns,
    "subfinder":    _ingest_subfinder,
    "Subfinder":    _ingest_subfinder,   # ToolRunResult uses NAME not slug
    "amass":        _ingest_amass,
    "masscan":      _ingest_masscan,
    "tcp_scan":     _ingest_tcp_scan,
    "nmap":         _ingest_nmap,
    "Nmap":         _ingest_nmap,
    "httpx":        _ingest_httpx,
    "httpx_tool":   _ingest_httpx,
    "httpx_json":   _ingest_httpx,
    "httpx":        _ingest_httpx,
    "whatweb":      _ingest_whatweb,
    "ssl_check":    _ingest_ssl_check,
    "header_check": _ingest_header_check,
    "takeover":     _ingest_takeover,
    "assetfinder":  _ingest_assetfinder,
    "findomain":    _ingest_findomain,
    "crtsh":        _ingest_crtsh,
    "chaos":        _ingest_chaos,
    "gau":          _ingest_gau,
    "waybackurls":  _ingest_waybackurls,
    "dnsx":       _ingest_dnsx,
    "massdns":    _ingest_massdns,
    "shuffledns": _ingest_shuffledns,
    "puredns":    _ingest_puredns,
    "naabu":     _ingest_naabu,
    "rustscan":  _ingest_rustscan,
    "katana":     _ingest_katana,
    "hakrawler":  _ingest_hakrawler,
    "ffuf":       _ingest_ffuf,
    "gobuster":   _ingest_gobuster,
    "dirsearch":  _ingest_dirsearch,
}


# ══════════════════════════════════════════════════════════════════════════════
#  Port collection helper
# ══════════════════════════════════════════════════════════════════════════════

def collect_discovered_ports(result: ReconResult) -> list[int]:
    ports: list[int] = []
    ports.extend(result.raw.get("masscan_ports", []))
    ports.extend(result.raw.get("tcp_ports", []))
    ports.extend(p.number for p in result.ports)
    return sorted(set(ports))
