"""
ReconX — ExecutionEngine v3.
Thin facade over BatchScheduler.
Keeps the public API stable: engine.run(target) → ReconResult
"""
from __future__ import annotations
import logging
from datetime import datetime
from typing import Optional

from rich.console import Console

from ..config.settings import PROFILES
from ..analysis.cve_mapper        import CVEMapper
from ..analysis.deduplicator      import Deduplicator
from ..analysis.risk_scorer       import RiskScorer
from ..analysis.sensitive_detector import SensitiveDetector
from ..analysis.suggestion_engine import SuggestionEngine
from ..engine.scheduler           import BatchScheduler
from ..models.execution           import ExecutionSummary
from ..models.findings            import ReconResult

logger = logging.getLogger("reconx.engine.executor")


class ExecutionEngine:
    """
    Public API surface for the ReconX engine.

    Usage:
        engine = ExecutionEngine(mode="balanced")
        result = engine.run("example.com")          # full scan
        engine.run_tools(["nmap","dns"], target, r)  # selective
    """

    def __init__(
        self,
        mode:    str             = "balanced",
        threads: Optional[int]  = None,
        silent:  bool           = False,
        console: Optional[Console] = None,
    ):
        self.mode    = mode
        self.silent  = silent
        self.console = console or Console()
        self.profile = PROFILES.get(mode, PROFILES["balanced"])

        # Override thread count if provided
        if threads:
            self.profile = {**self.profile, "threads": threads}

        self._scheduler = BatchScheduler(
            mode=mode,
            console=self.console,
            silent=silent,
            thread_count=threads,
        )

        # Post-processing pipeline
        self._dedup     = Deduplicator()
        self._sensitive = SensitiveDetector()
        self._suggest   = SuggestionEngine()
        self._cve       = CVEMapper()
        self._risk      = RiskScorer()

        # Stage 17 — Infrastructure Intelligence pipeline (lazy-init)
        self._s17_correlator  = None
        self._s17_rel_mapper  = None
        self._s17_tag_engine  = None
        self._s17_banner_anal = None

    # ── Full scan ─────────────────────────────────────────────────────────────

    def run(self, target: str) -> ReconResult:
        result = ReconResult(
            target=target,
            timestamp=datetime.now().strftime("%Y%m%d_%H%M%S"),
            mode=self.mode,
        )
        result.domains.append(target)

        # Run all stages via scheduler
        self._scheduler.run(target, result, profile=self.profile)

        # Post-processing
        result                    = self._dedup.deduplicate(result)
        result.sensitive_findings = self._sensitive.detect(result)
        result.cve_matches        = self._cve.scan(result.ports)
        result.suggestions        = self._suggest.generate(result)
        result.risk_score         = self._risk.score(result)

        # Stage 17 — Infrastructure intelligence correlation phase
        result = self._run_intelligence_pipeline(result)

        return result

    # ── Selective execution (learn mode / guided mode) ────────────────────────

    def run_tools(
        self,
        tool_names: list[str],
        target:     str,
        result:     Optional[ReconResult] = None,
    ) -> tuple[ReconResult, ExecutionSummary]:
        """Run specific tools by name. Creates a fresh result if none provided."""
        if result is None:
            result = ReconResult(
                target=target,
                timestamp=datetime.now().strftime("%Y%m%d_%H%M%S"),
                mode=self.mode,
            )
            result.domains.append(target)

        summary = self._scheduler.run_tools(tool_names, target, result,
                                            profile=self.profile)

        # Partial post-processing
        result              = self._dedup.deduplicate(result)
        result.cve_matches  = self._cve.scan(result.ports)
        result.risk_score   = self._risk.score(result)

        return result, summary

    # ── Stage 17 Intelligence Pipeline ───────────────────────────────────────

    def _run_intelligence_pipeline(self, result: "ReconResult") -> "ReconResult":
        """
        Stage 17 post-processing phase: service correlation, relationship
        mapping, banner analysis, and infrastructure tagging.

        Runs after the standard post-processing pipeline.  Each sub-phase
        is fully isolated — a failure adds a warning to result.raw and
        continues.  This method NEVER raises.

        Results are stored in result.raw["intelligence"] for downstream
        consumers (report generator, TUI infrastructure view).
        """
        intelligence: dict = {}

        # ── Banner Analysis ───────────────────────────────────────────────────
        try:
            if self._s17_banner_anal is None:
                from ..tools.banner_analyzer import BannerAnalyzer
                self._s17_banner_anal = BannerAnalyzer()
            banner_results = self._s17_banner_anal.analyze_all(result.ports)
            intelligence["banner_analysis"] = [
                br.to_dict() for br in banner_results
            ]
            intelligence["banner_summary"] = (
                self._s17_banner_anal.summarize(banner_results)
            )
            logger.debug(
                f"Banner analysis: {len(banner_results)} banners parsed"
            )
        except Exception as exc:
            logger.warning(f"[Stage17] Banner analysis failed: {exc}")
            intelligence["banner_analysis"] = []

        # ── Service Correlation ───────────────────────────────────────────────
        try:
            if self._s17_correlator is None:
                from ..analysis.service_correlator import ServiceCorrelator
                self._s17_correlator = ServiceCorrelator()
            corr_report = self._s17_correlator.correlate(result)
            intelligence["correlation"] = corr_report.to_dict()
            logger.debug(
                f"Correlation: {corr_report.node_count()} nodes, "
                f"{corr_report.edge_count()} edges"
            )
        except Exception as exc:
            logger.warning(f"[Stage17] Service correlation failed: {exc}")
            intelligence["correlation"] = {
                "warning": f"Correlation unavailable: {exc}"
            }

        # ── Relationship Mapping ──────────────────────────────────────────────
        try:
            if self._s17_rel_mapper is None:
                from ..analysis.relationship_mapper import RelationshipMapper
                self._s17_rel_mapper = RelationshipMapper()
            rel_map = self._s17_rel_mapper.map(result)
            intelligence["relationships"] = rel_map.to_dict()
            logger.debug(
                f"Relationship map: {rel_map.total_groups} groups"
            )
        except Exception as exc:
            logger.warning(f"[Stage17] Relationship mapping failed: {exc}")
            intelligence["relationships"] = {
                "warning": f"Relationship mapping unavailable: {exc}"
            }

        # ── Infrastructure Tagging ────────────────────────────────────────────
        try:
            if self._s17_tag_engine is None:
                from ..analysis.tag_engine import TagEngine
                self._s17_tag_engine = TagEngine()
            tag_result = self._s17_tag_engine.tag(result)
            intelligence["tags"] = tag_result.to_dict()
            logger.debug(
                f"Tagging: {len(tag_result.tagged_assets)} assets tagged, "
                f"summary={tag_result.tag_summary}"
            )
        except Exception as exc:
            logger.warning(f"[Stage17] Tag engine failed: {exc}")
            intelligence["tags"] = {
                "warning": f"Tagging unavailable: {exc}"
            }

        result.raw["intelligence"] = intelligence
        return result
