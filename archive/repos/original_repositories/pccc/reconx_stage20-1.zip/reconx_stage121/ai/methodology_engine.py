"""
ReconX — Stage 10: Methodology Engine.

Loads and queries YAML methodology knowledge files.
Provides structured guidance content for:
  - Pre-phase explanations
  - Tool-specific rationale
  - Concept definitions
  - Learning mode integration
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Optional

logger = logging.getLogger("reconx.ai.methodology")

try:
    import yaml
    YAML_AVAILABLE = True
except ImportError:
    YAML_AVAILABLE = False


class MethodologyEngine:
    """
    Loads YAML methodology files and answers queries about recon methodology.

    Falls back to built-in content if YAML files are not available.
    """

    METHODOLOGY_DIR = Path(__file__).parent.parent / "knowledge" / "methodologies"

    def __init__(self) -> None:
        self._cache: dict[str, dict] = {}
        self._load_all()

    def _load_all(self) -> None:
        if not YAML_AVAILABLE:
            return
        if not self.METHODOLOGY_DIR.exists():
            return
        for yaml_file in self.METHODOLOGY_DIR.glob("*.yaml"):
            try:
                content = yaml.safe_load(yaml_file.read_text(encoding="utf-8"))
                if isinstance(content, dict):
                    self._cache[yaml_file.stem] = content
                    logger.debug(f"Loaded methodology: {yaml_file.stem}")
            except Exception as exc:
                logger.warning(f"Failed to load {yaml_file}: {exc}")

    def get_phase_guidance(self, phase_name: str) -> Optional[dict]:
        """Return full methodology guidance for a recon phase."""
        return self._cache.get(phase_name.lower().replace(" ", "_"))

    def get_tool_rationale(self, tool: str, phase: str) -> str:
        """Return the rationale for using a specific tool in a phase."""
        guidance = self.get_phase_guidance(phase)
        if not guidance:
            return self._builtin_rationale(tool)
        tools = guidance.get("tools", {})
        entry = tools.get(tool, {})
        return entry.get("rationale", self._builtin_rationale(tool))

    def get_concept(self, concept: str) -> Optional[dict]:
        """Look up a concept across all methodology files."""
        for _, content in self._cache.items():
            concepts = content.get("concepts", [])
            for c in concepts:
                if c.get("name", "").lower() == concept.lower():
                    return c
        return None

    def list_phases(self) -> list[str]:
        return list(self._cache.keys())

    def _builtin_rationale(self, tool: str) -> str:
        rationales = {
            "subfinder":    "Passive subdomain enumeration using 40+ sources — no direct target contact.",
            "amass":        "Active and passive enumeration; includes ASN-based discovery and graph analysis.",
            "crtsh":        "Certificate Transparency log query — reveals all TLS certs issued for a domain.",
            "dnsx":         "High-speed DNS resolver; validates and resolves discovered subdomain lists.",
            "nmap":         "Industry-standard port scanner; provides service version detection and OS fingerprinting.",
            "naabu":        "Fast Go-based port scanner from ProjectDiscovery; optimised for large-scale scanning.",
            "masscan":      "Fastest internet port scanner; 25Mpps rate; ideal for broad initial sweeps.",
            "httpx":        "HTTP probing tool; confirms live web services and extracts technology signals.",
            "whatweb":      "Web technology fingerprinter; identifies CMS, frameworks, server software.",
            "katana":       "Modern web crawler; handles JavaScript-rendered content and API endpoint discovery.",
            "gau":          "GetAllURLs; queries Wayback Machine, Common Crawl, and OTX for historical URLs.",
            "ffuf":         "Web fuzzer; directory/parameter discovery with customisable wordlists.",
            "nuclei":       "Template-based vulnerability scanner; 9000+ templates for CVEs, misconfigs, exposures.",
            "nikto":        "Web server scanner; checks for dangerous files, outdated software, missing headers.",
            "subjack":      "Subdomain takeover checker; validates CNAME targets against known-vulnerable services.",
            "intelligence_pipeline": "ReconX intelligence correlation engine; cross-sources findings into risk scores.",
        }
        return rationales.get(tool.lower(), f"{tool} is used for targeted reconnaissance in this phase.")
