"""
ReconX — Stage 10: Workflow Planner & Adaptive Orchestrator.

WorkflowPlanner:
  Converts a StrategyConfig into an ordered execution plan.
  Supports phase skipping, re-ordering, and conditional inclusion.

AdaptiveOrchestrator:
  Runs the execution plan, adapts dynamically based on findings,
  and calls DecisionEngine + NextStepPredictor after each step.
  Maintains the ReconContext throughout the session.
"""
from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Optional

from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn, TimeElapsedColumn

from .context_analyzer import ReconContext, Phase, ExecutedStep, Strategy
from .decision_engine import Decision, DecisionEngine
from .next_step_predictor import NextStepPredictor, NextStepReport
from .explanation_engine import ExplanationEngine
from .recon_strategy import StrategyConfig, PhaseConfig, StrategyEngine

logger = logging.getLogger("reconx.ai.orchestrator")


# ── Workflow step ─────────────────────────────────────────────────────────────

@dataclass
class WorkflowStep:
    """A concrete execution step in the workflow plan."""
    order:      int
    phase:      Phase
    action:     str
    tools:      list[str]
    config:     PhaseConfig
    decision:   Optional[Decision] = None
    enabled:    bool               = True
    skip_reason: str               = ""


@dataclass
class WorkflowPlan:
    """Complete ordered execution plan for a guided recon session."""
    strategy:   StrategyConfig
    steps:      list[WorkflowStep]
    ctx:        ReconContext
    created_at: float = field(default_factory=time.time)

    @property
    def enabled_steps(self) -> list[WorkflowStep]:
        return [s for s in self.steps if s.enabled]

    def disable_phase(self, phase: Phase, reason: str) -> None:
        for step in self.steps:
            if step.phase == phase:
                step.enabled     = False
                step.skip_reason = reason


# ══════════════════════════════════════════════════════════════════════════════
#  Workflow Planner
# ══════════════════════════════════════════════════════════════════════════════

class WorkflowPlanner:
    """
    Converts a StrategyConfig into an ordered WorkflowPlan.

    Applies phase ordering, conditional inclusion, and pre-computes
    decisions from the DecisionEngine for each enabled step.
    """

    def __init__(self) -> None:
        self._decision_engine = DecisionEngine()

    def plan(self, config: StrategyConfig, ctx: ReconContext) -> WorkflowPlan:
        """
        Build a WorkflowPlan from a StrategyConfig and current context.

        Args:
            config: StrategyConfig from StrategyEngine
            ctx:    Current ReconContext

        Returns:
            WorkflowPlan with all steps, decisions, and phase metadata
        """
        steps: list[WorkflowStep] = []

        for order, phase_cfg in enumerate(config.phases, start=1):
            # Skip disabled phases
            if not phase_cfg.enabled:
                steps.append(WorkflowStep(
                    order   = order,
                    phase   = phase_cfg.phase,
                    action  = f"[SKIP] {phase_cfg.phase.display}",
                    tools   = [],
                    config  = phase_cfg,
                    enabled = False,
                    skip_reason = phase_cfg.depth if phase_cfg.depth == "skip" else "Strategy exclusion",
                ))
                continue

            # Pre-compute decision for this phase
            decisions = self._decision_engine.decisions_for_phase(ctx, phase_cfg.phase)
            decision  = decisions[0] if decisions else None

            step = WorkflowStep(
                order    = order,
                phase    = phase_cfg.phase,
                action   = decision.action if decision else phase_cfg.phase.display,
                tools    = phase_cfg.tools,
                config   = phase_cfg,
                decision = decision,
                enabled  = True,
            )
            steps.append(step)

        logger.info(
            f"Workflow planned: {len([s for s in steps if s.enabled])}/{len(steps)} phases enabled"
        )
        return WorkflowPlan(strategy=config, steps=steps, ctx=ctx)

    def adapt_plan(
        self,
        plan:     WorkflowPlan,
        report:   NextStepReport,
        ctx:      ReconContext,
    ) -> WorkflowPlan:
        """
        Adapt an existing plan based on NextStepReport findings.

        Disables phases recommended for skipping and re-orders urgent steps.
        """
        for phase in report.can_skip:
            plan.disable_phase(phase, "Skipped by next-step predictor based on findings")
            logger.debug(f"Disabled phase {phase.value} based on predictor output")

        return plan


# ══════════════════════════════════════════════════════════════════════════════
#  Adaptive Orchestrator
# ══════════════════════════════════════════════════════════════════════════════

class AdaptiveOrchestrator:
    """
    Executes a WorkflowPlan adaptively — modifying the plan as findings
    accumulate and making AI decisions at each step.

    Integration mode:
      In guided recon, the orchestrator runs each phase via the existing
      ReconX engine (executor.py) and feeds results back into the context.
      When running standalone (demo/planning mode), it simulates execution.

    The orchestrator:
      1. Shows decision explanation (ExplanationEngine)
      2. Prompts for confirmation (if automation_level < 2)
      3. Executes the phase (via engine or simulation)
      4. Updates ReconContext with findings
      5. Runs NextStepPredictor to generate recommendations
      6. Adapts the WorkflowPlan
      7. Repeats until complete
    """

    def __init__(
        self,
        console:    Optional[Console]    = None,
        verbosity:  int                  = 2,
        dry_run:    bool                 = False,
    ) -> None:
        self._console    = console or Console()
        self._explainer  = ExplanationEngine(console=self._console, verbosity=verbosity)
        self._predictor  = NextStepPredictor()
        self._planner    = WorkflowPlanner()
        self._strategy   = StrategyEngine()
        self._decision   = DecisionEngine()
        self._dry_run    = dry_run

    def run(
        self,
        ctx:            ReconContext,
        engine_runner:  Optional[callable] = None,
    ) -> ReconContext:
        """
        Execute the full guided recon workflow.

        Args:
            ctx:           Recon context (target, strategy, options)
            engine_runner: Optional callable(phase, tools, ctx) → dict of findings.
                           If None, runs in planning/explanation-only mode.

        Returns:
            Updated ReconContext with all accumulated findings.
        """
        # Build strategy config
        strategy_cfg = self._strategy.build(ctx.strategy, ctx)

        # Show strategy overview
        self._explainer.show_strategy_summary(strategy_cfg, ctx)

        # Build initial workflow plan
        plan = self._planner.plan(strategy_cfg, ctx)

        # Confirm start
        if ctx.automation_level < 2:
            if not self._confirm("Begin guided recon?"):
                self._console.print("[dim]Session cancelled.[/dim]")
                return ctx

        # Execute each step
        for step in plan.enabled_steps:
            if step.phase == Phase.COMPLETE:
                break

            ctx.current_phase = step.phase

            # Show decision explanation
            if step.decision:
                self._explainer.explain_decision(step.decision, ctx)

            # Announce phase
            self._explainer.explain_phase_start(step.phase, ctx)

            # Confirm if needed
            if step.config.ask_confirm and ctx.automation_level < 2:
                if not self._confirm(f"Execute {step.action}?"):
                    self._explainer.explain_skip(step.phase, "User declined")
                    ctx.skipped_phases.append(step.phase)
                    step.enabled = False
                    continue

            # Execute
            t0       = time.perf_counter()
            findings = self._execute_step(step, ctx, engine_runner)
            duration = time.perf_counter() - t0

            # Update context
            self._apply_findings(ctx, step.phase, findings)

            # Record the decision in context history
            if step.decision:
                from .context_analyzer import DecisionRecord
                ctx.record_decision(DecisionRecord(
                    phase      = step.phase,
                    decision   = step.decision.action,
                    reasoning  = step.decision.reason,
                    confidence = step.decision.confidence,
                    alternatives = step.decision.alternatives,
                ))

            # Record step
            ctx.record_step(ExecutedStep(
                phase          = step.phase,
                action         = step.action,
                tool           = step.tools[0] if step.tools else "",
                result_summary = self._summarise_findings(findings),
                findings_count = sum(
                    len(v) if isinstance(v, list) else 1
                    for v in findings.values() if v
                ),
                duration_s     = round(duration, 2),
            ))

            # Phase end summary
            key_findings = self._key_findings(findings, step.phase)
            self._explainer.explain_phase_end(
                step.phase,
                findings_count = ctx.total_findings(),
                duration_s     = duration,
                key_findings   = key_findings,
            )

            # Next-step prediction
            report = self._predictor.predict(ctx, step.phase)
            self._show_next_step_report(report, ctx)

            # Adapt plan based on predictions
            plan = self._planner.adapt_plan(plan, report, ctx)

            # Store methodology notes
            if step.config.explanation:
                ctx.add_methodology_note(step.config.explanation)

            # Mark intelligence done
            if step.phase == Phase.INTELLIGENCE:
                ctx.intel_done = True

        # Final summary
        self._explainer.show_session_summary(ctx)
        return ctx

    # ── Execution ─────────────────────────────────────────────────────────────

    def _execute_step(
        self,
        step:           WorkflowStep,
        ctx:            ReconContext,
        engine_runner:  Optional[callable],
    ) -> dict:
        """Execute a workflow step and return findings dict."""
        if self._dry_run or engine_runner is None:
            return self._simulate_step(step, ctx)

        try:
            return engine_runner(
                phase   = step.phase,
                tools   = step.tools,
                config  = step.config,
                ctx     = ctx,
            )
        except Exception as exc:
            logger.warning(f"Step {step.phase.value} failed: {exc}")
            return {}

    def _simulate_step(self, step: WorkflowStep, ctx: ReconContext) -> dict:
        """
        Planning/demo simulation — returns synthetic findings based on
        the phase type for dry-run and testing purposes.
        """
        simulations = {
            Phase.PASSIVE:        {"subdomains": [f"dev.{ctx.target}", f"api.{ctx.target}", f"staging.{ctx.target}"]},
            Phase.DNS:            {"live_subdomains": [f"api.{ctx.target}"], "ip_addresses": ["1.2.3.4"]},
            Phase.PORT_SCAN:      {"ports": [80, 443, 22, 8080]},
            Phase.SERVICE_DETECT: {"technologies": ["nginx", "jenkins"], "services": {80: "http", 443: "https", 8080: "jenkins"}},
            Phase.WEB_RECON:      {"endpoints": ["/api/v1/users", "/admin", "/.git"]},
            Phase.VULN_ANALYSIS:  {"cves": ["CVE-2024-23897"], "findings": ["Jenkins arbitrary file read"]},
            Phase.INTELLIGENCE:   {"risk_score": 78.5, "grade": "D", "recommendations": 8},
        }
        with Progress(SpinnerColumn(), TextColumn(f"[cyan]Simulating {step.phase.display}…"),
                      TimeElapsedColumn(), console=self._console, transient=True) as prog:
            prog.add_task("", total=None)
            time.sleep(0.5)   # brief pause for UX
        return simulations.get(step.phase, {})

    # ── Context update ────────────────────────────────────────────────────────

    def _apply_findings(self, ctx: ReconContext, phase: Phase, findings: dict) -> None:
        """Map findings dict keys into the ReconContext."""
        ctx.update_from_findings(
            ips          = findings.get("ip_addresses") or findings.get("ips"),
            subdomains   = findings.get("subdomains") or findings.get("live_subdomains"),
            ports        = findings.get("ports") or findings.get("open_ports"),
            services     = findings.get("services"),
            tech         = findings.get("technologies") or findings.get("tech"),
            endpoints    = findings.get("endpoints") or findings.get("web_endpoints"),
            emails       = findings.get("emails"),
            cves         = findings.get("cves"),
            sensitive    = findings.get("sensitive_files") or findings.get("sensitive"),
            admin_panels = findings.get("admin_panels"),
            takeovers    = findings.get("takeover_candidates") or findings.get("takeovers"),
        )

    def _summarise_findings(self, findings: dict) -> str:
        parts = []
        for k, v in findings.items():
            if isinstance(v, list) and v:
                parts.append(f"{len(v)} {k}")
            elif isinstance(v, dict) and v:
                parts.append(f"{len(v)} {k}")
            elif v:
                parts.append(f"{k}: {v}")
        return "; ".join(parts[:4]) or "no findings"

    def _key_findings(self, findings: dict, phase: Phase) -> list[str]:
        """Extract 3–4 noteworthy finding strings for the phase summary."""
        results: list[str] = []
        if "subdomains" in findings:
            results.extend(findings["subdomains"][:3])
        if "ports" in findings:
            results.append(f"Open ports: {sorted(findings['ports'])[:6]}")
        if "technologies" in findings:
            results.append(f"Technologies: {', '.join(findings['technologies'][:4])}")
        if "cves" in findings:
            results.extend(findings["cves"][:2])
        if "endpoints" in findings:
            results.extend(findings["endpoints"][:2])
        return results[:4]

    # ── Next-step report display ──────────────────────────────────────────────

    def _show_next_step_report(self, report: NextStepReport, ctx: ReconContext) -> None:
        """Display next-step recommendations after a phase."""
        if not report.steps and not report.notes:
            return

        self._console.print()
        if report.critical_path:
            urgency_style = {
                "IMMEDIATE": "bold red",
                "HIGH":      "red",
                "NORMAL":    "yellow",
                "OPTIONAL":  "dim",
            }.get(report.critical_path.urgency, "white")

            self._console.print(
                f"  [cyan]→ Next:[/cyan] "
                f"[{urgency_style}]{report.critical_path.action}[/{urgency_style}]"
            )
            self._console.print(f"    [dim]{report.critical_path.reason}[/dim]")

        for note in report.notes[:2]:
            icon = "⚠" if "CRITICAL" in note or "IMMEDIATE" in note else "💡"
            style = "yellow" if icon == "⚠" else "dim"
            self._console.print(f"  [{style}]{icon} {note}[/{style}]")

    # ── User interaction ──────────────────────────────────────────────────────

    def _confirm(self, prompt: str) -> bool:
        """Prompt the user for confirmation."""
        try:
            answer = self._console.input(f"\n  [cyan]{prompt}[/cyan] [dim][Y/n][/dim] ").strip().lower()
            return answer in ("", "y", "yes")
        except (KeyboardInterrupt, EOFError):
            return False
