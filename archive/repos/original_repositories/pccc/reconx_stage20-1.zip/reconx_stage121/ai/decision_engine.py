"""
ReconX — Stage 10: Decision Engine.

Selects the optimal next action based on accumulated reconnaissance context.
Uses rule-based inference over the ReconContext to produce a Decision object
with full reasoning, confidence, and alternatives.

This is the "brain" that drives adaptive scan path selection.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Optional

from .context_analyzer import ReconContext, Phase, Strategy, DecisionRecord

logger = logging.getLogger("reconx.ai.decision_engine")


@dataclass
class Decision:
    """
    A single AI decision produced by the DecisionEngine.

    Contains the recommended action, full reasoning chain,
    confidence, and alternative options considered.
    """
    phase:          Phase
    action:         str             # brief action label
    tool:           str             # primary tool to run
    tools:          list[str]       # all tools for this action
    reason:         str             # primary reasoning
    reasoning_chain: list[str]      # ordered list of reasoning steps
    confidence:     float           # 0–1
    priority:       int             # 1 = highest
    methodology_note: str           # educational explanation
    alternatives:   list[str]       = field(default_factory=list)
    skip_reason:    str             = ""
    should_skip:    bool            = False
    tags:           list[str]       = field(default_factory=list)


# ── Decision rules (ordered by priority, first match wins) ───────────────────

class DecisionEngine:
    """
    Rule-based AI decision engine for guided recon.

    Evaluates the current ReconContext against a prioritised rule set
    and returns the best next Decision to execute.

    Rules are ordered by priority — the first applicable rule fires.
    """

    def next_decision(self, ctx: ReconContext) -> Optional[Decision]:
        """
        Compute the best next action based on current context.

        Returns None when the session is complete.
        """
        # Run all rule methods in priority order
        rules = [
            self._rule_start_passive,
            self._rule_dns_after_passive,
            self._rule_port_scan_after_dns,
            self._rule_service_after_ports,
            self._rule_web_after_service,
            self._rule_vuln_after_web,
            self._rule_vuln_after_service,        # infra path (no web)
            self._rule_intelligence_after_vuln,
            self._rule_intelligence_after_service, # fast path
            self._rule_opportunistic_cicd,
            self._rule_opportunistic_database,
            self._rule_opportunistic_takeover,
            self._rule_complete,
        ]

        for rule in rules:
            decision = rule(ctx)
            if decision is not None:
                ctx.record_decision(DecisionRecord(
                    phase      = decision.phase,
                    decision   = decision.action,
                    reasoning  = decision.reason,
                    confidence = decision.confidence,
                    alternatives = decision.alternatives,
                ))
                logger.debug(f"Decision: {decision.action} (conf={decision.confidence:.0%})")
                return decision

        return None

    def decisions_for_phase(
        self, ctx: ReconContext, phase: Phase
    ) -> list[Decision]:
        """Return all applicable decisions for a specific phase (for planning)."""
        decisions: list[Decision] = []
        phase_rules = {
            Phase.PASSIVE:        [self._rule_start_passive],
            Phase.DNS:            [self._rule_dns_after_passive],
            Phase.PORT_SCAN:      [self._rule_port_scan_after_dns],
            Phase.SERVICE_DETECT: [self._rule_service_after_ports],
            Phase.WEB_RECON:      [self._rule_web_after_service],
            Phase.VULN_ANALYSIS:  [self._rule_vuln_after_web, self._rule_vuln_after_service],
            Phase.INTELLIGENCE:   [self._rule_intelligence_after_vuln, self._rule_intelligence_after_service],
        }
        for rule in phase_rules.get(phase, []):
            d = rule(ctx)
            if d:
                decisions.append(d)
        return decisions

    # ── Decision rules ────────────────────────────────────────────────────────

    def _rule_start_passive(self, ctx: ReconContext) -> Optional[Decision]:
        """Begin passive enumeration — always the first step."""
        if ctx.has_executed(Phase.PASSIVE):
            return None

        tools = self._passive_tools(ctx.strategy)

        return Decision(
            phase   = Phase.PASSIVE,
            action  = "Passive Subdomain Enumeration",
            tool    = tools[0],
            tools   = tools,
            reason  = "Passive reconnaissance is always the starting point — zero direct footprint on the target.",
            reasoning_chain = [
                f"Target: {ctx.target}",
                "No previous recon data in context",
                "Passive sources (CT logs, DNS records, OSINT) reveal assets without alerting the target",
                f"Strategy '{ctx.strategy.display}' begins with passive enumeration",
            ],
            confidence       = 0.98,
            priority         = 1,
            methodology_note = (
                "Certificate Transparency logs (crt.sh) store every TLS certificate ever issued. "
                "Combined with passive DNS databases, they reveal subdomains that were never meant "
                "to be public. This data collection generates zero network traffic to the target."
            ),
            alternatives = ["Start with port scan if target IPs are already known"],
            tags         = ["passive", "subdomain", "osint"],
        )

    def _rule_dns_after_passive(self, ctx: ReconContext) -> Optional[Decision]:
        """Validate and expand subdomains after passive enumeration."""
        if not ctx.has_executed(Phase.PASSIVE):
            return None
        if ctx.has_executed(Phase.DNS):
            return None

        if not ctx.subdomains:
            return Decision(
                phase   = Phase.DNS,
                action  = "DNS Bruteforce (no passive subdomains found)",
                tool    = "puredns",
                tools   = ["puredns", "shuffledns"],
                reason  = "Passive enumeration found no subdomains — DNS bruteforce needed.",
                reasoning_chain = [
                    "Passive enumeration returned 0 subdomains",
                    "Target may use internal naming not in certificate logs",
                    "DNS bruteforce with common wordlists is the next logical step",
                ],
                confidence       = 0.85,
                priority         = 2,
                methodology_note = (
                    "When passive sources yield nothing, DNS bruteforce applies wordlists of common "
                    "subdomain prefixes (dev, api, staging, admin) against the target domain. "
                    "Wildcard filtering is essential to avoid false positives."
                ),
                alternatives     = ["Skip DNS if target has no subdomain attack surface"],
                tags             = ["dns", "bruteforce"],
            )

        chain = [
            f"{len(ctx.subdomains)} subdomains discovered passively",
            "DNS validation confirms which subdomains are live (not all passive results are valid)",
        ]

        if len(ctx.subdomains) > 100:
            chain.append(f"Large subdomain set ({len(ctx.subdomains)}) — deep DNS validation recommended")
            tools = ["dnsx", "massdns", "puredns"]
            note  = (
                "With 100+ subdomains, systematic DNS validation is essential. MassDNS resolves "
                "thousands per second using public resolvers. Live hosts are then passed to "
                "service detection. Wildcard responses must be filtered."
            )
        else:
            tools = ["dnsx"]
            note  = (
                "dnsx validates DNS resolution for each discovered subdomain. Results include "
                "A records (IPv4), CNAME chains, and wildcard detection — essential before "
                "running any active scanning."
            )

        return Decision(
            phase   = Phase.DNS,
            action  = f"DNS Validation ({len(ctx.subdomains)} subdomains)",
            tool    = tools[0],
            tools   = tools,
            reason  = f"Validate {len(ctx.subdomains)} passively discovered subdomains.",
            reasoning_chain = chain,
            confidence       = 0.95,
            priority         = 2,
            methodology_note = note,
            alternatives     = ["Skip DNS validation and proceed to port scan with known IPs"],
            tags             = ["dns", "validation"],
        )

    def _rule_port_scan_after_dns(self, ctx: ReconContext) -> Optional[Decision]:
        """Run port scan after DNS validation."""
        if not ctx.has_executed(Phase.DNS):
            return None
        if ctx.has_executed(Phase.PORT_SCAN):
            return None

        tools   = self._port_tools(ctx.strategy)
        targets = len(ctx.ip_addresses) or len(ctx.subdomains)

        chain = [
            f"DNS validation complete — {len(ctx.subdomains)} live subdomains confirmed",
            f"IP addresses identified: {len(ctx.ip_addresses)}",
        ]

        if ctx.is_cdn_target:
            chain.append("⚠ CDN detected — port scan will reflect CDN infrastructure, not origin IPs")

        if ctx.strategy == Strategy.STEALTH:
            chain.append("Stealth strategy — using slow SYN scan to minimise detection risk")
            note = (
                "Stealth SYN scanning (-sS) completes the TCP handshake only to confirm port state, "
                "then sends RST. This is faster and less likely to appear in application logs than "
                "a full connect scan (-sT). Rate limiting (-T2) further reduces signature detection."
            )
        else:
            note = (
                "Port scanning identifies all listening services — the foundation of attack surface "
                "mapping. naabu provides speed for initial discovery; nmap provides accuracy and "
                "version detection on confirmed ports. Scanning all 65535 ports ensures nothing is hidden."
            )

        return Decision(
            phase   = Phase.PORT_SCAN,
            action  = f"Port Scan ({targets} hosts)",
            tool    = tools[0],
            tools   = tools,
            reason  = f"Map exposed services across {targets} discovered host(s).",
            reasoning_chain = chain,
            confidence       = 0.93,
            priority         = 3,
            methodology_note = note,
            alternatives     = ["Use Shodan/Censys for passive port data if active scanning is restricted"],
            tags             = ["ports", "scanning", "services"],
        )

    def _rule_service_after_ports(self, ctx: ReconContext) -> Optional[Decision]:
        """Service detection after port scan."""
        if not ctx.has_executed(Phase.PORT_SCAN):
            return None
        if ctx.has_executed(Phase.SERVICE_DETECT):
            return None
        if not ctx.open_ports:
            return Decision(
                phase   = Phase.SERVICE_DETECT,
                action  = "Skip Service Detection (no open ports)",
                tool    = "",
                tools   = [],
                reason  = "Port scan found no open ports — service detection skipped.",
                reasoning_chain = ["Port scan completed", "0 open ports found",
                                   "Target may be firewalled, offline, or using non-standard ports"],
                confidence    = 0.90,
                priority      = 4,
                methodology_note = "No open ports typically indicates host-based firewall or incorrect target IP.",
                should_skip   = True,
                skip_reason   = "No open ports found",
                tags          = ["skip"],
            )

        interesting_ports = [p for p in ctx.open_ports if p in
                              {80, 443, 8080, 8443, 22, 21, 25, 445, 3389, 6379, 9200, 27017}]
        chain = [
            f"{len(ctx.open_ports)} open port(s) discovered",
            f"Interesting ports: {sorted(interesting_ports)[:8]}",
            "Service fingerprinting maps ports to specific software versions",
            "Version information enables precise CVE matching",
        ]

        return Decision(
            phase   = Phase.SERVICE_DETECT,
            action  = f"Service Detection ({len(ctx.open_ports)} ports)",
            tool    = "nmap",
            tools   = ["nmap", "httpx", "whatweb"],
            reason  = f"Fingerprint {len(ctx.open_ports)} open ports to identify services and versions.",
            reasoning_chain = chain,
            confidence       = 0.95,
            priority         = 4,
            methodology_note = (
                "nmap service scripts (-sV) send protocol-specific probes to extract exact version "
                "strings. This enables CPE matching against CVE databases. WhatWeb and httpx add "
                "HTTP-layer fingerprinting (server headers, cookies, error messages, JavaScript "
                "references) that nmap cannot extract."
            ),
            alternatives     = ["Use banner grabbing only for speed"],
            tags             = ["service", "fingerprint", "version"],
        )

    def _rule_web_after_service(self, ctx: ReconContext) -> Optional[Decision]:
        """Web recon after service detection, if web ports exist."""
        if not ctx.has_executed(Phase.SERVICE_DETECT):
            return None
        if ctx.has_executed(Phase.WEB_RECON):
            return None
        if not ctx.has_web:
            return None

        tools  = self._web_tools(ctx.strategy)
        chain  = [
            f"Web ports detected: {[p for p in ctx.open_ports if p in {80, 443, 8080, 8443}]}",
            "Web technologies identified — targeted web recon now applicable",
        ]

        if ctx.technologies:
            chain.append(f"Technologies: {', '.join(ctx.technologies[:5])}")
            if "wordpress" in ctx.technologies:
                chain.append("WordPress detected → WP-specific scanning recommended")
            if "javascript" in " ".join(ctx.technologies).lower() or "node" in ctx.technologies:
                chain.append("JS-heavy stack → JS file analysis for API endpoints")

        return Decision(
            phase   = Phase.WEB_RECON,
            action  = "Web Reconnaissance",
            tool    = tools[0],
            tools   = tools,
            reason  = f"Web services detected on {len([p for p in ctx.open_ports if p in {80,443,8080,8443}])} port(s) — map full web attack surface.",
            reasoning_chain = chain,
            confidence       = 0.92,
            priority         = 5,
            methodology_note = (
                "Web recon discovers endpoints that don't appear in DNS or port scans. "
                "Crawlers follow links; fuzzers probe for hidden paths; Wayback Machine "
                "reveals historical endpoints still accessible. JavaScript files often "
                "contain hardcoded API endpoints, credentials, and internal URLs."
            ),
            alternatives     = ["Skip and go straight to vulnerability scanning"],
            tags             = ["web", "crawl", "endpoints"],
        )

    def _rule_vuln_after_web(self, ctx: ReconContext) -> Optional[Decision]:
        """Vulnerability analysis after web recon."""
        if not ctx.has_executed(Phase.WEB_RECON):
            return None
        if ctx.has_executed(Phase.VULN_ANALYSIS):
            return None

        return self._make_vuln_decision(ctx)

    def _rule_vuln_after_service(self, ctx: ReconContext) -> Optional[Decision]:
        """Vulnerability analysis after service detect (infra path — no web recon needed)."""
        if not ctx.has_executed(Phase.SERVICE_DETECT):
            return None
        if ctx.has_executed(Phase.VULN_ANALYSIS):
            return None
        if ctx.has_web and not ctx.has_executed(Phase.WEB_RECON):
            return None   # web path takes priority

        return self._make_vuln_decision(ctx)

    def _rule_intelligence_after_vuln(self, ctx: ReconContext) -> Optional[Decision]:
        """Intelligence correlation after vulnerability analysis."""
        if not ctx.has_executed(Phase.VULN_ANALYSIS):
            return None
        if ctx.intel_done:
            return None
        return self._make_intel_decision(ctx)

    def _rule_intelligence_after_service(self, ctx: ReconContext) -> Optional[Decision]:
        """Fast path: intelligence after service detect when vuln scan skipped."""
        if not ctx.has_executed(Phase.SERVICE_DETECT):
            return None
        if ctx.intel_done:
            return None
        if ctx.strategy in (Strategy.FAST, Strategy.STEALTH) and not ctx.has_executed(Phase.VULN_ANALYSIS):
            return self._make_intel_decision(ctx)
        return None

    # ── Opportunistic rules ───────────────────────────────────────────────────

    def _rule_opportunistic_cicd(self, ctx: ReconContext) -> Optional[Decision]:
        """Detect Jenkins/CI-CD exposure and recommend targeted action."""
        if "jenkins" not in ctx.technologies and 8080 not in ctx.open_ports:
            return None
        if ctx.has_executed(Phase.VULN_ANALYSIS):
            return None   # already covered by vuln phase
        if ctx.has_executed(Phase.SERVICE_DETECT):
            return Decision(
                phase   = Phase.VULN_ANALYSIS,
                action  = "Targeted CI/CD Vulnerability Scan",
                tool    = "nuclei",
                tools   = ["nuclei"],
                reason  = "Jenkins/CI-CD system detected — immediate targeted vulnerability scan recommended.",
                reasoning_chain = [
                    "Jenkins or CI/CD platform detected in technology stack or on port 8080",
                    "CI/CD systems are high-value targets: contain secrets, pipeline configs, deploy keys",
                    "Known critical CVEs: CVE-2024-23897 (arbitrary file read), CVE-2018-1000861 (RCE)",
                    "Targeted nuclei templates (jenkins, ci) provide fast, high-confidence results",
                ],
                confidence       = 0.90,
                priority         = 2,
                methodology_note = (
                    "Jenkins is one of the most commonly exploited assets in corporate networks. "
                    "Nuclei's jenkins-specific templates check for: unauthenticated access, "
                    "Groovy script console exposure, CVE-2024-23897 (file read via CLI endpoint), "
                    "and default credentials. A compromised Jenkins system = supply chain access."
                ),
                alternatives     = ["Manual Jenkins fingerprinting via /api/json endpoint"],
                tags             = ["cicd", "jenkins", "opportunistic"],
            )
        return None

    def _rule_opportunistic_database(self, ctx: ReconContext) -> Optional[Decision]:
        """Detect exposed databases and recommend verification."""
        db_ports = {p for p in ctx.open_ports if p in {6379, 9200, 27017, 5432, 3306, 1433}}
        if not db_ports:
            return None
        if ctx.has_executed(Phase.VULN_ANALYSIS):
            return None
        if ctx.has_executed(Phase.SERVICE_DETECT):
            db_names = {6379: "Redis", 9200: "Elasticsearch", 27017: "MongoDB",
                        5432: "PostgreSQL", 3306: "MySQL", 1433: "MSSQL"}
            found = [db_names.get(p, f"DB:{p}") for p in db_ports]
            return Decision(
                phase   = Phase.VULN_ANALYSIS,
                action  = f"Database Exposure Verification ({', '.join(found)})",
                tool    = "nuclei",
                tools   = ["nuclei"],
                reason  = f"Database service(s) exposed: {', '.join(found)}. Verify authentication status.",
                reasoning_chain = [
                    f"Database ports open: {sorted(db_ports)}",
                    "Databases exposed to internet frequently lack authentication",
                    "Unauthenticated database = complete data exfiltration",
                    "Nuclei default-login and exposure templates provide rapid verification",
                ],
                confidence       = 0.92,
                priority         = 1,
                methodology_note = (
                    "Redis, Elasticsearch, and MongoDB are frequently deployed without authentication "
                    "in cloud environments due to misconfigured security groups. A single curl command "
                    "can dump an entire database. Verification should happen before any other testing."
                ),
                alternatives     = ["Manual connection test: redis-cli -h <host> PING"],
                tags             = ["database", "exposure", "opportunistic"],
            )
        return None

    def _rule_opportunistic_takeover(self, ctx: ReconContext) -> Optional[Decision]:
        """Flag takeover candidates for immediate action."""
        if not ctx.takeover_candidates:
            return None
        if ctx.has_executed(Phase.INTELLIGENCE):
            return None
        return Decision(
            phase   = Phase.INTELLIGENCE,
            action  = "Subdomain Takeover Verification",
            tool    = "subjack",
            tools   = ["subjack", "subzy"],
            reason  = f"{len(ctx.takeover_candidates)} subdomain takeover candidate(s) detected.",
            reasoning_chain = [
                f"Takeover candidates: {ctx.takeover_candidates[:3]}",
                "Dangling CNAME records point to unclaimed third-party services",
                "Claiming the subdomain enables phishing, cookie theft, and CSP bypass",
                "Immediate verification and DNS record cleanup required",
            ],
            confidence       = 0.95,
            priority         = 1,
            methodology_note = (
                "Subdomain takeover occurs when a CNAME points to an unclaimed resource "
                "(S3 bucket, GitHub Pages, Heroku app). An attacker claims the service and "
                "controls the subdomain — enabling credential phishing on a trusted domain."
            ),
            alternatives     = ["Manual: dig CNAME legacy.example.com → check if service is claimed"],
            tags             = ["takeover", "dns", "opportunistic"],
        )

    def _rule_complete(self, ctx: ReconContext) -> Optional[Decision]:
        """All phases complete — signal session end."""
        if ctx.intel_done:
            return Decision(
                phase        = Phase.COMPLETE,
                action       = "Session Complete",
                tool         = "",
                tools        = [],
                reason       = "All planned reconnaissance phases have been executed.",
                reasoning_chain = [
                    f"Total findings: {ctx.total_findings()}",
                    f"Executed steps: {len(ctx.executed_steps)}",
                    f"Decisions made: {len(ctx.decision_history)}",
                ],
                confidence       = 1.0,
                priority         = 99,
                methodology_note = "Recon complete. Review the intelligence report for prioritised findings.",
                tags             = ["complete"],
            )
        return None

    # ── Shared decision factories ─────────────────────────────────────────────

    def _make_vuln_decision(self, ctx: ReconContext) -> Decision:
        tools = self._vuln_tools(ctx.strategy)
        chain = [f"Service detection complete — {len(ctx.open_ports)} ports, {len(ctx.technologies)} technologies"]

        severity_filter = "critical,high,medium"
        if ctx.strategy == Strategy.FAST:
            severity_filter = "critical,high"
            chain.append("Fast strategy — critical+high severity only")

        if ctx.technologies:
            tech_str = ", ".join(ctx.technologies[:6])
            chain.append(f"Technology-aware template selection: {tech_str}")

        if ctx.cves:
            chain.append(f"Pre-existing CVE context: {len(ctx.cves)} CVEs — validate with templates")

        return Decision(
            phase   = Phase.VULN_ANALYSIS,
            action  = f"Vulnerability Analysis (severity: {severity_filter})",
            tool    = tools[0],
            tools   = tools,
            reason  = "Run template-based vulnerability scanning against identified services.",
            reasoning_chain  = chain,
            confidence       = 0.90,
            priority         = 6,
            methodology_note = (
                "Nuclei runs YAML-defined templates that send targeted requests and match "
                "specific vulnerability signatures. Unlike generic scanners, templates are "
                "precise — a CVE template for CVE-2021-44228 sends the exact Log4Shell probe "
                "and confirms exploitation via DNS callback. False positives are rare when "
                "technology-aware template selection is applied."
            ),
            alternatives     = ["Manual CVE verification with PoC payloads"],
            tags             = ["vulnerability", "cve", "nuclei"],
        )

    def _make_intel_decision(self, ctx: ReconContext) -> Decision:
        return Decision(
            phase   = Phase.INTELLIGENCE,
            action  = "Intelligence Correlation & Risk Assessment",
            tool    = "intelligence_pipeline",
            tools   = ["intelligence_pipeline"],
            reason  = "Correlate all findings into a prioritised attack surface intelligence report.",
            reasoning_chain = [
                f"Total findings accumulated: {ctx.total_findings()}",
                f"Subdomains: {len(ctx.subdomains)}, Ports: {len(ctx.open_ports)}, "
                f"CVEs: {len(ctx.cves)}, Sensitive: {len(ctx.sensitive_files)}",
                "Cross-source correlation amplifies individual findings into attack chains",
                "Risk scoring produces a prioritised remediation queue",
            ],
            confidence       = 0.98,
            priority         = 7,
            methodology_note = (
                "Intelligence correlation is where individual low-severity findings become "
                "critical attack chains. An exposed Jenkins (MEDIUM) + default credentials (MEDIUM) "
                "= supply chain compromise (CRITICAL). The attack graph reveals paths an attacker "
                "would follow — giving defenders a clear, prioritised remediation roadmap."
            ),
            alternatives     = ["Manual correlation in a spreadsheet (not recommended)"],
            tags             = ["intelligence", "correlation", "final"],
        )

    # ── Tool selectors ────────────────────────────────────────────────────────

    def _passive_tools(self, strategy: Strategy) -> list[str]:
        m = {
            Strategy.FAST:           ["subfinder", "crtsh"],
            Strategy.BALANCED:       ["subfinder", "amass", "crtsh", "assetfinder"],
            Strategy.DEEP:           ["subfinder", "amass", "findomain", "crtsh", "assetfinder", "chaos"],
            Strategy.STEALTH:        ["crtsh", "waybackurls"],
            Strategy.WEB:            ["subfinder", "crtsh", "waybackurls"],
            Strategy.INFRASTRUCTURE: ["subfinder", "crtsh"],
            Strategy.VULNERABILITY:  ["subfinder"],
        }
        return m.get(strategy, ["subfinder", "crtsh"])

    def _port_tools(self, strategy: Strategy) -> list[str]:
        m = {
            Strategy.FAST:           ["naabu"],
            Strategy.BALANCED:       ["naabu", "nmap"],
            Strategy.DEEP:           ["masscan", "nmap", "naabu"],
            Strategy.STEALTH:        ["nmap"],
            Strategy.INFRASTRUCTURE: ["masscan", "nmap", "naabu"],
            Strategy.WEB:            ["naabu"],
            Strategy.VULNERABILITY:  ["nmap"],
        }
        return m.get(strategy, ["naabu", "nmap"])

    def _web_tools(self, strategy: Strategy) -> list[str]:
        m = {
            Strategy.FAST:           ["katana", "gau"],
            Strategy.BALANCED:       ["katana", "hakrawler", "gau", "ffuf"],
            Strategy.DEEP:           ["katana", "hakrawler", "gau", "ffuf", "dirsearch", "gobuster"],
            Strategy.STEALTH:        ["gau", "waybackurls"],
            Strategy.WEB:            ["katana", "hakrawler", "gau", "ffuf", "dirsearch"],
            Strategy.INFRASTRUCTURE: ["katana"],
            Strategy.VULNERABILITY:  ["katana"],
        }
        return m.get(strategy, ["katana", "gau"])

    def _vuln_tools(self, strategy: Strategy) -> list[str]:
        m = {
            Strategy.FAST:           ["nuclei"],
            Strategy.BALANCED:       ["nuclei", "nikto"],
            Strategy.DEEP:           ["nuclei", "nikto"],
            Strategy.STEALTH:        ["nuclei"],
            Strategy.WEB:            ["nuclei", "nikto"],
            Strategy.INFRASTRUCTURE: ["nuclei", "nikto"],
            Strategy.VULNERABILITY:  ["nuclei", "nikto"],
        }
        return m.get(strategy, ["nuclei", "nikto"])
