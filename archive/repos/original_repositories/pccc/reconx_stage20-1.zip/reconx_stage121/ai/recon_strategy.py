"""
ReconX — Stage 10: Recon Strategy Engine.

Defines strategy profiles and maps them to tool selections, batch sizes,
throttle settings, phase ordering, and depth parameters.

Each strategy produces a StrategyConfig consumed by the workflow planner
and adaptive orchestrator.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from .context_analyzer import Strategy, Phase, ReconContext


@dataclass
class PhaseConfig:
    """Configuration for a single recon phase within a strategy."""
    phase:          Phase
    tools:          list[str]           # ordered tool list for this phase
    max_threads:    int
    timeout_s:      int
    depth:          str                 # "shallow" | "standard" | "deep"
    enabled:        bool                = True
    ask_confirm:    bool                = False     # prompt before execution
    explanation:    str                 = ""        # why this phase matters


@dataclass
class StrategyConfig:
    """
    Complete configuration for a recon strategy.
    Produced by StrategyEngine.build() and consumed by WorkflowPlanner.
    """
    strategy:       Strategy
    phases:         list[PhaseConfig]
    passive_first:  bool                = True
    max_parallel:   int                 = 4
    rate_limit:     int                 = 150       # req/min for vuln tools
    noise_level:    str                 = "medium"  # low | medium | high
    description:    str                 = ""
    tags:           list[str]           = field(default_factory=list)


# ── Per-phase tool catalogs ───────────────────────────────────────────────────
# Tools ordered by recommended execution sequence within a phase

PASSIVE_TOOLS_ALL   = ["subfinder", "amass", "findomain", "assetfinder", "crtsh",
                        "chaos", "github_subdomains", "waybackurls"]
PASSIVE_TOOLS_FAST  = ["subfinder", "crtsh", "assetfinder"]
PASSIVE_TOOLS_STEALTH = ["crtsh", "waybackurls"]

DNS_TOOLS_ALL       = ["dnsx", "massdns", "puredns", "shuffledns"]
DNS_TOOLS_FAST      = ["dnsx"]

PORT_TOOLS_ALL      = ["nmap", "masscan", "naabu", "rustscan"]
PORT_TOOLS_FAST     = ["naabu"]
PORT_TOOLS_STEALTH  = ["nmap"]          # -sS stealth scan only

SERVICE_TOOLS_ALL   = ["nmap", "httpx", "whatweb"]
SERVICE_TOOLS_FAST  = ["httpx"]

WEB_TOOLS_ALL       = ["katana", "hakrawler", "gau", "ffuf", "dirsearch", "gobuster"]
WEB_TOOLS_FAST      = ["katana", "gau"]
WEB_TOOLS_STEALTH   = ["gau", "waybackurls"]

VULN_TOOLS_ALL      = ["nuclei", "nikto"]
VULN_TOOLS_FAST     = ["nuclei"]

INTEL_TOOLS         = ["intelligence_pipeline"]


class StrategyEngine:
    """
    Maps a Strategy enum to a full StrategyConfig.

    Usage:
        engine = StrategyEngine()
        config = engine.build(Strategy.DEEP, context=ctx)
        # config.phases → ordered list of PhaseConfig
    """

    def build(
        self,
        strategy: Strategy,
        context:  Optional[ReconContext] = None,
    ) -> StrategyConfig:
        """Build a StrategyConfig for the given strategy, optionally adapted to context."""
        builders = {
            Strategy.FAST:           self._fast,
            Strategy.BALANCED:       self._balanced,
            Strategy.DEEP:           self._deep,
            Strategy.STEALTH:        self._stealth,
            Strategy.WEB:            self._web,
            Strategy.INFRASTRUCTURE: self._infrastructure,
            Strategy.VULNERABILITY:  self._vulnerability,
        }
        builder  = builders.get(strategy, self._balanced)
        config   = builder()

        # Dynamic adaptation based on accumulated context
        if context:
            config = self._adapt(config, context)

        return config

    # ── Strategy builders ─────────────────────────────────────────────────────

    def _fast(self) -> StrategyConfig:
        return StrategyConfig(
            strategy    = Strategy.FAST,
            passive_first = True,
            max_parallel  = 6,
            rate_limit    = 200,
            noise_level   = "medium",
            description   = "Quick intelligence sweep — 5–15 min per target",
            tags          = ["quick", "initial", "triage"],
            phases = [
                PhaseConfig(
                    phase=Phase.PASSIVE, tools=PASSIVE_TOOLS_FAST,
                    max_threads=50, timeout_s=120, depth="shallow",
                    explanation="Passive enumeration discovers assets without touching the target.",
                ),
                PhaseConfig(
                    phase=Phase.DNS, tools=DNS_TOOLS_FAST,
                    max_threads=100, timeout_s=60, depth="shallow",
                    explanation="DNS validation confirms which subdomains are live.",
                ),
                PhaseConfig(
                    phase=Phase.PORT_SCAN, tools=PORT_TOOLS_FAST,
                    max_threads=500, timeout_s=120, depth="shallow",
                    explanation="Top-1000 port sweep identifies key exposed services.",
                ),
                PhaseConfig(
                    phase=Phase.SERVICE_DETECT, tools=SERVICE_TOOLS_FAST,
                    max_threads=50, timeout_s=60, depth="shallow",
                    explanation="HTTP probing identifies live web services and technologies.",
                ),
                PhaseConfig(
                    phase=Phase.INTELLIGENCE, tools=INTEL_TOOLS,
                    max_threads=1, timeout_s=30, depth="shallow",
                    explanation="Intelligence correlation links findings into prioritised risks.",
                ),
            ],
        )

    def _balanced(self) -> StrategyConfig:
        return StrategyConfig(
            strategy      = Strategy.BALANCED,
            passive_first = True,
            max_parallel  = 4,
            rate_limit    = 150,
            noise_level   = "medium",
            description   = "Standard methodology — comprehensive without being excessive",
            tags          = ["standard", "default", "complete"],
            phases = [
                PhaseConfig(
                    phase=Phase.PASSIVE, tools=PASSIVE_TOOLS_ALL[:5],
                    max_threads=50, timeout_s=300, depth="standard",
                    explanation="Multiple passive sources maximise subdomain coverage without alerting the target.",
                ),
                PhaseConfig(
                    phase=Phase.DNS, tools=DNS_TOOLS_ALL[:2],
                    max_threads=200, timeout_s=120, depth="standard",
                    explanation="DNS validation with bruteforce discovers subdomains not in passive sources.",
                ),
                PhaseConfig(
                    phase=Phase.PORT_SCAN, tools=["nmap", "naabu"],
                    max_threads=100, timeout_s=300, depth="standard",
                    explanation="Full 1–65535 service sweep on key hosts reveals the complete attack surface.",
                ),
                PhaseConfig(
                    phase=Phase.SERVICE_DETECT, tools=SERVICE_TOOLS_ALL,
                    max_threads=50, timeout_s=120, depth="standard",
                    explanation="Service fingerprinting identifies exact versions, enabling CVE matching.",
                ),
                PhaseConfig(
                    phase=Phase.WEB_RECON, tools=WEB_TOOLS_ALL[:4],
                    max_threads=20, timeout_s=300, depth="standard",
                    explanation="Web recon maps all endpoints, APIs, parameters, and JavaScript references.",
                ),
                PhaseConfig(
                    phase=Phase.VULN_ANALYSIS, tools=VULN_TOOLS_ALL,
                    max_threads=25, timeout_s=600, depth="standard",
                    explanation="Template-based scanning validates specific CVEs and misconfigurations.",
                ),
                PhaseConfig(
                    phase=Phase.INTELLIGENCE, tools=INTEL_TOOLS,
                    max_threads=1, timeout_s=60, depth="standard",
                    explanation="Cross-source correlation amplifies findings and maps attack paths.",
                ),
            ],
        )

    def _deep(self) -> StrategyConfig:
        return StrategyConfig(
            strategy      = Strategy.DEEP,
            passive_first = True,
            max_parallel  = 3,
            rate_limit    = 100,
            noise_level   = "high",
            description   = "Maximum coverage — aggressive surface mapping, long runtime",
            tags          = ["thorough", "aggressive", "full"],
            phases = [
                PhaseConfig(
                    phase=Phase.PASSIVE, tools=PASSIVE_TOOLS_ALL,
                    max_threads=100, timeout_s=600, depth="deep",
                    explanation="All passive sources including GitHub dorks and certificate transparency logs.",
                ),
                PhaseConfig(
                    phase=Phase.DNS, tools=DNS_TOOLS_ALL,
                    max_threads=500, timeout_s=300, depth="deep",
                    explanation="Deep DNS bruteforce with large wordlists uncovers internal asset naming patterns.",
                ),
                PhaseConfig(
                    phase=Phase.PORT_SCAN, tools=PORT_TOOLS_ALL,
                    max_threads=1000, timeout_s=600, depth="deep",
                    explanation="Full port range on all discovered hosts — nothing left unchecked.",
                ),
                PhaseConfig(
                    phase=Phase.SERVICE_DETECT, tools=SERVICE_TOOLS_ALL,
                    max_threads=100, timeout_s=300, depth="deep",
                    explanation="Aggressive service detection with version scripts and OS fingerprinting.",
                ),
                PhaseConfig(
                    phase=Phase.WEB_RECON, tools=WEB_TOOLS_ALL,
                    max_threads=50, timeout_s=600, depth="deep",
                    explanation="Full crawl + forced browsing + parameter mining + JS analysis.",
                ),
                PhaseConfig(
                    phase=Phase.VULN_ANALYSIS, tools=VULN_TOOLS_ALL,
                    max_threads=15, timeout_s=900, depth="deep",
                    explanation="Full nuclei template library + comprehensive nikto scan.",
                ),
                PhaseConfig(
                    phase=Phase.INTELLIGENCE, tools=INTEL_TOOLS,
                    max_threads=1, timeout_s=120, depth="deep",
                    explanation="Full intelligence correlation with attack graph generation.",
                ),
            ],
        )

    def _stealth(self) -> StrategyConfig:
        return StrategyConfig(
            strategy      = Strategy.STEALTH,
            passive_first = True,
            max_parallel  = 2,
            rate_limit    = 30,
            noise_level   = "low",
            description   = "Passive-first, minimal active footprint — reduces IDS detection risk",
            tags          = ["passive", "quiet", "low-noise"],
            phases = [
                PhaseConfig(
                    phase=Phase.PASSIVE, tools=PASSIVE_TOOLS_STEALTH,
                    max_threads=10, timeout_s=300, depth="standard",
                    explanation="Certificate transparency and Wayback Machine leave zero direct footprint.",
                ),
                PhaseConfig(
                    phase=Phase.DNS, tools=["dnsx"],
                    max_threads=20, timeout_s=120, depth="shallow",
                    explanation="Slow DNS resolution minimises query rate spikes that may trigger alerts.",
                ),
                PhaseConfig(
                    phase=Phase.PORT_SCAN, tools=PORT_TOOLS_STEALTH,
                    max_threads=10, timeout_s=600, depth="shallow",
                    explanation="Slow SYN scan with randomised timing — avoids threshold-based detection.",
                ),
                PhaseConfig(
                    phase=Phase.SERVICE_DETECT, tools=["httpx"],
                    max_threads=5, timeout_s=120, depth="shallow",
                    explanation="Minimal HTTP probing — single request per host.",
                ),
                PhaseConfig(
                    phase=Phase.INTELLIGENCE, tools=INTEL_TOOLS,
                    max_threads=1, timeout_s=30, depth="shallow",
                    explanation="Passive intelligence correlation from accumulated findings only.",
                ),
            ],
        )

    def _web(self) -> StrategyConfig:
        return StrategyConfig(
            strategy      = Strategy.WEB,
            passive_first = True,
            max_parallel  = 4,
            rate_limit    = 120,
            noise_level   = "medium",
            description   = "Web application focus — crawling, fuzzing, APIs, JS analysis",
            tags          = ["web", "api", "javascript"],
            phases = [
                PhaseConfig(
                    phase=Phase.PASSIVE, tools=["subfinder", "crtsh", "waybackurls"],
                    max_threads=50, timeout_s=180, depth="standard",
                    explanation="Wayback Machine reveals historical endpoints often still accessible.",
                ),
                PhaseConfig(
                    phase=Phase.SERVICE_DETECT, tools=["httpx", "whatweb"],
                    max_threads=50, timeout_s=120, depth="standard",
                    explanation="Technology fingerprinting guides template and payload selection.",
                ),
                PhaseConfig(
                    phase=Phase.WEB_RECON, tools=WEB_TOOLS_ALL,
                    max_threads=30, timeout_s=600, depth="deep",
                    explanation="Full web recon — crawl every endpoint, mine JS, fuzz directories.",
                ),
                PhaseConfig(
                    phase=Phase.VULN_ANALYSIS, tools=VULN_TOOLS_ALL,
                    max_threads=20, timeout_s=600, depth="standard",
                    explanation="Web-focused nuclei templates (xss, sqli, ssrf, lfi, exposure).",
                ),
                PhaseConfig(
                    phase=Phase.INTELLIGENCE, tools=INTEL_TOOLS,
                    max_threads=1, timeout_s=60, depth="standard",
                    explanation="Correlate web findings into prioritised attack paths.",
                ),
            ],
        )

    def _infrastructure(self) -> StrategyConfig:
        return StrategyConfig(
            strategy      = Strategy.INFRASTRUCTURE,
            passive_first = False,
            max_parallel  = 4,
            rate_limit    = 150,
            noise_level   = "medium",
            description   = "Network and service focus — ports, banners, services, CVEs",
            tags          = ["network", "ports", "services"],
            phases = [
                PhaseConfig(
                    phase=Phase.PASSIVE, tools=PASSIVE_TOOLS_FAST,
                    max_threads=50, timeout_s=180, depth="shallow",
                    explanation="Basic passive discovery to map the IP space before active scanning.",
                ),
                PhaseConfig(
                    phase=Phase.PORT_SCAN, tools=PORT_TOOLS_ALL,
                    max_threads=1000, timeout_s=600, depth="deep",
                    explanation="Masscan for speed, then Nmap for accuracy on discovered ports.",
                ),
                PhaseConfig(
                    phase=Phase.SERVICE_DETECT, tools=SERVICE_TOOLS_ALL,
                    max_threads=100, timeout_s=300, depth="deep",
                    explanation="Service version detection enables precise CVE matching.",
                ),
                PhaseConfig(
                    phase=Phase.VULN_ANALYSIS, tools=VULN_TOOLS_ALL,
                    max_threads=20, timeout_s=600, depth="standard",
                    explanation="Network-focused nuclei templates + nikto for web services.",
                ),
                PhaseConfig(
                    phase=Phase.INTELLIGENCE, tools=INTEL_TOOLS,
                    max_threads=1, timeout_s=60, depth="standard",
                    explanation="Infrastructure-focused intelligence correlation.",
                ),
            ],
        )

    def _vulnerability(self) -> StrategyConfig:
        return StrategyConfig(
            strategy      = Strategy.VULNERABILITY,
            passive_first = False,
            max_parallel  = 2,
            rate_limit    = 80,
            noise_level   = "high",
            description   = "CVE-focused — assumes service discovery complete, goes straight to vulns",
            tags          = ["cve", "vulnerability", "exploitation"],
            phases = [
                PhaseConfig(
                    phase=Phase.SERVICE_DETECT, tools=SERVICE_TOOLS_ALL,
                    max_threads=50, timeout_s=120, depth="standard",
                    explanation="Quick service confirmation before running vulnerability templates.",
                ),
                PhaseConfig(
                    phase=Phase.VULN_ANALYSIS, tools=VULN_TOOLS_ALL,
                    max_threads=15, timeout_s=900, depth="deep",
                    explanation="Full nuclei template library with all severity levels.",
                ),
                PhaseConfig(
                    phase=Phase.INTELLIGENCE, tools=INTEL_TOOLS,
                    max_threads=1, timeout_s=60, depth="deep",
                    explanation="Vulnerability correlation, risk scoring, and remediation queue.",
                ),
            ],
        )

    # ── Dynamic adaptation ────────────────────────────────────────────────────

    def _adapt(self, config: StrategyConfig, ctx: ReconContext) -> StrategyConfig:
        """
        Adapt a StrategyConfig based on what the context already knows.

        - Skip phases if context has sufficient data
        - Boost web phase if web ports detected
        - Enable/disable tools based on CDN/cloud detection
        """
        adapted_phases: list[PhaseConfig] = []

        for phase in config.phases:
            pc = PhaseConfig(**phase.__dict__)  # shallow copy

            # If we already have subdomain data, skip passive phase
            if pc.phase == Phase.PASSIVE and len(ctx.subdomains) > 20:
                pc.enabled  = False
                pc.depth    = "skip"

            # If no web ports, skip web recon
            if pc.phase == Phase.WEB_RECON and not ctx.has_web:
                pc.enabled     = False
                pc.skip_reason = "No web ports detected"

            # If CDN, skip port scan (ports behind CDN don't reflect origin)
            if pc.phase == Phase.PORT_SCAN and ctx.is_cdn_target:
                pc.ask_confirm = True
                pc.explanation += " NOTE: CDN detected — port scan will show CDN IPs, not origin."

            # If many subdomains, bump DNS depth
            if pc.phase == Phase.DNS and len(ctx.subdomains) > 50:
                pc.depth = "deep"

            # If tech detected, tailor vuln tools
            if pc.phase == Phase.VULN_ANALYSIS and ctx.technologies:
                # Add tech-specific note to explanation
                pc.explanation += f" Tech-aware: {', '.join(ctx.technologies[:4])}."

            adapted_phases.append(pc)

        config.phases = adapted_phases
        return config
