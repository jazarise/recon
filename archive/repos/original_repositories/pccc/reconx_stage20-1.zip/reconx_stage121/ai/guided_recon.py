"""
ReconX — Stage 10: Guided Recon Engine.

The top-level entry point for guided recon mode.
Provides the full interactive CLI experience:
  - Strategy selection
  - Target analysis
  - Step-by-step guided execution
  - Adaptive workflow
  - Learning mode integration

Entry points:
  launch_guided_recon(target, console)     → full interactive session
  plan_recon(target, strategy, console)    → plan only (no execution)
  explain_methodology(topic, console)      → education only
"""
from __future__ import annotations

import logging
from typing import Optional

from rich.console import Console
from rich.panel import Panel
from rich.prompt import Prompt
from rich.table import Table
from rich import box

from .context_analyzer import ReconContext, Strategy, Phase
from .recon_strategy import StrategyEngine
from .decision_engine import DecisionEngine
from .explanation_engine import ExplanationEngine
from .workflow_planner import WorkflowPlanner, AdaptiveOrchestrator
from .next_step_predictor import NextStepPredictor
from .methodology_engine import MethodologyEngine

logger = logging.getLogger("reconx.ai.guided_recon")


def launch_guided_recon(
    target:           str,
    console:          Optional[Console] = None,
    strategy:         Optional[str]     = None,
    verbosity:        int               = 2,
    automation_level: int               = 1,
    dry_run:          bool              = False,
    engine_runner:    Optional[callable] = None,
) -> ReconContext:
    """
    Launch a full interactive guided recon session.

    Args:
        target:           Target domain or IP
        console:          Rich Console instance
        strategy:         Strategy name (or None to prompt interactively)
        verbosity:        1=quiet, 2=normal, 3=verbose
        automation_level: 0=ask all, 1=ask key steps, 2=fully automatic
        dry_run:          If True, simulates execution without running tools
        engine_runner:    Optional callable(phase, tools, config, ctx) → findings dict

    Returns:
        ReconContext with all accumulated findings and session history
    """
    console   = console or Console()
    explainer = ExplanationEngine(console=console, verbosity=verbosity)

    _print_guided_header(console)

    # Analyse target
    target_type, target_notes = _analyse_target(target)

    # Show target analysis
    console.print(Panel(
        f"[bold white]Target Analysis[/bold white]\n\n"
        f"[white]Target:[/white]   [yellow]{target}[/yellow]\n"
        f"[white]Type:[/white]     [cyan]{target_type}[/cyan]\n"
        f"[white]Notes:[/white]    [dim]{target_notes}[/dim]",
        border_style="cyan",
    ))
    console.print()

    # Strategy selection
    chosen_strategy = _select_strategy(strategy, target_type, console, automation_level)

    # Build context
    ctx = ReconContext(
        target           = target,
        strategy         = chosen_strategy,
        verbosity        = verbosity,
        automation_level = automation_level,
        allow_active     = True,
    )

    # Show initial decision
    decision_engine = DecisionEngine()
    first_decision  = decision_engine.next_decision(ctx)
    if first_decision:
        console.print()
        console.print(
            f"  [cyan]→[/cyan] [bold]Initial action:[/bold] {first_decision.action}\n"
            f"    [dim]{first_decision.reason}[/dim]"
        )

    console.print()

    # Run the orchestrator
    orchestrator = AdaptiveOrchestrator(
        console   = console,
        verbosity = verbosity,
        dry_run   = dry_run,
    )
    ctx = orchestrator.run(ctx, engine_runner=engine_runner)

    return ctx


def plan_recon(
    target:   str,
    strategy: str               = "balanced",
    console:  Optional[Console] = None,
) -> None:
    """
    Display a recon plan without executing it.
    Useful for previewing what a guided session would do.
    """
    console   = console or Console()
    strat_eng = StrategyEngine()
    ctx       = ReconContext(target=target, strategy=Strategy(strategy))
    cfg       = strat_eng.build(ctx.strategy, ctx)

    explainer = ExplanationEngine(console=console, verbosity=3)
    explainer.show_strategy_summary(cfg, ctx)

    # Show decisions for each phase
    dec_engine = DecisionEngine()
    console.print("[bold cyan]Phase Decision Preview:[/bold cyan]\n")

    for pc in cfg.phases:
        if not pc.enabled:
            console.print(f"  [dim]✗ {pc.phase.display} — skipped[/dim]")
            continue
        decisions = dec_engine.decisions_for_phase(ctx, pc.phase)
        d = decisions[0] if decisions else None
        if d:
            console.print(f"  [cyan]→[/cyan] [bold]{pc.phase.display}[/bold]")
            console.print(f"    {d.action}")
            console.print(f"    [dim]{d.reason}[/dim]")
            if pc.explanation:
                console.print(f"    [yellow dim]💡 {pc.explanation}[/yellow dim]")
        else:
            console.print(f"  [dim]→ {pc.phase.display}[/dim]")
        console.print()


def explain_methodology(
    topic:   str,
    console: Optional[Console] = None,
) -> None:
    """
    Display educational content about a recon methodology topic.
    Entry point for --explain CLI flag.
    """
    console  = console or Console()
    explainer = ExplanationEngine(console=console, verbosity=3)
    meth     = MethodologyEngine()

    # Try concept library first
    concept = meth.get_concept(topic)
    if concept:
        console.print(Panel(
            f"[bold]{concept.get('name', topic)}[/bold]\n\n"
            f"[white]{concept.get('summary', '')}[/white]\n\n"
            f"[dim]{concept.get('detail', '')}[/dim]",
            title="[yellow]📚 Methodology Concept[/yellow]",
            border_style="yellow",
        ))
        return

    # Fall back to explanation engine concept library
    explainer.explain_concept(topic)


def show_strategy_comparison(console: Optional[Console] = None) -> None:
    """Display a comparison table of all available strategies."""
    console = console or Console()

    table = Table(
        title="ReconX Strategy Profiles",
        box=box.SIMPLE_HEAD, border_style="cyan", show_lines=False,
    )
    table.add_column("Strategy",     style="bold cyan", width=18)
    table.add_column("Noise",        style="dim",       width=8)
    table.add_column("Runtime",      style="white",     width=12)
    table.add_column("Best For",     style="white",     width=35)

    rows = [
        ("fast",           "medium",  "5–15 min",   "Initial triage, quick risk assessment"),
        ("balanced",       "medium",  "30–90 min",  "Standard engagements, default choice"),
        ("deep",           "high",    "2–6 hours",  "Thorough assessments, nothing missed"),
        ("stealth",        "low",     "45–120 min", "Sensitive targets, minimal detection risk"),
        ("web",            "medium",  "30–60 min",  "Web applications, APIs, JavaScript analysis"),
        ("infrastructure", "medium",  "20–60 min",  "Network/service targets, CVE-heavy"),
        ("vulnerability",  "high",    "20–40 min",  "Service discovery done — go straight to CVEs"),
    ]
    for name, noise, runtime, best_for in rows:
        noise_style = {"low": "green", "medium": "yellow", "high": "red"}.get(noise, "white")
        table.add_row(
            name, f"[{noise_style}]{noise}[/{noise_style}]", runtime, best_for
        )

    console.print()
    console.print(table)
    console.print()


# ── Internal helpers ──────────────────────────────────────────────────────────

def _print_guided_header(console: Console) -> None:
    console.print()
    console.print(Panel(
        "[bold cyan]ReconX Guided Recon Mode[/bold cyan]\n"
        "[dim]AI-assisted reconnaissance with methodology explanations[/dim]",
        border_style="cyan",
        padding=(0, 2),
    ))


def _analyse_target(target: str) -> tuple[str, str]:
    """Infer target type and generate analysis notes."""
    import re

    # IP address
    if re.match(r"^\d{1,3}(\.\d{1,3}){3}$", target):
        return "IP Address", "Direct IP target — port scan will be the primary discovery method. No subdomain enumeration."

    # IP range / CIDR
    if "/" in target and re.match(r"^\d+\.\d+\.\d+\.\d+/\d+$", target):
        return "IP Range (CIDR)", "IP range target — masscan recommended for initial sweep."

    # Single-label hostname (no dots)
    if "." not in target:
        return "Hostname (no TLD)", "Internal hostname or single-label target — DNS enumeration limited."

    # Cloud provider domains
    cloud_patterns = {
        "amazonaws.com": "AWS-hosted asset — cloud infrastructure target",
        "azurewebsites.net": "Azure-hosted asset — cloud infrastructure target",
        "googleapis.com": "GCP-hosted asset — cloud infrastructure target",
        "cloudfront.net": "AWS CloudFront CDN — origin IP scanning required for true surface",
        "herokuapp.com": "Heroku-hosted application",
        "github.io": "GitHub Pages — static site, limited attack surface",
    }
    for suffix, note in cloud_patterns.items():
        if target.endswith(suffix):
            return "Cloud/Hosted Asset", note

    # Count subdomain levels
    parts = target.split(".")
    if len(parts) == 2:
        return "Apex Domain", "Root domain target — full subdomain enumeration recommended."
    elif len(parts) == 3:
        return "Subdomain", "Single subdomain target — focus on service discovery and web recon."
    else:
        return "Deep Subdomain", "Multi-level subdomain — likely a specific service endpoint."


def _select_strategy(
    strategy_name:    Optional[str],
    target_type:      str,
    console:          Console,
    automation_level: int,
) -> Strategy:
    """Select or prompt for a recon strategy."""
    # Auto-select based on target type if not specified
    type_defaults = {
        "IP Address":        Strategy.INFRASTRUCTURE,
        "IP Range (CIDR)":   Strategy.INFRASTRUCTURE,
        "Cloud/Hosted Asset": Strategy.WEB,
        "Apex Domain":       Strategy.BALANCED,
        "Subdomain":         Strategy.WEB,
    }

    if strategy_name:
        try:
            return Strategy(strategy_name.lower())
        except ValueError:
            pass

    if automation_level >= 2:
        # Auto-select
        suggested = type_defaults.get(target_type, Strategy.BALANCED)
        console.print(f"  [dim]Auto-selected strategy: {suggested.display}[/dim]")
        return suggested

    # Interactive selection
    suggested = type_defaults.get(target_type, Strategy.BALANCED)

    console.print(f"  [dim]Suggested strategy for {target_type}: [bold]{suggested.display}[/bold][/dim]")
    console.print()
    show_strategy_comparison(console)

    while True:
        choice = Prompt.ask(
            "  Select strategy",
            choices=["fast", "balanced", "deep", "stealth", "web", "infrastructure", "vulnerability"],
            default=suggested.value,
            console=console,
        )
        try:
            return Strategy(choice)
        except ValueError:
            console.print(f"[red]Invalid strategy: {choice}[/red]")
