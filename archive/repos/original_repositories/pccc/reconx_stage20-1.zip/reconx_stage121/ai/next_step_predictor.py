"""
ReconX — Stage 10: Next Step Predictor.

After each recon stage completes, analyses findings and recommends
specific follow-up actions with reasoning and prioritisation.

Outputs a NextStepReport with ranked recommendations that the
AdaptiveOrchestrator uses to modify the workflow plan.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from .context_analyzer import ReconContext, Phase


@dataclass
class NextStep:
    """A single recommended next action."""
    priority:     int
    action:       str
    reason:       str
    phase:        Phase
    tools:        list[str]
    urgency:      str       # IMMEDIATE | HIGH | NORMAL | OPTIONAL
    confidence:   float
    tags:         list[str] = field(default_factory=list)


@dataclass
class NextStepReport:
    """Complete set of next-step recommendations after a phase."""
    after_phase:    Phase
    steps:          list[NextStep]
    critical_path:  Optional[NextStep]    # most important action
    can_skip:       list[Phase]           # phases safe to skip given findings
    notes:          list[str]


class NextStepPredictor:
    """
    Analyses the current ReconContext after a phase completes and produces
    a NextStepReport with ranked, justified recommendations.
    """

    def predict(self, ctx: ReconContext, after_phase: Phase) -> NextStepReport:
        """
        Generate next-step recommendations after completing `after_phase`.

        Args:
            ctx:         Current recon context (with updated findings)
            after_phase: The phase that just completed

        Returns:
            NextStepReport with prioritised action recommendations
        """
        predictors = {
            Phase.PASSIVE:        self._after_passive,
            Phase.DNS:            self._after_dns,
            Phase.PORT_SCAN:      self._after_port_scan,
            Phase.SERVICE_DETECT: self._after_service_detect,
            Phase.WEB_RECON:      self._after_web_recon,
            Phase.VULN_ANALYSIS:  self._after_vuln_analysis,
            Phase.INTELLIGENCE:   self._after_intelligence,
        }

        predictor = predictors.get(after_phase, self._generic)
        return predictor(ctx)

    # ── Phase-specific predictors ─────────────────────────────────────────────

    def _after_passive(self, ctx: ReconContext) -> NextStepReport:
        steps: list[NextStep] = []
        can_skip: list[Phase] = []
        notes: list[str] = []

        sub_count = len(ctx.subdomains)

        if sub_count == 0:
            steps.append(NextStep(
                priority=1, urgency="HIGH",
                action="DNS Bruteforce — passive yielded nothing",
                reason="No subdomains from passive sources. DNS bruteforce with common wordlists is required.",
                phase=Phase.DNS, tools=["puredns", "shuffledns"],
                confidence=0.90, tags=["dns", "bruteforce"],
            ))
            notes.append("Zero passive subdomains may indicate a narrow domain, non-standard naming, or private infrastructure.")
        else:
            steps.append(NextStep(
                priority=1, urgency="IMMEDIATE",
                action=f"DNS Validation ({sub_count} subdomains)",
                reason=f"Validate all {sub_count} passive subdomains — not all passive results resolve.",
                phase=Phase.DNS, tools=["dnsx"],
                confidence=0.97, tags=["dns", "validation"],
            ))
            notes.append(f"Passive sources returned {sub_count} subdomains. Expect ~70% to be live after validation.")

        if ctx.takeover_candidates:
            steps.append(NextStep(
                priority=2, urgency="IMMEDIATE",
                action=f"Verify {len(ctx.takeover_candidates)} takeover candidate(s)",
                reason="Dangling DNS found — verify claimability before proceeding.",
                phase=Phase.DNS, tools=["subjack", "subzy"],
                confidence=0.93, tags=["takeover"],
            ))

        if sub_count > 100:
            steps.append(NextStep(
                priority=3, urgency="NORMAL",
                action="Identify sensitive subdomain patterns",
                reason=f"Large subdomain set ({sub_count}) — filter for staging, admin, dev patterns.",
                phase=Phase.DNS, tools=["dnsx", "httprobe"],
                confidence=0.85, tags=["patterns"],
            ))
            notes.append("With 100+ subdomains, focus port scanning on the highest-value targets first.")

        return NextStepReport(
            after_phase=Phase.PASSIVE,
            steps=sorted(steps, key=lambda s: s.priority),
            critical_path=steps[0] if steps else None,
            can_skip=[],
            notes=notes,
        )

    def _after_dns(self, ctx: ReconContext) -> NextStepReport:
        steps: list[NextStep] = []
        can_skip: list[Phase] = []
        notes: list[str] = []

        live_count = len(ctx.subdomains)
        ip_count   = len(ctx.ip_addresses)

        if live_count == 0:
            notes.append("No live subdomains — target may be IP-only or all subdomains are internal.")
            steps.append(NextStep(
                priority=1, urgency="HIGH",
                action="Port scan primary target IP directly",
                reason="No live subdomains — scan the root target's IP address.",
                phase=Phase.PORT_SCAN, tools=["nmap", "naabu"],
                confidence=0.88, tags=["port", "direct"],
            ))
        else:
            steps.append(NextStep(
                priority=1, urgency="IMMEDIATE",
                action=f"Port scan {min(live_count, 50)} highest-value hosts",
                reason=f"{live_count} live hosts confirmed. Port scan reveals exposed services.",
                phase=Phase.PORT_SCAN, tools=["naabu", "nmap"],
                confidence=0.97, tags=["port", "service"],
            ))

        if ip_count > 0:
            notes.append(f"Resolved {ip_count} unique IPs — consider scanning IP ranges for additional assets.")

        if ctx.takeover_candidates:
            steps.insert(0, NextStep(
                priority=0, urgency="IMMEDIATE",
                action="Takeover verification (do before port scan)",
                reason="Takeover candidates need immediate verification — high value, low effort.",
                phase=Phase.INTELLIGENCE, tools=["subjack"],
                confidence=0.95, tags=["takeover", "urgent"],
            ))

        return NextStepReport(
            after_phase=Phase.DNS,
            steps=sorted(steps, key=lambda s: s.priority),
            critical_path=steps[0] if steps else None,
            can_skip=[],
            notes=notes,
        )

    def _after_port_scan(self, ctx: ReconContext) -> NextStepReport:
        steps: list[NextStep] = []
        can_skip: list[Phase] = []
        notes: list[str] = []

        port_count = len(ctx.open_ports)

        if port_count == 0:
            notes.append("No open ports — target is firewalled, offline, or using non-standard ports.")
            can_skip.extend([Phase.SERVICE_DETECT, Phase.WEB_RECON, Phase.VULN_ANALYSIS])
            steps.append(NextStep(
                priority=1, urgency="NORMAL",
                action="Verify target reachability (UDP scan / ICMP)",
                reason="No TCP ports found — verify host is reachable.",
                phase=Phase.PORT_SCAN, tools=["nmap"],
                confidence=0.70, tags=["verify"],
            ))
        else:
            # Web services
            web_ports = [p for p in ctx.open_ports if p in {80, 443, 8080, 8443, 8000, 3000}]
            if web_ports:
                steps.append(NextStep(
                    priority=1, urgency="IMMEDIATE",
                    action=f"Service fingerprint + HTTP probing ({len(web_ports)} web port(s))",
                    reason=f"Web ports {web_ports} open — identify technologies for targeted scanning.",
                    phase=Phase.SERVICE_DETECT, tools=["httpx", "whatweb", "nmap"],
                    confidence=0.96, tags=["web", "fingerprint"],
                ))

            # Dangerous ports
            danger = [p for p in ctx.open_ports if p in {6379, 9200, 27017, 2375, 2379, 445, 23}]
            if danger:
                steps.append(NextStep(
                    priority=0, urgency="IMMEDIATE",
                    action=f"Verify dangerous services: {danger}",
                    reason="High-risk ports open — verify auth status before anything else.",
                    phase=Phase.VULN_ANALYSIS, tools=["nuclei", "nmap"],
                    confidence=0.95, tags=["danger", "urgent"],
                ))
                notes.append(f"CRITICAL: {len(danger)} high-risk port(s) found: {danger}. Verify immediately.")

            steps.append(NextStep(
                priority=2, urgency="HIGH",
                action=f"Full service detection ({port_count} ports)",
                reason="Service version data enables precise CVE matching.",
                phase=Phase.SERVICE_DETECT, tools=["nmap", "httpx"],
                confidence=0.95, tags=["service", "version"],
            ))

        return NextStepReport(
            after_phase=Phase.PORT_SCAN,
            steps=sorted(steps, key=lambda s: s.priority),
            critical_path=steps[0] if steps else None,
            can_skip=can_skip,
            notes=notes,
        )

    def _after_service_detect(self, ctx: ReconContext) -> NextStepReport:
        steps: list[NextStep] = []
        can_skip: list[Phase] = []
        notes: list[str] = []

        techs      = ctx.technologies
        web_ports  = [p for p in ctx.open_ports if p in {80, 443, 8080, 8443}]

        if web_ports:
            web_steps = NextStep(
                priority=1, urgency="HIGH",
                action=f"Web recon ({len(web_ports)} web service(s))",
                reason=f"Web services on {web_ports} — map endpoints, APIs, and JS references.",
                phase=Phase.WEB_RECON, tools=["katana", "gau", "ffuf"],
                confidence=0.93, tags=["web", "crawl"],
            )
            steps.append(web_steps)
        else:
            can_skip.append(Phase.WEB_RECON)
            notes.append("No web ports detected — web recon phase will be skipped.")

        # Tech-specific recommendations
        if "jenkins" in techs or 8080 in ctx.open_ports:
            steps.append(NextStep(
                priority=0, urgency="IMMEDIATE",
                action="Scan Jenkins with CI/CD nuclei templates",
                reason="Jenkins detected — high-value target with known critical CVEs.",
                phase=Phase.VULN_ANALYSIS, tools=["nuclei"],
                confidence=0.94, tags=["jenkins", "cicd"],
            ))
            notes.append("Jenkins detected — CVE-2024-23897 (arbitrary file read) may apply.")

        if "elasticsearch" in techs or 9200 in ctx.open_ports:
            steps.append(NextStep(
                priority=0, urgency="IMMEDIATE",
                action="Verify Elasticsearch authentication",
                reason="Elasticsearch frequently deployed without auth — full data access risk.",
                phase=Phase.VULN_ANALYSIS, tools=["nuclei"],
                confidence=0.92, tags=["elasticsearch", "database"],
            ))

        if techs:
            notes.append(f"Technologies identified: {', '.join(techs[:6])}. Template selection will be tech-aware.")

        steps.append(NextStep(
            priority=2, urgency="HIGH",
            action="Run vulnerability analysis",
            reason="Service fingerprinting complete — vulnerability templates can now be targeted.",
            phase=Phase.VULN_ANALYSIS, tools=["nuclei", "nikto"],
            confidence=0.92, tags=["vuln"],
        ))

        return NextStepReport(
            after_phase=Phase.SERVICE_DETECT,
            steps=sorted(steps, key=lambda s: s.priority),
            critical_path=steps[0] if steps else None,
            can_skip=can_skip,
            notes=notes,
        )

    def _after_web_recon(self, ctx: ReconContext) -> NextStepReport:
        steps: list[NextStep] = []
        notes: list[str] = []

        ep_count    = len(ctx.web_endpoints)
        admin_count = len(ctx.admin_panels)

        if admin_count:
            steps.append(NextStep(
                priority=0, urgency="IMMEDIATE",
                action=f"Vulnerability scan {admin_count} admin panel(s)",
                reason="Admin interfaces are primary targets — scan with auth-bypass templates.",
                phase=Phase.VULN_ANALYSIS, tools=["nuclei"],
                confidence=0.94, tags=["admin", "urgent"],
            ))
            notes.append(f"{admin_count} admin panel(s) found — check for default credentials immediately.")

        if ep_count > 50:
            notes.append(f"{ep_count} endpoints discovered — large web surface, prioritise /api/ and /admin/ paths.")

        steps.append(NextStep(
            priority=1, urgency="HIGH",
            action="Full vulnerability scan (nuclei + nikto)",
            reason=f"{ep_count} endpoints mapped — run vulnerability templates across full web surface.",
            phase=Phase.VULN_ANALYSIS, tools=["nuclei", "nikto"],
            confidence=0.92, tags=["vuln", "web"],
        ))

        if ctx.sensitive_files:
            steps.append(NextStep(
                priority=0, urgency="IMMEDIATE",
                action=f"Investigate {len(ctx.sensitive_files)} sensitive file(s)",
                reason="Sensitive files exposed — may contain credentials or source code.",
                phase=Phase.VULN_ANALYSIS, tools=["nuclei"],
                confidence=0.96, tags=["sensitive", "urgent"],
            ))

        return NextStepReport(
            after_phase=Phase.WEB_RECON,
            steps=sorted(steps, key=lambda s: s.priority),
            critical_path=steps[0] if steps else None,
            can_skip=[],
            notes=notes,
        )

    def _after_vuln_analysis(self, ctx: ReconContext) -> NextStepReport:
        notes: list[str] = []
        cve_count = len(ctx.cves)

        if cve_count:
            notes.append(f"{cve_count} CVE(s) confirmed — intelligence correlation will prioritise these.")
        if ctx.sensitive_files:
            notes.append(f"{len(ctx.sensitive_files)} sensitive file(s) — rotate exposed credentials immediately.")

        steps = [NextStep(
            priority=1, urgency="HIGH",
            action="Intelligence correlation and risk assessment",
            reason="All scan data collected — correlate into attack surface intelligence report.",
            phase=Phase.INTELLIGENCE, tools=["intelligence_pipeline"],
            confidence=0.98, tags=["intelligence", "final"],
        )]

        return NextStepReport(
            after_phase=Phase.VULN_ANALYSIS,
            steps=steps,
            critical_path=steps[0],
            can_skip=[],
            notes=notes,
        )

    def _after_intelligence(self, ctx: ReconContext) -> NextStepReport:
        notes = [
            "Guided recon session complete.",
            "Review the IntelligenceReport for prioritised findings and remediation queue.",
            "Export JSON report for tracking and client delivery.",
        ]
        if ctx.cves:
            notes.append(f"IMMEDIATE: {len(ctx.cves)} CVE(s) require patching — review remediation queue.")
        return NextStepReport(
            after_phase=Phase.INTELLIGENCE,
            steps=[],
            critical_path=None,
            can_skip=[],
            notes=notes,
        )

    def _generic(self, ctx: ReconContext) -> NextStepReport:
        return NextStepReport(
            after_phase=ctx.current_phase,
            steps=[],
            critical_path=None,
            can_skip=[],
            notes=["Phase complete — review findings before proceeding."],
        )
