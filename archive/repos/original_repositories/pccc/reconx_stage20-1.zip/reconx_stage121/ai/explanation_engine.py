"""
ReconX — Stage 10: Explanation Engine.

Generates methodology explanations, reasoning narratives, and educational
content at every step of guided recon. Turns execution into learning.

Explanation types:
  - pre_action:   what is about to happen and why
  - post_action:  what was found and what it means
  - finding_note: significance of a specific finding
  - next_hint:    preview of what comes next
  - concept:      educational background on a technique
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from rich.console import Console
from rich.panel import Panel
from rich.text import Text
from rich import box
from rich.table import Table

from .context_analyzer import ReconContext, Phase
from .decision_engine import Decision


@dataclass
class Explanation:
    """Structured explanation output."""
    title:    str
    body:     str
    tip:      str = ""
    warning:  str = ""
    kind:     str = "info"   # info | warning | success | error


class ExplanationEngine:
    """
    Generates and renders methodology explanations to the terminal.

    All output is Rich-formatted. Verbosity levels control detail:
      1 = minimal (action + one-line reason)
      2 = normal  (full reasoning + methodology note)
      3 = verbose (full reasoning + concept + alternatives + next hint)
    """

    def __init__(self, console: Optional[Console] = None, verbosity: int = 2) -> None:
        self._console   = console or Console()
        self._verbosity = verbosity

    # ── Public render methods ─────────────────────────────────────────────────

    def explain_decision(self, decision: Decision, ctx: ReconContext) -> None:
        """Display a full decision explanation before executing an action."""
        if self._verbosity == 0:
            return

        self._console.print()
        self._console.rule(f"[bold cyan]ReconX Decision[/bold cyan]", style="cyan")

        # Core decision panel
        body = Text()
        body.append(f"{decision.action}\n", style="bold white")
        body.append("\n")
        body.append("Reason:  ", style="dim")
        body.append(f"{decision.reason}\n", style="white")

        if self._verbosity >= 2:
            body.append("\nReasoning:\n", style="dim cyan")
            for i, step in enumerate(decision.reasoning_chain, 1):
                prefix = "  ⚠  " if "⚠" in step else f"  {i}. "
                style  = "yellow" if "⚠" in step else "white"
                body.append(f"{prefix}{step}\n", style=style)

        self._console.print(Panel(body, border_style="cyan", padding=(0, 2)))

        # Methodology note
        if self._verbosity >= 2 and decision.methodology_note:
            note_text = Text()
            note_text.append("💡 ", style="yellow")
            note_text.append(decision.methodology_note, style="dim white")
            self._console.print(Panel(note_text, title="[yellow]Methodology[/yellow]",
                                      border_style="yellow", padding=(0, 2)))

        # Alternatives
        if self._verbosity >= 3 and decision.alternatives:
            self._console.print(f"[dim]  Alternatives: {' | '.join(decision.alternatives)}[/dim]")

        self._console.print()

    def explain_finding(
        self,
        finding_type: str,
        value:        str,
        context:      str = "",
        severity:     str = "INFO",
    ) -> None:
        """Explain the significance of a specific finding."""
        if self._verbosity == 0:
            return

        templates = self._finding_templates()
        template  = templates.get(finding_type.lower(), {})

        sig   = template.get("significance", f"Found {finding_type}: {value}")
        imply = template.get("implies",      "Further investigation recommended")
        sev_style = {"CRITICAL": "bold red", "HIGH": "red", "MEDIUM": "yellow",
                     "LOW": "cyan", "INFO": "dim"}.get(severity.upper(), "white")

        icon = {"CRITICAL": "🔴", "HIGH": "🟠", "MEDIUM": "🟡",
                "LOW": "🔵", "INFO": "⚪"}.get(severity.upper(), "•")

        self._console.print(
            f"  {icon} [{sev_style}]{severity}[/{sev_style}]  "
            f"[bold]{finding_type}[/bold]: [yellow]{value[:60]}[/yellow]"
        )
        if self._verbosity >= 2:
            self._console.print(f"       [dim]{sig}[/dim]")
            self._console.print(f"       [dim]→ {imply}[/dim]")

    def explain_phase_start(self, phase: Phase, ctx: ReconContext) -> None:
        """Announce a new recon phase with context."""
        if self._verbosity == 0:
            return

        phase_descriptions = {
            Phase.PASSIVE:        ("🌐", "Collecting open-source intelligence without touching the target"),
            Phase.DNS:            ("🔍", "Validating and expanding the discovered domain space"),
            Phase.PORT_SCAN:      ("🛰️",  "Mapping exposed network services across all discovered hosts"),
            Phase.SERVICE_DETECT: ("🔬", "Fingerprinting services to identify exact versions and technologies"),
            Phase.WEB_RECON:      ("🕷️",  "Mapping web application attack surface — endpoints, APIs, parameters"),
            Phase.VULN_ANALYSIS:  ("⚠️",  "Testing discovered services against known vulnerability templates"),
            Phase.INTELLIGENCE:   ("🧠", "Correlating findings into a prioritised attack surface intelligence report"),
            Phase.COMPLETE:       ("✅", "All planned phases complete — reviewing intelligence output"),
        }

        icon, desc = phase_descriptions.get(phase, ("→", phase.display))
        self._console.print()
        self._console.print(f"[bold cyan]{icon}  {phase.display}[/bold cyan]")
        self._console.print(f"[dim]   {desc}[/dim]")
        self._console.print()

    def explain_phase_end(
        self,
        phase:         Phase,
        findings_count: int,
        duration_s:    float,
        key_findings:  Optional[list[str]] = None,
    ) -> None:
        """Summarise a completed phase."""
        if self._verbosity == 0:
            return

        self._console.print(
            f"  [green]✔[/green] {phase.display} complete — "
            f"[bold]{findings_count}[/bold] findings in [dim]{duration_s:.1f}s[/dim]"
        )
        if self._verbosity >= 2 and key_findings:
            for f in key_findings[:4]:
                self._console.print(f"    [dim]→ {f}[/dim]")

    def explain_skip(self, phase: Phase, reason: str) -> None:
        """Explain why a phase was skipped."""
        if self._verbosity == 0:
            return
        self._console.print(
            f"  [dim]⟳ Skipping {phase.display}: {reason}[/dim]"
        )

    def explain_next_hint(self, decision: Decision) -> None:
        """Preview what comes next after the current action completes."""
        if self._verbosity < 2:
            return
        self._console.print(
            f"\n  [dim]→ Next: [italic]{decision.action}[/italic][/dim]"
        )

    def show_strategy_summary(self, strategy_config, ctx: ReconContext) -> None:
        """Display the selected strategy and planned phases."""
        from .recon_strategy import StrategyConfig, PhaseConfig

        self._console.print()
        self._console.print(Panel(
            f"[bold cyan]{strategy_config.strategy.display}[/bold cyan]\n"
            f"[dim]{strategy_config.strategy.description}[/dim]\n\n"
            f"[white]Target:[/white]  [yellow]{ctx.target}[/yellow]\n"
            f"[white]Phases:[/white]  {len([p for p in strategy_config.phases if p.enabled])}\n"
            f"[white]Noise:[/white]   {strategy_config.noise_level.upper()}\n"
            f"[white]Rate:[/white]    {strategy_config.rate_limit} req/min",
            title="[bold]Selected Strategy[/bold]",
            border_style="cyan",
        ))

        if self._verbosity >= 2:
            table = Table(box=box.SIMPLE, border_style="dim", show_header=True)
            table.add_column("Phase",    style="cyan",  width=22)
            table.add_column("Tools",    style="white", width=35)
            table.add_column("Depth",    style="dim",   width=10)
            table.add_column("Status",   style="dim",   width=8)

            for pc in strategy_config.phases:
                status = "[green]enabled[/green]" if pc.enabled else "[dim]skip[/dim]"
                table.add_row(
                    pc.phase.display,
                    ", ".join(pc.tools[:3]) + ("…" if len(pc.tools) > 3 else ""),
                    pc.depth,
                    status,
                )
            self._console.print(table)

    def show_session_summary(self, ctx: ReconContext) -> None:
        """Display final session summary."""
        self._console.print()
        self._console.rule("[bold cyan]Session Complete[/bold cyan]", style="cyan")

        table = Table(box=box.SIMPLE_HEAD, border_style="cyan", show_header=False)
        table.add_column("Metric",  style="dim",   width=24)
        table.add_column("Value",   style="white", width=20)

        rows = [
            ("Target",        ctx.target),
            ("Strategy",      ctx.strategy.display),
            ("Subdomains",    str(len(ctx.subdomains))),
            ("Open Ports",    str(len(ctx.open_ports))),
            ("Technologies",  str(len(ctx.technologies))),
            ("Endpoints",     str(len(ctx.web_endpoints))),
            ("CVEs Found",    str(len(ctx.cves))),
            ("Sensitive Files", str(len(ctx.sensitive_files))),
            ("Steps Taken",   str(len(ctx.executed_steps))),
            ("Decisions",     str(len(ctx.decision_history))),
        ]
        for k, v in rows:
            table.add_row(k, v)
        self._console.print(table)

        if ctx.methodology_notes and self._verbosity >= 2:
            self._console.print("\n[bold cyan]Methodology Notes:[/bold cyan]")
            for note in ctx.methodology_notes[-5:]:
                self._console.print(f"  [dim]💡 {note}[/dim]")

    # ── Concept library ───────────────────────────────────────────────────────

    def explain_concept(self, concept: str) -> None:
        """Print an educational concept explanation."""
        concepts = self._concept_library()
        entry    = concepts.get(concept.lower())
        if not entry:
            self._console.print(f"[dim]No concept found for: {concept}[/dim]")
            return
        self._console.print(Panel(
            f"[bold]{entry['title']}[/bold]\n\n{entry['body']}",
            title="[yellow]📚 Concept[/yellow]",
            border_style="yellow",
        ))

    # ── Internal data ─────────────────────────────────────────────────────────

    def _finding_templates(self) -> dict[str, dict]:
        return {
            "subdomain": {
                "significance": "Every subdomain is a potential entry point to the organisation's infrastructure.",
                "implies":      "Probe for live hosts; check for staging/dev patterns and takeover candidates",
            },
            "open_port": {
                "significance": "An open port indicates a listening service — potential attack surface.",
                "implies":      "Service fingerprint to identify version; check for known CVEs",
            },
            "technology": {
                "significance": "Identified technology enables targeted template selection and CVE matching.",
                "implies":      "Load technology-specific nuclei templates; check version against CVE database",
            },
            "cve": {
                "significance": "A known CVE with public identifier — patch exists and exploit may be public.",
                "implies":      "Check CVSS score; verify affected version; apply patch or WAF rule immediately",
            },
            "sensitive_file": {
                "significance": "Sensitive files exposed via web often contain credentials or source code.",
                "implies":      "Retrieve and inspect content; rotate any credentials found; remove immediately",
            },
            "admin_panel": {
                "significance": "Administrative interfaces are high-value targets for brute-force and CVE exploitation.",
                "implies":      "Check for default credentials; test for auth bypass; verify MFA is enforced",
            },
            "takeover_candidate": {
                "significance": "Dangling DNS allows an attacker to claim the subdomain and impersonate the organisation.",
                "implies":      "Remove CNAME immediately; claim the third-party service if still needed",
            },
            "email": {
                "significance": "Email addresses enable targeted phishing and credential stuffing attacks.",
                "implies":      "Implement DMARC/DKIM/SPF; check HaveIBeenPwned; train staff on phishing",
            },
        }

    def _concept_library(self) -> dict[str, dict]:
        return {
            "passive recon": {
                "title": "Passive Reconnaissance",
                "body":  (
                    "Passive recon collects information about a target without sending packets to it.\n"
                    "Sources include: certificate transparency logs (crt.sh), DNS databases (SecurityTrails),\n"
                    "search engines, WHOIS, GitHub, Shodan, and web archives.\n\n"
                    "Key advantage: zero detection risk — all data is from public sources."
                ),
            },
            "certificate transparency": {
                "title": "Certificate Transparency (CT) Logs",
                "body":  (
                    "Every TLS certificate issued by a public CA must be logged in CT logs (RFC 6962).\n"
                    "These logs are public and searchable at crt.sh.\n\n"
                    "Attackers query CT logs to discover subdomains before active scanning.\n"
                    "A wildcard cert (*.example.com) confirms the domain but not specific subdomains.\n"
                    "Individual certs (api.example.com) reveal exact subdomain names."
                ),
            },
            "subdomain takeover": {
                "title": "Subdomain Takeover",
                "body":  (
                    "Occurs when a subdomain's DNS record (CNAME) points to an external service\n"
                    "that the organisation no longer controls.\n\n"
                    "Attack: Register the abandoned resource → control the subdomain.\n"
                    "Impact: Serve phishing pages from trusted domain, steal cookies (no HttpOnly),\n"
                    "bypass CSP policies, and abuse OAuth redirect URIs.\n\n"
                    "Common services: S3 buckets, GitHub Pages, Heroku, Azure, Fastly."
                ),
            },
            "attack surface": {
                "title": "Attack Surface",
                "body":  (
                    "The attack surface is the total set of points where an attacker could interact\n"
                    "with a system to attempt unauthorised access.\n\n"
                    "Components:\n"
                    "  Network layer:     open ports, protocols, firewall rules\n"
                    "  Application layer: endpoints, APIs, parameters, auth flows\n"
                    "  Identity layer:    user accounts, tokens, credentials, roles\n"
                    "  Human layer:       staff emails, social media, phishing surface\n\n"
                    "Reducing attack surface = decommissioning unused assets."
                ),
            },
            "cve": {
                "title": "CVE (Common Vulnerabilities and Exposures)",
                "body":  (
                    "CVEs are standardised identifiers for publicly disclosed vulnerabilities.\n"
                    "Format: CVE-YEAR-NNNNN\n\n"
                    "Scored by CVSS (0.0–10.0):\n"
                    "  Critical (9.0–10.0): Immediate exploitation, no user interaction\n"
                    "  High     (7.0–8.9):  Significant impact, often remotely exploitable\n"
                    "  Medium   (4.0–6.9):  Conditional exploitation\n"
                    "  Low      (0.1–3.9):  Local access or complex conditions required\n\n"
                    "Check: nvd.nist.gov/vuln/detail/CVE-XXXX-XXXX"
                ),
            },
        }
