"""
ReconX — Stage 10: Recon Context.

Single source of truth for all state maintained during a guided recon session.
Passed between all AI/guided modules — no global state.

Tracks:
  - target metadata
  - findings accumulated per stage
  - executed steps
  - confidence levels
  - skipped opportunities
  - current strategy
  - decision history
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Optional


# ── Strategy profiles ─────────────────────────────────────────────────────────

class Strategy(str, Enum):
    FAST           = "fast"
    BALANCED       = "balanced"
    DEEP           = "deep"
    STEALTH        = "stealth"
    WEB            = "web"
    INFRASTRUCTURE = "infrastructure"
    VULNERABILITY  = "vulnerability"

    @property
    def display(self) -> str:
        return {
            "fast":           "Fast Recon",
            "balanced":       "Balanced Recon",
            "deep":           "Deep Recon",
            "stealth":        "Stealth Recon",
            "web":            "Web-Focused Recon",
            "infrastructure": "Infrastructure-Focused Recon",
            "vulnerability":  "Vulnerability-Focused Recon",
        }[self.value]

    @property
    def description(self) -> str:
        return {
            "fast":           "Minimal footprint, quick intelligence — ideal for initial assessment",
            "balanced":       "Standard methodology covering all key recon phases",
            "deep":           "Aggressive surface mapping — maximum coverage, higher noise",
            "stealth":        "Reduced noise, passive-first approach — minimises detection risk",
            "web":            "Optimised for web application targets — crawling, fuzzing, APIs",
            "infrastructure": "Network and service focused — ports, services, protocols, CVEs",
            "vulnerability":  "CVE-first — assumes service discovery done, focus on vulnerabilities",
        }[self.value]


# ── Recon phase definitions ───────────────────────────────────────────────────

class Phase(str, Enum):
    PASSIVE         = "passive"
    DNS             = "dns"
    PORT_SCAN       = "port_scan"
    SERVICE_DETECT  = "service_detect"
    WEB_RECON       = "web_recon"
    VULN_ANALYSIS   = "vuln_analysis"
    INTELLIGENCE    = "intelligence"
    COMPLETE        = "complete"

    @property
    def display(self) -> str:
        return {
            "passive":        "Passive Reconnaissance",
            "dns":            "DNS Enumeration",
            "port_scan":      "Port Scanning",
            "service_detect": "Service Detection",
            "web_recon":      "Web Reconnaissance",
            "vuln_analysis":  "Vulnerability Analysis",
            "intelligence":   "Intelligence Correlation",
            "complete":       "Complete",
        }[self.value]

    @property
    def order(self) -> int:
        return list(Phase).index(self)


# ── Step record ───────────────────────────────────────────────────────────────

@dataclass
class ExecutedStep:
    """A completed step in the guided session."""
    phase:       Phase
    action:      str          # e.g. "Run Subfinder"
    tool:        str          # e.g. "subfinder"
    result_summary: str       # brief outcome
    findings_count: int
    duration_s:  float
    timestamp:   str = field(default_factory=lambda: datetime.utcnow().isoformat())
    skipped:     bool = False
    skip_reason: str  = ""


@dataclass
class DecisionRecord:
    """A recorded AI decision with reasoning."""
    phase:       Phase
    decision:    str          # what was decided
    reasoning:   str          # why
    confidence:  float        # 0–1
    alternatives: list[str]   = field(default_factory=list)
    timestamp:   str = field(default_factory=lambda: datetime.utcnow().isoformat())


# ── Session context ───────────────────────────────────────────────────────────

@dataclass
class ReconContext:
    """
    Full state for a guided recon session.

    Passed by reference between all Stage 10 modules.
    Mutated as the session progresses.
    """
    target:            str
    strategy:          Strategy          = Strategy.BALANCED
    current_phase:     Phase             = Phase.PASSIVE
    verbosity:         int               = 2          # 1=quiet, 2=normal, 3=verbose
    automation_level:  int               = 1          # 0=ask all, 1=ask key, 2=full auto
    allow_active:      bool              = True

    # ── Accumulated findings ──────────────────────────────────────────────────
    ip_addresses:      list[str]         = field(default_factory=list)
    subdomains:        list[str]         = field(default_factory=list)
    open_ports:        list[int]         = field(default_factory=list)
    services:          dict[int, str]    = field(default_factory=dict)  # port → service
    technologies:      list[str]         = field(default_factory=list)
    web_endpoints:     list[str]         = field(default_factory=list)
    emails:            list[str]         = field(default_factory=list)
    cves:              list[str]         = field(default_factory=list)
    sensitive_files:   list[str]         = field(default_factory=list)
    admin_panels:      list[str]         = field(default_factory=list)
    takeover_candidates: list[str]       = field(default_factory=list)

    # ── Confidence tracking ───────────────────────────────────────────────────
    confidence_levels: dict[str, float]  = field(default_factory=dict)  # finding → confidence

    # ── Session history ───────────────────────────────────────────────────────
    executed_steps:    list[ExecutedStep]  = field(default_factory=list)
    decision_history:  list[DecisionRecord] = field(default_factory=list)
    skipped_phases:    list[Phase]         = field(default_factory=list)
    methodology_notes: list[str]           = field(default_factory=list)

    # ── Flags ─────────────────────────────────────────────────────────────────
    has_web:           bool              = False
    has_subdomains:    bool              = False
    has_open_ports:    bool              = False
    is_cdn_target:     bool              = False
    is_cloud_target:   bool              = False
    vuln_scan_done:    bool              = False
    intel_done:        bool              = False

    # ── Session metadata ──────────────────────────────────────────────────────
    started_at:        str = field(default_factory=lambda: datetime.utcnow().isoformat())
    notes:             dict[str, Any]    = field(default_factory=dict)

    # ── Mutators ──────────────────────────────────────────────────────────────

    def record_step(self, step: ExecutedStep) -> None:
        self.executed_steps.append(step)

    def record_decision(self, decision: DecisionRecord) -> None:
        self.decision_history.append(decision)

    def add_methodology_note(self, note: str) -> None:
        self.methodology_notes.append(note)

    def update_from_findings(
        self,
        *,
        ips:          Optional[list[str]] = None,
        subdomains:   Optional[list[str]] = None,
        ports:        Optional[list[int]] = None,
        services:     Optional[dict]      = None,
        tech:         Optional[list[str]] = None,
        endpoints:    Optional[list[str]] = None,
        emails:       Optional[list[str]] = None,
        cves:         Optional[list[str]] = None,
        sensitive:    Optional[list[str]] = None,
        admin_panels: Optional[list[str]] = None,
        takeovers:    Optional[list[str]] = None,
    ) -> None:
        """Merge new findings into context, deduplicate, update flags."""
        def _merge(dst: list, src: list | None) -> list:
            if not src: return dst
            return list(dict.fromkeys(dst + src))

        self.ip_addresses       = _merge(self.ip_addresses, ips)
        self.subdomains         = _merge(self.subdomains, subdomains)
        self.open_ports         = sorted(set(self.open_ports + (ports or [])))
        self.technologies       = _merge(self.technologies, tech)
        self.web_endpoints      = _merge(self.web_endpoints, endpoints)
        self.emails             = _merge(self.emails, emails)
        self.cves               = _merge(self.cves, cves)
        self.sensitive_files    = _merge(self.sensitive_files, sensitive)
        self.admin_panels       = _merge(self.admin_panels, admin_panels)
        self.takeover_candidates = _merge(self.takeover_candidates, takeovers)

        if services:
            self.services.update(services)

        # Update flags
        self.has_web        = bool(self.web_endpoints or
                                   any(p in self.open_ports for p in [80, 443, 8080, 8443]))
        self.has_subdomains = len(self.subdomains) > 0
        self.has_open_ports = len(self.open_ports) > 0

        cdn_tech  = {"cloudflare", "fastly", "akamai", "cloudfront", "imperva"}
        cloud_kw  = {"aws", "azure", "gcp", "digitalocean", "linode"}
        self.is_cdn_target   = any(t in cdn_tech   for t in self.technologies)
        self.is_cloud_target = any(t in cloud_kw   for t in self.technologies)

    def has_executed(self, phase: Phase) -> bool:
        return any(s.phase == phase and not s.skipped for s in self.executed_steps)

    def get_phase_findings(self, phase: Phase) -> list[ExecutedStep]:
        return [s for s in self.executed_steps if s.phase == phase]

    def total_findings(self) -> int:
        return (len(self.subdomains) + len(self.open_ports) + len(self.technologies) +
                len(self.web_endpoints) + len(self.cves) + len(self.sensitive_files))

    def summary(self) -> dict:
        return {
            "target":       self.target,
            "strategy":     self.strategy.value,
            "phase":        self.current_phase.value,
            "subdomains":   len(self.subdomains),
            "ports":        len(self.open_ports),
            "technologies": len(self.technologies),
            "endpoints":    len(self.web_endpoints),
            "cves":         len(self.cves),
            "sensitive":    len(self.sensitive_files),
            "steps":        len(self.executed_steps),
            "decisions":    len(self.decision_history),
        }
