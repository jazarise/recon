"""
ReconX — phoneinfoga wrapper.

PhoneInfoga gathers intelligence about phone numbers: carrier info,
country, region, line type, and OSINT lookups across social networks
and public data sources.

Stage 1 — Passive Identity Intelligence.
"""
from __future__ import annotations
import json
import re
import time
from typing import Optional

from ..base import BaseTool
from ...models.tool_result import ParsedFinding, RunStatus, ToolRunResult


class PhoneInfogaTool(BaseTool):

    NAME         = "phoneinfoga"
    BINARY       = "phoneinfoga"
    CATEGORY     = "identity"
    STAGE        = 1
    PRIORITY     = 20
    PASSIVE      = True
    TIMEOUT      = 60
    DEPENDENCIES: list[str] = []
    INSTALL_CMD  = (
        "# Linux:\ncurl -sSLf https://raw.githubusercontent.com/sundowndev/"
        "phoneinfoga/master/support/scripts/install | bash\n"
        "# or: go install github.com/sundowndev/phoneinfoga/v2/cmd/phoneinfoga@latest"
    )

    # ── run ───────────────────────────────────────────────────────────────────

    def run(
        self,
        target: str,
        *,
        scanners: Optional[list[str]] = None,   # ["numverify","googlesearch","ovh"]
        output_format: str = "json",
        **kwargs,
    ) -> ToolRunResult:
        """
        Args:
            target:        Phone number in E.164 format (e.g. +14155552671).
            scanners:      Specific scanner plugins to run.
            output_format: 'json' or 'text'.
        """
        if s := self.skip_if_unavailable():
            return s

        # Normalise phone number
        number = re.sub(r"[^\d\+]", "", target)
        if not number.startswith("+"):
            number = f"+{number}"

        args = ["scan", "-n", number, "--output", output_format]
        if scanners:
            for sc in scanners:
                args += ["--scanner", sc]

        t0  = time.perf_counter()
        res = self.exec(args, timeout_s=float(self.timeout), expected_codes=(0, 1))
        dur = time.perf_counter() - t0

        if res.timed_out:
            return ToolRunResult.timeout(self.NAME, dur, self.timeout)
        if res.returncode == 127:
            return ToolRunResult.skipped(self.NAME, res.stderr)

        data = self.parse_output(res.stdout)
        findings = self._build_findings(data, number)
        r = self.build_result(data, findings, stdout=res.stdout,
                              duration_s=dur, returncode=res.returncode)
        if not data.get("number"): r.status = RunStatus.NO_OUTPUT
        return r

    # ── parse_output ──────────────────────────────────────────────────────────

    def parse_output(self, raw: str, **kwargs) -> dict:
        if not raw.strip():
            return self._empty()

        try:
            obj = json.loads(raw)
            return {
                "number":   obj.get("rawLocal", obj.get("number", "")),
                "country":  obj.get("country", ""),
                "carrier":  obj.get("carrier", ""),
                "line_type": obj.get("lineType", ""),
                "valid":    obj.get("valid", False),
                "local":    obj.get("local", ""),
                "intl":     obj.get("international", ""),
                "scanners": obj.get("scanners", {}),
            }
        except Exception:
            pass

        # Text fallback
        result = self._empty()
        for line in raw.splitlines():
            low = line.lower().strip()
            if "country" in low:
                result["country"] = line.split(":")[-1].strip()
            elif "carrier" in low:
                result["carrier"] = line.split(":")[-1].strip()
            elif "valid" in low:
                result["valid"] = "true" in low
        return result

    @staticmethod
    def _empty() -> dict:
        return {"number": "", "country": "", "carrier": "", "line_type": "",
                "valid": False, "local": "", "intl": "", "scanners": {}}

    def _build_findings(self, data: dict, number: str) -> list[ParsedFinding]:
        if not data.get("number") and not number:
            return []
        return [ParsedFinding(
            finding_type="phone_intelligence",
            value=number,
            source=self.NAME, confidence=0.9,
            metadata={
                "country":   data.get("country", ""),
                "carrier":   data.get("carrier", ""),
                "line_type": data.get("line_type", ""),
                "valid":     data.get("valid", False),
            },
        )]
