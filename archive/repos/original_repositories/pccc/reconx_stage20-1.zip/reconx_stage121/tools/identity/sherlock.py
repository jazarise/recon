"""
ReconX — sherlock wrapper.

Sherlock hunts usernames across 400+ social networks and services.
Pure-Python fallback uses direct HTTP probing against a curated
subset of high-value platforms.

Stage 1 — Passive Identity Intelligence.
"""
from __future__ import annotations
import json
import re
import ssl
import time
import urllib.request
from typing import Optional

from ..base import BaseTool
from ...models.tool_result import ParsedFinding, RunStatus, ToolRunResult

# High-value platforms to probe in fallback mode (non-API, public profile URLs)
_PLATFORM_PROBES: list[tuple[str, str]] = [
    ("GitHub",     "https://github.com/{username}"),
    ("Twitter/X",  "https://twitter.com/{username}"),
    ("Instagram",  "https://www.instagram.com/{username}/"),
    ("Reddit",     "https://www.reddit.com/user/{username}"),
    ("LinkedIn",   "https://www.linkedin.com/in/{username}"),
    ("TikTok",     "https://www.tiktok.com/@{username}"),
    ("YouTube",    "https://www.youtube.com/@{username}"),
    ("Pinterest",  "https://www.pinterest.com/{username}/"),
    ("Twitch",     "https://www.twitch.tv/{username}"),
    ("HackerNews", "https://news.ycombinator.com/user?id={username}"),
    ("Keybase",    "https://keybase.io/{username}"),
    ("GitLab",     "https://gitlab.com/{username}"),
    ("Medium",     "https://medium.com/@{username}"),
    ("Dev.to",     "https://dev.to/{username}"),
    ("Patreon",    "https://www.patreon.com/{username}"),
]


class SherlockTool(BaseTool):

    NAME         = "sherlock"
    BINARY       = "sherlock"
    CATEGORY     = "identity"
    STAGE        = 1
    PRIORITY     = 10
    PASSIVE      = True
    TIMEOUT      = 120
    DEPENDENCIES: list[str] = []
    INSTALL_CMD  = "pip install sherlock-project  # or: git clone https://github.com/sherlock-project/sherlock"

    # ── run ───────────────────────────────────────────────────────────────────

    def run(
        self,
        target: str,
        *,
        usernames:    Optional[list[str]] = None,
        timeout:      int                 = 10,
        print_found:  bool                = True,
        no_color:     bool                = True,
        tor:          bool                = False,
        **kwargs,
    ) -> ToolRunResult:
        """
        Args:
            target:      Single username to search (or the primary target).
            usernames:   Additional usernames to search (batch mode).
            timeout:     Per-site HTTP timeout.
            print_found: Only output found profiles.
            no_color:    Disable ANSI colour output.
            tor:         Route through Tor (requires Tor running).
        """
        all_names = list(dict.fromkeys([target] + (usernames or [])))
        t0 = time.perf_counter()

        # ── Binary path ───────────────────────────────────────────────────────
        if self.is_available():
            args = [*all_names,
                    "--timeout", str(timeout),
                    "--print-found",
                    "--output", "/dev/null",  # suppress file output
                    "--folderoutput", "/tmp/sherlock_out"]
            if no_color:
                args.append("--no-color")
            if tor:
                args.append("--tor")

            res = self.exec(args, timeout_s=float(self.timeout), expected_codes=(0, 1))
            dur = time.perf_counter() - t0
            if res.timed_out:
                return ToolRunResult.timeout(self.NAME, dur, self.timeout)
            if res.returncode == 127:
                return ToolRunResult.skipped(self.NAME, res.stderr)

            data = self.parse_output(res.stdout)
            findings = self._build_findings(data)
            r = self.build_result(data, findings, stdout=res.stdout,
                                  duration_s=dur, returncode=res.returncode)
            if not data["profiles"]: r.status = RunStatus.NO_OUTPUT
            return r

        # ── Pure-Python HTTP probe fallback ───────────────────────────────────
        self._log("info", "sherlock binary not found — using HTTP probe fallback")
        data = self._http_probe(all_names[0], timeout)
        dur  = time.perf_counter() - t0
        findings = self._build_findings(data)
        r = self.build_result(data, findings, duration_s=dur, returncode=0)
        if not data["profiles"]: r.status = RunStatus.NO_OUTPUT
        return r

    # ── parse_output ──────────────────────────────────────────────────────────

    def parse_output(self, raw: str, **kwargs) -> dict:
        if not raw.strip():
            return {"profiles": [], "not_found": [], "count": 0}

        profiles:  list[dict] = []
        not_found: list[str]  = []
        ansi_re   = re.compile(r"\x1b\[[0-9;]*[A-Za-z]")
        url_re    = re.compile(r"(https?://[^\s]+)")

        for line in raw.splitlines():
            line = ansi_re.sub("", line).strip()
            lower = line.lower()

            if "[+]" in line or ("found" in lower and "http" in lower):
                platform_m = re.match(r"\[\+\]\s*([^:]+):\s*(https?://\S+)", line)
                if platform_m:
                    profiles.append({
                        "platform": platform_m.group(1).strip(),
                        "url":      platform_m.group(2).strip(),
                        "found":    True,
                    })
                else:
                    for url in url_re.findall(line):
                        profiles.append({"platform": "unknown", "url": url, "found": True})

            elif "[-]" in line or "not found" in lower:
                m = re.match(r"\[-\]\s*([^:]+)", line)
                if m:
                    not_found.append(m.group(1).strip())

        return {"profiles": profiles, "not_found": not_found, "count": len(profiles)}

    # ── internal ──────────────────────────────────────────────────────────────

    def _http_probe(self, username: str, timeout: int) -> dict:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode    = ssl.CERT_NONE
        opener = urllib.request.build_opener(urllib.request.HTTPSHandler(context=ctx))

        profiles:  list[dict] = []
        not_found: list[str]  = []

        for platform, url_tmpl in _PLATFORM_PROBES:
            url = url_tmpl.format(username=username)
            try:
                req = urllib.request.Request(
                    url, headers={"User-Agent": "Mozilla/5.0 (ReconX/2.0)"}
                )
                with opener.open(req, timeout=timeout) as resp:
                    code = resp.status
                    if code == 200:
                        profiles.append({"platform": platform, "url": url, "found": True})
                    else:
                        not_found.append(platform)
            except Exception:
                not_found.append(platform)

        return {"profiles": profiles, "not_found": not_found, "count": len(profiles)}

    def _build_findings(self, data: dict) -> list[ParsedFinding]:
        return [
            ParsedFinding(
                finding_type="social_profile",
                value=p.get("url", ""),
                source=self.NAME, confidence=0.85,
                metadata={"platform": p.get("platform", ""), "found": True},
            )
            for p in data.get("profiles", [])
        ]
