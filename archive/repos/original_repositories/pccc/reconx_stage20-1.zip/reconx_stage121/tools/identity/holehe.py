"""
ReconX — holehe wrapper.

holehe checks whether an email address is registered on 120+ websites
by probing password-reset flows (no login required). Maps email addresses
to social and service accounts for identity correlation.

Stage 1 — Passive Identity Intelligence.
"""
from __future__ import annotations
import re
import time
from typing import Optional

from ..base import BaseTool
from ...models.tool_result import ParsedFinding, RunStatus, ToolRunResult


class HoleheTool(BaseTool):

    NAME         = "holehe"
    BINARY       = "holehe"
    CATEGORY     = "identity"
    STAGE        = 1
    PRIORITY     = 15
    PASSIVE      = True
    TIMEOUT      = 120
    DEPENDENCIES: list[str] = []
    INSTALL_CMD  = "pip install holehe"

    # ── run ───────────────────────────────────────────────────────────────────

    def run(
        self,
        target: str,
        *,
        emails:       Optional[list[str]] = None,
        only_used:    bool                = True,
        timeout:      int                 = 10,
        no_color:     bool                = True,
        **kwargs,
    ) -> ToolRunResult:
        """
        Args:
            target:     Email address to check.
            emails:     Additional emails (batch mode).
            only_used:  Only show services where account was found.
            timeout:    Per-site request timeout.
            no_color:   Disable colour output.
        """
        all_emails = list(dict.fromkeys([target] + (emails or [])))
        t0 = time.perf_counter()

        if self.is_available():
            args = [*all_emails, "--timeout", str(timeout)]
            if only_used:
                args.append("--only-used")
            if no_color:
                args.append("--no-color")

            res = self.exec(args, timeout_s=float(self.timeout), expected_codes=(0, 1))
            dur = time.perf_counter() - t0

            if res.timed_out:
                return ToolRunResult.timeout(self.NAME, dur, self.timeout)
            if res.returncode == 127:
                return ToolRunResult.skipped(self.NAME, res.stderr)

            data = self.parse_output(res.stdout)
            findings = self._build_findings(data)
            r = self.build_result(data, findings, stdout=res.stdout,
                                  duration_s=dur, returncode=res.returncode)
            if not data["accounts"]: r.status = RunStatus.NO_OUTPUT
            return r

        # Fallback: holehe requires network — no meaningful offline fallback
        self._log("info", "holehe binary not found — install via: pip install holehe")
        return ToolRunResult.skipped(self.NAME, "holehe not installed. Run: pip install holehe")

    # ── parse_output ──────────────────────────────────────────────────────────

    def parse_output(self, raw: str, **kwargs) -> dict:
        """
        holehe output:
          [+] twitter.com        Email used
          [-] facebook.com       Email not used
          [x] linkedin.com       Error
        """
        if not raw.strip():
            return {"accounts": [], "not_found": [], "errors": [], "count": 0}

        accounts:  list[dict] = []
        not_found: list[str]  = []
        errors:    list[str]  = []
        ansi_re   = re.compile(r"\x1b\[[0-9;]*[A-Za-z]")

        for line in raw.splitlines():
            line  = ansi_re.sub("", line).strip()
            lower = line.lower()
            if not line:
                continue

            site_m = re.search(r"[\+\-x]\]\s*([a-zA-Z0-9\.\-]+)", line)
            site   = site_m.group(1) if site_m else ""

            if line.startswith("[+]") or "email used" in lower:
                accounts.append({"site": site, "status": "registered",
                                 "url": f"https://{site}"})
            elif line.startswith("[-]") or "not used" in lower:
                not_found.append(site)
            elif line.startswith("[x]") or "error" in lower:
                errors.append(site)

        return {
            "accounts":  accounts,
            "not_found": not_found,
            "errors":    errors,
            "count":     len(accounts),
        }

    def _build_findings(self, data: dict) -> list[ParsedFinding]:
        return [
            ParsedFinding(
                finding_type="email_account",
                value=a.get("url", a.get("site", "")),
                source=self.NAME, confidence=0.87,
                metadata={"site": a.get("site", ""), "status": "registered"},
            )
            for a in data.get("accounts", [])
        ]
