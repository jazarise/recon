"""
ReconX — Stage 17: Banner Intelligence Analyzer.

Parses raw service banners captured during port scanning and normalises
them into structured, actionable intelligence:
  • Software identification    (nginx, Apache, OpenSSH, vsftpd, Postfix, …)
  • Version extraction         (e.g. "nginx/1.18.0" → {"name": "nginx", "version": "1.18.0"})
  • Protocol classification    (HTTP, SSH, FTP, SMTP, IMAP, …)
  • Confidence scoring         (regex-based certainty estimate)
  • Risk annotation            (outdated version, known-bad version)

Follows BaseTool-compatible design: fails gracefully, returns structured data,
never raises to caller.

Usage:
    from reconx.tools.banner_analyzer import BannerAnalyzer

    analyzer = BannerAnalyzer()
    result   = analyzer.analyze(":22", "SSH-2.0-OpenSSH_7.4")
    print(result.software, result.version, result.confidence)

    batch = analyzer.analyze_all(port_list)
    for br in batch:
        if br.risk_level:
            print(br)
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import Optional

log = logging.getLogger("reconx.tools.banner_analyzer")


# ─────────────────────────────────────────────────────────────────────────────
# Banner pattern database
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class BannerPattern:
    """A single detection rule for banner parsing."""
    protocol:    str           # http | ssh | ftp | smtp | imap | pop3 | generic
    software:    str           # normalised software name
    regex:       str           # applied against banner (case-insensitive)
    version_group: int = 1     # regex capture group index for version
    confidence:  float = 0.90  # base confidence if matched


# Core patterns — ordered: more specific first
_PATTERNS: list[BannerPattern] = [

    # ── HTTP servers ─────────────────────────────────────────────────────────
    BannerPattern("http", "nginx",       r"nginx[/\s]?([\d.]+)?",      confidence=0.95),
    BannerPattern("http", "Apache",      r"Apache[/\s]?([\d.]+)?",     confidence=0.95),
    BannerPattern("http", "IIS",         r"Microsoft-IIS[/\s]?([\d.]+)?", confidence=0.95),
    BannerPattern("http", "Lighttpd",    r"lighttpd[/\s]?([\d.]+)?",   confidence=0.93),
    BannerPattern("http", "Tomcat",      r"Apache-Coyote[/\s]?([\d.]+)?|Tomcat[/\s]?([\d.]+)?", confidence=0.90),
    BannerPattern("http", "Jetty",       r"Jetty[/\s]?([\d.]+)?",      confidence=0.90),
    BannerPattern("http", "Caddy",       r"Caddy[/\s]?([\d.]+)?",      confidence=0.90),
    BannerPattern("http", "OpenResty",   r"openresty[/\s]?([\d.]+)?",  confidence=0.92),
    BannerPattern("http", "Gunicorn",    r"gunicorn[/\s]?([\d.]+)?",   confidence=0.88),
    BannerPattern("http", "Werkzeug",    r"Werkzeug[/\s]?([\d.]+)?",   confidence=0.85),
    BannerPattern("http", "PHP",         r"PHP[/\s]?([\d.]+)?",        confidence=0.88, version_group=1),

    # ── SSH ──────────────────────────────────────────────────────────────────
    BannerPattern("ssh",  "OpenSSH",     r"OpenSSH[_\s]?([\d.p]+)",    confidence=0.97),
    BannerPattern("ssh",  "Dropbear",    r"dropbear[_\s]?([\d.]+)?",   confidence=0.95),
    BannerPattern("ssh",  "libssh",      r"libssh[_\-]?([\d.]+)?",     confidence=0.90),
    BannerPattern("ssh",  "Bitvise",     r"Bitvise[_\s]?([\d.]+)?",    confidence=0.92),
    BannerPattern("ssh",  "Cisco SSH",   r"Cisco[_\-]SSH",              confidence=0.92, version_group=0),

    # ── FTP ──────────────────────────────────────────────────────────────────
    BannerPattern("ftp",  "vsftpd",      r"vsftpd[_\s]?([\d.]+)?",    confidence=0.95),
    BannerPattern("ftp",  "ProFTPD",     r"ProFTPD[_\s]?([\d.]+)?",   confidence=0.95),
    BannerPattern("ftp",  "PureFTPD",    r"Pure-FTPd[_\s]?([\d.]+)?", confidence=0.95),
    BannerPattern("ftp",  "FileZilla",   r"FileZilla Server",           confidence=0.92, version_group=0),
    BannerPattern("ftp",  "IIS FTP",     r"Microsoft FTP",              confidence=0.90, version_group=0),
    BannerPattern("ftp",  "wu-ftpd",     r"wu[-_]([\d.]+)?",           confidence=0.88),

    # ── SMTP ─────────────────────────────────────────────────────────────────
    BannerPattern("smtp", "Postfix",     r"Postfix[_\s]?([\d.]+)?",   confidence=0.95),
    BannerPattern("smtp", "Sendmail",    r"Sendmail[_\s]?([\d.]+)?",  confidence=0.93),
    BannerPattern("smtp", "Exim",        r"Exim[_\s]?([\d.]+)?",      confidence=0.93),
    BannerPattern("smtp", "Exchange",    r"Microsoft ESMTP",            confidence=0.90, version_group=0),
    BannerPattern("smtp", "hMailServer", r"hMailServer",                confidence=0.88, version_group=0),
    BannerPattern("smtp", "MailEnable",  r"MailEnable",                 confidence=0.87, version_group=0),
    BannerPattern("smtp", "Haraka",      r"Haraka",                     confidence=0.85, version_group=0),

    # ── IMAP / POP3 ──────────────────────────────────────────────────────────
    BannerPattern("imap", "Dovecot",     r"Dovecot",                    confidence=0.93, version_group=0),
    BannerPattern("imap", "Cyrus",       r"Cyrus IMAP[_\s]?([\d.]+)?", confidence=0.90),
    BannerPattern("imap", "Courier",     r"Courier-IMAP",               confidence=0.88, version_group=0),
    BannerPattern("pop3", "Dovecot POP3",r"Dovecot",                    confidence=0.90, version_group=0),

    # ── Databases ────────────────────────────────────────────────────────────
    BannerPattern("generic", "MySQL",      r"(?:mysql|MariaDB)[_\s]?([\d.]+)?",  confidence=0.90),
    BannerPattern("generic", "PostgreSQL", r"PostgreSQL[_\s]?([\d.]+)?",         confidence=0.90),
    BannerPattern("generic", "MongoDB",    r"MongoDB",                            confidence=0.88, version_group=0),
    BannerPattern("generic", "Redis",      r"Redis[_\s]?([\d.]+)?",              confidence=0.92),
    BannerPattern("generic", "Memcached",  r"memcached[_\s]?([\d.]+)?",          confidence=0.90),
    BannerPattern("generic", "Elasticsearch", r"elasticsearch[_\s]?([\d.]+)?",   confidence=0.88),

    # ── VPN / Remote access ───────────────────────────────────────────────────
    BannerPattern("generic", "OpenVPN",   r"OpenVPN",                            confidence=0.88, version_group=0),
    BannerPattern("generic", "Cisco VPN", r"Cisco VPN",                          confidence=0.88, version_group=0),
    BannerPattern("generic", "Fortinet",  r"FortiGate|fortinet",                 confidence=0.87, version_group=0),
    BannerPattern("generic", "Pulse",     r"Pulse Secure",                       confidence=0.87, version_group=0),
]

# Known-vulnerable version ranges (software: [bad_versions...])
_VULNERABLE_VERSIONS: dict[str, list[str]] = {
    "OpenSSH":   ["5.", "6.", "7.0", "7.1", "7.2", "7.3", "7.4"],
    "Apache":    ["2.2.", "2.0.", "1."],
    "nginx":     ["1.0.", "1.2.", "1.4.", "1.6.", "1.8.", "1.10.", "1.12."],
    "vsftpd":    ["2.3.4"],   # famous backdoor
    "ProFTPD":   ["1.2.", "1.3.0", "1.3.1", "1.3.2", "1.3.3"],
    "IIS":       ["5.", "6.", "7."],
    "PHP":       ["5.", "7.0", "7.1", "7.2"],
    "Exim":      ["4.8", "4.7", "4.6", "4.5"],
}


# ─────────────────────────────────────────────────────────────────────────────
# Result model
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class BannerResult:
    """Parsed intelligence from a single service banner."""
    port:            int
    raw_banner:      str
    protocol:        str          = "unknown"
    software:        str          = "unknown"
    version:         str          = ""
    confidence:      float        = 0.0
    risk_level:      str          = ""     # "" | LOW | MEDIUM | HIGH | CRITICAL
    risk_reason:     str          = ""
    normalized:      str          = ""     # cleaned, version-stripped label
    tags:            list[str]    = field(default_factory=list)

    def is_identified(self) -> bool:
        return self.software != "unknown" and self.confidence > 0

    def __str__(self) -> str:
        ver   = f" {self.version}" if self.version else ""
        risk  = f"  [{self.risk_level}]" if self.risk_level else ""
        conf  = f"  ({self.confidence:.0%})"
        return f":{self.port} {self.software}{ver}{risk}{conf}"

    def to_dict(self) -> dict:
        return {
            "port":       self.port,
            "raw_banner": self.raw_banner[:120],
            "protocol":   self.protocol,
            "software":   self.software,
            "version":    self.version,
            "confidence": self.confidence,
            "risk_level": self.risk_level,
            "risk_reason": self.risk_reason,
            "normalized": self.normalized,
            "tags":       self.tags,
        }


# ─────────────────────────────────────────────────────────────────────────────
# BannerAnalyzer
# ─────────────────────────────────────────────────────────────────────────────

class BannerAnalyzer:
    """
    Parses service banners into structured BannerResult objects.

    Designed to be used both standalone and as a post-processing step
    inside ServiceCorrelator / ExecutionEngine.
    """

    def analyze(self, port: int, banner: str) -> BannerResult:
        """
        Parse a single banner string.

        Args:
            port:   Port number (used for protocol inference)
            banner: Raw banner string captured from the service

        Returns BannerResult — never raises.
        """
        if not banner:
            return BannerResult(port=port, raw_banner="", software="unknown")

        try:
            return self._parse(port, banner)
        except Exception as exc:
            log.debug(f"Banner parse error on port {port}: {exc}")
            return BannerResult(port=port, raw_banner=banner, software="unknown")

    def analyze_all(self, ports: list) -> list[BannerResult]:
        """
        Analyze all Port objects from a ReconResult.ports list.
        Skips ports with empty banners and non-open state.
        """
        results: list[BannerResult] = []
        for port in ports:
            if not hasattr(port, "banner"):
                continue
            # Combine banner + version for richer matching
            combined = " ".join(filter(None, [
                getattr(port, "banner", ""),
                getattr(port, "version", ""),
                getattr(port, "service", ""),
            ]))
            if combined.strip():
                results.append(self.analyze(port.number, combined))
        return results

    def summarize(self, results: list[BannerResult]) -> dict:
        """
        Return aggregate statistics over a list of BannerResults.

        Useful for the infrastructure intelligence panel.
        """
        identified  = [r for r in results if r.is_identified()]
        risky       = [r for r in results if r.risk_level]
        software_counts: dict[str, int] = {}
        for r in identified:
            software_counts[r.software] = software_counts.get(r.software, 0) + 1

        return {
            "total_ports":      len(results),
            "identified":       len(identified),
            "risky":            len(risky),
            "software_counts":  software_counts,
            "risk_breakdown":   {
                level: sum(1 for r in risky if r.risk_level == level)
                for level in ("CRITICAL", "HIGH", "MEDIUM", "LOW")
            },
        }

    # ── Internal ──────────────────────────────────────────────────────────────

    def _parse(self, port: int, banner: str) -> BannerResult:
        banner_lower = banner.lower()
        result = BannerResult(
            port       = port,
            raw_banner = banner,
            protocol   = _infer_protocol(port, banner_lower),
        )

        # Try each pattern
        best_match: Optional[tuple[BannerPattern, re.Match]] = None
        for pattern in _PATTERNS:
            m = re.search(pattern.regex, banner, re.IGNORECASE)
            if m:
                # Prefer patterns with higher confidence / longer match
                if best_match is None or pattern.confidence > best_match[0].confidence:
                    best_match = (pattern, m)

        if best_match:
            pat, m = best_match
            result.software   = pat.software
            result.protocol   = pat.protocol if pat.protocol != "generic" else result.protocol
            result.confidence = pat.confidence

            # Version extraction
            try:
                ver = m.group(pat.version_group) if pat.version_group > 0 else ""
                result.version = (ver or "").strip()
            except IndexError:
                result.version = ""

        # Fallback: best-effort from raw banner
        if result.software == "unknown":
            result = self._fallback_parse(result, banner_lower)

        # Normalised label
        result.normalized = f"{result.software} {result.version}".strip()

        # Risk annotation
        self._annotate_risk(result)

        # Tags
        result.tags = self._generate_tags(result)

        return result

    def _fallback_parse(self, result: BannerResult, banner_lower: str) -> BannerResult:
        """
        When no pattern matched, attempt simple keyword extraction.
        Produces lower-confidence results.
        """
        keywords = {
            "ssh": "SSH", "ftp": "FTP", "smtp": "SMTP",
            "imap": "IMAP", "pop3": "POP3", "http": "HTTP",
            "mysql": "MySQL", "redis": "Redis", "mongodb": "MongoDB",
        }
        for kw, name in keywords.items():
            if kw in banner_lower:
                result.software   = name
                result.confidence = 0.50
                break
        return result

    def _annotate_risk(self, result: BannerResult) -> None:
        """Check version against known-vulnerable list and set risk fields."""
        if not result.version or not result.is_identified():
            return

        vuln_versions = _VULNERABLE_VERSIONS.get(result.software, [])
        for bad_ver in vuln_versions:
            if result.version.startswith(bad_ver):
                result.risk_level  = "HIGH"
                result.risk_reason = (
                    f"{result.software} {result.version} is known-vulnerable; "
                    f"check CVE database for applicable patches."
                )
                return

        # Version too old heuristic (single-digit major)
        if result.version and result.version[0].isdigit():
            major = int(result.version.split(".")[0])
            if major < 2 and result.software in ("nginx", "Apache", "IIS"):
                result.risk_level  = "MEDIUM"
                result.risk_reason = f"Major version {major} is legacy."

    def _generate_tags(self, result: BannerResult) -> list[str]:
        """Generate classification tags for this banner result."""
        tags: list[str] = []

        if result.protocol in ("ssh",):
            tags.append("SSH")
        if result.protocol in ("ftp",):
            tags.append("FTP")
        if result.protocol in ("smtp",):
            tags.append("MAIL")
        if result.protocol in ("http",):
            tags.append("HTTP")
        if result.risk_level in ("HIGH", "CRITICAL"):
            tags.append("VULNERABLE")
        if result.software != "unknown":
            tags.append("IDENTIFIED")

        return tags


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _infer_protocol(port: int, banner_lower: str) -> str:
    """Infer protocol from port number and banner content."""
    _port_protocols = {
        21: "ftp", 22: "ssh", 23: "telnet", 25: "smtp",
        110: "pop3", 143: "imap", 465: "smtp", 587: "smtp",
        636: "ldap", 993: "imap", 995: "pop3",
        80: "http", 443: "http", 8080: "http", 8443: "http",
    }
    # Banner-first
    if "ssh-" in banner_lower:
        return "ssh"
    if banner_lower.startswith("220 ") or "smtp" in banner_lower:
        return "smtp"
    if banner_lower.startswith("220-") and "ftp" in banner_lower:
        return "ftp"
    if banner_lower.startswith("* ok") or "imap" in banner_lower:
        return "imap"
    if banner_lower.startswith("+ok") or "pop3" in banner_lower:
        return "pop3"
    if "http/" in banner_lower or "<html" in banner_lower:
        return "http"
    return _port_protocols.get(port, "generic")
