"""
ReconX — aquatone wrapper.

Aquatone takes screenshots of web pages, clusters visually similar pages,
and produces an interactive HTML report. Excellent for triaging large
numbers of discovered web services by similarity.

Stage 3 — Active Visual Web Reconnaissance.
"""
from __future__ import annotations
import json
import os
import re
import time
from pathlib import Path
from typing import Optional

from ..base import BaseTool
from ...models.tool_result import ParsedFinding, RunStatus, ToolRunResult


class AquatoneTool(BaseTool):

    NAME         = "aquatone"
    BINARY       = "aquatone"
    CATEGORY     = "screenshot"
    STAGE        = 3
    PRIORITY     = 20
    PASSIVE      = False
    TIMEOUT      = 300
    DEPENDENCIES: list[str] = []
    INSTALL_CMD  = (
        "# Download from: https://github.com/michenriksen/aquatone/releases\n"
        "wget https://github.com/michenriksen/aquatone/releases/latest/download/"
        "aquatone_linux_amd64_*.zip && unzip *.zip && sudo mv aquatone /usr/local/bin/"
    )

    # ── run ───────────────────────────────────────────────────────────────────

    def run(
        self,
        target: str,
        *,
        urls_file:   Optional[str]      = None,
        urls:        Optional[list[str]] = None,
        output_dir:  str                = "reports/aquatone",
        threads:     int                = 5,
        timeout:     int                = 30,
        ports:       Optional[str]      = None,   # "small"|"medium"|"large"|"xlarge"
        scan_timeout: int               = 100,
        **kwargs,
    ) -> ToolRunResult:
        """
        Args:
            target:       Domain or single URL.
            urls_file:    File of URLs to screenshot (one per line).
            urls:         List of URLs passed directly.
            output_dir:   Directory for screenshots and report.
            threads:      Concurrent screenshot workers.
            timeout:      Per-page screenshot timeout (seconds).
            ports:        Port scan scope preset.
            scan_timeout: HTTP request timeout (ms).
        """
        if s := self.skip_if_unavailable():
            return s

        Path(output_dir).mkdir(parents=True, exist_ok=True)
        t0 = time.perf_counter()

        # Build stdin input
        if urls:
            stdin_data = "\n".join(urls)
        elif urls_file and os.path.exists(urls_file):
            stdin_data = Path(urls_file).read_text()
        else:
            stdin_data = self.ensure_scheme(target)

        args = [
            "-out",          output_dir,
            "-threads",      str(threads),
            "-timeout",      str(timeout),
            "-scan-timeout", str(scan_timeout),
            "-silent",
        ]
        if ports:
            args += ["-ports", ports]

        res = self.exec(args, stdin_data=stdin_data,
                        timeout_s=float(self.timeout), expected_codes=(0, 1))
        dur = time.perf_counter() - t0

        if res.timed_out:
            data = self._collect_partial(output_dir)
            r = self.build_result(data, self._build_findings(data),
                                  duration_s=dur, returncode=0)
            r.notes = "Timed out — partial screenshots collected."
            return r
        if res.returncode == 127:
            return ToolRunResult.skipped(self.NAME, res.stderr)

        data = self._collect_results(output_dir, res.stdout)
        findings = self._build_findings(data)
        r = self.build_result(data, findings, stdout=res.stdout,
                              duration_s=dur, returncode=res.returncode)
        if not data["screenshots"]: r.status = RunStatus.NO_OUTPUT
        return r

    # ── parse_output ──────────────────────────────────────────────────────────

    def parse_output(self, raw: str, **kwargs) -> dict:
        screenshots: list[dict] = []
        url_re = re.compile(r"(https?://[^\s]+)")
        for line in raw.splitlines():
            line = line.strip()
            if "screenshot" in line.lower() or "http" in line.lower():
                for url in url_re.findall(line):
                    screenshots.append({"url": url, "path": "", "title": "",
                                        "status": 200, "technologies": []})
        return {"screenshots": screenshots, "report": "", "count": len(screenshots)}

    # ── internal ──────────────────────────────────────────────────────────────

    def _collect_results(self, out_dir: str, stdout: str) -> dict:
        sessions_path = os.path.join(out_dir, "aquatone_session.json")
        if os.path.exists(sessions_path):
            return self._parse_session(sessions_path, out_dir)
        return self._collect_partial(out_dir)

    def _parse_session(self, session_path: str, out_dir: str) -> dict:
        try:
            session = json.loads(Path(session_path).read_text())
            screenshots: list[dict] = []
            for page in session.get("pages", {}).values():
                screenshots.append({
                    "url":          page.get("url", ""),
                    "path":         os.path.join(out_dir, page.get("screenshotPath", "")),
                    "title":        page.get("pageTitle", ""),
                    "status":       page.get("status", 0),
                    "technologies": page.get("detectedTechnologies", []),
                    "login":        self._is_login(page.get("pageTitle", "")),
                })
            report = os.path.join(out_dir, "aquatone_report.html")
            return {
                "screenshots": screenshots,
                "report":      report if os.path.exists(report) else "",
                "count":       len(screenshots),
            }
        except Exception:
            return self._collect_partial(out_dir)

    @staticmethod
    def _collect_partial(out_dir: str) -> dict:
        shots: list[dict] = []
        if os.path.isdir(out_dir):
            for root, _, files in os.walk(out_dir):
                for f in files:
                    if f.endswith(".png"):
                        shots.append({"url": "", "path": os.path.join(root, f),
                                      "title": "", "status": 0, "technologies": [],
                                      "login": False})
        return {"screenshots": shots, "report": "", "count": len(shots)}

    @staticmethod
    def _is_login(title: str) -> bool:
        return any(k in title.lower() for k in ("login", "sign in", "signin", "auth", "password"))

    def _build_findings(self, data: dict) -> list[ParsedFinding]:
        findings = []
        for s in data.get("screenshots", []):
            ftype = "login_page" if s.get("login") else "web_screenshot"
            findings.append(ParsedFinding(
                finding_type=ftype, value=s.get("url", s.get("path", "")),
                source=self.NAME, confidence=0.9,
                metadata={"title": s.get("title", ""),
                          "screenshot_path": s.get("path", ""),
                          "technologies": s.get("technologies", [])},
            ))
        return findings
