"""
ReconX — gowitness wrapper.

gowitness is a fast, Go-based web screenshot utility using Chrome.
Supports single URLs, files, Nmap XML, and Nessus XML as input.
Stores results in SQLite for querying and generates HTML reports.

Stage 3 — Active Visual Web Reconnaissance.
"""
from __future__ import annotations
import json
import os
import re
import sqlite3
import time
from pathlib import Path
from typing import Optional

from ..base import BaseTool
from ...models.tool_result import ParsedFinding, RunStatus, ToolRunResult


class GoWitnessTool(BaseTool):

    NAME         = "gowitness"
    BINARY       = "gowitness"
    CATEGORY     = "screenshot"
    STAGE        = 3
    PRIORITY     = 22
    PASSIVE      = False
    TIMEOUT      = 300
    DEPENDENCIES: list[str] = []
    INSTALL_CMD  = "go install github.com/sensepost/gowitness@latest"

    # ── run ───────────────────────────────────────────────────────────────────

    def run(
        self,
        target: str,
        *,
        urls:        Optional[list[str]] = None,
        urls_file:   Optional[str]       = None,
        output_dir:  str                 = "reports/gowitness",
        threads:     int                 = 4,
        timeout:     int                 = 10,
        delay:       float               = 0.0,
        disable_db:  bool                = False,
        user_agent:  Optional[str]       = None,
        **kwargs,
    ) -> ToolRunResult:
        """
        Args:
            target:      Single URL or domain to screenshot.
            urls:        List of URLs (batch mode).
            urls_file:   File of URLs to process.
            output_dir:  Storage directory for screenshots and DB.
            threads:     Concurrent Chrome workers.
            timeout:     Per-page timeout in seconds.
            delay:       Delay after page load before screenshot (seconds).
            disable_db:  Skip SQLite storage.
            user_agent:  Custom User-Agent string.
        """
        if s := self.skip_if_unavailable():
            return s

        Path(output_dir).mkdir(parents=True, exist_ok=True)
        db_path = os.path.join(output_dir, "gowitness.db")
        t0      = time.perf_counter()

        # Determine subcommand
        if urls or urls_file:
            tmp_file = "/tmp/gowitness_input.txt"
            if urls:
                Path(tmp_file).write_text("\n".join(urls))
            else:
                tmp_file = urls_file

            args = ["file", "-f", tmp_file,
                    "--screenshot-path", output_dir,
                    "--threads", str(threads),
                    "--timeout", str(timeout)]
        else:
            url = self.ensure_scheme(target)
            args = ["single", url,
                    "--screenshot-path", output_dir,
                    "--timeout", str(timeout)]

        if not disable_db:
            args += ["--db-path", db_path]
        if delay:
            args += ["--delay", str(int(delay * 1000))]
        if user_agent:
            args += ["--user-agent", user_agent]

        res = self.exec(args, timeout_s=float(self.timeout), expected_codes=(0, 1))
        dur = time.perf_counter() - t0

        if res.timed_out:
            data = self._collect_screenshots(output_dir, db_path)
            r = self.build_result(data, self._build_findings(data),
                                  duration_s=dur, returncode=0)
            r.notes = "Partial results — timed out."
            return r
        if res.returncode == 127:
            return ToolRunResult.skipped(self.NAME, res.stderr)

        data = self._collect_screenshots(output_dir, db_path)
        findings = self._build_findings(data)
        r = self.build_result(data, findings, stdout=res.stdout,
                              duration_s=dur, returncode=res.returncode)
        if not data["screenshots"]: r.status = RunStatus.NO_OUTPUT
        return r

    # ── parse_output ──────────────────────────────────────────────────────────

    def parse_output(self, raw: str, **kwargs) -> dict:
        screenshots: list[dict] = []
        url_re = re.compile(r"(https?://[^\s]+)")
        ansi_re = re.compile(r"\x1b\[[0-9;]*[A-Za-z]")
        for line in raw.splitlines():
            line = ansi_re.sub("", line).strip()
            if "screenshot" in line.lower():
                for url in url_re.findall(line):
                    screenshots.append({"url": url, "path": "", "title": "",
                                        "status": 0, "login": False})
        return {"screenshots": screenshots, "count": len(screenshots),
                "report_dir": ""}

    # ── internal ──────────────────────────────────────────────────────────────

    def _collect_screenshots(self, out_dir: str, db_path: str) -> dict:
        """Read from SQLite DB if available, else walk filesystem."""
        screenshots: list[dict] = []

        if os.path.exists(db_path):
            try:
                conn = sqlite3.connect(db_path)
                conn.row_factory = sqlite3.Row
                cur = conn.cursor()
                cur.execute(
                    "SELECT url, screenshot_path, title, response_code "
                    "FROM urls WHERE screenshot_path IS NOT NULL"
                )
                for row in cur.fetchall():
                    screenshots.append({
                        "url":    row["url"] or "",
                        "path":   os.path.join(out_dir, row["screenshot_path"] or ""),
                        "title":  row["title"] or "",
                        "status": row["response_code"] or 0,
                        "login":  self._is_login(row["title"] or ""),
                    })
                conn.close()
            except Exception:
                pass

        if not screenshots:
            # Fallback: filesystem walk
            for root, _, files in os.walk(out_dir):
                for f in files:
                    if f.endswith(".png"):
                        screenshots.append({
                            "url": "", "path": os.path.join(root, f),
                            "title": "", "status": 0, "login": False,
                        })

        return {"screenshots": screenshots, "count": len(screenshots),
                "report_dir": out_dir}

    @staticmethod
    def _is_login(title: str) -> bool:
        return any(k in title.lower() for k in ("login", "sign in", "auth", "password", "portal"))

    def _build_findings(self, data: dict) -> list[ParsedFinding]:
        findings = []
        for s in data.get("screenshots", []):
            ftype = "login_page" if s.get("login") else "web_screenshot"
            findings.append(ParsedFinding(
                finding_type=ftype,
                value=s.get("url") or s.get("path", ""),
                source=self.NAME, confidence=0.9,
                metadata={"title": s.get("title", ""),
                          "screenshot_path": s.get("path", ""),
                          "http_status": s.get("status", 0)},
            ))
        return findings
