"""
ReconX — tlsx wrapper.

tlsx is a fast TLS data extraction tool that grabs certificate information,
cipher suites, TLS versions, and JARM fingerprints. Useful for
infrastructure correlation and certificate-based subdomain discovery.

Stage 2 — Active TLS Fingerprinting.
"""
from __future__ import annotations
import json
import re
import ssl
import socket
import time
from typing import Optional

from ..base import BaseTool
from ...models.tool_result import ParsedFinding, RunStatus, ToolRunResult


class TLSXTool(BaseTool):

    NAME         = "tlsx"
    BINARY       = "tlsx"
    CATEGORY     = "certs"
    STAGE        = 2
    PRIORITY     = 20
    PASSIVE      = False
    TIMEOUT      = 120
    DEPENDENCIES: list[str] = []
    INSTALL_CMD  = "go install github.com/projectdiscovery/tlsx/cmd/tlsx@latest"

    # ── run ───────────────────────────────────────────────────────────────────

    def run(
        self,
        target: str,
        *,
        ports:        Optional[list[int]] = None,
        hosts:        Optional[list[str]] = None,
        san:          bool = True,    # extract Subject Alternative Names
        cn:           bool = True,    # extract Common Name
        jarm:         bool = False,   # JARM fingerprint (slow)
        json_output:  bool = True,
        timeout:      int  = 5,
        **kwargs,
    ) -> ToolRunResult:
        """
        Args:
            target:   Host or CIDR to TLS-probe.
            ports:    Ports to probe (default: 443, 8443).
            hosts:    Additional hosts list.
            san:      Extract SAN names from certificates.
            cn:       Extract Common Name.
            jarm:     Generate JARM fingerprint (slower).
            timeout:  Per-connection timeout (seconds).
        """
        t0 = time.perf_counter()
        probe_ports = ports or [443, 8443]

        # ── Binary path ───────────────────────────────────────────────────────
        if self.is_available():
            args = ["-host", target, "-json", "-silent",
                    "-timeout", str(timeout)]
            if ports:
                args += ["-port", ",".join(str(p) for p in ports)]
            if san:
                args.append("-san")
            if cn:
                args.append("-cn")
            if jarm:
                args.append("-jarm")
            if hosts:
                import tempfile
                tf = tempfile.NamedTemporaryFile(delete=False, suffix=".txt", mode="w")
                tf.write("\n".join(hosts))
                tf.close()
                args += ["-list", tf.name]

            res = self.exec(args, timeout_s=float(self.timeout), expected_codes=(0, 1))
            dur = time.perf_counter() - t0
            if res.timed_out:
                return ToolRunResult.timeout(self.NAME, dur, self.timeout)
            if res.returncode == 127:
                return ToolRunResult.skipped(self.NAME, res.stderr)

            data = self.parse_output(res.stdout)
            findings = self._build_findings(data)
            r = self.build_result(data, findings, stdout=res.stdout,
                                  duration_s=dur, returncode=res.returncode)
            if not data["certs"]: r.status = RunStatus.NO_OUTPUT
            return r

        # ── Pure-Python TLS probe fallback ────────────────────────────────────
        self._log("info", "tlsx binary not found — using Python ssl fallback")
        hosts_to_probe = [target] + (hosts or [])
        data = self._python_tls_probe(hosts_to_probe, probe_ports, timeout)
        dur  = time.perf_counter() - t0
        findings = self._build_findings(data)
        r = self.build_result(data, findings, duration_s=dur, returncode=0)
        if not data["certs"]: r.status = RunStatus.NO_OUTPUT
        return r

    # ── parse_output ──────────────────────────────────────────────────────────

    def parse_output(self, raw: str, **kwargs) -> dict:
        if not raw.strip():
            return {"certs": [], "subdomains": [], "count": 0}

        certs:      list[dict] = []
        subdomains: set[str]   = set()

        for line in raw.splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
                san_list = obj.get("san", obj.get("subject_an", []))
                cn       = obj.get("cn", obj.get("subject_cn", ""))
                host     = obj.get("host", "")

                entry = {
                    "host":         host,
                    "cn":           cn,
                    "san":          san_list,
                    "issuer":       obj.get("issuer_cn", obj.get("issuer", "")),
                    "not_before":   obj.get("not_before", ""),
                    "not_after":    obj.get("not_after",  ""),
                    "tls_version":  obj.get("tls_version", obj.get("version", "")),
                    "jarm":         obj.get("jarm", ""),
                    "cipher":       obj.get("cipher", ""),
                }
                certs.append(entry)

                for name in [cn] + san_list:
                    name = name.lstrip("*.").lower()
                    if "." in name:
                        subdomains.add(name)
            except Exception:
                pass

        return {
            "certs":      certs,
            "subdomains": sorted(subdomains),
            "count":      len(certs),
        }

    # ── internal ──────────────────────────────────────────────────────────────

    def _python_tls_probe(
        self, hosts: list[str], ports: list[int], timeout: int
    ) -> dict:
        certs:      list[dict] = []
        subdomains: set[str]   = set()

        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode    = ssl.CERT_NONE

        for host in hosts:
            for port in ports:
                try:
                    with socket.create_connection((host, port), timeout=timeout) as raw_sock:
                        with ctx.wrap_socket(raw_sock, server_hostname=host) as ssock:
                            cert = ssock.getpeercert()
                            tls_ver = ssock.version()

                    # Extract fields
                    cn  = dict(x for y in cert.get("subject", []) for x in y).get("commonName", "")
                    san = [v for _, v in cert.get("subjectAltName", [])
                           if not v.startswith("IP:")]
                    issuer = dict(x for y in cert.get("issuer", []) for x in y).get("commonName", "")

                    certs.append({
                        "host": host, "cn": cn, "san": san, "issuer": issuer,
                        "not_before": str(cert.get("notBefore", "")),
                        "not_after":  str(cert.get("notAfter", "")),
                        "tls_version": tls_ver, "jarm": "", "cipher": "",
                    })
                    for name in [cn] + san:
                        name = name.lstrip("*.").lower()
                        if "." in name:
                            subdomains.add(name)
                except Exception:
                    pass

        return {"certs": certs, "subdomains": sorted(subdomains), "count": len(certs)}

    def _build_findings(self, data: dict) -> list[ParsedFinding]:
        findings = []
        for cert in data.get("certs", []):
            findings.append(ParsedFinding(
                finding_type="tls_certificate",
                value=cert.get("host", ""),
                source=self.NAME, confidence=1.0,
                metadata={"cn": cert.get("cn",""), "san_count": len(cert.get("san",[])),
                          "issuer": cert.get("issuer",""), "tls_version": cert.get("tls_version",""),
                          "jarm": cert.get("jarm","")},
            ))
        for sub in data.get("subdomains", []):
            findings.append(ParsedFinding(
                finding_type="subdomain", value=sub,
                source=self.NAME, confidence=0.93,
                metadata={"source": "tls_san"},
            ))
        return findings
