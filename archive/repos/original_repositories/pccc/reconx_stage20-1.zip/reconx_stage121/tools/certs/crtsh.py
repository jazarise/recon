"""
ReconX — crt.sh certificate transparency wrapper.

Queries the crt.sh certificate transparency log aggregator for all
SSL/TLS certificates issued for a domain. Discovers subdomains from
certificate SANs (Subject Alternative Names) — passive, no target traffic.

Stage 1 — Passive Certificate Intelligence.
"""
from __future__ import annotations
import json
import re
import ssl
import time
import urllib.parse
import urllib.request
from typing import Optional

from ..base import BaseTool
from ...models.tool_result import ParsedFinding, RunStatus, ToolRunResult

_CRTSH_API = "https://crt.sh/?q={query}&output=json"


class CrtshTool(BaseTool):

    NAME         = "crt.sh"
    BINARY       = "curl"         # no dedicated binary — uses public API
    CATEGORY     = "certs"
    STAGE        = 1
    PRIORITY     = 5
    PASSIVE      = True
    TIMEOUT      = 60
    DEPENDENCIES: list[str] = []
    INSTALL_CMD  = "No installation required — uses crt.sh public API"

    # ── run ───────────────────────────────────────────────────────────────────

    def run(
        self,
        target: str,
        *,
        wildcard:      bool = True,    # query *.domain.com (all subdomains)
        expired:       bool = False,   # include expired certificates
        deduplicate:   bool = True,
        max_results:   int  = 5000,
        **kwargs,
    ) -> ToolRunResult:
        """
        Args:
            target:      Domain to query (e.g. example.com).
            wildcard:    Prefix with % for wildcard match (all subdomains).
            expired:     Include expired certificates.
            deduplicate: Collapse duplicate names.
            max_results: Cap on results returned.
        """
        if self.classify_target(target) != "domain":
            return ToolRunResult.invalid_target(self.NAME, target, "Requires a domain.")

        t0 = time.perf_counter()
        query = f"%.{target}" if wildcard else target
        data, err = self._fetch_crtsh(query, expired, deduplicate, max_results)
        dur = time.perf_counter() - t0

        if err and not data["subdomains"]:
            return self.fail("api_error", err, duration_s=dur)

        findings = self._build_findings(data)
        r = self.build_result(data, findings, duration_s=dur, returncode=0)
        if not data["subdomains"]: r.status = RunStatus.NO_OUTPUT
        return r

    # ── parse_output ──────────────────────────────────────────────────────────

    def parse_output(self, raw: str, **kwargs) -> dict:
        if not raw.strip():
            return {"subdomains": [], "certs": [], "count": 0}
        try:
            data = json.loads(raw)
            return self._process_crtsh_json(data, True, 5000)
        except Exception:
            return {"subdomains": [], "certs": [], "count": 0}

    # ── internal ──────────────────────────────────────────────────────────────

    def _fetch_crtsh(
        self, query: str, expired: bool, dedup: bool, max_results: int
    ) -> tuple[dict, str]:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode    = ssl.CERT_NONE
        opener = urllib.request.build_opener(urllib.request.HTTPSHandler(context=ctx))

        url = _CRTSH_API.format(query=urllib.parse.quote(query))
        try:
            req = urllib.request.Request(
                url, headers={
                    "User-Agent": "ReconX/2.0 (crtsh-passive)",
                    "Accept":     "application/json",
                }
            )
            with opener.open(req, timeout=30) as resp:
                body = json.loads(resp.read().decode("utf-8", errors="replace"))
            return self._process_crtsh_json(body, dedup, max_results), ""
        except Exception as e:
            return {"subdomains": [], "certs": [], "count": 0}, str(e)

    @staticmethod
    def _process_crtsh_json(data: list, dedup: bool, max_results: int) -> dict:
        subdomains: set[str] = set()
        certs:      list[dict] = []
        domain_re = re.compile(
            r"\b([a-zA-Z0-9\*](?:[a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?"
            r"(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?)+\.[a-zA-Z]{2,})\b"
        )

        for cert in data[:max_results]:
            if not isinstance(cert, dict):
                continue
            names_raw = cert.get("name_value", cert.get("common_name", ""))
            issuer    = cert.get("issuer_name", "")
            not_before = cert.get("not_before", "")
            not_after  = cert.get("not_after",  "")

            names = [n.strip().lower() for n in names_raw.splitlines()]
            for name in names:
                # Skip wildcards that aren't useful
                if name.startswith("*."):
                    name = name[2:]
                for m in domain_re.findall(name):
                    subdomains.add(m.lower())

            certs.append({
                "names":      names,
                "issuer":     issuer,
                "not_before": not_before,
                "not_after":  not_after,
                "id":         cert.get("id", ""),
            })

        subs = sorted(subdomains)
        return {"subdomains": subs, "certs": certs[:200], "count": len(subs)}

    def _build_findings(self, data: dict) -> list[ParsedFinding]:
        return [
            ParsedFinding(
                finding_type="subdomain", value=sub,
                source=self.NAME, confidence=0.92,
                metadata={"source": "certificate_transparency"},
            )
            for sub in data.get("subdomains", [])
        ]
