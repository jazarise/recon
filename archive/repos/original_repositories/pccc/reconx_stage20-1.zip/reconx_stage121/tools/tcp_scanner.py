"""
ReconX — Pure-Python TCP connect scanner.
Used as fallback when masscan is unavailable or no root access.
"""
from __future__ import annotations
import logging
import socket
from concurrent.futures import ThreadPoolExecutor, as_completed

logger = logging.getLogger("reconx.tools.tcp_scanner")


class TCPScanner:
    """Multi-threaded TCP connect scanner — no external binary required."""

    def __init__(self, threads: int = 80, timeout: float = 2.0, retries: int = 1):
        self.threads = threads
        self.timeout = timeout
        self.retries = retries

    def run(self, target: str, port_range: str = "1-1000", **kwargs) -> dict:
        start, end = self._parse_range(port_range)
        ports = range(start, end + 1)

        open_ports: list[int] = []

        with ThreadPoolExecutor(max_workers=self.threads) as pool:
            futures = {pool.submit(self._probe, target, p): p for p in ports}
            for future in as_completed(futures):
                result = future.result()
                if result:
                    open_ports.append(result)

        return {"open_ports": sorted(open_ports)}

    def _probe(self, target: str, port: int) -> int | None:
        for _ in range(self.retries):
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(self.timeout)
                rc = sock.connect_ex((target, port))
                sock.close()
                if rc == 0:
                    return port
            except Exception:
                pass
        return None

    @staticmethod
    def _parse_range(port_range: str) -> tuple[int, int]:
        if "-" in port_range:
            parts = port_range.split("-")
            return int(parts[0]), int(parts[1])
        return int(port_range), int(port_range)
