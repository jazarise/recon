"""
ReconX — Production-grade BaseTool.

Every tool in ReconX inherits from BaseTool.
It composes three mixins:
  SubprocessMixin   → safe binary execution
  ParserMixin       → structured output parsing
  ValidationMixin   → target validation

Contract every subclass must honour
────────────────────────────────────
1. Define class-level metadata constants (NAME, BINARY, …)
2. Implement run(target, **kwargs) → ToolRunResult
3. Implement parse_output(raw) → dict  (tool-specific schema)
4. Call self.validate_or_fail(target) at the top of run()

Subclasses must NEVER:
  - call subprocess directly (use self.exec())
  - return raw strings from run()
  - raise exceptions from run() (return ToolRunResult.failure() instead)
  - print() anything (use self._log())
"""
from __future__ import annotations
import logging
import time
import traceback
from abc import ABC, abstractmethod
from typing import Optional

from ..models.tool_result import (
    ExecutionMetrics, ParsedFinding, RunStatus, ToolError, ToolRunResult,
)
from .mixins.subprocess_mixin import SubprocessMixin
from .mixins.parser_mixin     import ParserMixin
from .mixins.validation_mixin import ValidationMixin

logger = logging.getLogger("reconx.tools.base")


class BaseTool(SubprocessMixin, ParserMixin, ValidationMixin, ABC):
    """
    Abstract base class for all ReconX tool wrappers.

    Metadata constants (override in subclass)
    ─────────────────────────────────────────
    NAME        Human-readable name           e.g. "Subfinder"
    BINARY      System binary name            e.g. "subfinder"
    CATEGORY    Tool category slug            e.g. "subdomain"
    STAGE       Execution stage (1–5)         e.g. 2
    PRIORITY    Order within stage (0=first)  e.g. 10
    PASSIVE     True = no packets to target   e.g. True
    TIMEOUT     Default timeout seconds       e.g. 120
    DEPENDENCIES List of tool NAME slugs that must succeed first
    INSTALL_CMD  How to install (for error messages)
    """

    # ── Metadata — override in every subclass ─────────────────────────────────
    NAME:         str       = ""
    BINARY:       str       = ""
    CATEGORY:     str       = ""
    STAGE:        int       = 0
    PRIORITY:     int       = 50
    PASSIVE:      bool      = False
    TIMEOUT:      int       = 60
    DEPENDENCIES: list[str] = []
    INSTALL_CMD:  str       = ""

    def __init__(
        self,
        timeout:         Optional[int] = None,
        binary_override: Optional[str] = None,
    ):
        self.timeout = timeout or self.TIMEOUT
        self._binary_override = binary_override
        self._logger = logging.getLogger(f"reconx.tools.{self.NAME.lower()}")

    # ══════════════════════════════════════════════════════════════════════════
    #  Abstract interface — must implement in subclass
    # ══════════════════════════════════════════════════════════════════════════

    @abstractmethod
    def run(self, target: str, **kwargs) -> ToolRunResult:
        """
        Execute the tool against target.
        Must return a ToolRunResult — never raise, never return None.
        """

    @abstractmethod
    def parse_output(self, raw: str, **kwargs) -> dict:
        """
        Parse raw tool output into a structured dict.
        Return {} on empty/invalid input — never raise.
        """

    # ══════════════════════════════════════════════════════════════════════════
    #  Convenience helpers for subclass run() implementations
    # ══════════════════════════════════════════════════════════════════════════

    def validate_or_fail(self, target: str) -> Optional[ToolRunResult]:
        """
        Call at start of run(). Returns a ToolRunResult.invalid_target() if
        the target is invalid, else None (meaning validation passed).

        Usage in subclass:
            fail = self.validate_or_fail(target)
            if fail: return fail
        """
        if not self.is_valid_target(target):
            self._log("warn", f"Invalid target: '{target}'")
            return ToolRunResult.invalid_target(
                self.NAME, target,
                f"Expected IP, domain, CIDR or URL. "
                f"Got: '{self.classify_target(target)}'"
            )
        return None

    def skip_if_unavailable(self) -> Optional[ToolRunResult]:
        """
        Call at start of run(). Returns ToolRunResult.skipped() if binary
        missing, else None (meaning tool is available).

        Usage in subclass:
            skip = self.skip_if_unavailable()
            if skip: return skip
        """
        if not self.is_available():
            msg = f"Binary '{self.BINARY}' not found on PATH."
            if self.INSTALL_CMD:
                msg += f" Install: {self.INSTALL_CMD}"
            self._log("debug", msg)
            return ToolRunResult.skipped(self.NAME, msg)
        return None

    def build_result(
        self,
        data:       dict,
        findings:   list[ParsedFinding],
        stdout:     str          = "",
        stderr:     str          = "",
        duration_s: float        = 0.0,
        returncode: int          = 0,
    ) -> ToolRunResult:
        """Build a SUCCESS ToolRunResult with metrics."""
        metrics = ExecutionMetrics(
            duration_s=duration_s,
            returncode=returncode,
        )
        return ToolRunResult.success(
            tool_name=self.NAME,
            data=data,
            findings=findings,
            metrics=metrics,
            stdout=stdout,
        )

    def fail(
        self,
        reason:     str,
        message:    str,
        stderr:     str   = "",
        duration_s: float = 0.0,
        tb:         str   = "",
    ) -> ToolRunResult:
        """Build a FAILED ToolRunResult."""
        self._log("warning", f"Failed [{reason}]: {message}")
        metrics = ExecutionMetrics(duration_s=duration_s, returncode=-1)
        return ToolRunResult.failure(
            tool_name=self.NAME,
            reason=reason,
            message=message,
            stderr=stderr,
            traceback=tb,
            metrics=metrics,
        )

    # ══════════════════════════════════════════════════════════════════════════
    #  Structured logging helpers
    # ══════════════════════════════════════════════════════════════════════════

    def _log(self, level: str, msg: str, *args) -> None:
        """Structured log with tool name prefix. Use instead of print()."""
        getattr(self._logger, level)(f"[{self.NAME}] {msg}", *args)

    # ── Rich-formatted status strings (used by scheduler UI) ─────────────────

    @property
    def display_name(self) -> str:
        return self.NAME or self.BINARY or type(self).__name__

    @property
    def meta_str(self) -> str:
        passive = "passive" if self.PASSIVE else "active"
        avail   = "✔" if self.is_available() else "✘"
        return (f"{avail} {self.NAME}  "
                f"[stage:{self.STAGE}  {passive}  timeout:{self.TIMEOUT}s]")

    def install_hint(self) -> str:
        if self.INSTALL_CMD:
            return f"Install {self.NAME}: {self.INSTALL_CMD}"
        return f"Install {self.NAME} and ensure '{self.BINARY}' is on PATH."

    # ══════════════════════════════════════════════════════════════════════════
    #  Learning-mode integration
    # ══════════════════════════════════════════════════════════════════════════

    def get_knowledge(self) -> Optional[dict]:
        """
        Load YAML knowledge file for this tool (if it exists).
        Returns None if not found — non-fatal.
        """
        try:
            from ..knowledge.loader import load_tool
            slug = self.NAME.lower().replace(" ", "_")
            return load_tool(slug)
        except Exception:
            return None

    # ══════════════════════════════════════════════════════════════════════════
    #  Safe run wrapper — catches any uncaught exception from subclass run()
    # ══════════════════════════════════════════════════════════════════════════

    def safe_run(self, target: str, **kwargs) -> ToolRunResult:
        """
        Calls self.run() and catches any unhandled exception.
        Scheduler calls this instead of run() directly.
        """
        t0 = time.perf_counter()
        try:
            result = self.run(target, **kwargs)
            return result
        except KeyboardInterrupt:
            duration = time.perf_counter() - t0
            return ToolRunResult.failure(
                tool_name=self.NAME,
                reason="interrupted",
                message="Interrupted by user",
                metrics=ExecutionMetrics(duration_s=duration),
            )
        except Exception as exc:
            duration = time.perf_counter() - t0
            tb = traceback.format_exc()
            self._log("error", f"Unhandled exception: {exc}")
            return ToolRunResult.failure(
                tool_name=self.NAME,
                reason="unhandled_exception",
                message=str(exc),
                traceback=tb,
                metrics=ExecutionMetrics(duration_s=duration),
            )
