"""
ReconX — RustScan ultra-fast port scanner (standardized).
Discovers open ports in seconds; chains directly to nmap for service detection.
"""
from __future__ import annotations
import json
import re
import time
from typing import Optional

from ..base import BaseTool
from ...config.settings import SCAN_CONFIG
from ...models.tool_result import ParsedFinding, RunStatus, ToolRunResult

_RE_OPEN = re.compile(r"Open\s+[\d.]+:(\d+)")


class RustScanTool(BaseTool):
    NAME         = "rustscan"
    BINARY       = "rustscan"
    CATEGORY     = "scanning"
    STAGE        = 3
    PRIORITY     = 6             # fastest discovery — runs first
    PASSIVE      = False
    TIMEOUT      = 120
    DEPENDENCIES: list[str] = []
    INSTALL_CMD  = "cargo install rustscan  OR  https://github.com/RustScan/RustScan/releases"

    def run(
        self,
        target:     str,
        *,
        batch_size: int  = 0,
        timeout_ms: int  = 0,
        port_range: str  = "",
        ulimit:     int  = 5000,
        **kwargs,
    ) -> ToolRunResult:
        if s := self.skip_if_unavailable(): return s
        if f := self.validate_or_fail(target): return f

        batch   = batch_size or SCAN_CONFIG.get("rustscan_batch",   2500)
        t_ms    = timeout_ms or SCAN_CONFIG.get("rustscan_timeout",  1500)
        p_range = port_range or SCAN_CONFIG.get("port_range_balanced", "1-10000")

        args = [
            "-a",      target,
            "-b",      str(batch),
            "--timeout", str(t_ms),
            "-r",      p_range,
            "--ulimit", str(ulimit),
            "-g",              # greppable output
            "--no-nmap",       # ReconX handles nmap separately
        ]

        t0  = time.perf_counter()
        res = self.exec(args, timeout_s=float(self.timeout), expected_codes=(0, 1))
        dur = time.perf_counter() - t0

        if res.timed_out:
            return ToolRunResult.timeout(self.NAME, dur, self.timeout)
        if res.returncode == 127:
            return ToolRunResult.skipped(self.NAME, res.stderr)

        data     = self.parse_output(res.stdout)
        findings = [self._finding("port", str(p)) for p in data["open_ports"]]

        r = self.build_result(data, findings, stdout=res.stdout,
                              duration_s=dur, returncode=res.returncode)
        if not data["open_ports"]:
            r.status = RunStatus.NO_OUTPUT
        return r

    def parse_output(self, raw: str, **kwargs) -> dict:
        if not raw.strip():
            return {"open_ports": [], "count": 0}

        ports: list[int] = []
        seen:  set[int]  = set()

        for line in self.parse_lines_output(raw):
            # Greppable: "Open 1.2.3.4:80"
            m = _RE_OPEN.search(line)
            if m:
                p = int(m.group(1))
                if p not in seen:
                    seen.add(p)
                    ports.append(p)
                continue

            # JSON-like list fallback: "[80, 443, 22]"
            if line.startswith("["):
                try:
                    candidates = json.loads(line)
                    for p in candidates:
                        if isinstance(p, int) and p not in seen:
                            seen.add(p)
                            ports.append(p)
                except Exception:
                    pass

        return {"open_ports": sorted(ports), "count": len(ports)}
