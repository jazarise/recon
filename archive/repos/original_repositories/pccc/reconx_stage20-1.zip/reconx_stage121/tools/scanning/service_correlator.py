"""
ReconX — Service Correlation Engine.
Maps port + banner combinations to likely applications,
assigns risk labels, and surfaces attack-surface insights.
"""
from __future__ import annotations
import re
from dataclasses import dataclass, field
from typing import Optional
from ...models.findings import Port
from ...config.settings import SCAN_CONFIG

# ── Application fingerprints ─────────────────────────────────────────────────
_APP_SIGNATURES: list[dict] = [
    # Web servers
    {"pattern": r"nginx",          "app": "Nginx",         "category": "web_server",  "risk": "LOW"},
    {"pattern": r"apache",         "app": "Apache HTTPD",  "category": "web_server",  "risk": "LOW"},
    {"pattern": r"iis",            "app": "Microsoft IIS", "category": "web_server",  "risk": "LOW"},
    {"pattern": r"lighttpd",       "app": "Lighttpd",      "category": "web_server",  "risk": "LOW"},
    {"pattern": r"caddy",          "app": "Caddy",         "category": "web_server",  "risk": "LOW"},
    {"pattern": r"openresty",      "app": "OpenResty",     "category": "web_server",  "risk": "LOW"},

    # App servers / frameworks
    {"pattern": r"tomcat",         "app": "Apache Tomcat", "category": "app_server",  "risk": "MEDIUM"},
    {"pattern": r"jboss|wildfly",  "app": "JBoss/WildFly", "category": "app_server",  "risk": "HIGH"},
    {"pattern": r"weblogic",       "app": "Oracle WebLogic","category": "app_server", "risk": "HIGH"},
    {"pattern": r"glassfish",      "app": "GlassFish",     "category": "app_server",  "risk": "HIGH"},
    {"pattern": r"jetty",          "app": "Jetty",         "category": "app_server",  "risk": "MEDIUM"},

    # CI/CD & DevOps
    {"pattern": r"jenkins",        "app": "Jenkins",       "category": "ci_cd",       "risk": "HIGH"},
    {"pattern": r"gitlab",         "app": "GitLab",        "category": "vcs",         "risk": "MEDIUM"},
    {"pattern": r"gitea",          "app": "Gitea",         "category": "vcs",         "risk": "MEDIUM"},
    {"pattern": r"sonarqube",      "app": "SonarQube",     "category": "ci_cd",       "risk": "MEDIUM"},
    {"pattern": r"nexus",          "app": "Nexus",         "category": "artifact",    "risk": "MEDIUM"},

    # Databases
    {"pattern": r"mysql|mariadb",  "app": "MySQL/MariaDB", "category": "database",    "risk": "HIGH"},
    {"pattern": r"postgresql|postgres","app":"PostgreSQL",  "category": "database",    "risk": "HIGH"},
    {"pattern": r"mongodb",        "app": "MongoDB",       "category": "database",    "risk": "CRITICAL"},
    {"pattern": r"redis",          "app": "Redis",         "category": "cache",       "risk": "CRITICAL"},
    {"pattern": r"memcached",      "app": "Memcached",     "category": "cache",       "risk": "HIGH"},
    {"pattern": r"elasticsearch",  "app": "Elasticsearch", "category": "search",      "risk": "HIGH"},
    {"pattern": r"cassandra",      "app": "Cassandra",     "category": "database",    "risk": "HIGH"},
    {"pattern": r"couchdb",        "app": "CouchDB",       "category": "database",    "risk": "HIGH"},

    # Monitoring
    {"pattern": r"grafana",        "app": "Grafana",       "category": "monitoring",  "risk": "MEDIUM"},
    {"pattern": r"prometheus",     "app": "Prometheus",    "category": "monitoring",  "risk": "MEDIUM"},
    {"pattern": r"kibana",         "app": "Kibana",        "category": "monitoring",  "risk": "MEDIUM"},
    {"pattern": r"zabbix",         "app": "Zabbix",        "category": "monitoring",  "risk": "MEDIUM"},

    # SSH
    {"pattern": r"openssh[\s_-]?([0-9.]+)", "app": "OpenSSH",  "category": "remote_access","risk": "LOW"},
    {"pattern": r"dropbear",       "app": "Dropbear SSH",  "category": "remote_access","risk": "LOW"},

    # Containers
    {"pattern": r"docker",         "app": "Docker",        "category": "container",   "risk": "CRITICAL"},
    {"pattern": r"kubernetes|k8s", "app": "Kubernetes",    "category": "container",   "risk": "CRITICAL"},

    # Other
    {"pattern": r"jupyter",        "app": "Jupyter",       "category": "dev_tool",    "risk": "HIGH"},
    {"pattern": r"phpmyadmin",     "app": "phpMyAdmin",    "category": "db_admin",    "risk": "HIGH"},
    {"pattern": r"adminer",        "app": "Adminer",       "category": "db_admin",    "risk": "HIGH"},
    {"pattern": r"vnc",            "app": "VNC",           "category": "remote_access","risk": "HIGH"},
    {"pattern": r"rdp|ms-wbt",     "app": "RDP",           "category": "remote_access","risk": "CRITICAL"},
    {"pattern": r"ldap",           "app": "LDAP",          "category": "directory",   "risk": "HIGH"},
    {"pattern": r"rsync",          "app": "rsync",         "category": "file_transfer","risk": "HIGH"},
    {"pattern": r"nfs",            "app": "NFS",           "category": "file_transfer","risk": "HIGH"},
    {"pattern": r"printer|cups|ipp","app":"Print Service",  "category": "printer",    "risk": "MEDIUM"},
]

_COMPILED: list[dict] = [
    {**sig, "_re": re.compile(sig["pattern"], re.IGNORECASE)}
    for sig in _APP_SIGNATURES
]


@dataclass
class CorrelatedService:
    port:       int
    service:    str
    app:        str           = "unknown"
    version:    str           = ""
    category:   str           = "other"
    risk:       str           = "UNKNOWN"
    banner:     str           = ""
    confidence: float         = 0.5
    insights:   list[str]     = field(default_factory=list)


class ServiceCorrelator:
    """
    Enriches Port objects with application intelligence.
    Operates on nmap service results + banners.
    """

    def correlate(
        self,
        ports:   list[Port],
        banners: dict[int, str] | None = None,
    ) -> list[CorrelatedService]:
        banners = banners or {}
        results: list[CorrelatedService] = []

        for port in ports:
            combined = " ".join(filter(None, [
                port.service, port.version, port.banner,
                banners.get(port.number, "")
            ]))
            corr = self._match(port, combined)
            corr.insights = self._generate_insights(corr)
            results.append(corr)

        return sorted(results, key=lambda x: (
            {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "UNKNOWN": 4}.get(x.risk, 4),
            x.port
        ))

    def _match(self, port: Port, text: str) -> CorrelatedService:
        risky = SCAN_CONFIG.get("risky_services", {})
        base_risk = risky.get(port.service.lower(), "UNKNOWN")

        for sig in _COMPILED:
            m = sig["_re"].search(text)
            if m:
                version = ""
                if m.lastindex and m.lastindex >= 1:
                    try: version = m.group(1)
                    except Exception: pass
                # Use detected risk or port-based risk (whichever is higher)
                detected_risk = sig["risk"]
                final_risk    = _higher_risk(detected_risk, base_risk)
                return CorrelatedService(
                    port=port.number,
                    service=port.service or sig["app"].lower(),
                    app=sig["app"],
                    version=version or port.version,
                    category=sig["category"],
                    risk=final_risk,
                    banner=port.banner,
                    confidence=0.85,
                )

        # No signature match — use port-based defaults
        return CorrelatedService(
            port=port.number,
            service=port.service,
            app=port.service.title() if port.service else "Unknown",
            version=port.version,
            category="other",
            risk=base_risk,
            banner=port.banner,
            confidence=0.5,
        )

    @staticmethod
    def _generate_insights(svc: CorrelatedService) -> list[str]:
        insights: list[str] = []

        if svc.risk in ("CRITICAL", "HIGH"):
            insights.append(f"{svc.app} is externally accessible — verify authorization controls.")

        category_insights = {
            "database":    "Database port exposed — check for unauthenticated access.",
            "cache":       "Cache service exposed — likely no auth by default. Check immediately.",
            "ci_cd":       "CI/CD service exposed — risk of code execution or secret theft.",
            "remote_access": "Remote access service — ensure MFA and restricted IP access.",
            "container":   "Container runtime exposed — risk of host escape and full compromise.",
            "dev_tool":    "Development tool exposed — may contain credentials or source code.",
            "db_admin":    "Database admin panel exposed — high risk of data exfiltration.",
            "monitoring":  "Monitoring dashboard exposed — may leak infrastructure topology.",
        }
        if svc.category in category_insights:
            insights.append(category_insights[svc.category])

        if svc.version:
            insights.append(f"Version detected: {svc.version} — check for known CVEs.")

        return insights


def _higher_risk(a: str, b: str) -> str:
    order = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "UNKNOWN": 4}
    return a if order.get(a, 4) <= order.get(b, 4) else b
