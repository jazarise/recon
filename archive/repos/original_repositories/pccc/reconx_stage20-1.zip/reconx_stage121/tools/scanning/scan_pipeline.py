"""
ReconX — Active Scanning Pipeline.

Flow:
  ScanOptimizer → Fast Discovery (RustScan|naabu|masscan|TCP)
  → PortPrioritizer → Nmap deep scan → OSFingerprintEngine
  → ServiceCorrelator → Enriched ReconResult
"""
from __future__ import annotations
import logging
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from typing import Optional

from rich import box
from rich.columns import Columns
from rich.console import Console
from rich.panel import Panel
from rich.rule import Rule
from rich.table import Table
from rich.text import Text

from .naabu_tool        import NaabuTool
from .rustscan_tool     import RustScanTool
from .nmap_tool         import NmapTool
from .scan_optimizer    import ScanOptimizer
from .port_prioritizer  import PortPrioritizer, PortInfo
from .os_fingerprint    import OSFingerprintEngine
from .service_correlator import ServiceCorrelator
from ..tcp_scanner      import TCPScanner
from ..masscan          import MasscanTool
from ...models.findings    import ReconResult, Port
from ...models.tool_result import RunStatus, ToolRunResult
from ...config.settings    import SCAN_CONFIG

logger = logging.getLogger("reconx.scanning.pipeline")

_R  = "red"
_RB = "bold red"
_RD = "dim red"
_G  = "bold green"
_Y  = "yellow"
_D  = "dim"


@dataclass
class ScanStageStats:
    stage:      str
    tool:       str
    status:     RunStatus
    ports_found: int  = 0
    duration_s:  float = 0.0
    detail:      str  = ""


class ScanPipeline:
    """Orchestrates the full active scanning + service intelligence flow."""

    def __init__(
        self,
        console:   Optional[Console] = None,
        silent:    bool  = False,
        mode:      str   = "balanced",
        threads:   int   = 0,
    ):
        self.console  = console or Console()
        self.silent   = silent
        self.mode     = mode
        self.threads  = threads or SCAN_CONFIG.get("scan_threads", 50)
        self.optimizer    = ScanOptimizer(mode=mode)
        self.prioritizer  = PortPrioritizer()
        self.os_engine    = OSFingerprintEngine()
        self.correlator   = ServiceCorrelator()

    # ── Public ────────────────────────────────────────────────────────────────

    def run(self, target: str, result: ReconResult) -> list[ScanStageStats]:
        stats: list[ScanStageStats] = []
        t0    = time.perf_counter()

        # Build optimal scan plan
        is_root = self.optimizer.is_root()
        plan    = self.optimizer.build_plan(target, is_root=is_root)

        self._header(target, plan)

        # ── Step 1: Fast port discovery ───────────────────────────────────────
        self._section("Step 1 — Fast Port Discovery")
        s1, open_ports = self._step_discovery(target, plan, result)
        stats.append(s1)

        if not open_ports:
            self._print(f"  [{_Y}]⚠  No open ports found — target may be firewalled.[/{_Y}]")
            self._print_summary(stats, time.perf_counter() - t0)
            return stats

        # ── Step 2: Port prioritization ───────────────────────────────────────
        prioritized = self.prioritizer.prioritize(open_ports)
        self._print_port_table(prioritized.all_sorted[:30])
        if prioritized.uncommon_ports:
            self._print(f"  [{_Y}]⚠  Uncommon ports: {prioritized.uncommon_ports}[/{_Y}]")
        if prioritized.critical_ports:
            self._print(f"  [{_RB}]⚠  Critical ports exposed: {prioritized.critical_ports}[/{_RB}]")

        stats.append(ScanStageStats("prioritize", "PortPrioritizer", RunStatus.SUCCESS,
                                    ports_found=len(open_ports)))

        # ── Step 3: Nmap deep scan ────────────────────────────────────────────
        self._section("Step 3 — Service & Version Detection (Nmap)")
        s3, nmap_data = self._step_nmap(target, plan, prioritized.nmap_priority_list or open_ports)
        stats.append(s3)

        if nmap_data:
            result.ports.extend(nmap_data.get("ports", []))
            if nmap_data.get("os_info"):
                result.os_info = nmap_data["os_info"]
            result.raw["nmap_scripts"] = nmap_data.get("scripts", {})

        # ── Step 4: OS fingerprint ────────────────────────────────────────────
        self._section("Step 4 — OS Fingerprinting")
        os_result = self.os_engine.fingerprint(
            target,
            nmap_result=nmap_data,
        )
        if os_result.confidence > 0:
            result.os_info = os_result.to_dict()
            self._print(f"  [{_G}]✔  OS: {os_result.os_name} "
                        f"({os_result.confidence}% — method: {os_result.method})[/{_G}]")
        else:
            self._print(f"  [{_D}]○  OS detection inconclusive[/{_D}]")

        stats.append(ScanStageStats("os_detect", "OSFingerprintEngine",
                                    RunStatus.SUCCESS if os_result.confidence > 0 else RunStatus.NO_OUTPUT,
                                    detail=os_result.os_name))

        # ── Step 5: Service correlation ───────────────────────────────────────
        if result.ports:
            self._section("Step 5 — Service Intelligence")
            correlated = self.correlator.correlate(result.ports)
            self._print_service_table(correlated[:20])

            # Surface high-risk insights
            for svc in correlated:
                if svc.risk in ("CRITICAL", "HIGH"):
                    for insight in svc.insights[:1]:
                        self._print(f"  [{_RB}]  ⚠  {svc.app} (:{svc.port}): {insight}[/{_RB}]")

            result.raw["correlated_services"] = [
                {"port": s.port, "app": s.app, "risk": s.risk, "insights": s.insights}
                for s in correlated
            ]
            stats.append(ScanStageStats("correlate", "ServiceCorrelator",
                                         RunStatus.SUCCESS, ports_found=len(correlated)))

        self._print_summary(stats, time.perf_counter() - t0)
        return stats

    # ── Step implementations ──────────────────────────────────────────────────

    def _step_discovery(
        self, target: str, plan, result: ReconResult
    ) -> tuple[ScanStageStats, list[int]]:
        t0 = time.perf_counter()
        open_ports: list[int] = []
        tr: Optional[ToolRunResult] = None

        if plan.discovery_tool == "rustscan":
            tr = RustScanTool().safe_run(target, port_range=plan.port_range)
            if tr.ok:
                open_ports = tr.data.get("open_ports", [])

        elif plan.discovery_tool == "naabu":
            tr = NaabuTool().safe_run(target, port_range=plan.port_range,
                                       rate=plan.discovery_rate)
            if tr.ok:
                open_ports = tr.data.get("open_ports", [])

        elif plan.discovery_tool == "masscan":
            tr = MasscanTool().safe_run(target, port_range=plan.port_range,
                                         rate=plan.discovery_rate)
            if tr and tr.ok:
                open_ports = tr.data.get("open_ports", [])

        else:  # tcp_scan
            raw = TCPScanner(threads=self.threads, timeout=2.0).run(
                target, port_range=plan.port_range
            )
            open_ports = raw.get("open_ports", [])

        dur  = time.perf_counter() - t0
        stat = ScanStageStats(
            stage="discovery",
            tool=plan.discovery_tool,
            status=RunStatus.SUCCESS if open_ports else RunStatus.NO_OUTPUT,
            ports_found=len(open_ports),
            duration_s=dur,
            detail=f"{len(open_ports)} open ports in {dur:.1f}s",
        )

        # Store raw port list
        result.raw["discovered_ports"] = open_ports
        self._print(f"  [{_G}]✔  {plan.discovery_tool}: {len(open_ports)} open ports [{dur:.1f}s][/{_G}]")
        return stat, open_ports

    def _step_nmap(
        self, target: str, plan, ports: list[int]
    ) -> tuple[ScanStageStats, Optional[dict]]:
        nmap = NmapTool()
        t0   = time.perf_counter()

        if not nmap.is_available():
            self._print(f"  [{_D}]○  nmap not installed — skipping service detection[/{_D}]")
            return ScanStageStats("nmap", "Nmap", RunStatus.SKIPPED,
                                   detail="nmap not installed"), None

        tr = nmap.safe_run(
            target,
            ports=ports[:500],     # cap for safety
            profile=plan.nmap_profile,
            os_detect=True,
            timing=plan.nmap_timing,
            udp_scan=plan.udp_enabled,
        )
        dur = time.perf_counter() - t0

        if tr.ok:
            svc_count = len(tr.data.get("ports", []))
            self._print(f"  [{_G}]✔  nmap: {svc_count} services identified [{dur:.1f}s][/{_G}]")
            return (
                ScanStageStats("nmap", "Nmap", RunStatus.SUCCESS,
                                ports_found=svc_count, duration_s=dur,
                                detail=f"{svc_count} services, profile={plan.nmap_profile}"),
                tr.data,
            )

        detail = tr.error.message if tr.error else tr.status.value
        self._print(f"  [{_Y}]⚠  nmap: {detail}[/{_Y}]")
        return (
            ScanStageStats("nmap", "Nmap", tr.status, duration_s=dur, detail=detail),
            None,
        )

    # ── Rich UI ───────────────────────────────────────────────────────────────

    def _header(self, target: str, plan) -> None:
        if self.silent: return
        self.console.print()
        self.console.print(Panel(
            f"[{_RB}]ACTIVE SCANNING PIPELINE[/{_RB}]\n"
            f"[{_D}]Target:[/{_D}] [{_R}]{target}[/{_R}]   "
            f"[{_D}]Discovery:[/{_D}] [{_R}]{plan.discovery_tool}[/{_R}]   "
            f"[{_D}]Range:[/{_D}] [{_R}]{plan.port_range}[/{_R}]   "
            f"[{_D}]ETA:[/{_D}] [{_R}]{plan.estimated_time}[/{_R}]",
            border_style=_R, padding=(0, 3),
        ))
        for note in plan.notes:
            self.console.print(f"  [{_Y}]ℹ  {note}[/{_Y}]")

    def _section(self, label: str) -> None:
        if not self.silent:
            self.console.print()
            self.console.print(Rule(f"[{_RD}]  {label}  [/{_RD}]", style=_R))

    def _print(self, msg: str) -> None:
        if not self.silent:
            self.console.print(msg)

    def _print_port_table(self, ports: list[PortInfo]) -> None:
        if self.silent or not ports: return
        t = Table(box=box.SIMPLE, show_edge=False, border_style=_RD,
                  header_style=_RB, padding=(0, 2))
        t.add_column("PORT",    style=_R, width=8,  no_wrap=True)
        t.add_column("SERVICE", style="white", width=14)
        t.add_column("RISK",               width=10)
        t.add_column("CATEGORY", style=_D, width=16)
        t.add_column("⚑",       style=_Y, width=4)
        rc_map = {"CRITICAL":"bold red","HIGH":"red","MEDIUM":"yellow","LOW":"green","UNKNOWN":"dim"}
        for pi in ports:
            t.add_row(str(pi.port), pi.service,
                      Text(pi.risk, style=rc_map.get(pi.risk,"white")),
                      pi.category, "★" if pi.uncommon else "")
        self.console.print(t)

    def _print_service_table(self, services) -> None:
        if self.silent or not services: return
        t = Table(box=box.SIMPLE, show_edge=False, border_style=_RD,
                  header_style=_RB, padding=(0, 2))
        t.add_column("PORT",    style=_R,     width=8)
        t.add_column("APP",     style="white",width=18)
        t.add_column("VERSION", style=_D,     width=18)
        t.add_column("RISK",                  width=10)
        rc_map = {"CRITICAL":"bold red","HIGH":"red","MEDIUM":"yellow","LOW":"green","UNKNOWN":"dim"}
        for s in services:
            t.add_row(str(s.port), s.app, s.version or "—",
                      Text(s.risk, style=rc_map.get(s.risk, "white")))
        self.console.print(t)

    def _print_summary(self, stats: list[ScanStageStats], total_t: float) -> None:
        if self.silent: return
        self.console.print()
        self.console.print(Rule(f"[{_RB}]  SCAN PIPELINE COMPLETE  [/{_RB}]", style=_R))
        self.console.print()
        ok   = sum(1 for s in stats if s.status == RunStatus.SUCCESS)
        skip = sum(1 for s in stats if s.status == RunStatus.SKIPPED)
        self.console.print(Columns([
            Panel(f"[{_G}]{ok}[/{_G}]\n[{_D}]STEPS OK[/{_D}]",
                  border_style="green", padding=(0,3), expand=True),
            Panel(f"[{_D}]{skip}[/{_D}]\n[{_D}]SKIPPED[/{_D}]",
                  border_style="dim",  padding=(0,3), expand=True),
            Panel(f"[white]{total_t:.1f}s[/white]\n[{_D}]TOTAL TIME[/{_D}]",
                  border_style=_RD,   padding=(0,3), expand=True),
        ], equal=True, expand=True))
        self.console.print()
