"""
ReconX — Nmap advanced orchestration (Stage 6 upgrade).
Full XML-driven, multi-profile, NSE-aware wrapper.
Replaces tools/nmap_tool.py with scanning-module version.
"""
from __future__ import annotations
import os
import tempfile
import time
from typing import Optional

from ..base import BaseTool
from ...config.settings import SCAN_CONFIG
from ...models.findings import Port
from ...models.tool_result import ParsedFinding, RunStatus, ToolRunResult


class NmapTool(BaseTool):
    NAME         = "Nmap"
    BINARY       = "nmap"
    CATEGORY     = "scanning"
    STAGE        = 3
    PRIORITY     = 30
    PASSIVE      = False
    TIMEOUT      = 300
    DEPENDENCIES: list[str] = []
    INSTALL_CMD  = "sudo apt install nmap"

    # ── NSE script profiles ───────────────────────────────────────────────────
    NSE_PROFILES: dict[str, list[str]] = {
        "default": ["version", "default"],
        "safe":    ["safe"],
        "vuln":    ["vuln"],
        "web":     ["http-title", "http-headers", "http-methods", "http-server-header"],
        "smb":     ["smb-security-mode", "smb2-security-mode", "smb-vuln-ms17-010"],
        "ssh":     ["ssh-auth-methods", "ssh-hostkey"],
        "db":      ["mysql-info", "ms-sql-info", "mongodb-info", "redis-info"],
        "full":    ["version", "default", "vuln"],
    }

    def run(
        self,
        target: str,
        *,
        ports:             Optional[list[int]] = None,
        port_range:        str  = "",
        profile:           str  = "default",        # NSE profile key
        nse_scripts:       Optional[list[str]] = None,  # override profile
        os_detect:         bool = True,
        timing:            int  = 0,                # 0 = use config default
        version_intensity: int  = 0,
        udp_scan:          bool = False,
        aggressive:        bool = False,
        **kwargs,
    ) -> ToolRunResult:
        if s := self.skip_if_unavailable(): return s
        if f := self.validate_or_fail(target): return f

        timing   = timing   or SCAN_CONFIG.get("nmap_timing", 4)
        vin      = version_intensity or SCAN_CONFIG.get("nmap_version_intensity", 5)
        port_arg = (",".join(str(p) for p in sorted(set(ports))) if ports
                    else port_range or SCAN_CONFIG.get("port_range_balanced", "1-10000"))
        scripts  = nse_scripts or self.NSE_PROFILES.get(profile, ["version", "default"])

        tmp_xml = None
        t0 = time.perf_counter()

        try:
            with tempfile.NamedTemporaryFile(suffix=".xml", delete=False) as f:
                tmp_xml = f.name

            args = [
                "-sV",
                "--version-intensity", str(vin),
                f"-T{timing}",
                "-p", port_arg,
                "--open",
                "--script", ",".join(scripts),
                "-oX", tmp_xml,
            ]

            if os_detect:
                args += ["-O", "--osscan-limit"]
            if udp_scan:
                args.insert(0, "-sU")
            if aggressive:
                args.append("-A")

            args.append(target)

            res = self.exec(args, timeout_s=float(self.timeout),
                            expected_codes=(0, 1))

        finally:
            pass  # cleanup after reading

        dur = time.perf_counter() - t0

        if res.timed_out:
            self._del(tmp_xml)
            return ToolRunResult.timeout(self.NAME, dur, self.timeout)
        if res.returncode == 127:
            self._del(tmp_xml)
            return ToolRunResult.skipped(self.NAME, res.stderr)

        xml_text = ""
        try:
            if tmp_xml and os.path.exists(tmp_xml):
                with open(tmp_xml, "r", encoding="utf-8", errors="replace") as f:
                    xml_text = f.read()
        finally:
            self._del(tmp_xml)

        data     = self.parse_output(xml_text)
        findings = self._make_findings(data)

        r = self.build_result(data, findings, stdout=res.stdout,
                              stderr=res.stderr, duration_s=dur,
                              returncode=res.returncode)
        if not data["ports"]:
            r.status = RunStatus.NO_OUTPUT
        return r

    def parse_output(self, raw: str, **kwargs) -> dict:
        if not raw.strip():
            return {"ports": [], "os_info": {}, "scripts": {}, "count": 0}
        try:
            return self._parse_xml(raw)
        except Exception as exc:
            self._log("warning", f"XML parse failed: {exc}")
            return {"ports": [], "os_info": {}, "scripts": {}, "count": 0}

    def _parse_xml(self, xml: str) -> dict:
        from ...utils.parsers import parse_xml, parse_nmap_xml
        root = parse_xml(xml)
        if root is None:
            return {"ports": [], "os_info": {}, "scripts": {}, "count": 0}

        base   = parse_nmap_xml(root)
        scripts: dict[str, dict] = {}

        # Extract NSE script output per port
        import xml.etree.ElementTree as ET
        for host in root.findall("host"):
            for port_el in host.findall(".//port"):
                port_num = int(port_el.get("portid", 0))
                for script in port_el.findall("script"):
                    sid    = script.get("id", "")
                    output = script.get("output", "").strip()
                    if sid and output:
                        scripts.setdefault(port_num, {})[sid] = output

        base["scripts"] = scripts
        base["count"]   = len(base["ports"])
        return base

    def _make_findings(self, data: dict) -> list[ParsedFinding]:
        findings = []
        for port in data.get("ports", []):
            findings.append(self._finding(
                "port", str(port.number),
                service=port.service, version=port.version,
            ))
        if data.get("os_info", {}).get("os"):
            findings.append(self._finding(
                "os", data["os_info"]["os"],
                confidence=data["os_info"].get("confidence", 0) / 100,
            ))
        for port_num, script_data in data.get("scripts", {}).items():
            for script_id, output in script_data.items():
                findings.append(self._finding(
                    "nse_script", script_id,
                    port=port_num, output=output[:200],
                ))
        return findings

    @staticmethod
    def _del(path: Optional[str]) -> None:
        if path:
            try: os.unlink(path)
            except Exception: pass
