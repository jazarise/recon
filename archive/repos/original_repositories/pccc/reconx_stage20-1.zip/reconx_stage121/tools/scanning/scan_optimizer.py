"""
ReconX — Scan Optimizer.
Selects the best available scanner, builds adaptive scan arguments,
and manages scan fallback chains.

Priority chain (fastest → most accurate):
  RustScan → naabu → masscan → TCP connect → nmap

"""
from __future__ import annotations
import logging
import shutil
from dataclasses import dataclass
from typing import Optional

from ...config.settings import SCAN_CONFIG

logger = logging.getLogger("reconx.scanning.optimizer")


@dataclass
class ScanPlan:
    """Optimized scan plan output."""
    discovery_tool:  str        # "rustscan" | "naabu" | "masscan" | "tcp_scan"
    detail_tool:     str        # always "nmap" if available
    port_range:      str
    discovery_rate:  int
    nmap_timing:     int
    nmap_profile:    str        # NSE profile key
    use_syn:         bool       # SYN scan available (root)?
    udp_enabled:     bool
    estimated_time:  str        # human estimate
    notes:           list[str]

    def summary(self) -> str:
        return (f"Discovery: {self.discovery_tool} | "
                f"Detail: {self.detail_tool} | "
                f"Ports: {self.port_range} | "
                f"SYN: {self.use_syn}")


class ScanOptimizer:
    """
    Analyses available tools and target context to build the optimal scan plan.
    """

    def __init__(self, mode: str = "balanced"):
        self.mode = mode

    def build_plan(
        self,
        target:      str,
        is_root:     bool           = False,
        open_ports:  Optional[list[int]] = None,
        port_range:  Optional[str]  = None,
    ) -> ScanPlan:
        cfg   = SCAN_CONFIG
        notes: list[str] = []

        # ── Port range ────────────────────────────────────────────────────────
        if port_range:
            p_range = port_range
        elif open_ports:
            p_range = ",".join(str(p) for p in sorted(set(open_ports)))
        else:
            p_range = {
                "fast":     cfg["port_range_fast"],
                "balanced": cfg["port_range_balanced"],
                "deep":     cfg["port_range_deep"],
            }.get(self.mode, cfg["port_range_balanced"])

        # ── Discovery tool selection ──────────────────────────────────────────
        if shutil.which("rustscan"):
            discovery = "rustscan"
            rate      = cfg.get("rustscan_batch", 2500)
            est       = "< 30s"
        elif shutil.which("naabu"):
            discovery = "naabu"
            rate      = cfg.get("naabu_rate", 1000)
            est       = "30-90s"
        elif shutil.which("masscan"):
            discovery = "masscan"
            rate      = cfg.get("masscan_rate", 2000)
            est       = "30-60s"
            if not is_root:
                notes.append("masscan requires root — falling back to tcp_scan")
                discovery = "tcp_scan"
        else:
            discovery = "tcp_scan"
            rate      = 0
            est       = "1-5min"
            notes.append("No fast scanner found — using Python TCP connect scanner")

        # ── Detail tool ───────────────────────────────────────────────────────
        detail = "nmap" if shutil.which("nmap") else "none"
        if detail == "none":
            notes.append("nmap not found — service fingerprinting unavailable")

        # ── NSE profile ───────────────────────────────────────────────────────
        nse_profile = "default"
        if self.mode == "deep":
            nse_profile = "full"
        elif open_ports:
            if any(p in (80, 443, 8080, 8443) for p in open_ports):
                nse_profile = "web"
            if any(p in (445, 139) for p in open_ports):
                nse_profile = "smb"

        # ── SYN scan ─────────────────────────────────────────────────────────
        use_syn = is_root and discovery in ("naabu", "masscan")
        if use_syn:
            notes.append("SYN scan enabled (root detected)")

        # ── UDP scan ─────────────────────────────────────────────────────────
        udp = self.mode == "deep" and shutil.which("nmap") and is_root

        return ScanPlan(
            discovery_tool=discovery,
            detail_tool=detail,
            port_range=p_range,
            discovery_rate=rate,
            nmap_timing=cfg.get("nmap_timing", 4),
            nmap_profile=nse_profile,
            use_syn=use_syn,
            udp_enabled=udp,
            estimated_time=est,
            notes=notes,
        )

    @staticmethod
    def is_root() -> bool:
        import os
        try:
            return os.geteuid() == 0
        except AttributeError:
            return False   # Windows
