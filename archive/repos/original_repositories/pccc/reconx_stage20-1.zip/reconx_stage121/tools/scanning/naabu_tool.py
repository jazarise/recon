"""
ReconX — naabu port scanner (standardized).
Fast SYN/CONNECT scanner by ProjectDiscovery.
Excellent alternative to masscan — Go-based, JSON output, CDN-aware.
"""
from __future__ import annotations
import os
import tempfile
import time
from typing import Optional

from ..base import BaseTool
from ...config.settings import SCAN_CONFIG
from ...models.tool_result import ParsedFinding, RunStatus, ToolRunResult


class NaabuTool(BaseTool):
    NAME         = "naabu"
    BINARY       = "naabu"
    CATEGORY     = "scanning"
    STAGE        = 3
    PRIORITY     = 8            # runs right after DNS, before nmap
    PASSIVE      = False
    TIMEOUT      = 90
    DEPENDENCIES: list[str] = []
    INSTALL_CMD  = "go install github.com/projectdiscovery/naabu/v2/cmd/naabu@latest"

    def run(
        self,
        target:      str,
        *,
        port_range:  str            = "",
        top_ports:   int            = 0,
        rate:        int            = 0,
        threads:     int            = 25,
        syn_scan:    bool           = False,   # requires root
        exclude_cdn: bool           = True,
        hosts:       Optional[list[str]] = None,   # scan multiple hosts
        **kwargs,
    ) -> ToolRunResult:
        if s := self.skip_if_unavailable(): return s
        if f := self.validate_or_fail(target): return f

        rate     = rate     or SCAN_CONFIG.get("naabu_rate", 1000)
        port_arg = port_range or SCAN_CONFIG.get("port_range_balanced", "1-10000")

        tmp_hosts = None
        t0 = time.perf_counter()

        try:
            args = [
                "-rate",    str(rate),
                "-c",       str(threads),
                "-json",
                "-silent",
            ]

            if top_ports:
                args += ["-top-ports", str(top_ports)]
            else:
                args += ["-p", port_arg]

            if syn_scan:
                args.append("-s")      # SYN scan (root needed)

            if exclude_cdn:
                args.append("-exclude-cdn")

            if hosts:
                with tempfile.NamedTemporaryFile(mode="w", suffix=".txt",
                                                 delete=False) as f:
                    f.write("\n".join(hosts))
                    tmp_hosts = f.name
                args += ["-l", tmp_hosts]
            else:
                args += ["-host", target]

            res = self.exec(args, timeout_s=float(self.timeout),
                            expected_codes=(0, 1))

        finally:
            if tmp_hosts and os.path.exists(tmp_hosts):
                os.unlink(tmp_hosts)

        dur = time.perf_counter() - t0

        if res.timed_out:
            return ToolRunResult.timeout(self.NAME, dur, self.timeout)
        if res.returncode == 127:
            return ToolRunResult.skipped(self.NAME, res.stderr)

        data     = self.parse_output(res.stdout)
        findings = self._make_findings(data)

        r = self.build_result(data, findings, stdout=res.stdout,
                              stderr=res.stderr, duration_s=dur,
                              returncode=res.returncode)
        if not data["open_ports"]:
            r.status = RunStatus.NO_OUTPUT
        return r

    def parse_output(self, raw: str, **kwargs) -> dict:
        if not raw.strip():
            return {"open_ports": [], "host_port_map": {}, "count": 0}

        open_ports:    list[int]        = []
        host_port_map: dict[str, list]  = {}
        seen:          set[int]         = set()

        for obj in self.parse_json_lines_output(raw):
            port = obj.get("port", 0)
            host = obj.get("host", "")
            ip   = obj.get("ip", "")

            if not port:
                continue

            if port not in seen:
                seen.add(port)
                open_ports.append(port)

            host_key = host or ip or "unknown"
            host_port_map.setdefault(host_key, [])
            if port not in host_port_map[host_key]:
                host_port_map[host_key].append(port)

        return {
            "open_ports":    sorted(open_ports),
            "host_port_map": host_port_map,
            "count":         len(open_ports),
        }

    def _make_findings(self, data: dict) -> list[ParsedFinding]:
        return [self._finding("port", str(p)) for p in data["open_ports"]]
