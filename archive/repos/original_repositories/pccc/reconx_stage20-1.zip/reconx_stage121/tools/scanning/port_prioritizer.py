"""
ReconX — Port Prioritizer.
Ranks open ports by security relevance, groups them into action queues,
and identifies uncommon / suspicious services.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional
from ...config.settings import SCAN_CONFIG

# ── Service metadata ───────────────────────────────────────────────────────────
_PORT_MAP: dict[int, dict] = {
    21:    {"service": "ftp",           "protocol": "tcp", "risk": "HIGH",     "category": "file_transfer"},
    22:    {"service": "ssh",           "protocol": "tcp", "risk": "MEDIUM",   "category": "remote_access"},
    23:    {"service": "telnet",        "protocol": "tcp", "risk": "CRITICAL", "category": "remote_access"},
    25:    {"service": "smtp",          "protocol": "tcp", "risk": "MEDIUM",   "category": "mail"},
    53:    {"service": "dns",           "protocol": "both","risk": "LOW",      "category": "infrastructure"},
    80:    {"service": "http",          "protocol": "tcp", "risk": "LOW",      "category": "web"},
    110:   {"service": "pop3",          "protocol": "tcp", "risk": "MEDIUM",   "category": "mail"},
    111:   {"service": "rpc",           "protocol": "tcp", "risk": "HIGH",     "category": "rpc"},
    135:   {"service": "msrpc",         "protocol": "tcp", "risk": "HIGH",     "category": "rpc"},
    139:   {"service": "netbios",       "protocol": "tcp", "risk": "HIGH",     "category": "smb"},
    143:   {"service": "imap",          "protocol": "tcp", "risk": "MEDIUM",   "category": "mail"},
    443:   {"service": "https",         "protocol": "tcp", "risk": "LOW",      "category": "web"},
    445:   {"service": "smb",           "protocol": "tcp", "risk": "CRITICAL", "category": "smb"},
    465:   {"service": "smtps",         "protocol": "tcp", "risk": "LOW",      "category": "mail"},
    587:   {"service": "submission",    "protocol": "tcp", "risk": "LOW",      "category": "mail"},
    993:   {"service": "imaps",         "protocol": "tcp", "risk": "LOW",      "category": "mail"},
    995:   {"service": "pop3s",         "protocol": "tcp", "risk": "LOW",      "category": "mail"},
    1433:  {"service": "mssql",         "protocol": "tcp", "risk": "HIGH",     "category": "database"},
    1521:  {"service": "oracle",        "protocol": "tcp", "risk": "HIGH",     "category": "database"},
    2049:  {"service": "nfs",           "protocol": "tcp", "risk": "HIGH",     "category": "file_transfer"},
    2375:  {"service": "docker",        "protocol": "tcp", "risk": "CRITICAL", "category": "container"},
    2376:  {"service": "docker-tls",    "protocol": "tcp", "risk": "HIGH",     "category": "container"},
    3000:  {"service": "grafana",       "protocol": "tcp", "risk": "MEDIUM",   "category": "monitoring"},
    3306:  {"service": "mysql",         "protocol": "tcp", "risk": "HIGH",     "category": "database"},
    3389:  {"service": "rdp",           "protocol": "tcp", "risk": "CRITICAL", "category": "remote_access"},
    4443:  {"service": "https-alt",     "protocol": "tcp", "risk": "LOW",      "category": "web"},
    4848:  {"service": "glassfish",     "protocol": "tcp", "risk": "HIGH",     "category": "app_server"},
    5432:  {"service": "postgresql",    "protocol": "tcp", "risk": "HIGH",     "category": "database"},
    5900:  {"service": "vnc",           "protocol": "tcp", "risk": "HIGH",     "category": "remote_access"},
    5985:  {"service": "winrm",         "protocol": "tcp", "risk": "HIGH",     "category": "remote_access"},
    5986:  {"service": "winrm-ssl",     "protocol": "tcp", "risk": "HIGH",     "category": "remote_access"},
    6379:  {"service": "redis",         "protocol": "tcp", "risk": "CRITICAL", "category": "cache"},
    7001:  {"service": "weblogic",      "protocol": "tcp", "risk": "HIGH",     "category": "app_server"},
    8000:  {"service": "http-alt",      "protocol": "tcp", "risk": "LOW",      "category": "web"},
    8080:  {"service": "http-proxy",    "protocol": "tcp", "risk": "LOW",      "category": "web"},
    8443:  {"service": "https-alt",     "protocol": "tcp", "risk": "LOW",      "category": "web"},
    8888:  {"service": "jupyter",       "protocol": "tcp", "risk": "HIGH",     "category": "dev_tool"},
    9000:  {"service": "php-fpm",       "protocol": "tcp", "risk": "HIGH",     "category": "web"},
    9090:  {"service": "prometheus",    "protocol": "tcp", "risk": "MEDIUM",   "category": "monitoring"},
    9200:  {"service": "elasticsearch", "protocol": "tcp", "risk": "HIGH",     "category": "database"},
    9300:  {"service": "elasticsearch", "protocol": "tcp", "risk": "HIGH",     "category": "database"},
    11211: {"service": "memcached",     "protocol": "tcp", "risk": "HIGH",     "category": "cache"},
    27017: {"service": "mongodb",       "protocol": "tcp", "risk": "CRITICAL", "category": "database"},
    50000: {"service": "jenkins",       "protocol": "tcp", "risk": "HIGH",     "category": "ci_cd"},
}

_WEB_PORTS   = {80, 443, 8080, 8443, 8000, 4443, 8888, 3000, 9090}
_DB_PORTS    = {3306, 5432, 1433, 1521, 27017, 6379, 9200, 9300, 11211}
_REMOTE_PORTS= {22, 23, 3389, 5900, 5985, 5986}
_SMB_PORTS   = {139, 445}
_RISK_ORDER  = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "UNKNOWN": 4}


@dataclass
class PortInfo:
    port:        int
    service:     str     = "unknown"
    protocol:    str     = "tcp"
    risk:        str     = "UNKNOWN"
    category:    str     = "other"
    priority:    int     = 50       # 0 = highest priority
    uncommon:    bool    = False
    banner:      str     = ""
    confidence:  float   = 0.5


@dataclass
class PrioritizedScan:
    """Output of PortPrioritizer — ports grouped by action queue."""
    web_ports:       list[int] = field(default_factory=list)
    database_ports:  list[int] = field(default_factory=list)
    remote_ports:    list[int] = field(default_factory=list)
    smb_ports:       list[int] = field(default_factory=list)
    critical_ports:  list[int] = field(default_factory=list)
    uncommon_ports:  list[int] = field(default_factory=list)
    all_sorted:      list[PortInfo] = field(default_factory=list)

    @property
    def nmap_priority_list(self) -> list[int]:
        """Ports to scan first in nmap — highest value targets."""
        seen, out = set(), []
        for p in self.critical_ports + self.database_ports + self.web_ports + self.remote_ports:
            if p not in seen:
                seen.add(p)
                out.append(p)
        return out


class PortPrioritizer:
    """Enriches raw port lists with metadata and groups them into action queues."""

    def prioritize(self, open_ports: list[int], banners: dict[int, str] | None = None) -> PrioritizedScan:
        banners = banners or {}
        port_infos: list[PortInfo] = []

        for port in sorted(set(open_ports)):
            meta = _PORT_MAP.get(port, {})
            service  = meta.get("service", self._guess_service(port, banners.get(port, "")))
            risk     = meta.get("risk", "UNKNOWN")
            category = meta.get("category", "other")
            priority = _RISK_ORDER.get(risk, 4) * 10 + (0 if port in _PORT_MAP else 5)
            uncommon = port not in _PORT_MAP and port not in {80, 443, 22, 21}

            pi = PortInfo(
                port=port, service=service,
                protocol=meta.get("protocol", "tcp"),
                risk=risk, category=category,
                priority=priority, uncommon=uncommon,
                banner=banners.get(port, ""),
                confidence=0.95 if port in _PORT_MAP else 0.5,
            )
            port_infos.append(pi)

        port_infos.sort(key=lambda x: (x.priority, x.port))

        result = PrioritizedScan(all_sorted=port_infos)
        for pi in port_infos:
            if pi.port in _WEB_PORTS:    result.web_ports.append(pi.port)
            if pi.port in _DB_PORTS:     result.database_ports.append(pi.port)
            if pi.port in _REMOTE_PORTS: result.remote_ports.append(pi.port)
            if pi.port in _SMB_PORTS:    result.smb_ports.append(pi.port)
            if pi.risk in ("CRITICAL","HIGH"): result.critical_ports.append(pi.port)
            if pi.uncommon:              result.uncommon_ports.append(pi.port)

        # Deduplicate
        result.critical_ports = list(dict.fromkeys(result.critical_ports))
        return result

    @staticmethod
    def _guess_service(port: int, banner: str) -> str:
        banner_lower = banner.lower()
        if "ssh" in banner_lower:   return "ssh"
        if "http" in banner_lower:  return "http"
        if "ftp" in banner_lower:   return "ftp"
        if "smtp" in banner_lower:  return "smtp"
        if port > 49151:            return "ephemeral"
        if 1024 <= port <= 49151:   return "registered"
        return "unknown"

    def get_port_info(self, port: int) -> Optional[PortInfo]:
        meta = _PORT_MAP.get(port)
        if not meta:
            return None
        return PortInfo(port=port, **{k: v for k, v in meta.items()
                                       if k in PortInfo.__dataclass_fields__})
