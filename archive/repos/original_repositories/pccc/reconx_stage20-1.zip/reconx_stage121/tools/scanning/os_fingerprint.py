"""
ReconX — OS Fingerprinting Engine.
Multi-method OS detection combining TTL heuristics, TCP stack analysis,
nmap XML results, and banner analysis.
"""
from __future__ import annotations
import logging
import re
import socket
import struct
import time
from dataclasses import dataclass, field
from typing import Optional

logger = logging.getLogger("reconx.scanning.os_fingerprint")

_TTL_MAP = [
    (range(0, 65),   "Linux / Unix",          75),
    (range(65, 129),  "Windows",               70),
    (range(129, 256), "Network Device / Cisco", 65),
]

_BANNER_OS_PATTERNS: list[tuple[re.Pattern, str, int]] = [
    (re.compile(r"ubuntu",      re.I), "Ubuntu Linux",      85),
    (re.compile(r"debian",      re.I), "Debian Linux",      85),
    (re.compile(r"centos",      re.I), "CentOS Linux",      85),
    (re.compile(r"fedora",      re.I), "Fedora Linux",      85),
    (re.compile(r"red hat",     re.I), "Red Hat Linux",     85),
    (re.compile(r"alpine",      re.I), "Alpine Linux",      85),
    (re.compile(r"freebsd",     re.I), "FreeBSD",           85),
    (re.compile(r"openbsd",     re.I), "OpenBSD",           90),
    (re.compile(r"windows nt",  re.I), "Windows NT",        80),
    (re.compile(r"windows server", re.I), "Windows Server", 85),
    (re.compile(r"win32",       re.I), "Windows",           70),
    (re.compile(r"ios",         re.I), "Cisco IOS",         75),
    (re.compile(r"junos",       re.I), "Juniper JunOS",     80),
    (re.compile(r"vmware",      re.I), "VMware ESXi",       80),
    (re.compile(r"mikrotik",    re.I), "MikroTik RouterOS", 85),
]


@dataclass
class OSResult:
    os_name:     str   = "Unknown"
    os_family:   str   = ""        # "linux", "windows", "bsd", "network"
    confidence:  int   = 0         # 0–100
    method:      str   = ""        # "ttl", "banner", "nmap", "combined"
    ttl:         int   = 0
    details:     dict  = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {"os": self.os_name, "confidence": self.confidence,
                "family": self.os_family, "method": self.method}


class OSFingerprintEngine:
    """
    Multi-method OS fingerprinting.
    Combines results for higher confidence.
    """

    def __init__(self, timeout: float = 3.0):
        self.timeout = timeout

    # ── Public ────────────────────────────────────────────────────────────────

    def fingerprint(
        self,
        target:     str,
        banners:    dict[int, str] | None = None,
        nmap_result: dict | None = None,
        open_ports:  list[int] | None = None,
    ) -> OSResult:
        """Combine all available methods into best OS guess."""
        candidates: list[OSResult] = []

        # Method 1: nmap XML (highest confidence if available)
        if nmap_result and nmap_result.get("os_info", {}).get("os"):
            r = self._from_nmap(nmap_result["os_info"])
            if r.confidence > 0:
                candidates.append(r)

        # Method 2: Banner analysis
        if banners:
            r = self._from_banners(banners)
            if r.confidence > 0:
                candidates.append(r)

        # Method 3: TTL probe (active)
        r = self._from_ttl(target)
        if r.confidence > 0:
            candidates.append(r)

        if not candidates:
            return OSResult(os_name="Unknown", confidence=0, method="none")

        # Pick highest confidence; if tie, prefer nmap > banner > ttl
        best = max(candidates, key=lambda x: x.confidence)

        # Boost confidence if multiple methods agree on OS family
        if len(candidates) > 1:
            families = [c.os_family for c in candidates if c.os_family]
            if families and len(set(families)) == 1:
                best.confidence = min(best.confidence + 10, 99)
                best.method = "combined"

        return best

    # ── Method implementations ────────────────────────────────────────────────

    @staticmethod
    def _from_nmap(os_info: dict) -> OSResult:
        os_name    = os_info.get("os", "")
        confidence = os_info.get("confidence", 0)
        family     = _classify_family(os_name)
        return OSResult(os_name=os_name, os_family=family,
                        confidence=confidence, method="nmap")

    @staticmethod
    def _from_banners(banners: dict[int, str]) -> OSResult:
        all_text = " ".join(str(v) for v in banners.values())
        for pattern, os_name, conf in _BANNER_OS_PATTERNS:
            if pattern.search(all_text):
                return OSResult(
                    os_name=os_name, os_family=_classify_family(os_name),
                    confidence=conf, method="banner",
                )
        return OSResult(confidence=0, method="banner")

    def _from_ttl(self, target: str) -> OSResult:
        ttl = self._ping_ttl(target)
        if ttl <= 0:
            return OSResult(confidence=0, method="ttl")
        for rng, os_name, conf in _TTL_MAP:
            if ttl in rng:
                return OSResult(
                    os_name=os_name, os_family=_classify_family(os_name),
                    confidence=conf, method="ttl", ttl=ttl,
                )
        return OSResult(confidence=0, method="ttl")

    def _ping_ttl(self, target: str) -> int:
        """Get TTL via raw ICMP echo (requires root) or TCP connect fallback."""
        try:
            import subprocess
            import platform
            flag = "-n 1" if platform.system() == "Windows" else "-c 1"
            result = subprocess.run(
                f"ping {flag} -W 2 {target}",
                shell=True, capture_output=True, text=True, timeout=5
            )
            output = result.stdout + result.stderr
            for pattern in [r"ttl=(\d+)", r"TTL=(\d+)", r"Time to live[=: ]+(\d+)"]:
                m = re.search(pattern, output, re.I)
                if m:
                    return int(m.group(1))
        except Exception as exc:
            logger.debug("Ping TTL failed for %s: %s", target, exc)
        return 0


def _classify_family(os_name: str) -> str:
    os_lower = os_name.lower()
    if any(k in os_lower for k in ("linux", "ubuntu", "debian", "centos", "fedora", "alpine", "red hat")):
        return "linux"
    if any(k in os_lower for k in ("windows", "win32", "nt")):
        return "windows"
    if any(k in os_lower for k in ("freebsd", "openbsd", "netbsd", "bsd")):
        return "bsd"
    if any(k in os_lower for k in ("cisco", "junos", "network", "router", "mikrotik")):
        return "network"
    if "vmware" in os_lower:
        return "hypervisor"
    return "unknown"
