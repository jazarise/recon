"""
ReconX — httpx tool wrapper (standardized).
Fast HTTP probing: status codes, titles, tech stack, redirects.
"""
from __future__ import annotations
import os
import tempfile
import time
from typing import Optional

from .base import BaseTool
from ..models.tool_result import ParsedFinding, RunStatus, ToolRunResult


class HttpxTool(BaseTool):

    NAME         = "httpx"
    BINARY       = "httpx"
    CATEGORY     = "web"
    STAGE        = 4
    PRIORITY     = 10
    PASSIVE      = False
    TIMEOUT      = 120
    DEPENDENCIES : list[str] = []
    INSTALL_CMD  = "go install github.com/projectdiscovery/httpx/cmd/httpx@latest"

    # ── run ───────────────────────────────────────────────────────────────────

    def run(
        self,
        target: str,          # single target OR ignored when targets= provided
        *,
        targets: Optional[list[str]] = None,   # list of hosts/URLs to probe
        threads: int = 50,
        timeout_per_req: int = 10,
        follow_redirects: bool = True,
        **kwargs,
    ) -> ToolRunResult:

        skip = self.skip_if_unavailable()
        if skip:
            return skip

        # Build target list
        probe_list = targets or [target]
        probe_list = [h for h in probe_list if h]
        if not probe_list:
            return self.fail("no_targets", "Empty target list provided.")

        t0 = time.perf_counter()

        # Write targets to temp file (httpx -l)
        tmp_path = None
        try:
            with tempfile.NamedTemporaryFile(
                mode="w", suffix=".txt", delete=False, encoding="utf-8"
            ) as tmp:
                tmp.write("\n".join(probe_list))
                tmp_path = tmp.name

            args = [
                "-l",  tmp_path,
                "-json",
                "-title",
                "-tech-detect",
                "-status-code",
                "-content-length",
                "-web-server",
                "-silent",
                "-t",  str(threads),
                "-timeout", str(timeout_per_req),
            ]
            if follow_redirects:
                args.append("-follow-redirects")

            res = self.exec(args, timeout_s=float(self.timeout))

        finally:
            if tmp_path and os.path.exists(tmp_path):
                os.unlink(tmp_path)

        duration = time.perf_counter() - t0

        if res.timed_out:
            return ToolRunResult.timeout(self.NAME, duration, self.timeout)
        if res.returncode == 127:
            return ToolRunResult.skipped(self.NAME, res.stderr)
        if not res.stdout.strip() and res.returncode != 0:
            return self.fail("subprocess_error", f"Exit {res.returncode}",
                             stderr=res.stderr, duration_s=duration)

        data     = self.parse_output(res.stdout)
        findings = self._make_findings(data)

        result = self.build_result(
            data, findings,
            stdout=res.stdout, stderr=res.stderr,
            duration_s=duration, returncode=res.returncode,
        )
        if not data["endpoints"]:
            result.status = RunStatus.NO_OUTPUT
        return result

    # ── parse_output ──────────────────────────────────────────────────────────

    def parse_output(self, raw: str, **kwargs) -> dict:
        if not raw.strip():
            return {"endpoints": [], "technologies": [], "live_hosts": []}

        raw_endpoints = self.parse_httpx_json(raw)
        endpoints     = []
        technologies  = set()
        live_hosts    = []

        for ep in raw_endpoints:
            url = ep.get("url", "")
            if not url:
                continue

            # Normalize
            entry = {
                "url":            url,
                "status_code":    ep.get("status_code", 0),
                "title":          ep.get("title", ""),
                "content_length": ep.get("content_length", 0),
                "webserver":      ep.get("webserver", ""),
                "cdn":            ep.get("cdn", False),
                "technologies":   ep.get("technologies", []),
            }
            endpoints.append(entry)
            live_hosts.append(url)

            for tech in ep.get("technologies", []):
                if tech:
                    technologies.add(tech)

        return {
            "endpoints":    endpoints,
            "technologies": sorted(technologies),
            "live_hosts":   list(dict.fromkeys(live_hosts)),
        }

    # ── private ───────────────────────────────────────────────────────────────

    def _make_findings(self, data: dict) -> list[ParsedFinding]:
        findings = []
        for ep in data.get("endpoints", []):
            findings.append(self._finding(
                "url", ep["url"],
                status_code=ep["status_code"],
                title=ep["title"],
                webserver=ep["webserver"],
            ))
        for tech in data.get("technologies", []):
            findings.append(self._finding("technology", tech))
        return findings
