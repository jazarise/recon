"""
ReconX — HTTP Security Header Analyzer.
Pure-Python urllib; no external binary needed.
Checks for presence/weakness of critical security headers.
"""
from __future__ import annotations
import logging
import ssl
import urllib.error
import urllib.request
from typing import Optional

from ..models.findings import HeaderFinding

logger = logging.getLogger("reconx.tools.header_checker")


# Each rule: header name, required?, weakness patterns, risk, recommendation
_HEADER_RULES: list[dict] = [
    {
        "header": "Strict-Transport-Security",
        "required": True,
        "weak_if_missing": True,
        "risk": "Missing HSTS allows downgrade attacks and MITM over HTTP.",
        "recommendation": "Add: Strict-Transport-Security: max-age=31536000; includeSubDomains; preload",
        "weak_values": [],
    },
    {
        "header": "Content-Security-Policy",
        "required": True,
        "weak_if_missing": True,
        "risk": "No CSP leaves the site open to Cross-Site Scripting (XSS) attacks.",
        "recommendation": "Define a strict CSP policy. Start with: default-src 'self'",
        "weak_values": ["unsafe-inline", "unsafe-eval", "*"],
    },
    {
        "header": "X-Frame-Options",
        "required": True,
        "weak_if_missing": True,
        "risk": "Missing X-Frame-Options enables clickjacking attacks.",
        "recommendation": "Add: X-Frame-Options: DENY (or SAMEORIGIN)",
        "weak_values": ["ALLOWALL"],
    },
    {
        "header": "X-Content-Type-Options",
        "required": True,
        "weak_if_missing": True,
        "risk": "Missing header allows MIME-type sniffing attacks.",
        "recommendation": "Add: X-Content-Type-Options: nosniff",
        "weak_values": [],
    },
    {
        "header": "Referrer-Policy",
        "required": False,
        "weak_if_missing": False,
        "risk": "Referrer information may leak sensitive URL parameters.",
        "recommendation": "Add: Referrer-Policy: strict-origin-when-cross-origin",
        "weak_values": ["unsafe-url"],
    },
    {
        "header": "Permissions-Policy",
        "required": False,
        "weak_if_missing": False,
        "risk": "No Permissions-Policy means browser features (camera, mic) are unrestricted.",
        "recommendation": "Define: Permissions-Policy: geolocation=(), camera=(), microphone=()",
        "weak_values": [],
    },
    {
        "header": "X-Powered-By",
        "required": False,
        "weak_if_missing": False,
        "risk": "Server technology disclosed — aids targeted exploitation.",
        "recommendation": "Remove X-Powered-By header from server config.",
        "weak_values": ["__any__"],   # presence itself is weak
        "flag_presence": True,
    },
    {
        "header": "Server",
        "required": False,
        "weak_if_missing": False,
        "risk": "Server version disclosure aids fingerprinting and targeted attacks.",
        "recommendation": "Remove or anonymize the Server header.",
        "weak_values": ["__any__"],
        "flag_presence": True,
    },
]


class HeaderChecker:
    def __init__(self, timeout: float = 8.0):
        self.timeout = timeout

    def check(self, url: str) -> list[HeaderFinding]:
        """Fetch URL headers and evaluate security posture."""
        headers = self._fetch_headers(url)
        if headers is None:
            return []
        return self._evaluate(headers)

    def _fetch_headers(self, url: str) -> Optional[dict]:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE

        try:
            req = urllib.request.Request(
                url,
                headers={"User-Agent": "ReconX/1.0 (security-audit)"},
                method="HEAD",
            )
            handler = urllib.request.HTTPSHandler(context=ctx)
            opener = urllib.request.build_opener(handler)
            with opener.open(req, timeout=self.timeout) as resp:
                return dict(resp.headers)
        except urllib.error.HTTPError as exc:
            return dict(exc.headers) if exc.headers else {}
        except Exception as exc:
            logger.debug("Header fetch failed for %s: %s", url, exc)
            return None

    @staticmethod
    def _evaluate(raw_headers: dict) -> list[HeaderFinding]:
        # Normalize header names to lowercase for lookup
        lower_headers = {k.lower(): v for k, v in raw_headers.items()}
        findings: list[HeaderFinding] = []

        for rule in _HEADER_RULES:
            name = rule["header"]
            name_lower = name.lower()
            value = lower_headers.get(name_lower, "")
            flag_presence = rule.get("flag_presence", False)

            if flag_presence:
                # These headers are bad to have (info disclosure)
                if value:
                    findings.append(HeaderFinding(
                        header=name,
                        status="weak",
                        value=value,
                        risk=rule["risk"],
                        recommendation=rule["recommendation"],
                    ))
                continue

            if not value:
                if rule["weak_if_missing"]:
                    findings.append(HeaderFinding(
                        header=name,
                        status="missing",
                        value="",
                        risk=rule["risk"],
                        recommendation=rule["recommendation"],
                    ))
                continue

            # Check for weak values
            weak_match = any(w in value for w in rule.get("weak_values", []))
            if weak_match:
                findings.append(HeaderFinding(
                    header=name,
                    status="weak",
                    value=value,
                    risk=f"Weak configuration detected: {rule['risk']}",
                    recommendation=rule["recommendation"],
                ))
            else:
                findings.append(HeaderFinding(
                    header=name,
                    status="present",
                    value=value,
                ))

        return findings
