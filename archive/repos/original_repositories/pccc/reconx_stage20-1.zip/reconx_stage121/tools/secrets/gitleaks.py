"""
ReconX — gitleaks wrapper.

Gitleaks scans git repositories for hardcoded secrets using regex rules
and Shannon entropy analysis. Supports local repos, remote URLs, and
pre-commit hooks. Faster than TruffleHog for local scanning.

Stage 2 — Active Secret Detection in Git Repositories.
"""
from __future__ import annotations
import json
import os
import re
import time
from pathlib import Path
from typing import Optional

from ..base import BaseTool
from ...models.tool_result import ParsedFinding, RunStatus, ToolRunResult


class GitleaksTool(BaseTool):

    NAME         = "gitleaks"
    BINARY       = "gitleaks"
    CATEGORY     = "secrets"
    STAGE        = 2
    PRIORITY     = 12
    PASSIVE      = True
    TIMEOUT      = 300
    DEPENDENCIES: list[str] = []
    INSTALL_CMD  = (
        "# Linux:\nbrew install gitleaks\n"
        "# or: go install github.com/gitleaks/gitleaks/v8@latest"
    )

    # ── run ───────────────────────────────────────────────────────────────────

    def run(
        self,
        target: str,
        *,
        source:       str           = "detect",  # "detect"|"protect"|"dir"
        repo_url:     Optional[str] = None,
        config_file:  Optional[str] = None,
        log_opts:     Optional[str] = None,     # git log options e.g. "--all"
        no_git:       bool          = False,
        redact:       bool          = True,
        verbose:      bool          = False,
        **kwargs,
    ) -> ToolRunResult:
        """
        Args:
            target:      Local path or git repo URL.
            source:      'detect' (scan repo), 'protect' (pre-commit), 'dir' (filesystem).
            repo_url:    Remote git repo URL (alternative to local path).
            config_file: Path to custom .gitleaks.toml config.
            log_opts:    Extra git log options (e.g. '--since=2023-01-01').
            no_git:      Scan directory without git context.
            redact:      Redact discovered secret values in output.
            verbose:     Enable verbose output.
        """
        if s := self.skip_if_unavailable():
            return s

        report_path = "/tmp/gitleaks_report.json"
        t0 = time.perf_counter()

        cmd_target = repo_url or target
        args = [
            source,
            "--source", cmd_target,
            "--report-format", "json",
            "--report-path",   report_path,
            "--exit-code",     "0",   # don't fail on findings
        ]

        if config_file and os.path.exists(config_file):
            args += ["--config", config_file]
        if log_opts:
            args += ["--log-opts", log_opts]
        if no_git:
            args.append("--no-git")
        if redact:
            args.append("--redact")
        if verbose:
            args.append("--verbose")

        res = self.exec(args, timeout_s=float(self.timeout), expected_codes=(0, 1))
        dur = time.perf_counter() - t0

        if res.timed_out:
            return ToolRunResult.timeout(self.NAME, dur, self.timeout)
        if res.returncode == 127:
            return ToolRunResult.skipped(self.NAME, res.stderr)

        # Prefer JSON report
        raw = self._read_json_report(report_path)
        data = (self._parse_json_report(raw) if raw
                else self.parse_output(res.stdout))

        findings = self._build_findings(data)
        r = self.build_result(data, findings, stdout=res.stdout,
                              duration_s=dur, returncode=res.returncode)
        if not data["secrets"]: r.status = RunStatus.NO_OUTPUT
        return r

    # ── parse_output ──────────────────────────────────────────────────────────

    def parse_output(self, raw: str, **kwargs) -> dict:
        if not raw.strip():
            return {"secrets": [], "count": 0}
        try:
            return self._parse_json_report(json.loads(raw))
        except Exception:
            pass
        # Text fallback
        secrets: list[dict] = []
        for line in raw.splitlines():
            if re.search(r"(secret|token|key|password|credential)", line, re.I):
                secrets.append({"rule": "text_match", "secret": "***",
                                "file": "", "commit": "", "line": 0, "severity": "MEDIUM"})
        return {"secrets": secrets, "count": len(secrets)}

    # ── internal ──────────────────────────────────────────────────────────────

    @staticmethod
    def _read_json_report(path: str):
        try:
            if os.path.exists(path):
                data = json.loads(Path(path).read_text())
                os.unlink(path)
                return data
        except Exception:
            pass
        return None

    def _parse_json_report(self, data) -> dict:
        if not data:
            return {"secrets": [], "count": 0}
        secrets: list[dict] = []
        items = data if isinstance(data, list) else [data]
        for item in items:
            if not isinstance(item, dict):
                continue
            secrets.append({
                "rule":     item.get("RuleID", item.get("rule_id", "unknown")),
                "secret":   "***" if item.get("Secret", "") else "",
                "file":     item.get("File", item.get("file", "")),
                "commit":   item.get("Commit", item.get("commit", ""))[:12],
                "line":     item.get("StartLine", 0),
                "severity": "HIGH" if item.get("RuleID", "").lower() in
                            ("awsaccesskey", "privatekey", "githubtoken", "gcpserviceaccount")
                            else "MEDIUM",
            })
        return {"secrets": secrets, "count": len(secrets)}

    def _build_findings(self, data: dict) -> list[ParsedFinding]:
        return [
            ParsedFinding(
                finding_type="secret",
                value=f"{s.get('rule','unknown')} in {s.get('file','?')}",
                source=self.NAME, confidence=0.85,
                metadata={k: v for k, v in s.items() if k != "secret"},
            )
            for s in data.get("secrets", [])
        ]
