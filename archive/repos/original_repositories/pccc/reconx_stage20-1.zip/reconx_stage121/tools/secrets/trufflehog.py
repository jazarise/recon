"""
ReconX — trufflehog v3 wrapper.

TruffleHog scans git repositories, filesystems, S3 buckets, and
other sources for high-entropy strings, regex-matched secrets, and
verified credentials. v3 includes 700+ built-in detectors.

Stage 2 — Passive/Active Secret Discovery.
"""
from __future__ import annotations
import json
import re
import time
from typing import Optional

from ..base import BaseTool
from ...models.tool_result import ParsedFinding, RunStatus, ToolRunResult

# Severity mapping from TruffleHog detector types
_HIGH_VALUE_TYPES = {
    "AWS", "GCP", "Azure", "GitHub", "GitLab", "Slack", "Stripe",
    "Twilio", "SendGrid", "Mailgun", "HerokuKey", "PrivateKey",
    "JWT", "Shopify", "DigitalOcean", "Cloudflare",
}


class TrufflehogTool(BaseTool):

    NAME         = "trufflehog"
    BINARY       = "trufflehog"
    CATEGORY     = "secrets"
    STAGE        = 2
    PRIORITY     = 10
    PASSIVE      = True
    TIMEOUT      = 300
    DEPENDENCIES: list[str] = []
    INSTALL_CMD  = (
        "# Linux:\n"
        "curl -sSfL https://raw.githubusercontent.com/trufflesecurity/trufflehog/main/"
        "scripts/install.sh | sh -s -- -b /usr/local/bin\n"
        "# or: go install github.com/trufflesecurity/trufflehog/v3@latest"
    )

    # ── run ───────────────────────────────────────────────────────────────────

    def run(
        self,
        target: str,
        *,
        source:          str           = "git",   # "git"|"github"|"filesystem"|"s3"|"url"
        branch:          Optional[str] = None,
        only_verified:   bool          = True,
        no_verification: bool          = False,
        include_detectors: Optional[list[str]] = None,
        exclude_detectors: Optional[list[str]] = None,
        concurrency:     int           = 8,
        **kwargs,
    ) -> ToolRunResult:
        """
        Args:
            target:            Git URL, GitHub org, directory path, or S3 bucket.
            source:            Source type: 'git'|'github'|'filesystem'|'s3'|'url'.
            branch:            Git branch to scan.
            only_verified:     Only report verified (live) credentials.
            no_verification:   Skip credential verification entirely.
            include_detectors: List of detector names to enable.
            exclude_detectors: List of detector names to skip.
            concurrency:       Worker thread count.
        """
        if s := self.skip_if_unavailable():
            return s

        args = [
            source, target,
            "--json",
            "--no-update",
            "--concurrency", str(concurrency),
        ]

        if only_verified and not no_verification:
            args.append("--only-verified")
        if no_verification:
            args.append("--no-verification")
        if branch:
            args += ["--branch", branch]
        if include_detectors:
            args += ["--include-detectors", ",".join(include_detectors)]
        if exclude_detectors:
            args += ["--exclude-detectors", ",".join(exclude_detectors)]

        t0  = time.perf_counter()
        res = self.exec(args, timeout_s=float(self.timeout), expected_codes=(0, 1))
        dur = time.perf_counter() - t0

        if res.timed_out:
            return ToolRunResult.timeout(self.NAME, dur, self.timeout)
        if res.returncode == 127:
            return ToolRunResult.skipped(self.NAME, res.stderr)

        data = self.parse_output(res.stdout)
        findings = self._build_findings(data)
        r = self.build_result(data, findings, stdout=res.stdout,
                              duration_s=dur, returncode=res.returncode)
        if not data["secrets"]: r.status = RunStatus.NO_OUTPUT
        return r

    # ── parse_output ──────────────────────────────────────────────────────────

    def parse_output(self, raw: str, **kwargs) -> dict:
        """Parse TruffleHog JSON-lines output."""
        if not raw.strip():
            return {"secrets": [], "count": 0, "verified": 0}

        secrets:  list[dict] = []
        verified_count = 0

        for line in raw.splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
                detector  = obj.get("DetectorName", obj.get("detector_name", "Unknown"))
                verified  = obj.get("Verified", obj.get("verified", False))
                raw_val   = obj.get("Raw", obj.get("raw", ""))
                file_path = (obj.get("SourceMetadata", {})
                             .get("Data", {}).get("Git", {}).get("file",
                             obj.get("file", "")))
                commit    = (obj.get("SourceMetadata", {})
                             .get("Data", {}).get("Git", {}).get("commit", ""))

                severity = "CRITICAL" if (verified and detector in _HIGH_VALUE_TYPES) else \
                           "HIGH"     if (detector in _HIGH_VALUE_TYPES) else \
                           "MEDIUM"   if verified else "LOW"

                if verified:
                    verified_count += 1

                secrets.append({
                    "detector":  detector,
                    "verified":  verified,
                    "severity":  severity,
                    "raw":       self._redact(str(raw_val)),
                    "file":      file_path,
                    "commit":    commit[:12] if commit else "",
                })
            except Exception:
                pass

        return {"secrets": secrets, "count": len(secrets), "verified": verified_count}

    # ── internal ──────────────────────────────────────────────────────────────

    @staticmethod
    def _redact(value: str) -> str:
        """Partially redact secret value for safe storage."""
        if len(value) <= 8:
            return "***"
        return value[:4] + "..." + value[-4:]

    def _build_findings(self, data: dict) -> list[ParsedFinding]:
        findings = []
        for s in data.get("secrets", []):
            findings.append(ParsedFinding(
                finding_type="secret",
                value=f"{s['detector']} credential detected",
                source=self.NAME,
                confidence=0.95 if s.get("verified") else 0.7,
                metadata={
                    "detector":  s.get("detector", ""),
                    "severity":  s.get("severity", "MEDIUM"),
                    "verified":  s.get("verified", False),
                    "file":      s.get("file", ""),
                    "commit":    s.get("commit", ""),
                    "raw":       s.get("raw", ""),
                },
            ))
        return findings
