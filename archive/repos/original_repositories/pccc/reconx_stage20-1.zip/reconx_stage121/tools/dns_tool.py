"""
ReconX — DNS enumeration tool.
Uses dnspython (pure-Python) so no external binary required.
Falls back to socket for A records if dnspython unavailable.
"""
from __future__ import annotations
import logging
import socket
from typing import Optional

logger = logging.getLogger("reconx.tools.dns")

try:
    import dns.resolver
    import dns.exception
    HAS_DNSPYTHON = True
except ImportError:
    HAS_DNSPYTHON = False


class DNSTool:
    """DNS enumeration — no external binary needed."""

    RECORD_TYPES = ["A", "AAAA", "MX", "NS", "TXT", "CNAME", "SOA"]

    def __init__(self, timeout: float = 5.0, nameserver: Optional[str] = None):
        self.timeout = timeout
        self.nameserver = nameserver

    def run(self, target: str, **kwargs) -> dict:
        records: dict[str, list[str]] = {}
        ips: list[str] = []

        if HAS_DNSPYTHON:
            resolver = dns.resolver.Resolver()
            resolver.lifetime = self.timeout
            if self.nameserver:
                resolver.nameservers = [self.nameserver]

            for rtype in self.RECORD_TYPES:
                values = self._query(resolver, target, rtype)
                if values:
                    records[rtype] = values
                    if rtype == "A":
                        ips.extend(values)
        else:
            # Fallback: socket A-record only
            logger.warning("dnspython not available; using socket fallback for A records only.")
            try:
                info = socket.getaddrinfo(target, None)
                ips = list({i[4][0] for i in info})
                records["A"] = ips
            except Exception as exc:
                logger.error("DNS fallback failed: %s", exc)

        return {"records": records, "ip_addresses": ips}

    @staticmethod
    def _query(resolver, domain: str, rtype: str) -> list[str]:
        try:
            answers = resolver.resolve(domain, rtype)
            return [r.to_text() for r in answers]
        except Exception:
            return []
