"""
ReconX — Masscan wrapper for rapid port discovery.
Requires root / CAP_NET_RAW.
"""
from __future__ import annotations
import logging
import re
import json

from .base import BaseTool

logger = logging.getLogger("reconx.tools.masscan")


class MasscanTool(BaseTool):
    BINARY = "masscan"
    NAME = "Masscan"

    def run(self, target: str, port_range: str = "1-1000",
            rate: int = 2000, **kwargs) -> dict:
        if not self.is_available():
            logger.warning("masscan not found; skipping fast port discovery.")
            return {"open_ports": []}

        stdout, stderr, rc = self._run(
            [target, "-p", port_range, "--rate", str(rate),
             "--output-format", "json", "--output-filename", "-"],
            timeout=300,
        )

        open_ports: list[int] = []

        if rc != 0 and rc != 1:   # masscan returns 1 on success (odd but true)
            logger.warning("masscan exited %s: %s", rc, stderr[:200])

        # Parse JSON output
        try:
            # masscan JSON can be a list directly
            text = stdout.strip()
            if text.startswith("["):
                records = json.loads(text)
            else:
                # Strip masscan's funky comment header
                lines = [l for l in text.splitlines() if not l.startswith("#")]
                records = json.loads("[" + ",".join(lines) + "]") if lines else []

            for rec in records:
                for port_info in rec.get("ports", []):
                    pnum = port_info.get("port")
                    state = port_info.get("status", "")
                    if pnum and state == "open":
                        open_ports.append(pnum)
        except Exception as exc:
            logger.debug("masscan JSON parse failed (%s); falling back to regex.", exc)
            # Fallback: regex on plaintext output
            for m in re.finditer(r"Discovered open port (\d+)/", stdout + stderr):
                open_ports.append(int(m.group(1)))

        return {"open_ports": sorted(set(open_ports))}
