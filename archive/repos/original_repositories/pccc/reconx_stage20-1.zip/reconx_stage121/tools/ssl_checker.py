"""
ReconX — TLS/SSL Certificate Inspector.
Pure-Python; uses ssl + socket. No external binary needed.
"""
from __future__ import annotations
import logging
import socket
import ssl
from datetime import datetime, timezone

from ..models.findings import TLSInfo

logger = logging.getLogger("reconx.tools.ssl_checker")


class SSLChecker:
    """Inspect TLS certificate on port 443 (or custom port)."""

    def __init__(self, timeout: float = 8.0):
        self.timeout = timeout

    def check(self, host: str, port: int = 443) -> TLSInfo | None:
        try:
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE   # grab cert even if invalid

            with socket.create_connection((host, port), timeout=self.timeout) as sock:
                with ctx.wrap_socket(sock, server_hostname=host) as ssock:
                    cert = ssock.getpeercert()
                    protocol = ssock.version() or ""
                    cipher_info = ssock.cipher()
                    cipher = cipher_info[0] if cipher_info else ""

            if not cert:
                return TLSInfo(subject=host, protocol=protocol, cipher=cipher)

            return self._parse_cert(cert, protocol, cipher)

        except ssl.SSLError as exc:
            logger.debug("SSL error for %s:%s — %s", host, port, exc)
            return None
        except (socket.timeout, ConnectionRefusedError, OSError) as exc:
            logger.debug("Cannot connect to %s:%s — %s", host, port, exc)
            return None
        except Exception as exc:
            logger.warning("SSL check failed for %s: %s", host, exc)
            return None

    @staticmethod
    def _parse_cert(cert: dict, protocol: str, cipher: str) -> TLSInfo:
        info = TLSInfo(protocol=protocol, cipher=cipher)

        # Subject
        subject_dict = dict(x[0] for x in cert.get("subject", []))
        info.subject = subject_dict.get("commonName", "")

        # Issuer
        issuer_dict = dict(x[0] for x in cert.get("issuer", []))
        info.issuer = issuer_dict.get("organizationName", issuer_dict.get("commonName", ""))

        # Validity
        fmt = "%b %d %H:%M:%S %Y %Z"
        try:
            not_before = cert.get("notBefore", "")
            not_after = cert.get("notAfter", "")
            if not_before:
                info.valid_from = not_before
            if not_after:
                info.valid_until = not_after
                expiry = datetime.strptime(not_after, fmt).replace(tzinfo=timezone.utc)
                now = datetime.now(tz=timezone.utc)
                info.days_remaining = (expiry - now).days
                info.is_expired = info.days_remaining < 0
        except ValueError:
            pass

        # Self-signed?
        info.is_self_signed = (
            subject_dict.get("commonName") == issuer_dict.get("commonName")
            or subject_dict.get("organizationName") == issuer_dict.get("organizationName")
        )

        # SAN domains
        san_list = cert.get("subjectAltName", [])
        info.san_domains = [v for t, v in san_list if t == "DNS"]

        return info
