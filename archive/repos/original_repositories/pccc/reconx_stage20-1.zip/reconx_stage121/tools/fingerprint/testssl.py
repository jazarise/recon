"""
ReconX — testssl.sh wrapper.

testssl.sh checks TLS/SSL configuration against known vulnerabilities:
POODLE, BEAST, CRIME, HEARTBLEED, weak ciphers, outdated protocols,
missing HSTS, and certificate issues. The industry standard for TLS auditing.

Stage 3 — Active TLS Security Analysis.
"""
from __future__ import annotations
import json
import re
import time
from typing import Optional

from ..base import BaseTool
from ...models.tool_result import ParsedFinding, RunStatus, ToolRunResult

# Severity mapping for testssl findings
_TESTSSL_SEVERITY = {
    "OK":       "INFO",
    "INFO":     "INFO",
    "WARN":     "MEDIUM",
    "NOT OK":   "HIGH",
    "CRITICAL": "CRITICAL",
    "LOW":      "LOW",
    "MEDIUM":   "MEDIUM",
    "HIGH":     "HIGH",
}

# Issues that are always HIGH/CRITICAL regardless of testssl rating
_HIGH_VALUE_CHECKS = {
    "heartbleed", "ccs", "ticketbleed", "robot", "secure_client_renego",
    "crime_tls", "breach", "poodle_ssl", "fallback_scsv", "sweet32",
    "beast", "lucky13", "rc4", "ssl2", "ssl3", "tls1",
}


class TestSSLTool(BaseTool):

    NAME         = "testssl"
    BINARY       = "testssl.sh"
    CATEGORY     = "fingerprint"
    STAGE        = 3
    PRIORITY     = 15
    PASSIVE      = False
    TIMEOUT      = 300
    DEPENDENCIES: list[str] = []
    INSTALL_CMD  = (
        "git clone --depth 1 https://github.com/drwetter/testssl.sh.git\n"
        "sudo ln -s $(pwd)/testssl.sh/testssl.sh /usr/local/bin/testssl.sh\n"
        "# or: sudo apt install testssl.sh"
    )

    # ── run ───────────────────────────────────────────────────────────────────

    def run(
        self,
        target: str,
        *,
        port:         int  = 443,
        full:         bool = False,     # run all checks
        fast:         bool = True,      # skip slower checks
        json_output:  bool = True,
        severity:     str  = "MEDIUM",  # minimum severity to report
        starttls:     Optional[str] = None,   # "smtp"|"ftp"|"imap" etc.
        **kwargs,
    ) -> ToolRunResult:
        """
        Args:
            target:     Hostname to test (e.g. example.com).
            port:       Port to connect to (default: 443).
            full:       Run all checks including slow ones.
            fast:       Skip time-consuming checks (overridden by full).
            json_output: Write JSON results for reliable parsing.
            severity:   Minimum severity level to include in findings.
            starttls:   STARTTLS protocol for non-HTTPS services.
        """
        if s := self.skip_if_unavailable():
            return s

        host = target.replace("https://", "").replace("http://", "").split("/")[0]
        report_path = f"/tmp/testssl_{host}_{port}.json"
        t0 = time.perf_counter()

        args = [
            "--jsonfile", report_path,
            "--color", "0",
            "--quiet",
        ]

        if fast and not full:
            args += ["--fast"]
        elif full:
            args += ["--full"]
        else:
            # Default: common vulnerability checks
            args += ["-p", "-h", "-v", "-U"]   # protos, headers, server-pref, vulns

        if starttls:
            args += ["--starttls", starttls]

        args.append(f"{host}:{port}")

        res = self.exec(args, timeout_s=float(self.timeout), expected_codes=(0, 1))
        dur = time.perf_counter() - t0

        if res.timed_out:
            return ToolRunResult.timeout(self.NAME, dur, self.timeout)
        if res.returncode == 127:
            return ToolRunResult.skipped(self.NAME, res.stderr)

        raw_json = self._read_json_file(report_path)
        data = (self._parse_json(raw_json, severity) if raw_json
                else self.parse_output(res.stdout, severity=severity))

        findings = self._build_findings(data)
        r = self.build_result(data, findings, stdout=res.stdout,
                              duration_s=dur, returncode=res.returncode)
        if not data["issues"]: r.status = RunStatus.NO_OUTPUT
        return r

    # ── parse_output ──────────────────────────────────────────────────────────

    def parse_output(self, raw: str, severity: str = "MEDIUM", **kwargs) -> dict:
        """Parse testssl.sh text output."""
        if not raw.strip():
            return self._empty()

        issues:  list[dict] = []
        min_sev  = ["INFO", "LOW", "MEDIUM", "HIGH", "CRITICAL"]
        min_idx  = min_sev.index(severity.upper()) if severity.upper() in min_sev else 2
        ansi_re  = re.compile(r"\x1b\[[0-9;]*[A-Za-z]")

        for line in raw.splitlines():
            line = ansi_re.sub("", line).strip()
            if not line:
                continue

            sev = "INFO"
            if re.search(r"\bCRITICAL\b", line, re.I):
                sev = "CRITICAL"
            elif re.search(r"\bNOT OK\b|\bHIGH\b|\bVULNERABLE\b", line, re.I):
                sev = "HIGH"
            elif re.search(r"\bWARN\b|\bMEDIUM\b", line, re.I):
                sev = "MEDIUM"
            elif re.search(r"\bLOW\b", line, re.I):
                sev = "LOW"

            if min_sev.index(sev) < min_idx:
                continue

            issues.append({
                "id":          "",
                "description": line[:200],
                "severity":    sev,
                "finding":     line,
            })

        return {"issues": issues, "count": len(issues), "host": ""}

    # ── internal ──────────────────────────────────────────────────────────────

    @staticmethod
    def _read_json_file(path: str):
        import os
        try:
            if os.path.exists(path):
                import os as _os
                data = json.loads(open(path).read())
                _os.unlink(path)
                return data
        except Exception:
            pass
        return None

    def _parse_json(self, data, severity: str = "MEDIUM") -> dict:
        """Parse testssl.sh JSON output format."""
        issues:   list[dict] = []
        host      = ""
        min_sev   = ["INFO", "LOW", "MEDIUM", "HIGH", "CRITICAL"]
        min_idx   = min_sev.index(severity.upper()) if severity.upper() in min_sev else 2

        if isinstance(data, dict):
            # testssl JSON: {"scanResult": [{"targetHost": ..., "findings": [...]}]}
            host     = data.get("targetHost", data.get("ip", ""))
            findings = data.get("scanResult", [data])
            if isinstance(findings, list) and findings:
                findings = findings[0].get("findings", [])
        elif isinstance(data, list):
            findings = data
        else:
            findings = []

        for f in findings:
            if not isinstance(f, dict):
                continue
            raw_sev  = f.get("severity", "INFO").upper()
            mapped   = _TESTSSL_SEVERITY.get(raw_sev, raw_sev)
            check_id = f.get("id", "").lower()

            # Escalate known critical checks
            if any(check_id.startswith(k) for k in _HIGH_VALUE_CHECKS):
                if mapped not in ("HIGH", "CRITICAL"):
                    mapped = "HIGH"

            if min_sev.index(mapped) if mapped in min_sev else 0 < min_idx:
                continue

            issues.append({
                "id":          f.get("id", ""),
                "description": f.get("finding", f.get("output", "")),
                "severity":    mapped,
                "finding":     f.get("finding", ""),
            })

        return {"issues": issues, "count": len(issues), "host": host}

    @staticmethod
    def _empty() -> dict:
        return {"issues": [], "count": 0, "host": ""}

    def _build_findings(self, data: dict) -> list[ParsedFinding]:
        findings = []
        for issue in data.get("issues", []):
            sev = issue.get("severity", "INFO")
            if sev == "INFO":
                continue  # skip pure info items
            findings.append(ParsedFinding(
                finding_type="tls_vulnerability",
                value=issue.get("id") or issue.get("description", "")[:80],
                source=self.NAME,
                confidence=0.9,
                metadata={
                    "severity":    sev,
                    "description": issue.get("description", ""),
                    "host":        data.get("host", ""),
                },
            ))
        return findings
