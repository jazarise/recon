"""
ReconX — wafw00f wrapper.

wafw00f identifies Web Application Firewalls (WAFs) by sending
crafted HTTP requests and analysing response headers, cookies,
status codes, and body content. Identifies 160+ WAF products.
Pure-Python fallback probes common WAF indicators directly.

Stage 3 — Active WAF Fingerprinting.
"""
from __future__ import annotations
import json
import re
import ssl
import time
import urllib.request
from typing import Optional

from ..base import BaseTool
from ...models.tool_result import ParsedFinding, RunStatus, ToolRunResult

# WAF header/cookie indicators for the Python fallback
_WAF_SIGNATURES: list[tuple[str, str, str]] = [
    # (waf_name, indicator_type, pattern)
    ("Cloudflare",          "header",  r"cf-ray|cloudflare"),
    ("AWS WAF",             "header",  r"x-amzn-requestid|x-amz-cf-id"),
    ("Akamai",              "header",  r"akamai|x-akamai"),
    ("Imperva / Incapsula", "header",  r"x-iinfo|incap_ses|visid_incap"),
    ("F5 BIG-IP ASM",       "cookie",  r"ts[a-f0-9]{8,}"),
    ("Sucuri",              "header",  r"x-sucuri-id|x-sucuri-cache"),
    ("Barracuda",           "cookie",  r"barra_counter_session"),
    ("ModSecurity",         "header",  r"mod_security|modsecurity"),
    ("Fastly",              "header",  r"x-fastly-request-id|fastly"),
    ("Varnish",             "header",  r"x-varnish|via.*varnish"),
    ("Nginx",               "header",  r"x-nginx-cache"),
    ("Wordfence",           "body",    r"wordfence"),
    ("DDoS-Guard",          "header",  r"ddos-guard"),
    ("Reblaze",             "cookie",  r"rbzid"),
    ("Radware",             "cookie",  r"ns_af"),
]

# Request that WAFs commonly block (LFI-like)
_WAF_PROBE_PATH = "/?id=1+AND+1=1+UNION+SELECT+NULL--"


class Wafw00fTool(BaseTool):

    NAME         = "wafw00f"
    BINARY       = "wafw00f"
    CATEGORY     = "fingerprint"
    STAGE        = 3
    PRIORITY     = 10
    PASSIVE      = False
    TIMEOUT      = 60
    DEPENDENCIES: list[str] = []
    INSTALL_CMD  = "pip install wafw00f"

    # ── run ───────────────────────────────────────────────────────────────────

    def run(
        self,
        target: str,
        *,
        all_waf:    bool           = False,    # test all WAF fingerprints
        no_redirect: bool          = False,
        extra_headers: Optional[dict] = None,
        **kwargs,
    ) -> ToolRunResult:
        """
        Args:
            target:        URL to fingerprint (e.g. https://example.com).
            all_waf:       Test all 160+ WAF signatures (-a flag).
            no_redirect:   Don't follow redirects.
            extra_headers: Additional HTTP headers to include.
        """
        url = self.ensure_scheme(target)
        t0  = time.perf_counter()

        # ── Binary path ───────────────────────────────────────────────────────
        if self.is_available():
            args = [url, "-f", "json", "-o", "/tmp/wafw00f_out.json"]
            if all_waf:
                args.append("-a")
            if no_redirect:
                args.append("--no-redirect")

            res = self.exec(args, timeout_s=float(self.timeout), expected_codes=(0, 1))
            dur = time.perf_counter() - t0

            if res.timed_out:
                return ToolRunResult.timeout(self.NAME, dur, self.timeout)
            if res.returncode == 127:
                return ToolRunResult.skipped(self.NAME, res.stderr)

            raw_json = self._read_file("/tmp/wafw00f_out.json")
            data = (self._parse_json(raw_json) if raw_json
                    else self.parse_output(res.stdout))
            findings = self._build_findings(data)
            r = self.build_result(data, findings, stdout=res.stdout,
                                  duration_s=dur, returncode=res.returncode)
            return r

        # ── Pure-Python header probe fallback ─────────────────────────────────
        self._log("info", "wafw00f binary not found — using HTTP header probe fallback")
        data, err = self._http_probe(url, extra_headers or {})
        dur = time.perf_counter() - t0

        findings = self._build_findings(data)
        r = self.build_result(data, findings, duration_s=dur, returncode=0)
        return r

    # ── parse_output ──────────────────────────────────────────────────────────

    def parse_output(self, raw: str, **kwargs) -> dict:
        if not raw.strip():
            return self._empty()

        ansi_re = re.compile(r"\x1b\[[0-9;]*[A-Za-z]")
        clean   = ansi_re.sub("", raw)
        wafs:   list[str] = []

        for line in clean.splitlines():
            lower = line.lower()
            if "is behind" in lower or "detected" in lower:
                m = re.search(r"behind\s+(.+?)(?:\s+WAF|\s+web|$)", line, re.I)
                if m:
                    wafs.append(m.group(1).strip())
            elif "no waf" in lower or "not detected" in lower:
                pass

        return {
            "wafs":     list(dict.fromkeys(wafs)),
            "detected": bool(wafs),
            "count":    len(wafs),
        }

    # ── internal ──────────────────────────────────────────────────────────────

    def _parse_json(self, raw) -> dict:
        try:
            if isinstance(raw, str):
                import json
                raw = json.loads(raw)
            wafs = []
            if isinstance(raw, list):
                for item in raw:
                    if waf := item.get("firewall", item.get("waf", "")):
                        wafs.append(waf)
            elif isinstance(raw, dict):
                if waf := raw.get("firewall", raw.get("waf", "")):
                    wafs.append(waf)
            return {"wafs": wafs, "detected": bool(wafs), "count": len(wafs)}
        except Exception:
            return self._empty()

    def _http_probe(self, url: str, extra_headers: dict) -> tuple[dict, str]:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode    = ssl.CERT_NONE
        opener = urllib.request.build_opener(urllib.request.HTTPSHandler(context=ctx))

        base = url.rstrip("/")
        probes = [base, base + _WAF_PROBE_PATH]
        detected: list[str] = []

        for probe_url in probes:
            try:
                req = urllib.request.Request(
                    probe_url,
                    headers={
                        "User-Agent": "ReconX/2.0 (wafw00f-probe)",
                        **extra_headers,
                    },
                )
                with opener.open(req, timeout=10) as resp:
                    headers_str = " ".join(
                        f"{k}:{v}" for k, v in resp.headers.items()
                    ).lower()
                    cookies_str = " ".join(
                        v for k, v in resp.headers.items() if k.lower() == "set-cookie"
                    ).lower()
                    body_preview = resp.read(4096).decode("utf-8", errors="replace").lower()

                for waf_name, itype, pattern in _WAF_SIGNATURES:
                    target_str = {
                        "header": headers_str,
                        "cookie": cookies_str,
                        "body":   body_preview,
                    }.get(itype, headers_str)
                    if re.search(pattern, target_str, re.I):
                        if waf_name not in detected:
                            detected.append(waf_name)

            except Exception:
                continue

        return {"wafs": detected, "detected": bool(detected), "count": len(detected)}, ""

    @staticmethod
    def _empty() -> dict:
        return {"wafs": [], "detected": False, "count": 0}

    def _build_findings(self, data: dict) -> list[ParsedFinding]:
        findings = []
        for waf in data.get("wafs", []):
            findings.append(ParsedFinding(
                finding_type="waf_detected",
                value=waf,
                source=self.NAME,
                confidence=0.88,
                metadata={"note": "WAF presence affects testing approach"},
            ))
        if not data.get("detected"):
            findings.append(ParsedFinding(
                finding_type="waf_absent",
                value="No WAF detected",
                source=self.NAME,
                confidence=0.7,
                metadata={"note": "No WAF signatures found — target may be unprotected"},
            ))
        return findings
