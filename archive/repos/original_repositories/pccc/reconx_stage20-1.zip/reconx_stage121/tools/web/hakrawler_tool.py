"""
ReconX — hakrawler web crawler (standardized).
Fast Go-based crawler pulling from Wayback Machine, CommonCrawl, and live crawling.
"""
from __future__ import annotations
import time
from ..base import BaseTool
from ...config.settings import WEB_CONFIG
from ...models.tool_result import ParsedFinding, RunStatus, ToolRunResult


class HakrawlerTool(BaseTool):
    NAME         = "hakrawler"
    BINARY       = "hakrawler"
    CATEGORY     = "web"
    STAGE        = 4
    PRIORITY     = 10
    PASSIVE      = False
    TIMEOUT      = 60
    DEPENDENCIES: list[str] = []
    INSTALL_CMD  = "go install github.com/hakluke/hakrawler@latest"

    def run(self, target: str, *, depth: int = 2, subs: bool = True,
            wayback: bool = True, **kwargs) -> ToolRunResult:
        if s := self.skip_if_unavailable(): return s

        url = self.ensure_scheme(target)
        args = ["-d", str(depth), "-t", "8"]
        if subs:    args.append("-subs")
        if wayback: args.append("-wayback")

        t0  = time.perf_counter()
        res = self.exec(args, stdin_data=url + "\n",
                        timeout_s=float(self.timeout), expected_codes=(0,1))
        dur = time.perf_counter() - t0

        if res.timed_out: return ToolRunResult.timeout(self.NAME, dur, self.timeout)
        if res.returncode == 127: return ToolRunResult.skipped(self.NAME, res.stderr)

        data     = self.parse_output(res.stdout)
        findings = [self._finding("url", u) for u in data["urls"][:500]]
        r = self.build_result(data, findings, stdout=res.stdout, duration_s=dur, returncode=res.returncode)
        if not data["urls"]: r.status = RunStatus.NO_OUTPUT
        return r

    def parse_output(self, raw: str, **kwargs) -> dict:
        if not raw.strip():
            return {"urls": [], "endpoints": [], "js_files": [], "count": 0}
        urls, endpoints, js_files = [], set(), []
        seen: set[str] = set()
        for line in self.parse_lines_output(raw):
            url = self.clean(line)
            if not url.startswith(("http://","https://")) or url in seen: continue
            seen.add(url); urls.append(url)
            path = url.split("?")[0].lower()
            endpoints.add(path)
            if path.endswith(".js"): js_files.append(url)
        return {"urls": urls, "endpoints": sorted(endpoints),
                "js_files": list(dict.fromkeys(js_files)), "count": len(urls)}
