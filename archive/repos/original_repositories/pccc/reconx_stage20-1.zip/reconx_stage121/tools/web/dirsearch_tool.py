"""
ReconX — dirsearch directory bruteforcer (standardized).
Python-based; excellent recursive discovery with built-in wordlists.
"""
from __future__ import annotations
import os, time
from typing import Optional
from ..base import BaseTool
from ...config.settings import WEB_CONFIG
from ...models.tool_result import ParsedFinding, RunStatus, ToolRunResult


class DirsearchTool(BaseTool):
    NAME         = "dirsearch"
    BINARY       = "dirsearch"
    CATEGORY     = "web"
    STAGE        = 4
    PRIORITY     = 30
    PASSIVE      = False
    TIMEOUT      = 300
    DEPENDENCIES: list[str] = []
    INSTALL_CMD  = "pip install dirsearch  OR  git clone https://github.com/maurosoria/dirsearch"

    def run(self, target: str, *, extensions: Optional[list[str]] = None,
            threads: int = 0, wordlist: Optional[str] = None,
            recursive: bool = True, **kwargs) -> ToolRunResult:
        if s := self.skip_if_unavailable(): return s

        url     = self.ensure_scheme(target)
        threads = threads or WEB_CONFIG.get("dirsearch_threads", 30)
        exts    = extensions or WEB_CONFIG.get("extensions_web",
                    ["php","asp","aspx","jsp","html","txt","xml","json","bak","old"])

        args = ["-u", url, "-t", str(threads), "-e", ",".join(exts),
                "--format=plain", "--no-color", "-q"]
        if wordlist and os.path.exists(wordlist):
            args += ["-w", wordlist]
        if recursive:
            args += ["--recursive", "--recursion-depth", str(WEB_CONFIG.get("fuzz_recursion_depth",2))]

        t0  = time.perf_counter()
        res = self.exec(args, timeout_s=float(self.timeout), expected_codes=(0,1))
        dur = time.perf_counter() - t0

        if res.timed_out: return ToolRunResult.timeout(self.NAME, dur, self.timeout)
        if res.returncode == 127: return ToolRunResult.skipped(self.NAME, res.stderr)

        data     = self.parse_output(res.stdout, base_url=url)
        findings = [self._finding("url", e["url"], status=e["status"]) for e in data["found"]]
        r = self.build_result(data, findings, stdout=res.stdout, duration_s=dur, returncode=res.returncode)
        if not data["found"]: r.status = RunStatus.NO_OUTPUT
        return r

    def parse_output(self, raw: str, base_url: str = "", **kwargs) -> dict:
        """
        Parse dirsearch plain output:
          200   1.2KB  http://target.com/admin/
          301   0B     http://target.com/login
        """
        import re
        if not raw.strip():
            return {"found": [], "count": 0}
        _re = re.compile(r'^(\d{3})\s+[\d.]+\w*\s+(https?://\S+)', re.M)
        found: list[dict] = []; seen: set[str] = set()
        for m in _re.finditer(raw):
            status = int(m.group(1)); url = m.group(2).rstrip("/")
            if url in seen: continue
            seen.add(url); found.append({"url": url, "status": status})
        return {"found": found, "count": len(found)}
