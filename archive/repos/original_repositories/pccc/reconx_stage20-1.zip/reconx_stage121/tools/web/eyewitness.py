"""
ReconX — EyeWitness wrapper.

EyeWitness takes screenshots of web services, captures page titles,
detects login pages, and categorizes targets for efficient review.
Integrates screenshot metadata into ReconX reports.

Stage 3 — Active Web Visual Reconnaissance.
"""
from __future__ import annotations
import json
import os
import re
import shutil
import time
from pathlib import Path
from typing import Optional

from ..base import BaseTool
from ...models.tool_result import ParsedFinding, RunStatus, ToolRunResult


class EyeWitnessTool(BaseTool):

    NAME         = "EyeWitness"
    BINARY       = "eyewitness"
    CATEGORY     = "web"
    STAGE        = 3
    PRIORITY     = 30
    PASSIVE      = False
    TIMEOUT      = 300
    DEPENDENCIES: list[str] = []
    INSTALL_CMD  = (
        "sudo apt install eyewitness  # or:\n"
        "git clone https://github.com/RedSiege/EyeWitness && "
        "cd EyeWitness/Python/setup && sudo ./setup.sh"
    )

    # ── run ───────────────────────────────────────────────────────────────────

    def run(
        self,
        target: str,
        *,
        targets_file:  Optional[str] = None,
        output_dir:    str           = "screenshots",
        timeout:       int           = 10,
        threads:       int           = 5,
        prepend_https: bool          = True,
        delay:         float         = 0.0,
        user_agent:    Optional[str] = None,
        **kwargs,
    ) -> ToolRunResult:
        """
        Args:
            target:        Single URL or domain to screenshot.
            targets_file:  Path to file with one URL per line (batch mode).
            output_dir:    Directory to store screenshots and report.
            timeout:       Per-page render timeout (seconds).
            threads:       Concurrent screenshot workers.
            prepend_https: Auto-prepend https:// if no scheme present.
            delay:         Delay between requests (stealth).
            user_agent:    Custom User-Agent string.
        """
        if s := self.skip_if_unavailable():
            return s

        Path(output_dir).mkdir(parents=True, exist_ok=True)
        ts_dir = os.path.join(output_dir, f"ew_{int(time.time())}")

        args = [
            "--web",
            "--timeout",    str(timeout),
            "--threads",    str(threads),
            "--no-prompt",
            "-d",           ts_dir,
        ]

        if targets_file and os.path.exists(targets_file):
            args += ["-f", targets_file]
        else:
            # Write single target to temp file
            tmp_file = "/tmp/ew_targets.txt"
            url = self.ensure_scheme(target) if prepend_https else target
            Path(tmp_file).write_text(url)
            args += ["-f", tmp_file]

        if delay > 0:
            args += ["--delay", str(int(delay * 1000))]
        if user_agent:
            args += ["--user-agent", user_agent]

        t0  = time.perf_counter()
        res = self.exec(args, timeout_s=float(self.timeout), expected_codes=(0, 1))
        dur = time.perf_counter() - t0

        if res.timed_out:
            # Collect whatever screenshots were captured before timeout
            partial = self._collect_screenshots(ts_dir)
            data = {"screenshots": partial, "report_dir": ts_dir,
                    "count": len(partial), "partial": True}
            findings = self._build_findings(data)
            result = self.build_result(
                data, findings, stdout=res.stdout, duration_s=dur, returncode=0,
            )
            result.notes = "Scan timed out — partial screenshots collected."
            return result

        if res.returncode == 127:
            return ToolRunResult.skipped(self.NAME, res.stderr)

        data     = self._collect_results(ts_dir, res.stdout)
        findings = self._build_findings(data)
        result   = self.build_result(
            data, findings, stdout=res.stdout, duration_s=dur, returncode=res.returncode,
        )
        if not findings:
            result.status = RunStatus.NO_OUTPUT
        return result

    # ── parse_output ──────────────────────────────────────────────────────────

    def parse_output(self, raw: str, **kwargs) -> dict:
        """Parse EyeWitness console output for page metadata."""
        if not raw.strip():
            return {"screenshots": [], "count": 0}

        screenshots: list[dict] = []
        url_re   = re.compile(r"(https?://[^\s]+)")
        title_re = re.compile(r"Page Title:\s*(.+)", re.IGNORECASE)
        login_re = re.compile(r"(login|signin|authentication|password)", re.IGNORECASE)

        current: dict = {}
        for line in raw.splitlines():
            line = line.strip()
            if not line:
                if current:
                    screenshots.append(current)
                    current = {}
                continue

            url_m   = url_re.search(line)
            title_m = title_re.search(line)

            if url_m and "Attempting" in line:
                current = {"url": url_m.group(1), "title": "", "login_detected": False, "path": ""}
            elif title_m and current:
                current["title"] = title_m.group(1)
                current["login_detected"] = bool(login_re.search(current["title"]))
            elif "Saved" in line and ".png" in line and current:
                path_m = re.search(r"(/[^\s]+\.png)", line)
                if path_m:
                    current["path"] = path_m.group(1)

        if current:
            screenshots.append(current)

        return {"screenshots": screenshots, "count": len(screenshots)}

    # ── internal ──────────────────────────────────────────────────────────────

    def _collect_results(self, ts_dir: str, stdout: str) -> dict:
        """Merge file-system screenshot scan with console parse."""
        text_data   = self.parse_output(stdout)
        fs_shots    = self._collect_screenshots(ts_dir)
        report_json = self._parse_report_json(ts_dir)

        # Merge
        if report_json:
            return {**report_json, "report_dir": ts_dir}

        # Fallback: combine text parse + filesystem
        merged = text_data["screenshots"]
        path_set = {s.get("path") for s in merged}
        for shot in fs_shots:
            if shot.get("path") not in path_set:
                merged.append(shot)

        return {"screenshots": merged, "report_dir": ts_dir, "count": len(merged)}

    @staticmethod
    def _collect_screenshots(directory: str) -> list[dict]:
        """Walk output directory and collect .png screenshot paths."""
        shots: list[dict] = []
        if not os.path.isdir(directory):
            return shots
        for root, _, files in os.walk(directory):
            for fname in files:
                if fname.endswith(".png"):
                    shots.append({
                        "path":           os.path.join(root, fname),
                        "url":            fname.replace("_", "/").replace(".png", ""),
                        "title":          "",
                        "login_detected": False,
                    })
        return shots

    @staticmethod
    def _parse_report_json(directory: str) -> Optional[dict]:
        """Read EyeWitness report JSON if present."""
        report_path = os.path.join(directory, "report.json")
        try:
            if os.path.exists(report_path):
                with open(report_path) as fh:
                    raw = json.load(fh)
                screenshots = []
                for item in raw.get("targets", []):
                    screenshots.append({
                        "url":            item.get("target", ""),
                        "title":          item.get("title", ""),
                        "path":           item.get("screenshot_path", ""),
                        "login_detected": item.get("login_page", False),
                        "category":       item.get("category", ""),
                        "error":          item.get("error", ""),
                    })
                return {"screenshots": screenshots, "count": len(screenshots)}
        except Exception:
            pass
        return None

    def _build_findings(self, data: dict) -> list[ParsedFinding]:
        findings = []
        for shot in data.get("screenshots", []):
            url   = shot.get("url", "")
            title = shot.get("title", "")
            is_login = shot.get("login_detected", False)

            ftype = "login_page" if is_login else "web_screenshot"
            findings.append(ParsedFinding(
                finding_type=ftype,
                value=url,
                source=self.NAME,
                confidence=0.93,
                metadata={
                    "title":           title,
                    "screenshot_path": shot.get("path", ""),
                    "login_detected":  is_login,
                    "category":        shot.get("category", ""),
                },
            ))
        return findings
