"""
ReconX — JavaScript Analysis Engine.
Fetches and analyses JS files to extract endpoints, API routes,
secret indicators, tokens, GraphQL refs, and WebSocket endpoints.
Pure-Python; no binary required.
"""
from __future__ import annotations
import logging
import re
import ssl
import urllib.request
import urllib.error
from dataclasses import dataclass, field
from typing import Optional
from ...config.settings import WEB_CONFIG

logger = logging.getLogger("reconx.web.js_analyzer")

# ── Extraction patterns ────────────────────────────────────────────────────────
_RE_ENDPOINTS = re.compile(
    r"""["'`](\s*/(?:api|v\d+|graphql|rest|internal|admin|auth|oauth|user|account|file|upload|download|ws|socket|webhook)(?:/[^"'`\s]{0,60})?)\s*["'`]""",
    re.I,
)
_RE_URLS = re.compile(
    r"""["'`](https?://[^"'`\s<>]{8,200})["'`]""",
    re.I,
)
_RE_RELATIVE_PATHS = re.compile(
    r"""["'`](/[a-zA-Z0-9_\-./]{4,80})["'`]""",
)
_RE_GRAPHQL = re.compile(r'(?:query|mutation|subscription)\s+\w+\s*\{', re.I)
_RE_WS      = re.compile(r"""["'`](wss?://[^"'`\s]{4,100})["'`]""", re.I)
_RE_API_KEY = re.compile(
    r"""(?:api_?key|apikey|access_?token|auth_?token|secret|password|passwd|private_?key|client_?secret)\s*[=:]\s*["'`]([A-Za-z0-9_\-./+]{20,80})["'`]""",
    re.I,
)
_RE_AWS     = re.compile(r'\b(AKIA[0-9A-Z]{16})\b')
_RE_JWT     = re.compile(r'\beyJ[A-Za-z0-9\-_=]+\.[A-Za-z0-9\-_=]+\.?[A-Za-z0-9\-_.+/=]*\b')
_RE_IMPORT  = re.compile(r"""(?:import|require)\s*\(?["'`]([^"'`\s]{1,80})["'`]\)?""", re.I)


@dataclass
class JSFinding:
    url:        str
    endpoints:  list[str]    = field(default_factory=list)
    api_routes: list[str]    = field(default_factory=list)
    ext_urls:   list[str]    = field(default_factory=list)
    ws_urls:    list[str]    = field(default_factory=list)
    secrets:    list[dict]   = field(default_factory=list)   # {type, value, masked}
    graphql:    bool         = False
    imports:    list[str]    = field(default_factory=list)
    size_kb:    float        = 0.0
    error:      str          = ""


class JSAnalyzer:
    """Fetches JS files and extracts security-relevant content."""

    def __init__(self, timeout: float = 10.0, max_size_kb: int = 0):
        self.timeout    = timeout
        self.max_size_kb = max_size_kb or WEB_CONFIG.get("js_max_size_kb", 500)
        self._ctx       = ssl.create_default_context()
        self._ctx.check_hostname = False
        self._ctx.verify_mode   = ssl.CERT_NONE

    # ── Public ────────────────────────────────────────────────────────────────

    def analyse_url(self, url: str) -> JSFinding:
        finding = JSFinding(url=url)
        content, err = self._fetch(url)
        if err:
            finding.error = err
            return finding

        finding.size_kb = len(content) / 1024
        return self._analyse_content(url, content)

    def analyse_batch(self, urls: list[str]) -> list[JSFinding]:
        import concurrent.futures
        results: list[JSFinding] = []
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            futures = {pool.submit(self.analyse_url, u): u for u in urls}
            for future in concurrent.futures.as_completed(futures):
                try:
                    results.append(future.result())
                except Exception as exc:
                    url = futures[future]
                    results.append(JSFinding(url=url, error=str(exc)))
        return results

    def analyse_content(self, url: str, content: str) -> JSFinding:
        return self._analyse_content(url, content)

    # ── Analysis ──────────────────────────────────────────────────────────────

    def _analyse_content(self, url: str, content: str) -> JSFinding:
        f = JSFinding(url=url, size_kb=len(content) / 1024)

        # API endpoints
        seen_ep: set[str] = set()
        for m in _RE_ENDPOINTS.finditer(content):
            ep = m.group(1).strip()
            if ep not in seen_ep:
                seen_ep.add(ep)
                f.api_routes.append(ep)

        # Relative paths (broader)
        seen_paths: set[str] = set()
        for m in _RE_RELATIVE_PATHS.finditer(content):
            path = m.group(1)
            # Skip asset-like paths
            if any(path.endswith(ext) for ext in ('.png','.jpg','.css','.woff','.ico')):
                continue
            if path not in seen_paths:
                seen_paths.add(path)
                f.endpoints.append(path)

        # External URLs
        seen_urls: set[str] = set()
        for m in _RE_URLS.finditer(content):
            u = m.group(1)
            if u not in seen_urls:
                seen_urls.add(u)
                f.ext_urls.append(u)

        # WebSocket URLs
        for m in _RE_WS.finditer(content):
            f.ws_urls.append(m.group(1))

        # GraphQL
        f.graphql = bool(_RE_GRAPHQL.search(content))

        # Secrets / credential indicators
        for m in _RE_API_KEY.finditer(content):
            raw_val = m.group(1)
            masked  = raw_val[:4] + "***" + raw_val[-4:] if len(raw_val) > 10 else "***"
            f.secrets.append({"type": "api_credential", "masked": masked, "length": len(raw_val)})

        for m in _RE_AWS.finditer(content):
            f.secrets.append({"type": "aws_access_key", "masked": m.group(1)[:8] + "***", "length": 20})

        for m in _RE_JWT.finditer(content):
            token = m.group(0)
            f.secrets.append({"type": "jwt_token", "masked": token[:12] + "***", "length": len(token)})

        # Module imports (reveals dependencies + potential paths)
        for m in _RE_IMPORT.finditer(content):
            imp = m.group(1)
            if not imp.startswith(("http", "./")):
                f.imports.append(imp)

        # Deduplicate
        f.api_routes = list(dict.fromkeys(f.api_routes))[:100]
        f.endpoints  = list(dict.fromkeys(f.endpoints))[:200]
        f.ext_urls   = list(dict.fromkeys(f.ext_urls))[:100]
        f.imports    = list(dict.fromkeys(f.imports))[:50]

        return f

    # ── Fetch ─────────────────────────────────────────────────────────────────

    def _fetch(self, url: str) -> tuple[str, str]:
        try:
            req = urllib.request.Request(
                url,
                headers={"User-Agent": "ReconX/2.0 (js-analysis)", "Accept": "*/*"},
            )
            handler = urllib.request.HTTPSHandler(context=self._ctx)
            opener  = urllib.request.build_opener(handler)
            with opener.open(req, timeout=self.timeout) as resp:
                content_type = resp.headers.get("Content-Type", "")
                max_bytes    = self.max_size_kb * 1024
                data         = resp.read(int(max_bytes))
                return data.decode("utf-8", errors="replace"), ""
        except urllib.error.HTTPError as exc:
            return "", f"HTTP {exc.code}"
        except Exception as exc:
            return "", str(exc)
