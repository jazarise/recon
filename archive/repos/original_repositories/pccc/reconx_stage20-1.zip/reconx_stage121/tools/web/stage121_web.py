"""
ReconX — Web recon tools (Stage 12.1 additions appended to existing __init__).

Existing tools: gobuster, httpx, nikto, whatweb, wafw00f, etc.
Stage 12.1 adds: DirBuster/dirb, feroxbuster, EyeWitness.
"""
# ── Stage 12.1 additions ──────────────────────────────────────────────────────
from .dirbuster   import DirbusterTool
from .feroxbuster import FeroxbusterTool
from .eyewitness  import EyeWitnessTool

STAGE121_WEB_TOOLS = [DirbusterTool, FeroxbusterTool, EyeWitnessTool]

__all__ = ["DirbusterTool", "FeroxbusterTool", "EyeWitnessTool", "STAGE121_WEB_TOOLS"]
