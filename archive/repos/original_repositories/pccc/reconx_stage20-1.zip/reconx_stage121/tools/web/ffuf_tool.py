"""
ReconX — ffuf web fuzzer (standardized).
Fastest directory/file fuzzer. Auto-calibrates response filtering.
"""
from __future__ import annotations
import os, tempfile, time
from pathlib import Path
from typing import Optional
from ..base import BaseTool
from ...config.settings import WEB_CONFIG, WEB_MINI_WORDLIST
from ...models.tool_result import ParsedFinding, RunStatus, ToolRunResult


class FfufTool(BaseTool):
    NAME         = "ffuf"
    BINARY       = "ffuf"
    CATEGORY     = "web"
    STAGE        = 4
    PRIORITY     = 20
    PASSIVE      = False
    TIMEOUT      = 300
    DEPENDENCIES: list[str] = []
    INSTALL_CMD  = "go install github.com/ffuf/ffuf/v2@latest"

    def run(self, target: str, *, wordlist: Optional[str] = None,
            extensions: Optional[list[str]] = None, threads: int = 0,
            rate: int = 0, recursive: bool = True,
            match_codes: Optional[list[int]] = None, **kwargs) -> ToolRunResult:
        if s := self.skip_if_unavailable(): return s

        url = self.ensure_scheme(target).rstrip("/") + "/FUZZ"
        threads     = threads     or WEB_CONFIG.get("ffuf_threads", 50)
        rate        = rate        or WEB_CONFIG.get("ffuf_rate", 0)
        match_codes = match_codes or WEB_CONFIG.get("fuzz_match_codes", [200,204,301,302,307,401,403])
        exts        = extensions  or WEB_CONFIG.get("extensions_common", ["php","html","txt"])
        max_depth   = WEB_CONFIG.get("fuzz_recursion_depth", 2)

        wl_path = wordlist or WEB_CONFIG.get("wordlist_small","")
        tmp_wl  = None
        t0 = time.perf_counter()

        try:
            if not wl_path or not Path(wl_path).exists():
                with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as f:
                    f.write("\n".join(WEB_MINI_WORDLIST)); tmp_wl = f.name
                wl_path = tmp_wl
                self._log("info", "Using built-in mini wordlist (%d entries)", len(WEB_MINI_WORDLIST))

            args = ["-u", url, "-w", wl_path, "-t", str(threads),
                    "-mc", ",".join(str(c) for c in match_codes),
                    "-json", "-noninteractive", "-s"]
            if rate: args += ["-rate", str(rate)]
            if recursive: args += ["-recursion", "-recursion-depth", str(max_depth)]
            if exts: args += ["-e", ",".join(f".{e}" for e in exts)]
            args += ["-ac"]  # auto-calibrate

            res = self.exec(args, timeout_s=float(self.timeout), expected_codes=(0,1))
        finally:
            if tmp_wl and os.path.exists(tmp_wl): os.unlink(tmp_wl)

        dur = time.perf_counter() - t0
        if res.timed_out: return ToolRunResult.timeout(self.NAME, dur, self.timeout)
        if res.returncode == 127: return ToolRunResult.skipped(self.NAME, res.stderr)

        data     = self.parse_output(res.stdout)
        findings = self._make_findings(data)
        r = self.build_result(data, findings, stdout=res.stdout, duration_s=dur, returncode=res.returncode)
        if not data["found"]: r.status = RunStatus.NO_OUTPUT
        return r

    def parse_output(self, raw: str, **kwargs) -> dict:
        if not raw.strip():
            return {"found": [], "count": 0, "by_status": {}}
        found: list[dict] = []; by_status: dict[int,list] = {}; seen: set[str] = set()
        for obj in self.parse_json_lines_output(raw):
            url = obj.get("url",""); status = obj.get("status",0)
            if not url or url in seen: continue
            seen.add(url)
            entry = {"url": url, "status": status,
                     "length": obj.get("length",0), "words": obj.get("words",0)}
            found.append(entry)
            by_status.setdefault(status,[]).append(url)
        return {"found": found, "count": len(found), "by_status": by_status}

    def _make_findings(self, data: dict) -> list[ParsedFinding]:
        return [self._finding("url", e["url"], status=e["status"]) for e in data["found"]]
