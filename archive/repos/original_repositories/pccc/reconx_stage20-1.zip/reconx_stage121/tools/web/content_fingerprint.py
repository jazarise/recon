"""
ReconX — Content Fingerprinter.
Identifies CMS, frameworks, login pages, admin panels,
and interesting content patterns from HTTP responses.
"""
from __future__ import annotations
import re
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class ContentFingerprint:
    url:          str
    technologies: list[str]  = field(default_factory=list)
    cms:          str         = ""
    framework:    str         = ""
    login_page:   bool        = False
    admin_panel:  bool        = False
    api_endpoint: bool        = False
    error_page:   bool        = False
    interesting:  list[str]   = field(default_factory=list)
    title:        str         = ""
    status_code:  int         = 0


_CMS_PATTERNS: list[tuple[re.Pattern, str]] = [
    (re.compile(r'wp-content|wp-includes|wordpress', re.I), "WordPress"),
    (re.compile(r'joomla',                           re.I), "Joomla"),
    (re.compile(r'drupal',                           re.I), "Drupal"),
    (re.compile(r'typo3',                            re.I), "TYPO3"),
    (re.compile(r'magento',                          re.I), "Magento"),
    (re.compile(r'shopify',                          re.I), "Shopify"),
    (re.compile(r'squarespace',                      re.I), "Squarespace"),
    (re.compile(r'wix\.com',                         re.I), "Wix"),
    (re.compile(r'ghost\.io|content-api',            re.I), "Ghost CMS"),
    (re.compile(r'strapi',                           re.I), "Strapi"),
]

_FRAMEWORK_PATTERNS: list[tuple[re.Pattern, str]] = [
    (re.compile(r'laravel|csrf-token.*laravel|laravel_session', re.I), "Laravel"),
    (re.compile(r'rails|_rails_|rack.session',                  re.I), "Ruby on Rails"),
    (re.compile(r'django|csrfmiddlewaretoken',                  re.I), "Django"),
    (re.compile(r'flask|werkzeug',                              re.I), "Flask"),
    (re.compile(r'spring|x-application-context',               re.I), "Spring"),
    (re.compile(r'asp\.net|__viewstate|x-aspnet',              re.I), "ASP.NET"),
    (re.compile(r'express\.js|x-powered-by.*express',          re.I), "Express.js"),
    (re.compile(r'next\.js|__next',                            re.I), "Next.js"),
    (re.compile(r'nuxt|__nuxt',                                re.I), "Nuxt.js"),
    (re.compile(r'react|_reactrootcontainer',                  re.I), "React"),
    (re.compile(r'angular|ng-version',                         re.I), "Angular"),
    (re.compile(r'vue\.js|vue-router',                         re.I), "Vue.js"),
]

_LOGIN_PATTERNS   = re.compile(r'type=["\']password["\']|login|signin|sign.in|auth|password', re.I)
_ADMIN_PATTERNS   = re.compile(r'admin|administrator|dashboard|management.console', re.I)
_API_PATTERNS     = re.compile(r'"swagger"|"openapi"|"paths"\s*:\s*\{|application/json', re.I)
_ERROR_PATTERNS   = re.compile(r'error|exception|stack.trace|not.found|forbidden|unauthorized', re.I)
_SECRET_INDICATORS = re.compile(
    r'api.key|access.token|secret|password|credential|private.key|authorization', re.I
)


class ContentFingerprinter:
    """Analyses HTTP response content for security intelligence."""

    def fingerprint(
        self,
        url:         str,
        body:        str,
        headers:     dict[str, str] | None = None,
        status_code: int = 200,
        title:       str = "",
    ) -> ContentFingerprint:
        fp = ContentFingerprint(url=url, status_code=status_code, title=title)
        headers = headers or {}
        combined = body[:50000] + " ".join(headers.values())  # cap body size

        # CMS
        for pattern, cms_name in _CMS_PATTERNS:
            if pattern.search(combined):
                fp.cms = cms_name
                fp.technologies.append(cms_name)
                break

        # Framework
        for pattern, fw_name in _FRAMEWORK_PATTERNS:
            if pattern.search(combined):
                fp.framework = fw_name
                fp.technologies.append(fw_name)
                break

        # Server
        server = headers.get("server", "") or headers.get("x-powered-by", "")
        if server:
            fp.technologies.append(server.strip())

        # Page type classification
        fp.login_page   = bool(_LOGIN_PATTERNS.search(combined))
        fp.admin_panel  = bool(_ADMIN_PATTERNS.search(title + body[:5000]))
        fp.api_endpoint = bool(_API_PATTERNS.search(combined))
        fp.error_page   = status_code >= 400 or bool(_ERROR_PATTERNS.search(title))

        # Interesting indicators
        if _SECRET_INDICATORS.search(body[:10000]):
            fp.interesting.append("Possible secret/credential reference in page")
        if "debug" in body[:5000].lower() and status_code == 200:
            fp.interesting.append("Debug content visible in response")
        if "internal server error" in body[:2000].lower():
            fp.interesting.append("Internal server error — may leak stack trace")
        if "x-debug" in headers or "x-forwarded-for" in headers:
            fp.interesting.append("Debug headers present")

        fp.technologies = list(dict.fromkeys(fp.technologies))
        return fp
