"""
ReconX — feroxbuster wrapper.

Feroxbuster is a fast, recursive content discovery tool written in Rust.
It supports automatic recursion into discovered directories, making it
more thorough than single-pass tools like dirb.

Stage 3 — Active Web Content Discovery (recursive).
"""
from __future__ import annotations
import json
import re
import time
from typing import Optional

from ..base import BaseTool
from ...models.tool_result import ParsedFinding, RunStatus, ToolRunResult


class FeroxbusterTool(BaseTool):

    NAME         = "feroxbuster"
    BINARY       = "feroxbuster"
    CATEGORY     = "web"
    STAGE        = 3
    PRIORITY     = 18
    PASSIVE      = False
    TIMEOUT      = 300
    DEPENDENCIES: list[str] = []
    INSTALL_CMD  = (
        "sudo apt install feroxbuster  # or:\n"
        "curl -sL https://raw.githubusercontent.com/epi052/feroxbuster/main/install-nix.sh | bash"
    )

    DEFAULT_WORDLIST = "/usr/share/seclists/Discovery/Web-Content/raft-medium-directories.txt"
    FALLBACK_WORDLIST = "/usr/share/dirb/wordlists/common.txt"

    # ── run ───────────────────────────────────────────────────────────────────

    def run(
        self,
        target: str,
        *,
        wordlist:     Optional[str]       = None,
        extensions:   Optional[list[str]] = None,
        threads:      int                  = 50,
        depth:        int                  = 2,
        filter_codes: Optional[list[int]] = None,
        rate_limit:   int                  = 0,
        quiet:        bool                 = False,
        insecure:     bool                 = True,
        **kwargs,
    ) -> ToolRunResult:
        """
        Args:
            target:       URL to scan.
            wordlist:     Wordlist path (falls back to common.txt if SecLists absent).
            extensions:   Extra file extensions (e.g. ['php', 'bak', 'txt']).
            threads:      Concurrent request threads.
            depth:        Max recursion depth (default: 2).
            filter_codes: HTTP status codes to exclude from output.
            rate_limit:   Max requests/second (0 = unlimited).
            quiet:        Minimal output.
            insecure:     Accept invalid TLS certs (-k flag).
        """
        if s := self.skip_if_unavailable():
            return s

        url = self.ensure_scheme(target)
        wl  = self._resolve_wordlist(wordlist)
        fc  = filter_codes or [404, 500, 503]

        args = [
            "--url",         url,
            "--wordlist",    wl,
            "--threads",     str(threads),
            "--depth",       str(depth),
            "--filter-status", ",".join(str(c) for c in fc),
            "--json",                        # machine-readable output
            "--output",      "/tmp/ferox_out.json",
            "--no-state",                    # don't write .feroxbuster state file
        ]

        if extensions:
            args += ["--extensions", ",".join(e.lstrip(".") for e in extensions)]
        if rate_limit:
            args += ["--rate-limit", str(rate_limit)]
        if insecure:
            args.append("--insecure")
        if quiet:
            args.append("--quiet")

        t0  = time.perf_counter()
        res = self.exec(args, timeout_s=float(self.timeout), expected_codes=(0, 1))
        dur = time.perf_counter() - t0

        if res.timed_out:
            return ToolRunResult.timeout(self.NAME, dur, self.timeout)
        if res.returncode == 127:
            return ToolRunResult.skipped(self.NAME, res.stderr)

        raw_json = self._read_json_file("/tmp/ferox_out.json")
        data = (self._parse_json_output(raw_json)
                if raw_json else self.parse_output(res.stdout))

        findings = self._build_findings(data)
        result   = self.build_result(
            data, findings, stdout=res.stdout, duration_s=dur, returncode=res.returncode,
        )
        if not findings:
            result.status = RunStatus.NO_OUTPUT
        return result

    # ── parse_output ──────────────────────────────────────────────────────────

    def parse_output(self, raw: str, **kwargs) -> dict:
        """Fallback text parser for feroxbuster non-JSON output."""
        if not raw.strip():
            return {"paths": [], "count": 0}

        paths: list[dict] = []
        url_re  = re.compile(r"(https?://[^\s]+)")
        code_re = re.compile(r"\b(\d{3})\b")
        size_re = re.compile(r"\b(\d+)w\b|\b(\d+)c\b")   # words / chars

        ansi_re = re.compile(r"\x1b\[[0-9;]*[A-Za-z]")

        for line in raw.splitlines():
            line  = ansi_re.sub("", line).strip()
            url_m = url_re.search(line)
            if not url_m:
                continue
            code_m = code_re.search(line)
            paths.append({
                "url":    url_m.group(1),
                "code":   int(code_m.group(1)) if code_m else None,
                "words":  None,
                "method": "GET",
            })

        return {"paths": paths, "count": len(paths)}

    # ── internal ──────────────────────────────────────────────────────────────

    def _parse_json_output(self, records: list[dict]) -> dict:
        """Parse feroxbuster NDJSON/JSON array output."""
        paths: list[dict] = []
        for rec in records:
            rtype = rec.get("type", "")
            if rtype not in ("response", "result", ""):
                continue
            url  = rec.get("url", "")
            code = rec.get("status", rec.get("status_code"))
            if url:
                paths.append({
                    "url":      url,
                    "code":     code,
                    "words":    rec.get("word_count"),
                    "lines":    rec.get("line_count"),
                    "method":   rec.get("method", "GET"),
                    "redirect": rec.get("redirect_url", ""),
                })
        return {"paths": paths, "count": len(paths)}

    def _resolve_wordlist(self, requested: Optional[str]) -> str:
        import os
        if requested and os.path.exists(requested):
            return requested
        if os.path.exists(self.DEFAULT_WORDLIST):
            return self.DEFAULT_WORDLIST
        return self.FALLBACK_WORDLIST

    @staticmethod
    def _read_json_file(path: str) -> Optional[list]:
        import os
        results = []
        try:
            if not os.path.exists(path):
                return None
            with open(path) as fh:
                for line in fh:
                    line = line.strip()
                    if line:
                        try:
                            results.append(json.loads(line))
                        except json.JSONDecodeError:
                            pass
            os.unlink(path)
        except Exception:
            return None
        return results if results else None

    def _build_findings(self, data: dict) -> list[ParsedFinding]:
        findings = []
        for p in data.get("paths", []):
            url  = p.get("url", "")
            code = p.get("code")
            low  = url.lower()
            ftype = (
                "admin_panel"  if any(k in low for k in ("/admin", "/manager", "/console", "/dashboard")) else
                "login_page"   if any(k in low for k in ("/login", "/signin", "/auth", "/portal")) else
                "backup_file"  if any(k in low for k in (".bak", ".old", ".backup", "~")) else
                "api_endpoint" if "/api/" in low else
                "web_path"
            )
            findings.append(ParsedFinding(
                finding_type=ftype,
                value=url,
                source=self.NAME,
                confidence=0.88,
                metadata={"http_code": code, "words": p.get("words")},
            ))
        return findings
