"""
ReconX — Endpoint Classifier & Parameter Extractor.
Classifies discovered URLs into meaningful categories and
extracts parameter names from query strings.
"""
from __future__ import annotations
import re
from dataclasses import dataclass, field
from urllib.parse import urlparse, parse_qs
from ...config.settings import WEB_CONFIG


@dataclass
class ClassifiedEndpoint:
    url:        str
    path:       str
    category:   str     # admin|login|api|debug|upload|dashboard|static|other
    risk:       str     # HIGH|MEDIUM|LOW
    params:     list[str] = field(default_factory=list)
    status_code: int    = 0
    title:      str     = ""
    is_interesting: bool = False


class EndpointClassifier:
    """Classifies URLs into security-relevant categories."""

    _ADMIN_RE   = re.compile(r'/' + '|/'.join(WEB_CONFIG.get("admin_paths", [])), re.I)
    _API_RE     = re.compile(r'/' + '|/'.join(WEB_CONFIG.get("api_indicators", [])), re.I)
    _DEBUG_RE   = re.compile(r'/' + '|/'.join(WEB_CONFIG.get("debug_paths", [])), re.I)
    _UPLOAD_RE  = re.compile(r'/' + '|/'.join(WEB_CONFIG.get("upload_paths", [])), re.I)
    _SECRET_RE  = re.compile(r'(?:\.env|config\.php|\.git|wp-config|backup|\.sql|\.bak|\.log|id_rsa|\.pem)', re.I)
    _STATIC_RE  = re.compile(r'\.(css|js|png|jpg|jpeg|gif|svg|ico|woff|woff2|ttf|eot|map)$', re.I)

    def classify(self, url: str, status_code: int = 0, title: str = "") -> ClassifiedEndpoint:
        try:
            parsed = urlparse(url)
            path   = parsed.path.lower()
        except Exception:
            return ClassifiedEndpoint(url=url, path="", category="other",
                                       risk="LOW", status_code=status_code)

        # Extract params
        params = list(parse_qs(parsed.query).keys())

        # Classify
        if self._SECRET_RE.search(path):
            cat, risk = "secret_file", "CRITICAL"
        elif self._ADMIN_RE.search(path):
            cat, risk = "admin", "HIGH"
        elif self._DEBUG_RE.search(path):
            cat, risk = "debug", "HIGH"
        elif self._UPLOAD_RE.search(path):
            cat, risk = "upload", "HIGH"
        elif self._API_RE.search(path):
            cat, risk = "api", "MEDIUM"
        elif self._STATIC_RE.search(path):
            cat, risk = "static", "LOW"
        elif any(k in path for k in ("login", "signin", "auth", "oauth", "sso")):
            cat, risk = "login", "MEDIUM"
        elif any(k in path for k in ("dashboard", "panel", "portal", "console")):
            cat, risk = "dashboard", "HIGH"
        else:
            cat, risk = "other", "LOW"

        interesting = risk in ("CRITICAL", "HIGH") or bool(params)

        return ClassifiedEndpoint(
            url=url, path=parsed.path,
            category=cat, risk=risk,
            params=params, status_code=status_code,
            title=title, is_interesting=interesting,
        )

    def classify_batch(self, urls: list[str]) -> list[ClassifiedEndpoint]:
        return [self.classify(u) for u in urls]

    def filter_interesting(self, endpoints: list[ClassifiedEndpoint]) -> list[ClassifiedEndpoint]:
        return [e for e in endpoints if e.is_interesting]


class ParameterExtractor:
    """Extracts and deduplicates parameter names across all discovered URLs."""

    _RE_PARAM = re.compile(r'[?&]([a-zA-Z0-9_\-]{1,40})=', )

    def extract_from_urls(self, urls: list[str]) -> dict[str, list[str]]:
        """Returns {param_name: [urls containing it]}"""
        param_map: dict[str, list[str]] = {}
        for url in urls:
            for m in self._RE_PARAM.finditer(url):
                name = m.group(1)
                param_map.setdefault(name, [])
                if url not in param_map[name]:
                    param_map[name].append(url)
        return param_map

    def unique_params(self, urls: list[str]) -> list[str]:
        return sorted(self.extract_from_urls(urls).keys())

    def high_value_params(self, urls: list[str]) -> list[str]:
        """Parameters that commonly indicate injection points."""
        risky = {
            "id","user","username","email","password","file","path","url","redirect",
            "return","next","page","query","q","search","cmd","exec","command","shell",
            "token","key","api","debug","admin","load","include","template","view",
            "callback","jsonp","xml","data","input","output","format","type","lang",
        }
        found = set(self.unique_params(urls))
        return sorted(found & risky)
