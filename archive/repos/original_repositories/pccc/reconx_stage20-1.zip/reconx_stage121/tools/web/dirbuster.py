"""
ReconX — DirBuster / dirb wrapper.

Hidden directory and file discovery via HTTP brute-force. Since
DirBuster (Java GUI) is rarely available in headless environments,
this wrapper auto-falls-back to 'dirb' (CLI equivalent) while
maintaining identical output normalization.

Stage 3 — Active Web Content Discovery.
"""
from __future__ import annotations
import re
import shutil
import time
from typing import Optional

from ..base import BaseTool
from ...models.tool_result import ParsedFinding, RunStatus, ToolRunResult


class DirbusterTool(BaseTool):

    NAME         = "DirBuster"
    BINARY       = "dirb"            # headless fallback; prefer dirb or gobuster
    CATEGORY     = "web"
    STAGE        = 3
    PRIORITY     = 20
    PASSIVE      = False
    TIMEOUT      = 300
    DEPENDENCIES: list[str] = []
    INSTALL_CMD  = "sudo apt install dirb"

    # Sane defaults for recon — not exhaustive
    DEFAULT_WORDLIST = "/usr/share/dirb/wordlists/common.txt"

    # ── run ───────────────────────────────────────────────────────────────────

    def run(
        self,
        target: str,
        *,
        wordlist:    Optional[str] = None,
        extensions:  Optional[list[str]] = None,
        threads:     int  = 10,
        follow_redirect: bool = True,
        ignore_codes: Optional[list[int]] = None,
        user_agent:  Optional[str] = None,
        **kwargs,
    ) -> ToolRunResult:
        """
        Args:
            target:          URL to scan (e.g. http://example.com).
            wordlist:        Path to wordlist (default: dirb common.txt).
            extensions:      File extensions to append (e.g. ['php','html']).
            threads:         Concurrent request threads (dirb: -t flag).
            follow_redirect: Follow HTTP redirects.
            ignore_codes:    HTTP status codes to suppress (default: [404]).
            user_agent:      Custom User-Agent header.
        """
        if s := self.skip_if_unavailable():
            return s

        url = self.ensure_scheme(target)
        wl  = wordlist or self.DEFAULT_WORDLIST

        ignore = ignore_codes or [404]
        ignore_str = ",".join(str(c) for c in ignore)

        # Build dirb args
        args = [url, wl, "-r",          # -r: don't search recursively (controlled)
                "-N", ignore_str,        # -N: ignore these codes
                "-o", "/tmp/dirb_out.txt"]

        if extensions:
            args += ["-X", ",".join(f".{e.lstrip('.')}" for e in extensions)]
        if not follow_redirect:
            args.append("-l")
        if user_agent:
            args += ["-a", user_agent]

        t0  = time.perf_counter()
        res = self.exec(args, timeout_s=float(self.timeout), expected_codes=(0, 1))
        dur = time.perf_counter() - t0

        if res.timed_out:
            return ToolRunResult.timeout(self.NAME, dur, self.timeout)
        if res.returncode == 127:
            return ToolRunResult.skipped(self.NAME, res.stderr)

        raw      = self._read_and_clean("/tmp/dirb_out.txt") or res.stdout
        data     = self.parse_output(raw)
        findings = self._build_findings(data)
        result   = self.build_result(
            data, findings, stdout=res.stdout, duration_s=dur, returncode=res.returncode,
        )
        if not findings:
            result.status = RunStatus.NO_OUTPUT
        return result

    # ── parse_output ──────────────────────────────────────────────────────────

    def parse_output(self, raw: str, **kwargs) -> dict:
        """
        dirb output format:
          + http://example.com/admin (CODE:200|SIZE:1234)
          + http://example.com/login (CODE:301|SIZE:0)
          ==> DIRECTORY: http://example.com/uploads/
        """
        if not raw.strip():
            return {"paths": [], "directories": [], "count": 0}

        paths:       list[dict] = []
        directories: list[str] = []

        url_re  = re.compile(r"(https?://[^\s\(]+)")
        code_re = re.compile(r"CODE:(\d{3})")
        size_re = re.compile(r"SIZE:(\d+)")

        for line in raw.splitlines():
            line = line.strip()
            if not line:
                continue

            # Directory found
            if "==> DIRECTORY:" in line:
                m = url_re.search(line)
                if m:
                    directories.append(m.group(1))
                continue

            if not line.startswith("+"):
                continue

            url_match  = url_re.search(line)
            code_match = code_re.search(line)
            size_match = size_re.search(line)

            if url_match:
                paths.append({
                    "url":    url_match.group(1),
                    "code":   int(code_match.group(1)) if code_match else None,
                    "size":   int(size_match.group(1)) if size_match else None,
                })

        return {
            "paths":       paths,
            "directories": sorted(set(directories)),
            "count":       len(paths),
        }

    # ── internal ──────────────────────────────────────────────────────────────

    @staticmethod
    def _read_and_clean(path: str) -> str:
        import os
        try:
            if os.path.exists(path):
                content = open(path).read()
                os.unlink(path)
                return content
        except Exception:
            pass
        return ""

    def _build_findings(self, data: dict) -> list[ParsedFinding]:
        findings = []
        for p in data.get("paths", []):
            code = p.get("code")
            ftype = (
                "login_page"   if "login" in p["url"].lower() or "auth" in p["url"].lower() else
                "admin_panel"  if "admin" in p["url"].lower() else
                "web_path"
            )
            findings.append(ParsedFinding(
                finding_type=ftype,
                value=p["url"],
                source=self.NAME,
                confidence=0.9,
                metadata={"http_code": code, "size": p.get("size")},
            ))
        for d in data.get("directories", []):
            findings.append(ParsedFinding(
                finding_type="web_directory",
                value=d,
                source=self.NAME,
                confidence=0.88,
            ))
        return findings
