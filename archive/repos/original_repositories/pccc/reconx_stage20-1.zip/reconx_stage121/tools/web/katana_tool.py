"""
ReconX — Katana web crawler (standardized).
Next-generation crawling framework by ProjectDiscovery.
Supports JavaScript rendering, form submission, headless mode.
"""
from __future__ import annotations
import time
from typing import Optional
from ..base import BaseTool
from ...config.settings import WEB_CONFIG
from ...models.tool_result import ParsedFinding, RunStatus, ToolRunResult


class KatanaTool(BaseTool):
    NAME         = "katana"
    BINARY       = "katana"
    CATEGORY     = "web"
    STAGE        = 4
    PRIORITY     = 5
    PASSIVE      = False
    TIMEOUT      = 120
    DEPENDENCIES: list[str] = []
    INSTALL_CMD  = "go install github.com/projectdiscovery/katana/cmd/katana@latest"

    def run(
        self,
        target:     str,
        *,
        depth:      int  = 0,
        concurrency:int  = 0,
        rate_limit: int  = 0,
        js_crawl:   bool = True,
        headless:   bool = False,
        scope:      str  = "",
        **kwargs,
    ) -> ToolRunResult:
        if s := self.skip_if_unavailable(): return s

        url = self.ensure_scheme(target)
        depth       = depth       or WEB_CONFIG.get("crawl_depth",       3)
        concurrency = concurrency or WEB_CONFIG.get("crawl_concurrency", 10)
        rate_limit  = rate_limit  or WEB_CONFIG.get("crawl_rate_limit",  150)
        scope       = scope       or WEB_CONFIG.get("crawl_scope",       "fqdn")
        max_urls    = WEB_CONFIG.get("crawl_max_urls", 5000)

        args = [
            "-u",  url,
            "-d",  str(depth),
            "-c",  str(concurrency),
            "-rl", str(rate_limit),
            "-fs", scope,
            "-json",
            "-silent",
            "-no-color",
        ]
        if js_crawl:
            args.append("-jc")
        if headless:
            args.append("-headless")

        # Skip large static files
        skip_ext = ",".join(WEB_CONFIG.get("crawl_extensions_skip", []))
        if skip_ext:
            args += ["-fx", skip_ext]

        t0  = time.perf_counter()
        res = self.exec(args, timeout_s=float(self.timeout), expected_codes=(0, 1))
        dur = time.perf_counter() - t0

        if res.timed_out: return ToolRunResult.timeout(self.NAME, dur, self.timeout)
        if res.returncode == 127: return ToolRunResult.skipped(self.NAME, res.stderr)

        data     = self.parse_output(res.stdout, max_urls=max_urls)
        findings = self._make_findings(data)
        r = self.build_result(data, findings, stdout=res.stdout, duration_s=dur, returncode=res.returncode)
        if not data["urls"]: r.status = RunStatus.NO_OUTPUT
        return r

    def parse_output(self, raw: str, max_urls: int = 5000, **kwargs) -> dict:
        if not raw.strip():
            return {"urls": [], "endpoints": [], "js_files": [], "forms": [], "count": 0}

        urls:      list[str] = []
        endpoints: set[str]  = set()
        js_files:  list[str] = []
        forms:     list[str] = []
        seen:      set[str]  = set()

        for obj in self.parse_json_lines_output(raw):
            url = obj.get("endpoint", "") or obj.get("url", "")
            if not url or url in seen: continue
            seen.add(url)
            if not url.startswith(("http://","https://")): continue
            urls.append(url)

            # Classify
            path = url.split("?")[0].lower()
            if path.endswith(".js"):
                js_files.append(url)
            if obj.get("tag") == "form" or "form" in obj.get("attribute","").lower():
                forms.append(url)
            endpoints.add(path)

            if len(urls) >= max_urls: break

        return {
            "urls":      urls,
            "endpoints": sorted(endpoints),
            "js_files":  list(dict.fromkeys(js_files)),
            "forms":     list(dict.fromkeys(forms)),
            "count":     len(urls),
        }

    def _make_findings(self, data: dict) -> list[ParsedFinding]:
        f  = [self._finding("url", u) for u in data["urls"][:500]]
        f += [self._finding("js_file", j) for j in data["js_files"]]
        return f
