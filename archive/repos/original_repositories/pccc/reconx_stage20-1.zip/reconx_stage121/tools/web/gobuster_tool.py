"""
ReconX — gobuster directory/file fuzzer (standardized).
Supports dir, dns, vhost, and fuzz modes.
"""
from __future__ import annotations
import os, tempfile, time
from pathlib import Path
from typing import Optional
from ..base import BaseTool
from ...config.settings import WEB_CONFIG, WEB_MINI_WORDLIST
from ...models.tool_result import ParsedFinding, RunStatus, ToolRunResult


class GobusterTool(BaseTool):
    NAME         = "gobuster"
    BINARY       = "gobuster"
    CATEGORY     = "web"
    STAGE        = 4
    PRIORITY     = 25
    PASSIVE      = False
    TIMEOUT      = 300
    DEPENDENCIES: list[str] = []
    INSTALL_CMD  = "go install github.com/OJ/gobuster/v3@latest"

    def run(self, target: str, *, mode: str = "dir",
            wordlist: Optional[str] = None, threads: int = 0,
            extensions: Optional[list[str]] = None,
            status_codes: Optional[list[int]] = None, **kwargs) -> ToolRunResult:
        if s := self.skip_if_unavailable(): return s

        url     = self.ensure_scheme(target)
        threads = threads or WEB_CONFIG.get("gobuster_threads", 50)
        codes   = status_codes or WEB_CONFIG.get("fuzz_match_codes", [200,204,301,302,307,401,403])
        exts    = extensions or WEB_CONFIG.get("extensions_common", ["php","html","txt"])

        wl_path = wordlist or WEB_CONFIG.get("wordlist_small","")
        tmp_wl  = None
        t0 = time.perf_counter()

        try:
            if not wl_path or not Path(wl_path).exists():
                with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as f:
                    f.write("\n".join(WEB_MINI_WORDLIST)); tmp_wl = f.name
                wl_path = tmp_wl

            args = [mode, "-u", url, "-w", wl_path, "-t", str(threads),
                    "-s", ",".join(str(c) for c in codes), "--no-progress", "-q"]
            if mode == "dir" and exts:
                args += ["-x", ",".join(exts)]

            res = self.exec(args, timeout_s=float(self.timeout), expected_codes=(0,1))
        finally:
            if tmp_wl and os.path.exists(tmp_wl): os.unlink(tmp_wl)

        dur = time.perf_counter() - t0
        if res.timed_out: return ToolRunResult.timeout(self.NAME, dur, self.timeout)
        if res.returncode == 127: return ToolRunResult.skipped(self.NAME, res.stderr)

        data     = self.parse_output(res.stdout, base_url=url)
        findings = [self._finding("url", e["url"], status=e.get("status",0)) for e in data["found"]]
        r = self.build_result(data, findings, stdout=res.stdout, duration_s=dur, returncode=res.returncode)
        if not data["found"]: r.status = RunStatus.NO_OUTPUT
        return r

    def parse_output(self, raw: str, base_url: str = "", **kwargs) -> dict:
        """
        Parse gobuster output lines:
          /admin (Status: 200) [Size: 1234]
          Found: /login [Status: 301]
        """
        import re
        if not raw.strip():
            return {"found": [], "count": 0}
        _re = re.compile(r'^(/\S*)\s+\(?[Ss]tatus:\s*(\d+)\)?', re.M)
        found: list[dict] = []; seen: set[str] = set()
        for m in _re.finditer(raw):
            path = m.group(1); status = int(m.group(2))
            url  = base_url.rstrip("/") + path if base_url else path
            if url in seen: continue
            seen.add(url); found.append({"url": url, "path": path, "status": status})
        return {"found": found, "count": len(found)}
