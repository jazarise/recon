"""
ReconX — Web Reconnaissance Pipeline.

Flow:
  HTTP Targets → Katana Crawl → Hakrawler →
  JS Analysis → Endpoint Classification → Parameter Extraction →
  ffuf/gobuster/dirsearch Content Discovery →
  Content Fingerprint → Attack Surface Report
"""
from __future__ import annotations
import logging
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from typing import Optional

from rich import box
from rich.columns import Columns
from rich.console import Console
from rich.panel import Panel
from rich.rule import Rule
from rich.table import Table
from rich.text import Text

from .katana_tool        import KatanaTool
from .hakrawler_tool     import HakrawlerTool
from .ffuf_tool          import FfufTool
from .gobuster_tool      import GobusterTool
from .dirsearch_tool     import DirsearchTool
from .js_analyzer        import JSAnalyzer
from .endpoint_classifier import EndpointClassifier, ParameterExtractor
from .content_fingerprint import ContentFingerprinter
from ...models.findings    import ReconResult
from ...models.tool_result import RunStatus, ToolRunResult
from ...config.settings    import WEB_CONFIG

logger = logging.getLogger("reconx.web.pipeline")

_R  = "red"; _RB = "bold red"; _RD = "dim red"
_G  = "bold green"; _Y = "yellow"; _D = "dim"


@dataclass
class WebStageStats:
    stage:      str
    tool:       str
    status:     RunStatus
    urls_found: int   = 0
    duration_s: float = 0.0
    detail:     str   = ""


class WebPipeline:
    """Orchestrates the full web reconnaissance and content discovery flow."""

    def __init__(self, console: Optional[Console] = None, silent: bool = False,
                 mode: str = "balanced", run_bruteforce: bool = True):
        self.console       = console or Console()
        self.silent        = silent
        self.mode          = mode
        self.run_bf        = run_bruteforce
        self.js_analyzer   = JSAnalyzer()
        self.classifier    = EndpointClassifier()
        self.param_extractor = ParameterExtractor()
        self.fingerprinter = ContentFingerprinter()

    def run(self, target: str, result: ReconResult) -> list[WebStageStats]:
        stats: list[WebStageStats] = []
        t0 = time.perf_counter()
        url = f"https://{target}" if not target.startswith("http") else target

        self._header(target)

        # ── Step 1: Parallel crawling ─────────────────────────────────────────
        self._section("Step 1 — Web Crawling")
        crawl_stats = self._step_crawl(url, result)
        stats.extend(crawl_stats)

        # ── Step 2: JavaScript analysis ───────────────────────────────────────
        js_files = result.raw.get("js_files", [])
        if js_files:
            self._section("Step 2 — JavaScript Analysis")
            s = self._step_js_analysis(js_files, result)
            stats.append(s)

        # ── Step 3: Endpoint classification ──────────────────────────────────
        all_urls = list(dict.fromkeys(result.web_endpoints))
        if all_urls:
            self._section("Step 3 — Endpoint Classification")
            s = self._step_classify(all_urls, result)
            stats.append(s)

        # ── Step 4: Parameter extraction ──────────────────────────────────────
        if all_urls:
            params = self.param_extractor.unique_params(all_urls)
            risky  = self.param_extractor.high_value_params(all_urls)
            result.raw["params"]       = params
            result.raw["risky_params"] = risky
            if params:
                self._print(f"  [{_G}]✔  Parameters: {len(params)} unique, "
                            f"{len(risky)} high-value ({', '.join(risky[:5])}{'…' if len(risky)>5 else ''})[/{_G}]")
            stats.append(WebStageStats("params","ParameterExtractor",RunStatus.SUCCESS,
                                       urls_found=len(params),detail=f"{len(risky)} risky"))

        # ── Step 5: Content discovery ──────────────────────────────────────────
        if self.run_bf:
            self._section("Step 4 — Content Discovery (Bruteforce)")
            bf_stats = self._step_bruteforce(url, result)
            stats.extend(bf_stats)

        self._print_summary(stats, time.perf_counter() - t0)
        return stats

    # ── Step implementations ──────────────────────────────────────────────────

    def _step_crawl(self, url: str, result: ReconResult) -> list[WebStageStats]:
        stats: list[WebStageStats] = []
        crawlers = [("katana", KatanaTool()), ("hakrawler", HakrawlerTool())]

        for name, tool in crawlers:
            t0 = time.perf_counter()
            tr = tool.safe_run(url)
            dur = time.perf_counter() - t0
            stat = WebStageStats(f"crawl_{name}", name, tr.status, duration_s=dur)

            if tr.ok:
                urls = tr.data.get("urls",[])
                result.web_endpoints.extend(urls)
                js = tr.data.get("js_files",[])
                result.raw.setdefault("js_files",[]).extend(js)
                stat.urls_found = len(urls)
                stat.detail = f"{len(urls)} URLs, {len(js)} JS files"
                self._print(f"  [{_G}]✔  {name}: {len(urls):,} URLs [{dur:.1f}s][/{_G}]")
            elif tr.status == RunStatus.SKIPPED:
                stat.detail = f"{name} not installed"
                self._print(f"  [{_D}]○  {name} not found — skipped[/{_D}]")
            else:
                stat.detail = tr.error.message if tr.error else "failed"
                self._print(f"  [{_Y}]⚠  {name}: {stat.detail}[/{_Y}]")

            stats.append(stat)

        # Deduplicate
        result.web_endpoints = list(dict.fromkeys(result.web_endpoints))
        result.raw["js_files"] = list(dict.fromkeys(result.raw.get("js_files",[])))
        return stats

    def _step_js_analysis(self, js_files: list[str], result: ReconResult) -> WebStageStats:
        t0 = time.perf_counter()
        max_js = 20  # cap to avoid long waits
        files  = js_files[:max_js]

        findings = self.js_analyzer.analyse_batch(files)
        dur = time.perf_counter() - t0

        all_routes: list[str] = []
        all_secrets: list[dict] = []
        graphql_found = False

        for f in findings:
            all_routes.extend(f.api_routes)
            all_secrets.extend(f.secrets)
            if f.graphql:
                graphql_found = True
            result.web_endpoints.extend(f.endpoints[:50])

        all_routes = list(dict.fromkeys(all_routes))
        result.raw["js_api_routes"] = all_routes
        result.raw["js_secrets"]    = all_secrets

        detail_parts = [f"{len(all_routes)} API routes"]
        if all_secrets:
            detail_parts.append(f"⚠ {len(all_secrets)} secret indicators")
        if graphql_found:
            detail_parts.append("GraphQL detected")
        detail = " | ".join(detail_parts)

        color = _Y if all_secrets else _G
        self._print(f"  [{color}]{'⚠' if all_secrets else '✔'}  JS analysis ({len(files)} files): {detail}[/{color}]")

        return WebStageStats("js_analysis","JSAnalyzer", RunStatus.SUCCESS,
                             urls_found=len(all_routes), duration_s=dur, detail=detail)

    def _step_classify(self, urls: list[str], result: ReconResult) -> WebStageStats:
        t0 = time.perf_counter()
        endpoints = self.classifier.classify_batch(urls)
        dur = time.perf_counter() - t0

        interesting = self.classifier.filter_interesting(endpoints)
        by_cat: dict[str,int] = {}
        for ep in endpoints:
            by_cat[ep.category] = by_cat.get(ep.category,0) + 1

        result.raw["classified_endpoints"] = [
            {"url": ep.url, "category": ep.category, "risk": ep.risk, "params": ep.params}
            for ep in interesting
        ]

        high_risk = [ep for ep in interesting if ep.risk in ("CRITICAL","HIGH")]
        for ep in high_risk[:5]:
            self._print(f"  [{_RB}]  ⚠  [{ep.risk}] {ep.category}: {ep.url}[/{_RB}]")

        cats_str = " | ".join(f"{k}:{v}" for k,v in sorted(by_cat.items()) if k!="static")
        detail   = f"{len(interesting)} interesting | {cats_str}"
        self._print(f"  [{_G}]✔  Classified {len(urls):,} URLs — {len(high_risk)} high risk[/{_G}]")

        return WebStageStats("classify","EndpointClassifier",RunStatus.SUCCESS,
                             urls_found=len(interesting),duration_s=dur,detail=detail)

    def _step_bruteforce(self, url: str, result: ReconResult) -> list[WebStageStats]:
        stats: list[WebStageStats] = []
        # Try tools in order — first available wins
        for name, ToolCls in [("ffuf",FfufTool),("gobuster",GobusterTool),("dirsearch",DirsearchTool)]:
            tool = ToolCls()
            if not tool.is_available(): continue

            t0  = time.perf_counter()
            tr  = tool.safe_run(url)
            dur = time.perf_counter() - t0

            stat = WebStageStats(f"bruteforce_{name}", name, tr.status, duration_s=dur)
            if tr.ok:
                found = tr.data.get("found",[])
                for f in found:
                    fu = f.get("url","")
                    if fu: result.web_endpoints.append(fu)
                result.web_endpoints = list(dict.fromkeys(result.web_endpoints))
                stat.urls_found = len(found)
                stat.detail     = f"{len(found)} paths found"
                self._print(f"  [{_G}]✔  {name}: {len(found)} paths found [{dur:.1f}s][/{_G}]")
            elif tr.status == RunStatus.SKIPPED:
                stat.detail = f"{name} not installed"; continue
            else:
                stat.detail = tr.error.message if tr.error else "failed"
                self._print(f"  [{_Y}]⚠  {name}: {stat.detail}[/{_Y}]")

            stats.append(stat)
            break  # one bruteforce tool is enough per run

        if not stats:
            self._print(f"  [{_D}]○  No bruteforce tool available (ffuf/gobuster/dirsearch)[/{_D}]")
            stats.append(WebStageStats("bruteforce","none",RunStatus.SKIPPED,
                                       detail="No tool installed"))
        return stats

    # ── Rich UI ───────────────────────────────────────────────────────────────

    def _header(self, target: str) -> None:
        if self.silent: return
        self.console.print()
        self.console.print(Panel(
            f"[{_RB}]WEB RECON PIPELINE[/{_RB}]\n"
            f"[{_D}]Target:[/{_D}] [{_R}]{target}[/{_R}]   "
            f"[{_D}]Bruteforce:[/{_D}] [{_R}]{'ON' if self.run_bf else 'OFF'}[/{_R}]",
            border_style=_R, padding=(0,3),
        ))

    def _section(self, label: str) -> None:
        if not self.silent:
            self.console.print()
            self.console.print(Rule(f"[{_RD}]  {label}  [/{_RD}]", style=_R))

    def _print(self, msg: str) -> None:
        if not self.silent: self.console.print(msg)

    def _print_summary(self, stats: list[WebStageStats], total_t: float) -> None:
        if self.silent: return
        self.console.print()
        self.console.print(Rule(f"[{_RB}]  WEB RECON COMPLETE  [/{_RB}]", style=_R))
        self.console.print()
        total_urls = sum(s.urls_found for s in stats)
        ok   = sum(1 for s in stats if s.status == RunStatus.SUCCESS)
        skip = sum(1 for s in stats if s.status == RunStatus.SKIPPED)
        self.console.print(Columns([
            Panel(f"[{_RB}]{total_urls:,}[/{_RB}]\n[{_D}]TOTAL URLS[/{_D}]",
                  border_style=_R, padding=(0,3), expand=True),
            Panel(f"[{_G}]{ok}[/{_G}]\n[{_D}]STEPS OK[/{_D}]",
                  border_style="green", padding=(0,3), expand=True),
            Panel(f"[{_D}]{skip}[/{_D}]\n[{_D}]SKIPPED[/{_D}]",
                  border_style="dim", padding=(0,3), expand=True),
            Panel(f"[white]{total_t:.1f}s[/white]\n[{_D}]TIME[/{_D}]",
                  border_style=_RD, padding=(0,3), expand=True),
        ], equal=True, expand=True))
        self.console.print()
