"""
ReconX — WHOIS tool wrapper.
"""
from __future__ import annotations
import logging
import re

from .base import BaseTool

logger = logging.getLogger("reconx.tools.whois")


class WhoisTool(BaseTool):
    BINARY = "whois"
    NAME = "WHOIS"

    def run(self, target: str, **kwargs) -> dict:
        self.require()
        stdout, stderr, rc = self._run([target], timeout=20)

        if rc != 0 or not stdout.strip():
            logger.warning("WHOIS returned no data for %s", target)
            return {}

        return self._parse(stdout)

    # ── Parser ────────────────────────────────────────────────────────────────

    @staticmethod
    def _parse(raw: str) -> dict:
        result: dict = {"raw": raw, "registrar": "", "creation_date": "",
                        "expiry_date": "", "name_servers": [], "registrant_org": "",
                        "emails": []}

        patterns = {
            "registrar":        r"(?i)Registrar:\s*(.+)",
            "creation_date":    r"(?i)Creation Date:\s*(.+)",
            "expiry_date":      r"(?i)(?:Expir[a-z]+ Date|Registry Expiry Date):\s*(.+)",
            "registrant_org":   r"(?i)Registrant Organization:\s*(.+)",
        }

        for key, pattern in patterns.items():
            m = re.search(pattern, raw)
            if m:
                result[key] = m.group(1).strip()

        # Name servers
        result["name_servers"] = re.findall(r"(?i)Name Server:\s*(.+)", raw)
        result["name_servers"] = [ns.strip().lower() for ns in result["name_servers"]]

        # Email addresses
        result["emails"] = list(set(re.findall(
            r"[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+", raw
        )))

        return result
