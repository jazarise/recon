"""
ReconX — Tool Registry (Stage 12.3).

Merges with Stages 12.1 and 12.2 registries.

Usage:
    from reconx.tools.registry_123 import get_full_registry_123
    registry = get_full_registry_123()
"""
from __future__ import annotations
import importlib
import logging
from typing import Any

log = logging.getLogger("reconx.registry.123")

_STAGE123_SPEC: list[tuple[str, str, dict]] = [
    # DNS Intelligence
    ("MassDNSTool",      "tools.dns_intel.massdns",    {}),
    ("ShuffleDNSTool",   "tools.dns_intel.shuffledns", {}),
    ("PureDNSTool",      "tools.dns_intel.puredns",    {}),
    # Screenshot
    ("AquatoneTool",     "tools.screenshot.aquatone",  {}),
    ("GoWitnessTool",    "tools.screenshot.gowitness",  {}),
    # API Recon
    ("KiterunnerTool",   "tools.api_recon.kiterunner", {}),
    ("Graphw00fTool",    "tools.api_recon.graphw00f",  {}),
    # Secrets
    ("TrufflehogTool",   "tools.secrets.trufflehog",   {}),
    ("GitleaksTool",     "tools.secrets.gitleaks",     {}),
    # Cloud
    ("S3ScannerTool",    "tools.cloud.s3scanner",      {}),
    # Certs
    ("CrtshTool",        "tools.certs.crtsh",          {}),
    ("TLSXTool",         "tools.certs.tlsx",           {}),
    # Fingerprint
    ("Wafw00fTool",      "tools.fingerprint.wafw00f",  {}),
    ("TestSSLTool",      "tools.fingerprint.testssl",  {}),
    # Identity
    ("SherlockTool",     "tools.identity.sherlock",    {}),
    ("HoleheTool",       "tools.identity.holehe",      {}),
    ("PhoneInfogaTool",  "tools.identity.phoneinfoga", {}),
]


class _NullTool:
    def __init__(self, name: str, reason: str):
        self.NAME = name; self._reason = reason
    def is_available(self): return False
    def run(self, target, **kw):
        from types import SimpleNamespace
        return SimpleNamespace(status="skipped", findings=[],
                               error=f"{self.NAME}: {self._reason}")


def get_123_additions(base_package: str = "reconx", config: dict | None = None) -> dict[str, Any]:
    registry: dict[str, Any] = {}
    cfg = config or {}
    for class_name, module_rel, kwargs in _STAGE123_SPEC:
        for prefix in (f"{base_package}.", ""):
            try:
                mod  = importlib.import_module(f"{prefix}{module_rel}")
                cls  = getattr(mod, class_name)
                inst = cls(**{**kwargs, **_fkw(cls, cfg)})
                registry[class_name] = inst
                log.debug(f"[123] {class_name}")
                break
            except ImportError:
                continue
            except Exception as e:
                log.error(f"[123][INIT FAILED] {class_name}: {e}")
                registry[class_name] = _NullTool(class_name, str(e))
                break
        else:
            registry[class_name] = _NullTool(class_name, "ImportError")
    return registry


def get_full_registry_123(base_package: str = "reconx", config: dict | None = None) -> dict[str, Any]:
    """Return merged Stage 12.1 + 12.2 + 12.3 registry."""
    try:
        from reconx.tools.registry_122 import get_full_registry
    except ModuleNotFoundError:
        from tools.registry_122 import get_full_registry
    return {**get_full_registry(base_package, config), **get_123_additions(base_package, config)}


def _fkw(cls, cfg: dict) -> dict:
    import inspect
    try:
        params = set(inspect.signature(cls.__init__).parameters) - {"self"}
        return {k: v for k, v in cfg.items() if k in params}
    except Exception:
        return {}
