"""
ReconX — Amass passive enumeration wrapper.
"""
from __future__ import annotations
import logging

from .base import BaseTool

logger = logging.getLogger("reconx.tools.amass")


class AmassTool(BaseTool):
    BINARY = "amass"
    NAME = "Amass"

    def run(self, target: str, **kwargs) -> dict:
        if not self.is_available():
            logger.warning("amass not found; skipping.")
            return {"subdomains": []}

        stdout, stderr, rc = self._run(
            ["enum", "-passive", "-d", target, "-silent"],
            timeout=300,
        )

        subdomains: list[str] = []

        for line in stdout.splitlines():
            line = line.strip()
            if line and "." in line and " " not in line:
                subdomains.append(line.lower())

        return {"subdomains": list(set(subdomains))}
