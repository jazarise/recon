"""
ReconX — Stage 12: Cloud Storage Scanner.

Detects public cloud storage buckets across AWS S3, Azure Blob, and GCP GCS.

Discovery strategies:
  - Target domain name → bucket name guessing
  - DNS-based bucket detection (S3 CNAME)
  - Direct URL probing for known bucket patterns
  - Listing detection
  - Sensitive file enumeration
  - CORS wildcard detection

No authentication credentials required — passive checks only.
"""
from __future__ import annotations

import hashlib
import re
import ssl
import time
import urllib.request
import urllib.error
from typing import Optional
from xml.etree import ElementTree

from ..base import BaseTool
from ...models.tool_result import ParsedFinding, ToolRunResult
from ...models.cloud_models import StorageBucket, StorageType, CloudRisk


# ── Bucket name generators ────────────────────────────────────────────────────
def _bucket_candidates(target: str) -> list[str]:
    """Generate common bucket name candidates from a target domain."""
    hostname = target.strip().lstrip("https://").lstrip("http://").split("/")[0]
    parts    = hostname.replace("-", ".").split(".")
    base     = parts[0] if parts else hostname
    root     = ".".join(parts[-2:]) if len(parts) >= 2 else hostname
    name     = root.replace(".", "-")

    candidates: list[str] = []
    for b in [base, name, root.replace(".", ""), hostname.replace(".", "-")]:
        if not b: continue
        for suffix in ["", "-static", "-assets", "-backup", "-data", "-dev",
                       "-staging", "-prod", "-public", "-private", "-files",
                       "-logs", "-uploads", "-media", "-cdn", "-www",
                       "-storage", "-archive", "-backup", "-config"]:
            candidates.append(f"{b}{suffix}")

    return list(dict.fromkeys(candidates))[:20]


# ── Sensitive file patterns ───────────────────────────────────────────────────
SENSITIVE_EXTENSIONS = {
    ".env", ".sql", ".zip", ".tar.gz", ".bak", ".backup",
    ".key", ".pem", ".crt", ".p12", ".pfx",
    "credentials", "secret", "password", "token", "config",
    "database.yml", "settings.py", "web.config", ".htpasswd",
}


def _is_sensitive(name: str) -> bool:
    name_lower = name.lower()
    return any(s in name_lower for s in SENSITIVE_EXTENSIONS)


class S3Scanner(BaseTool):
    """
    AWS S3 / Azure Blob / GCP GCS public bucket exposure scanner.

    Detects: public access, listing enabled, sensitive files, CORS misconfiguration.
    All checks are passive (no write attempts).
    """

    NAME        = "S3Scanner"
    BINARY      = ""
    CATEGORY    = "cloud"
    STAGE       = 7
    PRIORITY    = 10
    PASSIVE     = True
    TIMEOUT     = 120
    INSTALL_CMD = ""

    def run(
        self,
        target: str,
        *,
        bucket_names:    Optional[list[str]] = None,
        check_aws:       bool = True,
        check_azure:     bool = True,
        check_gcp:       bool = True,
        max_objects:     int  = 50,
        timeout_per:     float = 5.0,
        **kwargs,
    ) -> ToolRunResult:
        if f := self.validate_or_fail(target): return f

        t0 = time.perf_counter()
        candidates = bucket_names or _bucket_candidates(target)
        buckets:    list[StorageBucket] = []

        try:
            for name in candidates:
                if check_aws:
                    b = self._probe_s3(name, timeout_per, max_objects)
                    if b: buckets.append(b)

                if check_azure:
                    b = self._probe_azure_blob(name, timeout_per)
                    if b: buckets.append(b)

                if check_gcp:
                    b = self._probe_gcs(name, timeout_per, max_objects)
                    if b: buckets.append(b)

            public   = [b for b in buckets if b.is_public]
            listings = [b for b in buckets if b.listing_enabled]
            sensitives = [b for b in buckets if b.sensitive_files]

            parsed = {
                "buckets_found":   len(buckets),
                "public_buckets":  len(public),
                "listing_enabled": len(listings),
                "sensitive_files": sum(len(b.sensitive_files) for b in buckets),
                "buckets": [self._bucket_dict(b) for b in buckets],
            }

            self._log("info",
                      f"Storage scan: {len(buckets)} found, {len(public)} public, "
                      f"{len(listings)} listing, {len(sensitives)} with sensitive files")

            return self.build_result(
                data     = parsed,
                findings = self._to_findings(buckets),
                duration_s = time.perf_counter() - t0,
            )

        except Exception as exc:
            import traceback
            return self.fail(reason="runtime_error", message=str(exc),
                             duration_s=time.perf_counter() - t0,
                             tb=traceback.format_exc())

    # ── AWS S3 ────────────────────────────────────────────────────────────────

    def _probe_s3(self, name: str, timeout: float, max_objects: int) -> Optional[StorageBucket]:
        """Probe an S3 bucket for public access and listing."""
        urls_to_try = [
            f"https://{name}.s3.amazonaws.com/",
            f"https://s3.amazonaws.com/{name}/",
        ]

        for url in urls_to_try:
            try:
                resp_hdrs, body, status = self._http_get(url, timeout)
                if status == 0:
                    continue

                bucket = StorageBucket(
                    name     = name,
                    url      = url,
                    provider = StorageType.S3,
                )

                if status == 403:
                    # Bucket exists but access denied
                    bucket.is_public = False
                    bucket.risk      = CloudRisk.LOW
                    if "NoSuchBucket" not in body:
                        return bucket
                    return None

                if status == 404 or "NoSuchBucket" in body:
                    return None

                if status == 200:
                    bucket.is_public = True
                    bucket.risk      = CloudRisk.HIGH

                    # Check listing
                    if "<ListBucketResult" in body or "<Contents>" in body:
                        bucket.listing_enabled = True
                        bucket.risk            = CloudRisk.CRITICAL
                        bucket.sample_objects, bucket.sensitive_files = \
                            self._parse_s3_listing(body, max_objects)

                    # CORS check
                    cors = resp_hdrs.get("access-control-allow-origin", "")
                    if cors == "*":
                        bucket.cors_wildcard = True

                    return bucket

            except Exception:
                continue

        return None

    def _parse_s3_listing(self, body: str, max_objects: int) -> tuple[list[str], list[str]]:
        """Parse S3 XML listing response."""
        objects:   list[str] = []
        sensitive: list[str] = []
        try:
            root = ElementTree.fromstring(body)
            ns   = {"s3": "http://s3.amazonaws.com/doc/2006-03-01/"}
            for content in root.findall(".//s3:Contents", ns) or root.findall(".//Contents"):
                key_el = content.find("s3:Key", ns) or content.find("Key")
                if key_el is not None and key_el.text:
                    key = key_el.text
                    objects.append(key)
                    if _is_sensitive(key):
                        sensitive.append(key)
                if len(objects) >= max_objects:
                    break
        except Exception:
            # Regex fallback for malformed XML
            keys = re.findall(r"<Key>([^<]+)</Key>", body)
            for key in keys[:max_objects]:
                objects.append(key)
                if _is_sensitive(key):
                    sensitive.append(key)
        return objects, sensitive

    # ── Azure Blob ────────────────────────────────────────────────────────────

    def _probe_azure_blob(self, name: str, timeout: float) -> Optional[StorageBucket]:
        """Probe an Azure Blob Storage container for public access."""
        # Azure blob URL patterns
        urls = [
            f"https://{name}.blob.core.windows.net/{name}?restype=container&comp=list",
            f"https://{name}.blob.core.windows.net/$root?restype=container&comp=list",
        ]
        for url in urls:
            try:
                resp_hdrs, body, status = self._http_get(url, timeout)
                if status == 0:
                    continue
                if status == 404:
                    return None
                if status == 403:
                    return StorageBucket(
                        name=name,
                        url=f"https://{name}.blob.core.windows.net/",
                        provider=StorageType.AZURE_BLOB,
                        is_public=False,
                        risk=CloudRisk.LOW,
                    )
                if status == 200 and ("<EnumerationResults" in body or "<Blobs" in body):
                    sensitive = self._scan_listing_for_sensitive(body)
                    return StorageBucket(
                        name             = name,
                        url              = f"https://{name}.blob.core.windows.net/",
                        provider         = StorageType.AZURE_BLOB,
                        is_public        = True,
                        listing_enabled  = True,
                        sensitive_files  = sensitive,
                        risk             = CloudRisk.CRITICAL if sensitive else CloudRisk.HIGH,
                    )
            except Exception:
                continue
        return None

    # ── Google Cloud Storage ──────────────────────────────────────────────────

    def _probe_gcs(self, name: str, timeout: float, max_objects: int) -> Optional[StorageBucket]:
        """Probe a GCS bucket for public access."""
        urls = [
            f"https://storage.googleapis.com/{name}/",
            f"https://{name}.storage.googleapis.com/",
        ]
        for url in urls:
            try:
                resp_hdrs, body, status = self._http_get(url, timeout)
                if status == 0:
                    continue
                if status == 404:
                    return None
                if status == 403:
                    # GCS might exist but deny access
                    if "Your client does not have permission" in body or "AccessDenied" in body:
                        return StorageBucket(
                            name=name,
                            url=url,
                            provider=StorageType.GCS,
                            is_public=False,
                            risk=CloudRisk.LOW,
                        )
                    return None
                if status == 200:
                    listing = "<Contents>" in body or "<Key>" in body or '"name":' in body
                    keys    = re.findall(r'"name":\s*"([^"]+)"', body)[:max_objects]
                    sensitive = [k for k in keys if _is_sensitive(k)]
                    return StorageBucket(
                        name            = name,
                        url             = url,
                        provider        = StorageType.GCS,
                        is_public       = True,
                        listing_enabled = listing,
                        sample_objects  = keys,
                        sensitive_files = sensitive,
                        risk            = CloudRisk.CRITICAL if sensitive else
                                          (CloudRisk.HIGH if listing else CloudRisk.MEDIUM),
                    )
            except Exception:
                continue
        return None

    # ── HTTP helper ───────────────────────────────────────────────────────────

    def _http_get(self, url: str, timeout: float) -> tuple[dict, str, int]:
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode    = ssl.CERT_NONE
            with urllib.request.urlopen(req, timeout=timeout, context=ctx) as resp:
                hdrs = {k.lower(): v for k, v in resp.getheaders()}
                body = resp.read(512_000).decode("utf-8", errors="replace")
                return hdrs, body, resp.status
        except urllib.error.HTTPError as e:
            try:
                body = e.read(4096).decode("utf-8", errors="replace")
            except Exception:
                body = ""
            return {}, body, e.code
        except Exception:
            return {}, "", 0

    def _scan_listing_for_sensitive(self, body: str) -> list[str]:
        files  = re.findall(r"<Name>([^<]+)</Name>", body)
        files += re.findall(r'"name":\s*"([^"]+)"', body)
        return [f for f in files if _is_sensitive(f)][:20]

    def _bucket_dict(self, b: StorageBucket) -> dict:
        return {
            "name":           b.name,
            "url":            b.url,
            "provider":       b.provider.value,
            "is_public":      b.is_public,
            "listing":        b.listing_enabled,
            "sensitive_files": b.sensitive_files,
            "cors_wildcard":  b.cors_wildcard,
            "risk":           b.risk.value,
        }

    def _to_findings(self, buckets: list[StorageBucket]) -> list[ParsedFinding]:
        result = []
        for b in buckets:
            if b.is_public:
                result.append(ParsedFinding(
                    finding_type = "public_cloud_bucket",
                    value        = b.url,
                    source       = self.NAME,
                    confidence   = 0.95,
                    metadata     = self._bucket_dict(b),
                ))
            for sf in b.sensitive_files[:5]:
                result.append(ParsedFinding(
                    finding_type = "cloud_storage_sensitive_file",
                    value        = f"{b.url}{sf}",
                    source       = self.NAME,
                    confidence   = 0.90,
                    metadata     = {"bucket": b.name, "file": sf, "provider": b.provider.value},
                ))
        return result

    def parse_output(self, raw: str, **kwargs) -> dict:
        return {}


class BucketCorrelator:
    """
    Correlates bucket discoveries from multiple sources into a unified map.
    Deduplicates by name+provider, calculates aggregate risk.
    """

    def correlate(self, buckets: list[dict]) -> dict:
        seen:    dict[str, dict]  = {}
        public:  list[dict]       = []
        listing: list[dict]       = []

        for b in buckets:
            key = f"{b.get('provider','?')}::{b.get('name','?')}"
            if key not in seen:
                seen[key] = b
            else:
                # Merge sensitive files
                existing = seen[key]
                existing["sensitive_files"] = list(dict.fromkeys(
                    existing.get("sensitive_files", []) + b.get("sensitive_files", [])
                ))

        all_buckets = list(seen.values())
        public  = [b for b in all_buckets if b.get("is_public")]
        listing = [b for b in all_buckets if b.get("listing")]

        return {
            "total":   len(all_buckets),
            "public":  len(public),
            "listing": len(listing),
            "sensitive": sum(len(b.get("sensitive_files", [])) for b in all_buckets),
            "buckets": all_buckets,
        }
