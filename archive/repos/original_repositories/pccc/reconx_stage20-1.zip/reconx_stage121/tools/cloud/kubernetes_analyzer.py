"""
ReconX — Stage 12: Kubernetes Analyzer.

Detects and analyses exposed Kubernetes infrastructure:
  - API server (port 6443, 8443)
  - Dashboard (port 8001, 30000-32767 NodePort)
  - etcd (port 2379, 2380)
  - kubelet (port 10250, 10255)
  - Metrics server (port 443, 8443)
  - Helm dashboard
  - Ingress controllers

All checks are passive HTTP probes — no kubectl or cluster credentials required.
"""
from __future__ import annotations

import json
import re
import ssl
import time
import urllib.request
import urllib.error
from typing import Optional

from ..base import BaseTool
from ...models.tool_result import ParsedFinding, ToolRunResult
from ...models.cloud_models import (
    K8sAsset, K8sComponent, CloudProvider, CloudRisk, CloudMisconfig,
)


# ── Common K8s endpoint probes ────────────────────────────────────────────────
K8S_ENDPOINTS: list[dict] = [
    # API server
    {
        "component": K8sComponent.API_SERVER,
        "paths":     ["/api", "/api/v1", "/apis"],
        "ports":     [6443, 8443, 443],
        "indicators": ['"apiVersion"', '"kind":"APIVersions"', '"groups":['],
        "risk":      CloudRisk.CRITICAL,
        "auth_indicator": '"401"',
    },
    # Dashboard
    {
        "component": K8sComponent.DASHBOARD,
        "paths":     ["/", "/api/v1/namespace/default/pods", "/api/v1/nodes"],
        "ports":     [8001, 30000, 31000, 32000, 9090, 8443],
        "indicators": ["Kubernetes Dashboard", "kubernetes-dashboard",
                       "Dashboard", '"kind":"PodList"', '"kind":"NodeList"'],
        "risk":      CloudRisk.CRITICAL,
        "auth_indicator": "Login",
    },
    # etcd
    {
        "component": K8sComponent.ETCD,
        "paths":     ["/health", "/version", "/v3/cluster/member/list"],
        "ports":     [2379, 2380],
        "indicators": ['"etcdserver"', '"health":"true"', '"cluster_version"'],
        "risk":      CloudRisk.CRITICAL,
        "auth_indicator": None,
    },
    # kubelet API
    {
        "component": K8sComponent.KUBELET,
        "paths":     ["/pods", "/stats/summary", "/metrics"],
        "ports":     [10250, 10255],
        "indicators": ['"pods":', '"items":', '"apiVersion"', '"metadata":'],
        "risk":      CloudRisk.CRITICAL,
        "auth_indicator": "401",
    },
    # Metrics server
    {
        "component": K8sComponent.METRICS,
        "paths":     ["/apis/metrics.k8s.io", "/metrics"],
        "ports":     [443, 8443],
        "indicators": ['"kind":"APIResourceList"', "metrics.k8s.io"],
        "risk":      CloudRisk.MEDIUM,
        "auth_indicator": None,
    },
]

# ── Managed K8s provider detection ───────────────────────────────────────────
MANAGED_K8S_PATTERNS: list[tuple[str, CloudProvider, str]] = [
    (r"eks\.amazonaws\.com|\.us-east-\d\.eks",    CloudProvider.AWS,   "Amazon EKS"),
    (r"azmk8s\.io|aks\.azure\.com",               CloudProvider.AZURE, "Azure AKS"),
    (r"gke\.io|\.gke\.|container\.googleapis",    CloudProvider.GCP,   "Google GKE"),
    (r"digitalocean.*k8s|doks",                   CloudProvider.DO,    "DigitalOcean DOKS"),
    (r"k3s|rancher",                               CloudProvider.UNKNOWN, "K3s/Rancher"),
]


class KubernetesAnalyzer(BaseTool):
    """
    Kubernetes exposure analysis and component discovery.

    Probes known ports and paths to identify exposed K8s components.
    Classifies managed K8s provider (EKS/AKS/GKE) from response metadata.
    """

    NAME        = "KubernetesAnalyzer"
    BINARY      = ""
    CATEGORY    = "cloud"
    STAGE       = 7
    PRIORITY    = 20
    PASSIVE     = True
    TIMEOUT     = 90
    INSTALL_CMD = ""

    def run(
        self,
        target: str,
        *,
        headers:       Optional[dict] = None,
        timeout_per:   float          = 5.0,
        probe_nodeports: bool         = False,
        **kwargs,
    ) -> ToolRunResult:
        if f := self.validate_or_fail(target): return f

        t0      = time.perf_counter()
        hdrs    = headers or {}
        host    = self._extract_host(target)
        assets: list[K8sAsset]        = []
        misconfigs: list[CloudMisconfig] = []

        try:
            for ep_def in K8S_ENDPOINTS:
                component = ep_def["component"]
                for port in ep_def["ports"]:
                    for path in ep_def["paths"]:
                        for scheme in ("https", "http"):
                            url    = f"{scheme}://{host}:{port}{path}"
                            result = self._probe(url, hdrs, timeout_per)
                            if not result:
                                continue

                            body, resp_hdrs, status = result
                            if status == 0:
                                continue

                            # Check for K8s indicators
                            matched = any(ind in body for ind in ep_def["indicators"])
                            if not matched and status not in (200, 401, 403):
                                continue

                            # Determine auth state
                            auth_indicator = ep_def.get("auth_indicator")
                            auth_required  = (
                                status == 401 or
                                (auth_indicator and auth_indicator in body)
                            )

                            # Detect managed K8s provider
                            provider = self._detect_k8s_provider(
                                body + str(resp_hdrs), host
                            )

                            # Extract version
                            version = self._extract_version(body)

                            asset = K8sAsset(
                                component    = component,
                                url          = url,
                                provider     = provider,
                                is_exposed   = True,
                                version      = version,
                                risk         = ep_def["risk"] if not auth_required else CloudRisk.MEDIUM,
                                auth_required = auth_required,
                                evidence     = [
                                    f"HTTP {status} on {url}",
                                    f"Provider: {provider.value}",
                                ] + ([f"Version: {version}"] if version else []),
                            )
                            assets.append(asset)

                            # Misconfiguration detection
                            if not auth_required and ep_def["risk"] in (CloudRisk.CRITICAL, CloudRisk.HIGH):
                                misconfigs.append(CloudMisconfig(
                                    category    = f"exposed_{component.value}",
                                    title       = f"Unauthenticated Kubernetes {component.value.replace('_',' ').title()} Exposed",
                                    description = (
                                        f"Kubernetes {component.value} at {url} is accessible "
                                        "without authentication."
                                    ),
                                    risk        = CloudRisk.CRITICAL,
                                    evidence    = f"HTTP {status} returned without auth",
                                    remediation = self._remediation(component),
                                    url         = url,
                                    provider    = provider,
                                ))

                            break   # found on this port, move to next component
                        else:
                            continue
                        break
                    else:
                        continue
                    break

            parsed = {
                "k8s_assets":   [self._asset_dict(a) for a in assets],
                "misconfigs":   [self._misconfig_dict(m) for m in misconfigs],
                "exposed_count": sum(1 for a in assets if not a.auth_required),
                "component_types": list({a.component.value for a in assets}),
                "providers":    list({a.provider.value for a in assets}),
                "is_kubernetes": len(assets) > 0,
            }

            self._log("info",
                      f"K8s: {len(assets)} components, {len(misconfigs)} misconfigs, "
                      f"providers={parsed['providers']}")

            return self.build_result(
                data     = parsed,
                findings = self._to_findings(assets, misconfigs),
                duration_s = time.perf_counter() - t0,
            )

        except Exception as exc:
            import traceback
            return self.fail(reason="runtime_error", message=str(exc),
                             duration_s=time.perf_counter() - t0,
                             tb=traceback.format_exc())

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _probe(self, url: str, hdrs: dict, timeout: float) -> Optional[tuple[str, dict, int]]:
        try:
            req = urllib.request.Request(url, headers={**hdrs, "Accept": "application/json"})
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode    = ssl.CERT_NONE
            with urllib.request.urlopen(req, timeout=timeout, context=ctx) as resp:
                resp_hdrs = {k.lower(): v for k, v in resp.getheaders()}
                body      = resp.read(65536).decode("utf-8", errors="replace")
                return body, resp_hdrs, resp.status
        except urllib.error.HTTPError as e:
            try:
                body = e.read(2048).decode("utf-8", errors="replace")
            except Exception:
                body = ""
            return body, {}, e.code
        except Exception:
            return None

    def _detect_k8s_provider(self, text: str, host: str) -> CloudProvider:
        combined = text + host
        for pattern, provider, _ in MANAGED_K8S_PATTERNS:
            if re.search(pattern, combined, re.IGNORECASE):
                return provider
        return CloudProvider.UNKNOWN

    def _extract_version(self, body: str) -> str:
        patterns = [
            r'"gitVersion":\s*"([^"]+)"',
            r'"serverVersion":\s*"([^"]+)"',
            r'"etcdserver":\s*"([^"]+)"',
        ]
        for p in patterns:
            m = re.search(p, body)
            if m:
                return m.group(1)
        return ""

    def _extract_host(self, target: str) -> str:
        target = target.strip()
        if target.startswith("http"):
            target = target.split("//", 1)[1]
        return target.split("/")[0].split(":")[0]

    def _remediation(self, component: K8sComponent) -> str:
        return {
            K8sComponent.API_SERVER: "Restrict API server access to internal network. Enable RBAC and network policies.",
            K8sComponent.DASHBOARD: "Remove public dashboard exposure. Require kubectl proxy or VPN.",
            K8sComponent.ETCD:      "Bind etcd to localhost only. Enable TLS client authentication.",
            K8sComponent.KUBELET:   "Disable anonymous kubelet API access. Enable webhook authentication.",
            K8sComponent.METRICS:   "Restrict metrics-server access to cluster-internal sources.",
        }.get(component, "Restrict component access to internal cluster network.")

    def _asset_dict(self, a: K8sAsset) -> dict:
        return {
            "component":     a.component.value,
            "url":           a.url,
            "provider":      a.provider.value,
            "auth_required": a.auth_required,
            "risk":          a.risk.value,
            "version":       a.version,
            "evidence":      a.evidence,
        }

    def _misconfig_dict(self, m: CloudMisconfig) -> dict:
        return {
            "category":    m.category,
            "title":       m.title,
            "risk":        m.risk.value,
            "evidence":    m.evidence,
            "remediation": m.remediation,
            "url":         m.url,
        }

    def _to_findings(
        self, assets: list[K8sAsset], misconfigs: list[CloudMisconfig]
    ) -> list[ParsedFinding]:
        result = []
        for a in assets:
            result.append(ParsedFinding(
                finding_type = "k8s_component",
                value        = a.url,
                source       = self.NAME,
                confidence   = 0.92,
                metadata     = self._asset_dict(a),
            ))
        for m in misconfigs:
            result.append(ParsedFinding(
                finding_type = "cloud_misconfiguration",
                value        = m.url,
                source       = self.NAME,
                confidence   = 0.90,
                metadata     = self._misconfig_dict(m),
            ))
        return result

    def parse_output(self, raw: str, **kwargs) -> dict:
        return {}
