"""
ReconX — s3scanner wrapper.

s3scanner probes S3-compatible bucket names for public access,
ACL misconfigurations, and content listing vulnerabilities.
Pure-Python fallback performs HTTP HEAD probes against common bucket endpoints.

Stage 2 — Passive/Active Cloud Storage Reconnaissance.
"""
from __future__ import annotations
import json
import re
import ssl
import time
import urllib.request
from typing import Optional

from ..base import BaseTool
from ...models.tool_result import ParsedFinding, RunStatus, ToolRunResult

# Cloud storage endpoints to probe in fallback mode
_BUCKET_TEMPLATES = [
    "https://{bucket}.s3.amazonaws.com",
    "https://{bucket}.s3.us-east-1.amazonaws.com",
    "https://storage.googleapis.com/{bucket}",
    "https://{bucket}.blob.core.windows.net",
    "https://{bucket}.storage.googleapis.com",
]

# Common bucket name patterns derived from a domain
def _bucket_names(domain: str) -> list[str]:
    base = domain.split(".")[0]
    return [
        base, f"{base}-backup", f"{base}-dev", f"{base}-prod",
        f"{base}-assets", f"{base}-media", f"{base}-static",
        f"{base}-files", f"{base}-data", f"{base}-logs",
        f"{base}-uploads", f"{base}-images", f"{base}-public",
        f"{base}.com", domain, f"backup.{base}", f"static.{base}",
    ]


class S3ScannerTool(BaseTool):

    NAME         = "s3scanner"
    BINARY       = "s3scanner"
    CATEGORY     = "cloud"
    STAGE        = 2
    PRIORITY     = 15
    PASSIVE      = True
    TIMEOUT      = 120
    DEPENDENCIES: list[str] = []
    INSTALL_CMD  = "pip install s3scanner  # or: go install github.com/sa7mon/s3scanner@latest"

    # ── run ───────────────────────────────────────────────────────────────────

    def run(
        self,
        target: str,
        *,
        buckets:      Optional[list[str]] = None,
        buckets_file: Optional[str]       = None,
        providers:    Optional[list[str]] = None,   # ["aws","gcp","azure","do"]
        threads:      int                 = 4,
        **kwargs,
    ) -> ToolRunResult:
        """
        Args:
            target:       Domain name — used to generate bucket name candidates.
            buckets:      Explicit bucket name list.
            buckets_file: File of bucket names to test.
            providers:    Cloud providers to test (default: aws, gcp, azure).
            threads:      Concurrent scan threads.
        """
        t0 = time.perf_counter()

        # ── Binary path ───────────────────────────────────────────────────────
        if self.is_available():
            bucket_list = buckets or _bucket_names(target)
            import tempfile
            tf = tempfile.NamedTemporaryFile(delete=False, suffix=".txt", mode="w")
            tf.write("\n".join(bucket_list))
            tf.close()

            args = ["scan", "--bucket-file", tf.name,
                    "--threads", str(threads), "--json"]
            if providers:
                for p in providers:
                    args += ["--provider", p]

            res = self.exec(args, timeout_s=float(self.timeout), expected_codes=(0, 1))
            dur = time.perf_counter() - t0
            if res.timed_out:
                return ToolRunResult.timeout(self.NAME, dur, self.timeout)
            if res.returncode == 127:
                return ToolRunResult.skipped(self.NAME, res.stderr)

            data = self.parse_output(res.stdout)
            findings = self._build_findings(data)
            r = self.build_result(data, findings, stdout=res.stdout,
                                  duration_s=dur, returncode=res.returncode)
            if not data["buckets"]: r.status = RunStatus.NO_OUTPUT
            return r

        # ── Pure-Python HTTP probe fallback ───────────────────────────────────
        self._log("info", "s3scanner binary not found — using HTTP probe fallback")
        bucket_list = buckets or _bucket_names(target)
        data, err = self._http_probe(bucket_list)
        dur = time.perf_counter() - t0
        findings = self._build_findings(data)
        r = self.build_result(data, findings, duration_s=dur, returncode=0)
        if not data["buckets"]: r.status = RunStatus.NO_OUTPUT
        return r

    # ── parse_output ──────────────────────────────────────────────────────────

    def parse_output(self, raw: str, **kwargs) -> dict:
        if not raw.strip():
            return {"buckets": [], "count": 0}

        buckets: list[dict] = []
        for line in raw.splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
                buckets.append({
                    "name":     obj.get("name", obj.get("bucket", "")),
                    "provider": obj.get("provider", "aws"),
                    "url":      obj.get("url", ""),
                    "exists":   obj.get("exists", True),
                    "public":   obj.get("public", False),
                    "listable": obj.get("listable", obj.get("objects_listable", False)),
                    "writable": obj.get("writable", False),
                })
            except Exception:
                m = re.search(r"([\w\-\.]+)\s+\|\s+(\w+)\s+\|\s+(\w+)", line)
                if m:
                    buckets.append({"name": m.group(1), "provider": m.group(2),
                                    "public": m.group(3).lower() == "public",
                                    "listable": False, "writable": False, "url": ""})
        return {"buckets": buckets, "count": len(buckets)}

    # ── internal ──────────────────────────────────────────────────────────────

    def _http_probe(self, bucket_names: list[str]) -> tuple[dict, str]:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode    = ssl.CERT_NONE
        opener = urllib.request.build_opener(urllib.request.HTTPSHandler(context=ctx))

        buckets: list[dict] = []
        for name in bucket_names:
            for template in _BUCKET_TEMPLATES:
                url = template.format(bucket=name)
                try:
                    req = urllib.request.Request(
                        url, headers={"User-Agent": "ReconX/2.0 (s3scanner-probe)"},
                        method="HEAD",
                    )
                    with opener.open(req, timeout=5) as resp:
                        code = resp.status
                        # 200/403 = bucket exists; 403=private; 200=public
                        if code in (200, 403):
                            is_public  = code == 200
                            is_listable = False
                            if is_public:
                                # Try GET to check listing
                                try:
                                    greq = urllib.request.Request(
                                        url, headers={"User-Agent": "ReconX/2.0"})
                                    with opener.open(greq, timeout=5) as gr:
                                        body = gr.read(2048).decode(errors="replace")
                                        is_listable = "<ListBucketResult" in body or \
                                                      "<EnumerationResults" in body
                                except Exception:
                                    pass
                            buckets.append({
                                "name":     name,
                                "provider": self._detect_provider(url),
                                "url":      url,
                                "exists":   True,
                                "public":   is_public,
                                "listable": is_listable,
                                "writable": False,
                            })
                            break
                except Exception:
                    continue

        return {"buckets": buckets, "count": len(buckets)}, ""

    @staticmethod
    def _detect_provider(url: str) -> str:
        if "amazonaws.com" in url: return "AWS S3"
        if "googleapis.com" in url: return "GCP GCS"
        if "blob.core.windows.net" in url: return "Azure Blob"
        return "Unknown"

    def _build_findings(self, data: dict) -> list[ParsedFinding]:
        findings = []
        for b in data.get("buckets", []):
            if not b.get("exists"):
                continue
            sev = ("CRITICAL" if b.get("listable") else
                   "HIGH"     if b.get("public")   else "LOW")
            ftype = "exposed_bucket" if b.get("public") else "cloud_asset"
            findings.append(ParsedFinding(
                finding_type=ftype, value=b.get("url") or b.get("name", ""),
                source=self.NAME, confidence=0.95,
                metadata={"provider": b.get("provider", ""),
                          "public": b.get("public", False),
                          "listable": b.get("listable", False),
                          "severity": sev},
            ))
        return findings
