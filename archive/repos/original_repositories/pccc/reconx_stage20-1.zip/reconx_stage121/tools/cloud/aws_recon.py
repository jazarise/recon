"""
ReconX — Stage 12: AWS, Azure, GCP Reconnaissance Tools.
CloudFront Mapper, Docker Registry Analyzer, CI/CD Cloud Mapper.

Passive reconnaissance for cloud infrastructure — no credentials required.
"""
from __future__ import annotations

import re
import ssl
import time
import urllib.request
import urllib.error
from typing import Optional

from ..base import BaseTool
from ...models.tool_result import ParsedFinding, ToolRunResult
from ...models.cloud_models import CloudAsset, CloudProvider, CloudRisk, CICDAsset, CloudMisconfig


# ══════════════════════════════════════════════════════════════════════════════
#  AWS Recon
# ══════════════════════════════════════════════════════════════════════════════

AWS_SERVICE_PATTERNS: list[tuple[str, str, CloudRisk]] = [
    # (url_pattern, service_name, risk)
    (r"\.cloudfront\.net",              "AWS CloudFront",         CloudRisk.LOW),
    (r"\.execute-api\..+\.amazonaws",   "AWS API Gateway",        CloudRisk.MEDIUM),
    (r"\.elb\.amazonaws\.com",          "AWS ELB",                CloudRisk.LOW),
    (r"\.s3\.amazonaws\.com",           "AWS S3",                 CloudRisk.MEDIUM),
    (r"\.s3-website",                   "AWS S3 Static Website",  CloudRisk.MEDIUM),
    (r"\.lambda-url\..+\.amazonaws",    "AWS Lambda",             CloudRisk.MEDIUM),
    (r"\.elasticbeanstalk\.com",        "AWS Elastic Beanstalk",  CloudRisk.MEDIUM),
    (r"\.eks\.amazonaws\.com",          "AWS EKS",                CloudRisk.HIGH),
    (r"\.rds\.amazonaws\.com",          "AWS RDS",                CloudRisk.HIGH),
    (r"\.cache\.amazonaws\.com",        "AWS ElastiCache",        CloudRisk.HIGH),
    (r"\.es\.amazonaws\.com",           "AWS OpenSearch",         CloudRisk.HIGH),
    (r"cognito",                        "AWS Cognito",            CloudRisk.MEDIUM),
    (r"\.amplify\..+\.amazonaws\.com",  "AWS Amplify",            CloudRisk.LOW),
]

AWS_METADATA_URL = "http://169.254.169.254/latest/meta-data/"
AWS_IMDSV2_URL   = "http://169.254.169.254/latest/api/token"


class AWSRecon(BaseTool):
    """
    AWS infrastructure reconnaissance.

    Detects AWS services from hostname patterns, response headers,
    and published IP range metadata. Tests for IMDS exposure via SSRF indicators.
    """

    NAME        = "AWSRecon"
    BINARY      = ""
    CATEGORY    = "cloud"
    STAGE       = 7
    PRIORITY    = 15
    PASSIVE     = True
    TIMEOUT     = 60
    INSTALL_CMD = ""

    def run(self, target: str, *, timeout_per: float = 5.0, **kwargs) -> ToolRunResult:
        if f := self.validate_or_fail(target): return f
        t0 = time.perf_counter()

        try:
            hostname = self._hostname(target)
            assets:   list[dict] = []
            evidence: list[str]  = []

            # Pattern matching on hostname
            for pattern, service, risk in AWS_SERVICE_PATTERNS:
                if re.search(pattern, hostname, re.IGNORECASE):
                    assets.append({
                        "service":   service,
                        "url":       target,
                        "provider":  "aws",
                        "risk":      risk.value,
                        "evidence":  f"Hostname match: {pattern}",
                    })
                    evidence.append(f"{service} (hostname pattern)")

            # HTTP header probe for AWS identifiers
            hdrs, body, status = self._http_get(target, timeout_per)
            for hdr_key in ("x-amz-request-id", "x-amzn-requestid", "x-amz-id-2",
                             "x-amzn-trace-id"):
                if hdr_key in hdrs:
                    evidence.append(f"AWS header: {hdr_key}")

            if "Via" in hdrs and "cloudfront" in hdrs.get("Via", "").lower():
                assets.append({
                    "service": "AWS CloudFront", "url": target,
                    "provider": "aws", "risk": CloudRisk.LOW.value,
                    "evidence": "Via: CloudFront header",
                })

            # Region detection from headers
            region = ""
            for src in [hdrs.get("x-amz-cf-id", ""), body]:
                m = re.search(r"\b(us|eu|ap|sa|ca|me|af)-(?:east|west|north|south|central|northeast|southeast|southwest)-\d\b", src)
                if m:
                    region = m.group(0)
                    evidence.append(f"AWS region: {region}")
                    break

            parsed = {
                "is_aws":    bool(assets),
                "assets":    assets,
                "evidence":  evidence,
                "region":    region,
                "total":     len(assets),
            }

            return self.build_result(
                data=parsed, findings=self._to_findings(assets),
                duration_s=time.perf_counter() - t0,
            )

        except Exception as exc:
            import traceback
            return self.fail(reason="runtime_error", message=str(exc),
                             duration_s=time.perf_counter() - t0, tb=traceback.format_exc())

    def _hostname(self, t: str) -> str:
        return t.split("//")[-1].split("/")[0] if "://" in t else t.split("/")[0]

    def _http_get(self, url: str, timeout: float) -> tuple[dict, str, int]:
        try:
            req = urllib.request.Request(url if url.startswith("http") else f"https://{url}")
            ctx = ssl.create_default_context(); ctx.check_hostname=False; ctx.verify_mode=ssl.CERT_NONE
            with urllib.request.urlopen(req, timeout=timeout, context=ctx) as r:
                return {k.lower(): v for k,v in r.getheaders()}, r.read(8192).decode("utf-8","replace"), r.status
        except urllib.error.HTTPError as e:
            return {k.lower():v for k,v in e.headers.items()} if e.headers else {}, "", e.code
        except Exception:
            return {}, "", 0

    def _to_findings(self, assets: list[dict]) -> list[ParsedFinding]:
        return [
            ParsedFinding(finding_type="aws_service", value=a["url"], source=self.NAME,
                          confidence=0.85, metadata=a)
            for a in assets
        ]

    def parse_output(self, raw: str, **kwargs) -> dict:
        return {}


# ══════════════════════════════════════════════════════════════════════════════
#  Azure Recon
# ══════════════════════════════════════════════════════════════════════════════

AZURE_PATTERNS: list[tuple[str, str, CloudRisk]] = [
    (r"\.azurewebsites\.net",           "Azure App Service",      CloudRisk.LOW),
    (r"\.azurefd\.net",                 "Azure Front Door",       CloudRisk.LOW),
    (r"\.blob\.core\.windows\.net",     "Azure Blob Storage",     CloudRisk.MEDIUM),
    (r"\.trafficmanager\.net",          "Azure Traffic Manager",  CloudRisk.LOW),
    (r"\.azure-api\.net",              "Azure API Management",   CloudRisk.MEDIUM),
    (r"\.cloudapp\.azure\.com",         "Azure VM",               CloudRisk.MEDIUM),
    (r"\.azurecontainer\.io",           "Azure Container Instance", CloudRisk.HIGH),
    (r"azmk8s\.io",                     "Azure AKS",              CloudRisk.HIGH),
    (r"\.servicebus\.windows\.net",     "Azure Service Bus",      CloudRisk.MEDIUM),
    (r"\.database\.windows\.net",       "Azure SQL",              CloudRisk.HIGH),
    (r"\.azurecr\.io",                  "Azure Container Registry", CloudRisk.HIGH),
    (r"\.cognitiveservices\.azure\.com","Azure Cognitive Services", CloudRisk.MEDIUM),
    (r"\.search\.windows\.net",         "Azure Cognitive Search", CloudRisk.MEDIUM),
]


class AzureRecon(BaseTool):
    """Azure infrastructure reconnaissance from hostname and header patterns."""

    NAME="AzureRecon"; BINARY=""; CATEGORY="cloud"; STAGE=7; PRIORITY=16
    PASSIVE=True; TIMEOUT=60; INSTALL_CMD=""

    def run(self, target: str, *, timeout_per: float = 5.0, **kwargs) -> ToolRunResult:
        if f := self.validate_or_fail(target): return f
        t0 = time.perf_counter()
        hostname = target.split("//")[-1].split("/")[0]
        assets: list[dict] = []

        for pattern, service, risk in AZURE_PATTERNS:
            if re.search(pattern, hostname, re.IGNORECASE):
                assets.append({"service": service, "url": target,
                                "provider": "azure", "risk": risk.value,
                                "evidence": f"Pattern: {pattern}"})

        try:
            req = urllib.request.Request(target if target.startswith("http") else f"https://{target}")
            ctx = ssl.create_default_context(); ctx.check_hostname=False; ctx.verify_mode=ssl.CERT_NONE
            with urllib.request.urlopen(req, timeout=timeout_per, context=ctx) as r:
                hdrs = {k.lower(): v for k,v in r.getheaders()}
                for h in ("x-azure-ref","x-ms-request-id","x-powered-by-azure"):
                    if h in hdrs and not any(a["service"].startswith("Azure") for a in assets):
                        assets.append({"service": "Azure", "url": target,
                                       "provider": "azure", "risk": CloudRisk.INFO.value,
                                       "evidence": f"Header: {h}"})
        except Exception:
            pass

        return self.build_result(
            data={"is_azure": bool(assets), "assets": assets, "total": len(assets)},
            findings=[ParsedFinding(finding_type="azure_service", value=a["url"],
                      source=self.NAME, confidence=0.85, metadata=a) for a in assets],
            duration_s=time.perf_counter() - t0,
        )

    def parse_output(self, raw: str, **kwargs) -> dict:
        return {}


# ══════════════════════════════════════════════════════════════════════════════
#  GCP Recon
# ══════════════════════════════════════════════════════════════════════════════

GCP_PATTERNS: list[tuple[str, str, CloudRisk]] = [
    (r"\.appspot\.com",                 "GCP App Engine",         CloudRisk.LOW),
    (r"\.run\.app",                     "GCP Cloud Run",          CloudRisk.MEDIUM),
    (r"\.cloudfunctions\.net",          "GCP Cloud Functions",    CloudRisk.MEDIUM),
    (r"\.storage\.googleapis\.com",     "GCP Cloud Storage",      CloudRisk.MEDIUM),
    (r"\.googleapis\.com",              "GCP Service",            CloudRisk.LOW),
    (r"\.gke\.io|\.container\.googleapis", "GCP GKE",             CloudRisk.HIGH),
    (r"\.firebase\.io|\.web\.app",      "GCP Firebase",           CloudRisk.MEDIUM),
    (r"\.firebaseio\.com",              "Firebase Realtime DB",   CloudRisk.HIGH),
    (r"\.cloudsql",                     "GCP Cloud SQL",          CloudRisk.HIGH),
    (r"\.artifactregistry\.googleapis", "GCP Artifact Registry",  CloudRisk.HIGH),
]


class GCPRecon(BaseTool):
    """GCP infrastructure reconnaissance from hostname and response patterns."""

    NAME="GCPRecon"; BINARY=""; CATEGORY="cloud"; STAGE=7; PRIORITY=17
    PASSIVE=True; TIMEOUT=60; INSTALL_CMD=""

    def run(self, target: str, *, timeout_per: float = 5.0, **kwargs) -> ToolRunResult:
        if f := self.validate_or_fail(target): return f
        t0 = time.perf_counter()
        hostname = target.split("//")[-1].split("/")[0]
        assets: list[dict] = []

        for pattern, service, risk in GCP_PATTERNS:
            if re.search(pattern, hostname, re.IGNORECASE):
                assets.append({"service": service, "url": target,
                                "provider": "gcp", "risk": risk.value,
                                "evidence": f"Pattern: {pattern}"})

        # Firebase public access check (unauthenticated read)
        if "firebaseio.com" in hostname:
            try:
                db_url = f"https://{hostname}/.json"
                req = urllib.request.Request(db_url)
                ctx = ssl.create_default_context(); ctx.check_hostname=False; ctx.verify_mode=ssl.CERT_NONE
                with urllib.request.urlopen(req, timeout=timeout_per, context=ctx) as r:
                    if r.status == 200:
                        assets.append({"service": "Firebase DB (Public Read)", "url": db_url,
                                       "provider": "gcp", "risk": CloudRisk.CRITICAL.value,
                                       "evidence": "/.json returned 200 — unauthenticated read"})
            except Exception:
                pass

        return self.build_result(
            data={"is_gcp": bool(assets), "assets": assets, "total": len(assets)},
            findings=[ParsedFinding(finding_type="gcp_service", value=a["url"],
                      source=self.NAME, confidence=0.85, metadata=a) for a in assets],
            duration_s=time.perf_counter() - t0,
        )

    def parse_output(self, raw: str, **kwargs) -> dict:
        return {}


# ══════════════════════════════════════════════════════════════════════════════
#  CloudFront Mapper
# ══════════════════════════════════════════════════════════════════════════════

class CloudFrontMapper(BaseTool):
    """
    Maps AWS CloudFront distributions and attempts origin discovery.

    Identifies CDN usage and tests for CloudFront bypass vulnerabilities.
    """

    NAME="CloudFrontMapper"; BINARY=""; CATEGORY="cloud"; STAGE=7; PRIORITY=25
    PASSIVE=True; TIMEOUT=60; INSTALL_CMD=""

    def run(self, target: str, *, timeout_per: float = 5.0, **kwargs) -> ToolRunResult:
        if f := self.validate_or_fail(target): return f
        t0 = time.perf_counter()

        try:
            hostname = target.split("//")[-1].split("/")[0]
            is_cf    = False
            cf_id    = ""
            origin_candidates: list[str] = []

            # Probe for CloudFront headers
            for scheme in ("https", "http"):
                url = target if target.startswith("http") else f"{scheme}://{hostname}"
                try:
                    req = urllib.request.Request(url, headers={"Host": hostname})
                    ctx = ssl.create_default_context(); ctx.check_hostname=False; ctx.verify_mode=ssl.CERT_NONE
                    with urllib.request.urlopen(req, timeout=timeout_per, context=ctx) as r:
                        hdrs = {k.lower(): v for k,v in r.getheaders()}
                        body = r.read(4096).decode("utf-8","replace")
                        if any(h in hdrs for h in ("x-cache","x-amz-cf-id","x-amz-cf-pop")):
                            is_cf  = True
                            cf_id  = hdrs.get("x-amz-cf-id","")[:40]
                            # Try to find origin in response or DNS
                            origin_candidates = self._guess_origins(hostname)
                        break
                except Exception:
                    continue

            parsed = {
                "is_cloudfront": is_cf,
                "cf_id":         cf_id,
                "hostname":      hostname,
                "origin_candidates": origin_candidates,
            }
            findings = []
            if is_cf:
                findings.append(ParsedFinding(
                    finding_type="cloudfront_distribution",
                    value=target, source=self.NAME, confidence=0.92,
                    metadata=parsed,
                ))

            return self.build_result(data=parsed, findings=findings,
                                     duration_s=time.perf_counter()-t0)

        except Exception as exc:
            import traceback
            return self.fail(reason="runtime_error", message=str(exc),
                             duration_s=time.perf_counter()-t0, tb=traceback.format_exc())

    def _guess_origins(self, hostname: str) -> list[str]:
        """Generate likely origin server candidates."""
        parts = hostname.split(".")
        base  = parts[0] if parts else hostname
        return [
            f"{base}.s3.amazonaws.com",
            f"{base}-origin.{'.'.join(parts[1:])}",
            f"origin.{hostname}",
            f"backend.{hostname}",
        ]

    def parse_output(self, raw: str, **kwargs) -> dict:
        return {}


# ══════════════════════════════════════════════════════════════════════════════
#  Docker Registry Analyzer
# ══════════════════════════════════════════════════════════════════════════════

REGISTRY_PATHS = [
    "/v2/",
    "/v2/_catalog",
    "/v1/search",
    "/api/v2.0/projects",           # Harbor
    "/service/rest/v1/repositories",# Nexus
]


class DockerRegistryAnalyzer(BaseTool):
    """
    Detects and analyses exposed Docker / OCI container registries.

    Identifies: Docker Hub-style registries, Harbor, Nexus, GitLab registry,
    AWS ECR, Azure ACR, GCP Artifact Registry.
    """

    NAME="DockerRegistryAnalyzer"; BINARY=""; CATEGORY="cloud"; STAGE=7; PRIORITY=30
    PASSIVE=True; TIMEOUT=60; INSTALL_CMD=""

    def run(self, target: str, *, timeout_per: float = 5.0, **kwargs) -> ToolRunResult:
        if f := self.validate_or_fail(target): return f
        t0 = time.perf_counter()
        base = target.rstrip("/")
        findings_data: list[dict] = []

        try:
            for path in REGISTRY_PATHS:
                url = f"{base}{path}" if base.startswith("http") else f"https://{base}{path}"
                try:
                    req = urllib.request.Request(url, headers={"Accept":"application/json"})
                    ctx = ssl.create_default_context(); ctx.check_hostname=False; ctx.verify_mode=ssl.CERT_NONE
                    with urllib.request.urlopen(req, timeout=timeout_per, context=ctx) as r:
                        hdrs   = {k.lower(): v for k,v in r.getheaders()}
                        body   = r.read(32768).decode("utf-8","replace")
                        status = r.status

                        # Detect registry type
                        registry_type = self._detect_type(hdrs, body, url)
                        if not registry_type:
                            continue

                        # Check if listing is public
                        is_public = status == 200 and (
                            '"repositories"' in body or '"catalog"' in body or
                            '"repositories"' in body or "repositories" in body
                        )
                        no_auth = status == 200  # no 401 challenge

                        import json as _json
                        repos: list[str] = []
                        try:
                            data  = _json.loads(body)
                            repos = (data.get("repositories") or
                                     data.get("results", [{"name":""}]))
                            if isinstance(repos[0], dict):
                                repos = [r.get("name","") for r in repos]
                        except Exception:
                            pass

                        findings_data.append({
                            "url":           url,
                            "registry_type": registry_type,
                            "is_public":     is_public,
                            "auth_required": not no_auth,
                            "repos":         repos[:20],
                            "risk":          CloudRisk.CRITICAL.value if (is_public and not no_auth is False)
                                             else (CloudRisk.HIGH.value if is_public else CloudRisk.MEDIUM.value),
                        })
                        break   # found registry, stop probing more paths

                except urllib.error.HTTPError as e:
                    if e.code == 401:
                        # Registry exists but requires auth — still worth noting
                        findings_data.append({
                            "url":           url,
                            "registry_type": "Docker Registry (auth required)",
                            "is_public":     False,
                            "auth_required": True,
                            "repos":         [],
                            "risk":          CloudRisk.MEDIUM.value,
                        })
                    continue
                except Exception:
                    continue

            parsed = {"registries": findings_data, "total": len(findings_data),
                      "public_count": sum(1 for f in findings_data if f["is_public"])}
            return self.build_result(
                data=parsed,
                findings=[
                    ParsedFinding(finding_type="container_registry", value=f["url"],
                                  source=self.NAME, confidence=0.90, metadata=f)
                    for f in findings_data
                ],
                duration_s=time.perf_counter()-t0,
            )

        except Exception as exc:
            import traceback
            return self.fail(reason="runtime_error", message=str(exc),
                             duration_s=time.perf_counter()-t0, tb=traceback.format_exc())

    def _detect_type(self, hdrs: dict, body: str, url: str) -> str:
        if '"Docker-Distribution-Api-Version"'.lower() in str(hdrs).lower() or \
           "docker-distribution-api-version" in hdrs:
            return "Docker Registry v2"
        if '"repositories"' in body and "/v2/" in url:
            return "Docker Registry v2"
        if "Harbor" in body or "harbor" in hdrs.get("server",""):
            return "Harbor"
        if "Nexus" in body or "nexus" in hdrs.get("server",""):
            return "Nexus Repository"
        if '"total_count"' in body and '"repositories"' in body:
            return "GitLab Container Registry"
        if ".azurecr.io" in url:
            return "Azure Container Registry"
        if ".ecr." in url and "amazonaws" in url:
            return "AWS ECR"
        if "artifactregistry.googleapis" in url:
            return "GCP Artifact Registry"
        return ""

    def parse_output(self, raw: str, **kwargs) -> dict:
        return {}


# ══════════════════════════════════════════════════════════════════════════════
#  CI/CD Cloud Mapper
# ══════════════════════════════════════════════════════════════════════════════

CICD_PROBE_PATTERNS: list[dict] = [
    {"system": "argocd",    "paths": ["/api/v1/applications", "/api/version"],
     "indicators": ['"apiVersion"', '"ArgoCD"', '"applications"'], "risk": CloudRisk.CRITICAL},
    {"system": "tekton",    "paths": ["/apis/tekton.dev", "/api/v1/namespaces"],
     "indicators": ['"tekton.dev"', '"TaskRun"', '"Pipeline"'], "risk": CloudRisk.HIGH},
    {"system": "flux",      "paths": ["/api/v1/kustomizations", "/.well-known/flux"],
     "indicators": ['"flux"', '"kustomization"', '"gitrepository"'], "risk": CloudRisk.HIGH},
    {"system": "jenkins",   "paths": ["/api/json", "/view/all/api/json"],
     "indicators": ['"_class":"hudson"', '"jobs":', '"numExecutors"'], "risk": CloudRisk.CRITICAL},
    {"system": "gitlab_ci", "paths": ["/api/v4/runners", "/api/v4/projects"],
     "indicators": ['"runners"', '"id":', '"description":', '"is_shared"'], "risk": CloudRisk.HIGH},
    {"system": "drone",     "paths": ["/api/user", "/api/repos"],
     "indicators": ['"login":', '"active":', '"config_path"'], "risk": CloudRisk.HIGH},
    {"system": "concourse", "paths": ["/api/v1/info", "/api/v1/pipelines"],
     "indicators": ['"version":', '"pipelines"', '"concourse"'], "risk": CloudRisk.HIGH},
]


class CICDCloudMapper(BaseTool):
    """
    Discovers and maps CI/CD systems running in cloud environments.

    Detects: ArgoCD, Tekton, Flux, Jenkins, GitLab CI, Drone, Concourse.
    Flags exposed pipelines and unauthenticated CI/CD dashboards.
    """

    NAME="CICDCloudMapper"; BINARY=""; CATEGORY="cloud"; STAGE=7; PRIORITY=35
    PASSIVE=True; TIMEOUT=90; INSTALL_CMD=""

    def run(self, target: str, *, timeout_per: float = 5.0, **kwargs) -> ToolRunResult:
        if f := self.validate_or_fail(target): return f
        t0 = time.perf_counter()
        base = target.rstrip("/")
        cicd_assets: list[dict] = []

        try:
            for probe in CICD_PROBE_PATTERNS:
                for path in probe["paths"]:
                    url = f"{base}{path}" if base.startswith("http") else f"https://{base}{path}"
                    try:
                        req = urllib.request.Request(url, headers={"Accept":"application/json"})
                        ctx = ssl.create_default_context(); ctx.check_hostname=False; ctx.verify_mode=ssl.CERT_NONE
                        with urllib.request.urlopen(req, timeout=timeout_per, context=ctx) as r:
                            body   = r.read(16384).decode("utf-8","replace")
                            status = r.status
                            if status != 200:
                                continue
                            if any(ind in body for ind in probe["indicators"]):
                                cicd_assets.append({
                                    "system":      probe["system"],
                                    "url":         url,
                                    "is_exposed":  True,
                                    "auth_required": False,
                                    "risk":        probe["risk"].value,
                                    "evidence":    f"HTTP 200 with {probe['system']} indicators",
                                })
                                break
                    except urllib.error.HTTPError as e:
                        if e.code == 401:
                            # System exists but requires auth
                            cicd_assets.append({
                                "system":       probe["system"],
                                "url":          url,
                                "is_exposed":   True,
                                "auth_required": True,
                                "risk":         "MEDIUM",
                                "evidence":     f"HTTP 401 — {probe['system']} auth required",
                            })
                        continue
                    except Exception:
                        continue

            parsed = {
                "cicd_assets":   cicd_assets,
                "total":         len(cicd_assets),
                "unauthenticated": sum(1 for a in cicd_assets if not a["auth_required"]),
            }
            return self.build_result(
                data=parsed,
                findings=[
                    ParsedFinding(finding_type="cicd_cloud_asset", value=a["url"],
                                  source=self.NAME, confidence=0.90, metadata=a)
                    for a in cicd_assets
                ],
                duration_s=time.perf_counter()-t0,
            )

        except Exception as exc:
            import traceback
            return self.fail(reason="runtime_error", message=str(exc),
                             duration_s=time.perf_counter()-t0, tb=traceback.format_exc())

    def parse_output(self, raw: str, **kwargs) -> dict:
        return {}
