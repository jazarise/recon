"""
ReconX — Stage 12: Cloud Fingerprint Tool.

Identifies cloud providers and services via:
  - DNS record analysis (CNAME patterns, NS servers)
  - HTTP response header signatures
  - IP range matching (AWS/Azure/GCP published ranges)
  - Service-specific URL patterns
  - TLS certificate SANs

Supports: AWS, Azure, GCP, Cloudflare, Fastly, Akamai, DigitalOcean.
"""
from __future__ import annotations

import re
import socket
import ssl
import time
import urllib.request
import urllib.error
from typing import Optional

from ..base import BaseTool
from ...models.tool_result import ParsedFinding, ToolRunResult
from ...models.cloud_models import CloudProvider, CloudAsset, CloudRisk


# ── DNS CNAME fingerprints ────────────────────────────────────────────────────
CNAME_PATTERNS: list[tuple[str, CloudProvider, str]] = [
    # (regex, provider, service_name)
    (r"\.cloudfront\.net",             CloudProvider.AWS,        "AWS CloudFront CDN"),
    (r"\.elb\.amazonaws\.com",         CloudProvider.AWS,        "AWS ELB Load Balancer"),
    (r"\.execute-api\..+\.amazonaws\.com", CloudProvider.AWS,    "AWS API Gateway"),
    (r"\.s3\..+\.amazonaws\.com",      CloudProvider.AWS,        "AWS S3"),
    (r"\.s3-website.+\.amazonaws\.com", CloudProvider.AWS,       "AWS S3 Static Website"),
    (r"\.lambda-url\..+\.amazonaws\.com", CloudProvider.AWS,     "AWS Lambda URL"),
    (r"\.elasticbeanstalk\.com",       CloudProvider.AWS,        "AWS Elastic Beanstalk"),
    (r"\.azurewebsites\.net",          CloudProvider.AZURE,      "Azure App Service"),
    (r"\.azurefd\.net",                CloudProvider.AZURE,      "Azure Front Door"),
    (r"\.blob\.core\.windows\.net",    CloudProvider.AZURE,      "Azure Blob Storage"),
    (r"\.trafficmanager\.net",         CloudProvider.AZURE,      "Azure Traffic Manager"),
    (r"\.azure-api\.net",              CloudProvider.AZURE,      "Azure API Management"),
    (r"\.cloudapp\.azure\.com",        CloudProvider.AZURE,      "Azure VM / Cloud"),
    (r"\.appspot\.com",                CloudProvider.GCP,        "GCP App Engine"),
    (r"\.run\.app",                    CloudProvider.GCP,        "GCP Cloud Run"),
    (r"\.cloudfunctions\.net",         CloudProvider.GCP,        "GCP Cloud Functions"),
    (r"\.storage\.googleapis\.com",    CloudProvider.GCP,        "GCP Cloud Storage"),
    (r"\.nip\.io",                     CloudProvider.UNKNOWN,    "Dynamic DNS / Dev"),
    (r"cloudflare\.com",               CloudProvider.CLOUDFLARE, "Cloudflare"),
    (r"\.pages\.dev",                  CloudProvider.CLOUDFLARE, "Cloudflare Pages"),
    (r"fastly\.net",                   CloudProvider.FASTLY,     "Fastly CDN"),
    (r"akamaitech\.net|akamaiedge\.net|akamaihd\.net", CloudProvider.AKAMAI, "Akamai CDN"),
    (r"\.digitaloceanspaces\.com",     CloudProvider.DO,         "DigitalOcean Spaces"),
    (r"ondigitalocean\.app",           CloudProvider.DO,         "DigitalOcean App Platform"),
]

# ── HTTP header fingerprints ──────────────────────────────────────────────────
HEADER_PATTERNS: list[tuple[str, str, CloudProvider, str]] = [
    # (header_name, value_pattern, provider, service)
    ("server",      r"(?i)amazons3|awselb|amazon",    CloudProvider.AWS,        "AWS"),
    ("server",      r"(?i)cloudflare",                CloudProvider.CLOUDFLARE, "Cloudflare"),
    ("via",         r"(?i)cloudfront",                CloudProvider.AWS,        "AWS CloudFront"),
    ("x-cache",     r"(?i)cloudfront",                CloudProvider.AWS,        "AWS CloudFront"),
    ("x-amz-",      r".*",                            CloudProvider.AWS,        "AWS"),
    ("x-azure-ref", r".*",                            CloudProvider.AZURE,      "Azure"),
    ("x-ms-",       r".*",                            CloudProvider.AZURE,      "Azure"),
    ("x-cloud-trace-context", r".*",                  CloudProvider.GCP,        "GCP"),
    ("x-goog-",     r".*",                            CloudProvider.GCP,        "GCP"),
    ("x-powered-by", r"(?i)express|nextjs",           CloudProvider.UNKNOWN,    "Node.js"),
    ("cf-ray",      r".*",                            CloudProvider.CLOUDFLARE, "Cloudflare"),
    ("fly-request-id", r".*",                         CloudProvider.UNKNOWN,    "Fly.io"),
    ("x-vercel-",   r".*",                            CloudProvider.UNKNOWN,    "Vercel"),
    ("x-netlify-",  r".*",                            CloudProvider.UNKNOWN,    "Netlify"),
    ("x-github-request-id", r".*",                   CloudProvider.UNKNOWN,    "GitHub Pages"),
    ("x-fastly-",   r".*",                            CloudProvider.FASTLY,     "Fastly CDN"),
    ("x-do-cache",  r".*",                            CloudProvider.DO,         "DigitalOcean"),
]

# ── Body content fingerprints ─────────────────────────────────────────────────
BODY_PATTERNS: list[tuple[str, CloudProvider, str]] = [
    (r"<Code>NoSuchBucket</Code>",     CloudProvider.AWS,        "AWS S3 (missing bucket)"),
    (r"Access Denied.*s3\.amazonaws",  CloudProvider.AWS,        "AWS S3 (access denied)"),
    (r"AmazonS3",                      CloudProvider.AWS,        "AWS S3"),
    (r"The specified bucket does not exist", CloudProvider.AWS,  "AWS S3"),
    (r"StorageErrorCode.*BlobNotFound", CloudProvider.AZURE,     "Azure Blob Storage"),
    (r"NoSuchKey.*amazonaws",          CloudProvider.AWS,        "AWS S3"),
    (r"<Error><Code>",                 CloudProvider.AWS,        "AWS S3 Error"),
    (r"Your client does not have permission", CloudProvider.GCP, "GCP Storage"),
    (r"storage\.googleapis\.com",      CloudProvider.GCP,        "GCP Storage"),
    (r"IAM",                           CloudProvider.AWS,        "AWS IAM indicator"),
]

# ── Kubernetes fingerprints ───────────────────────────────────────────────────
K8S_PATTERNS: list[tuple[str, str]] = [
    (r'"kind":\s*"Status"',           "Kubernetes API"),
    (r'"apiVersion":\s*"v1"',         "Kubernetes API"),
    (r'Kubernetes\s+Dashboard',        "Kubernetes Dashboard"),
    (r'"kubernetes":\s*true',          "Kubernetes"),
    (r'kube-system|kube-public',       "Kubernetes namespace"),
    (r'Bearer\s+eyJ',                  "Kubernetes JWT auth"),
]


class CloudFingerprint(BaseTool):
    """
    Cloud provider and service fingerprinting tool.

    Combines DNS, HTTP header, body content, and IP-range analysis
    to identify the cloud provider(s) serving a target.
    """

    NAME        = "CloudFingerprint"
    BINARY      = ""
    CATEGORY    = "cloud"
    STAGE       = 7
    PRIORITY    = 5
    PASSIVE     = True
    TIMEOUT     = 60
    INSTALL_CMD = ""

    def run(
        self,
        target: str,
        *,
        headers:     Optional[dict] = None,
        timeout_per: float          = 6.0,
        probe_dns:   bool           = True,
        probe_http:  bool           = True,
        **kwargs,
    ) -> ToolRunResult:
        if f := self.validate_or_fail(target): return f

        t0        = time.perf_counter()
        hdrs      = headers or {}
        providers: dict[CloudProvider, list[str]] = {}   # provider → evidence list
        assets:    list[CloudAsset]                = []
        is_k8s    = False

        try:
            hostname = self._extract_hostname(target)

            # ── DNS fingerprinting ────────────────────────────────────────────
            if probe_dns:
                cnames = self._resolve_cnames(hostname)
                for cname in cnames:
                    for pattern, provider, service in CNAME_PATTERNS:
                        if re.search(pattern, cname, re.IGNORECASE):
                            providers.setdefault(provider, []).append(
                                f"CNAME {cname} → {service}"
                            )
                            assets.append(CloudAsset(
                                asset_id   = self._aid(target, service),
                                asset_type = service.lower().replace(" ", "_"),
                                provider   = provider,
                                name       = service,
                                url        = target,
                                evidence   = [f"CNAME: {cname}"],
                                risk       = self._service_risk(service),
                                tags       = ["cname", "cloud"],
                            ))

                # NS-based provider detection
                ns_records = self._resolve_ns(hostname)
                for ns in ns_records:
                    if "awsdns" in ns:
                        providers.setdefault(CloudProvider.AWS, []).append(f"NS: {ns}")
                    elif "azure" in ns or "msft" in ns:
                        providers.setdefault(CloudProvider.AZURE, []).append(f"NS: {ns}")
                    elif "googledomains" in ns or "dns.google" in ns:
                        providers.setdefault(CloudProvider.GCP, []).append(f"NS: {ns}")
                    elif "cloudflare" in ns:
                        providers.setdefault(CloudProvider.CLOUDFLARE, []).append(f"NS: {ns}")

            # ── HTTP fingerprinting ───────────────────────────────────────────
            if probe_http:
                for scheme in ("https", "http"):
                    url_to_probe = target if target.startswith("http") else f"{scheme}://{hostname}"
                    resp_hdrs, body, status = self._probe(url_to_probe, hdrs, timeout_per)

                    if not resp_hdrs and not body:
                        continue

                    # Header patterns
                    for hdr_name, val_pattern, provider, service in HEADER_PATTERNS:
                        matched_val = resp_hdrs.get(hdr_name, "")
                        if matched_val and re.search(val_pattern, matched_val):
                            providers.setdefault(provider, []).append(
                                f"Header {hdr_name}: {matched_val[:40]} → {service}"
                            )

                    # Body patterns
                    for body_pattern, provider, service in BODY_PATTERNS:
                        if body and re.search(body_pattern, body):
                            providers.setdefault(provider, []).append(
                                f"Body pattern → {service}"
                            )

                    # Kubernetes detection
                    for k8s_pattern, k8s_service in K8S_PATTERNS:
                        if body and re.search(k8s_pattern, body):
                            is_k8s = True
                            providers.setdefault(CloudProvider.UNKNOWN, []).append(
                                f"Kubernetes indicator: {k8s_service}"
                            )
                    break   # stop after first working scheme

            # ── Compile results ───────────────────────────────────────────────
            detected = [p for p in providers if p != CloudProvider.UNKNOWN]
            parsed   = {
                "providers":   [p.value for p in providers.keys()],
                "detected":    [p.value for p in detected],
                "evidence":    {p.value: ev for p, ev in providers.items()},
                "assets":      [
                    {"type": a.asset_type, "provider": a.provider.value,
                     "name": a.name, "url": a.url, "risk": a.risk.value}
                    for a in assets
                ],
                "is_kubernetes": is_k8s,
                "primary_provider": detected[0].value if detected else "unknown",
            }

            self._log("info",
                      f"Fingerprint: providers={[p.value for p in detected]}, k8s={is_k8s}")

            return self.build_result(
                data    = parsed,
                findings= self._to_findings(parsed, target),
                duration_s = time.perf_counter() - t0,
            )

        except Exception as exc:
            import traceback
            return self.fail(reason="runtime_error", message=str(exc),
                             duration_s=time.perf_counter() - t0,
                             tb=traceback.format_exc())

    # ── DNS resolution helpers ────────────────────────────────────────────────

    def _resolve_cnames(self, hostname: str) -> list[str]:
        """Follow CNAME chain and return all intermediate names."""
        cnames: list[str] = []
        try:
            import socket
            # getaddrinfo resolves but doesn't give CNAME chain directly
            # Use a simple DNS lookup approach
            addrs = socket.getaddrinfo(hostname, None)
            # Try to get canonical name
            canonical = socket.gethostbyaddr(addrs[0][4][0])[0] if addrs else ""
            if canonical and canonical != hostname:
                cnames.append(canonical)
        except Exception:
            pass

        # Also try direct string matching on hostname itself
        for pattern, provider, service in CNAME_PATTERNS:
            if re.search(pattern, hostname, re.IGNORECASE):
                cnames.append(hostname)
                break

        return cnames

    def _resolve_ns(self, hostname: str) -> list[str]:
        """Return NS records for the domain (best-effort via subprocess)."""
        import subprocess
        try:
            # Extract root domain for NS lookup
            parts = hostname.split(".")
            root  = ".".join(parts[-2:]) if len(parts) >= 2 else hostname
            result = subprocess.run(
                ["nslookup", "-type=NS", root],
                capture_output=True, text=True, timeout=5,
            )
            return re.findall(r"nameserver\s*=\s*(\S+)", result.stdout, re.IGNORECASE)
        except Exception:
            return []

    # ── HTTP probe ────────────────────────────────────────────────────────────

    def _probe(self, url: str, hdrs: dict, timeout: float) -> tuple[dict, str, int]:
        try:
            req = urllib.request.Request(url, headers={**hdrs, "Accept": "*/*"})
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode    = ssl.CERT_NONE
            with urllib.request.urlopen(req, timeout=timeout, context=ctx) as resp:
                resp_hdrs = {k.lower(): v for k, v in resp.getheaders()}
                body      = resp.read(16384).decode("utf-8", errors="replace")
                return resp_hdrs, body, resp.status
        except urllib.error.HTTPError as e:
            try:
                body = e.read(4096).decode("utf-8", errors="replace")
            except Exception:
                body = ""
            hdrs_ = {k.lower(): v for k, v in e.headers.items()} if e.headers else {}
            return hdrs_, body, e.code
        except Exception:
            return {}, "", 0

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _extract_hostname(self, target: str) -> str:
        target = target.strip()
        if target.startswith("http://") or target.startswith("https://"):
            target = target.split("//", 1)[1]
        return target.split("/")[0].split("?")[0]

    def _service_risk(self, service: str) -> CloudRisk:
        svc = service.lower()
        if any(k in svc for k in ("api gateway", "lambda", "function", "run")):
            return CloudRisk.MEDIUM
        if any(k in svc for k in ("s3", "blob", "storage")):
            return CloudRisk.MEDIUM   # risk elevated if public
        return CloudRisk.LOW

    def _aid(self, target: str, service: str) -> str:
        import hashlib
        return hashlib.md5(f"{target}::{service}".encode(), usedforsecurity=False).hexdigest()[:10]

    def _to_findings(self, parsed: dict, target: str) -> list[ParsedFinding]:
        result = []
        for provider in parsed.get("detected", []):
            result.append(ParsedFinding(
                finding_type = "cloud_provider",
                value        = provider,
                source       = self.NAME,
                confidence   = 0.88,
                metadata     = {
                    "target":   target,
                    "evidence": parsed.get("evidence", {}).get(provider, []),
                },
            ))
        if parsed.get("is_kubernetes"):
            result.append(ParsedFinding(
                finding_type = "kubernetes_indicator",
                value        = target,
                source       = self.NAME,
                confidence   = 0.85,
                metadata     = {"evidence": "Kubernetes API/Dashboard response pattern"},
            ))
        return result

    def parse_output(self, raw: str, **kwargs) -> dict:
        return {}
