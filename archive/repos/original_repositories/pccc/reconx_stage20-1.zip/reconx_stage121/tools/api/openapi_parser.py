# OpenAPI 3.x is handled by SwaggerParser (supports both Swagger 2.0 and OpenAPI 3.x)
from .swagger_parser import SwaggerParser as OpenAPIParser  # noqa: F401
