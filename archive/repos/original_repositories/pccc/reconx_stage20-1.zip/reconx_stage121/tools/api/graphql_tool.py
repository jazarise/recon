"""
ReconX — Stage 11: GraphQL Tool.

Comprehensive GraphQL analysis:
  - Endpoint discovery (common paths + header fingerprinting)
  - Introspection query execution
  - Schema parsing and type extraction
  - Mutation enumeration
  - Hidden field detection
  - Auth weakness detection
  - Batch query abuse detection
  - Query depth limit testing
"""
from __future__ import annotations

import json
import time
import urllib.request
import urllib.error
import ssl
from typing import Optional

from ..base import BaseTool
from ...models.tool_result import ParsedFinding, ToolRunResult
from ...models.api_models import (
    GraphQLSchema, GraphQLType, GraphQLField,
    AuthFinding, AuthType, RiskLevel, APIEndpoint, APIType,
)


# Standard GraphQL endpoint paths to probe
GRAPHQL_PATHS = [
    "/graphql", "/graphiql", "/playground",
    "/api/graphql", "/v1/graphql", "/v2/graphql",
    "/query", "/gql", "/graphql/v1",
    "/admin/graphql", "/internal/graphql",
    "/api", "/graph",
]

# GraphQL introspection query (standard)
INTROSPECTION_QUERY = """
{
  __schema {
    queryType { name }
    mutationType { name }
    subscriptionType { name }
    types {
      name
      kind
      description
      fields(includeDeprecated: true) {
        name
        description
        isDeprecated
        deprecationReason
        type {
          name
          kind
          ofType { name kind }
        }
        args {
          name
          type { name kind ofType { name kind } }
        }
      }
      inputFields {
        name
        type { name kind ofType { name kind } }
      }
      interfaces { name }
      enumValues(includeDeprecated: true) { name }
      possibleTypes { name }
    }
    directives {
      name
      description
      locations
      args {
        name
        type { name kind ofType { name kind } }
      }
    }
  }
}
""".strip()

# Minimal field list query (when introspection is restricted)
FIELD_SUGGESTION_QUERY = """{
  __type(name:"Query") {
    fields { name type { name kind } }
  }
}"""

# Sensitive type/field name patterns
SENSITIVE_PATTERNS = {
    "types":  {"admin", "user", "password", "token", "secret", "credential",
                "key", "auth", "internal", "private", "hidden", "debug"},
    "fields": {"password", "token", "secret", "apiKey", "sessionToken",
                "accessToken", "refreshToken", "privateKey", "ssn", "creditCard"},
}


class GraphQLTool(BaseTool):
    """
    GraphQL endpoint analysis and schema intelligence tool.

    Probes common GraphQL paths, executes introspection, extracts schema,
    and analyses for security weaknesses.
    """

    NAME        = "GraphQL"
    BINARY      = ""            # pure Python — no binary dependency
    CATEGORY    = "api"
    STAGE       = 6
    PRIORITY    = 15
    PASSIVE     = False
    TIMEOUT     = 120
    INSTALL_CMD = ""            # built-in

    def run(
        self,
        target: str,
        *,
        headers:         Optional[dict] = None,
        try_paths:       bool           = True,
        test_introspect: bool           = True,
        test_batch:      bool           = True,
        test_depth:      bool           = True,
        max_depth:       int            = 10,
        timeout_per_req: float          = 8.0,
        **kwargs,
    ) -> ToolRunResult:
        # No binary check — pure Python HTTP
        if f := self.validate_or_fail(target): return f

        t0 = time.perf_counter()
        hdrs = headers or {}

        try:
            # Step 1: Discover GraphQL endpoints
            endpoints = self._discover_endpoints(target, hdrs, timeout_per_req) \
                        if try_paths else [target]

            schemas:      list[dict]       = []
            auth_findings: list[dict]      = []
            found_eps:     list[dict]      = []

            for ep_url in endpoints:
                ep_data, auth_data, schema_data = self._analyse_endpoint(
                    ep_url, hdrs, test_introspect, test_batch, test_depth,
                    max_depth, timeout_per_req,
                )
                if ep_data:
                    found_eps.append(ep_data)
                if auth_data:
                    auth_findings.extend(auth_data)
                if schema_data:
                    schemas.append(schema_data)

            dur    = time.perf_counter() - t0
            parsed = {
                "endpoints":    found_eps,
                "schemas":      schemas,
                "auth_findings": auth_findings,
                "total_endpoints": len(found_eps),
                "introspection_enabled": any(s.get("introspection_enabled") for s in schemas),
            }

            self._log("info",
                      f"GraphQL: {len(found_eps)} endpoints, "
                      f"introspection={'yes' if parsed['introspection_enabled'] else 'no'}, "
                      f"auth_issues={len(auth_findings)}")

            return self.build_result(
                data=parsed,
                findings=self._to_findings(found_eps, schemas, auth_findings),
                duration_s=dur,
            )

        except Exception as exc:
            import traceback
            dur = time.perf_counter() - t0
            return self.fail(
                reason="runtime_error", message=str(exc),
                duration_s=dur, tb=traceback.format_exc(),
            )

    # ── Endpoint discovery ────────────────────────────────────────────────────

    def _discover_endpoints(
        self, base_url: str, headers: dict, timeout: float
    ) -> list[str]:
        """Probe common GraphQL paths and return responding endpoints."""
        base = base_url.rstrip("/")
        found: list[str] = []

        for path in GRAPHQL_PATHS:
            url = f"{base}{path}"
            if self._is_graphql(url, headers, timeout):
                found.append(url)
                self._log("info", f"GraphQL endpoint: {url}")

        return found or [base_url]

    def _is_graphql(self, url: str, headers: dict, timeout: float) -> bool:
        """Send a minimal probe to check if URL is a GraphQL endpoint."""
        try:
            probe    = json.dumps({"query": "{__typename}"}).encode()
            req_hdrs = {
                "Content-Type": "application/json",
                "Accept":       "application/json",
                **headers,
            }
            req  = urllib.request.Request(url, data=probe, headers=req_hdrs, method="POST")
            ctx  = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode    = ssl.CERT_NONE

            with urllib.request.urlopen(req, timeout=timeout, context=ctx) as resp:
                body = resp.read(4096).decode("utf-8", errors="replace")
                ct   = resp.getheader("Content-Type", "")
                return (
                    resp.status in (200, 400, 422) and
                    ("application/json" in ct or "errors" in body.lower() or
                     "__typename" in body or "data" in body)
                )
        except Exception:
            return False

    # ── Endpoint analysis ─────────────────────────────────────────────────────

    def _analyse_endpoint(
        self,
        url:             str,
        headers:         dict,
        test_introspect: bool,
        test_batch:      bool,
        test_depth:      bool,
        max_depth:       int,
        timeout:         float,
    ) -> tuple[Optional[dict], list[dict], Optional[dict]]:
        """
        Full analysis of a single GraphQL endpoint.

        Returns (endpoint_info, auth_findings, schema_data)
        """
        ep_info: dict = {
            "url":                  url,
            "introspection_enabled": False,
            "batch_enabled":        False,
            "depth_limit_enabled":  True,
            "anonymous_access":     False,
            "mutations":            [],
            "query_types":          [],
            "subscription_types":   [],
            "type_count":           0,
            "sensitive_types":      [],
            "source":               "graphql_tool",
        }
        auth_findings: list[dict] = []
        schema_data:   Optional[dict] = None

        # Test introspection
        if test_introspect:
            schema_data, introspect_ok = self._run_introspection(url, headers, timeout)
            ep_info["introspection_enabled"] = introspect_ok

            if introspect_ok and schema_data:
                ep_info["type_count"]         = len(schema_data.get("types", []))
                ep_info["mutations"]          = schema_data.get("mutations", [])
                ep_info["query_types"]        = schema_data.get("query_types", [])
                ep_info["sensitive_types"]    = schema_data.get("sensitive_types", [])
                ep_info["subscription_types"] = schema_data.get("subscriptions", [])

                auth_findings.append({
                    "endpoint":    url,
                    "auth_type":   "none",
                    "risk_level":  "HIGH",
                    "issue":       "GraphQL introspection is enabled — full schema exposed to any client.",
                    "evidence":    f"Introspection returned {ep_info['type_count']} types.",
                    "remediation": "Disable introspection in production. Use query complexity limits instead.",
                    "confidence":  0.98,
                })

        # Test anonymous access
        anon_data = self._probe_anonymous(url, headers, timeout)
        ep_info["anonymous_access"] = anon_data is not None

        if ep_info["anonymous_access"] and not ep_info["introspection_enabled"]:
            auth_findings.append({
                "endpoint":    url,
                "auth_type":   "none",
                "risk_level":  "MEDIUM",
                "issue":       "GraphQL endpoint accepts unauthenticated queries.",
                "evidence":    "Anonymous query returned data.",
                "remediation": "Implement authentication middleware on the GraphQL endpoint.",
                "confidence":  0.85,
            })

        # Test batch queries
        if test_batch:
            batch_ok = self._test_batch(url, headers, timeout)
            ep_info["batch_enabled"] = batch_ok
            if batch_ok:
                auth_findings.append({
                    "endpoint":    url,
                    "auth_type":   "unknown",
                    "risk_level":  "MEDIUM",
                    "issue":       "GraphQL batch queries enabled — rate limiting may be bypassable.",
                    "evidence":    "Batch query array accepted successfully.",
                    "remediation": "Disable batch queries or limit batch size to 1-5 operations.",
                    "confidence":  0.85,
                })

        # Depth limit test
        if test_depth:
            no_depth_limit = self._test_depth_limit(url, headers, timeout, max_depth)
            ep_info["depth_limit_enabled"] = not no_depth_limit
            if no_depth_limit:
                auth_findings.append({
                    "endpoint":    url,
                    "auth_type":   "unknown",
                    "risk_level":  "MEDIUM",
                    "issue":       f"No query depth limit detected (tested depth {max_depth}).",
                    "evidence":    f"Nested query at depth {max_depth} did not return depth error.",
                    "remediation": "Implement query depth limiting (max 5-10). Use query complexity analysis.",
                    "confidence":  0.80,
                })

        return ep_info, auth_findings, schema_data

    # ── Introspection ─────────────────────────────────────────────────────────

    def _run_introspection(
        self, url: str, headers: dict, timeout: float
    ) -> tuple[Optional[dict], bool]:
        """Execute introspection query and parse schema."""
        result = self._gql_request(url, INTROSPECTION_QUERY, headers, timeout)
        if not result or "data" not in result or "__schema" not in result.get("data", {}):
            return None, False

        schema_raw = result["data"]["__schema"]
        return self._parse_schema(schema_raw, url), True

    def _parse_schema(self, schema_raw: dict, url: str) -> dict:
        """Parse introspection response into structured schema data."""
        types_raw = schema_raw.get("types", [])

        # Filter built-in types
        custom_types = [
            t for t in types_raw
            if not (t.get("name") or "").startswith("__")
            and t.get("name") not in ("String", "Boolean", "Int", "Float", "ID",
                                       "Query", "Mutation", "Subscription")
        ]

        mutations:     list[str] = []
        query_types:   list[str] = []
        subscriptions: list[str] = []
        sensitive:     list[str] = []
        parsed_types:  list[dict] = []

        mutation_name = (schema_raw.get("mutationType") or {}).get("name")
        query_name    = (schema_raw.get("queryType")    or {}).get("name")
        sub_name      = (schema_raw.get("subscriptionType") or {}).get("name")

        for t in types_raw:
            name = t.get("name", "")
            if not name or name.startswith("__"):
                continue

            fields_raw = t.get("fields") or []
            fields = [f["name"] for f in fields_raw if f.get("name")]

            if name == mutation_name:
                mutations = fields
            elif name == query_name:
                query_types = fields
            elif name == sub_name:
                subscriptions = fields

            # Sensitive type detection
            name_lower = name.lower()
            if any(p in name_lower for p in SENSITIVE_PATTERNS["types"]):
                sensitive.append(name)

            field_names = [f.get("name", "") for f in fields_raw]
            for fn in field_names:
                if fn.lower() in SENSITIVE_PATTERNS["fields"]:
                    if name not in sensitive:
                        sensitive.append(f"{name}.{fn}")

            parsed_types.append({
                "name":   name,
                "kind":   t.get("kind", "OBJECT"),
                "fields": field_names[:20],
            })

        return {
            "endpoint":              url,
            "introspection_enabled": True,
            "types":                 parsed_types,
            "mutations":             mutations,
            "query_types":           query_types,
            "subscriptions":         subscriptions,
            "sensitive_types":       sensitive,
            "query_type":            query_name,
            "mutation_type":         mutation_name,
            "subscription_type":     sub_name,
            "type_count":            len(parsed_types),
        }

    def _probe_anonymous(
        self, url: str, headers: dict, timeout: float
    ) -> Optional[dict]:
        """Test anonymous access with a simple query."""
        return self._gql_request(url, "{__typename}", headers, timeout)

    def _test_batch(self, url: str, headers: dict, timeout: float) -> bool:
        """Test if batch queries are accepted."""
        batch_body = json.dumps([
            {"query": "{__typename}"},
            {"query": "{__typename}"},
        ])
        result = self._raw_request(url, batch_body, headers, timeout)
        return result is not None and isinstance(result, list)

    def _test_depth_limit(
        self, url: str, headers: dict, timeout: float, depth: int
    ) -> bool:
        """Test if deep nested queries are rejected."""
        # Build a deeply nested query
        nested = "{__typename " + "a: __typename " * 2 + "}"
        query  = "{__typename " + (f"nested: __schema {{ types {{ name }} }} " * depth) + "}"
        result = self._gql_request(url, query, headers, timeout)
        if result is None:
            return False
        # If it returned data without a depth error, limit is absent
        return "data" in result and "errors" not in result

    # ── HTTP helpers ──────────────────────────────────────────────────────────

    def _gql_request(
        self, url: str, query: str, headers: dict, timeout: float
    ) -> Optional[dict]:
        raw = self._raw_request(url, json.dumps({"query": query}), headers, timeout)
        if isinstance(raw, dict):
            return raw
        return None

    def _raw_request(
        self, url: str, body: str, headers: dict, timeout: float
    ) -> Optional[object]:
        try:
            req_hdrs = {
                "Content-Type": "application/json",
                "Accept":       "application/json",
                **headers,
            }
            req = urllib.request.Request(
                url, data=body.encode(), headers=req_hdrs, method="POST"
            )
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode    = ssl.CERT_NONE

            with urllib.request.urlopen(req, timeout=timeout, context=ctx) as resp:
                content = resp.read(1_000_000).decode("utf-8", errors="replace")
                return json.loads(content)
        except Exception:
            return None

    # ── ParsedFinding converter ───────────────────────────────────────────────

    def _to_findings(
        self,
        endpoints:    list[dict],
        schemas:      list[dict],
        auth_findings: list[dict],
    ) -> list[ParsedFinding]:
        result: list[ParsedFinding] = []

        for ep in endpoints:
            result.append(ParsedFinding(
                finding_type = "graphql_endpoint",
                value        = ep["url"],
                source       = self.NAME,
                confidence   = 0.95,
                metadata     = {
                    "introspection_enabled": ep.get("introspection_enabled", False),
                    "mutations":             ep.get("mutations", [])[:10],
                    "sensitive_types":       ep.get("sensitive_types", []),
                    "type_count":            ep.get("type_count", 0),
                    "batch_enabled":         ep.get("batch_enabled", False),
                    "anonymous_access":      ep.get("anonymous_access", False),
                },
            ))

        for af in auth_findings:
            risk_map = {"CRITICAL": 0.95, "HIGH": 0.90, "MEDIUM": 0.80, "LOW": 0.70}
            result.append(ParsedFinding(
                finding_type = "api_auth_issue",
                value        = af["endpoint"],
                source       = self.NAME,
                confidence   = risk_map.get(af.get("risk_level", "MEDIUM"), 0.80),
                metadata     = af,
            ))

        return result
