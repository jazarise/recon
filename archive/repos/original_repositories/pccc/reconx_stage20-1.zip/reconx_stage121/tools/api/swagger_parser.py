"""
ReconX — Stage 11: Swagger/OpenAPI Parser.

Parses Swagger 2.0 and OpenAPI 3.x specs (JSON/YAML) to extract:
  - All endpoints with methods and parameters
  - Authentication schemes
  - Example values (potential credential leakage)
  - Server definitions
  - Security definitions
"""
from __future__ import annotations

import json
import re
import urllib.request
import urllib.error
import ssl
import time
from pathlib import Path
from typing import Optional

from ..base import BaseTool
from ...models.tool_result import ParsedFinding, ToolRunResult
from ...models.api_models import APIEndpoint, APIParameter, AuthType, APIType, RiskLevel


# Common spec file locations to probe
SWAGGER_PATHS = [
    "/swagger.json", "/swagger.yaml", "/swagger/v1/swagger.json",
    "/api-docs", "/api-docs.json", "/v1/api-docs", "/v2/api-docs",
    "/openapi.json", "/openapi.yaml", "/openapi/v3/api-docs",
    "/api/swagger.json", "/api/openapi.json", "/api/docs",
    "/docs/swagger.json", "/docs/openapi.json",
    "/swagger-ui/swagger.json", "/v1/swagger.json", "/v2/swagger.json",
    "/api/v1/swagger.json", "/api/v2/swagger.json",
    "/.well-known/openapi", "/.well-known/api-catalog",
]

SENSITIVE_VALUE_PATTERNS = [
    r'(?i)(password|passwd|secret|token|apikey|api_key|access_token|private_key)',
    r'(?i)(authorization|bearer|oauth|credential)',
]


class SwaggerParser(BaseTool):
    """
    Swagger/OpenAPI spec discovery and parsing tool.

    Probes common spec paths, downloads and parses JSON/YAML specs,
    and extracts a structured endpoint inventory with auth analysis.
    """

    NAME        = "SwaggerParser"
    BINARY      = ""           # pure Python
    CATEGORY    = "api"
    STAGE       = 6
    PRIORITY    = 30
    PASSIVE     = True
    TIMEOUT     = 120
    INSTALL_CMD = "pip install pyyaml"

    def run(
        self,
        target: str,
        *,
        spec_url:       Optional[str]  = None,
        headers:        Optional[dict] = None,
        timeout_per:    float          = 8.0,
        detect_leakage: bool           = True,
        **kwargs,
    ) -> ToolRunResult:
        if f := self.validate_or_fail(target): return f

        t0   = time.perf_counter()
        hdrs = headers or {}

        try:
            # Discover spec URL(s)
            spec_urls = [spec_url] if spec_url else self._discover_specs(target, hdrs, timeout_per)

            all_endpoints: list[dict] = []
            all_params:    list[dict] = []
            auth_schemes:  list[dict] = []
            servers:       list[str]  = []
            leaked_values: list[str]  = []
            found_specs:   list[str]  = []

            for url in spec_urls:
                spec = self._fetch_spec(url, hdrs, timeout_per)
                if not spec:
                    continue

                found_specs.append(url)
                version = self._detect_version(spec)

                eps, params, auths, srvrs, leaks = self._parse_spec(spec, url, version, detect_leakage)
                all_endpoints.extend(eps)
                all_params.extend(params)
                auth_schemes.extend(auths)
                servers.extend(srvrs)
                leaked_values.extend(leaks)

            dur    = time.perf_counter() - t0
            parsed = {
                "specs_found":    found_specs,
                "endpoints":      all_endpoints,
                "parameters":     all_params,
                "auth_schemes":   auth_schemes,
                "servers":        list(dict.fromkeys(servers)),
                "leaked_values":  list(dict.fromkeys(leaked_values))[:20],
                "total_endpoints": len(all_endpoints),
                "total_params":   len(all_params),
            }

            self._log("info",
                      f"OpenAPI: {len(found_specs)} spec(s), {len(all_endpoints)} endpoints, "
                      f"{len(leaked_values)} potential leaks")

            return self.build_result(
                data=parsed,
                findings=self._to_findings(parsed),
                duration_s=dur,
            )

        except Exception as exc:
            import traceback
            return self.fail(
                reason="runtime_error", message=str(exc),
                duration_s=time.perf_counter() - t0,
                tb=traceback.format_exc(),
            )

    # ── Discovery ─────────────────────────────────────────────────────────────

    def _discover_specs(self, base_url: str, headers: dict, timeout: float) -> list[str]:
        base  = base_url.rstrip("/")
        found = []
        for path in SWAGGER_PATHS:
            url = f"{base}{path}"
            try:
                spec = self._fetch_spec(url, headers, timeout)
                if spec and self._looks_like_spec(spec):
                    found.append(url)
                    self._log("info", f"Spec found: {url}")
                    if len(found) >= 5:   # avoid excessive probing
                        break
            except Exception:
                continue
        return found

    def _fetch_spec(self, url: str, headers: dict, timeout: float) -> Optional[dict]:
        try:
            req_hdrs = {"Accept": "application/json,application/yaml,*/*", **headers}
            req  = urllib.request.Request(url, headers=req_hdrs)
            ctx  = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode    = ssl.CERT_NONE

            with urllib.request.urlopen(req, timeout=timeout, context=ctx) as resp:
                if resp.status not in (200, 206):
                    return None
                content = resp.read(5_000_000).decode("utf-8", errors="replace")
                ct      = resp.getheader("Content-Type", "")

                # Try JSON first
                if "json" in ct or content.strip().startswith("{"):
                    return json.loads(content)

                # Try YAML
                try:
                    import yaml
                    return yaml.safe_load(content)
                except Exception:
                    # Return raw dict if JSON parsing of YAML-like content fails
                    if content.strip().startswith("{") or content.strip().startswith("["):
                        return json.loads(content)
                    return None
        except Exception:
            return None

    def _looks_like_spec(self, spec: dict) -> bool:
        if not isinstance(spec, dict):
            return False
        return ("swagger" in spec or "openapi" in spec or
                "paths" in spec or "info" in spec)

    def _detect_version(self, spec: dict) -> str:
        if "openapi" in spec:
            return f"OpenAPI {spec['openapi']}"
        if "swagger" in spec:
            return f"Swagger {spec['swagger']}"
        return "Unknown"

    # ── Parsing ───────────────────────────────────────────────────────────────

    def _parse_spec(
        self, spec: dict, spec_url: str, version: str, detect_leakage: bool
    ) -> tuple[list, list, list, list, list]:
        endpoints:    list[dict] = []
        parameters:   list[dict] = []
        auth_schemes: list[dict] = []
        servers:      list[str]  = []
        leaked:       list[str]  = []

        # Extract servers
        servers.extend(self._extract_servers(spec))

        # Extract auth schemes
        auth_schemes.extend(self._extract_auth(spec))

        # Parse paths
        paths = spec.get("paths", {})
        for path, path_item in paths.items():
            if not isinstance(path_item, dict):
                continue
            methods = ["get", "post", "put", "patch", "delete", "head", "options"]
            for method in methods:
                op = path_item.get(method)
                if not op:
                    continue

                ep_url    = path
                params    = self._extract_params(op, path_item)
                auth_reqs = op.get("security", spec.get("security", []))
                tags      = op.get("tags", [])

                ep = {
                    "url":          ep_url,
                    "full_url":     f"{spec_url.split('/swagger')[0]}{ep_url}",
                    "method":       method.upper(),
                    "summary":      op.get("summary", ""),
                    "description":  op.get("description", ""),
                    "tags":         tags,
                    "parameters":   [p["name"] for p in params],
                    "auth_required": bool(auth_reqs),
                    "source":       "swagger_parser",
                    "spec_version": version,
                    "deprecated":   op.get("deprecated", False),
                }
                endpoints.append(ep)
                parameters.extend(params)

                # Leakage check
                if detect_leakage:
                    leaked.extend(self._scan_for_leakage(op))

        return endpoints, parameters, auth_schemes, servers, leaked

    def _extract_servers(self, spec: dict) -> list[str]:
        servers: list[str] = []
        # OpenAPI 3.x
        for srv in spec.get("servers", []):
            if isinstance(srv, dict) and "url" in srv:
                servers.append(srv["url"])
        # Swagger 2.0
        host     = spec.get("host", "")
        base     = spec.get("basePath", "")
        schemes  = spec.get("schemes", ["https"])
        if host:
            for scheme in schemes:
                servers.append(f"{scheme}://{host}{base}")
        return servers

    def _extract_auth(self, spec: dict) -> list[dict]:
        auth: list[dict] = []
        # OpenAPI 3.x
        components = spec.get("components", {})
        sec_schemes = components.get("securitySchemes", {})
        # Swagger 2.0
        sec_defs = spec.get("securityDefinitions", {})
        all_schemes = {**sec_schemes, **sec_defs}

        for name, scheme in all_schemes.items():
            if not isinstance(scheme, dict):
                continue
            auth.append({
                "name":       name,
                "type":       scheme.get("type", "unknown"),
                "scheme":     scheme.get("scheme", ""),
                "in":         scheme.get("in", ""),
                "flows":      list(scheme.get("flows", {}).keys()),
                "description": scheme.get("description", ""),
            })
        return auth

    def _extract_params(self, op: dict, path_item: dict) -> list[dict]:
        params: list[dict] = []
        seen: set[str] = set()

        # Path-level params + op-level params
        all_p = (path_item.get("parameters") or []) + (op.get("parameters") or [])

        for p in all_p:
            if not isinstance(p, dict):
                continue
            name = p.get("name", "")
            if not name or name in seen:
                continue
            seen.add(name)
            schema = p.get("schema", {})
            params.append({
                "name":         name,
                "location":     p.get("in", "query"),
                "required":     p.get("required", False),
                "data_type":    schema.get("type", p.get("type", "string")),
                "description":  p.get("description", ""),
                "example":      str(p.get("example", schema.get("example", ""))),
                "is_sensitive": self._is_sensitive_param(name),
            })

        # Request body parameters (OpenAPI 3.x)
        rb = op.get("requestBody", {})
        if rb:
            content = rb.get("content", {})
            for ct, ct_data in content.items():
                schema = ct_data.get("schema", {})
                for prop_name, prop in (schema.get("properties") or {}).items():
                    if prop_name in seen:
                        continue
                    seen.add(prop_name)
                    params.append({
                        "name":        prop_name,
                        "location":    "body",
                        "required":    prop_name in schema.get("required", []),
                        "data_type":   prop.get("type", "string"),
                        "description": prop.get("description", ""),
                        "example":     str(prop.get("example", "")),
                        "is_sensitive": self._is_sensitive_param(prop_name),
                    })

        return params

    def _is_sensitive_param(self, name: str) -> bool:
        sensitive_kw = {"password", "secret", "token", "key", "auth", "credit",
                        "ssn", "cvv", "pin", "dob", "dateofbirth", "apikey"}
        return name.lower() in sensitive_kw or any(kw in name.lower() for kw in sensitive_kw)

    def _scan_for_leakage(self, op: dict) -> list[str]:
        leaks: list[str] = []
        op_str = json.dumps(op)
        for pattern in SENSITIVE_VALUE_PATTERNS:
            matches = re.findall(pattern, op_str)
            leaks.extend(matches)
        return leaks

    def _to_findings(self, parsed: dict) -> list[ParsedFinding]:
        result: list[ParsedFinding] = []

        for spec_url in parsed.get("specs_found", []):
            result.append(ParsedFinding(
                finding_type = "swagger_spec",
                value        = spec_url,
                source       = self.NAME,
                confidence   = 0.98,
                metadata     = {
                    "total_endpoints": parsed["total_endpoints"],
                    "total_params":    parsed["total_params"],
                    "auth_schemes":    parsed["auth_schemes"],
                    "risk":            "HIGH" if parsed["total_endpoints"] > 0 else "MEDIUM",
                },
            ))

        for ep in parsed.get("endpoints", []):
            if not ep.get("auth_required", True):
                result.append(ParsedFinding(
                    finding_type = "unauthenticated_api_endpoint",
                    value        = ep["full_url"],
                    source       = self.NAME,
                    confidence   = 0.90,
                    metadata     = ep,
                ))

        for leak in parsed.get("leaked_values", []):
            result.append(ParsedFinding(
                finding_type = "api_spec_leakage",
                value        = leak,
                source       = self.NAME,
                confidence   = 0.70,
                metadata     = {"spec_url": parsed.get("specs_found", [""])[0]},
            ))

        return result

    def parse_output(self, raw: str, **kwargs) -> dict:
        return {}   # not used — logic is in run()
