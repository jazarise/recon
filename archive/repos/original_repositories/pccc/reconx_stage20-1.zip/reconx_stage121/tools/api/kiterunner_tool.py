"""
ReconX — Stage 11: Kiterunner Tool.

Production-grade Kiterunner wrapper for API endpoint discovery.
Kiterunner replaces traditional directory fuzzing for APIs — uses API-aware
wordlists that understand REST route patterns, versioning, and common frameworks.

Supports:
  - Multiple wordlist sources
  - Custom header injection
  - Response filtering by status code
  - JSON output parsing
  - Technology-aware route selection
"""
from __future__ import annotations

import json
import os
import shutil
import tempfile
import time
from typing import Optional

from ..base import BaseTool
from ...models.tool_result import ParsedFinding, ToolRunResult
from ...models.api_models import APIEndpoint, APIType, RiskLevel


# Common API paths kiterunner may discover
INTERESTING_PATHS = {
    "/api", "/api/v1", "/api/v2", "/v1", "/v2",
    "/swagger", "/swagger.json", "/swagger.yaml", "/swagger-ui",
    "/openapi.json", "/openapi.yaml", "/docs", "/redoc",
    "/graphql", "/graphiql", "/playground",
    "/admin", "/internal", "/debug", "/health",
    "/metrics", "/actuator", "/actuator/health",
    "/.well-known", "/api-docs", "/_api",
}


class KiterunnerTool(BaseTool):
    """
    Kiterunner API route discovery tool.

    Discovers REST API endpoints using API-specific wordlists.
    Much more accurate than generic directory fuzzing for APIs.
    """

    NAME        = "Kiterunner"
    BINARY      = "kr"
    CATEGORY    = "api"
    STAGE       = 6
    PRIORITY    = 10
    PASSIVE     = False
    TIMEOUT     = 300
    INSTALL_CMD = "go install github.com/assetnote/kiterunner/cmd/kr@latest"

    def run(
        self,
        target: str,
        *,
        wordlist:       Optional[str]  = None,
        threads:        int            = 40,
        timeout_per:    int            = 3,
        status_codes:   str            = "200,201,204,301,302,401,403",
        max_conn:       int            = 5,
        delay_ms:       int            = 0,
        headers:        Optional[dict] = None,
        max_redirects:  int            = 3,
        **kwargs,
    ) -> ToolRunResult:
        if s := self.skip_if_unavailable(): return s
        if f := self.validate_or_fail(target): return f

        t0 = time.perf_counter()
        out_path: Optional[str] = None

        try:
            with tempfile.NamedTemporaryFile(suffix=".json", delete=False, mode="w") as tf:
                out_path = tf.name

            # Resolve wordlist
            wl = wordlist or self._default_wordlist()

            cmd = self._build_command(
                target, wl, threads, timeout_per, status_codes,
                max_conn, delay_ms, headers or {}, max_redirects, out_path,
            )

            self._log("info", f"Scanning {target} with {wl}")
            res = self.exec(cmd, timeout_s=float(self.timeout), expected_codes=(0, 1, 2))
            dur = time.perf_counter() - t0

            if res.timed_out:
                raw = self._read_and_cleanup(out_path)
                parsed = self.parse_output(raw)
                return self.build_result(
                    data={**parsed, "timed_out": True},
                    findings=self._to_findings(parsed.get("endpoints", [])),
                    duration_s=dur,
                )

            raw    = self._read_and_cleanup(out_path)
            parsed = self.parse_output(raw or "", stderr=res.stderr or "")

            self._log("info",
                      f"Complete — {parsed.get('total', 0)} endpoints in {dur:.1f}s")

            return self.build_result(
                data=parsed,
                findings=self._to_findings(parsed.get("endpoints", [])),
                stdout=res.stdout or "",
                stderr=res.stderr or "",
                duration_s=dur,
                returncode=res.returncode or 0,
            )

        except Exception as exc:
            import traceback
            dur = time.perf_counter() - t0
            self._cleanup(out_path)
            return self.fail(
                reason="runtime_error", message=str(exc),
                duration_s=dur, tb=traceback.format_exc(),
            )

    def _build_command(
        self,
        target:        str,
        wordlist:      str,
        threads:       int,
        timeout_per:   int,
        status_codes:  str,
        max_conn:      int,
        delay_ms:      int,
        headers:       dict,
        max_redirects: int,
        out_path:      str,
    ) -> list[str]:
        cmd = [
            "kr", "scan", target,
            "-w", wordlist,
            "--parallelism", str(threads),
            "--timeout", str(timeout_per * 1000),   # kr uses ms
            "--max-connection-per-host", str(max_conn),
            "--kitebuilder-full-scan",
            "-o", "json",
            "--output-file", out_path,
            "--ignore-length", "0",
        ]
        if delay_ms:
            cmd += ["--delay", str(delay_ms)]
        for k, v in headers.items():
            cmd += ["-H", f"{k}: {v}"]
        return cmd

    def parse_output(self, raw: str, stderr: str = "", **kwargs) -> dict:
        endpoints: list[dict] = []
        by_status: dict[str, int] = {}
        interesting: list[str] = []

        if not raw or not raw.strip():
            return {"endpoints": [], "total": 0, "by_status": {}, "interesting": []}

        for line in raw.splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                entry = json.loads(line) if line.startswith("{") else None
                if not entry:
                    continue
            except json.JSONDecodeError:
                continue

            url        = entry.get("url", entry.get("request", {}).get("url", ""))
            method     = entry.get("method", "GET").upper()
            status     = entry.get("status", 0)
            body_len   = entry.get("bodylen", entry.get("words", 0))
            path       = url.split("?")[0] if url else ""

            ep = {
                "url":      url,
                "method":   method,
                "status":   status,
                "body_len": body_len,
                "path":     path,
                "is_hidden": True,   # discovered via fuzzing = hidden
                "source":   "kiterunner",
            }
            endpoints.append(ep)

            skey = str(status)
            by_status[skey] = by_status.get(skey, 0) + 1

            if any(p in path for p in INTERESTING_PATHS) or status in (200, 201):
                interesting.append(url)

        return {
            "endpoints":    endpoints,
            "total":        len(endpoints),
            "by_status":    by_status,
            "interesting":  list(dict.fromkeys(interesting))[:20],
        }

    def _to_findings(self, endpoints: list[dict]) -> list[ParsedFinding]:
        result: list[ParsedFinding] = []
        for ep in endpoints:
            status = ep.get("status", 0)
            confidence = 0.90 if status in (200, 201, 204) else 0.70
            pf = ParsedFinding(
                finding_type = "api_endpoint",
                value        = ep["url"],
                source       = self.NAME,
                confidence   = confidence,
                metadata     = {
                    "method":    ep.get("method", "GET"),
                    "status":    status,
                    "is_hidden": True,
                    "source":    "kiterunner",
                },
            )
            result.append(pf)
        return result

    def _default_wordlist(self) -> str:
        candidates = [
            "/usr/share/wordlists/api.txt",
            "/opt/kiterunner/api.kite",
            os.path.expanduser("~/kiterunner/routes-large.kite"),
            os.path.expanduser("~/wordlists/api.txt"),
        ]
        for c in candidates:
            if os.path.exists(c):
                return c
        # Fall back to routes-small if nothing found
        return "routes-small.kite"

    def _read_and_cleanup(self, path: Optional[str]) -> str:
        if not path: return ""
        try:
            from pathlib import Path
            return Path(path).read_text(encoding="utf-8", errors="replace")
        except FileNotFoundError:
            return ""
        finally:
            self._cleanup(path)

    def _cleanup(self, path: Optional[str]) -> None:
        if path and os.path.exists(path):
            try:
                os.unlink(path)
            except OSError:
                pass
