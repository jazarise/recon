"""
ReconX — Stage 11: Postman Collection Parser.

Parses Postman Collection v2/v2.1 JSON files to extract:
  - All request definitions
  - Environment variables (potential credentials)
  - Auth headers
  - Base URLs
  - Pre-request scripts (may reveal logic)
"""
from __future__ import annotations

import json
import re
import time
from pathlib import Path
from typing import Optional

from ..base import BaseTool
from ...models.tool_result import ParsedFinding, ToolRunResult


class PostmanParser(BaseTool):
    """Parses Postman Collection files for API endpoint inventory."""

    NAME        = "PostmanParser"
    BINARY      = ""
    CATEGORY    = "api"
    STAGE       = 6
    PRIORITY    = 35
    PASSIVE     = True
    TIMEOUT     = 30
    INSTALL_CMD = ""

    def run(self, target: str, *, collection_path: Optional[str] = None, **kwargs) -> ToolRunResult:
        if not collection_path:
            return self.fail(reason="missing_input", message="collection_path required",
                             duration_s=0.0)

        t0 = time.perf_counter()
        try:
            data = json.loads(Path(collection_path).read_text(encoding="utf-8"))
            parsed = self._parse_collection(data)
            dur = time.perf_counter() - t0
            return self.build_result(
                data=parsed,
                findings=self._to_findings(parsed),
                duration_s=dur,
            )
        except Exception as exc:
            import traceback
            return self.fail(reason="parse_error", message=str(exc),
                             duration_s=time.perf_counter() - t0,
                             tb=traceback.format_exc())

    def _parse_collection(self, data: dict) -> dict:
        endpoints:   list[dict] = []
        env_vars:    list[str]  = []
        auth_headers: list[str] = []

        collection = data.get("collection", data)
        info       = collection.get("info", {})
        items      = collection.get("item", [])

        self._recurse_items(items, endpoints, env_vars, auth_headers)

        # Extract env vars from scripts
        raw_str = json.dumps(data)
        env_vars.extend(re.findall(r"\{\{(\w+)\}\}", raw_str))
        env_vars = list(dict.fromkeys(env_vars))

        return {
            "name":          info.get("name", "Unknown"),
            "endpoints":     endpoints,
            "env_vars":      env_vars,
            "auth_headers":  list(dict.fromkeys(auth_headers)),
            "total":         len(endpoints),
        }

    def _recurse_items(
        self, items: list, endpoints: list, env_vars: list, auth_headers: list
    ) -> None:
        for item in items:
            if not isinstance(item, dict):
                continue
            # Folder — recurse
            if "item" in item:
                self._recurse_items(item["item"], endpoints, env_vars, auth_headers)
                continue
            # Request
            req = item.get("request", {})
            if not isinstance(req, dict):
                continue
            url_raw = req.get("url", "")
            url     = url_raw.get("raw", str(url_raw)) if isinstance(url_raw, dict) else str(url_raw)
            method  = req.get("method", "GET")

            headers = {
                h.get("key", ""): h.get("value", "")
                for h in req.get("header", [])
                if isinstance(h, dict)
            }
            for k, v in headers.items():
                if k.lower() in ("authorization", "x-api-key", "api-key"):
                    auth_headers.append(f"{k}: {v[:40]}")

            body = req.get("body", {})
            body_params: list[str] = []
            if isinstance(body, dict):
                for p in body.get("urlencoded", []) or []:
                    body_params.append(p.get("key", ""))
                for p in body.get("formdata", []) or []:
                    body_params.append(p.get("key", ""))
                raw_body = body.get("raw", "")
                if raw_body:
                    try:
                        rb = json.loads(raw_body)
                        body_params.extend(list(rb.keys()) if isinstance(rb, dict) else [])
                    except Exception:
                        pass

            endpoints.append({
                "url":        url,
                "method":     method,
                "name":       item.get("name", ""),
                "parameters": body_params,
                "has_auth":   bool(headers.get("Authorization") or headers.get("x-api-key")),
                "source":     "postman",
            })

    def _to_findings(self, parsed: dict) -> list[ParsedFinding]:
        result = []
        for ep in parsed.get("endpoints", []):
            result.append(ParsedFinding(
                finding_type="api_endpoint",
                value=ep["url"],
                source=self.NAME,
                confidence=0.92,
                metadata=ep,
            ))
        sensitive_vars = [v for v in parsed.get("env_vars", [])
                          if any(kw in v.lower() for kw in
                                 ("token", "key", "secret", "password", "auth"))]
        for var in sensitive_vars:
            result.append(ParsedFinding(
                finding_type="postman_sensitive_var",
                value=var,
                source=self.NAME,
                confidence=0.75,
                metadata={"collection": parsed.get("name", "")},
            ))
        return result

    def parse_output(self, raw: str, **kwargs) -> dict:
        return {}
