"""
ReconX — Stage 11: API Fingerprint, Auth Analyzer, Parameter Mapper, Route Correlator.

Four focused API intelligence modules:

APIFingerprint:    Identifies API frameworks, gateways, and cloud providers
AuthAnalyzer:      Analyses authentication mechanisms and detects weaknesses
ParameterMapper:   Builds a structured inventory of discovered parameters
RouteCorrelator:   Correlates routes from multiple sources into a unified map
"""
from __future__ import annotations

import hashlib
import re
import time
import urllib.request
import urllib.error
import ssl
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Optional

from ..base import BaseTool
from ...models.tool_result import ParsedFinding, ToolRunResult
from ...models.api_models import (
    APIParameter, AuthFinding, AuthType, RiskLevel, APIEndpoint, APIType,
)


# ══════════════════════════════════════════════════════════════════════════════
#  API Fingerprint
# ══════════════════════════════════════════════════════════════════════════════

FRAMEWORK_SIGNATURES: list[dict] = [
    # Headers
    {"header": "x-powered-by",           "pattern": r"(?i)express",       "name": "Express.js",    "type": "framework"},
    {"header": "x-powered-by",           "pattern": r"(?i)php",           "name": "PHP",           "type": "language"},
    {"header": "x-powered-by",           "pattern": r"(?i)asp\.net",      "name": "ASP.NET",       "type": "framework"},
    {"header": "server",                  "pattern": r"(?i)python",        "name": "Python WSGI",   "type": "language"},
    {"header": "x-runtime",              "pattern": r"(?i)ruby",          "name": "Ruby on Rails", "type": "framework"},
    # Body patterns
    {"body": True,                        "pattern": r'"__typename"',       "name": "GraphQL",       "type": "api_type"},
    {"body": True,                        "pattern": r'"swagger":\s*"[23]', "name": "Swagger UI",    "type": "spec"},
    {"body": True,                        "pattern": r'"openapi":\s*"3',   "name": "OpenAPI 3",     "type": "spec"},
    {"body": True,                        "pattern": r'FastAPI',            "name": "FastAPI",       "type": "framework"},
    {"body": True,                        "pattern": r'Django REST',        "name": "Django REST",   "type": "framework"},
    {"body": True,                        "pattern": r'"detail":"Not found"',"name": "Django REST",  "type": "framework"},
    # API Gateway signatures
    {"header": "x-kong-upstream-latency", "pattern": r".*",               "name": "Kong Gateway",  "type": "gateway"},
    {"header": "x-cache",                 "pattern": r"(?i)cloudfront",   "name": "AWS CloudFront","type": "cdn"},
    {"header": "x-amz-apigw-id",         "pattern": r".*",               "name": "AWS API Gateway","type": "gateway"},
    {"header": "x-azure-ref",             "pattern": r".*",               "name": "Azure API Mgmt", "type": "gateway"},
    {"header": "via",                     "pattern": r"(?i)kong",         "name": "Kong Gateway",  "type": "gateway"},
    {"header": "x-ratelimit-limit",       "pattern": r".*",               "name": "Rate Limited API","type": "feature"},
    {"header": "x-request-id",           "pattern": r".*",               "name": "Request Tracing","type": "feature"},
    {"header": "apigw-requestid",        "pattern": r".*",               "name": "AWS API Gateway","type": "gateway"},
    {"body": True,                        "pattern": r'"type":"about:blank"',"name": "RFC 7807",     "type": "standard"},
    {"body": True,                        "pattern": r'HAL\+JSON|_links.*self',"name": "HAL API",   "type": "standard"},
    {"body": True,                        "pattern": r'jsonapi\.org',     "name": "JSON:API",       "type": "standard"},
]


class APIFingerprint(BaseTool):
    """
    API technology fingerprinting via response header and body analysis.
    Identifies frameworks, gateways, CDNs, and API design standards.
    """

    NAME        = "APIFingerprint"
    BINARY      = ""
    CATEGORY    = "api"
    STAGE       = 6
    PRIORITY    = 40
    PASSIVE     = True
    TIMEOUT     = 60
    INSTALL_CMD = ""

    def run(
        self,
        target: str,
        *,
        headers:     Optional[dict] = None,
        probe_paths: Optional[list[str]] = None,
        timeout_per: float          = 6.0,
        **kwargs,
    ) -> ToolRunResult:
        if f := self.validate_or_fail(target): return f

        t0      = time.perf_counter()
        paths   = probe_paths or ["/", "/api", "/api/v1", "/health", "/swagger.json"]
        hdrs    = headers or {}
        matches: dict[str, set] = {"frameworks": set(), "gateways": set(),
                                    "features": set(), "standards": set()}
        all_headers: dict[str, str] = {}
        version_hints: list[str]    = []

        try:
            for path in paths[:6]:
                url      = target.rstrip("/") + path
                resp_hdrs, body = self._probe(url, hdrs, timeout_per)
                all_headers.update(resp_hdrs)
                self._match_signatures(resp_hdrs, body, matches)
                version_hints.extend(self._extract_versions(resp_hdrs, body))

            parsed = {
                "frameworks":    sorted(matches["frameworks"]),
                "gateways":      sorted(matches["gateways"]),
                "features":      sorted(matches["features"]),
                "standards":     sorted(matches["standards"]),
                "version_hints": list(dict.fromkeys(version_hints))[:10],
                "raw_headers":   dict(list(all_headers.items())[:20]),
            }

            self._log("info",
                      f"Fingerprint: frameworks={parsed['frameworks']}, "
                      f"gateways={parsed['gateways']}")

            return self.build_result(
                data=parsed,
                findings=self._to_findings(parsed, target),
                duration_s=time.perf_counter() - t0,
            )

        except Exception as exc:
            import traceback
            return self.fail(reason="runtime_error", message=str(exc),
                             duration_s=time.perf_counter() - t0,
                             tb=traceback.format_exc())

    def _probe(self, url: str, headers: dict, timeout: float) -> tuple[dict, str]:
        try:
            req = urllib.request.Request(url, headers={**headers, "Accept": "application/json"})
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode    = ssl.CERT_NONE
            with urllib.request.urlopen(req, timeout=timeout, context=ctx) as resp:
                resp_hdrs = {k.lower(): v for k, v in resp.getheaders()}
                body      = resp.read(8192).decode("utf-8", errors="replace")
                return resp_hdrs, body
        except Exception:
            return {}, ""

    def _match_signatures(self, hdrs: dict, body: str, matches: dict) -> None:
        for sig in FRAMEWORK_SIGNATURES:
            if "header" in sig:
                hval = hdrs.get(sig["header"], "")
                if hval and re.search(sig["pattern"], hval):
                    cat = sig["type"] + "s" if sig["type"] not in ("api_type",) else "frameworks"
                    bucket = {"framework": "frameworks", "gateway": "gateways",
                              "feature": "features", "standard": "standards",
                              "cdn": "gateways", "language": "frameworks",
                              "api_type": "frameworks", "spec": "frameworks"}.get(sig["type"], "frameworks")
                    matches[bucket].add(sig["name"])
            elif sig.get("body") and body:
                if re.search(sig["pattern"], body):
                    bucket = {"framework": "frameworks", "gateway": "gateways",
                              "feature": "features", "standard": "standards",
                              "spec": "frameworks", "api_type": "frameworks"}.get(sig["type"], "frameworks")
                    matches[bucket].add(sig["name"])

    def _extract_versions(self, hdrs: dict, body: str) -> list[str]:
        hints: list[str] = []
        for val in hdrs.values():
            m = re.search(r"v(\d+\.\d+[\d.]*)", val)
            if m: hints.append(m.group(0))
        for m in re.finditer(r'"version":\s*"([^"]+)"', body):
            hints.append(f"v{m.group(1)}")
        return hints

    def _to_findings(self, parsed: dict, target: str) -> list[ParsedFinding]:
        result = []
        all_tech = parsed["frameworks"] + parsed["gateways"]
        for tech in all_tech:
            result.append(ParsedFinding(
                finding_type="api_technology",
                value=tech,
                source=self.NAME,
                confidence=0.82,
                metadata={"target": target, "category": "api_tech"},
            ))
        return result

    def parse_output(self, raw: str, **kwargs) -> dict:
        return {}


# ══════════════════════════════════════════════════════════════════════════════
#  Auth Analyzer
# ══════════════════════════════════════════════════════════════════════════════

class AuthAnalyzer(BaseTool):
    """
    API authentication mechanism analyser.

    Detects: JWT, OAuth, API keys, Basic auth, missing auth.
    Flags weak configurations and exposed tokens in responses.
    """

    NAME        = "AuthAnalyzer"
    BINARY      = ""
    CATEGORY    = "api"
    STAGE       = 6
    PRIORITY    = 50
    PASSIVE     = True
    TIMEOUT     = 60
    INSTALL_CMD = ""

    JWT_PATTERN    = re.compile(r'eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]*')
    APIKEY_PATTERN = re.compile(r'(?i)(api[_-]?key|apikey|x-api-key)\s*[=:]\s*([A-Za-z0-9_\-]{16,64})')
    BEARER_PATTERN = re.compile(r'(?i)bearer\s+([A-Za-z0-9_\-\.]+)')
    BASIC_PATTERN  = re.compile(r'(?i)basic\s+([A-Za-z0-9+/=]{12,})')

    # Endpoints that should always require auth
    SENSITIVE_PATHS = {
        "/admin", "/user", "/users", "/account", "/payment", "/checkout",
        "/api/v1/users", "/api/v1/admin", "/api/v2/users", "/internal",
        "/management", "/private", "/secure",
    }

    def run(
        self,
        target: str,
        *,
        endpoints:   Optional[list[str]] = None,
        headers:     Optional[dict]      = None,
        timeout_per: float               = 6.0,
        **kwargs,
    ) -> ToolRunResult:
        if f := self.validate_or_fail(target): return f

        t0      = time.perf_counter()
        hdrs    = headers or {}
        eps     = endpoints or ["/api", "/api/v1", "/api/v2"]
        base    = target.rstrip("/")
        findings: list[dict] = []

        try:
            for path in eps[:20]:
                url = path if path.startswith("http") else f"{base}{path}"
                resp_hdrs, body, status = self._probe(url, hdrs, timeout_per)

                # Detect exposed tokens in response
                findings.extend(self._detect_exposed_tokens(url, body))

                # Detect missing auth on sensitive paths
                if status == 200 and any(sp in url for sp in self.SENSITIVE_PATHS):
                    findings.append({
                        "endpoint":    url,
                        "auth_type":   "none",
                        "risk_level":  "HIGH",
                        "issue":       "Sensitive endpoint accessible without authentication.",
                        "evidence":    f"HTTP {status} returned without Authorization header.",
                        "remediation": "Require authentication for all sensitive endpoints.",
                        "confidence":  0.85,
                    })

                # Detect weak auth headers in request vs response
                findings.extend(self._analyse_auth_headers(url, resp_hdrs, body))

            parsed = {"auth_findings": findings, "total": len(findings)}
            self._log("info", f"Auth analysis: {len(findings)} findings")

            return self.build_result(
                data=parsed,
                findings=self._to_findings(findings),
                duration_s=time.perf_counter() - t0,
            )

        except Exception as exc:
            import traceback
            return self.fail(reason="runtime_error", message=str(exc),
                             duration_s=time.perf_counter() - t0,
                             tb=traceback.format_exc())

    def _probe(self, url: str, hdrs: dict, timeout: float) -> tuple[dict, str, int]:
        try:
            req = urllib.request.Request(url, headers=hdrs)
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode    = ssl.CERT_NONE
            with urllib.request.urlopen(req, timeout=timeout, context=ctx) as resp:
                resp_hdrs = {k.lower(): v for k, v in resp.getheaders()}
                body      = resp.read(16384).decode("utf-8", errors="replace")
                return resp_hdrs, body, resp.status
        except urllib.error.HTTPError as e:
            return {}, "", e.code
        except Exception:
            return {}, "", 0

    def _detect_exposed_tokens(self, url: str, body: str) -> list[dict]:
        findings = []
        if self.JWT_PATTERN.search(body):
            findings.append({
                "endpoint":   url,
                "auth_type":  "jwt",
                "risk_level": "CRITICAL",
                "issue":      "JWT token exposed in API response body.",
                "evidence":   "JWT pattern (eyJ...) found in response.",
                "remediation":"Never return tokens in response bodies. Use secure cookies or headers.",
                "confidence": 0.88,
            })
        if m := self.APIKEY_PATTERN.search(body):
            findings.append({
                "endpoint":   url,
                "auth_type":  "api_key",
                "risk_level": "CRITICAL",
                "issue":      "API key exposed in response.",
                "evidence":   f"API key pattern found: {m.group(1)}",
                "remediation":"Remove API keys from responses. Rotate exposed keys immediately.",
                "confidence": 0.85,
            })
        return findings

    def _analyse_auth_headers(self, url: str, hdrs: dict, body: str) -> list[dict]:
        findings = []
        www_auth = hdrs.get("www-authenticate", "")
        if "basic" in www_auth.lower():
            findings.append({
                "endpoint":   url,
                "auth_type":  "basic_auth",
                "risk_level": "HIGH",
                "issue":      "HTTP Basic Authentication in use — credentials transmitted Base64-encoded.",
                "evidence":   f"WWW-Authenticate: {www_auth[:80]}",
                "remediation":"Replace Basic Auth with OAuth 2.0 or API key with HTTPS.",
                "confidence": 0.92,
            })
        cors = hdrs.get("access-control-allow-origin", "")
        if cors == "*":
            findings.append({
                "endpoint":   url,
                "auth_type":  "unknown",
                "risk_level": "MEDIUM",
                "issue":      "Wildcard CORS policy — any origin can make cross-site requests.",
                "evidence":   "Access-Control-Allow-Origin: *",
                "remediation":"Restrict CORS to specific trusted origins.",
                "confidence": 0.95,
            })
        if not hdrs.get("x-content-type-options") and "application/json" in hdrs.get("content-type", ""):
            findings.append({
                "endpoint":   url,
                "auth_type":  "unknown",
                "risk_level": "LOW",
                "issue":      "Missing X-Content-Type-Options header on API response.",
                "evidence":   "Header absent.",
                "remediation":"Add X-Content-Type-Options: nosniff to all API responses.",
                "confidence": 0.90,
            })
        return findings

    def _to_findings(self, auth_findings: list[dict]) -> list[ParsedFinding]:
        result = []
        risk_conf = {"CRITICAL": 0.95, "HIGH": 0.88, "MEDIUM": 0.80, "LOW": 0.70}
        for af in auth_findings:
            result.append(ParsedFinding(
                finding_type="api_auth_issue",
                value=af["endpoint"],
                source=self.NAME,
                confidence=risk_conf.get(af.get("risk_level", "MEDIUM"), 0.80),
                metadata=af,
            ))
        return result

    def parse_output(self, raw: str, **kwargs) -> dict:
        return {}


# ══════════════════════════════════════════════════════════════════════════════
#  Parameter Mapper
# ══════════════════════════════════════════════════════════════════════════════

class ParameterMapper:
    """
    Builds a unified parameter inventory from multiple API discovery sources.

    Merges parameters from: Swagger specs, Arjun discovery, JS extraction,
    Kiterunner, and crawl results into structured APIParameter objects.
    """

    SENSITIVE_KW = {"password", "passwd", "secret", "token", "key", "auth",
                     "credit", "card", "ssn", "cvv", "pin", "apikey", "api_key",
                     "access_token", "refresh_token", "private", "admin"}

    INJECTION_KW = {"id", "user_id", "uid", "object_id", "account_id",
                     "file", "path", "url", "redirect", "callback", "next",
                     "return", "template", "format", "output", "cmd", "exec",
                     "query", "search", "filter", "sort", "order", "page",
                     "limit", "offset", "count", "size", "start", "end"}

    def map(self, sources: list[dict]) -> list[APIParameter]:
        """
        Merge parameter data from multiple sources into APIParameter objects.

        Args:
            sources: List of dicts, each with "name", "location", optionally
                     "url", "method", "data_type", "is_required", "example"

        Returns:
            Deduplicated list of APIParameter objects
        """
        seen: dict[str, APIParameter] = {}

        for item in sources:
            name     = item.get("name", "").strip()
            location = item.get("location", "query")
            if not name:
                continue

            key = f"{name}::{location}"
            if key in seen:
                # Merge endpoint list
                url = item.get("url", "")
                if url and url not in seen[key].endpoints:
                    seen[key].endpoints.append(url)
                continue

            is_sensitive = (
                name.lower() in self.SENSITIVE_KW or
                any(kw in name.lower() for kw in self.SENSITIVE_KW)
            )
            is_injection = name.lower() in self.INJECTION_KW

            tags: list[str] = []
            if is_sensitive:  tags.append("sensitive")
            if is_injection:  tags.append("injection_candidate")

            param = APIParameter(
                name         = name,
                location     = location,
                data_type    = item.get("data_type", "string"),
                is_required  = item.get("is_required", item.get("required", False)),
                is_sensitive = is_sensitive,
                example      = str(item.get("example", ""))[:100],
                description  = item.get("description", ""),
                endpoints    = [item["url"]] if item.get("url") else [],
                tags         = tags,
            )
            seen[key] = param

        return list(seen.values())

    def summarise(self, params: list[APIParameter]) -> dict:
        by_location: dict[str, int] = {}
        sensitive = 0
        injection = 0

        for p in params:
            by_location[p.location] = by_location.get(p.location, 0) + 1
            if p.is_sensitive:       sensitive += 1
            if "injection_candidate" in p.tags: injection += 1

        return {
            "total":       len(params),
            "by_location": by_location,
            "sensitive":   sensitive,
            "injection_candidates": injection,
        }


# ══════════════════════════════════════════════════════════════════════════════
#  Route Correlator
# ══════════════════════════════════════════════════════════════════════════════

class RouteCorrelator:
    """
    Correlates API routes from multiple discovery sources into a unified map.

    Deduplicates endpoints, infers API versions, detects hidden routes,
    and builds a route hierarchy for attack surface mapping.
    """

    def correlate(self, sources: list[dict]) -> dict:
        """
        Merge endpoint data from multiple tools into a unified route map.

        Args:
            sources: List of endpoint dicts (from Kiterunner, Swagger, GraphQL, etc.)

        Returns:
            Dict with unified endpoints, version groups, hidden routes, hierarchy
        """
        seen: dict[str, dict] = {}
        version_groups: dict[str, list[str]] = defaultdict(list)
        method_groups:  dict[str, list[str]] = defaultdict(list)
        hidden_routes:  list[str] = []

        for ep in sources:
            url    = self._normalise_url(ep.get("url", ep.get("full_url", "")))
            method = ep.get("method", "GET").upper()
            if not url:
                continue

            key = f"{method}::{url}"
            if key not in seen:
                seen[key] = {
                    "url":         url,
                    "method":      method,
                    "sources":     [ep.get("source", "unknown")],
                    "is_hidden":   ep.get("is_hidden", False),
                    "auth_required": ep.get("auth_required", True),
                    "status":      ep.get("status", 0),
                    "tags":        ep.get("tags", []),
                    "parameters":  ep.get("parameters", []),
                }
            else:
                # Merge sources
                src = ep.get("source", "unknown")
                if src not in seen[key]["sources"]:
                    seen[key]["sources"].append(src)
                # Multi-source = higher confidence, mark as confirmed
                if len(seen[key]["sources"]) > 1:
                    seen[key]["confirmed"] = True

            # Version detection
            ver = self._detect_version(url)
            if ver:
                version_groups[ver].append(url)

            # Method grouping
            method_groups[method].append(url)

            # Hidden route detection
            if ep.get("is_hidden") or ep.get("source") == "kiterunner":
                hidden_routes.append(url)

        endpoints = list(seen.values())
        hierarchy = self._build_hierarchy(endpoints)

        return {
            "endpoints":      endpoints,
            "total":          len(endpoints),
            "hidden":         len(set(hidden_routes)),
            "version_groups": dict(version_groups),
            "method_groups":  dict(method_groups),
            "hierarchy":      hierarchy,
            "confirmed":      sum(1 for e in endpoints if e.get("confirmed", False)),
        }

    def _normalise_url(self, url: str) -> str:
        if not url:
            return ""
        # Strip query string for dedup purposes
        url = url.split("?")[0].rstrip("/")
        # Normalise double slashes
        url = re.sub(r"/+", "/", url)
        return url.lower()

    def _detect_version(self, url: str) -> Optional[str]:
        m = re.search(r"/(v\d+)/", url, re.IGNORECASE)
        return m.group(1).lower() if m else None

    def _build_hierarchy(self, endpoints: list[dict]) -> dict:
        hierarchy: dict[str, list[str]] = defaultdict(list)
        for ep in endpoints:
            url   = ep["url"]
            parts = [p for p in url.split("/") if p]
            root  = f"/{parts[0]}" if parts else "/"
            hierarchy[root].append(url)
        return dict(hierarchy)
