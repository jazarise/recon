"""
ReconX — Stage 11: Arjun Tool.

Production-grade Arjun wrapper for HTTP parameter discovery.
Arjun finds hidden GET and POST parameters via intelligent fuzzing —
essential for finding IDOR vulnerabilities, hidden filters, and debug params.
"""
from __future__ import annotations

import json
import os
import tempfile
import time
from typing import Optional

from ..base import BaseTool
from ...models.tool_result import ParsedFinding, ToolRunResult
from ...models.api_models import APIParameter


# Parameters that indicate potential security issues
SENSITIVE_PARAM_PATTERNS = {
    "id", "user_id", "uid", "account", "admin", "debug", "token",
    "key", "secret", "password", "passwd", "pass", "auth", "apikey",
    "api_key", "access_token", "session", "file", "path", "redirect",
    "url", "callback", "next", "return", "returnUrl", "redirect_uri",
    "format", "output", "template", "page", "limit", "offset", "role",
    "privilege", "internal", "test", "dev", "staging", "verbose",
}


class ArjunTool(BaseTool):
    """
    Arjun HTTP parameter discovery tool.

    Discovers hidden GET/POST parameters by fuzzing endpoints with
    large wordlists and analysing response differences.
    """

    NAME        = "Arjun"
    BINARY      = "arjun"
    CATEGORY    = "api"
    STAGE       = 6
    PRIORITY    = 20
    PASSIVE     = False
    TIMEOUT     = 300
    INSTALL_CMD = "pip install arjun"

    def run(
        self,
        target: str,
        *,
        method:     str            = "GET",
        wordlist:   Optional[str]  = None,
        threads:    int            = 10,
        delay:      float          = 0,
        stable:     bool           = True,
        headers:    Optional[dict] = None,
        include_methods: Optional[list[str]] = None,
        **kwargs,
    ) -> ToolRunResult:
        if s := self.skip_if_unavailable(): return s
        if f := self.validate_or_fail(target): return f

        t0 = time.perf_counter()
        out_path: Optional[str] = None

        try:
            with tempfile.NamedTemporaryFile(
                suffix=".json", delete=False, mode="w"
            ) as tf:
                out_path = tf.name

            methods = include_methods or [method.upper()]
            all_params: list[dict] = []

            for m in methods:
                cmd  = self._build_command(target, m, wordlist, threads, delay, stable,
                                           headers or {}, out_path)
                res  = self.exec(cmd, timeout_s=float(self.timeout), expected_codes=(0, 1))
                raw  = self._read_and_cleanup(out_path)
                data = self._parse_json(raw)

                for ep_url, params in data.items():
                    for param in (params if isinstance(params, list) else []):
                        all_params.append({
                            "name":     param,
                            "method":   m,
                            "url":      ep_url,
                            "is_sensitive": param.lower() in SENSITIVE_PARAM_PATTERNS,
                        })

            dur    = time.perf_counter() - t0
            parsed = {"parameters": all_params, "total": len(all_params)}

            self._log("info", f"Found {len(all_params)} parameters in {dur:.1f}s")

            return self.build_result(
                data=parsed,
                findings=self._to_findings(all_params),
                duration_s=dur,
            )

        except Exception as exc:
            import traceback
            dur = time.perf_counter() - t0
            self._cleanup(out_path)
            return self.fail(
                reason="runtime_error", message=str(exc),
                duration_s=dur, tb=traceback.format_exc(),
            )

    def _build_command(
        self,
        target:   str,
        method:   str,
        wordlist: Optional[str],
        threads:  int,
        delay:    float,
        stable:   bool,
        headers:  dict,
        out_path: str,
    ) -> list[str]:
        cmd = [
            "arjun",
            "-u", target,
            "-m", method,
            "-t", str(threads),
            "-oJ", out_path,
            "--disable-redirects",
        ]
        if wordlist:
            cmd += ["-w", wordlist]
        if delay:
            cmd += ["--delay", str(delay)]
        if stable:
            cmd.append("--stable")
        for k, v in headers.items():
            cmd += ["-H", f"{k}: {v}"]
        return cmd

    def parse_output(self, raw: str, **kwargs) -> dict:
        data = self._parse_json(raw)
        params: list[dict] = []
        for url, param_list in data.items():
            for p in (param_list if isinstance(param_list, list) else []):
                params.append({
                    "name":         p,
                    "url":          url,
                    "is_sensitive": p.lower() in SENSITIVE_PARAM_PATTERNS,
                })
        return {"parameters": params, "total": len(params)}

    def _parse_json(self, raw: str) -> dict:
        if not raw or not raw.strip():
            return {}
        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            return {}

    def _to_findings(self, params: list[dict]) -> list[ParsedFinding]:
        result: list[ParsedFinding] = []
        for p in params:
            is_sensitive = p.get("is_sensitive", False)
            result.append(ParsedFinding(
                finding_type = "api_parameter",
                value        = p["name"],
                source       = self.NAME,
                confidence   = 0.88,
                metadata     = {
                    "url":          p.get("url", ""),
                    "method":       p.get("method", "GET"),
                    "is_sensitive": is_sensitive,
                },
            ))
        return result

    def _read_and_cleanup(self, path: Optional[str]) -> str:
        if not path: return ""
        try:
            from pathlib import Path
            return Path(path).read_text(encoding="utf-8", errors="replace")
        except FileNotFoundError:
            return ""
        finally:
            self._cleanup(path)

    def _cleanup(self, path: Optional[str]) -> None:
        if path and os.path.exists(path):
            try:
                os.unlink(path)
            except OSError:
                pass
