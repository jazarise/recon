"""
ReconX — Tool Registry (Stage 12.1 update).

Provides a single get_tool_registry() call that returns every registered
tool instance, keyed by class name. The WorkflowRunner and ExecutionEngine
consume this registry for tool lookup.

Adding a new tool:
  1. Create tools/<category>/my_tool.py inheriting BaseTool
  2. Import it here and add an entry to _REGISTRY_SPEC
  3. Done — it will appear in Guided Recon, Learning Mode, and CLI
"""
from __future__ import annotations
import logging
from typing import Any, Optional

log = logging.getLogger("reconx.registry")


# ─────────────────────────────────────────────────────────────────────────────
# Registry spec: maps class name → (module_path, constructor_kwargs)
# ─────────────────────────────────────────────────────────────────────────────

_REGISTRY_SPEC: list[tuple[str, str, dict]] = [

    # ── Existing tools (pre-Stage-12.1) ──────────────────────────────────────
    ("NmapTool",           "tools.nmap_tool",             {}),
    ("WhoisTool",          "tools.whois_tool",            {}),
    ("AmassTool",          "tools.amass_tool",            {}),
    ("WhatWebTool",        "tools.web.whatweb",           {}),
    ("GobusterTool",       "tools.web.gobuster_tool",     {}),
    ("HttpxTool",          "tools.web.httpx_tool",        {}),
    ("NiktoTool",          "tools.web.nikto_tool",        {}),
    ("ShuffleDNSTool",     "tools.shuffledns_tool",       {}),

    # ── Stage 12.1 — OSINT / Passive ─────────────────────────────────────────
    ("TheHarvesterTool",   "tools.osint.theharvester",    {}),
    ("SpiderFootTool",     "tools.osint.spiderfoot",      {}),
    ("OSRFrameworkTool",   "tools.osint.osrframework",    {}),
    ("MaltegoTool",        "tools.osint.maltego",         {}),

    # ── Stage 12.1 — DNS ─────────────────────────────────────────────────────
    ("DNSEnumTool",        "tools.dns_extra.dnsenum_tool",   {}),
    ("DNSReconTool",       "tools.dns_extra.dnsrecon_tool",  {}),
    ("FierceTool",         "tools.dns_extra.fierce_tool",    {}),
    ("Sublist3rTool",      "tools.dns_extra.sublist3r_tool", {}),

    # ── Stage 12.1 — Network Discovery ───────────────────────────────────────
    ("NetdiscoverTool",    "tools.network.netdiscover_tool", {}),
    ("FpingTool",          "tools.network.fping_tool",       {}),

    # ── Stage 12.1 — Web Recon ───────────────────────────────────────────────
    ("DirbusterTool",      "tools.web.dirbuster",         {}),
    ("FeroxbusterTool",    "tools.web.feroxbuster",       {}),
    ("EyeWitnessTool",     "tools.web.eyewitness",        {}),

    # ── Stage 12.1 — Frameworks ──────────────────────────────────────────────
    ("MetasploitAuxTool",  "tools.frameworks.metasploit_aux", {}),

    # ── Stage 12.1 — Utilities ───────────────────────────────────────────────
    ("NetcatWrapperTool",  "tools.utilities.netcat_wrapper",  {}),
]


# ─────────────────────────────────────────────────────────────────────────────
# Registry loader
# ─────────────────────────────────────────────────────────────────────────────

def get_tool_registry(
    base_package: str = "reconx",
    config:       Optional[dict] = None,
) -> dict[str, Any]:
    """
    Dynamically import and instantiate every tool in _REGISTRY_SPEC.

    Returns a dict  {class_name: tool_instance}  where unavailable
    tools are replaced with a NullTool stub so the registry never raises.

    Args:
        base_package: Top-level package name (used to build import paths).
        config:       Optional global config dict forwarded to tool constructors.
    """
    registry: dict[str, Any] = {}
    cfg = config or {}

    for class_name, module_rel, kwargs in _REGISTRY_SPEC:
        full_module = f"{base_package}.{module_rel}"
        try:
            import importlib
            mod  = importlib.import_module(full_module)
            cls  = getattr(mod, class_name)
            inst = cls(**{**kwargs, **_filter_kwargs(cls, cfg)})
            registry[class_name] = inst
            log.debug(f"Registered: {class_name}")
        except ImportError as e:
            log.warning(f"[IMPORT FAILED] {class_name} from {full_module}: {e}")
            registry[class_name] = _NullTool(class_name, str(e))
        except Exception as e:
            log.error(f"[INIT FAILED] {class_name}: {e}")
            registry[class_name] = _NullTool(class_name, str(e))

    log.info(f"Registry loaded: {len(registry)} tools "
             f"({sum(1 for v in registry.values() if not isinstance(v, _NullTool))} active)")
    return registry


def _filter_kwargs(cls, cfg: dict) -> dict:
    """Pass only kwargs the constructor actually accepts."""
    import inspect
    try:
        sig    = inspect.signature(cls.__init__)
        params = set(sig.parameters.keys()) - {"self"}
        return {k: v for k, v in cfg.items() if k in params}
    except Exception:
        return {}


# ─────────────────────────────────────────────────────────────────────────────
# NullTool stub — safe placeholder for unavailable tools
# ─────────────────────────────────────────────────────────────────────────────

class _NullTool:
    """
    Returned when a tool cannot be imported or instantiated.
    Provides safe run() / is_available() methods so the workflow
    never crashes on a missing tool.
    """
    def __init__(self, name: str, reason: str):
        self.NAME    = name
        self._reason = reason

    def is_available(self) -> bool:
        return False

    def run(self, target: str, **kwargs):
        from types import SimpleNamespace
        return SimpleNamespace(
            status="skipped",
            findings=[],
            error=f"{self.NAME} unavailable: {self._reason}",
            notes="Tool could not be loaded.",
        )

    def __repr__(self) -> str:
        return f"<NullTool name={self.NAME!r} reason={self._reason!r}>"
