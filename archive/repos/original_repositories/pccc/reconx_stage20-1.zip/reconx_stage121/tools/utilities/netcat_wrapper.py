"""
ReconX — Netcat (nc) utility wrapper.

Provides banner grabbing, TCP connectivity tests, and manual service
interaction. Uses 'nc' or 'ncat' (nmap's netcat). Falls back to a
pure-Python socket implementation when nc is unavailable.

Stage 2 — Service Banner Grabbing / Connectivity.
"""
from __future__ import annotations
import re
import select
import socket
import time
from typing import Optional

from ..base import BaseTool
from ...models.tool_result import ParsedFinding, RunStatus, ToolRunResult


# Probes to send per common service — elicits a banner
_SERVICE_PROBES: dict[int, bytes] = {
    21:   b"",                          # FTP — passive wait
    22:   b"",                          # SSH — passive wait
    25:   b"EHLO reconx\r\n",          # SMTP
    80:   b"HEAD / HTTP/1.0\r\n\r\n",  # HTTP
    110:  b"",                          # POP3
    143:  b"",                          # IMAP
    443:  b"HEAD / HTTP/1.0\r\n\r\n",  # HTTPS (raw — won't get TLS banner)
    3306: b"",                          # MySQL
    5432: b"",                          # PostgreSQL
    6379: b"*1\r\n$4\r\nPING\r\n",    # Redis
}


class NetcatWrapperTool(BaseTool):

    NAME         = "NetcatWrapper"
    BINARY       = "nc"
    CATEGORY     = "utility"
    STAGE        = 2
    PRIORITY     = 5
    PASSIVE      = False
    TIMEOUT      = 30
    DEPENDENCIES: list[str] = []
    INSTALL_CMD  = "sudo apt install netcat-openbsd  # nc / ncat"

    # ── run ───────────────────────────────────────────────────────────────────

    def run(
        self,
        target: str,
        *,
        ports:   Optional[list[int]] = None,
        timeout: float               = 3.0,
        send:    Optional[str]       = None,    # custom probe string
        **kwargs,
    ) -> ToolRunResult:
        """
        Args:
            target:  Hostname or IP to connect to.
            ports:   Port list to grab banners from (default: common ports).
            timeout: Per-connection timeout in seconds.
            send:    Custom string to send after connecting.
        """
        if f := self.validate_or_fail(target):
            return f

        port_list = ports or [21, 22, 25, 80, 110, 143, 443, 3306, 5432, 6379]
        t0 = time.perf_counter()

        # Try nc binary first; fall back to Python sockets
        if self.is_available():
            results = self._grab_via_nc(target, port_list, timeout, send)
        else:
            self._log("info", "nc unavailable — using Python socket fallback.")
            results = self._grab_via_socket(target, port_list, timeout, send)

        dur      = time.perf_counter() - t0
        data     = {"banners": results, "count": len([r for r in results if r.get("banner")])}
        findings = self._build_findings(data)
        result   = self.build_result(
            data, findings, duration_s=dur, returncode=0,
        )
        if not findings:
            result.status = RunStatus.NO_OUTPUT
        return result

    # ── parse_output ──────────────────────────────────────────────────────────

    def parse_output(self, raw: str, **kwargs) -> dict:
        """Not used directly — run() builds structured data internally."""
        return {"banners": [], "count": 0}

    # ── nc execution ──────────────────────────────────────────────────────────

    def _grab_via_nc(
        self,
        host:      str,
        ports:     list[int],
        timeout:   float,
        send_str:  Optional[str],
    ) -> list[dict]:
        results: list[dict] = []
        for port in ports:
            probe = send_str or ""
            args  = ["-w", str(int(timeout)), "-v", host, str(port)]
            if probe:
                # echo probe | nc -w3 host port
                res = self.exec(
                    args,
                    stdin_data=probe,
                    timeout_s=timeout + 2,
                    expected_codes=(0, 1),
                )
            else:
                res = self.exec(args, timeout_s=timeout + 2, expected_codes=(0, 1))

            banner   = (res.stdout or "").strip()
            stderr   = (res.stderr or "").strip()
            open_ind = res.returncode == 0 and ("Connection" not in stderr or banner)

            results.append({
                "port":    port,
                "open":    open_ind,
                "banner":  banner,
                "service": self._guess_service(port, banner),
            })
        return results

    # ── Python socket fallback ────────────────────────────────────────────────

    def _grab_via_socket(
        self,
        host:     str,
        ports:    list[int],
        timeout:  float,
        send_str: Optional[str],
    ) -> list[dict]:
        results: list[dict] = []
        for port in ports:
            entry = self._socket_connect(host, port, timeout, send_str)
            results.append(entry)
        return results

    @staticmethod
    def _socket_connect(
        host: str, port: int, timeout: float, custom_probe: Optional[str]
    ) -> dict:
        try:
            with socket.create_connection((host, port), timeout=timeout) as sock:
                # Determine probe
                if custom_probe:
                    probe = custom_probe.encode(errors="ignore")
                else:
                    probe = _SERVICE_PROBES.get(port, b"")

                if probe:
                    sock.sendall(probe)

                # Wait for response with select (non-blocking read)
                ready, _, _ = select.select([sock], [], [], timeout)
                if ready:
                    banner = sock.recv(2048).decode(errors="ignore").strip()
                else:
                    banner = ""

                return {
                    "port":    port,
                    "open":    True,
                    "banner":  banner,
                    "service": NetcatWrapperTool._guess_service(port, banner),
                }
        except (socket.timeout, ConnectionRefusedError, OSError):
            return {"port": port, "open": False, "banner": "", "service": ""}

    # ── internal ──────────────────────────────────────────────────────────────

    @staticmethod
    def _guess_service(port: int, banner: str) -> str:
        """Heuristic service name from port number and banner content."""
        banner_low = banner.lower()
        if "ssh" in banner_low:    return "SSH"
        if "ftp" in banner_low:    return "FTP"
        if "smtp" in banner_low:   return "SMTP"
        if "http" in banner_low:   return "HTTP"
        if "pop3" in banner_low:   return "POP3"
        if "imap" in banner_low:   return "IMAP"
        if "redis" in banner_low:  return "Redis"
        if "mysql" in banner_low:  return "MySQL"
        if "+ok" in banner_low:    return "POP3"
        if "* ok" in banner_low:   return "IMAP"
        # Port-number fallback
        _port_svc = {21:"FTP",22:"SSH",25:"SMTP",80:"HTTP",110:"POP3",
                     143:"IMAP",443:"HTTPS",3306:"MySQL",5432:"PostgreSQL",6379:"Redis"}
        return _port_svc.get(port, "unknown")

    def _build_findings(self, data: dict) -> list[ParsedFinding]:
        findings = []
        for b in data.get("banners", []):
            if not b.get("open"):
                continue
            banner  = b.get("banner", "")
            service = b.get("service", "")
            findings.append(ParsedFinding(
                finding_type="banner",
                value=banner or service,
                source=self.NAME,
                confidence=0.9 if banner else 0.6,
                metadata={
                    "port":    b["port"],
                    "service": service,
                    "open":    True,
                },
            ))
        return findings
