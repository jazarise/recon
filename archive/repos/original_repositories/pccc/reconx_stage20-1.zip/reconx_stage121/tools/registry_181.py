"""
ReconX — Tool Registry (Stage 18.1)
Burp Intelligence Layer Registration.

Registers BurpIntelligenceLayer with the ReconX tool registry so it is
automatically discovered by the execution engine, TUI tool browser, and
the guided recon workflow planner.

Usage:
    from reconx.tools.registry_181 import get_stage181_registry
    registry = get_stage181_registry()

    # Merge into full registry
    full_registry = {**get_full_registry_123(), **get_stage181_registry()}
"""
from __future__ import annotations

import importlib
import logging
from typing import Any

log = logging.getLogger("reconx.registry.181")

# ── Stage 18.1 tool manifest ──────────────────────────────────────────────────
#
# Each entry: (ClassName, module_dotpath, init_kwargs)
# ClassName    — the class inside the module
# module_path  — relative to the reconx package root
# init_kwargs  — passed to __init__ when the tool is instantiated
#
_STAGE181_SPEC: list[tuple[str, str, dict]] = [
    (
        "BurpIntelligenceLayer",
        "integrations.burp",
        {},   # reads RECONX_BURP_API_KEY from env at init time
    ),
]


def get_stage181_registry() -> dict[str, Any]:
    """
    Return a dict mapping tool display-names to instantiated tool objects.

    Tools that fail to import are silently omitted (logged at DEBUG level).
    This preserves the ReconX principle that integration failures are
    non-fatal to the wider tool registry.
    """
    registry: dict[str, Any] = {}

    for class_name, module_path, kwargs in _STAGE181_SPEC:
        try:
            mod  = importlib.import_module(f"reconx.{module_path}")
            cls  = getattr(mod, class_name)
            tool = cls(**kwargs)
            key  = getattr(cls, "NAME", class_name)
            registry[key] = tool
            log.debug("[Registry 18.1] Registered: %s → %s", key, class_name)
        except Exception as exc:
            log.debug(
                "[Registry 18.1] Could not load %s from %s: %s",
                class_name, module_path, exc,
            )

    return registry


def get_stage181_catalog() -> list[dict]:
    """
    Return structured catalog metadata for TUI tool browser and marketplace.

    Each entry is a dict compatible with the Stage 12.2 catalog format.
    Does NOT instantiate tools — pure metadata, always fast.
    """
    return [
        {
            "name":         "Burp Suite",
            "class":        "BurpIntelligenceLayer",
            "module":       "reconx.integrations.burp",
            "category":     "web_intelligence",
            "stage":        4,
            "priority":     20,
            "passive":      True,
            "binary":       "",
            "description":  (
                "Browser-aware web intelligence via Burp Suite REST API. "
                "Captures proxy traffic, discovers hidden endpoints, extracts "
                "auth tokens and cookies, imports passive findings, and replays "
                "sessions. Requires Burp Suite Professional."
            ),
            "capabilities": [
                "proxy_traffic_capture",
                "endpoint_discovery",
                "api_route_detection",
                "graphql_detection",
                "jwt_extraction",
                "cookie_analysis",
                "passive_findings",
                "session_replay",
                "oauth_flow_mapping",
                "spa_route_detection",
            ],
            "requires_root":     False,
            "requires_network":  True,
            "install_required":  True,
            "install_cmd": (
                "Install Burp Suite Pro from https://portswigger.net/burp. "
                "Enable REST API in Burp Settings → Suite → REST API."
            ),
            "learning_yaml":     "knowledge/burp/burp_suite.yaml",
            "recommended_after": [
                "httpx", "katana", "gobuster", "ffuf",
                "js_analyzer", "hakrawler",
            ],
            "tags": [
                "web", "proxy", "traffic", "passive", "auth",
                "api", "cookies", "jwt", "replay", "burp",
            ],
        }
    ]


def get_stage181_tool_chains() -> list[dict]:
    """
    Return workflow chain entries that include the Burp layer.

    These are injected into WorkflowTemplateLibrary and the workflow builder
    catalogue so Burp appears as a selectable step.
    """
    return [
        {
            "chain":       "web_intelligence",
            "description": "Browser-aware web recon with Burp traffic analysis",
            "steps": [
                {
                    "tool":       "Katana",
                    "tool_class": "KatanaTool",
                    "stage":      3,
                    "parallel_group": "web_crawl",
                    "why_next":   "Crawl the application and route traffic through Burp",
                },
                {
                    "tool":       "Burp Suite",
                    "tool_class": "BurpIntelligenceLayer",
                    "stage":      4,
                    "parallel_group": None,
                    "why_next":   "Analyse captured proxy traffic for hidden endpoints, auth artefacts, and passive findings",
                },
            ],
        },
        {
            "chain":       "full_web_assessment",
            "description": "Complete web assessment with Burp as traffic intelligence layer",
            "steps": [
                {
                    "tool":       "httpx",
                    "tool_class": "HTTPXTool",
                    "stage":      2,
                    "parallel_group": "web_probe",
                    "why_next":   "Probe live hosts and gather HTTP fingerprints",
                },
                {
                    "tool":       "Gobuster",
                    "tool_class": "GobusterTool",
                    "stage":      3,
                    "parallel_group": "web_discovery",
                    "why_next":   "Bruteforce hidden paths and directories",
                },
                {
                    "tool":       "Katana",
                    "tool_class": "KatanaTool",
                    "stage":      3,
                    "parallel_group": "web_discovery",
                    "why_next":   "Crawl application links and JS-rendered routes",
                },
                {
                    "tool":       "Burp Suite",
                    "tool_class": "BurpIntelligenceLayer",
                    "stage":      4,
                    "parallel_group": None,
                    "why_next":   "Analyse all captured traffic through Burp for auth tokens, CORS, missing headers, cookies",
                },
            ],
        },
    ]
