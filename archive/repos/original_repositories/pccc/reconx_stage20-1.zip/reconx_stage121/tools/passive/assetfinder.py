"""
ReconX — Assetfinder passive subdomain discovery.
Queries cert transparency, web archives, DNS datasets.
"""
from __future__ import annotations
import time
from ..base import BaseTool
from ...models.tool_result import ParsedFinding, RunStatus, ToolRunResult


class AssetfinderTool(BaseTool):
    NAME         = "assetfinder"
    BINARY       = "assetfinder"
    CATEGORY     = "subdomain"
    STAGE        = 2
    PRIORITY     = 15
    PASSIVE      = True
    TIMEOUT      = 60
    DEPENDENCIES: list[str] = []
    INSTALL_CMD  = "go install github.com/tomnomnom/assetfinder@latest"

    def run(self, target: str, **kwargs) -> ToolRunResult:
        if s := self.skip_if_unavailable(): return s

        t = self.classify_target(target)
        if t not in ("domain",):
            return ToolRunResult.invalid_target(self.NAME, target, "Requires a domain.")

        t0  = time.perf_counter()
        res = self.exec(["--subs-only", target], timeout_s=float(self.timeout))
        dur = time.perf_counter() - t0

        if res.timed_out:
            return ToolRunResult.timeout(self.NAME, dur, self.timeout)
        if res.returncode == 127:
            return ToolRunResult.skipped(self.NAME, res.stderr)
        if not res.stdout.strip() and res.returncode != 0:
            return self.fail("subprocess_error", f"Exit {res.returncode}",
                             stderr=res.stderr, duration_s=dur)

        data     = self.parse_output(res.stdout, root=target)
        findings = self._findings_from_list(data["subdomains"], "subdomain")

        r = self.build_result(data, findings, stdout=res.stdout,
                              stderr=res.stderr, duration_s=dur,
                              returncode=res.returncode)
        if not data["subdomains"]:
            r.status = RunStatus.NO_OUTPUT
        return r

    def parse_output(self, raw: str, root: str = "", **kwargs) -> dict:
        if not raw.strip():
            return {"subdomains": []}

        seen:  set[str] = set()
        clean: list[str] = []

        for line in self.parse_lines_output(raw):
            sub = line.lower().strip(".")
            # Skip wildcards, bare root, and clearly malformed entries
            if sub.startswith("*") or not sub or "." not in sub:
                continue
            if root and not sub.endswith(root.lower()):
                continue
            if sub not in seen:
                seen.add(sub)
                clean.append(sub)

        return {"subdomains": clean}
