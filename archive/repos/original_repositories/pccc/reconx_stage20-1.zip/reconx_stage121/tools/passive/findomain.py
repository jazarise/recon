"""
ReconX — Findomain passive subdomain discovery.
Queries 16+ passive sources including Certspotter, Virustotal, Threatcrowd.
"""
from __future__ import annotations
import time
from ..base import BaseTool
from ...models.tool_result import ParsedFinding, RunStatus, ToolRunResult


class FindomainTool(BaseTool):
    NAME         = "findomain"
    BINARY       = "findomain"
    CATEGORY     = "subdomain"
    STAGE        = 2
    PRIORITY     = 20
    PASSIVE      = True
    TIMEOUT      = 90
    DEPENDENCIES: list[str] = []
    INSTALL_CMD  = "https://github.com/Findomain/Findomain/releases  OR  cargo install findomain"

    def run(self, target: str, **kwargs) -> ToolRunResult:
        if s := self.skip_if_unavailable(): return s
        if self.classify_target(target) != "domain":
            return ToolRunResult.invalid_target(self.NAME, target, "Requires a domain.")

        t0 = time.perf_counter()
        # -t = target, --quiet = no banner, --unique-output /dev/stdout = stdout
        res = self.exec(
            ["-t", target, "--quiet"],
            timeout_s=float(self.timeout),
            expected_codes=(0, 1),
        )
        dur = time.perf_counter() - t0

        if res.timed_out:
            return ToolRunResult.timeout(self.NAME, dur, self.timeout)
        if res.returncode == 127:
            return ToolRunResult.skipped(self.NAME, res.stderr)

        data     = self.parse_output(res.stdout, root=target)
        findings = self._findings_from_list(data["subdomains"], "subdomain")

        r = self.build_result(data, findings, stdout=res.stdout,
                              duration_s=dur, returncode=res.returncode)
        if not data["subdomains"]:
            r.status = RunStatus.NO_OUTPUT
        return r

    def parse_output(self, raw: str, root: str = "", **kwargs) -> dict:
        if not raw.strip():
            return {"subdomains": []}

        seen: set[str] = set()
        subs: list[str] = []

        for line in self.parse_lines_output(raw):
            sub = self.clean(line).lower().strip(".")
            if not sub or sub.startswith("*") or "." not in sub:
                continue
            if root and not sub.endswith(root.lower()):
                continue
            if sub not in seen:
                seen.add(sub)
                subs.append(sub)

        return {"subdomains": subs}
