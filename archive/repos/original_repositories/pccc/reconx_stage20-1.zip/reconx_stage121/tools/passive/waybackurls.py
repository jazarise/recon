"""
ReconX — waybackurls historical URL fetcher.
Queries the Wayback Machine CDX API for all archived URLs.
Falls back to pure-Python CDX API query when binary not installed.
"""
from __future__ import annotations
import json
import ssl
import time
import urllib.error
import urllib.request
from urllib.parse import urlparse, parse_qs, urlunparse

from ..base import BaseTool
from ...config.settings import PASSIVE_CONFIG
from ...models.tool_result import ParsedFinding, RunStatus, ToolRunResult

_CDX_API = (
    "https://web.archive.org/cdx/search/cdx"
    "?url=*.{domain}&output=json&fl=original&collapse=urlkey&limit={limit}"
)


class WaybackurlsTool(BaseTool):
    NAME         = "waybackurls"
    BINARY       = "waybackurls"
    CATEGORY     = "url"
    STAGE        = 2
    PRIORITY     = 45
    PASSIVE      = True
    TIMEOUT      = 120
    DEPENDENCIES: list[str] = []
    INSTALL_CMD  = "go install github.com/tomnomnom/waybackurls@latest"

    def run(self, target: str, **kwargs) -> ToolRunResult:
        t = self.classify_target(target)
        if t not in ("domain", "url"):
            return ToolRunResult.invalid_target(self.NAME, target, "Requires domain or URL.")

        host    = self.strip_scheme(target) if t == "url" else target
        max_urls = PASSIVE_CONFIG.get("wayback_max_urls", 5000)

        t0 = time.perf_counter()

        if self.is_available():
            # Binary path: pipe domain via stdin
            res = self.exec([], stdin_data=host + "\n",
                            timeout_s=float(self.timeout), expected_codes=(0,1))
            dur = time.perf_counter() - t0
            if res.timed_out:
                return ToolRunResult.timeout(self.NAME, dur, self.timeout)
            raw = res.stdout
            rc  = res.returncode
        else:
            # Pure-Python CDX fallback
            self._log("info", "Binary not found — using CDX API fallback")
            raw, err = self._cdx_fetch(host, max_urls)
            dur = time.perf_counter() - t0
            if err:
                if "timed out" in err.lower():
                    return ToolRunResult.timeout(self.NAME, dur, self.timeout)
                return self.fail("network_error", err, duration_s=dur)
            rc = 0

        data     = self.parse_output(raw, max_urls=max_urls)
        findings = self._make_findings(data)

        r = self.build_result(data, findings, stdout=raw,
                              duration_s=dur, returncode=rc)
        if not data["urls"]:
            r.status = RunStatus.NO_OUTPUT
        return r

    def parse_output(self, raw: str, max_urls: int = 5000, **kwargs) -> dict:
        if not raw.strip():
            return {"urls": [], "endpoints": [], "params": [], "url_count": 0}

        # May be CDX JSON array or plain URL-per-line
        urls:      list[str] = []
        endpoints: set[str]  = set()
        params:    set[str]  = set()
        seen:      set[str]  = set()

        # Try JSON (CDX fallback format: [[header], [url], ...])
        if raw.strip().startswith("["):
            try:
                records = json.loads(raw)
                lines = [r[0] for r in records[1:] if r and r[0].startswith("http")]
            except Exception:
                lines = self.parse_lines_output(raw)
        else:
            lines = self.parse_lines_output(raw)

        for url in lines:
            url = self.clean(url)
            if not url.startswith(("http://", "https://")):
                continue
            try:
                from urllib.parse import urlparse as _up
                _p = _up(url)
                if not _p.netloc or "." not in _p.netloc:
                    continue
            except Exception:
                continue
            if url in seen:
                continue
            seen.add(url)
            urls.append(url)

            try:
                parsed = urlparse(url)
                ep = urlunparse((parsed.scheme, parsed.netloc, parsed.path, "", "", ""))
                endpoints.add(ep)
                for k in parse_qs(parsed.query):
                    params.add(k)
            except Exception:
                pass

            if len(urls) >= max_urls:
                break

        return {
            "urls":      urls,
            "endpoints": sorted(endpoints),
            "params":    sorted(params),
            "url_count": len(urls),
        }

    def _make_findings(self, data: dict) -> list[ParsedFinding]:
        f  = [self._finding("url",      u)  for u  in data["urls"][:500]]
        f += [self._finding("endpoint", ep) for ep in data["endpoints"][:200]]
        f += [self._finding("param",    p)  for p  in data["params"]]
        return f

    def _cdx_fetch(self, domain: str, limit: int) -> tuple[str, str]:
        url = _CDX_API.format(domain=domain, limit=min(limit, 10000))
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode    = ssl.CERT_NONE
        try:
            req     = urllib.request.Request(url,
                          headers={"User-Agent": "ReconX/2.0 (wayback-cdx)"})
            handler = urllib.request.HTTPSHandler(context=ctx)
            opener  = urllib.request.build_opener(handler)
            with opener.open(req, timeout=self.timeout) as resp:
                return resp.read().decode("utf-8", errors="replace"), ""
        except Exception as exc:
            return "", str(exc)
