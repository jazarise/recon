"""
ReconX — GetAllUrls (gau) historical URL collector.
Queries Wayback Machine, Common Crawl, OTX, URLScan.io
"""
from __future__ import annotations
import time
from urllib.parse import urlparse, parse_qs, urlunparse

from ..base import BaseTool
from ...config.settings import PASSIVE_CONFIG
from ...models.tool_result import ParsedFinding, RunStatus, ToolRunResult


class GauTool(BaseTool):
    NAME         = "gau"
    BINARY       = "gau"
    CATEGORY     = "url"
    STAGE        = 2
    PRIORITY     = 40
    PASSIVE      = True
    TIMEOUT      = 120
    DEPENDENCIES: list[str] = []
    INSTALL_CMD  = "go install github.com/lc/gau/v2/cmd/gau@latest"

    def run(self, target: str, **kwargs) -> ToolRunResult:
        if s := self.skip_if_unavailable(): return s
        t = self.classify_target(target)
        if t not in ("domain", "url"):
            return ToolRunResult.invalid_target(self.NAME, target, "Requires domain or URL.")

        host     = self.strip_scheme(target) if t == "url" else target
        max_urls = PASSIVE_CONFIG.get("gau_max_urls", 5000)

        t0  = time.perf_counter()
        res = self.exec(
            [host, "--subs", "--retries", "2", "--threads", "5"],
            timeout_s=float(self.timeout),
            expected_codes=(0, 1),
        )
        dur = time.perf_counter() - t0

        if res.timed_out:
            return ToolRunResult.timeout(self.NAME, dur, self.timeout)
        if res.returncode == 127:
            return ToolRunResult.skipped(self.NAME, res.stderr)

        data     = self.parse_output(res.stdout, max_urls=max_urls)
        findings = self._make_findings(data)
        r = self.build_result(data, findings, stdout=res.stdout,
                              duration_s=dur, returncode=res.returncode)
        if not data["urls"]:
            r.status = RunStatus.NO_OUTPUT
        return r

    def parse_output(self, raw: str, max_urls: int = 5000, **kwargs) -> dict:
        if not raw.strip():
            return {"urls": [], "endpoints": [], "params": [], "url_count": 0}

        urls:      list[str] = []
        endpoints: set[str]  = set()
        params:    set[str]  = set()
        seen:      set[str]  = set()

        for line in self.parse_lines_output(raw):
            url = self.clean(line)
            # Strict URL filter: must have scheme + valid netloc with dot
            if not (url.startswith("http://") or url.startswith("https://")):
                continue
            if " " in url:
                continue
            try:
                from urllib.parse import urlparse as _up
                _parsed = _up(url)
                if not _parsed.netloc or "." not in _parsed.netloc:
                    continue
            except Exception:
                continue
            if url in seen:
                continue
            seen.add(url)
            urls.append(url)

            try:
                p = urlparse(url)
                ep = urlunparse((p.scheme, p.netloc, p.path, "", "", ""))
                endpoints.add(ep)
                for k in parse_qs(p.query):
                    params.add(k)
            except Exception:
                pass

            if len(urls) >= max_urls:
                break

        return {
            "urls":      urls,
            "endpoints": sorted(endpoints),
            "params":    sorted(params),
            "url_count": len(urls),
        }

    def _make_findings(self, data: dict) -> list[ParsedFinding]:
        f  = [self._finding("url",      u)  for u  in data["urls"][:500]]
        f += [self._finding("endpoint", ep) for ep in data["endpoints"][:200]]
        f += [self._finding("param",    p)  for p  in data["params"]]
        return f
