"""
ReconX — crt.sh certificate transparency log parser.
Pure-Python HTTPS query — no binary needed. Never fails silently.
Handles rate limits, timeouts, and malformed JSON gracefully.
"""
from __future__ import annotations
import json
import re
import ssl
import time
import urllib.error
import urllib.parse
import urllib.request
from typing import Optional

from ..base import BaseTool
from ...models.tool_result import ParsedFinding, RunStatus, ToolRunResult

_CRTSH_URL = "https://crt.sh/?q=%25.{domain}&output=json"
_RE_WILDCARD = re.compile(r"^\*\.")


class CrtshTool(BaseTool):
    NAME         = "crt.sh"
    BINARY       = ""           # pure-Python, always available
    CATEGORY     = "subdomain"
    STAGE        = 2
    PRIORITY     = 25
    PASSIVE      = True
    TIMEOUT      = 30
    DEPENDENCIES: list[str] = []
    INSTALL_CMD  = ""           # no install needed

    def run(self, target: str, **kwargs) -> ToolRunResult:
        if self.classify_target(target) != "domain":
            return ToolRunResult.invalid_target(self.NAME, target, "Requires a domain.")

        t0 = time.perf_counter()
        raw, err = self._fetch(target)
        dur = time.perf_counter() - t0

        if err:
            # Distinguish timeout from other errors
            if "timed out" in err.lower() or "timeout" in err.lower():
                return ToolRunResult.timeout(self.NAME, dur, self.timeout)
            return self.fail("network_error", err, duration_s=dur)

        data     = self.parse_output(raw, root=target)
        findings = self._findings_from_list(data["subdomains"], "subdomain",
                                             source_url="https://crt.sh")

        r = self.build_result(data, findings, stdout=raw, duration_s=dur)
        if not data["subdomains"]:
            r.status = RunStatus.NO_OUTPUT
        return r

    def parse_output(self, raw: str, root: str = "", **kwargs) -> dict:
        if not raw.strip():
            return {"subdomains": [], "cert_count": 0}

        try:
            records = json.loads(raw)
        except json.JSONDecodeError:
            self._log("warning", "crt.sh JSON parse failed")
            return {"subdomains": [], "cert_count": 0}

        seen: set[str] = set()
        subs: list[str] = []

        for rec in records:
            # name_value can contain multiple domains separated by newlines
            for name in (rec.get("name_value", "") or "").splitlines():
                name = name.strip().lower().lstrip("*.")
                if not name or "." not in name:
                    continue
                if root and not name.endswith(root.lower()):
                    continue
                if name not in seen:
                    seen.add(name)
                    subs.append(name)

            # Also check common_name
            cn = (rec.get("common_name") or "").strip().lower().lstrip("*.")
            if cn and "." in cn and cn not in seen:
                if not root or cn.endswith(root.lower()):
                    seen.add(cn)
                    subs.append(cn)

        return {"subdomains": sorted(subs), "cert_count": len(records)}

    # ── Internal HTTP fetch ───────────────────────────────────────────────────

    def _fetch(self, domain: str) -> tuple[str, str]:
        url = _CRTSH_URL.format(domain=urllib.parse.quote(domain))
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE

        try:
            req = urllib.request.Request(
                url,
                headers={"User-Agent": "ReconX/2.0 (cert-transparency)"},
            )
            handler = urllib.request.HTTPSHandler(context=ctx)
            opener  = urllib.request.build_opener(handler)

            with opener.open(req, timeout=self.timeout) as resp:
                return resp.read().decode("utf-8", errors="replace"), ""

        except urllib.error.HTTPError as exc:
            if exc.code == 429:
                return "", "Rate limited by crt.sh (HTTP 429)"
            return "", f"HTTP {exc.code}: {exc.reason}"
        except Exception as exc:
            return "", str(exc)
