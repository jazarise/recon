"""
ReconX — Chaos (ProjectDiscovery) passive subdomain dataset.
Requires an API key: set RECONX_CHAOS_KEY env var.
"""
from __future__ import annotations
import json
import ssl
import time
import urllib.error
import urllib.request
from typing import Optional

from ..base import BaseTool
from ...config.settings import get_passive_cfg
from ...models.tool_result import ParsedFinding, RunStatus, ToolRunResult

_API_BASE = "https://dns.projectdiscovery.io/dns/{domain}/subdomains"


class ChaosTool(BaseTool):
    NAME         = "chaos"
    BINARY       = ""           # pure-Python API client
    CATEGORY     = "subdomain"
    STAGE        = 2
    PRIORITY     = 30
    PASSIVE      = True
    TIMEOUT      = 60
    DEPENDENCIES: list[str] = []
    INSTALL_CMD  = "Get API key at https://chaos.projectdiscovery.io"

    def run(self, target: str, **kwargs) -> ToolRunResult:
        if self.classify_target(target) != "domain":
            return ToolRunResult.invalid_target(self.NAME, target, "Requires a domain.")

        api_key = get_passive_cfg("chaos_api_key", "RECONX_CHAOS_KEY")
        if not api_key:
            return self.fail(
                "api_key_missing",
                "RECONX_CHAOS_KEY not set. Export your Chaos API key to use this tool.",
            )

        t0 = time.perf_counter()
        raw, err = self._fetch(target, api_key)
        dur = time.perf_counter() - t0

        if err:
            if "timed out" in err.lower():
                return ToolRunResult.timeout(self.NAME, dur, self.timeout)
            if "401" in err or "403" in err:
                return self.fail("auth_error",
                                 f"Invalid or expired Chaos API key. {err}",
                                 duration_s=dur)
            return self.fail("network_error", err, duration_s=dur)

        data     = self.parse_output(raw, root=target)
        findings = self._findings_from_list(data["subdomains"], "subdomain")

        r = self.build_result(data, findings, stdout=raw, duration_s=dur)
        if not data["subdomains"]:
            r.status = RunStatus.NO_OUTPUT
        return r

    def parse_output(self, raw: str, root: str = "", **kwargs) -> dict:
        if not raw.strip():
            return {"subdomains": [], "count": 0}
        try:
            obj = json.loads(raw)
        except json.JSONDecodeError:
            return {"subdomains": [], "count": 0}

        # Response: {"domain": "example.com", "subdomains": ["www","mail",...], "count": N}
        base     = obj.get("domain", root).lower()
        raw_subs = obj.get("subdomains", [])
        count    = obj.get("count", len(raw_subs))

        full_subs: list[str] = []
        seen: set[str] = set()
        for s in raw_subs:
            # Chaos returns bare labels; we reconstruct full FQDNs
            full = f"{s.lower()}.{base}" if base and not s.endswith(base) else s.lower()
            full = full.strip(".")
            if full and full not in seen:
                seen.add(full)
                full_subs.append(full)

        return {"subdomains": sorted(full_subs), "count": count}

    def _fetch(self, domain: str, api_key: str) -> tuple[str, str]:
        url = _API_BASE.format(domain=domain)
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode    = ssl.CERT_NONE
        try:
            req = urllib.request.Request(
                url,
                headers={
                    "Authorization": api_key,
                    "User-Agent":    "ReconX/2.0",
                },
            )
            handler = urllib.request.HTTPSHandler(context=ctx)
            opener  = urllib.request.build_opener(handler)
            with opener.open(req, timeout=self.timeout) as resp:
                return resp.read().decode("utf-8", errors="replace"), ""
        except urllib.error.HTTPError as exc:
            return "", f"HTTP {exc.code}: {exc.reason}"
        except Exception as exc:
            return "", str(exc)
