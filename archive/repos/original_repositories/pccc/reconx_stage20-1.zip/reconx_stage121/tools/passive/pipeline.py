"""
ReconX — Passive Recon Pipeline Orchestrator.

Runs all passive tools in intelligent parallel batches.
Aggregates, deduplicates, and correlates findings.
Produces a rich terminal display with per-tool stats.
"""
from __future__ import annotations
import logging
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from typing import Optional

from rich import box
from rich.columns import Columns
from rich.console import Console
from rich.live import Live
from rich.panel import Panel
from rich.rule import Rule
from rich.table import Table
from rich.text import Text

from .assetfinder   import AssetfinderTool
from .findomain      import FindomainTool
from .crtsh          import CrtshTool
from .chaos          import ChaosTool
from .gau            import GauTool
from .waybackurls    import WaybackurlsTool
from ..subfinder     import SubfinderTool
from ..amass         import AmassTool
from ...models.tool_result import RunStatus, ToolRunResult
from ...models.findings    import ReconResult
from ...config.settings    import PASSIVE_CONFIG

logger = logging.getLogger("reconx.passive.pipeline")

# ── Theme ─────────────────────────────────────────────────────────────────────
_R  = "red"
_RB = "bold red"
_RD = "dim red"
_G  = "bold green"
_Y  = "yellow"
_D  = "dim"


@dataclass
class PassiveRunStats:
    tool_name:    str
    status:       RunStatus
    subdomains:   int  = 0
    urls:         int  = 0
    duration_s:   float = 0.0
    error_detail: str  = ""


class PassivePipeline:
    """
    Orchestrates all passive recon tools in two parallel batches:
      Batch A: subdomain tools  (subfinder, assetfinder, findomain, crt.sh, chaos, amass)
      Batch B: URL tools        (gau, waybackurls)   — runs after batch A
    """

    def __init__(
        self,
        console:  Optional[Console] = None,
        silent:   bool = False,
        threads:  int  = 6,
        run_amass: bool = False,   # amass is slow; opt-in
    ):
        self.console    = console or Console()
        self.silent     = silent
        self.threads    = threads
        self.run_amass  = run_amass

    # ── Public entry point ────────────────────────────────────────────────────

    def run(self, target: str, result: ReconResult) -> list[PassiveRunStats]:
        """Execute full passive pipeline. Mutates result in-place."""
        stats: list[PassiveRunStats] = []
        run_start = time.perf_counter()

        self._print_header(target)

        # ── Batch A: Subdomain tools ──────────────────────────────────────────
        subdomain_tools = [
            SubfinderTool(),
            AssetfinderTool(),
            FindomainTool(),
            CrtshTool(),
            ChaosTool(),
        ]
        if self.run_amass:
            subdomain_tools.append(AmassTool())

        self._section("Batch A — Subdomain Discovery")
        batch_a_stats = self._run_batch(
            target, subdomain_tools,
            ingest_fn=self._ingest_subdomains,
            result=result,
        )
        stats.extend(batch_a_stats)

        # ── Batch B: URL tools ────────────────────────────────────────────────
        url_tools = [GauTool(), WaybackurlsTool()]
        self._section("Batch B — URL & Endpoint Discovery")
        batch_b_stats = self._run_batch(
            target, url_tools,
            ingest_fn=self._ingest_urls,
            result=result,
        )
        stats.extend(batch_b_stats)

        # ── Post-processing ───────────────────────────────────────────────────
        self._deduplicate(result)
        self._print_summary(stats, time.perf_counter() - run_start)

        return stats

    # ── Batch runner ──────────────────────────────────────────────────────────

    def _run_batch(
        self,
        target:     str,
        tools:      list,
        ingest_fn:  callable,
        result:     ReconResult,
    ) -> list[PassiveRunStats]:
        """Run a list of tools in parallel; ingest results; return stats."""
        run_stats:   list[PassiveRunStats] = []
        tool_results: dict[str, ToolRunResult] = {}

        # Initial status map for live display
        status_map: dict[str, PassiveRunStats] = {
            t.NAME: PassiveRunStats(t.NAME, RunStatus.SKIPPED)
            for t in tools
        }

        workers = min(len(tools), self.threads)

        if self.silent:
            with ThreadPoolExecutor(max_workers=workers) as pool:
                futures = {pool.submit(t.safe_run, target): t for t in tools}
                for future in as_completed(futures):
                    tool = futures[future]
                    try:
                        tool_results[tool.NAME] = future.result()
                    except Exception as exc:
                        tool_results[tool.NAME] = ToolRunResult.failure(
                            tool.NAME, "exception", str(exc)
                        )
        else:
            with Live(
                self._make_live_table(status_map),
                console=self.console,
                refresh_per_second=6,
                transient=False,
            ) as live:
                with ThreadPoolExecutor(max_workers=workers) as pool:
                    futures = {pool.submit(t.safe_run, target): t for t in tools}
                    for future in as_completed(futures):
                        tool = futures[future]
                        try:
                            tr = future.result()
                        except Exception as exc:
                            tr = ToolRunResult.failure(tool.NAME, "exception", str(exc))
                        tool_results[tool.NAME] = tr
                        # Update live display
                        s = self._to_stat(tr)
                        status_map[tool.NAME] = s
                        live.update(self._make_live_table(status_map))

        # Ingest and collect stats
        for tool_name, tr in tool_results.items():
            stat = self._to_stat(tr)
            if tr.ok:
                ingest_fn(tr.data, result)
            run_stats.append(stat)

        return run_stats

    # ── Ingestors ─────────────────────────────────────────────────────────────

    @staticmethod
    def _ingest_subdomains(data: dict, result: ReconResult) -> None:
        result.subdomains.extend(data.get("subdomains", []))

    @staticmethod
    def _ingest_urls(data: dict, result: ReconResult) -> None:
        result.web_endpoints.extend(data.get("urls", []))
        result.raw.setdefault("passive_params", set())
        result.raw["passive_params"].update(data.get("params", []))
        result.raw.setdefault("passive_endpoints", set())
        result.raw["passive_endpoints"].update(data.get("endpoints", []))

    # ── Deduplication ─────────────────────────────────────────────────────────

    @staticmethod
    def _deduplicate(result: ReconResult) -> None:
        result.subdomains  = sorted(set(
            s.lower().strip() for s in result.subdomains if s
        ))
        result.web_endpoints = list(dict.fromkeys(
            u for u in result.web_endpoints if u.startswith("http")
        ))

    # ── Stat helpers ──────────────────────────────────────────────────────────

    @staticmethod
    def _to_stat(tr: ToolRunResult) -> PassiveRunStats:
        data = tr.data or {}
        return PassiveRunStats(
            tool_name=tr.tool_name,
            status=tr.status,
            subdomains=len(data.get("subdomains", [])),
            urls=data.get("url_count", 0),
            duration_s=tr.metrics.duration_s if tr.metrics else 0.0,
            error_detail=(tr.error.message[:60] if tr.error else ""),
        )

    # ── Rich UI ───────────────────────────────────────────────────────────────

    def _print_header(self, target: str) -> None:
        if self.silent:
            return
        self.console.print()
        self.console.print(Panel(
            f"[{_RB}]PASSIVE RECON PIPELINE[/{_RB}]\n"
            f"[{_D}]Target:[/{_D}] [{_R}]{target}[/{_R}]   "
            f"[{_D}]Threads:[/{_D}] [{_R}]{self.threads}[/{_R}]",
            border_style=_R, padding=(0, 3),
        ))

    def _section(self, label: str) -> None:
        if not self.silent:
            self.console.print()
            self.console.print(Rule(f"[{_RD}]  {label}  [/{_RD}]", style=_R))

    def _make_live_table(self, status_map: dict[str, PassiveRunStats]) -> Table:
        t = Table(box=box.SIMPLE, show_header=True, show_edge=False,
                  border_style=_RD, header_style=_RB, padding=(0, 2))
        t.add_column("",        width=3,  no_wrap=True)
        t.add_column("TOOL",    style=_R, width=16, no_wrap=True)
        t.add_column("STATUS",            width=14, no_wrap=True)
        t.add_column("SUBS",    style=_D, width=8)
        t.add_column("URLS",    style=_D, width=8)
        t.add_column("TIME",    style=_D, width=7)
        t.add_column("DETAIL",  style=_D)

        for name, s in status_map.items():
            icon, style = self._status_icon(s.status)
            t.add_row(
                Text(icon, style=style),
                name,
                Text(s.status.value.upper(), style=style),
                str(s.subdomains) if s.subdomains else "—",
                str(s.urls)       if s.urls       else "—",
                f"{s.duration_s:.1f}s" if s.duration_s > 0 else "—",
                s.error_detail,
            )
        return t

    def _print_summary(self, stats: list[PassiveRunStats], total: float) -> None:
        if self.silent:
            return
        self.console.print()
        self.console.print(Rule(f"[{_RB}]  PASSIVE RECON COMPLETE  [/{_RB}]", style=_R))
        self.console.print()

        total_subs = sum(s.subdomains for s in stats)
        total_urls = sum(s.urls for s in stats)
        ok   = sum(1 for s in stats if s.status == RunStatus.SUCCESS)
        fail = sum(1 for s in stats if s.status in (RunStatus.FAILED, RunStatus.TIMEOUT))
        skip = sum(1 for s in stats if s.status == RunStatus.SKIPPED)

        self.console.print(Columns([
            Panel(f"[{_RB}]{total_subs}[/{_RB}]\n[{_D}]SUBDOMAINS[/{_D}]",
                  border_style=_R,   padding=(0,3), expand=True),
            Panel(f"[{_RB}]{total_urls:,}[/{_RB}]\n[{_D}]URLS[/{_D}]",
                  border_style=_R,   padding=(0,3), expand=True),
            Panel(f"[{_G}]{ok}[/{_G}]\n[{_D}]SUCCESS[/{_D}]",
                  border_style="green", padding=(0,3), expand=True),
            Panel(f"[{_RB}]{fail}[/{_RB}]\n[{_D}]FAILED[/{_D}]",
                  border_style=_R,   padding=(0,3), expand=True),
            Panel(f"[{_D}]{skip}[/{_D}]\n[{_D}]SKIPPED[/{_D}]",
                  border_style="dim", padding=(0,3), expand=True),
            Panel(f"[white]{total:.1f}s[/white]\n[{_D}]TOTAL TIME[/{_D}]",
                  border_style=_RD,  padding=(0,3), expand=True),
        ], equal=True, expand=True))
        self.console.print()

    @staticmethod
    def _status_icon(status: RunStatus) -> tuple[str, str]:
        return {
            RunStatus.SUCCESS:       ("✔", "bold green"),
            RunStatus.FAILED:        ("✖", "bold red"),
            RunStatus.TIMEOUT:       ("⏱", "yellow"),
            RunStatus.SKIPPED:       ("○", "dim"),
            RunStatus.NO_OUTPUT:     ("∅", "dim cyan"),
            RunStatus.PARSE_ERROR:   ("⚡", "orange3"),
            RunStatus.INVALID_TARGET:("⚠", "red"),
        }.get(status, ("?", "white"))
