"""
ReconX — ParserMixin.
Bridges tool raw output → ParsedFinding list via utils.parsers.
Tools call self.parse_*() helpers instead of reimplementing regex everywhere.
"""
from __future__ import annotations
import logging
from typing import Any, Optional

from ...models.tool_result import ParsedFinding
from ...utils import parsers as P

logger = logging.getLogger("reconx.tools.parser")


class ParserMixin:
    """
    Mixin providing structured output parsing helpers.
    All parsers return lists or dicts; they never raise.
    """

    # Subclass must define NAME for source attribution
    NAME: str = "unknown"

    # ── Finding builders ──────────────────────────────────────────────────────

    def _finding(
        self,
        finding_type: str,
        value:        str,
        confidence:   float = 1.0,
        **metadata,
    ) -> ParsedFinding:
        return ParsedFinding(
            finding_type=finding_type,
            value=value,
            source=self.NAME,
            confidence=confidence,
            metadata=metadata,
        )

    def _findings_from_list(
        self,
        items:        list[str],
        finding_type: str,
        confidence:   float = 1.0,
        **metadata,
    ) -> list[ParsedFinding]:
        return [self._finding(finding_type, v, confidence, **metadata)
                for v in items if v]

    # ── Text extraction ───────────────────────────────────────────────────────

    def parse_subdomains(self, text: str) -> list[ParsedFinding]:
        domains = P.extract_domains(text)
        return self._findings_from_list(domains, "subdomain")

    def parse_ips(self, text: str) -> list[ParsedFinding]:
        ips = P.extract_ips(text)
        return self._findings_from_list(ips, "ip")

    def parse_urls(self, text: str) -> list[ParsedFinding]:
        urls = P.extract_urls(text)
        return self._findings_from_list(urls, "url")

    def parse_emails(self, text: str) -> list[ParsedFinding]:
        emails = P.extract_emails(text)
        return self._findings_from_list(emails, "email")

    def parse_cves(self, text: str) -> list[ParsedFinding]:
        cves = P.extract_cves(text)
        return self._findings_from_list(cves, "cve")

    # ── Format-specific parsers ───────────────────────────────────────────────

    def parse_json_output(self, text: str) -> Optional[Any]:
        return P.parse_json(text)

    def parse_json_lines_output(self, text: str) -> list[dict]:
        return P.parse_json_lines(text)

    def parse_lines_output(self, text: str, **kwargs) -> list[str]:
        return P.parse_lines(text, **kwargs)

    def parse_key_value_output(self, text: str, sep: str = ":") -> dict[str, str]:
        return P.parse_key_value(text, sep=sep)

    def parse_xml_output(self, text: str):
        return P.parse_xml(text)

    def parse_nmap_xml_output(self, text: str) -> dict:
        root = P.parse_xml(text)
        if root is None:
            return {"ports": [], "os_info": {}}
        return P.parse_nmap_xml(root)

    # ── Port line parser ──────────────────────────────────────────────────────

    def parse_port_lines(self, text: str) -> list[dict]:
        results = []
        for line in text.splitlines():
            parsed = P.parse_nmap_port_line(line)
            if parsed:
                results.append(parsed)
        return results

    # ── Subdomain-specific JSON lines (subfinder format) ──────────────────────

    def parse_subfinder_json(self, text: str) -> list[str]:
        """Parse subfinder -oJ output: one JSON obj per line with 'host' key."""
        subdomains = []
        for obj in self.parse_json_lines_output(text):
            host = obj.get("host", "")
            if host:
                subdomains.append(host.lower())
        return list(dict.fromkeys(subdomains))

    # ── httpx JSON parser ─────────────────────────────────────────────────────

    def parse_httpx_json(self, text: str) -> list[dict]:
        """Parse httpx -json output into normalized endpoint dicts."""
        endpoints = []
        for obj in self.parse_json_lines_output(text):
            endpoints.append({
                "url":            obj.get("url", ""),
                "status_code":    obj.get("status-code", 0),
                "title":          obj.get("title", ""),
                "content_length": obj.get("content-length", 0),
                "webserver":      obj.get("webserver", ""),
                "technologies":   obj.get("tech", []),
                "cdn":            obj.get("cdn", False),
            })
        return endpoints

    # ── Clean output helper ───────────────────────────────────────────────────

    def clean(self, text: str) -> str:
        """Strip ANSI codes and normalize whitespace."""
        return P.strip_ansi(text).strip()
