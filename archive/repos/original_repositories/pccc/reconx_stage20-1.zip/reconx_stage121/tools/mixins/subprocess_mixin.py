"""
ReconX — SubprocessMixin.
Wraps utils.subprocess_runner for tools that execute external binaries.
Adds tool-aware logging, binary path resolution, and structured error handling.
"""
from __future__ import annotations
import logging
import os
import shutil
from typing import Optional

from ...utils.subprocess_runner import SubprocessResult, run_subprocess

logger = logging.getLogger("reconx.tools.subprocess")


class SubprocessMixin:
    """
    Mixin for tools that call external binaries via subprocess.
    Requires that the class defines:
        BINARY: str   — binary name (e.g. "nmap")
        NAME:   str   — display name
        TIMEOUT: int  — default timeout in seconds
    """

    # Subclass must define these
    BINARY:  str = ""
    NAME:    str = ""
    TIMEOUT: int = 60

    # Cache per-instance
    _binary_path: Optional[str] = None

    # ── Binary resolution ─────────────────────────────────────────────────────

    def resolve_binary(self, override: Optional[str] = None) -> Optional[str]:
        """
        Resolve the full path to the tool binary.
        Checks: 1) explicit override, 2) RECONX_TOOL_<NAME> env var, 3) PATH.
        Caches the result on first call.
        """
        if self._binary_path and not override:
            return self._binary_path

        candidate = (
            override
            or os.environ.get(f"RECONX_TOOL_{self.NAME.upper().replace('-','_')}")
            or self.BINARY
        )
        path = shutil.which(candidate)
        if path:
            self._binary_path = path
            logger.debug("%s binary resolved: %s", self.NAME, path)
        return path

    def is_available(self) -> bool:
        if not self.BINARY:
            return True   # pure-Python tool; no binary needed
        return self.resolve_binary() is not None

    # ── Execution ─────────────────────────────────────────────────────────────

    def exec(
        self,
        args:            list[str],
        *,
        timeout_s:       Optional[float]   = None,
        retries:         int               = 0,
        env:             Optional[dict]    = None,
        cwd:             Optional[str]     = None,
        stdin_data:      Optional[str]     = None,
        expected_codes:  tuple[int, ...]   = (0,),
        capture_stderr:  bool              = True,
        binary_override: Optional[str]     = None,
    ) -> SubprocessResult:
        """
        Execute the tool binary with given args.
        Returns SubprocessResult — never raises.
        """
        binary = self.resolve_binary(binary_override)
        if not binary:
            return SubprocessResult(
                stderr=f"Binary '{self.BINARY}' not found",
                returncode=127,
            )

        cmd = [binary] + args
        timeout = timeout_s or float(getattr(self, "timeout", self.TIMEOUT))

        logger.debug("%s exec: %s", self.NAME, " ".join(cmd[:6]))

        return run_subprocess(
            cmd,
            timeout_s=timeout,
            retries=retries,
            env=env,
            cwd=cwd,
            stdin_data=stdin_data,
            expected_codes=expected_codes,
            capture_stderr=capture_stderr,
        )

    # ── Convenience wrappers ──────────────────────────────────────────────────

    def exec_json(self, args: list[str], **kwargs) -> SubprocessResult:
        """Execute tool and expect JSON output. Adds json-specific args if needed."""
        return self.exec(args, **kwargs)

    def exec_xml(self, args: list[str], **kwargs) -> SubprocessResult:
        """Execute tool and expect XML output."""
        return self.exec(args, **kwargs)
