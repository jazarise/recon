"""
ReconX — ValidationMixin.
Reusable target validation for every tool. Zero duplication across the codebase.
"""
from __future__ import annotations
import ipaddress
import re
from typing import Literal
from urllib.parse import urlparse

# Precompiled for performance
_RE_HOSTNAME = re.compile(
    r"^(?:[a-zA-Z0-9](?:[a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$"
)
_RE_CIDR = re.compile(r"^(\d{1,3}\.){3}\d{1,3}/\d{1,2}$")

TargetType = Literal["ip", "domain", "url", "cidr", "unknown"]


class ValidationMixin:
    """
    Mixin providing target and input validation.
    Mix into BaseTool subclasses — no __init__ required.
    """

    # ── Target classification ─────────────────────────────────────────────────

    @staticmethod
    def classify_target(target: str) -> TargetType:
        target = target.strip()
        # URL
        if target.startswith(("http://", "https://")):
            p = urlparse(target)
            return "url" if p.netloc else "unknown"
        # IP
        try:
            ipaddress.ip_address(target)
            return "ip"
        except ValueError:
            pass
        # CIDR
        if _RE_CIDR.match(target):
            try:
                ipaddress.ip_network(target, strict=False)
                return "cidr"
            except ValueError:
                pass
        # Hostname / domain
        if _RE_HOSTNAME.match(target):
            return "domain"
        return "unknown"

    # ── Validators ────────────────────────────────────────────────────────────

    @staticmethod
    def is_valid_ip(value: str) -> bool:
        try:
            ipaddress.ip_address(value.strip())
            return True
        except ValueError:
            return False

    @staticmethod
    def is_valid_domain(value: str) -> bool:
        return bool(_RE_HOSTNAME.match(value.strip()))

    @staticmethod
    def is_valid_url(value: str) -> bool:
        try:
            p = urlparse(value.strip())
            return p.scheme in ("http", "https") and bool(p.netloc)
        except Exception:
            return False

    @staticmethod
    def is_valid_cidr(value: str) -> bool:
        try:
            ipaddress.ip_network(value.strip(), strict=False)
            return True
        except ValueError:
            return False

    def is_valid_target(self, target: str) -> bool:
        """Accept IP, domain, CIDR, or URL."""
        t = self.classify_target(target)
        return t in ("ip", "domain", "cidr", "url")

    # ── Normalizers ───────────────────────────────────────────────────────────

    @staticmethod
    def strip_scheme(target: str) -> str:
        """'https://example.com/path' → 'example.com'"""
        p = urlparse(target)
        return p.netloc.split(":")[0] if p.netloc else target

    @staticmethod
    def ensure_scheme(url: str, default: str = "https") -> str:
        if not url.startswith(("http://", "https://")):
            return f"{default}://{url}"
        return url

    @staticmethod
    def expand_cidr(cidr: str) -> list[str]:
        """Return all host IPs in a /24 or smaller. Refuses larger ranges."""
        try:
            net = ipaddress.ip_network(cidr, strict=False)
            if net.num_addresses > 256:
                raise ValueError(f"CIDR {cidr} too large (>{net.num_addresses} hosts)")
            return [str(h) for h in net.hosts()]
        except ValueError as exc:
            raise ValueError(str(exc)) from exc
