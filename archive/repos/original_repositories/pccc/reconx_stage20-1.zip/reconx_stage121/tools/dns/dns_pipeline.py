"""
ReconX — DNS Intelligence Pipeline.

Full pipeline flow:
  Passive subdomains → Wildcard Detection → dnsx Validation
  → massdns Mass Resolution → shuffledns/puredns Bruteforce
  → IP Mapping → Final Dedup → Enriched ReconResult
"""
from __future__ import annotations
import logging
import time
from dataclasses import dataclass, field
from typing import Optional

from rich import box
from rich.columns import Columns
from rich.console import Console
from rich.live import Live
from rich.panel import Panel
from rich.rule import Rule
from rich.table import Table
from rich.text import Text

from .dnsx_tool       import DnsxTool
from .shuffledns_tool import ShuffleDNSTool
from .massdns_tool    import MassDNSTool
from .puredns_tool    import PureDNSTool
from .wildcard_detector import WildcardDetector, WildcardResult
from .resolver_manager  import ResolverManager
from ...models.findings    import ReconResult, DNSRecord
from ...models.tool_result import RunStatus, ToolRunResult
from ...config.settings    import DNS_CONFIG

logger = logging.getLogger("reconx.dns.pipeline")

_R  = "red"
_RB = "bold red"
_RD = "dim red"
_G  = "bold green"
_Y  = "yellow"
_D  = "dim"


@dataclass
class DNSPipelineStats:
    stage:        str
    tool:         str
    status:       RunStatus
    found:        int   = 0
    resolved:     int   = 0
    duration_s:   float = 0.0
    detail:       str   = ""


class DNSPipeline:
    """
    Orchestrates DNS validation, wildcard filtering,
    mass resolution, and brute-force expansion.
    """

    def __init__(
        self,
        console:   Optional[Console] = None,
        silent:    bool  = False,
        bruteforce: bool = False,    # enable subdomain brute-force
        threads:   int   = 50,
        resolvers: Optional[list[str]] = None,
    ):
        self.console    = console or Console()
        self.silent     = silent
        self.bruteforce = bruteforce
        self.threads    = threads
        self.resolver_mgr = ResolverManager.from_config(health_check=False)
        if resolvers:
            self.resolver_mgr = ResolverManager(resolvers, health_check=False)

    # ── Public ────────────────────────────────────────────────────────────────

    def run(self, target: str, result: ReconResult) -> list[DNSPipelineStats]:
        stats: list[DNSPipelineStats] = []
        t0    = time.perf_counter()

        self._header(target)

        # ── Step 1: Wildcard detection ────────────────────────────────────────
        self._section("Step 1 — Wildcard Detection")
        wc_stats, wildcard_results = self._step_wildcard(target, result)
        stats.extend(wc_stats)

        # ── Step 2: DNS validation with dnsx ─────────────────────────────────
        self._section("Step 2 — DNS Validation (dnsx)")
        val_stats = self._step_validate(target, result, wildcard_results)
        stats.extend(val_stats)

        # ── Step 3: Mass resolution with massdns ──────────────────────────────
        self._section("Step 3 — Mass Resolution (massdns)")
        mass_stats = self._step_mass_resolve(target, result)
        stats.extend(mass_stats)

        # ── Step 4: Brute-force (optional) ────────────────────────────────────
        if self.bruteforce:
            self._section("Step 4 — DNS Brute-Force")
            bf_stats = self._step_bruteforce(target, result)
            stats.extend(bf_stats)

        # ── Step 5: Final dedup ───────────────────────────────────────────────
        before = len(result.subdomains)
        result.subdomains   = sorted(set(s.lower() for s in result.subdomains if s))
        result.ip_addresses = sorted(set(result.ip_addresses))
        after = len(result.subdomains)

        self._print_summary(stats, time.perf_counter() - t0, before, after, target)
        return stats

    # ── Pipeline steps ────────────────────────────────────────────────────────

    def _step_wildcard(
        self, target: str, result: ReconResult
    ) -> tuple[list[DNSPipelineStats], dict[str, WildcardResult]]:
        t0 = time.perf_counter()

        # Check root + any second-level domains present in subdomain list
        domains_to_check = {target}
        for sub in result.subdomains[:50]:
            parts = sub.split(".")
            if len(parts) > 2:
                domains_to_check.add(".".join(parts[-2:]))

        detector = WildcardDetector(
            probe_count=DNS_CONFIG.get("wildcard_test_count", 3),
            threshold=DNS_CONFIG.get("wildcard_threshold", 0.8),
            resolvers=self.resolver_mgr.get_batch(3),
        )
        wc_results = detector.detect_batch(list(domains_to_check))
        dur = time.perf_counter() - t0

        wildcard_domains = [d for d, r in wc_results.items() if r.is_wildcard]

        if wildcard_domains:
            self._print(f"  [{_Y}]⚠  Wildcard detected on: {', '.join(wildcard_domains)}[/{_Y}]")
            # Filter subdomains from wildcard domains
            clean, filtered = detector.filter_wildcards(result.subdomains, wc_results)
            if filtered:
                self._print(f"  [{_D}]Filtered {len(filtered)} potential wildcard subdomains[/{_D}]")
                result.subdomains = clean
        else:
            self._print(f"  [{_G}]✔  No wildcards detected[/{_G}]")

        stat = DNSPipelineStats(
            stage="wildcard", tool="WildcardDetector",
            status=RunStatus.SUCCESS,
            found=len(wildcard_domains),
            duration_s=dur,
            detail=f"{len(wildcard_domains)} wildcard domain(s) detected",
        )
        return [stat], wc_results

    def _step_validate(
        self,
        target:          str,
        result:          ReconResult,
        wildcard_results: dict[str, WildcardResult],
    ) -> list[DNSPipelineStats]:
        if not result.subdomains:
            return []

        dnsx = DnsxTool()
        t0   = time.perf_counter()

        tr = dnsx.safe_run(
            target,
            subdomains=result.subdomains,
            threads=self.threads,
            resolvers=self.resolver_mgr.get_batch(10),
        )
        dur = time.perf_counter() - t0

        stat = DNSPipelineStats(
            stage="validate", tool="dnsx",
            status=tr.status, duration_s=dur,
        )

        if tr.ok:
            data = tr.data
            resolved = data.get("resolved", [])
            stat.resolved = len(resolved)
            stat.detail   = f"{len(resolved)}/{len(result.subdomains)} resolved"
            self._print(f"  [{_G}]✔  dnsx validated {len(resolved)} hosts[/{_G}]")

            # Update subdomains to only resolved ones
            result.subdomains = resolved

            # Enrich IP map
            for host, ips in data.get("ip_map", {}).items():
                result.ip_addresses.extend(ips)

            # Enrich DNS records
            for host, recs in data.get("record_map", {}).items():
                for rtype, vals in recs.items():
                    for v in (vals or []):
                        result.dns_records.append(
                            DNSRecord(record_type=rtype.upper(), value=v)
                        )
        elif tr.status == RunStatus.SKIPPED:
            stat.detail = "dnsx not installed — skipping validation"
            self._print(f"  [{_D}]○  dnsx not found — skipping validation[/{_D}]")
        else:
            stat.detail = tr.error.message if tr.error else "failed"
            self._print(f"  [{_RB}]✖  dnsx failed: {stat.detail}[/{_RB}]")

        return [stat]

    def _step_mass_resolve(self, target: str, result: ReconResult) -> list[DNSPipelineStats]:
        if not result.subdomains:
            return []

        massdns = MassDNSTool()
        t0      = time.perf_counter()

        tr = massdns.safe_run(
            target,
            subdomains=result.subdomains,
            resolvers=self.resolver_mgr.get_batch(20),
            threads=self.threads * 2,
        )
        dur = time.perf_counter() - t0

        stat = DNSPipelineStats(
            stage="mass_resolve", tool="massdns",
            status=tr.status, duration_s=dur,
        )

        if tr.ok:
            data     = tr.data
            resolved = data.get("resolved", [])
            stat.resolved = len(resolved)
            stat.detail   = f"{len(resolved)} resolutions"
            self._print(f"  [{_G}]✔  massdns resolved {len(resolved)} hosts[/{_G}]")

            # Merge new resolved hosts
            existing = set(result.subdomains)
            for host in resolved:
                if host not in existing:
                    result.subdomains.append(host)
                    existing.add(host)

            for ips in data.get("ip_map", {}).values():
                result.ip_addresses.extend(ips)

        elif tr.status == RunStatus.SKIPPED:
            stat.detail = "massdns not installed"
            self._print(f"  [{_D}]○  massdns not found — skipping[/{_D}]")
        else:
            stat.detail = tr.error.message if tr.error else "failed"
            self._print(f"  [{_Y}]⚠  massdns: {stat.detail}[/{_Y}]")

        return [stat]

    def _step_bruteforce(self, target: str, result: ReconResult) -> list[DNSPipelineStats]:
        # Try puredns first; fall back to shuffledns
        for ToolClass, tname in [(PureDNSTool, "puredns"), (ShuffleDNSTool, "shuffledns")]:
            tool = ToolClass()
            if not tool.is_available():
                continue

            t0 = time.perf_counter()
            tr = tool.safe_run(
                target,
                mode="bruteforce",
                threads=DNS_CONFIG.get("bruteforce_threads", 100),
                resolvers=self.resolver_mgr.get_batch(20),
            )
            dur = time.perf_counter() - t0

            stat = DNSPipelineStats(
                stage="bruteforce", tool=tname,
                status=tr.status, duration_s=dur,
            )

            if tr.ok:
                new_subs = tr.data.get("subdomains", [])
                existing = set(result.subdomains)
                added    = [s for s in new_subs if s not in existing]
                result.subdomains.extend(added)
                stat.found  = len(new_subs)
                stat.detail = f"{len(added)} new subdomains discovered"
                self._print(f"  [{_G}]✔  {tname} bruteforce: {len(added)} new subdomains[/{_G}]")
            elif tr.status == RunStatus.SKIPPED:
                stat.detail = f"{tname} not installed"
            else:
                stat.detail = tr.error.message if tr.error else "failed"
                self._print(f"  [{_Y}]⚠  {tname}: {stat.detail}[/{_Y}]")

            return [stat]

        self._print(f"  [{_D}]○  No brute-force tool available (puredns/shuffledns)[/{_D}]")
        return [DNSPipelineStats(stage="bruteforce", tool="none",
                                 status=RunStatus.SKIPPED,
                                 detail="No brute-force tool installed")]

    # ── Rich UI ───────────────────────────────────────────────────────────────

    def _header(self, target: str) -> None:
        if self.silent: return
        self.console.print()
        self.console.print(Panel(
            f"[{_RB}]DNS INTELLIGENCE PIPELINE[/{_RB}]\n"
            f"[{_D}]Target:[/{_D}] [{_R}]{target}[/{_R}]   "
            f"[{_D}]Threads:[/{_D}] [{_R}]{self.threads}[/{_R}]   "
            f"[{_D}]Bruteforce:[/{_D}] [{_R}]{'ON' if self.bruteforce else 'OFF'}[/{_R}]",
            border_style=_R, padding=(0, 3),
        ))

    def _section(self, label: str) -> None:
        if not self.silent:
            self.console.print()
            self.console.print(Rule(f"[{_RD}]  {label}  [/{_RD}]", style=_R))

    def _print(self, msg: str) -> None:
        if not self.silent:
            self.console.print(msg)

    def _print_summary(
        self,
        stats:    list[DNSPipelineStats],
        total_t:  float,
        before:   int,
        after:    int,
        target:   str,
    ) -> None:
        if self.silent: return
        self.console.print()
        self.console.print(Rule(f"[{_RB}]  DNS PIPELINE COMPLETE  [/{_RB}]", style=_R))
        self.console.print()

        ok   = sum(1 for s in stats if s.status == RunStatus.SUCCESS)
        skip = sum(1 for s in stats if s.status == RunStatus.SKIPPED)
        total_resolved = sum(s.resolved for s in stats)

        self.console.print(Columns([
            Panel(f"[{_RB}]{after}[/{_RB}]\n[{_D}]VALID HOSTS[/{_D}]",
                  border_style=_R,   padding=(0,3), expand=True),
            Panel(f"[{_RB}]{after - (before - after) if after > before else before - after}[/{_RB}]\n[{_D}]DELTA[/{_D}]",
                  border_style=_RD,  padding=(0,3), expand=True),
            Panel(f"[{_G}]{ok}[/{_G}]\n[{_D}]STEPS OK[/{_D}]",
                  border_style="green", padding=(0,3), expand=True),
            Panel(f"[{_D}]{skip}[/{_D}]\n[{_D}]SKIPPED[/{_D}]",
                  border_style="dim", padding=(0,3), expand=True),
            Panel(f"[white]{total_t:.1f}s[/white]\n[{_D}]TIME[/{_D}]",
                  border_style=_RD,  padding=(0,3), expand=True),
        ], equal=True, expand=True))

        t = Table(box=box.SIMPLE_HEAD, show_edge=False,
                  border_style=_RD, header_style=_RB, padding=(0,2))
        t.add_column("STEP",   style=_R, width=14)
        t.add_column("TOOL",   style=_D, width=16)
        t.add_column("STATUS",           width=12)
        t.add_column("FOUND",  style=_D, width=8)
        t.add_column("TIME",   style=_D, width=7)
        t.add_column("DETAIL", style=_D)
        sc = {RunStatus.SUCCESS:"bold green", RunStatus.SKIPPED:"dim",
              RunStatus.FAILED:"bold red", RunStatus.TIMEOUT:"yellow"}
        for s in stats:
            t.add_row(
                s.stage, s.tool,
                Text(s.status.value.upper(), style=sc.get(s.status,"white")),
                str(s.found or s.resolved or "—"),
                f"{s.duration_s:.1f}s",
                s.detail,
            )
        self.console.print(t)
        self.console.print()
