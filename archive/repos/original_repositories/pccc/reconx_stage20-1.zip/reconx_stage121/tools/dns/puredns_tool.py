"""
ReconX — puredns DNS brute-force & resolver validation tool.
Combines massdns speed with wildcard detection and trusted resolver validation.
Best tool for large-scale accurate DNS brute-force.
"""
from __future__ import annotations
import os
import tempfile
import time
from pathlib import Path
from typing import Optional

from ..base import BaseTool
from ...config.settings import DNS_CONFIG, DNS_MINI_WORDLIST
from ...models.tool_result import ParsedFinding, RunStatus, ToolRunResult


class PureDNSTool(BaseTool):
    NAME         = "puredns"
    BINARY       = "puredns"
    CATEGORY     = "dns"
    STAGE        = 3
    PRIORITY     = 15
    PASSIVE      = False
    TIMEOUT      = 120
    DEPENDENCIES: list[str] = []
    INSTALL_CMD  = "go install github.com/d3mondev/puredns/v2@latest"

    def run(
        self,
        target: str,
        *,
        mode:       str             = "bruteforce",   # "bruteforce" | "resolve"
        wordlist:   Optional[str]   = None,
        subdomains: Optional[list[str]] = None,       # for resolve mode
        resolvers:  Optional[list[str]] = None,
        threads:    int             = 100,
        wildcard_tests: int         = 3,
        **kwargs,
    ) -> ToolRunResult:
        if s := self.skip_if_unavailable(): return s
        if self.classify_target(target) != "domain":
            return ToolRunResult.invalid_target(self.NAME, target, "Requires a domain.")

        tmp_wordlist = tmp_subdomains = tmp_resolvers = None
        t0 = time.perf_counter()

        try:
            resolver_list = resolvers or DNS_CONFIG.get("public_resolvers", ["8.8.8.8"])
            with tempfile.NamedTemporaryFile(mode="w", suffix=".txt",
                                             delete=False) as rf:
                rf.write("\n".join(resolver_list))
                tmp_resolvers = rf.name

            if mode == "bruteforce":
                wl_path = wordlist or DNS_CONFIG.get("wordlist_path", "")
                if wl_path and Path(wl_path).exists():
                    wl_arg = wl_path
                else:
                    with tempfile.NamedTemporaryFile(mode="w", suffix=".txt",
                                                     delete=False) as wf:
                        wf.write("\n".join(DNS_MINI_WORDLIST))
                        tmp_wordlist = wf.name
                    wl_arg = tmp_wordlist

                args = [
                    "bruteforce", wl_arg, target,
                    "-r", tmp_resolvers,
                    "--threads", str(threads),
                    "--wildcard-tests", str(wildcard_tests),
                    "-q",
                ]

            elif mode == "resolve" and subdomains:
                with tempfile.NamedTemporaryFile(mode="w", suffix=".txt",
                                                 delete=False) as sf:
                    sf.write("\n".join(subdomains))
                    tmp_subdomains = sf.name

                args = [
                    "resolve", tmp_subdomains,
                    "-r", tmp_resolvers,
                    "--threads", str(threads),
                    "--wildcard-tests", str(wildcard_tests),
                    "-q",
                ]
            else:
                return self.fail("invalid_mode",
                                 f"Mode must be 'bruteforce' or 'resolve' with subdomains. Got: {mode}")

            res = self.exec(args, timeout_s=float(self.timeout),
                            expected_codes=(0, 1))

        finally:
            for p in (tmp_wordlist, tmp_subdomains, tmp_resolvers):
                if p and os.path.exists(p): os.unlink(p)

        dur = time.perf_counter() - t0

        if res.timed_out:
            return ToolRunResult.timeout(self.NAME, dur, self.timeout)
        if res.returncode == 127:
            return ToolRunResult.skipped(self.NAME, res.stderr)

        data     = self.parse_output(res.stdout, root=target)
        findings = self._findings_from_list(data["subdomains"], "subdomain",
                                             tool="puredns", mode=mode)

        r = self.build_result(data, findings, stdout=res.stdout,
                              duration_s=dur, returncode=res.returncode)
        if not data["subdomains"]:
            r.status = RunStatus.NO_OUTPUT
        return r

    def parse_output(self, raw: str, root: str = "", **kwargs) -> dict:
        if not raw.strip():
            return {"subdomains": [], "count": 0}

        seen: set[str] = set()
        subs: list[str] = []
        for line in self.parse_lines_output(raw):
            sub = self.clean(line).lower().strip(".")
            if not sub or "." not in sub:
                continue
            if root and not sub.endswith(root.lower()):
                continue
            if sub not in seen:
                seen.add(sub)
                subs.append(sub)

        return {"subdomains": sorted(subs), "count": len(subs)}
