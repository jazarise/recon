"""
ReconX — Wildcard DNS Detector.

A wildcard domain (*.example.com resolves to something) inflates subdomain
lists with thousands of fake "live" hosts. This module detects wildcards
before mass-resolution so we can filter them out properly.

Algorithm:
  1. Generate N random 32-char hex subdomains under the domain
  2. Resolve each via multiple resolvers
  3. If ≥ threshold fraction resolve to the SAME IP(s) → wildcard detected
  4. Store the wildcard IPs; downstream tools filter any result matching them
"""
from __future__ import annotations
import hashlib
import logging
import os
import random
import socket
import string
import time
from dataclasses import dataclass, field
from typing import Optional

logger = logging.getLogger("reconx.dns.wildcard")

try:
    import dns.resolver
    import dns.exception
    HAS_DNSPYTHON = True
except ImportError:
    HAS_DNSPYTHON = False


@dataclass
class WildcardResult:
    domain:          str
    is_wildcard:     bool
    wildcard_ips:    set[str]          = field(default_factory=set)
    wildcard_cnames: set[str]          = field(default_factory=set)
    confidence:      float             = 0.0   # 0.0–1.0
    probe_count:     int               = 0
    resolved_count:  int               = 0
    detection_time_s: float            = 0.0


class WildcardDetector:
    """
    Detect wildcard DNS configurations for a list of domains.
    Thread-safe — create once, call detect() from multiple threads.
    """

    def __init__(
        self,
        probe_count:  int   = 3,
        threshold:    float = 0.8,
        timeout:      float = 3.0,
        resolvers:    Optional[list[str]] = None,
    ):
        self.probe_count = probe_count
        self.threshold   = threshold
        self.timeout     = timeout
        self.resolvers   = resolvers or ["1.1.1.1", "8.8.8.8"]

    # ── Public ────────────────────────────────────────────────────────────────

    def detect(self, domain: str) -> WildcardResult:
        """Check whether *.domain is a wildcard DNS entry."""
        t0 = time.perf_counter()
        result = WildcardResult(domain=domain, is_wildcard=False)

        probes  = [self._random_label() + "." + domain for _ in range(self.probe_count)]
        all_ips: list[set[str]] = []

        for probe in probes:
            ips = self._resolve_a(probe)
            all_ips.append(ips)
            result.probe_count += 1
            if ips:
                result.resolved_count += 1

        result.detection_time_s = time.perf_counter() - t0

        if result.resolved_count == 0:
            return result  # nothing resolved → no wildcard

        # Find IP sets that appear in ≥ threshold of probes
        resolved_sets = [s for s in all_ips if s]
        if not resolved_sets:
            return result

        confidence = result.resolved_count / result.probe_count

        if confidence >= self.threshold:
            # Wildcard confirmed — collect the IPs that match
            result.is_wildcard  = True
            result.confidence   = confidence
            # Union of all wildcard IPs (usually the same set across probes)
            for ip_set in resolved_sets:
                result.wildcard_ips.update(ip_set)
            logger.info(
                "Wildcard detected: *.%s → %s (confidence=%.0f%%)",
                domain, result.wildcard_ips, confidence * 100,
            )
        else:
            result.confidence = confidence

        return result

    def detect_batch(self, domains: list[str]) -> dict[str, WildcardResult]:
        """
        Check multiple domains for wildcards in parallel.
        Returns {domain: WildcardResult}.
        """
        import concurrent.futures
        results: dict[str, WildcardResult] = {}

        with concurrent.futures.ThreadPoolExecutor(max_workers=10) as pool:
            futures = {pool.submit(self.detect, d): d for d in domains}
            for future in concurrent.futures.as_completed(futures):
                domain = futures[future]
                try:
                    results[domain] = future.result()
                except Exception as exc:
                    logger.debug("Wildcard check failed for %s: %s", domain, exc)
                    results[domain] = WildcardResult(domain=domain, is_wildcard=False)

        return results

    def filter_wildcards(
        self,
        subdomains: list[str],
        wildcard_results: dict[str, WildcardResult],
    ) -> tuple[list[str], list[str]]:
        """
        Split subdomains into (clean, filtered_out) based on wildcard results.
        A subdomain is filtered if its parent domain has a wildcard AND the
        resolved IP matches a wildcard IP (checked by caller in real usage).
        For now: filter subdomains whose direct parent domain is a wildcard.
        """
        wildcard_domains = {
            d for d, r in wildcard_results.items() if r.is_wildcard
        }
        clean:    list[str] = []
        filtered: list[str] = []

        for sub in subdomains:
            parts  = sub.split(".")
            parent = ".".join(parts[1:]) if len(parts) > 2 else sub

            if parent in wildcard_domains or sub in wildcard_domains:
                filtered.append(sub)
            else:
                clean.append(sub)

        return clean, filtered

    # ── Internals ─────────────────────────────────────────────────────────────

    def _resolve_a(self, fqdn: str) -> set[str]:
        """Resolve A records for fqdn. Returns set of IPs (empty if NXDOMAIN)."""
        if HAS_DNSPYTHON:
            return self._resolve_dnspython(fqdn)
        return self._resolve_socket(fqdn)

    def _resolve_dnspython(self, fqdn: str) -> set[str]:
        try:
            resolver = dns.resolver.Resolver()
            resolver.nameservers = [random.choice(self.resolvers)]
            resolver.lifetime    = self.timeout
            answers = resolver.resolve(fqdn, "A")
            return {str(r) for r in answers}
        except (dns.exception.NXDOMAIN, dns.exception.NoAnswer):
            return set()
        except Exception:
            return set()

    def _resolve_socket(self, fqdn: str) -> set[str]:
        try:
            infos = socket.getaddrinfo(fqdn, None, socket.AF_INET,
                                        socket.SOCK_STREAM, 0,
                                        socket.AI_NUMERICSERV)
            return {info[4][0] for info in infos}
        except Exception:
            return set()

    @staticmethod
    def _random_label(length: int = 16) -> str:
        """Generate a random hex-like label unlikely to exist."""
        return "".join(random.choices(string.ascii_lowercase + string.digits, k=length))
