"""
ReconX — DNS Resolver Manager.

Maintains a thread-safe pool of DNS resolvers with:
  - health checking (removes dead resolvers)
  - round-robin + random rotation
  - concurrency-safe access
  - fallback to Google/Cloudflare if pool exhausted
  - custom resolver file support
"""
from __future__ import annotations
import logging
import random
import socket
import threading
import time
from pathlib import Path
from typing import Optional

logger = logging.getLogger("reconx.dns.resolver_manager")

_FALLBACK_RESOLVERS = ["1.1.1.1", "8.8.8.8", "9.9.9.9", "8.8.4.4", "1.0.0.1"]
_HEALTH_CHECK_DOMAIN = "a.root-servers.net"


class ResolverManager:
    """
    Thread-safe DNS resolver pool.

    Usage:
        mgr = ResolverManager.from_config()
        resolver = mgr.get()   # get one resolver IP
        mgr.mark_bad(resolver) # flag as failed
    """

    def __init__(self, resolvers: list[str], health_check: bool = True):
        self._all:   list[str] = list(dict.fromkeys(r.strip() for r in resolvers if r.strip()))
        self._good:  list[str] = list(self._all)
        self._bad:   set[str]  = set()
        self._lock   = threading.Lock()
        self._index  = 0

        if not self._good:
            logger.warning("No resolvers provided; using fallback set")
            self._good = list(_FALLBACK_RESOLVERS)
            self._all  = list(_FALLBACK_RESOLVERS)

        if health_check:
            self._health_check_all()

    # ── Factory methods ───────────────────────────────────────────────────────

    @classmethod
    def from_config(cls, health_check: bool = False) -> "ResolverManager":
        """Build from settings.py DNS_CONFIG."""
        from ...config.settings import DNS_CONFIG
        import os

        resolvers: list[str] = []

        # 1. Custom resolvers from config
        resolvers.extend(DNS_CONFIG.get("custom_resolvers", []))

        # 2. Resolver file
        rf = DNS_CONFIG.get("resolver_file", "") or os.environ.get("RECONX_RESOLVER_FILE", "")
        if rf:
            resolvers.extend(cls._load_file(rf))

        # 3. Built-in public resolvers
        resolvers.extend(DNS_CONFIG.get("public_resolvers", _FALLBACK_RESOLVERS))

        return cls(resolvers, health_check=health_check)

    @classmethod
    def from_file(cls, path: str, health_check: bool = False) -> "ResolverManager":
        resolvers = cls._load_file(path)
        if not resolvers:
            logger.warning("Resolver file empty or unreadable: %s; using fallbacks", path)
            resolvers = list(_FALLBACK_RESOLVERS)
        return cls(resolvers, health_check=health_check)

    @classmethod
    def minimal(cls) -> "ResolverManager":
        """Minimal pool — Cloudflare + Google only. No health check."""
        return cls(list(_FALLBACK_RESOLVERS), health_check=False)

    # ── Access ────────────────────────────────────────────────────────────────

    def get(self) -> str:
        """Return the next resolver via round-robin. Thread-safe."""
        with self._lock:
            pool = self._good if self._good else list(_FALLBACK_RESOLVERS)
            ip   = pool[self._index % len(pool)]
            self._index += 1
            return ip

    def get_random(self) -> str:
        """Return a random resolver from the pool."""
        with self._lock:
            pool = self._good if self._good else list(_FALLBACK_RESOLVERS)
            return random.choice(pool)

    def get_batch(self, n: int) -> list[str]:
        """Return n resolvers (with repetition if pool is smaller than n)."""
        pool = self._good if self._good else list(_FALLBACK_RESOLVERS)
        return [pool[i % len(pool)] for i in range(n)]

    def mark_bad(self, resolver: str) -> None:
        """Remove a resolver from the good pool after repeated failures."""
        with self._lock:
            if resolver in self._good:
                self._good.remove(resolver)
                self._bad.add(resolver)
                logger.debug("Resolver marked bad: %s (%d remaining)", resolver, len(self._good))
            if not self._good:
                # Never go empty
                logger.warning("All resolvers marked bad — restoring fallbacks")
                self._good = list(_FALLBACK_RESOLVERS)

    def restore_all(self) -> None:
        """Restore all resolvers (e.g. after a pause)."""
        with self._lock:
            self._good = list(self._all) or list(_FALLBACK_RESOLVERS)
            self._bad.clear()

    @property
    def count(self) -> int:
        return len(self._good)

    @property
    def all_resolvers(self) -> list[str]:
        return list(self._all)

    # ── Health check ──────────────────────────────────────────────────────────

    def _health_check_all(self) -> None:
        """Remove resolvers that fail a basic DNS query. Fast parallel check."""
        logger.debug("Health-checking %d resolvers…", len(self._good))
        good: list[str] = []

        def check(ip: str) -> bool:
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                sock.settimeout(2.0)
                # Minimal DNS query for A record of a.root-servers.net
                query = (
                    b"\xaa\xbb"     # transaction ID
                    b"\x01\x00"     # flags: standard query
                    b"\x00\x01"     # QDCOUNT = 1
                    b"\x00\x00\x00\x00\x00\x00"  # ANCOUNT, NSCOUNT, ARCOUNT
                    b"\x01a\x0croot-servers\x03net\x00"  # qname
                    b"\x00\x01\x00\x01"           # QTYPE=A, QCLASS=IN
                )
                sock.sendto(query, (ip, 53))
                data, _ = sock.recvfrom(512)
                sock.close()
                return len(data) > 12  # any valid DNS response
            except Exception:
                return False

        import concurrent.futures
        with concurrent.futures.ThreadPoolExecutor(max_workers=20) as pool:
            results = {pool.submit(check, ip): ip for ip in self._good}
            for future in concurrent.futures.as_completed(results):
                ip = results[future]
                if future.result():
                    good.append(ip)

        if good:
            logger.debug("Health check: %d/%d resolvers alive", len(good), len(self._good))
            self._good = good
        else:
            logger.warning("All resolvers failed health check; keeping original set")

    # ── File loader ───────────────────────────────────────────────────────────

    @staticmethod
    def _load_file(path: str) -> list[str]:
        try:
            lines = Path(path).read_text(encoding="utf-8").splitlines()
            return [l.strip() for l in lines if l.strip() and not l.startswith("#")]
        except Exception as exc:
            logger.debug("Could not read resolver file %s: %s", path, exc)
            return []

    def __repr__(self) -> str:
        return f"ResolverManager(good={len(self._good)}, bad={len(self._bad)})"
