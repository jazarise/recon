"""
ReconX — massdns mass DNS resolver.
Extremely fast bulk DNS resolution — resolves millions of hostnames/minute.
Parses simple-text output format for reliability.
"""
from __future__ import annotations
import os
import tempfile
import time
from typing import Optional

from ..base import BaseTool
from ...config.settings import DNS_CONFIG
from ...models.tool_result import ParsedFinding, RunStatus, ToolRunResult


class MassDNSTool(BaseTool):
    NAME         = "massdns"
    BINARY       = "massdns"
    CATEGORY     = "dns"
    STAGE        = 3
    PRIORITY     = 20
    PASSIVE      = False
    TIMEOUT      = 120
    DEPENDENCIES: list[str] = []
    INSTALL_CMD  = "git clone https://github.com/blechschmidt/massdns && cd massdns && make"

    def run(
        self,
        target:    str,
        *,
        subdomains: list[str],
        resolvers: Optional[list[str]] = None,
        threads:   int = 100,
        record_type: str = "A",
        **kwargs,
    ) -> ToolRunResult:
        if s := self.skip_if_unavailable(): return s
        if not subdomains:
            return self.fail("no_input", "subdomains list is required for massdns.")

        resolver_list = resolvers or DNS_CONFIG.get("public_resolvers", ["8.8.8.8"])
        tmp_input = tmp_resolvers = tmp_output = None
        t0 = time.perf_counter()

        try:
            with tempfile.NamedTemporaryFile(mode="w", suffix=".txt",
                                             delete=False) as f:
                f.write("\n".join(subdomains))
                tmp_input = f.name

            with tempfile.NamedTemporaryFile(mode="w", suffix=".txt",
                                             delete=False) as rf:
                rf.write("\n".join(resolver_list))
                tmp_resolvers = rf.name

            with tempfile.NamedTemporaryFile(suffix=".txt", delete=False) as of:
                tmp_output = of.name

            args = [
                "-r",   tmp_resolvers,
                "-o",   "S",              # simple output format
                "--output", tmp_output,
                "--type", record_type,
                "-q",                     # quiet
                "--threads", str(threads),
                tmp_input,
            ]

            res = self.exec(args, timeout_s=float(self.timeout),
                            expected_codes=(0, 1))

        finally:
            for p in (tmp_input, tmp_resolvers):
                if p and os.path.exists(p): os.unlink(p)

        dur = time.perf_counter() - t0

        if res.timed_out:
            if tmp_output: self._safe_unlink(tmp_output)
            return ToolRunResult.timeout(self.NAME, dur, self.timeout)
        if res.returncode == 127:
            if tmp_output: self._safe_unlink(tmp_output)
            return ToolRunResult.skipped(self.NAME, res.stderr)

        # Read output file
        output_text = ""
        try:
            if tmp_output and os.path.exists(tmp_output):
                with open(tmp_output, "r", encoding="utf-8", errors="replace") as f:
                    output_text = f.read()
        finally:
            self._safe_unlink(tmp_output)

        data     = self.parse_output(output_text or res.stdout)
        findings = self._make_findings(data)

        r = self.build_result(data, findings, stdout=output_text,
                              duration_s=dur, returncode=res.returncode)
        if not data["resolved"]:
            r.status = RunStatus.NO_OUTPUT
        return r

    def parse_output(self, raw: str, **kwargs) -> dict:
        """
        Parse massdns simple output format:
          sub.example.com. A 1.2.3.4
          sub.example.com. CNAME target.example.com.
        """
        if not raw.strip():
            return {"resolved": [], "ip_map": {}, "cname_map": {}, "count": 0}

        ip_map:    dict[str, list[str]] = {}
        cname_map: dict[str, str]       = {}
        resolved:  list[str]            = []
        seen:      set[str]             = set()

        for line in self.parse_lines_output(raw):
            parts = line.split()
            if len(parts) < 3:
                continue
            fqdn     = parts[0].rstrip(".").lower()
            rtype    = parts[1].upper()
            rdata    = parts[2].rstrip(".")

            if not fqdn or fqdn in seen:
                continue

            if rtype == "A":
                ip_map.setdefault(fqdn, []).append(rdata)
                if fqdn not in seen:
                    seen.add(fqdn)
                    resolved.append(fqdn)
            elif rtype == "CNAME":
                cname_map[fqdn] = rdata
                if fqdn not in seen:
                    seen.add(fqdn)
                    resolved.append(fqdn)

        return {
            "resolved":  resolved,
            "ip_map":    ip_map,
            "cname_map": cname_map,
            "count":     len(resolved),
        }

    def _make_findings(self, data: dict) -> list[ParsedFinding]:
        findings = []
        for host in data["resolved"]:
            ips = data["ip_map"].get(host, [])
            findings.append(self._finding("subdomain", host,
                                           ips=",".join(ips),
                                           cname=data["cname_map"].get(host, "")))
        return findings

    @staticmethod
    def _safe_unlink(path: Optional[str]) -> None:
        if path:
            try: os.unlink(path)
            except Exception: pass
