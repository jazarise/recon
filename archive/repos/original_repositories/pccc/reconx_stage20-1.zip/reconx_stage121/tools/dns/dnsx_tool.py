"""
ReconX — dnsx DNS resolution & enrichment tool.
Fast multi-purpose DNS toolkit by ProjectDiscovery.
Validates subdomains, resolves A/AAAA/CNAME/MX/TXT/NS, detects wildcards.
"""
from __future__ import annotations
import os
import tempfile
import time
from typing import Optional

from ..base import BaseTool
from ...models.tool_result import ParsedFinding, RunStatus, ToolRunResult


class DnsxTool(BaseTool):
    NAME         = "dnsx"
    BINARY       = "dnsx"
    CATEGORY     = "dns"
    STAGE        = 3
    PRIORITY     = 5           # runs first in stage 3 — validates before nmap
    PASSIVE      = False
    TIMEOUT      = 90
    DEPENDENCIES: list[str] = []
    INSTALL_CMD  = "go install github.com/projectdiscovery/dnsx/cmd/dnsx@latest"

    def run(
        self,
        target:     str,
        *,
        subdomains: Optional[list[str]] = None,   # resolve a list
        record_types: list[str] = None,           # A, AAAA, CNAME, MX, TXT, NS
        threads:    int  = 50,
        resp_only:  bool = True,                  # print only resolved hosts
        wildcard_filter: bool = True,
        resolvers:  Optional[list[str]] = None,
        **kwargs,
    ) -> ToolRunResult:
        if s := self.skip_if_unavailable(): return s

        targets = subdomains or [target]
        if not targets:
            return self.fail("no_targets", "No subdomains or target provided.")

        record_types = record_types or ["a"]

        tmp_input = tmp_resolver = None
        t0 = time.perf_counter()

        try:
            # Write targets to temp file
            with tempfile.NamedTemporaryFile(mode="w", suffix=".txt",
                                             delete=False, encoding="utf-8") as f:
                f.write("\n".join(targets))
                tmp_input = f.name

            args = [
                "-l",      tmp_input,
                "-t",      str(threads),
                "-json",
                "-silent",
            ]

            for rt in record_types:
                args += [f"-{rt.lower()}"]

            if resp_only:
                args.append("-resp-only")
            if wildcard_filter:
                args.append("-wd")
                args.append(target)    # wildcard domain to filter against

            # Custom resolvers
            if resolvers:
                with tempfile.NamedTemporaryFile(mode="w", suffix=".txt",
                                                 delete=False) as rf:
                    rf.write("\n".join(resolvers))
                    tmp_resolver = rf.name
                args += ["-r", tmp_resolver]

            res = self.exec(args, timeout_s=float(self.timeout),
                            expected_codes=(0, 1))

        finally:
            for p in (tmp_input, tmp_resolver):
                if p and os.path.exists(p):
                    os.unlink(p)

        dur = time.perf_counter() - t0

        if res.timed_out:
            return ToolRunResult.timeout(self.NAME, dur, self.timeout)
        if res.returncode == 127:
            return ToolRunResult.skipped(self.NAME, res.stderr)

        data     = self.parse_output(res.stdout)
        findings = self._make_findings(data)

        r = self.build_result(data, findings, stdout=res.stdout,
                              duration_s=dur, returncode=res.returncode)
        if not data["resolved"]:
            r.status = RunStatus.NO_OUTPUT
        return r

    def parse_output(self, raw: str, **kwargs) -> dict:
        if not raw.strip():
            return {"resolved": [], "ip_map": {}, "record_map": {}, "count": 0}

        resolved:   list[str]        = []
        ip_map:     dict[str, list]  = {}
        record_map: dict[str, dict]  = {}
        seen:       set[str]         = set()

        for obj in self.parse_json_lines_output(raw):
            host = obj.get("host", "").lower().strip()
            if not host or host in seen:
                continue
            seen.add(host)
            resolved.append(host)

            ips = []
            for key in ("a", "aaaa"):
                for val in (obj.get(key) or []):
                    if val:
                        ips.append(val)
            ip_map[host] = ips

            record_map[host] = {
                "a":     obj.get("a",     []) or [],
                "aaaa":  obj.get("aaaa",  []) or [],
                "cname": obj.get("cname", []) or [],
                "mx":    obj.get("mx",    []) or [],
                "txt":   obj.get("txt",   []) or [],
                "ns":    obj.get("ns",    []) or [],
            }

        return {
            "resolved":   resolved,
            "ip_map":     ip_map,
            "record_map": record_map,
            "count":      len(resolved),
        }

    def _make_findings(self, data: dict) -> list[ParsedFinding]:
        findings = []
        for host in data["resolved"]:
            ips = data["ip_map"].get(host, [])
            findings.append(self._finding("subdomain", host,
                                           resolved=True,
                                           ips=",".join(ips)))
            for ip in ips:
                findings.append(self._finding("ip", ip, source_host=host))
        return findings
