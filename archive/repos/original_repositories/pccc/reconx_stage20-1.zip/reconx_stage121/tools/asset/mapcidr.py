"""
ReconX — mapcidr wrapper.

mapcidr performs mathematical operations on CIDR ranges:
expansion to individual IPs, aggregation, splitting, filtering,
and generating Nmap-compatible target lists. Essential for converting
ASN ranges into scannable IP lists.

Stage 2 — Infrastructure Mapping / Pre-Scan.
"""
from __future__ import annotations
import ipaddress
import re
import time
from typing import Optional

from ..base import BaseTool
from ...models.tool_result import ParsedFinding, RunStatus, ToolRunResult


class MapCIDRTool(BaseTool):

    NAME         = "mapcidr"
    BINARY       = "mapcidr"
    CATEGORY     = "asset"
    STAGE        = 2
    PRIORITY     = 28
    PASSIVE      = True
    TIMEOUT      = 60
    DEPENDENCIES: list[str] = []
    INSTALL_CMD  = "go install github.com/projectdiscovery/mapcidr/cmd/mapcidr@latest"

    # ── run ───────────────────────────────────────────────────────────────────

    def run(
        self,
        target: str,
        *,
        mode:        str            = "expand",    # "expand"|"aggregate"|"split"|"filter"
        split_count: int            = 0,
        filter_bogon: bool          = True,
        max_ips:     int            = 65536,       # safety cap for expansion
        cidr_list:   Optional[list[str]] = None,   # alternative to target string
        **kwargs,
    ) -> ToolRunResult:
        """
        Args:
            target:       Single CIDR (e.g. 192.168.0.0/16) or newline-list.
            mode:         'expand' → individual IPs; 'aggregate' → merge ranges;
                          'split' → subdivide; 'filter' → remove bogons.
            split_count:  Number of subnets to split into (mode=split only).
            filter_bogon: Automatically remove RFC1918/bogon ranges.
            max_ips:      Cap individual IP expansion (large /8s would OOM).
            cidr_list:    Pass a list of CIDRs directly instead of target string.
        """
        cidrs = cidr_list or [c.strip() for c in target.splitlines() if c.strip()]
        if not cidrs:
            return ToolRunResult.invalid_target(self.NAME, target, "No valid CIDRs found.")

        if filter_bogon:
            cidrs = [c for c in cidrs if not self._is_bogon(c)]

        t0 = time.perf_counter()

        # ── Binary path ───────────────────────────────────────────────────────
        if self.is_available():
            stdin_input = "\n".join(cidrs)
            args = ["-silent"]
            if mode == "aggregate":
                args.append("-aggregate")
            elif mode == "split" and split_count:
                args += ["-sbc", str(split_count)]
            elif mode == "filter":
                args.append("-filter-ipv6") if not kwargs.get("ipv6") else None
            # Default: expand (no flag needed)

            res = self.exec(args, stdin_data=stdin_input,
                            timeout_s=float(self.timeout), expected_codes=(0, 1))
            dur = time.perf_counter() - t0
            if res.timed_out:
                return ToolRunResult.timeout(self.NAME, dur, self.timeout)
            if res.returncode == 127:
                return ToolRunResult.skipped(self.NAME, res.stderr)

            data = self.parse_output(res.stdout, mode=mode)
            findings = self._build_findings(data, mode)
            r = self.build_result(data, findings, stdout=res.stdout,
                                  duration_s=dur, returncode=res.returncode)
            if not data.get("items"): r.status = RunStatus.NO_OUTPUT
            return r

        # ── Pure-Python fallback ──────────────────────────────────────────────
        self._log("info", "mapcidr binary not found — using Python ipaddress fallback")
        data, err = self._python_process(cidrs, mode, split_count, max_ips)
        dur = time.perf_counter() - t0

        if err:
            return self.fail("process_error", err, duration_s=dur)

        findings = self._build_findings(data, mode)
        r = self.build_result(data, findings, duration_s=dur, returncode=0)
        if not data.get("items"): r.status = RunStatus.NO_OUTPUT
        return r

    # ── parse_output ──────────────────────────────────────────────────────────

    def parse_output(self, raw: str, mode: str = "expand", **kwargs) -> dict:
        if not raw.strip():
            return {"items": [], "count": 0, "mode": mode}

        items: list[str] = []
        cidr_re = re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}(?:/\d{1,2})?\b")

        for line in raw.splitlines():
            line = line.strip()
            if not line:
                continue
            matches = cidr_re.findall(line)
            items.extend(matches if matches else [line])

        unique = list(dict.fromkeys(items))
        return {"items": unique, "count": len(unique), "mode": mode}

    # ── internal ──────────────────────────────────────────────────────────────

    @staticmethod
    def _is_bogon(cidr: str) -> bool:
        """Return True if CIDR is a private/bogon range."""
        _PRIVATE = [
            "10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16",
            "127.0.0.0/8", "169.254.0.0/16", "100.64.0.0/10",
            "0.0.0.0/8", "224.0.0.0/4", "240.0.0.0/4",
        ]
        try:
            net = ipaddress.ip_network(cidr, strict=False)
            return any(
                net.overlaps(ipaddress.ip_network(p)) for p in _PRIVATE
            )
        except ValueError:
            return False

    def _python_process(
        self, cidrs: list[str], mode: str, split_count: int, max_ips: int
    ) -> tuple[dict, str]:
        items: list[str] = []
        try:
            if mode == "aggregate":
                nets = []
                for c in cidrs:
                    try:
                        nets.append(ipaddress.ip_network(c, strict=False))
                    except ValueError:
                        pass
                collapsed = list(ipaddress.collapse_addresses(nets))
                items = [str(n) for n in collapsed]

            elif mode == "split" and split_count > 0:
                for cidr in cidrs:
                    try:
                        net    = ipaddress.ip_network(cidr, strict=False)
                        prefix = net.prefixlen + max(0, split_count.bit_length() - 1)
                        prefix = min(prefix, 32)
                        items.extend(str(s) for s in net.subnets(new_prefix=prefix))
                    except (ValueError, TypeError):
                        pass

            else:   # expand (default)
                for cidr in cidrs:
                    try:
                        net = ipaddress.ip_network(cidr, strict=False)
                        if net.num_addresses > max_ips:
                            self._log("warning",
                                      f"Skipping {cidr} — too large ({net.num_addresses} IPs). "
                                      f"Use binary for large ranges.")
                            items.append(cidr)   # keep as CIDR instead
                            continue
                        items.extend(str(ip) for ip in net.hosts())
                    except ValueError:
                        pass

        except Exception as e:
            return {"items": [], "count": 0, "mode": mode}, str(e)

        unique = list(dict.fromkeys(items))
        return {"items": unique, "count": len(unique), "mode": mode}, ""

    def _build_findings(self, data: dict, mode: str) -> list[ParsedFinding]:
        ftype = "ip" if mode == "expand" else "cidr_range"
        return [
            ParsedFinding(
                finding_type=ftype, value=item,
                source=self.NAME, confidence=1.0,
                metadata={"mode": mode},
            )
            for item in data.get("items", [])[:10000]   # cap findings
        ]
