"""
ReconX — github-subdomains tool wrapper.

Discovers subdomains and infrastructure assets leaked in public GitHub
repositories: code, READMEs, config files, CI/CD scripts, and comments.
Uses the GitHub Search API (token optional but heavily rate-limited without one).

Stage 1 — Passive OSINT / Asset Discovery.
"""
from __future__ import annotations
import json
import re
import ssl
import time
import urllib.error
import urllib.parse
import urllib.request
from typing import Optional

from ..base import BaseTool
from ...models.tool_result import ParsedFinding, RunStatus, ToolRunResult

# GitHub Code Search API
_GH_SEARCH_URL = "https://api.github.com/search/code?q={query}&per_page=100&page={page}"
_GH_HEADERS_BASE = {
    "Accept":     "application/vnd.github.v3+json",
    "User-Agent": "ReconX/2.0 (github-subdomains-recon)",
}


class GitHubSubdomainsTool(BaseTool):

    NAME         = "github-subdomains"
    BINARY       = "github-subdomains"          # optional Go binary
    CATEGORY     = "asset"
    STAGE        = 1
    PRIORITY     = 35
    PASSIVE      = True
    TIMEOUT      = 120
    DEPENDENCIES: list[str] = []
    INSTALL_CMD  = "go install github.com/gwen001/github-subdomains@latest"

    # ── run ───────────────────────────────────────────────────────────────────

    def run(
        self,
        target: str,
        *,
        token:      Optional[str] = None,
        raw_only:   bool          = False,
        max_pages:  int           = 5,
        **kwargs,
    ) -> ToolRunResult:
        """
        Args:
            target:    Target domain to search for in GitHub.
            token:     GitHub personal access token (removes rate limits).
                       Falls back to env var RECONX_GITHUB_TOKEN.
            raw_only:  Skip API fallback; only use binary if available.
            max_pages: Max GitHub search result pages to fetch (API fallback).
        """
        if self.classify_target(target) != "domain":
            return ToolRunResult.invalid_target(self.NAME, target, "Requires a domain.")

        api_token = token or self._env("RECONX_GITHUB_TOKEN")
        t0 = time.perf_counter()

        # ── Binary path ───────────────────────────────────────────────────────
        if self.is_available():
            args = ["-d", target, "-t", "20"]
            if api_token:
                args += ["-token", api_token]
            res = self.exec(args, timeout_s=float(self.timeout), expected_codes=(0, 1))
            dur = time.perf_counter() - t0
            if res.timed_out:
                return ToolRunResult.timeout(self.NAME, dur, self.timeout)
            data = self.parse_output(res.stdout, root=target)
            findings = self._build_findings(data)
            r = self.build_result(data, findings, stdout=res.stdout,
                                  duration_s=dur, returncode=res.returncode)
            if not data["subdomains"]: r.status = RunStatus.NO_OUTPUT
            return r

        if raw_only:
            return ToolRunResult.skipped(self.NAME, "Binary not found and raw_only=True")

        # ── Pure-Python GitHub API fallback ───────────────────────────────────
        self._log("info", "Binary not found — using GitHub API fallback")
        if not api_token:
            self._log("warning", "No RECONX_GITHUB_TOKEN set — rate limit: 10 req/min")

        subdomains, err = self._api_search(target, api_token, max_pages)
        dur = time.perf_counter() - t0

        if err and not subdomains:
            if "rate" in err.lower():
                return self.fail("rate_limited", err, duration_s=dur)
            return self.fail("api_error", err, duration_s=dur)

        data     = {"subdomains": sorted(set(subdomains)), "count": len(set(subdomains)),
                    "source": "github_api"}
        findings = self._build_findings(data)
        r = self.build_result(data, findings, duration_s=dur, returncode=0)
        if not data["subdomains"]: r.status = RunStatus.NO_OUTPUT
        return r

    # ── parse_output ──────────────────────────────────────────────────────────

    def parse_output(self, raw: str, root: str = "", **kwargs) -> dict:
        if not raw.strip():
            return {"subdomains": [], "count": 0, "source": "binary"}

        domain_re = re.compile(
            r"\b([a-zA-Z0-9](?:[a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?"
            r"(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?)*"
            r"\." + re.escape(root.lower()) + r")\b"
        ) if root else re.compile(
            r"\b([a-zA-Z0-9\-]+(?:\.[a-zA-Z0-9\-]+)+\.[a-zA-Z]{2,})\b"
        )

        seen: set[str] = set()
        subs: list[str] = []
        ansi_re = re.compile(r"\x1b\[[0-9;]*[A-Za-z]")

        for line in raw.splitlines():
            line = ansi_re.sub("", line).strip()
            if not line:
                continue
            for match in domain_re.findall(line):
                sub = match.lower().strip(".")
                if sub and sub not in seen and "." in sub:
                    seen.add(sub)
                    subs.append(sub)

        return {"subdomains": subs, "count": len(subs), "source": "binary"}

    # ── internal ──────────────────────────────────────────────────────────────

    def _api_search(
        self, domain: str, token: Optional[str], max_pages: int
    ) -> tuple[list[str], str]:
        """Search GitHub code for subdomain patterns using the REST API."""
        subdomains: list[str] = []
        error_msg   = ""

        # Search queries that typically find infrastructure
        queries = [
            f'"{domain}" extension:yaml',
            f'"{domain}" extension:json',
            f'"{domain}" extension:env',
            f'"{domain}" extension:conf',
        ]

        domain_re = re.compile(
            r"\b([a-zA-Z0-9](?:[a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?"
            r"(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?)*"
            r"\." + re.escape(domain.lower()) + r")\b"
        )

        headers = dict(_GH_HEADERS_BASE)
        if token:
            headers["Authorization"] = f"token {token}"

        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode    = ssl.CERT_NONE
        opener = urllib.request.build_opener(urllib.request.HTTPSHandler(context=ctx))

        for query in queries[:2]:   # limit to 2 queries to avoid rate limits
            for page in range(1, max_pages + 1):
                url = _GH_SEARCH_URL.format(
                    query=urllib.parse.quote(query), page=page
                )
                try:
                    req  = urllib.request.Request(url, headers=headers)
                    with opener.open(req, timeout=15) as resp:
                        body = json.loads(resp.read().decode("utf-8", errors="replace"))

                    items = body.get("items", [])
                    for item in items:
                        # Extract from file URL and any text content available
                        for text in [item.get("path", ""), item.get("name", ""),
                                     item.get("html_url", "")]:
                            for m in domain_re.findall(text):
                                subdomains.append(m.lower())

                    if len(items) < 100:
                        break   # no more pages for this query

                    time.sleep(1.5)   # respect rate limits

                except urllib.error.HTTPError as e:
                    if e.code in (403, 429):
                        error_msg = f"Rate limited (HTTP {e.code}). Add RECONX_GITHUB_TOKEN."
                    else:
                        error_msg = f"HTTP {e.code}: {e.reason}"
                    break
                except Exception as e:
                    error_msg = str(e)
                    break

        return list(dict.fromkeys(subdomains)), error_msg   # preserve order, dedup

    @staticmethod
    def _env(key: str) -> Optional[str]:
        import os
        return os.environ.get(key)

    def _build_findings(self, data: dict) -> list[ParsedFinding]:
        return [
            ParsedFinding(
                finding_type="subdomain", value=sub,
                source=self.NAME, confidence=0.75,
                metadata={"source": "github", "method": data.get("source", "binary")},
            )
            for sub in data.get("subdomains", [])
        ]
