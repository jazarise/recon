"""
ReconX — asnmap wrapper.

asnmap resolves ASN numbers, organisation names, or domains to their
announced BGP CIDR ranges. Enables infrastructure-level attack surface
mapping by identifying all IP space owned by a target organisation.

Stage 1 — Passive Infrastructure Discovery.
"""
from __future__ import annotations
import json
import re
import ssl
import time
import urllib.request
from ipaddress import ip_network
from typing import Optional

from ..base import BaseTool
from ...models.tool_result import ParsedFinding, RunStatus, ToolRunResult

# RIPE / Hurricane Electric API fallback
_ASN_API_RIPE   = "https://stat.ripe.net/data/announced-prefixes/data.json?resource={asn}"
_BGP_VIEW_API   = "https://api.bgpview.io/asn/{asn}/prefixes"
_DOMAIN_ASN_API = "https://api.bgpview.io/search?query_term={domain}"


class AsnmapTool(BaseTool):

    NAME         = "asnmap"
    BINARY       = "asnmap"
    CATEGORY     = "asset"
    STAGE        = 1
    PRIORITY     = 25
    PASSIVE      = True
    TIMEOUT      = 60
    DEPENDENCIES: list[str] = []
    INSTALL_CMD  = "go install github.com/projectdiscovery/asnmap/cmd/asnmap@latest"

    # ── run ───────────────────────────────────────────────────────────────────

    def run(
        self,
        target: str,
        *,
        output_format: str = "cidr",       # "cidr" | "json" | "text"
        ipv6:          bool = False,
        **kwargs,
    ) -> ToolRunResult:
        """
        Args:
            target:        ASN (AS12345), organisation name, domain, or IP.
            output_format: 'cidr' returns IP ranges; 'json' returns full data.
            ipv6:          Include IPv6 prefixes.
        """
        t0 = time.perf_counter()

        # ── Binary path ───────────────────────────────────────────────────────
        if self.is_available():
            args = ["-json", "-silent"]
            ttype = self.classify_target(target)

            if re.match(r"^AS\d+$", target, re.IGNORECASE):
                args += ["-asn", target]
            elif ttype == "domain":
                args += ["-domain", target]
            elif ttype in ("ip", "cidr"):
                args += ["-ip", target.split("/")[0]]
            else:
                args += ["-org", target]

            if ipv6:
                args.append("-v6")

            res = self.exec(args, timeout_s=float(self.timeout), expected_codes=(0, 1))
            dur = time.perf_counter() - t0
            if res.timed_out:
                return ToolRunResult.timeout(self.NAME, dur, self.timeout)
            if res.returncode == 127:
                return ToolRunResult.skipped(self.NAME, res.stderr)
            data = self.parse_output(res.stdout)
            findings = self._build_findings(data)
            r = self.build_result(data, findings, stdout=res.stdout,
                                  duration_s=dur, returncode=res.returncode)
            if not data["cidrs"]: r.status = RunStatus.NO_OUTPUT
            return r

        # ── Pure-Python BGPView API fallback ──────────────────────────────────
        self._log("info", "asnmap binary not found — using BGPView API fallback")
        data, err = self._bgpview_lookup(target)
        dur = time.perf_counter() - t0

        if err and not data["cidrs"]:
            return self.fail("api_error", err, duration_s=dur)

        findings = self._build_findings(data)
        r = self.build_result(data, findings, duration_s=dur, returncode=0)
        if not data["cidrs"]: r.status = RunStatus.NO_OUTPUT
        return r

    # ── parse_output ──────────────────────────────────────────────────────────

    def parse_output(self, raw: str, **kwargs) -> dict:
        """Parse asnmap JSON-lines output."""
        if not raw.strip():
            return self._empty()

        cidrs:  list[str] = []
        asns:   list[str] = []
        orgs:   list[str] = []

        cidr_re = re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}/\d{1,2}\b")
        asn_re  = re.compile(r"\bAS\d+\b", re.IGNORECASE)

        for line in raw.splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
                # asnmap JSON schema: {asn, org, country, cidr}
                if isinstance(obj, list):
                    for item in obj:
                        self._extract_json_entry(item, cidrs, asns, orgs)
                elif isinstance(obj, dict):
                    self._extract_json_entry(obj, cidrs, asns, orgs)
            except (json.JSONDecodeError, ValueError):
                # Fallback: regex extract
                for m in cidr_re.findall(line):
                    cidrs.append(m)
                for m in asn_re.findall(line):
                    asns.append(m.upper())

        return {
            "cidrs":    sorted(set(cidrs)),
            "asns":     sorted(set(asns)),
            "orgs":     sorted(set(orgs)),
            "ip_count": self._count_ips(cidrs),
            "count":    len(set(cidrs)),
        }

    # ── internal ──────────────────────────────────────────────────────────────

    @staticmethod
    def _extract_json_entry(
        obj: dict,
        cidrs: list, asns: list, orgs: list,
    ) -> None:
        if c := obj.get("cidr", obj.get("prefix", "")):
            cidrs.append(c)
        if a := obj.get("asn", ""):
            asns.append(f"AS{a}" if not str(a).upper().startswith("AS") else str(a))
        if o := obj.get("org", obj.get("description", obj.get("name", ""))):
            orgs.append(o)

    def _bgpview_lookup(self, target: str) -> tuple[dict, str]:
        """BGPView API fallback — resolves ASN, domain, or org."""
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode    = ssl.CERT_NONE
        opener = urllib.request.build_opener(urllib.request.HTTPSHandler(context=ctx))

        cidrs: list[str] = []
        asns:  list[str] = []
        orgs:  list[str] = []

        try:
            asn_num = None
            # Resolve domain → ASN first
            if not re.match(r"^AS\d+$", target, re.IGNORECASE):
                url = _DOMAIN_ASN_API.format(domain=urllib.parse.quote(target))
                req  = urllib.request.Request(url,
                           headers={"User-Agent": "ReconX/2.0 (asnmap-fallback)"})
                with opener.open(req, timeout=15) as resp:
                    body = json.loads(resp.read().decode())
                asn_results = (body.get("data", {}).get("asns") or
                               body.get("data", {}).get("ip_prefixes", []))
                if asn_results:
                    asn_num = str(asn_results[0].get("asn", "")).lstrip("ASas")
            else:
                asn_num = re.sub(r"[Aa][Ss]", "", target)

            if not asn_num:
                return self._empty(), f"Could not resolve ASN for: {target}"

            # Fetch prefixes for ASN
            url = _BGP_VIEW_API.format(asn=asn_num)
            req = urllib.request.Request(url,
                      headers={"User-Agent": "ReconX/2.0 (asnmap-fallback)"})
            with opener.open(req, timeout=15) as resp:
                body = json.loads(resp.read().decode())

            for prefix in body.get("data", {}).get("ipv4_prefixes", []):
                if p := prefix.get("prefix"):
                    cidrs.append(p)
                if a := prefix.get("asn", {}).get("asn"):
                    asns.append(f"AS{a}")
                if n := prefix.get("name", ""):
                    orgs.append(n)

            return {
                "cidrs":    sorted(set(cidrs)),
                "asns":     sorted(set(asns)),
                "orgs":     sorted(set(orgs)),
                "ip_count": self._count_ips(cidrs),
                "count":    len(set(cidrs)),
            }, ""

        except Exception as e:
            return self._empty(), str(e)

    @staticmethod
    def _count_ips(cidrs: list[str]) -> int:
        total = 0
        for c in cidrs:
            try:
                total += ip_network(c, strict=False).num_addresses
            except ValueError:
                pass
        return total

    @staticmethod
    def _empty() -> dict:
        return {"cidrs": [], "asns": [], "orgs": [], "ip_count": 0, "count": 0}

    def _build_findings(self, data: dict) -> list[ParsedFinding]:
        findings = []
        for cidr in data.get("cidrs", []):
            findings.append(ParsedFinding(
                finding_type="cidr_range", value=cidr,
                source=self.NAME, confidence=0.95,
                metadata={
                    "asns":     data.get("asns", []),
                    "orgs":     data.get("orgs", []),
                    "ip_count": data.get("ip_count", 0),
                },
            ))
        return findings
