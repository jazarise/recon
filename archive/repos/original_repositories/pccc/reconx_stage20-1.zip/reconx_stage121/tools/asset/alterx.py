"""
ReconX — alterx wrapper.

alterx generates smart subdomain permutations from a seed list using
configurable patterns and word substitution. Produces enriched subdomain
candidates for brute-force resolution — significantly more targeted than
pure wordlist approaches.

Stage 2 — Subdomain Enrichment / Permutation Generation.
"""
from __future__ import annotations
import re
import time
from typing import Optional

from ..base import BaseTool
from ...models.tool_result import ParsedFinding, RunStatus, ToolRunResult

# Default enrichment patterns if no config available
_DEFAULT_PATTERNS = [
    "{{sub}}-{{word}}",
    "{{word}}-{{sub}}",
    "{{sub}}.{{word}}",
    "{{word}}.{{sub}}",
    "{{sub}}{{word}}",
]

# Common permutation words for pure-Python fallback
_PERM_WORDS = [
    "dev", "stg", "stage", "staging", "prod", "production", "test", "uat",
    "qa", "api", "api2", "v1", "v2", "v3", "internal", "admin", "portal",
    "app", "apps", "web", "www", "www2", "cdn", "static", "assets", "media",
    "mail", "smtp", "imap", "vpn", "remote", "corp", "intranet", "extranet",
    "beta", "alpha", "legacy", "old", "new", "demo", "sandbox", "lab", "labs",
    "secure", "login", "auth", "sso", "oauth", "identity", "id", "accounts",
    "mgmt", "manage", "management", "dashboard", "panel", "console", "monitor",
    "status", "health", "metrics", "logs", "log", "report", "reports",
    "mobile", "m", "ios", "android", "ws", "wss", "mqtt", "stream",
    "backup", "bak", "db", "database", "sql", "elastic", "redis", "cache",
    "search", "git", "svn", "jenkins", "ci", "cd", "deploy", "k8s", "kube",
]


class AlterxTool(BaseTool):

    NAME         = "alterx"
    BINARY       = "alterx"
    CATEGORY     = "asset"
    STAGE        = 2
    PRIORITY     = 32
    PASSIVE      = True
    TIMEOUT      = 60
    DEPENDENCIES: list[str] = []
    INSTALL_CMD  = "go install github.com/projectdiscovery/alterx/cmd/alterx@latest"

    # ── run ───────────────────────────────────────────────────────────────────

    def run(
        self,
        target: str,
        *,
        subdomains:  Optional[list[str]] = None,
        patterns:    Optional[list[str]] = None,
        word_list:   Optional[list[str]] = None,
        limit:       int                 = 50000,
        enrich:      bool                = True,
        **kwargs,
    ) -> ToolRunResult:
        """
        Args:
            target:      Root domain (e.g. example.com).
            subdomains:  Known subdomains to generate permutations from.
                         If empty, generates from root domain only.
            patterns:    alterx pattern strings. Defaults to built-in patterns.
            word_list:   Additional words for permutation (augments built-ins).
            limit:       Max permutations to generate.
            enrich:      Use alterx's -enrich flag for smarter word extraction.
        """
        if self.classify_target(target) != "domain":
            return ToolRunResult.invalid_target(self.NAME, target, "Requires a domain.")

        seed_subs = subdomains or [target]
        t0 = time.perf_counter()

        # ── Binary path ───────────────────────────────────────────────────────
        if self.is_available():
            # Write seed subdomains to stdin
            stdin_input = "\n".join(seed_subs)
            args = ["-silent", "-limit", str(limit)]

            if enrich:
                args.append("-enrich")
            if patterns:
                for p in patterns:
                    args += ["-pattern", p]
            if word_list:
                for w in word_list:
                    args += ["-en", w]

            res = self.exec(args, stdin_data=stdin_input,
                            timeout_s=float(self.timeout), expected_codes=(0, 1))
            dur = time.perf_counter() - t0
            if res.timed_out:
                return ToolRunResult.timeout(self.NAME, dur, self.timeout)
            if res.returncode == 127:
                return ToolRunResult.skipped(self.NAME, res.stderr)

            data = self.parse_output(res.stdout, root=target)
            findings = self._build_findings(data)
            r = self.build_result(data, findings, stdout=res.stdout,
                                  duration_s=dur, returncode=res.returncode)
            if not data["permutations"]: r.status = RunStatus.NO_OUTPUT
            return r

        # ── Pure-Python permutation fallback ──────────────────────────────────
        self._log("info", "alterx binary not found — using Python permutation fallback")
        data = self._python_permute(seed_subs, target, word_list or [], limit)
        dur  = time.perf_counter() - t0

        findings = self._build_findings(data)
        r = self.build_result(data, findings, duration_s=dur, returncode=0)
        if not data["permutations"]: r.status = RunStatus.NO_OUTPUT
        return r

    # ── parse_output ──────────────────────────────────────────────────────────

    def parse_output(self, raw: str, root: str = "", **kwargs) -> dict:
        if not raw.strip():
            return {"permutations": [], "count": 0, "root": root}

        ansi_re = re.compile(r"\x1b\[[0-9;]*[A-Za-z]")
        domain_re = re.compile(
            r"\b([a-zA-Z0-9](?:[a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?"
            r"(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?)*"
            r"\." + re.escape(root.lower()) + r")\b"
        ) if root else re.compile(
            r"\b([a-zA-Z0-9\-]+(?:\.[a-zA-Z0-9\-]+)+\.[a-zA-Z]{2,})\b"
        )

        seen:  set[str] = set()
        perms: list[str] = []

        for line in raw.splitlines():
            line = ansi_re.sub("", line).strip()
            if not line:
                continue
            for m in domain_re.findall(line):
                sub = m.lower().strip(".")
                if sub and sub not in seen:
                    seen.add(sub)
                    perms.append(sub)

        return {"permutations": perms, "count": len(perms), "root": root}

    # ── internal ──────────────────────────────────────────────────────────────

    def _python_permute(
        self,
        seeds:     list[str],
        root:      str,
        extra_words: list[str],
        limit:     int,
    ) -> dict:
        """Generate permutations using _DEFAULT_PATTERNS without the binary."""
        words = list(dict.fromkeys(_PERM_WORDS + extra_words))
        perms: set[str] = set()
        root_lower = root.lower()

        for seed in seeds:
            # Extract the subdomain part (strip root domain)
            sub = seed.lower().removesuffix("." + root_lower).removesuffix(root_lower)
            if not sub or sub == seed.lower():
                sub = seed.lower().split(".")[0]

            for word in words:
                for pattern in _DEFAULT_PATTERNS:
                    candidate = (
                        pattern
                        .replace("{{sub}}", sub)
                        .replace("{{word}}", word)
                    )
                    fqdn = f"{candidate}.{root_lower}"
                    if self._valid_subdomain(fqdn):
                        perms.add(fqdn)
                    if len(perms) >= limit:
                        break
                if len(perms) >= limit:
                    break
            if len(perms) >= limit:
                break

        sorted_perms = sorted(perms)
        return {"permutations": sorted_perms, "count": len(sorted_perms), "root": root}

    @staticmethod
    def _valid_subdomain(fqdn: str) -> bool:
        parts = fqdn.rstrip(".").split(".")
        if len(parts) < 2:
            return False
        for part in parts:
            if not part or len(part) > 63:
                return False
            if not re.match(r"^[a-z0-9]([a-z0-9\-]*[a-z0-9])?$", part):
                return False
        return True

    def _build_findings(self, data: dict) -> list[ParsedFinding]:
        return [
            ParsedFinding(
                finding_type="subdomain_permutation", value=perm,
                source=self.NAME, confidence=0.5,   # permutations need DNS resolution to confirm
                metadata={"root": data.get("root", ""), "requires_resolution": True},
            )
            for perm in data.get("permutations", [])
        ]
