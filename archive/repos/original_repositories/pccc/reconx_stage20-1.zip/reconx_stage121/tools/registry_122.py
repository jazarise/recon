"""
ReconX — Tool Registry additions for Stage 12.2.

Call get_122_additions() to get the dict of new tool instances.
Merge with the Stage 12.1 registry from registry_121.py:

    from reconx.tools.registry_121 import get_tool_registry
    from reconx.tools.registry_122 import get_122_additions

    registry = {**get_tool_registry(), **get_122_additions()}
"""
from __future__ import annotations
import importlib
import logging
import types
from typing import Any

log = logging.getLogger("reconx.registry.122")


# ─────────────────────────────────────────────────────────────────────────────
# Stage 12.2 tool spec
# ─────────────────────────────────────────────────────────────────────────────

_STAGE122_SPEC: list[tuple[str, str, dict]] = [

    # ── Asset Discovery ───────────────────────────────────────────────────────
    ("GitHubSubdomainsTool", "tools.asset.github_subdomains", {}),
    ("AsnmapTool",           "tools.asset.asnmap",            {}),
    ("MapCIDRTool",          "tools.asset.mapcidr",           {}),
    ("AlterxTool",           "tools.asset.alterx",            {}),

    # ── Historical / URL ──────────────────────────────────────────────────────
    # Note: GauTool, WaybackurlsTool are already in Stage 12.1 registry
    # (tools/passive/). Katana, Hakrawler in tools/web/.
    # Only register new additions not already present.
    ("ParamSpiderTool",      "tools.param.paramspider",       {}),
    ("GospiderTool",         "tools.param.gospider",          {}),
    ("WaymoreTool",          "tools.param.waymore",           {}),

    # ── Re-registrations with canonical names used by guided_recon_122 ────────
    ("GauTool",              "tools.passive.gau",             {}),
    ("WaybackurlsTool",      "tools.passive.waybackurls",     {}),
    ("KatanaTool",           "tools.web.katana_tool",         {}),
    ("HakrawlerTool",        "tools.web.hakrawler_tool",      {}),
    ("ArjunTool",            "tools.api.arjun_tool",          {}),
]


# ─────────────────────────────────────────────────────────────────────────────
# Loader
# ─────────────────────────────────────────────────────────────────────────────

class _NullTool:
    def __init__(self, name: str, reason: str):
        self.NAME    = name
        self._reason = reason

    def is_available(self) -> bool:
        return False

    def run(self, target: str, **kwargs):
        from types import SimpleNamespace
        return SimpleNamespace(
            status="skipped", findings=[], error=f"{self.NAME}: {self._reason}"
        )


def get_122_additions(
    base_package: str = "reconx",
    config: dict | None = None,
) -> dict[str, Any]:
    """
    Load and instantiate all Stage 12.2 tools.

    Returns dict keyed by class name with tool instances.
    Missing tools are replaced with _NullTool stubs — never raises.
    """
    registry: dict[str, Any] = {}
    cfg = config or {}

    for class_name, module_rel, kwargs in _STAGE122_SPEC:
        full_module = f"{base_package}.{module_rel}"
        try:
            mod  = importlib.import_module(full_module)
            cls  = getattr(mod, class_name)
            inst = cls(**{**kwargs, **_filter_kwargs(cls, cfg)})
            registry[class_name] = inst
            log.debug(f"[122] Registered: {class_name}")
        except ImportError as e:
            # Try without package prefix (standalone execution)
            try:
                mod  = importlib.import_module(module_rel)
                cls  = getattr(mod, class_name)
                inst = cls(**{**kwargs, **_filter_kwargs(cls, cfg)})
                registry[class_name] = inst
                log.debug(f"[122] Registered (direct): {class_name}")
            except Exception as e2:
                log.warning(f"[122][IMPORT FAILED] {class_name}: {e} / {e2}")
                registry[class_name] = _NullTool(class_name, str(e))
        except Exception as e:
            log.error(f"[122][INIT FAILED] {class_name}: {e}")
            registry[class_name] = _NullTool(class_name, str(e))

    active = sum(1 for v in registry.values() if not isinstance(v, _NullTool))
    log.info(f"[122] Registry: {len(registry)} tools loaded ({active} active)")
    return registry


def get_full_registry(
    base_package: str = "reconx",
    config: dict | None = None,
) -> dict[str, Any]:
    """
    Return the complete merged registry (Stage 12.1 + 12.2).
    Use this as the single entry point for the WorkflowRunner.
    """
    try:
        from reconx.tools.registry_121 import get_tool_registry as get_121
    except ModuleNotFoundError:
        from tools.registry_121 import get_tool_registry as get_121

    base = get_121(base_package=base_package, config=config)
    additions = get_122_additions(base_package=base_package, config=config)
    merged = {**base, **additions}
    log.info(f"Full registry: {len(merged)} tools total")
    return merged


def _filter_kwargs(cls, cfg: dict) -> dict:
    import inspect
    try:
        sig    = inspect.signature(cls.__init__)
        params = set(sig.parameters.keys()) - {"self"}
        return {k: v for k, v in cfg.items() if k in params}
    except Exception:
        return {}
