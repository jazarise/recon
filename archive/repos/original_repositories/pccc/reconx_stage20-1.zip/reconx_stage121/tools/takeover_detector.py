"""
ReconX — Subdomain Takeover Detector.
Checks CNAME chains against known vulnerable service fingerprints.
Pure-Python (dnspython). No external binary needed.
"""
from __future__ import annotations
import logging
from typing import Optional

from ..models.findings import TakeoverCandidate

logger = logging.getLogger("reconx.tools.takeover")

# Service fingerprints: cname_pattern → {service, dangling_string, confidence}
# Based on EdOverflow/can-i-take-over-xyz and similar research
_FINGERPRINTS: list[dict] = [
    {"pattern": "github.io",         "service": "GitHub Pages",       "dangling": "There isn't a GitHub Pages site here", "confidence": "HIGH"},
    {"pattern": "herokuapp.com",     "service": "Heroku",             "dangling": "No such app",                          "confidence": "HIGH"},
    {"pattern": "s3.amazonaws.com",  "service": "AWS S3",             "dangling": "NoSuchBucket",                         "confidence": "HIGH"},
    {"pattern": "s3-website",        "service": "AWS S3 Website",     "dangling": "NoSuchBucket",                         "confidence": "HIGH"},
    {"pattern": "azurewebsites.net", "service": "Azure App Service",  "dangling": "404 Web Site not found",               "confidence": "HIGH"},
    {"pattern": "cloudapp.net",      "service": "Azure Cloud",        "dangling": "404",                                  "confidence": "MEDIUM"},
    {"pattern": "trafficmanager.net","service": "Azure Traffic Mgr",  "dangling": "404",                                  "confidence": "MEDIUM"},
    {"pattern": "netlify.app",       "service": "Netlify",            "dangling": "Not Found",                            "confidence": "HIGH"},
    {"pattern": "netlify.com",       "service": "Netlify",            "dangling": "Not Found",                            "confidence": "HIGH"},
    {"pattern": "pages.github.com",  "service": "GitHub Pages",       "dangling": "There isn't a GitHub Pages site here", "confidence": "HIGH"},
    {"pattern": "surge.sh",          "service": "Surge",              "dangling": "project not found",                    "confidence": "HIGH"},
    {"pattern": "bitbucket.io",      "service": "Bitbucket",          "dangling": "Repository not found",                 "confidence": "HIGH"},
    {"pattern": "fastly.net",        "service": "Fastly",             "dangling": "Fastly error: unknown domain",         "confidence": "HIGH"},
    {"pattern": "shopify.com",       "service": "Shopify",            "dangling": "Sorry, this shop is currently unavailable", "confidence": "HIGH"},
    {"pattern": "zendesk.com",       "service": "Zendesk",            "dangling": "Help Center Closed",                   "confidence": "HIGH"},
    {"pattern": "freshdesk.com",     "service": "Freshdesk",          "dangling": "There is no helpdesk here",            "confidence": "HIGH"},
    {"pattern": "ghost.io",          "service": "Ghost",              "dangling": "The thing you were looking for is no longer here", "confidence": "HIGH"},
    {"pattern": "readme.io",         "service": "Readme.io",          "dangling": "Project doesnt exist",                 "confidence": "HIGH"},
    {"pattern": "statuspage.io",     "service": "Statuspage",         "dangling": "Better luck next time",                "confidence": "HIGH"},
    {"pattern": "helpscoutdocs.com", "service": "Help Scout",         "dangling": "No settings were found for this company", "confidence": "HIGH"},
    {"pattern": "cargo.site",        "service": "Cargo",              "dangling": "404",                                  "confidence": "MEDIUM"},
    {"pattern": "strikingly.com",    "service": "Strikingly",         "dangling": "PAGE NOT FOUND",                       "confidence": "MEDIUM"},
    {"pattern": "webflow.io",        "service": "Webflow",            "dangling": "The page you are looking for doesn't exist", "confidence": "MEDIUM"},
    {"pattern": "fly.dev",           "service": "Fly.io",             "dangling": "404",                                  "confidence": "MEDIUM"},
    {"pattern": "vercel.app",        "service": "Vercel",             "dangling": "DEPLOYMENT_NOT_FOUND",                 "confidence": "HIGH"},
    {"pattern": "render.com",        "service": "Render",             "dangling": "No such app",                          "confidence": "HIGH"},
]


class TakeoverDetector:
    """Detect subdomains vulnerable to takeover via dangling CNAME records."""

    def __init__(self, timeout: float = 5.0):
        self.timeout = timeout
        self._has_dns = self._check_dns()

    @staticmethod
    def _check_dns() -> bool:
        try:
            import dns.resolver
            return True
        except ImportError:
            return False

    def detect(self, subdomains: list[str]) -> list[TakeoverCandidate]:
        if not self._has_dns:
            logger.warning("dnspython not available; skipping takeover detection.")
            return []

        candidates: list[TakeoverCandidate] = []
        for sub in subdomains:
            result = self._check_subdomain(sub)
            if result:
                candidates.append(result)
        return candidates

    def _check_subdomain(self, subdomain: str) -> Optional[TakeoverCandidate]:
        try:
            import dns.resolver
            import dns.exception

            resolver = dns.resolver.Resolver()
            resolver.lifetime = self.timeout

            # Follow CNAME chain
            cname_target = self._resolve_cname(resolver, subdomain)
            if not cname_target:
                return None

            # Check against fingerprints
            for fp in _FINGERPRINTS:
                if fp["pattern"] in cname_target:
                    # Check if the CNAME actually resolves (unresolvable = likely dangling)
                    resolves = self._resolves_to_ip(resolver, cname_target)
                    if not resolves:
                        return TakeoverCandidate(
                            subdomain=subdomain,
                            cname=cname_target,
                            service=fp["service"],
                            confidence=fp["confidence"],
                            detail=f"CNAME → {cname_target} does not resolve. "
                                   f"Service: {fp['service']}. "
                                   f"Expected error: \"{fp['dangling']}\"",
                        )
            return None

        except Exception as exc:
            logger.debug("Takeover check failed for %s: %s", subdomain, exc)
            return None

    @staticmethod
    def _resolve_cname(resolver, domain: str) -> Optional[str]:
        try:
            answers = resolver.resolve(domain, "CNAME")
            return str(answers[0].target).rstrip(".")
        except Exception:
            return None

    @staticmethod
    def _resolves_to_ip(resolver, domain: str) -> bool:
        try:
            resolver.resolve(domain, "A")
            return True
        except Exception:
            return False
