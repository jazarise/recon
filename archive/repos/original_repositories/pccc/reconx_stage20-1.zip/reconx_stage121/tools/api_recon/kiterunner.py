"""
ReconX — kiterunner (kr) wrapper.

Kiterunner is a context-aware API route discovery tool. Unlike directory
brute-forcers, it replays real API requests from built-in route wordlists
(from Swagger/OpenAPI specs) with proper headers, payloads, and methods.

Stage 3 — Active API Route Discovery.
"""
from __future__ import annotations
import re
import time
from typing import Optional

from ..base import BaseTool
from ...models.tool_result import ParsedFinding, RunStatus, ToolRunResult

# Built-in kiterunner route files (shipped with the tool)
_DEFAULT_ROUTES = "/usr/share/kiterunner/routes-large.kite"
_FALLBACK_ROUTES = "/tmp/kr_routes.kite"


class KiterunnerTool(BaseTool):

    NAME         = "kiterunner"
    BINARY       = "kr"
    CATEGORY     = "api_recon"
    STAGE        = 3
    PRIORITY     = 15
    PASSIVE      = False
    TIMEOUT      = 300
    DEPENDENCIES: list[str] = []
    INSTALL_CMD  = (
        "go install github.com/assetnote/kiterunner/cmd/kr@latest\n"
        "# Download routes: https://github.com/assetnote/kiterunner#wordlists"
    )

    # ── run ───────────────────────────────────────────────────────────────────

    def run(
        self,
        target: str,
        *,
        routes_file:   Optional[str]       = None,
        targets_file:  Optional[str]       = None,
        targets:       Optional[list[str]] = None,
        threads:       int                 = 20,
        rate_limit:    int                 = 0,
        timeout:       int                 = 3,
        fail_status:   Optional[list[int]] = None,
        headers:       Optional[dict]      = None,
        **kwargs,
    ) -> ToolRunResult:
        """
        Args:
            target:       Single URL to scan (e.g. https://api.example.com).
            routes_file:  Path to .kite routes wordlist.
            targets_file: File of target URLs (batch mode).
            targets:      List of target URLs.
            threads:      Concurrent request threads.
            rate_limit:   Requests per second (0 = unlimited).
            timeout:      HTTP request timeout in seconds.
            fail_status:  HTTP status codes to treat as non-findings.
            headers:      Extra request headers dict.
        """
        if s := self.skip_if_unavailable():
            return s

        url = self.ensure_scheme(target)
        routes = routes_file or (_DEFAULT_ROUTES if __import__("os").path.exists(_DEFAULT_ROUTES)
                                 else None)
        if not routes:
            return self.fail("missing_routes",
                             "No routes file found. Download from kiterunner releases.")

        fail_codes = fail_status or [400, 401, 403, 404, 429, 500, 502, 503]

        args = [
            "scan", url,
            "-w", routes,
            "-j",                          # JSON output
            "--timeout", str(timeout),
            "-x", str(threads),
            "--fail-status-codes",
            ",".join(str(c) for c in fail_codes),
        ]

        if targets_file:
            args[1] = f"file://{targets_file}"
        if targets:
            import tempfile
            tf = tempfile.NamedTemporaryFile(delete=False, suffix=".txt", mode="w")
            tf.write("\n".join(targets))
            tf.close()
            args[1] = f"file://{tf.name}"
        if rate_limit:
            args += ["-r", str(rate_limit)]
        if headers:
            for k, v in headers.items():
                args += ["-H", f"{k}: {v}"]

        t0  = time.perf_counter()
        res = self.exec(args, timeout_s=float(self.timeout), expected_codes=(0, 1))
        dur = time.perf_counter() - t0

        if res.timed_out:
            return ToolRunResult.timeout(self.NAME, dur, self.timeout)
        if res.returncode == 127:
            return ToolRunResult.skipped(self.NAME, res.stderr)

        data = self.parse_output(res.stdout)
        findings = self._build_findings(data)
        r = self.build_result(data, findings, stdout=res.stdout,
                              duration_s=dur, returncode=res.returncode)
        if not data["routes"]: r.status = RunStatus.NO_OUTPUT
        return r

    # ── parse_output ──────────────────────────────────────────────────────────

    def parse_output(self, raw: str, **kwargs) -> dict:
        """
        kiterunner -j output per line:
          {"timestamp":"...","status":200,"words":12,"lines":3,
           "content-length":234,"method":"GET","path":"/api/v1/users","url":"..."}
        """
        if not raw.strip():
            return {"routes": [], "count": 0}

        routes: list[dict] = []
        seen:   set[str]   = set()
        ansi_re = re.compile(r"\x1b\[[0-9;]*[A-Za-z]")

        for line in raw.splitlines():
            line = ansi_re.sub("", line).strip()
            if not line:
                continue
            try:
                import json
                obj = json.loads(line)
                key = f"{obj.get('method','')}{obj.get('url','')}"
                if key in seen:
                    continue
                seen.add(key)
                routes.append({
                    "url":     obj.get("url", ""),
                    "path":    obj.get("path", ""),
                    "method":  obj.get("method", "GET"),
                    "status":  obj.get("status", 0),
                    "length":  obj.get("content-length", 0),
                    "words":   obj.get("words", 0),
                })
            except Exception:
                # Fallback: parse human-readable kiterunner output
                # Format: [200] 234 GET /api/v1/users (example.com)
                m = re.match(r"\[(\d+)\]\s+\d+\s+(\w+)\s+(/\S+)", line)
                if m:
                    key = f"{m.group(2)}{m.group(3)}"
                    if key not in seen:
                        seen.add(key)
                        routes.append({
                            "url": "", "path": m.group(3),
                            "method": m.group(2), "status": int(m.group(1)),
                            "length": 0, "words": 0,
                        })

        return {"routes": routes, "count": len(routes)}

    # ── internal ──────────────────────────────────────────────────────────────

    def _build_findings(self, data: dict) -> list[ParsedFinding]:
        findings = []
        for r in data.get("routes", []):
            url = r.get("url") or r.get("path", "")
            findings.append(ParsedFinding(
                finding_type="api_endpoint", value=url,
                source=self.NAME, confidence=0.88,
                metadata={"method": r.get("method", ""), "status": r.get("status", 0),
                          "length": r.get("length", 0)},
            ))
        return findings
