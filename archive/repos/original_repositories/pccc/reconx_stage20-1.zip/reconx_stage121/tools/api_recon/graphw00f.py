"""
ReconX — graphw00f wrapper.

graphw00f detects and fingerprints GraphQL servers, identifies the
underlying implementation (Apollo, Hasura, Graphene, etc.) and
checks for dangerous features like introspection and debug mode.

Stage 3 — Active GraphQL Endpoint Detection.
"""
from __future__ import annotations
import json
import re
import ssl
import time
import urllib.request
from typing import Optional

from ..base import BaseTool
from ...models.tool_result import ParsedFinding, RunStatus, ToolRunResult

# Common GraphQL endpoint paths to probe in fallback mode
_GQL_PATHS = [
    "/graphql", "/graphiql", "/api/graphql", "/v1/graphql", "/v2/graphql",
    "/query", "/gql", "/graphql/v1", "/graphql/console", "/playground",
    "/altair", "/api/v1/graphql", "/graphql/api", "/graph",
]

_INTROSPECTION_QUERY = '{"query":"{__schema{types{name}}}"}'

# Fingerprint signatures: (implementation_name, response_pattern)
_FINGERPRINTS = [
    ("Apollo Server",   r"apollo"),
    ("Hasura",          r"hasura|x-hasura"),
    ("Graphene",        r"graphene"),
    ("AWS AppSync",     r"appsync"),
    ("WPGraphQL",       r"wpgraphql|wordpress"),
    ("HyperGraphQL",    r"hypergraphql"),
    ("Juniper",         r"juniper"),
    ("Sangria",         r"sangria"),
    ("Ariadne",         r"ariadne"),
    ("Strawberry",      r"strawberry"),
    ("GraphQL Java",    r"graphql.java|graphqljava"),
]


class Graphw00fTool(BaseTool):

    NAME         = "graphw00f"
    BINARY       = "graphw00f"
    CATEGORY     = "api_recon"
    STAGE        = 3
    PRIORITY     = 25
    PASSIVE      = False
    TIMEOUT      = 60
    DEPENDENCIES: list[str] = []
    INSTALL_CMD  = "pip install graphw00f  # or: git clone https://github.com/dolevf/graphw00f"

    # ── run ───────────────────────────────────────────────────────────────────

    def run(
        self,
        target: str,
        *,
        detect_only: bool = False,
        output_format: str = "json",
        cookies: Optional[str] = None,
        headers: Optional[dict] = None,
        **kwargs,
    ) -> ToolRunResult:
        """
        Args:
            target:        URL of the target (e.g. https://api.example.com).
            detect_only:   Only detect GraphQL presence, skip fingerprinting.
            output_format: 'json' or 'table'.
            cookies:       Cookie string for authenticated endpoints.
            headers:       Extra HTTP headers.
        """
        url = self.ensure_scheme(target)
        t0  = time.perf_counter()

        # ── Binary path ───────────────────────────────────────────────────────
        if self.is_available():
            args = ["-t", url, "-f"]
            if detect_only:
                args.append("-d")
            if output_format == "json":
                args += ["-o", "json"]
            if cookies:
                args += ["--cookies", cookies]
            if headers:
                for k, v in headers.items():
                    args += ["-H", f"{k}: {v}"]

            res = self.exec(args, timeout_s=float(self.timeout), expected_codes=(0, 1))
            dur = time.perf_counter() - t0
            if res.timed_out:
                return ToolRunResult.timeout(self.NAME, dur, self.timeout)
            if res.returncode == 127:
                return ToolRunResult.skipped(self.NAME, res.stderr)

            data = self.parse_output(res.stdout)
            findings = self._build_findings(data)
            r = self.build_result(data, findings, stdout=res.stdout,
                                  duration_s=dur, returncode=res.returncode)
            if not data["endpoints"]: r.status = RunStatus.NO_OUTPUT
            return r

        # ── Pure-Python probe fallback ─────────────────────────────────────────
        self._log("info", "graphw00f binary not found — using HTTP probe fallback")
        data, err = self._probe_graphql(url, headers or {}, cookies or "")
        dur = time.perf_counter() - t0

        findings = self._build_findings(data)
        r = self.build_result(data, findings, duration_s=dur, returncode=0)
        if not data["endpoints"]: r.status = RunStatus.NO_OUTPUT
        return r

    # ── parse_output ──────────────────────────────────────────────────────────

    def parse_output(self, raw: str, **kwargs) -> dict:
        if not raw.strip():
            return self._empty()

        # Try JSON
        try:
            parsed = json.loads(raw)
            if isinstance(parsed, list):
                endpoints = []
                for item in parsed:
                    endpoints.append({
                        "url":           item.get("url", ""),
                        "engine":        item.get("engine", "Unknown"),
                        "introspection": item.get("introspection", False),
                        "debug":         item.get("debug", False),
                        "detected":      item.get("detected", True),
                    })
                return {"endpoints": endpoints, "count": len(endpoints)}
        except Exception:
            pass

        # Fallback text parse
        endpoints = []
        lines = raw.splitlines()
        for line in lines:
            low = line.lower()
            if "graphql" in low and "http" in low:
                url_m = re.search(r"(https?://[^\s]+)", line)
                if url_m:
                    endpoints.append({
                        "url":           url_m.group(1),
                        "engine":        self._guess_engine(line),
                        "introspection": "introspection" in low,
                        "debug":         "debug" in low or "playground" in low,
                        "detected":      True,
                    })
        return {"endpoints": endpoints, "count": len(endpoints)}

    # ── internal ──────────────────────────────────────────────────────────────

    def _probe_graphql(
        self, base_url: str, headers: dict, cookies: str
    ) -> tuple[dict, str]:
        """Probe common GraphQL paths and fingerprint responses."""
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode    = ssl.CERT_NONE
        opener = urllib.request.build_opener(urllib.request.HTTPSHandler(context=ctx))

        endpoints: list[dict] = []
        base = base_url.rstrip("/")

        req_headers = {
            "Content-Type": "application/json",
            "User-Agent":   "ReconX/2.0 (graphw00f-probe)",
            **headers,
        }
        if cookies:
            req_headers["Cookie"] = cookies

        for path in _GQL_PATHS:
            url = base + path
            try:
                req = urllib.request.Request(
                    url,
                    data=_INTROSPECTION_QUERY.encode(),
                    headers=req_headers,
                    method="POST",
                )
                with opener.open(req, timeout=5) as resp:
                    body = resp.read().decode("utf-8", errors="replace")
                    resp_headers = dict(resp.headers)
                    code = resp.status

                if code in (200, 400) and (
                    "__schema" in body or "__typename" in body
                    or "graphql" in body.lower()
                ):
                    engine = self._fingerprint_response(body, resp_headers)
                    endpoints.append({
                        "url":           url,
                        "engine":        engine,
                        "introspection": "__schema" in body,
                        "debug":         "playground" in body.lower() or "graphiql" in body.lower(),
                        "detected":      True,
                    })

            except Exception:
                continue

        return {"endpoints": endpoints, "count": len(endpoints)}, ""

    @staticmethod
    def _fingerprint_response(body: str, headers: dict) -> str:
        combined = (body + " ".join(headers.values())).lower()
        for name, pattern in _FINGERPRINTS:
            if re.search(pattern, combined):
                return name
        return "Unknown GraphQL"

    @staticmethod
    def _guess_engine(text: str) -> str:
        for name, pattern in _FINGERPRINTS:
            if re.search(pattern, text, re.IGNORECASE):
                return name
        return "Unknown"

    @staticmethod
    def _empty() -> dict:
        return {"endpoints": [], "count": 0}

    def _build_findings(self, data: dict) -> list[ParsedFinding]:
        findings = []
        for ep in data.get("endpoints", []):
            findings.append(ParsedFinding(
                finding_type="graphql_endpoint", value=ep.get("url", ""),
                source=self.NAME, confidence=0.92,
                metadata={
                    "engine":        ep.get("engine", ""),
                    "introspection": ep.get("introspection", False),
                    "debug":         ep.get("debug", False),
                },
            ))
            if ep.get("introspection"):
                findings.append(ParsedFinding(
                    finding_type="vulnerability",
                    value="GraphQL introspection enabled",
                    source=self.NAME, confidence=1.0,
                    metadata={"severity": "MEDIUM", "url": ep.get("url", ""),
                              "description": "GraphQL introspection is enabled — schema fully exposed."},
                ))
        return findings
