"""
ReconX — Nmap tool wrapper (standardized).
Service/version detection, OS fingerprinting, NSE scripts.
Parses nmap XML output for reliable, structured data.
"""
from __future__ import annotations
import os
import tempfile
import time
from typing import Optional

from .base import BaseTool
from ..models.tool_result import ParsedFinding, RunStatus, ToolRunResult


class NmapTool(BaseTool):

    NAME         = "Nmap"
    BINARY       = "nmap"
    CATEGORY     = "scanning"
    STAGE        = 3
    PRIORITY     = 30
    PASSIVE      = False
    TIMEOUT      = 300
    DEPENDENCIES : list[str] = []
    INSTALL_CMD  = "sudo apt install nmap"

    # ── run ───────────────────────────────────────────────────────────────────

    def run(
        self,
        target: str,
        *,
        ports:           Optional[list[int]] = None,   # specific ports to scan
        port_range:      str                 = "1-1000",
        os_detect:       bool                = True,
        scripts:         Optional[list[str]] = None,   # NSE script names
        timing:          int                 = 4,       # T0–T5
        version_intensity: int               = 5,
        **kwargs,
    ) -> ToolRunResult:

        skip = self.skip_if_unavailable()
        if skip:
            return skip

        fail = self.validate_or_fail(target)
        if fail:
            return fail

        # Build port argument
        if ports:
            port_arg = ",".join(str(p) for p in sorted(set(ports)))
        else:
            port_arg = port_range

        # XML output to temp file (most reliable nmap output format)
        tmp_path = None
        t0 = time.perf_counter()

        try:
            with tempfile.NamedTemporaryFile(
                suffix=".xml", delete=False
            ) as tmp:
                tmp_path = tmp.name

            args = [
                "-sV",
                "--version-intensity", str(version_intensity),
                f"-T{timing}",
                "-p",  port_arg,
                "--open",
                "-oX", tmp_path,
            ]

            if os_detect:
                args += ["-O", "--osscan-limit"]

            if scripts:
                args += ["--script", ",".join(scripts)]

            args.append(target)

            res = self.exec(
                args,
                timeout_s=float(self.timeout),
                # nmap exits 1 if no hosts up — still valid
                expected_codes=(0, 1),
            )

        finally:
            pass  # don't delete yet — need to read xml below

        duration = time.perf_counter() - t0

        if res.timed_out:
            self._cleanup(tmp_path)
            return ToolRunResult.timeout(self.NAME, duration, self.timeout)

        if res.returncode == 127:
            self._cleanup(tmp_path)
            return ToolRunResult.skipped(self.NAME, res.stderr)

        # Read XML from temp file
        xml_text = ""
        try:
            if tmp_path and os.path.exists(tmp_path):
                with open(tmp_path, "r", encoding="utf-8", errors="replace") as f:
                    xml_text = f.read()
        except Exception as exc:
            self._cleanup(tmp_path)
            return self.fail("xml_read_error", str(exc), duration_s=duration)
        finally:
            self._cleanup(tmp_path)

        if not xml_text.strip():
            r = self.build_result(
                {"ports": [], "os_info": {}}, [],
                stdout=res.stdout, duration_s=duration
            )
            r.status = RunStatus.NO_OUTPUT
            return r

        # Parse
        data     = self.parse_output(xml_text)
        findings = self._make_findings(data)

        return self.build_result(
            data, findings,
            stdout=res.stdout, stderr=res.stderr,
            duration_s=duration, returncode=res.returncode,
        )

    # ── parse_output ──────────────────────────────────────────────────────────

    def parse_output(self, raw: str, **kwargs) -> dict:
        """
        Parse nmap XML into {"ports": [Port], "os_info": {...}}.
        Returns {"ports": [], "os_info": {}} on any parse failure.
        """
        if not raw.strip():
            return {"ports": [], "os_info": {}}

        try:
            return self.parse_nmap_xml_output(raw)
        except Exception as exc:
            self._log("warning", f"XML parse error: {exc}")
            return {"ports": [], "os_info": {}}

    # ── private ───────────────────────────────────────────────────────────────

    def _make_findings(self, data: dict) -> list[ParsedFinding]:
        findings = []
        for port in data.get("ports", []):
            findings.append(self._finding(
                "port",
                str(port.number),
                protocol=port.protocol,
                state=port.state,
                service=port.service,
                version=port.version,
            ))
        if data.get("os_info", {}).get("os"):
            findings.append(self._finding(
                "os",
                data["os_info"]["os"],
                confidence=data["os_info"].get("confidence", 0) / 100,
            ))
        return findings

    @staticmethod
    def _cleanup(path: Optional[str]) -> None:
        if path:
            try:
                os.unlink(path)
            except Exception:
                pass
