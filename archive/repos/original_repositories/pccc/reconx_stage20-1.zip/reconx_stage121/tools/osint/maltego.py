"""
ReconX — Maltego integration (entity extraction + MTGL/CSV export).

Maltego requires a licensed GUI installation. This wrapper:
  1. Invokes Maltego CLI / MaltegoHX command-line where available.
  2. Falls back to generating a Maltego-compatible .mtgl XML export
     from ReconX's own structured findings (graph visualization).
  3. Always produces a machine-readable entity graph regardless.

Stage 1 — Passive OSINT / Graph Intelligence.
"""
from __future__ import annotations
import json
import time
import xml.etree.ElementTree as ET
from datetime import datetime
from pathlib import Path
from typing import Optional

from ..base import BaseTool
from ...models.tool_result import ParsedFinding, RunStatus, ToolRunResult


class MaltegoTool(BaseTool):

    NAME         = "Maltego"
    BINARY       = "maltego"          # or "MaltegoHX" depending on install
    CATEGORY     = "osint"
    STAGE        = 1
    PRIORITY     = 25
    PASSIVE      = True
    TIMEOUT      = 180
    DEPENDENCIES: list[str] = []
    INSTALL_CMD  = "https://www.maltego.com/downloads/ (commercial license required)"

    # ── run ───────────────────────────────────────────────────────────────────

    def run(
        self,
        target: str,
        *,
        findings: Optional[dict] = None,
        output_dir: str = "reports",
        export_format: str = "mtgl",
        **kwargs,
    ) -> ToolRunResult:
        """
        Args:
            target:        Target domain or IP.
            findings:      Dict of existing ReconX findings to export as graph.
            output_dir:    Directory for .mtgl / .json graph exports.
            export_format: 'mtgl' (Maltego XML) or 'json' (entity graph).
        """
        if f := self.validate_or_fail(target):
            return f

        t0 = time.perf_counter()
        Path(output_dir).mkdir(parents=True, exist_ok=True)

        # --- Try native CLI first ---
        if self.is_available():
            res = self.exec(
                ["--headless", "--target", target, "--output", output_dir],
                timeout_s=float(self.timeout),
                expected_codes=(0, 1),
            )
            duration = time.perf_counter() - t0
            if res.returncode == 0:
                data = self.parse_output(res.stdout, target=target)
                return self.build_result(
                    data, self._build_findings(data),
                    stdout=res.stdout, duration_s=duration, returncode=0,
                )

        # --- Fallback: generate graph from provided findings ---
        self._log("info", "Maltego CLI unavailable. Generating graph from ReconX findings.")
        data = self._build_entity_graph(target, findings or {})
        graph_path = self._write_graph(data, output_dir, target, export_format)
        data["graph_path"] = str(graph_path)
        duration = time.perf_counter() - t0

        result = self.build_result(
            data, self._build_findings(data), duration_s=duration, returncode=0,
        )
        # Mark as skipped since we didn't use Maltego itself
        if not self.is_available():
            result.status = RunStatus.SKIPPED
        return result

    # ── parse_output ──────────────────────────────────────────────────────────

    def parse_output(self, raw: str, target: str = "", **kwargs) -> dict:
        if not raw.strip():
            return self._empty(target)
        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            return self._parse_xml_output(raw, target)

    # ── entity graph builder ─────────────────────────────────────────────────

    def _build_entity_graph(self, target: str, findings: dict) -> dict:
        """Convert ReconX findings dict into a Maltego entity graph structure."""
        entities: list[dict] = []
        links:    list[dict] = []

        root_id = f"domain:{target}"
        entities.append({
            "id":   root_id,
            "type": "maltego.Domain",
            "value": target,
        })

        for sub in findings.get("subdomains", []):
            eid = f"dns:{sub}"
            entities.append({"id": eid, "type": "maltego.DNSName", "value": sub})
            links.append({"from": root_id, "to": eid, "label": "has_subdomain"})

        for email in findings.get("emails", []):
            eid = f"email:{email}"
            entities.append({"id": eid, "type": "maltego.EmailAddress", "value": email})
            links.append({"from": root_id, "to": eid, "label": "has_email"})

        for ip in findings.get("ips", []):
            eid = f"ip:{ip}"
            entities.append({"id": eid, "type": "maltego.IPv4Address", "value": ip})
            links.append({"from": root_id, "to": eid, "label": "resolves_to"})

        for port_info in findings.get("open_ports", []):
            port = port_info.get("port", port_info) if isinstance(port_info, dict) else port_info
            eid = f"port:{ip}:{port}" if isinstance(port_info, dict) else f"port:{port}"
            entities.append({"id": eid, "type": "maltego.Port", "value": str(port)})
            links.append({"from": root_id, "to": eid, "label": "has_open_port"})

        return {
            "target":   target,
            "entities": entities,
            "links":    links,
            "count":    len(entities),
        }

    def _write_graph(self, data: dict, output_dir: str, target: str, fmt: str) -> Path:
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        safe_target = target.replace(".", "_").replace("/", "_")

        if fmt == "mtgl":
            path = Path(output_dir) / f"maltego_{safe_target}_{ts}.mtgl"
            self._write_mtgl(data, path)
        else:
            path = Path(output_dir) / f"maltego_{safe_target}_{ts}.json"
            path.write_text(json.dumps(data, indent=2))

        self._log("info", f"Graph written to {path}")
        return path

    @staticmethod
    def _write_mtgl(data: dict, path: Path) -> None:
        """Write Maltego MTGL (XML) entity graph."""
        root = ET.Element("MaltegoGraph", version="1.2")
        graph = ET.SubElement(root, "graph")
        entities_el = ET.SubElement(graph, "entities")
        links_el    = ET.SubElement(graph, "links")

        for entity in data["entities"]:
            e = ET.SubElement(entities_el, "entity",
                              id=entity["id"], type=entity["type"])
            v = ET.SubElement(e, "value")
            v.text = entity["value"]

        for link in data["links"]:
            lk = ET.SubElement(links_el, "link",
                                **{"from": link["from"], "to": link["to"]})
            lbl = ET.SubElement(lk, "label")
            lbl.text = link["label"]

        tree = ET.ElementTree(root)
        tree.write(str(path), encoding="utf-8", xml_declaration=True)

    def _parse_xml_output(self, raw: str, target: str) -> dict:
        try:
            root = ET.fromstring(raw)
            entities = [
                {"id": e.get("id", ""), "type": e.get("type", ""),
                 "value": (e.find("value") or ET.Element("v")).text or ""}
                for e in root.iter("entity")
            ]
            return {"target": target, "entities": entities, "links": [], "count": len(entities)}
        except ET.ParseError:
            return self._empty(target)

    @staticmethod
    def _empty(target: str) -> dict:
        return {"target": target, "entities": [], "links": [], "count": 0}

    def _build_findings(self, data: dict) -> list[ParsedFinding]:
        findings = []
        for entity in data.get("entities", []):
            etype = entity.get("type", "")
            val   = entity.get("value", "")
            if not val:
                continue
            ftype = (
                "subdomain"    if "DNS"    in etype else
                "email"        if "Email"  in etype else
                "ip"           if "IPv4"   in etype else
                "domain"       if "Domain" in etype else
                "entity"
            )
            findings.append(ParsedFinding(
                finding_type=ftype, value=val,
                source=self.NAME, confidence=0.8,
                metadata={"maltego_type": etype},
            ))
        return findings
