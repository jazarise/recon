"""
ReconX — SpiderFoot OSINT automation wrapper.

SpiderFoot runs automated OSINT scans against a target and correlates
data from 200+ sources. Supports CLI mode (sfcli) or the web API.

Stage 1 — Passive OSINT.
"""
from __future__ import annotations
import json
import time
from typing import Optional

from ..base import BaseTool
from ...models.tool_result import ParsedFinding, RunStatus, ToolRunResult


# SpiderFoot module categories we care about for recon
_RECON_MODULES = [
    "sfp_dnsraw",
    "sfp_dns",
    "sfp_whois",
    "sfp_sublist3r",
    "sfp_crt",
    "sfp_hackertarget",
    "sfp_shodan",
    "sfp_emailformat",
    "sfp_hunter",
    "sfp_portscan_tcp",
    "sfp_banner",
    "sfp_ssl",
]


class SpiderFootTool(BaseTool):

    NAME         = "SpiderFoot"
    BINARY       = "sfcli"            # CLI entrypoint
    CATEGORY     = "osint"
    STAGE        = 1
    PRIORITY     = 15
    PASSIVE      = True
    TIMEOUT      = 300
    DEPENDENCIES: list[str] = []
    INSTALL_CMD  = "sudo apt install spiderfoot  # or: pip install spiderfoot"

    # ── run ───────────────────────────────────────────────────────────────────

    def run(
        self,
        target: str,
        *,
        modules: Optional[list[str]] = None,
        output_format: str = "json",
        max_threads: int = 10,
        **kwargs,
    ) -> ToolRunResult:
        """
        Args:
            target:        Domain, IP, or email to investigate.
            modules:       Specific SpiderFoot module IDs to enable.
            output_format: Output format (json or csv).
            max_threads:   Thread count for concurrent module execution.
        """
        if s := self.skip_if_unavailable():
            return s
        if f := self.validate_or_fail(target):
            return f

        mods = ",".join(modules or _RECON_MODULES)
        t0 = time.perf_counter()

        args = [
            "-s", target,
            "-m", mods,
            "-o", output_format,
            "-t", str(max_threads),
            "-q",           # quiet — suppress progress noise
        ]

        res = self.exec(args, timeout_s=float(self.timeout), expected_codes=(0, 1, 2))
        duration = time.perf_counter() - t0

        if res.timed_out:
            return ToolRunResult.timeout(self.NAME, duration, self.timeout)
        if res.returncode == 127:
            return ToolRunResult.skipped(self.NAME, res.stderr)

        data = self.parse_output(res.stdout, fmt=output_format)
        findings = self._build_findings(data)

        result = self.build_result(
            data, findings, stdout=res.stdout, duration_s=duration, returncode=res.returncode
        )
        if not findings:
            result.status = RunStatus.NO_OUTPUT
        return result

    # ── parse_output ──────────────────────────────────────────────────────────

    def parse_output(self, raw: str, fmt: str = "json", **kwargs) -> dict:
        """Parse SpiderFoot CLI JSON or CSV output."""
        if not raw.strip():
            return self._empty()

        if fmt == "json":
            return self._parse_json(raw)
        return self._parse_text(raw)

    # ── internal ──────────────────────────────────────────────────────────────

    def _parse_json(self, raw: str) -> dict:
        result = self._empty()
        try:
            items = json.loads(raw)
            if not isinstance(items, list):
                items = [items]
            for item in items:
                etype = item.get("type", "")
                value = item.get("data", "")
                if not value:
                    continue
                if "DOMAIN_NAME" in etype or "SUBDOMAIN" in etype:
                    result["subdomains"].append(value)
                elif "EMAIL_ADDRESS" in etype:
                    result["emails"].append(value)
                elif "IP_ADDRESS" in etype or "NETBLOCK" in etype:
                    result["ips"].append(value)
                elif "INTERNET_NAME" in etype or "HOSTNAME" in etype:
                    result["hosts"].append(value)
                elif "BREACH" in etype or "LEAK" in etype:
                    result["breach_indicators"].append(value)
                elif "TCP_PORT_OPEN" in etype:
                    result["open_ports"].append(value)
                else:
                    result["raw_findings"].append({
                        "type": etype, "value": value,
                        "module": item.get("module", ""),
                    })
        except json.JSONDecodeError:
            return self._parse_text(raw)

        return self._deduplicate(result)

    def _parse_text(self, raw: str) -> dict:
        """Fallback text parser for CSV / plain output."""
        import re
        result = self._empty()
        email_re  = re.compile(r"[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}")
        ip_re     = re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}(?:/\d+)?\b")
        domain_re = re.compile(r"\b([a-zA-Z0-9\-]+(?:\.[a-zA-Z0-9\-]+)+\.[a-zA-Z]{2,})\b")

        for line in raw.splitlines():
            line = line.strip()
            if not line:
                continue
            for e in email_re.findall(line):
                result["emails"].append(e)
            for ip in ip_re.findall(line):
                result["ips"].append(ip)
            for d in domain_re.findall(line):
                result["subdomains"].append(d)

        return self._deduplicate(result)

    @staticmethod
    def _empty() -> dict:
        return {
            "subdomains":       [],
            "emails":           [],
            "ips":              [],
            "hosts":            [],
            "open_ports":       [],
            "breach_indicators": [],
            "raw_findings":     [],
        }

    @staticmethod
    def _deduplicate(d: dict) -> dict:
        for key in ("subdomains", "emails", "ips", "hosts", "open_ports", "breach_indicators"):
            d[key] = sorted(set(d[key]))
        return d

    def _build_findings(self, data: dict) -> list[ParsedFinding]:
        findings = []
        for sub in data.get("subdomains", []):
            findings.append(ParsedFinding(
                finding_type="subdomain", value=sub,
                source=self.NAME, confidence=0.85,
            ))
        for email in data.get("emails", []):
            findings.append(ParsedFinding(
                finding_type="email", value=email,
                source=self.NAME, confidence=0.9,
            ))
        for ip in data.get("ips", []):
            findings.append(ParsedFinding(
                finding_type="ip", value=ip,
                source=self.NAME, confidence=0.8,
            ))
        for breach in data.get("breach_indicators", []):
            findings.append(ParsedFinding(
                finding_type="breach_indicator", value=breach,
                source=self.NAME, confidence=0.75,
                metadata={"risk": "data_exposure"},
            ))
        return findings
