"""
ReconX — theHarvester tool wrapper.

Collects emails, subdomains, hosts, employee names, and public
intelligence from open sources (Google, Bing, LinkedIn, etc.)

Stage 1 — Passive OSINT (no direct target traffic).
"""
from __future__ import annotations
import json
import re
import time
from typing import Optional

from ..base import BaseTool
from ...models.tool_result import ParsedFinding, RunStatus, ToolRunResult


class TheHarvesterTool(BaseTool):

    NAME         = "theHarvester"
    BINARY       = "theHarvester"
    CATEGORY     = "osint"
    STAGE        = 1
    PRIORITY     = 5
    PASSIVE      = True
    TIMEOUT      = 180
    DEPENDENCIES: list[str] = []
    INSTALL_CMD  = "sudo apt install theharvester  # or: pip install theHarvester"

    # Default data sources (conservative — no API keys required)
    DEFAULT_SOURCES = "bing,crtsh,dnsdumpster,hackertarget,rapiddns,urlscan,virustotal"

    # ── run ───────────────────────────────────────────────────────────────────

    def run(
        self,
        target: str,
        *,
        sources: Optional[str] = None,
        limit: int = 500,
        dns_lookup: bool = False,
        dns_brute: bool = False,
        **kwargs,
    ) -> ToolRunResult:
        """
        Args:
            target:     Domain to harvest intelligence from.
            sources:    Comma-separated source list (default: no-API sources).
            limit:      Max results per source (default: 500).
            dns_lookup: Resolve discovered hosts (-n flag).
            dns_brute:  DNS brute force (-c flag).
        """
        if s := self.skip_if_unavailable():
            return s

        # theHarvester only works on domains
        ttype = self.classify_target(target)
        if ttype not in ("domain",):
            return self.fail(
                "invalid_target",
                f"theHarvester requires a domain. Got: {ttype} ({target})",
            )

        srcs = sources or self.DEFAULT_SOURCES
        t0 = time.perf_counter()

        args = ["-d", target, "-b", srcs, "-l", str(limit), "-f", "/tmp/theharvester_out"]
        if dns_lookup:
            args.append("-n")
        if dns_brute:
            args.append("-c")

        res = self.exec(args, timeout_s=float(self.timeout), expected_codes=(0, 1, 255))
        duration = time.perf_counter() - t0

        if res.timed_out:
            return ToolRunResult.timeout(self.NAME, duration, self.timeout)
        if res.returncode == 127:
            return ToolRunResult.skipped(self.NAME, res.stderr)

        data = self.parse_output(res.stdout or res.stderr)

        # Attempt JSON output if file was written
        try:
            import os
            for ext in (".json", "_json.json"):
                path = f"/tmp/theharvester_out{ext}"
                if os.path.exists(path):
                    with open(path) as fh:
                        json_data = json.load(fh)
                    data = self._merge_json_data(data, json_data)
                    os.unlink(path)
                    break
        except Exception:
            pass

        findings = self._build_findings(data)
        result = self.build_result(
            data, findings, stdout=res.stdout, duration_s=duration, returncode=res.returncode
        )
        if not findings:
            result.status = RunStatus.NO_OUTPUT
        return result

    # ── parse_output ──────────────────────────────────────────────────────────

    def parse_output(self, raw: str, **kwargs) -> dict:
        """Parse theHarvester plain-text console output."""
        if not raw.strip():
            return {"emails": [], "subdomains": [], "hosts": [], "names": [], "ips": []}

        emails:     list[str] = []
        subdomains: list[str] = []
        hosts:      list[str] = []
        names:      list[str] = []
        ips:        list[str] = []

        # Regexes
        email_re  = re.compile(r"[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}")
        ip_re     = re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b")
        # Track section context
        section = None
        for line in raw.splitlines():
            line = line.strip()
            if not line or line.startswith("*") or line.startswith("-"):
                continue
            lower = line.lower()
            if "email" in lower and "found" in lower:
                section = "email"
                continue
            if "host" in lower and "found" in lower:
                section = "host"
                continue
            if "ip" in lower and "found" in lower:
                section = "ip"
                continue
            if "interesting" in lower or "name" in lower:
                section = "name"
                continue

            # Extract emails anywhere
            for m in email_re.findall(line):
                if m not in emails:
                    emails.append(m)

            # Extract IPs anywhere
            for m in ip_re.findall(line):
                if m not in ips:
                    ips.append(m)

            # Domain-like patterns
            domain_re = re.compile(r"\b([a-zA-Z0-9\-]+(?:\.[a-zA-Z0-9\-]+)+\.[a-zA-Z]{2,})\b")
            for m in domain_re.findall(line):
                if m not in subdomains and m not in hosts:
                    subdomains.append(m)

        return {
            "emails":     sorted(set(emails)),
            "subdomains": sorted(set(subdomains)),
            "hosts":      sorted(set(hosts)),
            "names":      sorted(set(names)),
            "ips":        sorted(set(ips)),
            "count": {
                "emails": len(emails),
                "subdomains": len(subdomains),
                "hosts": len(hosts),
                "ips": len(ips),
            },
        }

    # ── internal ──────────────────────────────────────────────────────────────

    def _merge_json_data(self, parsed: dict, json_data: dict) -> dict:
        """Merge JSON export with text-parsed data — JSON takes priority."""
        merged = dict(parsed)
        if "emails" in json_data:
            merged["emails"] = sorted(set(parsed["emails"]) | set(json_data["emails"]))
        if "hosts" in json_data:
            for h in json_data["hosts"]:
                val = h if isinstance(h, str) else h.get("host", "")
                if val and val not in merged["subdomains"]:
                    merged["subdomains"].append(val)
        if "ips" in json_data:
            merged["ips"] = sorted(set(parsed["ips"]) | set(json_data["ips"]))
        return merged

    def _build_findings(self, data: dict) -> list[ParsedFinding]:
        findings = []
        for email in data.get("emails", []):
            findings.append(ParsedFinding(
                finding_type="email", value=email,
                source=self.NAME, confidence=0.9,
            ))
        for sub in data.get("subdomains", []):
            findings.append(ParsedFinding(
                finding_type="subdomain", value=sub,
                source=self.NAME, confidence=0.8,
            ))
        for ip in data.get("ips", []):
            findings.append(ParsedFinding(
                finding_type="ip", value=ip,
                source=self.NAME, confidence=0.75,
            ))
        return findings
