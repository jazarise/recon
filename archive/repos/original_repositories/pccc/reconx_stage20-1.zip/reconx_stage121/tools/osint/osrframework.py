"""
ReconX — OSRFramework wrapper (usufy / mailfy / searchfy).

OSRFramework provides username intelligence and social footprint analysis
across 300+ platforms. Non-intrusive OSINT — no direct target traffic.

Stage 1 — Passive OSINT.
"""
from __future__ import annotations
import json
import re
import time
from typing import Optional

from ..base import BaseTool
from ...models.tool_result import ParsedFinding, RunStatus, ToolRunResult


class OSRFrameworkTool(BaseTool):

    NAME         = "OSRFramework"
    BINARY       = "usufy"             # primary OSRFramework CLI binary
    CATEGORY     = "osint"
    STAGE        = 1
    PRIORITY     = 20
    PASSIVE      = True
    TIMEOUT      = 120
    DEPENDENCIES: list[str] = []
    INSTALL_CMD  = "pip install osrframework  # or: sudo apt install osrframework"

    # Wrapper modes
    MODE_USERNAME = "usufy"    # Username across platforms
    MODE_EMAIL    = "mailfy"   # Email existence checks
    MODE_SEARCH   = "searchfy" # Free-text search across platforms

    # ── run ───────────────────────────────────────────────────────────────────

    def run(
        self,
        target: str,
        *,
        mode: str = "usufy",
        platforms: Optional[list[str]] = None,
        output_format: str = "json",
        **kwargs,
    ) -> ToolRunResult:
        """
        Args:
            target:        Username, email, or search term.
            mode:          'usufy' | 'mailfy' | 'searchfy'
            platforms:     Restrict to specific platforms (default: all).
            output_format: 'json' or 'csv'.
        """
        # Resolve the correct binary for the mode
        binary_map = {
            "usufy":    "usufy",
            "mailfy":   "mailfy",
            "searchfy": "searchfy",
        }
        binary = binary_map.get(mode, "usufy")
        self.BINARY = binary

        if s := self.skip_if_unavailable():
            return s

        t0 = time.perf_counter()
        args = ["-n", target, "-o", output_format]
        if platforms:
            args += ["-p"] + platforms

        res = self.exec(args, timeout_s=float(self.timeout), expected_codes=(0, 1))
        duration = time.perf_counter() - t0

        if res.timed_out:
            return ToolRunResult.timeout(self.NAME, duration, self.timeout)
        if res.returncode == 127:
            return ToolRunResult.skipped(self.NAME, res.stderr)

        data = self.parse_output(res.stdout, mode=mode)
        findings = self._build_findings(data, mode)

        result = self.build_result(
            data, findings, stdout=res.stdout, duration_s=duration, returncode=res.returncode
        )
        if not findings:
            result.status = RunStatus.NO_OUTPUT
        return result

    # ── parse_output ──────────────────────────────────────────────────────────

    def parse_output(self, raw: str, mode: str = "usufy", **kwargs) -> dict:
        if not raw.strip():
            return {"profiles": [], "emails": [], "platforms": [], "mode": mode}

        # Try JSON first
        try:
            parsed = json.loads(raw)
            return self._normalize_json(parsed, mode)
        except (json.JSONDecodeError, ValueError):
            pass

        return self._parse_text(raw, mode)

    # ── internal ──────────────────────────────────────────────────────────────

    def _normalize_json(self, data: list | dict, mode: str) -> dict:
        profiles:  list[dict] = []
        emails:    list[str]  = []
        platforms: list[str]  = []

        items = data if isinstance(data, list) else [data]
        for item in items:
            platform = item.get("platform", item.get("name", ""))
            uri      = item.get("uri", item.get("url", ""))
            found    = item.get("found", item.get("valid", False))
            if platform:
                platforms.append(platform)
            if found and uri:
                profiles.append({
                    "platform": platform,
                    "url":      uri,
                    "found":    True,
                })

        return {
            "profiles":  profiles,
            "emails":    sorted(set(emails)),
            "platforms": sorted(set(platforms)),
            "mode":      mode,
            "count":     len(profiles),
        }

    def _parse_text(self, raw: str, mode: str) -> dict:
        profiles:  list[dict] = []
        emails:    list[str]  = []
        url_re    = re.compile(r"https?://\S+")
        email_re  = re.compile(r"[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}")

        for line in raw.splitlines():
            line = line.strip()
            for url in url_re.findall(line):
                profiles.append({"platform": "unknown", "url": url, "found": True})
            for email in email_re.findall(line):
                emails.append(email)

        return {
            "profiles":  profiles,
            "emails":    sorted(set(emails)),
            "platforms": [],
            "mode":      mode,
            "count":     len(profiles),
        }

    def _build_findings(self, data: dict, mode: str) -> list[ParsedFinding]:
        findings = []
        for profile in data.get("profiles", []):
            findings.append(ParsedFinding(
                finding_type="social_profile",
                value=profile.get("url", ""),
                source=self.NAME,
                confidence=0.85,
                metadata={
                    "platform": profile.get("platform", ""),
                    "mode": mode,
                },
            ))
        for email in data.get("emails", []):
            findings.append(ParsedFinding(
                finding_type="email", value=email,
                source=self.NAME, confidence=0.9,
            ))
        return findings
