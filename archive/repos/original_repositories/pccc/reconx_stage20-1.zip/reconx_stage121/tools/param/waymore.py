"""
ReconX — waymore wrapper.

waymore aggregates historical URLs and responses from multiple archive
sources simultaneously: Wayback Machine, Common Crawl, URLScan.io,
VirusTotal, and AlienVault OTX. More thorough than gau for deep
historical attack surface discovery.

Stage 2 — Passive Historical Content Aggregation.
"""
from __future__ import annotations
import json
import re
import ssl
import time
import urllib.parse
import urllib.request
from collections import defaultdict
from typing import Optional
from urllib.parse import urlparse, urlunparse, parse_qs

from ..base import BaseTool
from ...models.tool_result import ParsedFinding, RunStatus, ToolRunResult

# Archive source APIs used in fallback mode
_SOURCES = {
    "wayback": (
        "https://web.archive.org/cdx/search/cdx"
        "?url=*.{domain}/*&output=json&fl=original,statuscode"
        "&collapse=urlkey&limit={limit}&filter=statuscode:200"
    ),
    "commoncrawl_index": "https://index.commoncrawl.org/collinfo.json",
    "urlscan": "https://urlscan.io/api/v1/search/?q=domain:{domain}&size=100",
}


class WaymoreTool(BaseTool):

    NAME         = "waymore"
    BINARY       = "waymore"
    CATEGORY     = "param"
    STAGE        = 2
    PRIORITY     = 25
    PASSIVE      = True
    TIMEOUT      = 180
    DEPENDENCIES: list[str] = []
    INSTALL_CMD  = "pip install waymore  # or: git clone https://github.com/xnl-h4ck3r/waymore"

    # ── run ───────────────────────────────────────────────────────────────────

    def run(
        self,
        target: str,
        *,
        mode:         str            = "U",     # "U"=URLs only, "R"=responses, "B"=both
        sources:      Optional[list[str]] = None,  # ["wayback","commoncrawl","urlscan"]
        filter_codes: Optional[list[str]] = None,  # ["200","301"]
        filter_mime:  Optional[list[str]] = None,
        max_urls:     int            = 5000,
        threads:      int            = 10,
        no_subs:      bool           = False,
        **kwargs,
    ) -> ToolRunResult:
        """
        Args:
            target:       Domain to aggregate historical data for.
            mode:         'U' = URLs only (fastest); 'R' = download responses;
                          'B' = both (slow, disk-intensive).
            sources:      Archive sources to query. Defaults to all available.
            filter_codes: Only include these HTTP status codes.
            filter_mime:  Only include these MIME types.
            max_urls:     Maximum URLs to collect.
            threads:      Concurrent download threads (mode R/B only).
            no_subs:      Exclude subdomain URLs.
        """
        if self.classify_target(target) != "domain":
            return ToolRunResult.invalid_target(self.NAME, target, "Requires a domain.")

        t0 = time.perf_counter()

        # ── Binary path ───────────────────────────────────────────────────────
        if self.is_available():
            args = ["-i", target, "-mode", mode, "-p", str(threads),
                    "-l", str(max_urls), "-v", "0"]   # -v 0 = quiet

            if sources:
                args += ["-xwm"] if "wayback" not in sources else []
                args += ["-xcc"] if "commoncrawl" not in sources else []
                args += ["-xus"] if "urlscan" not in sources else []

            if filter_codes:
                args += ["-fc", ",".join(filter_codes)]
            if filter_mime:
                args += ["-ft", ",".join(filter_mime)]
            if no_subs:
                args.append("-no-subs")

            res = self.exec(args, timeout_s=float(self.timeout), expected_codes=(0, 1))
            dur = time.perf_counter() - t0
            if res.timed_out:
                return ToolRunResult.timeout(self.NAME, dur, self.timeout)
            if res.returncode == 127:
                return ToolRunResult.skipped(self.NAME, res.stderr)

            data = self.parse_output(res.stdout, max_urls=max_urls)
            findings = self._build_findings(data)
            r = self.build_result(data, findings, stdout=res.stdout,
                                  duration_s=dur, returncode=res.returncode)
            if not data["urls"]: r.status = RunStatus.NO_OUTPUT
            return r

        # ── Pure-Python multi-source fallback ─────────────────────────────────
        self._log("info", "waymore binary not found — using multi-source API fallback")
        srcs = sources or ["wayback", "urlscan"]
        data, err = self._multi_source_fetch(target, srcs, max_urls, filter_codes or [])
        dur = time.perf_counter() - t0

        if err and not data["urls"]:
            return self.fail("network_error", err, duration_s=dur)

        findings = self._build_findings(data)
        r = self.build_result(data, findings, duration_s=dur, returncode=0)
        if not data["urls"]: r.status = RunStatus.NO_OUTPUT
        return r

    # ── parse_output ──────────────────────────────────────────────────────────

    def parse_output(self, raw: str, max_urls: int = 5000, **kwargs) -> dict:
        if not raw.strip():
            return self._empty()

        urls:      list[str] = []
        endpoints: set[str]  = set()
        params:    set[str]  = set()
        js_files:  list[str] = []
        by_ext:    dict[str, int] = defaultdict(int)
        seen:      set[str]  = set()
        ansi_re   = re.compile(r"\x1b\[[0-9;]*[A-Za-z]")
        url_re    = re.compile(r"https?://[^\s\]\"'<>]+")

        for line in raw.splitlines():
            line = ansi_re.sub("", line).strip()
            for url in url_re.findall(line):
                url = url.rstrip(".,;)")
                if url in seen or not url.startswith("http"):
                    continue
                seen.add(url)
                urls.append(url)

                path = url.split("?")[0].lower()
                endpoints.add(urlunparse((*urlparse(url)[:3], "", "", "")))

                # Extension categorisation
                ext = path.rsplit(".", 1)[-1][:6] if "." in path.split("/")[-1] else "none"
                by_ext[ext] += 1

                if path.endswith(".js"):
                    js_files.append(url)

                try:
                    for p in parse_qs(urlparse(url).query):
                        params.add(p)
                except Exception:
                    pass

                if len(urls) >= max_urls:
                    break
            if len(urls) >= max_urls:
                break

        return {
            "urls":      urls,
            "endpoints": sorted(endpoints),
            "params":    sorted(params),
            "js_files":  list(dict.fromkeys(js_files)),
            "by_ext":    dict(sorted(by_ext.items(), key=lambda x: -x[1])[:20]),
            "count":     len(urls),
            "sources":   ["binary"],
        }

    # ── internal ──────────────────────────────────────────────────────────────

    def _multi_source_fetch(
        self,
        domain:       str,
        sources:      list[str],
        max_urls:     int,
        filter_codes: list[str],
    ) -> tuple[dict, str]:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode    = ssl.CERT_NONE
        opener = urllib.request.build_opener(urllib.request.HTTPSHandler(context=ctx))

        all_urls:  list[str] = []
        errors:    list[str] = []
        srcs_used: list[str] = []

        per_source = max_urls // max(len(sources), 1)

        for src in sources:
            try:
                fetched = self._fetch_source(src, domain, per_source, opener)
                all_urls.extend(fetched)
                srcs_used.append(src)
                time.sleep(0.5)   # polite rate limiting
            except Exception as e:
                errors.append(f"{src}: {e}")

        # Deduplicate preserving order
        seen: set[str] = set()
        unique: list[str] = []
        for u in all_urls:
            if u not in seen:
                seen.add(u)
                unique.append(u)

        if not unique:
            return self._empty(), "; ".join(errors)

        # Build result via parse_output for consistent schema
        pseudo_raw = "\n".join(unique[:max_urls])
        data = self.parse_output(pseudo_raw, max_urls=max_urls)
        data["sources"] = srcs_used
        return data, ""

    def _fetch_source(
        self, source: str, domain: str, limit: int, opener
    ) -> list[str]:
        urls: list[str] = []

        if source == "wayback":
            api_url = _SOURCES["wayback"].format(domain=domain, limit=min(limit, 10000))
            req = urllib.request.Request(
                api_url, headers={"User-Agent": "ReconX/2.0 (waymore-fallback)"}
            )
            with opener.open(req, timeout=30) as resp:
                body = json.loads(resp.read().decode("utf-8", errors="replace"))
            urls = [row[0] for row in body[1:] if row and str(row[0]).startswith("http")]

        elif source == "urlscan":
            api_url = _SOURCES["urlscan"].format(domain=urllib.parse.quote(domain))
            req = urllib.request.Request(
                api_url, headers={
                    "User-Agent": "ReconX/2.0 (waymore-fallback)",
                    "Accept": "application/json",
                }
            )
            with opener.open(req, timeout=15) as resp:
                body = json.loads(resp.read().decode("utf-8", errors="replace"))
            for result in body.get("results", []):
                if u := result.get("page", {}).get("url", ""):
                    urls.append(u)
                if u := result.get("task", {}).get("url", ""):
                    urls.append(u)

        return urls

    @staticmethod
    def _empty() -> dict:
        return {"urls": [], "endpoints": [], "params": [], "js_files": [],
                "by_ext": {}, "count": 0, "sources": []}

    def _build_findings(self, data: dict) -> list[ParsedFinding]:
        findings = []
        for url in data.get("urls", [])[:500]:
            findings.append(ParsedFinding(
                finding_type="historical_url", value=url,
                source=self.NAME, confidence=0.8,
                metadata={"sources": data.get("sources", [])},
            ))
        for js in data.get("js_files", []):
            findings.append(ParsedFinding(
                finding_type="js_file", value=js,
                source=self.NAME, confidence=0.85,
                metadata={"note": "Historical JS file — may contain leaked endpoints/keys"},
            ))
        for param in data.get("params", []):
            findings.append(ParsedFinding(
                finding_type="url_parameter", value=param,
                source=self.NAME, confidence=0.8,
            ))
        return findings
