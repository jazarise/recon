"""
ReconX — gospider wrapper.

gospider is a fast recursive web spider that extracts URLs from
HTML, JS files, and web archives simultaneously. Produces a
comprehensive endpoint inventory for parameter and attack-surface discovery.

Stage 3 — Active Web Crawling / Endpoint Discovery.
"""
from __future__ import annotations
import re
import time
from typing import Optional
from urllib.parse import urlparse, urlunparse, parse_qs

from ..base import BaseTool
from ...models.tool_result import ParsedFinding, RunStatus, ToolRunResult


class GospiderTool(BaseTool):

    NAME         = "gospider"
    BINARY       = "gospider"
    CATEGORY     = "param"
    STAGE        = 3
    PRIORITY     = 20
    PASSIVE      = False
    TIMEOUT      = 180
    DEPENDENCIES: list[str] = []
    INSTALL_CMD  = "go install github.com/jaeles-project/gospider@latest"

    # ── run ───────────────────────────────────────────────────────────────────

    def run(
        self,
        target: str,
        *,
        depth:        int            = 2,
        concurrent:   int            = 5,
        threads:      int            = 20,
        delay:        int            = 0,
        timeout:      int            = 10,
        include_subs: bool           = False,
        js:           bool           = True,
        sitemap:      bool           = True,
        robots:       bool           = True,
        wayback:      bool           = False,
        user_agent:   Optional[str]  = None,
        cookies:      Optional[str]  = None,
        max_urls:     int            = 5000,
        **kwargs,
    ) -> ToolRunResult:
        """
        Args:
            target:       URL to start crawling from.
            depth:        Recursion depth (higher = thorough, slower).
            concurrent:   Concurrent spider workers.
            threads:      Goroutines per worker.
            delay:        Milliseconds delay between requests.
            timeout:      HTTP request timeout in seconds.
            include_subs: Follow subdomain links.
            js:           Extract URLs from JavaScript files.
            sitemap:      Parse sitemap.xml.
            robots:       Respect / parse robots.txt.
            wayback:      Include Wayback Machine archived URLs.
            user_agent:   Custom User-Agent.
            cookies:      Cookie string (e.g. "session=abc;token=xyz").
            max_urls:     Cap on URLs to return.
        """
        if s := self.skip_if_unavailable(): return s

        url = self.ensure_scheme(target)
        args = [
            "-s",  url,
            "-d",  str(depth),
            "-c",  str(concurrent),
            "-t",  str(threads),
            "--timeout", str(timeout),
            "--quiet",
            "--no-redirect",
        ]
        if delay:
            args += ["--delay", str(delay)]
        if include_subs:
            args.append("--subs")
        if not js:
            args.append("--no-js")
        if not sitemap:
            args.append("--sitemap=false")
        if not robots:
            args.append("--robots=false")
        if wayback:
            args.append("--wayback")
        if user_agent:
            args += ["-ua", user_agent]
        if cookies:
            args += ["--cookie", cookies]

        t0  = time.perf_counter()
        res = self.exec(args, timeout_s=float(self.timeout), expected_codes=(0, 1))
        dur = time.perf_counter() - t0

        if res.timed_out:
            return ToolRunResult.timeout(self.NAME, dur, self.timeout)
        if res.returncode == 127:
            return ToolRunResult.skipped(self.NAME, res.stderr)

        data     = self.parse_output(res.stdout, max_urls=max_urls)
        findings = self._build_findings(data)
        r = self.build_result(data, findings, stdout=res.stdout,
                              duration_s=dur, returncode=res.returncode)
        if not data["urls"]: r.status = RunStatus.NO_OUTPUT
        return r

    # ── parse_output ──────────────────────────────────────────────────────────

    def parse_output(self, raw: str, max_urls: int = 5000, **kwargs) -> dict:
        """
        gospider output format:
          [url] - [code] - [from source] http://example.com/path?q=1
          [javascript] - [code] - http://example.com/app.js
          [form] - http://example.com/login
          [linkfinder] - http://example.com/static/app.js - http://api.example.com/v1/users
        """
        if not raw.strip():
            return self._empty()

        urls:      list[str] = []
        js_files:  list[str] = []
        forms:     list[str] = []
        endpoints: set[str]  = set()
        params:    set[str]  = set()
        seen:      set[str]  = set()
        ansi_re   = re.compile(r"\x1b\[[0-9;]*[A-Za-z]")
        url_re    = re.compile(r"https?://[^\s\]\"'<>]+")
        param_re  = re.compile(r"[?&]([a-zA-Z0-9_\-\.]+)=")

        for line in raw.splitlines():
            line   = ansi_re.sub("", line).strip()
            lower  = line.lower()
            is_js  = "[javascript]" in lower
            is_form= "[form]" in lower

            for url in url_re.findall(line):
                url = url.rstrip(".,;)")
                if url in seen:
                    continue
                seen.add(url)

                if is_js or url.split("?")[0].lower().endswith(".js"):
                    js_files.append(url)
                if is_form:
                    forms.append(url)
                urls.append(url)

                try:
                    parsed = urlparse(url)
                    ep = urlunparse((parsed.scheme, parsed.netloc, parsed.path, "", "", ""))
                    endpoints.add(ep)
                    for p in parse_qs(parsed.query):
                        params.add(p)
                except Exception:
                    pass

                if len(urls) >= max_urls:
                    break

            if len(urls) >= max_urls:
                break

        return {
            "urls":      urls,
            "js_files":  list(dict.fromkeys(js_files)),
            "forms":     list(dict.fromkeys(forms)),
            "endpoints": sorted(endpoints),
            "params":    sorted(params),
            "count":     len(urls),
        }

    # ── internal ──────────────────────────────────────────────────────────────

    @staticmethod
    def _empty() -> dict:
        return {"urls": [], "js_files": [], "forms": [], "endpoints": [],
                "params": [], "count": 0}

    def _build_findings(self, data: dict) -> list[ParsedFinding]:
        findings = []
        for url in data.get("urls", [])[:500]:
            findings.append(ParsedFinding(
                finding_type="url", value=url,
                source=self.NAME, confidence=0.9,
            ))
        for js in data.get("js_files", []):
            findings.append(ParsedFinding(
                finding_type="js_file", value=js,
                source=self.NAME, confidence=0.95,
                metadata={"note": "JavaScript file — check for secrets and endpoints"},
            ))
        for form in data.get("forms", []):
            findings.append(ParsedFinding(
                finding_type="form", value=form,
                source=self.NAME, confidence=0.9,
            ))
        for param in data.get("params", []):
            findings.append(ParsedFinding(
                finding_type="url_parameter", value=param,
                source=self.NAME, confidence=0.85,
            ))
        return findings
