"""
ReconX — ParamSpider wrapper.

ParamSpider mines parameter names from web archives (Wayback Machine, Common
Crawl) for a target domain — entirely passive, no direct target traffic.
Discovers hidden GET parameters that normal crawling misses.

Stage 2 — Passive Parameter Discovery.
"""
from __future__ import annotations
import json
import re
import ssl
import time
import urllib.parse
import urllib.request
from collections import defaultdict
from typing import Optional

from ..base import BaseTool
from ...models.tool_result import ParsedFinding, RunStatus, ToolRunResult

# Wayback CDX API used by the pure-Python fallback
_CDX_API = (
    "https://web.archive.org/cdx/search/cdx"
    "?url=*.{domain}/*&output=json&fl=original&collapse=urlkey"
    "&filter=statuscode:200&limit={limit}"
)


class ParamSpiderTool(BaseTool):

    NAME         = "paramspider"
    BINARY       = "paramspider"
    CATEGORY     = "param"
    STAGE        = 2
    PRIORITY     = 15
    PASSIVE      = True
    TIMEOUT      = 120
    DEPENDENCIES: list[str] = []
    INSTALL_CMD  = "pip install paramspider  # or: git clone https://github.com/devanshbatham/ParamSpider"

    # ── run ───────────────────────────────────────────────────────────────────

    def run(
        self,
        target: str,
        *,
        level:       str  = "high",    # "low"|"medium"|"high" (crawl depth)
        subs:        bool = True,       # include subdomains
        quiet:       bool = True,
        exclude_ext: Optional[list[str]] = None,
        max_urls:    int  = 5000,
        **kwargs,
    ) -> ToolRunResult:
        """
        Args:
            target:      Domain to harvest parameters from.
            level:       Discovery level (high = more sources).
            subs:        Include subdomain URLs.
            quiet:       Suppress banner output.
            exclude_ext: File extensions to exclude (default: images/fonts/css).
            max_urls:    Cap on URLs to process.
        """
        if self.classify_target(target) != "domain":
            return ToolRunResult.invalid_target(self.NAME, target, "Requires a domain.")

        excluded = exclude_ext or ["jpg", "jpeg", "png", "gif", "svg", "css",
                                    "woff", "woff2", "ttf", "eot", "ico", "mp4", "mp3"]
        t0 = time.perf_counter()

        # ── Binary path ───────────────────────────────────────────────────────
        if self.is_available():
            args = ["-d", target, "--level", level,
                    "--exclude", ",".join(excluded)]
            if subs:
                args.append("--subs")
            if quiet:
                args.append("--quiet")

            res = self.exec(args, timeout_s=float(self.timeout), expected_codes=(0, 1))
            dur = time.perf_counter() - t0
            if res.timed_out:
                return ToolRunResult.timeout(self.NAME, dur, self.timeout)
            if res.returncode == 127:
                return ToolRunResult.skipped(self.NAME, res.stderr)

            data = self.parse_output(res.stdout, max_urls=max_urls)
            findings = self._build_findings(data)
            r = self.build_result(data, findings, stdout=res.stdout,
                                  duration_s=dur, returncode=res.returncode)
            if not data["params"]: r.status = RunStatus.NO_OUTPUT
            return r

        # ── Pure-Python CDX fallback ──────────────────────────────────────────
        self._log("info", "paramspider binary not found — using Wayback CDX fallback")
        data, err = self._cdx_extract(target, max_urls, excluded)
        dur = time.perf_counter() - t0

        if err and not data["params"]:
            return self.fail("network_error", err, duration_s=dur)

        findings = self._build_findings(data)
        r = self.build_result(data, findings, duration_s=dur, returncode=0)
        if not data["params"]: r.status = RunStatus.NO_OUTPUT
        return r

    # ── parse_output ──────────────────────────────────────────────────────────

    def parse_output(self, raw: str, max_urls: int = 5000, **kwargs) -> dict:
        """
        ParamSpider outputs URLs with FUZZ placeholder:
          https://example.com/search?q=FUZZ&page=FUZZ
        """
        if not raw.strip():
            return self._empty()

        urls:    list[str] = []
        params:  set[str]  = set()
        param_map: dict[str, list[str]] = defaultdict(list)   # param → [urls]
        ansi_re  = re.compile(r"\x1b\[[0-9;]*[A-Za-z]")
        param_re = re.compile(r"[?&]([a-zA-Z0-9_\-\.]+)=")
        seen: set[str] = set()

        for line in raw.splitlines():
            line = ansi_re.sub("", line).strip()
            if not line.startswith("http"):
                continue
            url = line.split()[0] if " " in line else line
            if url in seen:
                continue
            seen.add(url)
            urls.append(url)

            for p in param_re.findall(url):
                params.add(p)
                param_map[p].append(url)

            if len(urls) >= max_urls:
                break

        return {
            "urls":      urls,
            "params":    sorted(params),
            "param_map": {k: v[:10] for k, v in param_map.items()},
            "count":     len(params),
        }

    # ── internal ──────────────────────────────────────────────────────────────

    def _cdx_extract(
        self, domain: str, max_urls: int, excluded_exts: list[str]
    ) -> tuple[dict, str]:
        """Fetch URLs from Wayback CDX API and extract parameters."""
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode    = ssl.CERT_NONE
        opener = urllib.request.build_opener(urllib.request.HTTPSHandler(context=ctx))

        url = _CDX_API.format(domain=domain, limit=min(max_urls * 2, 20000))
        try:
            req = urllib.request.Request(
                url, headers={"User-Agent": "ReconX/2.0 (paramspider-cdx)"}
            )
            with opener.open(req, timeout=30) as resp:
                body = json.loads(resp.read().decode("utf-8", errors="replace"))
        except Exception as e:
            return self._empty(), str(e)

        # CDX returns [[header], [url], ...]
        raw_urls = [row[0] for row in body[1:] if row and row[0].startswith("http")]

        # Filter extensions
        ext_re = re.compile(
            r"\.(" + "|".join(re.escape(e) for e in excluded_exts) + r")(\?|$)",
            re.IGNORECASE,
        )
        raw_urls = [u for u in raw_urls if not ext_re.search(u)]

        # Build fake stdout for parse_output
        pseudo_raw = "\n".join(raw_urls[:max_urls])
        return self.parse_output(pseudo_raw, max_urls=max_urls), ""

    @staticmethod
    def _empty() -> dict:
        return {"urls": [], "params": [], "param_map": {}, "count": 0}

    def _build_findings(self, data: dict) -> list[ParsedFinding]:
        findings = []
        for param in data.get("params", []):
            urls = data.get("param_map", {}).get(param, [])
            findings.append(ParsedFinding(
                finding_type="url_parameter", value=param,
                source=self.NAME, confidence=0.85,
                metadata={
                    "example_urls": urls[:3],
                    "occurrence_count": len(urls),
                },
            ))
        return findings
