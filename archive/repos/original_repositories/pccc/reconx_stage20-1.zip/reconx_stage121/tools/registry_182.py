"""
ReconX — Tool Registry (Stage 18.2)
Traffic Intelligence Layer Registration.
"""
from __future__ import annotations
import importlib
import logging

log = logging.getLogger("reconx.registry.182")

_STAGE182_SPEC = [
    ("TrafficIntelligenceTool", "network", {}),
]


def get_stage182_registry() -> dict:
    registry = {}
    for class_name, module_path, kwargs in _STAGE182_SPEC:
        try:
            mod  = importlib.import_module(f"reconx.{module_path}")
            cls  = getattr(mod, class_name)
            tool = cls(**kwargs)
            key  = getattr(cls, "NAME", class_name)
            registry[key] = tool
            log.debug("[Registry 18.2] Registered: %s", key)
        except Exception as exc:
            log.debug("[Registry 18.2] Could not load %s: %s", class_name, exc)
    return registry


def get_stage182_catalog() -> list[dict]:
    return [
        {
            "name":         "Traffic Intelligence",
            "class":        "TrafficIntelligenceTool",
            "module":       "reconx.network",
            "category":     "network_analysis",
            "stage":        2,
            "priority":     15,
            "passive":      True,
            "binary":       "tshark",
            "description": (
                "Packet-level traffic analysis via TShark/PyShark. "
                "Analyzes PCAP files or captures live traffic. Extracts protocols, "
                "hosts, credentials (masked), DNS intelligence, TLS fingerprints, "
                "and detects anomalies including beaconing, DNS tunneling, and "
                "data exfiltration signals."
            ),
            "capabilities": [
                "pcap_analysis", "live_capture", "protocol_detection",
                "credential_discovery", "dns_intelligence", "http_extraction",
                "tls_fingerprinting", "anomaly_detection", "beaconing_detection",
                "dns_tunnel_detection", "flow_reconstruction",
            ],
            "requires_root":     False,
            "requires_network":  False,
            "install_required":  True,
            "install_cmd": "sudo apt install tshark  |  brew install wireshark",
            "learning_yaml":     "knowledge/network/tshark.yaml",
            "recommended_after": ["nmap", "masscan", "rustscan"],
            "tags": [
                "pcap", "traffic", "tshark", "wireshark", "dns", "http",
                "tls", "anomaly", "credentials", "network", "passive", "live",
            ],
        }
    ]


def get_stage182_tool_chains() -> list[dict]:
    return [
        {
            "chain":       "network_intelligence",
            "description": "Packet-level network intelligence alongside port scanning",
            "steps": [
                {
                    "tool":       "Traffic Intelligence",
                    "tool_class": "TrafficIntelligenceTool",
                    "stage":      2,
                    "parallel_group": "network",
                    "why_next":   "Capture traffic during active scans for protocol and credential intelligence",
                },
            ],
        },
        {
            "chain":       "full_intelligence",
            "description": "Complete intelligence: traffic + web + Burp",
            "steps": [
                {
                    "tool":       "Traffic Intelligence",
                    "tool_class": "TrafficIntelligenceTool",
                    "stage":      2,
                    "parallel_group": "network",
                    "why_next":   "Packet-level visibility into all traffic",
                },
                {
                    "tool":       "Burp Suite",
                    "tool_class": "BurpIntelligenceLayer",
                    "stage":      4,
                    "parallel_group": None,
                    "why_next":   "HTTP-layer web intelligence on top of packet analysis",
                },
            ],
        },
    ]
