"""
ReconX — dnsenum wrapper.

Performs DNS brute-forcing, zone transfer checks, wildcard detection,
and Google scraping for subdomains.

Stage 2 — Active DNS Enumeration.
"""
from __future__ import annotations
import re
import time
from typing import Optional

from ..base import BaseTool
from ...models.tool_result import ParsedFinding, RunStatus, ToolRunResult


class DNSEnumTool(BaseTool):

    NAME         = "dnsenum"
    BINARY       = "dnsenum"
    CATEGORY     = "dns"
    STAGE        = 2
    PRIORITY     = 10
    PASSIVE      = False
    TIMEOUT      = 240
    DEPENDENCIES: list[str] = []
    INSTALL_CMD  = "sudo apt install dnsenum"

    # ── run ───────────────────────────────────────────────────────────────────

    def run(
        self,
        target: str,
        *,
        wordlist:    Optional[str] = None,
        threads:     int           = 20,
        dns_server:  Optional[str] = None,
        no_reverse:  bool          = True,
        no_scrape:   bool          = False,
        **kwargs,
    ) -> ToolRunResult:
        """
        Args:
            target:     Domain to enumerate.
            wordlist:   Path to subdomain wordlist for brute forcing.
            threads:    Brute-force thread count.
            dns_server: Custom DNS resolver (e.g. 8.8.8.8).
            no_reverse: Skip reverse lookups (faster).
            no_scrape:  Disable Google scraping.
        """
        if s := self.skip_if_unavailable():
            return s

        ttype = self.classify_target(target)
        if ttype != "domain":
            return self.fail("invalid_target",
                             f"dnsenum requires a domain. Got: {ttype} ({target})")

        args = [target, "--noreverse" if no_reverse else "",
                "-t", str(threads), "--nocolor"]

        if wordlist:
            args += ["-f", wordlist]
        if dns_server:
            args += ["--dnsserver", dns_server]
        if no_scrape:
            args.append("--noscrap")

        # Remove any empty strings from flag assembly
        args = [a for a in args if a]

        t0  = time.perf_counter()
        res = self.exec(args, timeout_s=float(self.timeout), expected_codes=(0, 1))
        dur = time.perf_counter() - t0

        if res.timed_out:
            return ToolRunResult.timeout(self.NAME, dur, self.timeout)
        if res.returncode == 127:
            return ToolRunResult.skipped(self.NAME, res.stderr)

        data     = self.parse_output(res.stdout)
        findings = self._build_findings(data)
        result   = self.build_result(
            data, findings, stdout=res.stdout, duration_s=dur, returncode=res.returncode
        )
        if not findings:
            result.status = RunStatus.NO_OUTPUT
        return result

    # ── parse_output ──────────────────────────────────────────────────────────

    def parse_output(self, raw: str, **kwargs) -> dict:
        if not raw.strip():
            return self._empty()

        subdomains:      list[str] = []
        zone_transfers:  list[str] = []
        mx_records:      list[str] = []
        ns_records:      list[str] = []
        ips:             list[str] = []
        zone_transfer_vulnerable = False

        ip_re     = re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b")
        host_re   = re.compile(r"\b([a-zA-Z0-9\-]+(?:\.[a-zA-Z0-9\-]+)+\.[a-zA-Z]{2,})\b")

        for line in raw.splitlines():
            lower = line.lower().strip()
            if not lower:
                continue

            # Zone transfer detection
            if "zone transfer" in lower:
                if "success" in lower or "worked" in lower:
                    zone_transfer_vulnerable = True
                    zone_transfers.append(line.strip())
                elif "failed" in lower or "refused" in lower:
                    zone_transfers.append(line.strip())

            # Record types
            if " mx " in lower or "mail exchanger" in lower:
                for m in host_re.findall(line):
                    mx_records.append(m)
            elif " ns " in lower or "name server" in lower:
                for m in host_re.findall(line):
                    ns_records.append(m)
            else:
                # Generic subdomains
                for m in host_re.findall(line):
                    subdomains.append(m)

            for ip in ip_re.findall(line):
                ips.append(ip)

        return {
            "subdomains":              sorted(set(subdomains)),
            "ips":                     sorted(set(ips)),
            "mx_records":              sorted(set(mx_records)),
            "ns_records":              sorted(set(ns_records)),
            "zone_transfers":          zone_transfers,
            "zone_transfer_vulnerable": zone_transfer_vulnerable,
            "count": {
                "subdomains": len(set(subdomains)),
                "ips":        len(set(ips)),
            },
        }

    # ── internal ──────────────────────────────────────────────────────────────

    @staticmethod
    def _empty() -> dict:
        return {
            "subdomains": [], "ips": [], "mx_records": [], "ns_records": [],
            "zone_transfers": [], "zone_transfer_vulnerable": False,
            "count": {"subdomains": 0, "ips": 0},
        }

    def _build_findings(self, data: dict) -> list[ParsedFinding]:
        findings = []
        for sub in data.get("subdomains", []):
            findings.append(ParsedFinding(
                finding_type="subdomain", value=sub,
                source=self.NAME, confidence=0.85,
            ))
        for ip in data.get("ips", []):
            findings.append(ParsedFinding(
                finding_type="ip", value=ip,
                source=self.NAME, confidence=0.9,
            ))
        if data.get("zone_transfer_vulnerable"):
            findings.append(ParsedFinding(
                finding_type="vulnerability", value="zone_transfer_exposed",
                source=self.NAME, confidence=1.0,
                metadata={"severity": "HIGH", "description": "DNS zone transfer is allowed"},
            ))
        return findings
