"""
ReconX — dnsrecon wrapper.

Comprehensive DNS record enumeration: A, AAAA, MX, SOA, NS, TXT, SRV,
zone transfers, reverse lookups, and cache snooping detection.

Stage 2 — Active DNS Enumeration.
"""
from __future__ import annotations
import json
import re
import time
from typing import Optional

from ..base import BaseTool
from ...models.tool_result import ParsedFinding, RunStatus, ToolRunResult


class DNSReconTool(BaseTool):

    NAME         = "dnsrecon"
    BINARY       = "dnsrecon"
    CATEGORY     = "dns"
    STAGE        = 2
    PRIORITY     = 15
    PASSIVE      = False
    TIMEOUT      = 180
    DEPENDENCIES: list[str] = []
    INSTALL_CMD  = "sudo apt install dnsrecon  # or: pip install dnsrecon"

    # ── run ───────────────────────────────────────────────────────────────────

    def run(
        self,
        target: str,
        *,
        scan_types:  Optional[list[str]] = None,
        wordlist:    Optional[str]        = None,
        threads:     int                  = 16,
        dns_server:  Optional[str]        = None,
        lifetime:    int                  = 3,
        **kwargs,
    ) -> ToolRunResult:
        """
        Args:
            target:      Domain or IP range to enumerate.
            scan_types:  dnsrecon -t types: std, axfr, brt, srv, rvl, etc.
                         Default: ['std', 'axfr', 'srv'].
            wordlist:    Path to brute-force wordlist (used with -t brt).
            threads:     Thread count for brute-force.
            dns_server:  Custom resolver.
            lifetime:    DNS query lifetime in seconds.
        """
        if s := self.skip_if_unavailable():
            return s
        if f := self.validate_or_fail(target):
            return f

        types = scan_types or ["std", "axfr", "srv"]

        args = [
            "-d", target,
            "-t", ",".join(types),
            "--lifetime", str(lifetime),
            "--threads", str(threads),
            "-j", "/tmp/dnsrecon_out.json",   # JSON output for reliable parsing
        ]
        if wordlist:
            args += ["-D", wordlist]
        if dns_server:
            args += ["-n", dns_server]

        t0  = time.perf_counter()
        res = self.exec(args, timeout_s=float(self.timeout), expected_codes=(0, 1))
        dur = time.perf_counter() - t0

        if res.timed_out:
            return ToolRunResult.timeout(self.NAME, dur, self.timeout)
        if res.returncode == 127:
            return ToolRunResult.skipped(self.NAME, res.stderr)

        # Prefer JSON file output for structured parsing
        raw_json = self._read_json_output("/tmp/dnsrecon_out.json")
        data = (self._parse_json(raw_json) if raw_json
                else self.parse_output(res.stdout))

        findings = self._build_findings(data)
        result   = self.build_result(
            data, findings, stdout=res.stdout, duration_s=dur, returncode=res.returncode
        )
        if not findings:
            result.status = RunStatus.NO_OUTPUT
        return result

    # ── parse_output ──────────────────────────────────────────────────────────

    def parse_output(self, raw: str, **kwargs) -> dict:
        """Fallback text parser for dnsrecon console output."""
        if not raw.strip():
            return self._empty()

        records: dict[str, list] = {
            "A": [], "AAAA": [], "MX": [], "NS": [], "TXT": [],
            "SOA": [], "SRV": [], "CNAME": [], "PTR": [],
        }
        zone_transfer_vulnerable = False
        subdomains: list[str] = []
        ips:        list[str] = []

        ip_re   = re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b")
        host_re = re.compile(r"\b([a-zA-Z0-9\-]+(?:\.[a-zA-Z0-9\-]+)+\.[a-zA-Z]{2,})\b")

        for line in raw.splitlines():
            stripped = line.strip()
            if not stripped:
                continue
            lower = stripped.lower()

            if "zone transfer" in lower and ("success" in lower or "complete" in lower):
                zone_transfer_vulnerable = True

            for rtype in records:
                if f" {rtype} " in stripped or stripped.startswith(f"[*] {rtype} "):
                    hosts_found = host_re.findall(stripped)
                    ips_found   = ip_re.findall(stripped)
                    for h in hosts_found:
                        records[rtype].append(h)
                        if rtype in ("A", "CNAME", "PTR"):
                            subdomains.append(h)
                    for ip in ips_found:
                        ips.append(ip)
                    break

        # Deduplicate
        for k in records:
            records[k] = sorted(set(records[k]))

        return {
            "records":                 records,
            "subdomains":              sorted(set(subdomains)),
            "ips":                     sorted(set(ips)),
            "zone_transfer_vulnerable": zone_transfer_vulnerable,
            "count":                   sum(len(v) for v in records.values()),
        }

    # ── internal ──────────────────────────────────────────────────────────────

    @staticmethod
    def _read_json_output(path: str) -> Optional[list]:
        import os
        try:
            if os.path.exists(path):
                with open(path) as fh:
                    data = json.load(fh)
                os.unlink(path)
                return data
        except Exception:
            pass
        return None

    def _parse_json(self, records: list) -> dict:
        """Parse dnsrecon's native JSON output format."""
        by_type:    dict[str, list] = {}
        subdomains: list[str]       = []
        ips:        list[str]       = []
        zone_transfer_vulnerable    = False

        for rec in records:
            rtype = rec.get("type", "UNKNOWN")
            name  = rec.get("name", "")
            addr  = rec.get("address", rec.get("target", ""))

            by_type.setdefault(rtype, [])
            if name:
                by_type[rtype].append(name)
                if rtype in ("A", "CNAME", "PTR"):
                    subdomains.append(name)
            if addr:
                if re.match(r"^\d{1,3}(?:\.\d{1,3}){3}$", addr):
                    ips.append(addr)

            if rtype == "AXFR" and rec.get("zone_transfer"):
                zone_transfer_vulnerable = True

        for k in by_type:
            by_type[k] = sorted(set(by_type[k]))

        return {
            "records":                 by_type,
            "subdomains":              sorted(set(subdomains)),
            "ips":                     sorted(set(ips)),
            "zone_transfer_vulnerable": zone_transfer_vulnerable,
            "count":                   sum(len(v) for v in by_type.values()),
        }

    @staticmethod
    def _empty() -> dict:
        return {
            "records": {}, "subdomains": [], "ips": [],
            "zone_transfer_vulnerable": False, "count": 0,
        }

    def _build_findings(self, data: dict) -> list[ParsedFinding]:
        findings = []
        for sub in data.get("subdomains", []):
            findings.append(ParsedFinding(
                finding_type="subdomain", value=sub,
                source=self.NAME, confidence=0.9,
            ))
        for ip in data.get("ips", []):
            findings.append(ParsedFinding(
                finding_type="ip", value=ip,
                source=self.NAME, confidence=0.95,
            ))
        if data.get("zone_transfer_vulnerable"):
            findings.append(ParsedFinding(
                finding_type="vulnerability",
                value="DNS_ZONE_TRANSFER_ALLOWED",
                source=self.NAME, confidence=1.0,
                metadata={"severity": "HIGH",
                          "description": "Zone transfer (AXFR) permitted — leaks entire DNS zone."},
            ))
        # Surface TXT records (SPF, DMARC misconfigs, juicy info)
        for txt in data.get("records", {}).get("TXT", []):
            findings.append(ParsedFinding(
                finding_type="dns_txt_record", value=txt,
                source=self.NAME, confidence=1.0,
            ))
        return findings
