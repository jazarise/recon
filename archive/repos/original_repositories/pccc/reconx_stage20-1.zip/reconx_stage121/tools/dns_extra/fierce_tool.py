"""
ReconX — fierce DNS reconnaissance wrapper.

Fierce is a DNS reconnaissance tool designed to locate non-contiguous
IP space and hostnames against specified domains. Particularly effective
at finding hidden targets beyond the primary domain.

Stage 2 — Active DNS / Subdomain Discovery.
"""
from __future__ import annotations
import re
import time
from typing import Optional

from ..base import BaseTool
from ...models.tool_result import ParsedFinding, RunStatus, ToolRunResult


class FierceTool(BaseTool):

    NAME         = "fierce"
    BINARY       = "fierce"
    CATEGORY     = "dns"
    STAGE        = 2
    PRIORITY     = 20
    PASSIVE      = False
    TIMEOUT      = 180
    DEPENDENCIES: list[str] = []
    INSTALL_CMD  = "sudo apt install fierce  # or: pip install fierce"

    # ── run ───────────────────────────────────────────────────────────────────

    def run(
        self,
        target: str,
        *,
        wordlist:   Optional[str] = None,
        threads:    int           = 5,
        dns_server: Optional[str] = None,
        delay:      float         = 0.0,
        subdomain_file: Optional[str] = None,
        **kwargs,
    ) -> ToolRunResult:
        """
        Args:
            target:         Domain to scan.
            wordlist:       Custom brute-force subdomain list.
            threads:        Concurrent DNS resolution threads.
            dns_server:     Custom DNS resolver.
            delay:          Delay between queries in seconds (stealth).
            subdomain_file: Use a different subdomains file.
        """
        if s := self.skip_if_unavailable():
            return s

        ttype = self.classify_target(target)
        if ttype != "domain":
            return self.fail("invalid_target",
                             f"fierce requires a domain. Got: {ttype} ({target})")

        args = ["--domain", target, "--threads", str(threads)]

        if wordlist:
            args += ["--wordlist", wordlist]
        elif subdomain_file:
            args += ["--subdomains", subdomain_file]

        if dns_server:
            args += ["--dns-servers", dns_server]
        if delay > 0:
            args += ["--delay", str(delay)]

        t0  = time.perf_counter()
        res = self.exec(args, timeout_s=float(self.timeout), expected_codes=(0, 1))
        dur = time.perf_counter() - t0

        if res.timed_out:
            return ToolRunResult.timeout(self.NAME, dur, self.timeout)
        if res.returncode == 127:
            return ToolRunResult.skipped(self.NAME, res.stderr)

        data     = self.parse_output(res.stdout)
        findings = self._build_findings(data)
        result   = self.build_result(
            data, findings, stdout=res.stdout, duration_s=dur, returncode=res.returncode
        )
        if not findings:
            result.status = RunStatus.NO_OUTPUT
        return result

    # ── parse_output ──────────────────────────────────────────────────────────

    def parse_output(self, raw: str, **kwargs) -> dict:
        """
        Fierce output format (v2+):
          NS: ns1.example.com.
          SOA: ns1.example.com (93.184.216.34)
          Zone: DNSSEC signing disabled
          Wildcard: *.example.com → 93.184.216.34
          Found: sub.example.com (93.184.216.34)
          ...
        """
        if not raw.strip():
            return self._empty()

        subdomains: list[str] = []
        ips:        list[str] = []
        ns_records: list[str] = []
        wildcard:   Optional[str] = None
        zone_info:  list[str] = []

        ip_re   = re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b")
        host_re = re.compile(r"\b([a-zA-Z0-9\-]+(?:\.[a-zA-Z0-9\-]+)+\.[a-zA-Z]{2,})\b")

        for line in raw.splitlines():
            stripped = line.strip()
            lower    = stripped.lower()
            if not stripped:
                continue

            if stripped.startswith("Found:"):
                # "Found: sub.example.com (93.184.216.34)"
                hosts = host_re.findall(stripped)
                found_ips = ip_re.findall(stripped)
                subdomains.extend(hosts)
                ips.extend(found_ips)

            elif stripped.startswith("NS:"):
                for h in host_re.findall(stripped):
                    ns_records.append(h)

            elif "wildcard" in lower:
                wc_hosts = host_re.findall(stripped)
                if wc_hosts:
                    wildcard = wc_hosts[0]

            elif stripped.startswith("Zone:") or stripped.startswith("SOA:"):
                zone_info.append(stripped)
            else:
                # Catch any missed host/IP pairs
                for h in host_re.findall(stripped):
                    if h not in subdomains:
                        subdomains.append(h)
                for ip in ip_re.findall(stripped):
                    if ip not in ips:
                        ips.append(ip)

        return {
            "subdomains": sorted(set(subdomains)),
            "ips":        sorted(set(ips)),
            "ns_records": sorted(set(ns_records)),
            "wildcard":   wildcard,
            "zone_info":  zone_info,
            "count":      len(set(subdomains)),
        }

    # ── internal ──────────────────────────────────────────────────────────────

    @staticmethod
    def _empty() -> dict:
        return {
            "subdomains": [], "ips": [], "ns_records": [],
            "wildcard": None, "zone_info": [], "count": 0,
        }

    def _build_findings(self, data: dict) -> list[ParsedFinding]:
        findings = []
        for sub in data.get("subdomains", []):
            findings.append(ParsedFinding(
                finding_type="subdomain", value=sub,
                source=self.NAME, confidence=0.88,
            ))
        for ip in data.get("ips", []):
            findings.append(ParsedFinding(
                finding_type="ip", value=ip,
                source=self.NAME, confidence=0.9,
            ))
        if data.get("wildcard"):
            findings.append(ParsedFinding(
                finding_type="dns_wildcard",
                value=data["wildcard"],
                source=self.NAME, confidence=1.0,
                metadata={"note": "Wildcard DNS detected — subdomain bruteforce may yield false positives"},
            ))
        return findings
