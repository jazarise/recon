"""
ReconX — Sublist3r wrapper.

Sublist3r is a fast passive subdomain enumeration tool using multiple
search engines and OSINT sources: Google, Bing, Yahoo, Baidu, Ask,
Netcraft, VirusTotal, ThreatCrowd, DNSdumpster, ReverseDNS.

Stage 1 — Passive Subdomain Enumeration (no target traffic).
"""
from __future__ import annotations
import re
import time
from typing import Optional

from ..base import BaseTool
from ...models.tool_result import ParsedFinding, RunStatus, ToolRunResult


class Sublist3rTool(BaseTool):

    NAME         = "Sublist3r"
    BINARY       = "sublist3r"
    CATEGORY     = "subdomain"
    STAGE        = 1
    PRIORITY     = 8
    PASSIVE      = True
    TIMEOUT      = 180
    DEPENDENCIES: list[str] = []
    INSTALL_CMD  = "sudo apt install sublist3r  # or: pip install sublist3r"

    # ── run ───────────────────────────────────────────────────────────────────

    def run(
        self,
        target: str,
        *,
        engines:   Optional[list[str]] = None,
        threads:   int                  = 20,
        bruteforce: bool                = False,
        wordlist:  Optional[str]        = None,
        ports:     Optional[list[int]]  = None,
        verbose:   bool                 = False,
        **kwargs,
    ) -> ToolRunResult:
        """
        Args:
            target:     Domain to enumerate subdomains for.
            engines:    List of search engine slugs to use (default: all).
            threads:    Thread count for concurrent source queries.
            bruteforce: Enable DNS brute-force via subbrute (-b flag).
            wordlist:   Wordlist for brute-force (requires bruteforce=True).
            ports:      Scan discovered subdomains on these ports.
            verbose:    Enable verbose output.
        """
        if s := self.skip_if_unavailable():
            return s

        ttype = self.classify_target(target)
        if ttype != "domain":
            return self.fail("invalid_target",
                             f"Sublist3r requires a domain. Got: {ttype} ({target})")

        args = ["-d", target, "-t", str(threads), "-o", "/tmp/sublist3r_out.txt"]

        if engines:
            args += ["-e", ",".join(engines)]
        if bruteforce:
            args.append("-b")
            if wordlist:
                args += ["-w", wordlist]
        if ports:
            args += ["-p", ",".join(str(p) for p in ports)]
        if verbose:
            args.append("-v")

        # Suppress color / ANSI codes for clean parsing
        args.append("--no-color") if "--no-color" in self._get_help_flags() else None

        t0  = time.perf_counter()
        res = self.exec(args, timeout_s=float(self.timeout), expected_codes=(0, 1))
        dur = time.perf_counter() - t0

        if res.timed_out:
            return ToolRunResult.timeout(self.NAME, dur, self.timeout)
        if res.returncode == 127:
            return ToolRunResult.skipped(self.NAME, res.stderr)

        # Prefer file output — cleaner than console
        file_data  = self._read_output_file("/tmp/sublist3r_out.txt")
        raw_source = file_data if file_data else res.stdout

        data     = self.parse_output(raw_source)
        findings = self._build_findings(data)
        result   = self.build_result(
            data, findings, stdout=res.stdout, duration_s=dur, returncode=res.returncode
        )
        if not findings:
            result.status = RunStatus.NO_OUTPUT
        return result

    # ── parse_output ──────────────────────────────────────────────────────────

    def parse_output(self, raw: str, **kwargs) -> dict:
        """
        Sublist3r outputs one subdomain per line in file mode.
        Console mode has progress/source banners — strip them.
        """
        if not raw.strip():
            return {"subdomains": [], "count": 0}

        # Remove ANSI codes
        ansi_re = re.compile(r"\x1b\[[0-9;]*[A-Za-z]")
        clean   = ansi_re.sub("", raw)

        subdomains: list[str] = []
        domain_re = re.compile(
            r"\b([a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?"
            r"(?:\.[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?)+\.[a-zA-Z]{2,})\b"
        )

        # Skip obvious banner/info lines
        skip_patterns = re.compile(
            r"(sublist3r|coded|searching|total|unique|found|error|warning|"
            r"\[\+\]|\[-\]|\[!\]|https?://|version)",
            re.IGNORECASE,
        )

        for line in clean.splitlines():
            line = line.strip()
            if not line or skip_patterns.search(line):
                continue
            for match in domain_re.findall(line):
                subdomains.append(match[0] if isinstance(match, tuple) else match)

        unique = sorted(set(subdomains))
        return {"subdomains": unique, "count": len(unique)}

    # ── internal ──────────────────────────────────────────────────────────────

    def _get_help_flags(self) -> list[str]:
        """Probe tool's help output to discover supported flags."""
        try:
            res = self.exec(["--help"], timeout_s=5, expected_codes=(0, 1, 2))
            return res.stdout + res.stderr
        except Exception:
            return ""

    @staticmethod
    def _read_output_file(path: str) -> str:
        import os
        try:
            if os.path.exists(path):
                content = open(path).read()
                os.unlink(path)
                return content
        except Exception:
            pass
        return ""

    def _build_findings(self, data: dict) -> list[ParsedFinding]:
        return [
            ParsedFinding(
                finding_type="subdomain", value=sub,
                source=self.NAME, confidence=0.82,
            )
            for sub in data.get("subdomains", [])
        ]
