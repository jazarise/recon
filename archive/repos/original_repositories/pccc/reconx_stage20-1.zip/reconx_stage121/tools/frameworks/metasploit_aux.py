"""
ReconX — Metasploit Auxiliary Scanner integration.

STRICT SCOPE: enumeration and fingerprinting auxiliary modules ONLY.
No exploitation, no payloads. Uses msfconsole -x for headless execution.

Supported module categories:
  scanner/http  — HTTP server fingerprinting, header analysis
  scanner/smb   — SMB version, share enumeration
  scanner/ssh   — SSH version, auth methods
  scanner/ftp   — FTP banner, anonymous access

Stage 3 — Active Service Fingerprinting.
"""
from __future__ import annotations
import re
import time
from typing import Optional

from ..base import BaseTool
from ...models.tool_result import ParsedFinding, RunStatus, ToolRunResult


# Allowlist: only safe, non-destructive auxiliary modules
_ALLOWED_MODULES: dict[str, list[str]] = {
    "http": [
        "auxiliary/scanner/http/http_version",
        "auxiliary/scanner/http/title",
        "auxiliary/scanner/http/options",
        "auxiliary/scanner/http/robots_txt",
    ],
    "smb": [
        "auxiliary/scanner/smb/smb_version",
        "auxiliary/scanner/smb/smb_enumshares",
        "auxiliary/scanner/smb/smb2",
    ],
    "ssh": [
        "auxiliary/scanner/ssh/ssh_version",
        "auxiliary/scanner/ssh/ssh_identify_pubkeys",
    ],
    "ftp": [
        "auxiliary/scanner/ftp/ftp_version",
        "auxiliary/scanner/ftp/anonymous",
    ],
}

# Hard block — never run these regardless of user input
_BLOCKED_KEYWORDS = [
    "exploit", "payload", "meterpreter", "shell", "reverse",
    "bind", "backdoor", "overflow", "exec", "upload", "post/",
]


class MetasploitAuxTool(BaseTool):

    NAME         = "MetasploitAux"
    BINARY       = "msfconsole"
    CATEGORY     = "framework"
    STAGE        = 3
    PRIORITY     = 40
    PASSIVE      = False
    TIMEOUT      = 180
    DEPENDENCIES: list[str] = []
    INSTALL_CMD  = "sudo apt install metasploit-framework"

    # ── run ───────────────────────────────────────────────────────────────────

    def run(
        self,
        target: str,
        *,
        services: Optional[list[str]] = None,
        ports:    Optional[dict[str, list[int]]] = None,
        threads:  int = 5,
        **kwargs,
    ) -> ToolRunResult:
        """
        Args:
            target:   Target IP or hostname.
            services: Categories to run: ['http','smb','ssh','ftp'].
                      Defaults to all four.
            ports:    Override default ports per service:
                      {'http': [80, 8080], 'smb': [445]}.
            threads:  Concurrent threads per module (THREADS option).
        """
        if s := self.skip_if_unavailable():
            return s
        if f := self.validate_or_fail(target):
            return f

        selected = services or list(_ALLOWED_MODULES.keys())
        default_ports: dict[str, list[int]] = {
            "http": [80, 443, 8080, 8443],
            "smb":  [445, 139],
            "ssh":  [22],
            "ftp":  [21],
        }
        port_map = {**default_ports, **(ports or {})}

        # Build msfconsole RC script
        rc_lines: list[str] = []
        for svc in selected:
            for module in _ALLOWED_MODULES.get(svc, []):
                if self._is_blocked(module):
                    self._log("warning", f"Blocked module skipped: {module}")
                    continue
                for port in port_map.get(svc, []):
                    rc_lines += [
                        f"use {module}",
                        f"set RHOSTS {target}",
                        f"set RPORT {port}",
                        f"set THREADS {threads}",
                        "run -j",   # run as job (non-blocking)
                        "jobs -i 0 2>/dev/null || true",  # wait for job
                    ]
        rc_lines.append("exit -y")

        rc_script = "\n".join(rc_lines)
        rc_path   = "/tmp/reconx_msf.rc"
        with open(rc_path, "w") as fh:
            fh.write(rc_script)

        args = ["-q", "-r", rc_path, "--no-readline"]

        t0  = time.perf_counter()
        res = self.exec(args, timeout_s=float(self.timeout), expected_codes=(0, 1))
        dur = time.perf_counter() - t0

        # Cleanup
        import os
        try:
            os.unlink(rc_path)
        except Exception:
            pass

        if res.timed_out:
            return ToolRunResult.timeout(self.NAME, dur, self.timeout)
        if res.returncode == 127:
            return ToolRunResult.skipped(self.NAME, res.stderr)

        data     = self.parse_output(res.stdout)
        findings = self._build_findings(data)
        result   = self.build_result(
            data, findings, stdout=res.stdout, duration_s=dur, returncode=res.returncode,
        )
        if not findings:
            result.status = RunStatus.NO_OUTPUT
        return result

    # ── parse_output ──────────────────────────────────────────────────────────

    def parse_output(self, raw: str, **kwargs) -> dict:
        if not raw.strip():
            return {"findings": [], "modules_run": [], "count": 0}

        findings:    list[dict] = []
        modules_run: list[str]  = []
        ansi_re      = re.compile(r"\x1b\[[0-9;]*[A-Za-z]")

        current_module = ""

        for line in raw.splitlines():
            clean = ansi_re.sub("", line).strip()
            if not clean:
                continue

            # Module tracking
            if clean.startswith("msf") and "use " in clean:
                m = re.search(r"use\s+(auxiliary/\S+)", clean)
                if m:
                    current_module = m.group(1)
                    if current_module not in modules_run:
                        modules_run.append(current_module)

            # Success / result lines
            if "[+]" in clean or "[*]" in clean:
                findings.append({
                    "module":  current_module,
                    "message": clean,
                    "type":    self._classify_msf_line(clean),
                })

        return {"findings": findings, "modules_run": modules_run, "count": len(findings)}

    # ── internal ──────────────────────────────────────────────────────────────

    @staticmethod
    def _is_blocked(module: str) -> bool:
        return any(kw in module.lower() for kw in _BLOCKED_KEYWORDS)

    @staticmethod
    def _classify_msf_line(line: str) -> str:
        low = line.lower()
        if "version" in low:
            return "version_info"
        if "anon" in low or "anonymous" in low:
            return "anonymous_access"
        if "share" in low:
            return "smb_share"
        if "title" in low:
            return "web_title"
        if "robot" in low:
            return "robots_txt"
        return "info"

    def _build_findings(self, data: dict) -> list[ParsedFinding]:
        findings = []
        for f in data.get("findings", []):
            findings.append(ParsedFinding(
                finding_type=f.get("type", "info"),
                value=f.get("message", ""),
                source=self.NAME,
                confidence=0.85,
                metadata={"module": f.get("module", "")},
            ))
        return findings
