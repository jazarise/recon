"""
ReconX — Framework integration tools (Stage 12.1).
"""
from .metasploit_aux import MetasploitAuxTool

__all__ = ["MetasploitAuxTool"]
