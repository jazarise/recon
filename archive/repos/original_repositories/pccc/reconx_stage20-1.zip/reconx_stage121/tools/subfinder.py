"""
ReconX — Subfinder tool wrapper (standardized).
Passive subdomain enumeration from 40+ OSINT sources.
"""
from __future__ import annotations
import time
from typing import Optional

from .base import BaseTool
from ..models.tool_result import ParsedFinding, ToolRunResult


class SubfinderTool(BaseTool):

    NAME         = "Subfinder"
    BINARY       = "subfinder"
    CATEGORY     = "subdomain"
    STAGE        = 2
    PRIORITY     = 10
    PASSIVE      = True
    TIMEOUT      = 120
    DEPENDENCIES : list[str] = []
    INSTALL_CMD  = "go install github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest"

    # ── run ───────────────────────────────────────────────────────────────────

    def run(self, target: str, **kwargs) -> ToolRunResult:
        # 1. Availability
        skip = self.skip_if_unavailable()
        if skip:
            return skip

        # 2. Validation — subfinder needs a domain, not an IP/URL
        t = self.classify_target(target)
        if t not in ("domain",):
            if t == "ip":
                return self.fail(
                    "invalid_target",
                    f"Subfinder requires a domain, not an IP: {target}",
                )
            fail = self.validate_or_fail(target)
            if fail:
                return fail

        # 3. Execute
        t0  = time.perf_counter()
        res = self.exec(
            ["-d", target, "-silent", "-oJ"],
            timeout_s=float(self.timeout),
        )
        duration = time.perf_counter() - t0

        if res.timed_out:
            return ToolRunResult.timeout(self.NAME, duration, self.timeout)

        if res.returncode == 127:
            return ToolRunResult.skipped(self.NAME, res.stderr)

        if res.returncode not in (0, 1) and not res.stdout.strip():
            # subfinder can return non-zero but still produce valid output
            return self.fail(
                "subprocess_error",
                f"Exit code {res.returncode}",
                stderr=res.stderr,
                duration_s=duration,
            )

        # 4. Parse
        data     = self.parse_output(res.stdout)
        findings = self._make_findings(data["subdomains"])

        if not data["subdomains"] and not res.stderr.strip():
            from ..models.tool_result import RunStatus
            result = self.build_result(data, findings,
                                        stdout=res.stdout, duration_s=duration)
            result.status = RunStatus.NO_OUTPUT
            return result

        return self.build_result(
            data, findings,
            stdout=res.stdout, stderr=res.stderr,
            duration_s=duration, returncode=res.returncode,
        )

    # ── parse_output ──────────────────────────────────────────────────────────

    def parse_output(self, raw: str, **kwargs) -> dict:
        """
        Parse subfinder -oJ output.
        Falls back to plain-line parsing if JSON lines fail.
        """
        if not raw.strip():
            return {"subdomains": []}

        # Try JSON-lines first (preferred: source attribution available)
        subdomains = self.parse_subfinder_json(raw)

        if not subdomains:
            # Fallback: each line is a plain hostname
            subdomains = [
                line.strip().lower()
                for line in self.parse_lines_output(raw)
                if "." in line and " " not in line.strip()
            ]

        return {"subdomains": list(dict.fromkeys(subdomains))}

    # ── private ───────────────────────────────────────────────────────────────

    def _make_findings(self, subdomains: list[str]) -> list[ParsedFinding]:
        return self._findings_from_list(subdomains, "subdomain")
