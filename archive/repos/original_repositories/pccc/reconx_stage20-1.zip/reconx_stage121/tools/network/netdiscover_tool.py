"""
ReconX — netdiscover wrapper.

Netdiscover is an ARP reconnaissance tool for local network host
discovery. Reveals live hosts, MAC addresses, and vendor info.
Requires root/CAP_NET_RAW. Operates entirely at Layer 2 (no IP traffic).

Stage 2 — Active Network Discovery (local segment).
"""
from __future__ import annotations
import re
import time
from ipaddress import ip_network
from typing import Optional

from ..base import BaseTool
from ...models.tool_result import ParsedFinding, RunStatus, ToolRunResult


class NetdiscoverTool(BaseTool):

    NAME         = "netdiscover"
    BINARY       = "netdiscover"
    CATEGORY     = "network"
    STAGE        = 2
    PRIORITY     = 10
    PASSIVE      = False
    TIMEOUT      = 60
    DEPENDENCIES: list[str] = []
    INSTALL_CMD  = "sudo apt install netdiscover"

    # ── run ───────────────────────────────────────────────────────────────────

    def run(
        self,
        target: str,
        *,
        interface:   Optional[str] = None,
        passive:     bool          = False,
        count:       int           = 0,
        retry:       int           = 3,
        **kwargs,
    ) -> ToolRunResult:
        """
        Args:
            target:     CIDR range (e.g. 192.168.1.0/24) or single IP.
            interface:  Network interface to use (e.g. eth0).
            passive:    Passive ARP sniff mode — don't send probes.
            count:      Stop after N ARP packets (0 = unlimited/timeout-driven).
            retry:      ARP retry count per host.
        """
        if s := self.skip_if_unavailable():
            return s

        # Validate CIDR or treat as single host
        try:
            net = ip_network(target, strict=False)
            cidr_target = str(net)
        except ValueError:
            cidr_target = target

        args = ["-r", cidr_target, "-P", "-N"]   # -P: print to stdout, -N: no header
        if interface:
            args += ["-i", interface]
        if passive:
            args.append("-p")
        if retry != 3:
            args += ["-s", str(retry)]
        if count:
            args += ["-c", str(count)]

        t0  = time.perf_counter()
        res = self.exec(args, timeout_s=float(self.timeout), expected_codes=(0, 1))
        dur = time.perf_counter() - t0

        if res.timed_out:
            # Timeout is normal for passive mode — parse whatever we captured
            data     = self.parse_output(res.stdout or "")
            findings = self._build_findings(data)
            result   = self.build_result(
                data, findings, stdout=res.stdout, duration_s=dur, returncode=0,
            )
            result.notes = "Scan stopped at timeout — partial results captured."
            return result

        if res.returncode == 127:
            return ToolRunResult.skipped(self.NAME, res.stderr)

        data     = self.parse_output(res.stdout)
        findings = self._build_findings(data)
        result   = self.build_result(
            data, findings, stdout=res.stdout, duration_s=dur, returncode=res.returncode,
        )
        if not findings:
            result.status = RunStatus.NO_OUTPUT
        return result

    # ── parse_output ──────────────────────────────────────────────────────────

    def parse_output(self, raw: str, **kwargs) -> dict:
        """
        Netdiscover -P output format:
          192.168.1.1     00:11:22:33:44:55      1      60  ASUS
          192.168.1.10    aa:bb:cc:dd:ee:ff      1      60  Unknown
        """
        if not raw.strip():
            return {"hosts": [], "count": 0}

        hosts: list[dict] = []
        ip_re  = re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b")
        mac_re = re.compile(r"\b(?:[0-9A-Fa-f]{2}[:\-]){5}[0-9A-Fa-f]{2}\b")

        for line in raw.splitlines():
            line = line.strip()
            if not line or line.startswith("#") or line.startswith("IP"):
                continue

            ips  = ip_re.findall(line)
            macs = mac_re.findall(line)
            if not ips:
                continue

            ip  = ips[0]
            mac = macs[0] if macs else "unknown"

            # Vendor is typically the remainder after IP and MAC
            vendor = ""
            if mac != "unknown":
                after_mac = line.split(mac, 1)[-1].strip()
                # Skip count and bytes columns (digits)
                parts = after_mac.split()
                vendor_parts = [p for p in parts if not p.isdigit()]
                vendor = " ".join(vendor_parts) if vendor_parts else ""

            hosts.append({
                "ip":      ip,
                "mac":     mac.upper(),
                "vendor":  vendor,
                "latency": None,    # netdiscover doesn't report latency
            })

        return {"hosts": hosts, "count": len(hosts)}

    # ── internal ──────────────────────────────────────────────────────────────

    def _build_findings(self, data: dict) -> list[ParsedFinding]:
        findings = []
        for host in data.get("hosts", []):
            findings.append(ParsedFinding(
                finding_type="live_host",
                value=host["ip"],
                source=self.NAME,
                confidence=0.97,          # ARP is near-definitive on LAN
                metadata={
                    "mac":    host["mac"],
                    "vendor": host["vendor"],
                    "method": "arp",
                },
            ))
        return findings
