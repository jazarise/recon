"""
ReconX — fping wrapper.

fping is a high-performance ICMP echo (ping) tool designed for
sweeping entire network ranges simultaneously. Faster than nmap -sn
for pure host-alive checking. Reports latency per host.

Stage 2 — Active Network Discovery.
"""
from __future__ import annotations
import re
import time
from ipaddress import ip_network
from typing import Optional

from ..base import BaseTool
from ...models.tool_result import ParsedFinding, RunStatus, ToolRunResult


class FpingTool(BaseTool):

    NAME         = "fping"
    BINARY       = "fping"
    CATEGORY     = "network"
    STAGE        = 2
    PRIORITY     = 8
    PASSIVE      = False
    TIMEOUT      = 90
    DEPENDENCIES: list[str] = []
    INSTALL_CMD  = "sudo apt install fping"

    # ── run ───────────────────────────────────────────────────────────────────

    def run(
        self,
        target: str,
        *,
        count:      int   = 3,
        interval:   int   = 10,    # ms between probes per host
        timeout:    int   = 500,   # ms wait per probe
        retry:      int   = 1,
        quiet:      bool  = False,
        alive_only: bool  = True,
        **kwargs,
    ) -> ToolRunResult:
        """
        Args:
            target:     CIDR range, single IP, or space-separated IPs.
            count:      Number of ICMP probes per host.
            interval:   Interval between probes per host (ms).
            timeout:    Per-probe timeout (ms).
            retry:      Retransmit count on no-reply.
            quiet:      Suppress per-packet output.
            alive_only: Only print alive hosts (-a flag).
        """
        if s := self.skip_if_unavailable():
            return s

        # Resolve CIDR → fping -g flag for range sweeps
        targets, gen_flag = self._resolve_target(target)

        args = ["-c", str(count), "-i", str(interval), "-t", str(timeout),
                "-r", str(retry), "-e",   # -e: show elapsed times
                "-A"]                      # -A: show targets as addresses

        if alive_only:
            args.append("-a")
        if quiet:
            args.append("-q")

        args += gen_flag + targets

        t0  = time.perf_counter()
        res = self.exec(args, timeout_s=float(self.timeout), expected_codes=(0, 1, 2))
        dur = time.perf_counter() - t0

        if res.timed_out:
            return ToolRunResult.timeout(self.NAME, dur, self.timeout)
        if res.returncode == 127:
            return ToolRunResult.skipped(self.NAME, res.stderr)

        # fping reports alive on stdout, dead/stats on stderr
        combined = (res.stdout or "") + "\n" + (res.stderr or "")
        data     = self.parse_output(combined, alive_only=alive_only)
        findings = self._build_findings(data)
        result   = self.build_result(
            data, findings, stdout=res.stdout, duration_s=dur, returncode=res.returncode,
        )
        if not findings:
            result.status = RunStatus.NO_OUTPUT
        return result

    # ── parse_output ──────────────────────────────────────────────────────────

    def parse_output(self, raw: str, alive_only: bool = True, **kwargs) -> dict:
        """
        fping output examples:
          192.168.1.1 is alive (1.23 ms)
          192.168.1.5 is unreachable
          192.168.1.1 : [0], 64 bytes, 1.23 ms (1.23 avg, 0% loss)
        """
        if not raw.strip():
            return {"hosts": [], "unreachable": [], "count": 0}

        alive:       list[dict] = []
        unreachable: list[str]  = []
        ip_re        = re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b")
        latency_re   = re.compile(r"(\d+(?:\.\d+)?)\s*ms")
        avg_re       = re.compile(r"(\d+(?:\.\d+)?)\s*avg")
        loss_re      = re.compile(r"(\d+)%\s*loss")

        seen: set[str] = set()

        for line in raw.splitlines():
            line = line.strip()
            if not line:
                continue
            lower = line.lower()

            ips = ip_re.findall(line)
            if not ips:
                continue
            ip = ips[0]
            if ip in seen:
                continue

            if "is alive" in lower or "is reachable" in lower:
                seen.add(ip)
                lat_match = latency_re.search(line)
                alive.append({
                    "ip":      ip,
                    "status":  "alive",
                    "latency": float(lat_match.group(1)) if lat_match else None,
                    "avg_ms":  None,
                    "loss_pct": 0,
                })

            elif "is unreachable" in lower or "is down" in lower:
                seen.add(ip)
                unreachable.append(ip)

            elif "%" in line and "loss" in lower:
                # Summary line: 192.168.1.1 : [0], 64 bytes, 1.2 ms (1.2 avg, 0% loss)
                seen.add(ip)
                lat   = latency_re.search(line)
                avg   = avg_re.search(line)
                loss  = loss_re.search(line)
                loss_val = int(loss.group(1)) if loss else 100
                if loss_val < 100:
                    alive.append({
                        "ip":      ip,
                        "status":  "alive",
                        "latency": float(lat.group(1)) if lat else None,
                        "avg_ms":  float(avg.group(1)) if avg else None,
                        "loss_pct": loss_val,
                    })
                else:
                    unreachable.append(ip)

        return {
            "hosts":       alive,
            "unreachable": sorted(set(unreachable)),
            "count":       len(alive),
        }

    # ── internal ──────────────────────────────────────────────────────────────

    @staticmethod
    def _resolve_target(target: str) -> tuple[list[str], list[str]]:
        """Return (targets_list, gen_flags) for fping CLI."""
        try:
            net = ip_network(target, strict=False)
            if net.num_addresses > 1:
                return [str(net.network_address), str(net.broadcast_address)], ["-g"]
        except ValueError:
            pass
        # Single host or space-separated list
        return target.split(), []

    def _build_findings(self, data: dict) -> list[ParsedFinding]:
        findings = []
        for host in data.get("hosts", []):
            findings.append(ParsedFinding(
                finding_type="live_host",
                value=host["ip"],
                source=self.NAME,
                confidence=0.92,
                metadata={
                    "method":    "icmp",
                    "latency_ms": host.get("latency"),
                    "avg_ms":     host.get("avg_ms"),
                    "loss_pct":   host.get("loss_pct"),
                },
            ))
        return findings
