"""
ReconX — Vulnerability Correlator (Stage 8).

Correlates findings across multiple tool outputs:
  - Cross-tool deduplication (Nuclei + Nikto + future tools)
  - CVE aggregation and mapping
  - Attack-surface chain detection
  - Port/service context enrichment
  - Correlated risk amplification
"""
from __future__ import annotations

import hashlib
import re
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Optional

from .severity_engine import Severity, SeverityEngine, ScoredFinding


# ── Correlation result ────────────────────────────────────────────────────────

@dataclass
class CorrelatedFinding:
    """
    A deduplicated, cross-correlated vulnerability finding.

    Merges identical/similar findings from multiple tools into one entry,
    raising the confidence and potentially adjusting severity.
    """
    finding_id:      str                 # stable hash-based ID
    title:           str
    severity:        Severity
    adjusted_score:  float
    sources:         list[str]           # tools that found this
    matched_at:      str                 # primary URL/host
    all_matches:     list[str]           # all matched locations
    cves:            list[str]
    description:     str
    category:        str
    confidence:      float               # boosted when multiple tools agree
    tags:            list[str]           = field(default_factory=list)
    chain:           list[str]           = field(default_factory=list)   # related finding IDs
    remediation:     str                 = ""
    is_amplified:    bool                = False                          # score raised by correlation


@dataclass
class CorrelationReport:
    """Full correlation output returned by VulnCorrelator.correlate()."""
    findings:        list[CorrelatedFinding]
    cve_index:       dict[str, list[str]]   # CVE → [finding_ids]
    chains:          list[list[str]]        # attack chains as finding-ID lists
    stats:           dict
    duplicates_removed: int


# ── Vulnerability correlator ──────────────────────────────────────────────────

class VulnCorrelator:
    """
    Correlates and deduplicates findings from multiple tools.

    Pipeline:
      1. Ingest scored findings from all tools
      2. Deduplicate by template/CVE/URL key
      3. Merge multi-source matches (boost confidence)
      4. Build CVE index
      5. Detect attack chains (amplify severity when chained)
      6. Return CorrelationReport
    """

    # Similarity threshold for URL fuzzy dedup (Jaccard-like token overlap)
    URL_SIMILARITY_THRESHOLD = 0.85

    # Score amplification when 2+ tools confirm same finding
    MULTI_SOURCE_BOOST = 0.5

    # Chain detection rules: if findings from these categories co-exist, flag a chain
    CHAIN_RULES: list[dict] = [
        {
            "name":     "auth_bypass → admin_panel",
            "requires": ["auth_bypass", "admin_panel"],
            "severity": Severity.CRITICAL,
            "message":  "Auth bypass paired with exposed admin panel — likely trivial takeover.",
        },
        {
            "name":     "rce + network_exposure",
            "requires": ["rce", "internet_exposed"],
            "severity": Severity.CRITICAL,
            "message":  "RCE vulnerability on internet-exposed service — critical priority.",
        },
        {
            "name":     "data_exposure + no_auth",
            "requires": ["data_exposure", "no_auth"],
            "severity": Severity.CRITICAL,
            "message":  "Sensitive data exposed on unauthenticated endpoint.",
        },
        {
            "name":     "sqli + data_exposure",
            "requires": ["sqli", "data_exposure"],
            "severity": Severity.HIGH,
            "message":  "SQL injection paired with data exposure — potential exfiltration path.",
        },
        {
            "name":     "backup_file + config_exposure",
            "requires": ["backup_exposed", "data_exposure"],
            "severity": Severity.HIGH,
            "message":  "Backup file + config exposure — credential harvesting risk.",
        },
        {
            "name":     "weak_ssl + sensitive_data",
            "requires": ["ssl_weak", "data_exposure"],
            "severity": Severity.HIGH,
            "message":  "Weak TLS on service handling sensitive data — interception risk.",
        },
        {
            "name":     "default_cred + admin",
            "requires": ["default_credential", "admin_panel"],
            "severity": Severity.CRITICAL,
            "message":  "Default credentials on admin panel — immediate access risk.",
        },
    ]

    def __init__(self) -> None:
        self._severity_engine = SeverityEngine()

    # ── Public API ─────────────────────────────────────────────────────────────

    def correlate(self, scored_findings: list[ScoredFinding]) -> CorrelationReport:
        """
        Correlate a list of ScoredFinding objects.

        Args:
            scored_findings: Output from SeverityEngine.score_batch()

        Returns:
            CorrelationReport with deduplicated, correlated, chained findings
        """
        # Step 1: Group by dedup key
        groups = self._group_by_dedup_key(scored_findings)

        # Step 2: Build CorrelatedFinding per group
        correlated: list[CorrelatedFinding] = []
        for key, group in groups.items():
            cf = self._merge_group(key, group)
            correlated.append(cf)

        # Step 3: Build CVE index
        cve_index = self._build_cve_index(correlated)

        # Step 4: Detect attack chains
        chains, correlated = self._detect_chains(correlated)

        # Step 5: Sort by adjusted_score desc
        correlated.sort(key=lambda c: c.adjusted_score, reverse=True)

        # Step 6: Stats
        stats = self._build_stats(correlated, cve_index, chains)
        duplicates_removed = len(scored_findings) - len(correlated)

        return CorrelationReport(
            findings           = correlated,
            cve_index          = cve_index,
            chains             = chains,
            stats              = stats,
            duplicates_removed = max(duplicates_removed, 0),
        )

    # ── Grouping / deduplication ──────────────────────────────────────────────

    def _group_by_dedup_key(
        self, findings: list[ScoredFinding]
    ) -> dict[str, list[ScoredFinding]]:
        """Group findings by a normalized dedup key."""
        groups: dict[str, list[ScoredFinding]] = defaultdict(list)

        for sf in findings:
            key = self._dedup_key(sf)
            groups[key].append(sf)

        return dict(groups)

    def _dedup_key(self, sf: ScoredFinding) -> str:
        """
        Compute a stable dedup key for a finding.

        Priority:
          1. CVE IDs (same CVE = same finding regardless of URL)
          2. Template ID + normalized URL
          3. Category + normalized URL hash
        """
        raw = sf.raw_finding

        # CVE-based key (CVE findings across tools are same issue)
        cves = sf.cves
        if cves:
            return "cve::" + ":".join(sorted(c.upper() for c in cves))

        # Template ID + host key
        tpl_id = raw.get("template_id", "")
        if tpl_id:
            host = self._normalize_host(raw.get("matched_at", raw.get("url", "")))
            return f"tpl::{tpl_id}::{host}"

        # Category + URL fallback
        category = raw.get("category", raw.get("type", "unknown"))
        msg_hash = hashlib.md5(
            raw.get("message", raw.get("name", "")).encode(), usedforsecurity=False
        ).hexdigest()[:8]
        return f"cat::{category}::{msg_hash}"

    def _normalize_host(self, url: str) -> str:
        """Normalize URL to host+path (drop query/fragment) for dedup."""
        url = url.strip().rstrip("/")
        # Remove query string and fragment
        url = re.sub(r"[?#].*$", "", url)
        return url.lower()

    # ── Merging ───────────────────────────────────────────────────────────────

    def _merge_group(self, key: str, group: list[ScoredFinding]) -> CorrelatedFinding:
        """Merge a group of duplicate findings into one CorrelatedFinding."""
        # Use highest-score finding as primary
        primary = max(group, key=lambda sf: sf.adjusted_score)
        raw     = primary.raw_finding

        sources    = list(dict.fromkeys(sf.source for sf in group if sf.source))
        all_matches = list(dict.fromkeys(
            sf.raw_finding.get("matched_at", sf.raw_finding.get("url", ""))
            for sf in group
        ))
        cves = list(dict.fromkeys(
            cve for sf in group for cve in sf.cves
        ))

        # Multi-source confidence boost
        confidence = primary.adjusted_score / 10.0
        is_amplified = False
        adj_score    = primary.adjusted_score

        if len(sources) > 1:
            adj_score    = min(adj_score + self.MULTI_SOURCE_BOOST, 10.0)
            confidence   = min(confidence + 0.1 * (len(sources) - 1), 1.0)
            is_amplified = True

        severity = Severity.from_cvss(adj_score)

        # Stable ID
        finding_id = hashlib.md5(key.encode(), usedforsecurity=False).hexdigest()[:12]

        title = (
            raw.get("name") or
            raw.get("message", "")[:80] or
            raw.get("template_id", "Unknown Finding")
        )

        return CorrelatedFinding(
            finding_id     = finding_id,
            title          = title,
            severity       = severity,
            adjusted_score = round(adj_score, 2),
            sources        = sources,
            matched_at     = all_matches[0] if all_matches else "",
            all_matches    = all_matches,
            cves           = cves,
            description    = raw.get("description", raw.get("message", "")),
            category       = raw.get("category", raw.get("type", "")),
            confidence     = round(confidence, 2),
            tags           = raw.get("tags", []),
            remediation    = self._remediation_hint(raw),
            is_amplified   = is_amplified,
        )

    # ── CVE index ─────────────────────────────────────────────────────────────

    def _build_cve_index(
        self, findings: list[CorrelatedFinding]
    ) -> dict[str, list[str]]:
        """Map CVE IDs to lists of finding IDs."""
        index: dict[str, list[str]] = defaultdict(list)
        for cf in findings:
            for cve in cf.cves:
                index[cve.upper()].append(cf.finding_id)
        return dict(index)

    # ── Chain detection ───────────────────────────────────────────────────────

    def _detect_chains(
        self, findings: list[CorrelatedFinding]
    ) -> tuple[list[list[str]], list[CorrelatedFinding]]:
        """
        Detect multi-finding attack chains.

        Modifies findings in-place to set chain references and amplify severity
        for findings that participate in a critical chain.

        Returns: (chains, modified_findings)
        """
        # Collect all active context flags across findings
        active_flags: set[str] = set()
        flag_to_findings: dict[str, list[str]] = defaultdict(list)

        for cf in findings:
            flags = self._extract_flags(cf)
            for flag in flags:
                active_flags.add(flag)
                flag_to_findings[flag].append(cf.finding_id)

        chains: list[list[str]] = []

        for rule in self.CHAIN_RULES:
            required = set(rule["requires"])
            if not required.issubset(active_flags):
                continue

            # Gather all findings participating in this chain
            chain_ids: list[str] = []
            for flag in required:
                chain_ids.extend(flag_to_findings.get(flag, []))
            chain_ids = list(dict.fromkeys(chain_ids))

            if not chain_ids:
                continue

            chains.append(chain_ids)

            # Amplify severity of participating findings
            for cf in findings:
                if cf.finding_id in chain_ids:
                    cf.chain.append(f"Chain: {rule['name']}")
                    # Boost score
                    new_score = min(cf.adjusted_score + 1.5, 10.0)
                    cf.adjusted_score = round(new_score, 2)
                    cf.severity       = Severity.from_cvss(cf.adjusted_score)
                    cf.is_amplified   = True

        return chains, findings

    def _extract_flags(self, cf: CorrelatedFinding) -> set[str]:
        """Extract context flags from a CorrelatedFinding for chain detection."""
        flags: set[str] = set()
        text = (cf.title + " " + cf.description + " " + cf.category + " " + " ".join(cf.tags)).lower()

        flag_keywords = {
            "auth_bypass":      ["auth bypass", "unauthenticated", "no auth"],
            "admin_panel":      ["admin", "panel", "dashboard", "jenkins", "grafana"],
            "rce":              ["rce", "remote code", "command execution"],
            "internet_exposed": ["exposed", "public"],
            "data_exposure":    [".env", "config", "backup", "secret", "token", "key"],
            "no_auth":          ["no auth", "unauthenticated", "anonymous"],
            "sqli":             ["sqli", "sql injection", "sql"],
            "backup_exposed":   ["backup", ".bak", ".sql", ".zip"],
            "ssl_weak":         ["ssl", "tls", "weak cipher"],
            "default_credential": ["default", "credential", "password"],
        }

        for flag, keywords in flag_keywords.items():
            if any(kw in text for kw in keywords):
                flags.add(flag)

        return flags

    # ── Remediation hints ─────────────────────────────────────────────────────

    def _remediation_hint(self, raw: dict) -> str:
        """Generate a brief remediation hint from finding metadata."""
        category = (raw.get("category", raw.get("type", ""))).lower()
        name     = (raw.get("name", raw.get("message", ""))).lower()

        hints = {
            "missing_header":   "Add the required HTTP security header to server configuration.",
            "directory_index":  "Disable directory listing in web server configuration.",
            "default_login":    "Change default credentials immediately; enforce strong password policy.",
            "backup_exposed":   "Remove backup/config files from web root; update .htaccess/nginx rules.",
            "ssl":              "Upgrade to TLS 1.2+; disable weak ciphers; use a valid certificate.",
            "admin_panel":      "Restrict admin panel access by IP; enforce MFA.",
            "xss":              "Sanitize and encode all user-controlled output; implement CSP.",
            "sqli":             "Use parameterized queries/prepared statements; apply WAF rules.",
            "lfi":              "Validate and whitelist file path inputs; disable allow_url_include.",
            "ssrf":             "Validate and restrict outbound connections; use a server-side allowlist.",
            "outdated_software": "Update software to latest patched version; track CVEs for dependencies.",
        }

        for key, hint in hints.items():
            if key in category or key in name:
                return hint

        return "Review finding and apply vendor-recommended patch or configuration hardening."

    # ── Stats ─────────────────────────────────────────────────────────────────

    def _build_stats(
        self,
        findings:  list[CorrelatedFinding],
        cve_index: dict[str, list[str]],
        chains:    list[list[str]],
    ) -> dict:
        by_sev: dict[str, int] = {}
        by_cat: dict[str, int] = {}
        amplified = 0

        for cf in findings:
            sev = cf.severity.value
            by_sev[sev] = by_sev.get(sev, 0) + 1
            cat = cf.category or "unknown"
            by_cat[cat] = by_cat.get(cat, 0) + 1
            if cf.is_amplified:
                amplified += 1

        return {
            "total":           len(findings),
            "by_severity":     by_sev,
            "by_category":     by_cat,
            "unique_cves":     len(cve_index),
            "attack_chains":   len(chains),
            "amplified":       amplified,
            "critical":        by_sev.get("CRITICAL", 0),
            "high":            by_sev.get("HIGH", 0),
            "medium":          by_sev.get("MEDIUM", 0),
            "low":             by_sev.get("LOW", 0),
            "info":            by_sev.get("INFO", 0),
        }
