"""
ReconX — Vulnerability Pipeline (Stage 8).

Orchestrates the full vulnerability detection and analysis pipeline:

  Recon Results → Service Correlation → Technology Identification
  → Target Classification → Template Selection → Vulnerability Scanning
  → Misconfiguration Analysis → False Positive Filtering
  → Severity Correlation → Risk Assessment → Final Report

Rich terminal output with live progress display.
"""
from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Optional

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich import box

from .nuclei_tool       import NucleiTool
from .nikto_tool        import NiktoTool
from .severity_engine   import SeverityEngine, ScoredFinding, Severity
from .vuln_correlator   import VulnCorrelator, CorrelationReport
from .exposure_classifier import ExposureClassifier, ExposureResult
from .false_positive_filter import FalsePositiveFilter
from .template_manager  import TemplateManager, TemplateSet
from .risk_mapper       import RiskMapper, RiskMapReport

logger = logging.getLogger("reconx.tools.vuln.pipeline")

# ── Severity colours for Rich ─────────────────────────────────────────────────
SEV_STYLE = {
    "CRITICAL": "bold red",
    "HIGH":     "red",
    "MEDIUM":   "yellow",
    "LOW":      "cyan",
    "INFO":     "dim",
}


@dataclass
class VulnPipelineConfig:
    """Configuration for a single pipeline run."""
    profile:          str             = "balanced"
    severities:       list[str]       = field(default_factory=lambda: ["critical", "high", "medium"])
    technologies:     list[str]       = field(default_factory=list)
    open_ports:       list[int]       = field(default_factory=list)
    run_nuclei:       bool            = True
    run_nikto:        bool            = True
    nikto_max_time:   str             = "10m"
    nuclei_rate:      int             = 150
    nuclei_concurrency: int           = 25
    min_confidence:   float           = 0.50
    suppress_info:    bool            = False
    update_templates: bool            = False
    custom_templates: list[str]       = field(default_factory=list)
    extra_tags:       list[str]       = field(default_factory=list)


@dataclass
class VulnPipelineResult:
    """Complete output from VulnPipeline.run()."""
    target:            str
    duration_s:        float
    nuclei_result:     Optional[dict]          = None
    nikto_result:      Optional[dict]          = None
    scored_findings:   list[ScoredFinding]     = field(default_factory=list)
    correlation:       Optional[CorrelationReport] = None
    exposures:         list[ExposureResult]    = field(default_factory=list)
    risk_report:       Optional[RiskMapReport] = None
    suppressed_count:  int                     = 0
    errors:            list[str]               = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return bool(self.scored_findings) or bool(self.exposures)

    @property
    def critical_count(self) -> int:
        return sum(1 for sf in self.scored_findings if sf.severity == Severity.CRITICAL)

    @property
    def high_count(self) -> int:
        return sum(1 for sf in self.scored_findings if sf.severity == Severity.HIGH)


class VulnPipeline:
    """
    Orchestrates all Stage 8 vulnerability analysis modules.

    Usage:
        pipeline = VulnPipeline(console=console)
        result = pipeline.run(target="https://example.com", config=cfg)
    """

    def __init__(self, console: Optional[Console] = None) -> None:
        self._console    = console or Console()
        self._nuclei     = NucleiTool()
        self._nikto      = NiktoTool()
        self._sev_engine = SeverityEngine()
        self._correlator = VulnCorrelator()
        self._classifier = ExposureClassifier()
        self._fp_filter  = FalsePositiveFilter()
        self._tmgr       = TemplateManager()
        self._risk       = RiskMapper()

    # ── Public API ─────────────────────────────────────────────────────────────

    def run(
        self,
        target: str,
        config: Optional[VulnPipelineConfig] = None,
    ) -> VulnPipelineResult:
        """
        Execute the full vulnerability analysis pipeline.

        Args:
            target: URL or host to scan (e.g. "https://example.com" or "192.168.1.1")
            config: Pipeline configuration

        Returns:
            VulnPipelineResult with all findings and risk assessment
        """
        config = config or VulnPipelineConfig()
        t0     = time.perf_counter()
        result = VulnPipelineResult(target=target)

        self._print_header(target, config)

        # ── Step 1: Template selection ─────────────────────────────────────────
        template_set = self._select_templates(config)
        self._status("Template Selection", f"{len(template_set.tags)} tags — {template_set.description}")

        # ── Step 2: Nuclei scan ───────────────────────────────────────────────
        raw_findings: list[dict] = []

        if config.run_nuclei:
            nuclei_findings, nuclei_data, err = self._run_nuclei(target, template_set, config)
            result.nuclei_result = nuclei_data
            raw_findings.extend(nuclei_findings)
            if err:
                result.errors.append(f"Nuclei: {err}")

        # ── Step 3: Nikto scan ────────────────────────────────────────────────
        if config.run_nikto:
            nikto_url = self._ensure_http(target)
            nikto_findings, nikto_data, err = self._run_nikto(nikto_url, config)
            result.nikto_result = nikto_data
            raw_findings.extend(nikto_findings)
            if err:
                result.errors.append(f"Nikto: {err}")

        # ── Step 4: Deduplication ─────────────────────────────────────────────
        before_dedup = len(raw_findings)
        raw_findings = self._fp_filter.filter_duplicates(raw_findings)
        self._status("Deduplication", f"{before_dedup} → {len(raw_findings)} findings")

        # ── Step 5: False positive filtering ──────────────────────────────────
        self._fp_filter = FalsePositiveFilter(
            min_confidence = config.min_confidence,
            suppress_info  = config.suppress_info,
        )
        filtered, suppressed = self._fp_filter.filter_batch(
            raw_findings, config.technologies
        )
        result.suppressed_count = suppressed
        self._status("FP Filtering", f"{suppressed} suppressed, {len(filtered)} remain")

        if not filtered:
            self._warn("No findings passed filtering — target may be well-hardened or unreachable")
            result.duration_s = time.perf_counter() - t0
            return result

        # ── Step 6: Severity scoring ──────────────────────────────────────────
        context = {"internet_exposed": True}  # assume internet-facing target
        scored = self._sev_engine.score_batch(filtered, context)
        result.scored_findings = scored
        sev_summary = self._sev_engine.summarize(scored)
        self._status(
            "Severity Scoring",
            f"critical={sev_summary['critical']} high={sev_summary['high']} "
            f"medium={sev_summary['medium']} (avg={sev_summary['avg_score']:.1f})"
        )

        # ── Step 7: Vulnerability correlation ─────────────────────────────────
        correlation = self._correlator.correlate(scored)
        result.correlation = correlation
        self._status(
            "Correlation",
            f"{correlation.stats['total']} unique findings, "
            f"{correlation.duplicates_removed} duplicates removed, "
            f"{len(correlation.chains)} attack chains"
        )

        # ── Step 8: Exposure classification ───────────────────────────────────
        all_raw = [f.raw_finding for f in scored]
        exposures = self._classifier.classify_findings(all_raw)
        result.exposures = exposures
        exp_summary = self._classifier.summarize(exposures)
        self._status(
            "Exposure Classification",
            f"{exp_summary['total']} exposures identified "
            f"(critical={exp_summary['critical']}, high={exp_summary['high']})"
        )

        # ── Step 9: Risk mapping ───────────────────────────────────────────────
        risk_report = self._risk.map(correlation, target=target)
        result.risk_report = risk_report
        result.duration_s  = time.perf_counter() - t0

        # ── Step 10: Print results ─────────────────────────────────────────────
        self._print_results(result)

        return result

    # ── Pipeline steps ─────────────────────────────────────────────────────────

    def _select_templates(self, config: VulnPipelineConfig) -> TemplateSet:
        return self._tmgr.select(
            profile       = config.profile,
            technologies  = config.technologies,
            open_ports    = config.open_ports,
            extra_tags    = config.extra_tags,
            extra_severities = config.severities,
            custom_paths  = config.custom_templates,
        )

    def _run_nuclei(
        self,
        target:       str,
        template_set: TemplateSet,
        config:       VulnPipelineConfig,
    ) -> tuple[list[dict], dict, str]:
        """Run Nuclei and return (raw_findings, data_dict, error_str)."""
        self._status("Nuclei", f"scanning {target} …")

        nres = self._nuclei.run(
            target            = target,
            severities        = template_set.severities,
            tags              = template_set.tags if template_set.tags else None,
            custom_templates  = template_set.custom_paths or None,
            rate_limit        = config.nuclei_rate,
            concurrency       = config.nuclei_concurrency,
            update_templates  = config.update_templates,
        )

        if not nres.ok:
            err = nres.error.message if nres.error else "unknown error"
            self._warn(f"Nuclei {nres.icon} {err}")
            return [], {}, err

        data     = nres.data
        findings = data.get("findings", [])
        for f in findings:
            f["source"] = "Nuclei"

        self._ok(
            f"nuclei → {len(findings)} findings "
            f"(critical={data.get('by_severity', {}).get('critical', 0)}, "
            f"high={data.get('by_severity', {}).get('high', 0)})"
        )
        return findings, data, ""

    def _run_nikto(
        self,
        target: str,
        config: VulnPipelineConfig,
    ) -> tuple[list[dict], dict, str]:
        """Run Nikto and return (raw_findings, data_dict, error_str)."""
        self._status("Nikto", f"scanning {target} …")

        nres = self._nikto.run(
            target   = target,
            max_time = config.nikto_max_time,
            ssl      = target.startswith("https://"),
        )

        if not nres.ok:
            err = nres.error.message if nres.error else "unknown error"
            self._warn(f"Nikto {nres.icon} {err}")
            return [], {}, err

        data     = nres.data
        findings = data.get("findings", [])
        for f in findings:
            f["source"] = "Nikto"

        missing = data.get("missing_headers", [])
        self._ok(
            f"nikto  → {len(findings)} findings "
            f"(missing headers: {', '.join(missing[:4]) or 'none'})"
        )
        return findings, data, ""

    # ── Rich output helpers ────────────────────────────────────────────────────

    def _print_header(self, target: str, config: VulnPipelineConfig) -> None:
        self._console.print()
        self._console.print(
            Panel.fit(
                f"[bold cyan][ Vulnerability Analysis ][/bold cyan]\n"
                f"[white]Target:[/white] [yellow]{target}[/yellow]  "
                f"[white]Profile:[/white] [yellow]{config.profile}[/yellow]  "
                f"[white]Severities:[/white] [yellow]{', '.join(config.severities)}[/yellow]",
                border_style="cyan",
            )
        )
        self._console.print()

    def _print_results(self, result: VulnPipelineResult) -> None:
        """Print final vulnerability analysis results table."""
        self._console.print()

        # ── Top findings table ─────────────────────────────────────────────────
        if result.correlation and result.correlation.findings:
            table = Table(
                title="⚠️  Vulnerability Findings",
                box=box.SIMPLE_HEAD,
                border_style="cyan",
                show_lines=True,
            )
            table.add_column("Severity",   style="bold",    width=10)
            table.add_column("Score",      style="cyan",    width=6)
            table.add_column("Title",      style="white",   width=45)
            table.add_column("Sources",    style="dim",     width=12)
            table.add_column("CVEs",       style="red",     width=20)

            for cf in result.correlation.findings[:30]:
                sev_style = SEV_STYLE.get(cf.severity.value, "white")
                table.add_row(
                    f"[{sev_style}]{cf.severity.value}[/{sev_style}]",
                    f"{cf.adjusted_score:.1f}",
                    cf.title[:44],
                    ", ".join(cf.sources[:2]),
                    ", ".join(cf.cves[:2]) or "—",
                )
            self._console.print(table)

        # ── Exposure table ─────────────────────────────────────────────────────
        if result.exposures:
            exp_table = Table(
                title="🔓 Exposure Analysis",
                box=box.SIMPLE_HEAD,
                border_style="yellow",
            )
            exp_table.add_column("Severity", width=10)
            exp_table.add_column("Type",     width=28)
            exp_table.add_column("Title",    width=40)
            exp_table.add_column("URL",      width=50)

            for exp in result.exposures[:15]:
                sev_style = SEV_STYLE.get(exp.severity, "white")
                exp_table.add_row(
                    f"[{sev_style}]{exp.severity}[/{sev_style}]",
                    exp.label,
                    exp.title[:39],
                    exp.url[:49],
                )
            self._console.print(exp_table)

        # ── Risk summary ───────────────────────────────────────────────────────
        if result.risk_report:
            rr = result.risk_report
            tier_style = {
                "IMMEDIATE": "bold red",
                "URGENT":    "red",
                "MODERATE":  "yellow",
                "PLANNED":   "cyan",
                "MONITOR":   "dim",
            }.get(rr.overall_risk_tier, "white")

            self._console.print()
            self._console.print(Panel(
                f"[bold]Overall Risk:[/bold]  "
                f"[{tier_style}]{rr.overall_risk_tier}[/{tier_style}]  "
                f"Score: [cyan]{rr.overall_risk_score:.1f}[/cyan]/10.0\n"
                f"[dim]{rr.stats.get('critical', 0)} critical  "
                f"{rr.stats.get('high', 0)} high  "
                f"{rr.stats.get('medium', 0)} medium  "
                f"| {rr.stats.get('unique_cves', 0)} CVEs  "
                f"| {len(result.risk_report.attack_vectors)} attack vectors  "
                f"| {len(result.risk_report.chains) if result.correlation else 0} chains  "
                f"| {result.suppressed_count} suppressed[/dim]\n"
                f"[dim]Completed in {result.duration_s:.1f}s[/dim]",
                title="Risk Assessment",
                border_style=tier_style,
            ))

            # Top remediation items
            if rr.remediation_queue:
                self._console.print("\n[bold cyan]🔧 Remediation Priority Queue:[/bold cyan]")
                for item in rr.remediation_queue[:8]:
                    tier_s = {
                        "IMMEDIATE": "[bold red]IMMEDIATE[/bold red]",
                        "URGENT":    "[red]URGENT[/red]",
                        "MODERATE":  "[yellow]MODERATE[/yellow]",
                        "PLANNED":   "[cyan]PLANNED[/cyan]",
                        "MONITOR":   "[dim]MONITOR[/dim]",
                    }.get(item.risk_tier, item.risk_tier)
                    effort_s = {"LOW": "●", "MEDIUM": "●●", "HIGH": "●●●"}.get(item.effort, "●")
                    self._console.print(
                        f"  [{item.priority:2d}] {tier_s}  {effort_s}  {item.title}"
                    )

        self._console.print()

    def _status(self, label: str, msg: str) -> None:
        self._console.print(f"  [cyan]→[/cyan] [bold]{label:<22}[/bold] {msg}")

    def _ok(self, msg: str) -> None:
        self._console.print(f"  [green]✔[/green] {msg}")

    def _warn(self, msg: str) -> None:
        self._console.print(f"  [yellow]⚠[/yellow] {msg}")

    @staticmethod
    def _ensure_http(target: str) -> str:
        if target.startswith("http://") or target.startswith("https://"):
            return target
        return f"http://{target}"
