"""
ReconX — Risk Mapper (Stage 8).

Maps vulnerability findings to an overall attack surface risk model:
  - Per-asset risk scoring
  - Attack vector mapping
  - Business impact assessment
  - Risk tier classification
  - Remediation priority queue
  - Executive summary generation
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from .severity_engine import Severity
from .vuln_correlator import CorrelatedFinding, CorrelationReport


# ── Risk tiers ────────────────────────────────────────────────────────────────

class RiskTier:
    IMMEDIATE  = "IMMEDIATE"     # Critical — fix now
    URGENT     = "URGENT"        # High — fix within 72h
    MODERATE   = "MODERATE"      # Medium — fix within 2 weeks
    PLANNED    = "PLANNED"       # Low — next sprint
    MONITOR    = "MONITOR"       # Info — track only


RISK_TIER_ORDER = {
    RiskTier.IMMEDIATE: 0,
    RiskTier.URGENT:    1,
    RiskTier.MODERATE:  2,
    RiskTier.PLANNED:   3,
    RiskTier.MONITOR:   4,
}


# ── Data structures ───────────────────────────────────────────────────────────

@dataclass
class RemediationItem:
    """A prioritized remediation action."""
    priority:       int             # 1 = highest
    risk_tier:      str
    title:          str
    description:    str
    remediation:    str
    finding_ids:    list[str]
    severity:       str
    effort:         str             # "LOW" | "MEDIUM" | "HIGH"
    cves:           list[str] = field(default_factory=list)


@dataclass
class AssetRisk:
    """Risk assessment for a single asset (URL/host)."""
    asset:          str
    risk_score:     float           # 0–10
    risk_tier:      str
    findings_count: int
    critical_count: int
    high_count:     int
    top_finding:    Optional[str]   # title of highest-severity finding


@dataclass
class RiskMapReport:
    """Full risk mapping output."""
    overall_risk_score:  float
    overall_risk_tier:   str
    asset_risks:         list[AssetRisk]
    remediation_queue:   list[RemediationItem]
    attack_vectors:      list[dict]
    executive_summary:   str
    stats:               dict


# ── Risk mapper ───────────────────────────────────────────────────────────────

class RiskMapper:
    """
    Maps correlated vulnerability findings to an attack surface risk model.

    Takes CorrelationReport as input and produces RiskMapReport.
    """

    # Effort estimation based on category
    EFFORT_MAP: dict[str, str] = {
        "missing_header":    "LOW",
        "directory_listing": "LOW",
        "info_disclosure":   "LOW",
        "ssl":               "MEDIUM",
        "outdated_software": "MEDIUM",
        "admin_panel":       "LOW",
        "backup_file":       "LOW",
        "config_file":       "LOW",
        "secret_file":       "LOW",
        "default_login":     "LOW",
        "xss":               "MEDIUM",
        "sqli":              "HIGH",
        "ssrf":              "HIGH",
        "lfi":               "HIGH",
        "rce":               "HIGH",
        "cve":               "MEDIUM",
    }

    def map(
        self,
        correlation_report: CorrelationReport,
        target:             str = "",
    ) -> RiskMapReport:
        """
        Produce a full risk map from a CorrelationReport.

        Args:
            correlation_report: Output from VulnCorrelator.correlate()
            target:             Primary scan target (for summary)

        Returns:
            RiskMapReport with prioritized remediation queue
        """
        findings = correlation_report.findings

        # 1. Per-asset risk
        asset_risks = self._compute_asset_risks(findings)

        # 2. Overall risk score
        overall_score = self._compute_overall_score(findings)
        overall_tier  = self._score_to_tier(overall_score)

        # 3. Remediation queue
        remediation_queue = self._build_remediation_queue(findings)

        # 4. Attack vectors
        attack_vectors = self._identify_attack_vectors(findings)

        # 5. Executive summary
        summary = self._generate_executive_summary(
            target            = target,
            overall_score     = overall_score,
            overall_tier      = overall_tier,
            stats             = correlation_report.stats,
            chains            = correlation_report.chains,
            attack_vectors    = attack_vectors,
            remediation_queue = remediation_queue,
        )

        stats = {
            **correlation_report.stats,
            "overall_risk_score": overall_score,
            "overall_risk_tier":  overall_tier,
            "assets_assessed":    len(asset_risks),
            "remediation_items":  len(remediation_queue),
            "attack_vectors":     len(attack_vectors),
        }

        return RiskMapReport(
            overall_risk_score  = round(overall_score, 2),
            overall_risk_tier   = overall_tier,
            asset_risks         = asset_risks,
            remediation_queue   = remediation_queue,
            attack_vectors      = attack_vectors,
            executive_summary   = summary,
            stats               = stats,
        )

    # ── Asset risk ────────────────────────────────────────────────────────────

    def _compute_asset_risks(
        self, findings: list[CorrelatedFinding]
    ) -> list[AssetRisk]:
        """Group findings by asset and score each asset."""
        asset_map: dict[str, list[CorrelatedFinding]] = {}

        for cf in findings:
            asset = self._normalize_asset(cf.matched_at)
            asset_map.setdefault(asset, []).append(cf)

        results: list[AssetRisk] = []
        for asset, asset_findings in asset_map.items():
            score    = self._compute_overall_score(asset_findings)
            tier     = self._score_to_tier(score)
            critical = sum(1 for f in asset_findings if f.severity == Severity.CRITICAL)
            high     = sum(1 for f in asset_findings if f.severity == Severity.HIGH)
            top      = asset_findings[0].title if asset_findings else None

            results.append(AssetRisk(
                asset          = asset,
                risk_score     = round(score, 2),
                risk_tier      = tier,
                findings_count = len(asset_findings),
                critical_count = critical,
                high_count     = high,
                top_finding    = top,
            ))

        results.sort(key=lambda a: a.risk_score, reverse=True)
        return results

    def _normalize_asset(self, url: str) -> str:
        """Normalize URL to host[:port] for asset grouping."""
        if not url:
            return "unknown"
        # Strip path
        for prefix in ("https://", "http://"):
            if url.startswith(prefix):
                url = url[len(prefix):]
                break
        host = url.split("/")[0].split("?")[0]
        return host.lower() or "unknown"

    # ── Overall score ─────────────────────────────────────────────────────────

    def _compute_overall_score(self, findings: list[CorrelatedFinding]) -> float:
        """
        Compute a weighted overall risk score from findings.

        Uses weighted average with severity multipliers and diminishing returns
        for large finding counts (to avoid score saturation).
        """
        if not findings:
            return 0.0

        weights = {
            Severity.CRITICAL: 10.0,
            Severity.HIGH:     7.0,
            Severity.MEDIUM:   4.0,
            Severity.LOW:      1.5,
            Severity.INFO:     0.0,
        }

        weighted_sum = sum(weights.get(f.severity, 0.0) * f.adjusted_score for f in findings)
        total_weight = sum(weights.get(f.severity, 0.0) for f in findings) or 1.0

        raw_score = weighted_sum / total_weight

        # Boost for critical findings
        critical_count = sum(1 for f in findings if f.severity == Severity.CRITICAL)
        if critical_count >= 3:
            raw_score = min(raw_score + 1.5, 10.0)
        elif critical_count >= 1:
            raw_score = min(raw_score + 0.75, 10.0)

        return min(raw_score, 10.0)

    def _score_to_tier(self, score: float) -> str:
        if score >= 8.5:
            return RiskTier.IMMEDIATE
        if score >= 6.5:
            return RiskTier.URGENT
        if score >= 4.0:
            return RiskTier.MODERATE
        if score >= 1.0:
            return RiskTier.PLANNED
        return RiskTier.MONITOR

    # ── Remediation queue ─────────────────────────────────────────────────────

    def _build_remediation_queue(
        self, findings: list[CorrelatedFinding]
    ) -> list[RemediationItem]:
        """
        Build a prioritized remediation queue from correlated findings.
        Groups similar-category findings into single action items where applicable.
        """
        # Group by category for consolidation
        cat_groups: dict[str, list[CorrelatedFinding]] = {}
        standalone: list[CorrelatedFinding] = []

        # Findings with CVEs are always standalone (specific patches needed)
        for cf in findings:
            if cf.cves:
                standalone.append(cf)
            else:
                cat = cf.category or "general"
                cat_groups.setdefault(cat, []).append(cf)

        items: list[RemediationItem] = []
        priority = 1

        # Standalone CVE findings first (highest priority)
        for cf in sorted(standalone, key=lambda f: f.adjusted_score, reverse=True):
            tier   = self._sev_to_tier(cf.severity)
            effort = self.EFFORT_MAP.get(cf.category, "MEDIUM")
            items.append(RemediationItem(
                priority     = priority,
                risk_tier    = tier,
                title        = cf.title,
                description  = cf.description,
                remediation  = cf.remediation,
                finding_ids  = [cf.finding_id],
                severity     = cf.severity.value,
                effort       = effort,
                cves         = cf.cves,
            ))
            priority += 1

        # Grouped category findings
        for cat, group in sorted(
            cat_groups.items(),
            key=lambda kv: max(f.adjusted_score for f in kv[1]),
            reverse=True,
        ):
            if not group:
                continue
            top  = max(group, key=lambda f: f.adjusted_score)
            tier = self._sev_to_tier(top.severity)
            effort = self.EFFORT_MAP.get(cat, "MEDIUM")

            if len(group) == 1:
                title       = top.title
                description = top.description
            else:
                title       = f"{top.title} (+{len(group)-1} similar)"
                description = (
                    f"{top.description} "
                    f"[{len(group)} findings in category '{cat}']"
                )

            items.append(RemediationItem(
                priority    = priority,
                risk_tier   = tier,
                title       = title,
                description = description,
                remediation = top.remediation,
                finding_ids = [f.finding_id for f in group],
                severity    = top.severity.value,
                effort      = effort,
                cves        = [],
            ))
            priority += 1

        return items

    def _sev_to_tier(self, severity: Severity) -> str:
        return {
            Severity.CRITICAL: RiskTier.IMMEDIATE,
            Severity.HIGH:     RiskTier.URGENT,
            Severity.MEDIUM:   RiskTier.MODERATE,
            Severity.LOW:      RiskTier.PLANNED,
            Severity.INFO:     RiskTier.MONITOR,
        }.get(severity, RiskTier.MONITOR)

    # ── Attack vectors ────────────────────────────────────────────────────────

    def _identify_attack_vectors(
        self, findings: list[CorrelatedFinding]
    ) -> list[dict]:
        """Identify high-level attack vectors from findings."""
        vectors: list[dict] = []
        seen: set[str] = set()

        vector_rules = [
            {
                "name":     "Remote Code Execution",
                "keywords": ["rce", "remote code", "command execution", "shellshock"],
                "severity": "CRITICAL",
                "impact":   "Full server compromise possible",
            },
            {
                "name":     "Authentication Bypass",
                "keywords": ["auth bypass", "unauthenticated", "default credential", "default password"],
                "severity": "CRITICAL",
                "impact":   "Unauthorized access to protected functionality",
            },
            {
                "name":     "Data Exfiltration",
                "keywords": [".env", "database dump", "backup", "config", "secret", "api key"],
                "severity": "HIGH",
                "impact":   "Sensitive data exposure and credential theft",
            },
            {
                "name":     "SQL Injection",
                "keywords": ["sqli", "sql injection", "blind sql"],
                "severity": "HIGH",
                "impact":   "Database access, data theft, authentication bypass",
            },
            {
                "name":     "Cross-Site Scripting (XSS)",
                "keywords": ["xss", "cross-site scripting"],
                "severity": "MEDIUM",
                "impact":   "Session hijacking, credential phishing, defacement",
            },
            {
                "name":     "Server-Side Request Forgery (SSRF)",
                "keywords": ["ssrf", "server-side request"],
                "severity": "HIGH",
                "impact":   "Internal network access, cloud metadata theft",
            },
            {
                "name":     "Sensitive File Exposure",
                "keywords": ["exposed", "disclosure", "accessible", "backup", "config"],
                "severity": "HIGH",
                "impact":   "Information disclosure enabling further attacks",
            },
            {
                "name":     "Weak SSL/TLS Configuration",
                "keywords": ["ssl", "tls", "cipher", "certificate"],
                "severity": "MEDIUM",
                "impact":   "Traffic interception and man-in-the-middle attacks",
            },
            {
                "name":     "Missing Security Headers",
                "keywords": ["x-frame", "content-security-policy", "hsts", "x-content-type"],
                "severity": "LOW",
                "impact":   "Clickjacking, MIME confusion, downgrade attacks",
            },
        ]

        for rule in vector_rules:
            matched_findings: list[str] = []
            for cf in findings:
                text = (cf.title + " " + cf.description + " " + cf.category).lower()
                if any(kw in text for kw in rule["keywords"]):
                    matched_findings.append(cf.finding_id)

            if matched_findings and rule["name"] not in seen:
                seen.add(rule["name"])
                vectors.append({
                    "name":          rule["name"],
                    "severity":      rule["severity"],
                    "impact":        rule["impact"],
                    "finding_count": len(matched_findings),
                    "finding_ids":   matched_findings[:10],
                })

        # Sort by severity
        sev_order = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3}
        vectors.sort(key=lambda v: sev_order.get(v["severity"], 4))
        return vectors

    # ── Executive summary ─────────────────────────────────────────────────────

    def _generate_executive_summary(
        self,
        target:            str,
        overall_score:     float,
        overall_tier:      str,
        stats:             dict,
        chains:            list,
        attack_vectors:    list[dict],
        remediation_queue: list[RemediationItem],
    ) -> str:
        critical = stats.get("critical", 0)
        high     = stats.get("high", 0)
        medium   = stats.get("medium", 0)
        total    = stats.get("total", 0)
        cves     = stats.get("unique_cves", 0)
        chain_ct = len(chains)

        risk_label = {
            RiskTier.IMMEDIATE: "CRITICAL RISK — Immediate remediation required",
            RiskTier.URGENT:    "HIGH RISK — Urgent remediation required",
            RiskTier.MODERATE:  "MODERATE RISK — Scheduled remediation required",
            RiskTier.PLANNED:   "LOW RISK — Planned remediation appropriate",
            RiskTier.MONITOR:   "MINIMAL RISK — Monitor and track",
        }.get(overall_tier, "RISK UNDETERMINED")

        summary_lines = [
            f"Target: {target or 'Unknown'}",
            f"Overall Risk: {risk_label} (Score: {overall_score:.1f}/10.0)",
            "",
            f"Vulnerability Summary:",
            f"  • Total findings:   {total}",
            f"  • Critical:         {critical}",
            f"  • High:             {high}",
            f"  • Medium:           {medium}",
            f"  • Unique CVEs:      {cves}",
        ]

        if chain_ct:
            summary_lines.append(f"  • Attack chains:    {chain_ct} detected")

        if attack_vectors:
            summary_lines.append("")
            summary_lines.append("Primary Attack Vectors:")
            for av in attack_vectors[:5]:
                summary_lines.append(f"  • {av['name']} [{av['severity']}] — {av['impact']}")

        if remediation_queue:
            immediate = [r for r in remediation_queue if r.risk_tier == RiskTier.IMMEDIATE]
            if immediate:
                summary_lines.append("")
                summary_lines.append("Immediate Actions Required:")
                for r in immediate[:5]:
                    summary_lines.append(f"  [{r.effort} effort] {r.title}")

        return "\n".join(summary_lines)
