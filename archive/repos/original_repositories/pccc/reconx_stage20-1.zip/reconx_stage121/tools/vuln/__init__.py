"""
ReconX — Stage 8: Vulnerability Detection & Exposure Analysis Layer.
"""
from .nuclei_tool           import NucleiTool
from .nikto_tool            import NiktoTool
from .severity_engine       import SeverityEngine, ScoredFinding, Severity
from .vuln_correlator       import VulnCorrelator, CorrelationReport, CorrelatedFinding
from .exposure_classifier   import ExposureClassifier, ExposureResult
from .false_positive_filter import FalsePositiveFilter, FilterResult
from .template_manager      import TemplateManager, TemplateSet
from .risk_mapper           import RiskMapper, RiskMapReport, RiskTier
from .vuln_pipeline         import VulnPipeline, VulnPipelineConfig, VulnPipelineResult

__all__ = [
    "NucleiTool",
    "NiktoTool",
    "SeverityEngine",
    "ScoredFinding",
    "Severity",
    "VulnCorrelator",
    "CorrelationReport",
    "CorrelatedFinding",
    "ExposureClassifier",
    "ExposureResult",
    "FalsePositiveFilter",
    "FilterResult",
    "TemplateManager",
    "TemplateSet",
    "RiskMapper",
    "RiskMapReport",
    "RiskTier",
    "VulnPipeline",
    "VulnPipelineConfig",
    "VulnPipelineResult",
]
