"""
ReconX — Nikto Web Server Scanner (Stage 8).

Production-grade Nikto wrapper with:
  - JSON output parsing
  - Plugin-aware execution
  - Header and misconfiguration extraction
  - SSL analysis
  - Structured finding normalization
"""
from __future__ import annotations

import json
import os
import tempfile
import time
from pathlib import Path
from typing import Optional

from ..base import BaseTool
from ...config.settings import VULN_CONFIG
from ...models.tool_result import ExecutionMetrics, ParsedFinding, ToolRunResult


# ── Finding categories Nikto reports ─────────────────────────────────────────
NIKTO_SEVERITY_MAP: dict[str, str] = {
    # OSVDB IDs / message keywords → severity
    "server_header":         "info",
    "x-powered-by":          "info",
    "anti-clickjacking":     "medium",
    "x-content-type":        "low",
    "x-xss-protection":      "low",
    "hsts":                  "medium",
    "directory_indexing":    "medium",
    "default_file":          "medium",
    "phpmyadmin":            "high",
    "admin":                 "medium",
    "backup":                "high",
    "config":                "high",
    "ssl":                   "medium",
    "cgi":                   "medium",
    "shellshock":            "critical",
    "heartbleed":            "critical",
    "struts":                "critical",
    "default_password":      "critical",
}


class NiktoTool(BaseTool):
    """
    Nikto web server misconfiguration and vulnerability scanner.

    Detects: outdated software, missing security headers, exposed files,
    directory indexing, default credentials indicators, dangerous HTTP methods,
    and known CVEs via OSVDB references.
    """

    NAME         = "Nikto"
    BINARY       = "nikto"
    CATEGORY     = "vuln"
    STAGE        = 5
    PRIORITY     = 20
    PASSIVE      = False
    TIMEOUT      = 300
    DEPENDENCIES: list[str] = []
    INSTALL_CMD  = "sudo apt install nikto"

    # ── Nikto tuning options (what to test) ───────────────────────────────────
    # 1=interesting, 2=misconfiguration, 3=info disclosure, 4=injection,
    # 5=Remote File Retrieval, 6=DoS (skip), 7=RFI, 8=exec, 9=SQL injection, x=reverse tuning
    DEFAULT_TUNING = "1234578"  # skip DoS (6) and RFI-only (7 optional)

    def run(
        self,
        target: str,
        *,
        port:          Optional[int]  = None,
        ssl:           bool           = False,
        tuning:        str            = "",
        plugins:       Optional[str]  = None,
        max_time:      str            = "10m",
        user_agent:    str            = "",
        follow_redirects: bool        = True,
        **kwargs,
    ) -> ToolRunResult:
        if s := self.skip_if_unavailable(): return s
        if f := self.validate_or_fail(target): return f

        cfg     = VULN_CONFIG.get("nikto", {})
        tuning  = tuning or cfg.get("tuning", self.DEFAULT_TUNING)
        max_time = max_time or cfg.get("max_time", "10m")

        t0 = time.perf_counter()
        out_path: Optional[str] = None

        try:
            with tempfile.NamedTemporaryFile(
                suffix=".json", delete=False, mode="w"
            ) as tf:
                out_path = tf.name

            cmd = self._build_command(
                target=target,
                port=port,
                ssl=ssl,
                tuning=tuning,
                plugins=plugins,
                max_time=max_time,
                user_agent=user_agent,
                follow_redirects=follow_redirects,
                out_path=out_path,
            )

            self._log("info", f"Scanning {target} (tuning={tuning}, maxtime={max_time})")
            res = self.exec(cmd, timeout_s=float(self.timeout), expected_codes=(0, 1))
            dur = time.perf_counter() - t0

            if res.timed_out:
                raw = self._read_and_cleanup(out_path)
                # Still parse partial output if available
                parsed = self.parse_output(raw)
                self._log("warning", f"Nikto timed out after {dur:.0f}s — partial results parsed")
                return self.build_result(
                    data={**parsed, "timed_out": True},
                    findings=self._to_parsed_findings(parsed.get("findings", [])),
                    duration_s=dur,
                )

            raw    = self._read_and_cleanup(out_path)
            parsed = self.parse_output(raw, stderr=res.stderr or "")

            findings = self._to_parsed_findings(parsed.get("findings", []))
            self._log(
                "info",
                f"Complete — {len(findings)} findings in {dur:.1f}s "
                f"(headers={parsed.get('missing_headers', [])!r})"
            )

            return self.build_result(
                data=parsed,
                findings=findings,
                stdout=res.stdout or "",
                stderr=res.stderr or "",
                duration_s=dur,
                returncode=res.returncode or 0,
            )

        except Exception as exc:
            import traceback
            dur = time.perf_counter() - t0
            self._cleanup(out_path)
            return self.fail(
                reason="runtime_error",
                message=str(exc),
                duration_s=dur,
                tb=traceback.format_exc(),
            )

    # ── Command builder ───────────────────────────────────────────────────────

    def _build_command(
        self,
        target:           str,
        port:             Optional[int],
        ssl:              bool,
        tuning:           str,
        plugins:          Optional[str],
        max_time:         str,
        user_agent:       str,
        follow_redirects: bool,
        out_path:         str,
    ) -> list[str]:
        cmd = [
            "nikto",
            "-host", target,
            "-Format", "json",
            "-output", out_path,
            "-Tuning", tuning,
            "-maxtime", max_time,
            "-nointeractive",
        ]

        if port:
            cmd += ["-port", str(port)]
        if ssl:
            cmd.append("-ssl")
        if plugins:
            cmd += ["-Plugins", plugins]
        if user_agent:
            cmd += ["-useragent", user_agent]
        if follow_redirects:
            cmd.append("-followredirects")

        return cmd

    # ── Output parser ─────────────────────────────────────────────────────────

    def parse_output(self, raw: str, stderr: str = "", **kwargs) -> dict:
        """Parse Nikto JSON output into normalized ReconX schema."""
        base: dict = {
            "findings":        [],
            "missing_headers": [],
            "server_info":     {},
            "ssl_info":        {},
            "osvdb_refs":      [],
            "by_severity":     {},
            "total":           0,
        }

        if not raw or not raw.strip():
            # Nikto sometimes writes nothing if target is unreachable
            if stderr:
                base["error"] = stderr.strip()[:500]
            return base

        # Nikto JSON output is wrapped in {"host": {...}, "vulnerabilities": [...]}
        try:
            data = json.loads(raw)
        except json.JSONDecodeError:
            # Fallback: parse plain-text output from stderr/stdout
            return self._parse_text_fallback(raw, base)

        host_info = data.get("host", {})
        vulns     = data.get("vulnerabilities", [])

        base["server_info"] = {
            "ip":           host_info.get("ip", ""),
            "hostname":     host_info.get("hostname", ""),
            "port":         host_info.get("port", ""),
            "banner":       host_info.get("banner", ""),
        }

        findings:        list[dict] = []
        missing_headers: list[str]  = []
        osvdb_refs:      list[str]  = []
        by_severity:     dict[str, int] = {}

        for vuln in vulns:
            normalized = self._normalize_vuln(vuln)
            if not normalized:
                continue

            findings.append(normalized)
            sev = normalized["severity"]
            by_severity[sev] = by_severity.get(sev, 0) + 1

            if normalized.get("category") == "missing_header":
                missing_headers.append(normalized.get("header_name", ""))

            if normalized.get("osvdb"):
                osvdb_refs.append(normalized["osvdb"])

        base["findings"]        = findings
        base["missing_headers"] = [h for h in missing_headers if h]
        base["osvdb_refs"]      = osvdb_refs
        base["by_severity"]     = by_severity
        base["total"]           = len(findings)

        return base

    def _normalize_vuln(self, vuln: dict) -> Optional[dict]:
        """Normalize a single Nikto vulnerability entry."""
        try:
            msg        = vuln.get("msg", vuln.get("message", "")).strip()
            method     = vuln.get("method", "GET")
            url        = vuln.get("url", vuln.get("uri", ""))
            osvdb      = str(vuln.get("osvdb", ""))
            references = vuln.get("references", "")

            if not msg:
                return None

            severity, category, header_name = self._classify_finding(msg, url)

            return {
                "message":     msg,
                "url":         url,
                "method":      method,
                "severity":    severity,
                "category":    category,
                "header_name": header_name,
                "osvdb":       osvdb if osvdb != "0" else "",
                "references":  references,
            }
        except Exception:
            return None

    def _classify_finding(self, msg: str, url: str) -> tuple[str, str, str]:
        """Classify a Nikto message into severity + category + header name."""
        msg_lower = msg.lower()
        url_lower = url.lower()

        # Security headers
        header_checks = {
            "x-frame-options":         ("medium", "missing_header", "X-Frame-Options"),
            "x-content-type-options":  ("low",    "missing_header", "X-Content-Type-Options"),
            "x-xss-protection":        ("low",    "missing_header", "X-XSS-Protection"),
            "strict-transport-security": ("medium", "missing_header", "Strict-Transport-Security"),
            "content-security-policy": ("medium", "missing_header", "Content-Security-Policy"),
            "referrer-policy":         ("low",    "missing_header", "Referrer-Policy"),
            "permissions-policy":      ("low",    "missing_header", "Permissions-Policy"),
        }
        for header_key, (sev, cat, name) in header_checks.items():
            if header_key in msg_lower and ("no " in msg_lower or "missing" in msg_lower or "not set" in msg_lower):
                return sev, cat, name

        # Critical patterns
        critical_keywords = ["shellshock", "heartbleed", "struts", "default password", "remote code", "rce"]
        for kw in critical_keywords:
            if kw in msg_lower:
                return "critical", "vulnerability", ""

        # High patterns
        high_keywords = ["phpmyadmin", "adminer", "backup", "config", "phpinfo", "server source", "traversal"]
        for kw in high_keywords:
            if kw in msg_lower or kw in url_lower:
                return "high", "exposure", ""

        # Directory indexing
        if "index of" in msg_lower or "directory listing" in msg_lower or "index listing" in msg_lower:
            return "medium", "directory_indexing", ""

        # Outdated software
        if "outdated" in msg_lower or "obsolete" in msg_lower or "end of life" in msg_lower:
            return "medium", "outdated_software", ""

        # Admin/panel
        if any(kw in url_lower for kw in ["/admin", "/manager", "/console", "/panel", "/dashboard"]):
            return "medium", "admin_panel", ""

        # SSL/TLS
        if "ssl" in msg_lower or "tls" in msg_lower or "certificate" in msg_lower:
            return "medium", "ssl", ""

        # Info disclosure
        if any(kw in msg_lower for kw in ["x-powered-by", "server:", "banner", "disclose"]):
            return "info", "info_disclosure", ""

        return "info", "general", ""

    def _parse_text_fallback(self, raw: str, base: dict) -> dict:
        """Minimal plain-text parser used when JSON output is unavailable."""
        findings: list[dict] = []
        for line in raw.splitlines():
            line = line.strip()
            if not line or line.startswith("+") and "Target" in line:
                continue
            if line.startswith("+ ") or line.startswith("- "):
                msg = line[2:].strip()
                if not msg:
                    continue
                sev, cat, hdr = self._classify_finding(msg, "")
                findings.append({
                    "message":     msg,
                    "url":         "",
                    "method":      "",
                    "severity":    sev,
                    "category":    cat,
                    "header_name": hdr,
                    "osvdb":       "",
                    "references":  "",
                })
        base["findings"] = findings
        base["total"]    = len(findings)
        return base

    # ── ParsedFinding converter ───────────────────────────────────────────────

    def _to_parsed_findings(self, findings: list[dict]) -> list[ParsedFinding]:
        result: list[ParsedFinding] = []
        for f in findings:
            sev        = f.get("severity", "info")
            confidence = {"critical": 0.90, "high": 0.85, "medium": 0.75,
                          "low": 0.65, "info": 0.55}.get(sev, 0.55)
            pf = ParsedFinding(
                finding_type="web_vulnerability",
                value=f.get("url") or f.get("message", ""),
                source=self.NAME,
                confidence=confidence,
                metadata={
                    "message":     f["message"],
                    "severity":    sev,
                    "category":    f.get("category", ""),
                    "method":      f.get("method", ""),
                    "osvdb":       f.get("osvdb", ""),
                    "header_name": f.get("header_name", ""),
                    "references":  f.get("references", ""),
                },
            )
            result.append(pf)
        return result

    # ── Filesystem helpers ────────────────────────────────────────────────────

    def _read_and_cleanup(self, path: Optional[str]) -> str:
        if not path:
            return ""
        try:
            content = Path(path).read_text(encoding="utf-8", errors="replace")
        except FileNotFoundError:
            content = ""
        finally:
            self._cleanup(path)
        return content

    def _cleanup(self, path: Optional[str]) -> None:
        if path and os.path.exists(path):
            try:
                os.unlink(path)
            except OSError:
                pass
