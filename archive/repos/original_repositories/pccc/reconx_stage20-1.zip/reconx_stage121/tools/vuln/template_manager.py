"""
ReconX — Template Manager (Stage 8).

Manages Nuclei template selection, categorization, and dynamic loading:
  - Technology-aware template selection
  - Service-aware template loading
  - Category-based template grouping
  - Custom template support
  - Template update management
  - Scan profile → template set mapping
"""
from __future__ import annotations

import subprocess
import shutil
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional
import logging

logger = logging.getLogger("reconx.tools.vuln.template_manager")


# ── Template set definition ───────────────────────────────────────────────────

@dataclass
class TemplateSet:
    """A resolved set of templates/tags ready for Nuclei execution."""
    tags:             list[str]
    severities:       list[str]
    custom_paths:     list[str]
    estimated_checks: int           # rough estimate for progress display
    description:      str


# ── Scan profile → template mapping ──────────────────────────────────────────

PROFILE_TEMPLATES: dict[str, dict] = {
    "fast": {
        "severities":    ["critical", "high"],
        "tags":          ["cve", "exposure", "default-login"],
        "description":   "Critical/High CVEs and exposed panels only",
        "est_checks":    500,
    },
    "balanced": {
        "severities":    ["critical", "high", "medium"],
        "tags":          ["cve", "exposure", "default-login", "misconfiguration", "exposed-panels"],
        "description":   "CVEs, exposures, misconfigurations",
        "est_checks":    2000,
    },
    "deep": {
        "severities":    ["critical", "high", "medium", "low"],
        "tags":          [],   # empty = all templates
        "description":   "Full template library (slow)",
        "est_checks":    9000,
    },
    "web": {
        "severities":    ["critical", "high", "medium"],
        "tags":          ["xss", "sqli", "ssrf", "lfi", "rfi", "redirect", "cve"],
        "description":   "Web application vulnerability templates",
        "est_checks":    1500,
    },
    "cloud": {
        "severities":    ["critical", "high", "medium"],
        "tags":          ["aws", "gcp", "azure", "s3", "cloud", "bucket"],
        "description":   "Cloud infrastructure misconfiguration templates",
        "est_checks":    300,
    },
    "network": {
        "severities":    ["critical", "high", "medium"],
        "tags":          ["network", "dns", "ssl", "service"],
        "description":   "Network service vulnerability templates",
        "est_checks":    400,
    },
}

# ── Technology → recommended tags ─────────────────────────────────────────────

TECH_TO_TAGS: dict[str, list[str]] = {
    "wordpress":     ["wordpress", "wp-plugin", "wp-theme", "cve"],
    "drupal":        ["drupal", "cve"],
    "joomla":        ["joomla", "cve"],
    "apache":        ["apache", "cve", "http"],
    "nginx":         ["nginx", "cve", "http"],
    "iis":           ["iis", "asp", "cve"],
    "tomcat":        ["tomcat", "apache", "java", "cve"],
    "jenkins":       ["jenkins", "ci", "default-login", "cve"],
    "grafana":       ["grafana", "default-login", "cve"],
    "kibana":        ["kibana", "elasticsearch", "cve"],
    "gitlab":        ["gitlab", "cve"],
    "jira":          ["jira", "atlassian", "cve"],
    "confluence":    ["confluence", "atlassian", "cve"],
    "spring":        ["spring", "springboot", "java", "cve"],
    "django":        ["django", "python", "cve"],
    "laravel":       ["laravel", "php", "cve"],
    "php":           ["php", "cve"],
    "docker":        ["docker", "container", "cve"],
    "kubernetes":    ["kubernetes", "k8s", "cve"],
    "redis":         ["redis", "default-login", "cve"],
    "mongodb":       ["mongodb", "default-login", "cve"],
    "elasticsearch": ["elasticsearch", "default-login", "cve"],
    "memcached":     ["memcached", "cve"],
    "mysql":         ["mysql", "default-login", "cve"],
    "postgresql":    ["postgresql", "default-login", "cve"],
    "mssql":         ["mssql", "default-login", "cve"],
}

# ── Port / Service → recommended tags ─────────────────────────────────────────

PORT_TO_TAGS: dict[int, list[str]] = {
    21:    ["ftp", "default-login", "cve"],
    22:    ["ssh", "default-login", "cve"],
    23:    ["telnet", "default-login"],
    25:    ["smtp", "cve"],
    80:    ["http", "exposure", "cve", "xss", "sqli"],
    443:   ["ssl", "http", "exposure", "cve", "xss", "sqli"],
    445:   ["smb", "cve"],
    1433:  ["mssql", "default-login", "cve"],
    1521:  ["oracle", "default-login", "cve"],
    3306:  ["mysql", "default-login", "cve"],
    3389:  ["rdp", "cve"],
    4848:  ["glassfish", "default-login", "cve"],
    5432:  ["postgresql", "default-login", "cve"],
    5900:  ["vnc", "default-login"],
    5985:  ["winrm", "cve"],
    6379:  ["redis", "default-login", "cve"],
    7001:  ["weblogic", "java", "cve"],
    8080:  ["http", "jenkins", "tomcat", "exposure", "cve"],
    8443:  ["ssl", "http", "tomcat", "cve"],
    8888:  ["jupyter", "default-login", "cve"],
    9000:  ["portainer", "sonarqube", "cve"],
    9090:  ["prometheus", "grafana", "cve"],
    9200:  ["elasticsearch", "default-login", "cve"],
    11211: ["memcached", "cve"],
    27017: ["mongodb", "default-login", "cve"],
}


class TemplateManager:
    """
    Manages Nuclei template selection for ReconX scans.

    Usage:
        tm = TemplateManager()
        template_set = tm.select(
            profile="balanced",
            technologies=["wordpress", "apache"],
            open_ports=[80, 443, 8080],
        )
        # Pass template_set.tags and template_set.severities to NucleiTool
    """

    def __init__(self, templates_dir: Optional[str] = None) -> None:
        self._templates_dir = Path(templates_dir) if templates_dir else self._detect_templates_dir()

    # ── Public API ─────────────────────────────────────────────────────────────

    def select(
        self,
        profile:       str               = "balanced",
        technologies:  Optional[list[str]] = None,
        open_ports:    Optional[list[int]] = None,
        extra_tags:    Optional[list[str]] = None,
        extra_severities: Optional[list[str]] = None,
        custom_paths:  Optional[list[str]] = None,
    ) -> TemplateSet:
        """
        Select the optimal template set for a scan.

        Args:
            profile:       Scan profile name (fast/balanced/deep/web/cloud/network)
            technologies:  Detected technologies (from WhatWeb/httpx fingerprint)
            open_ports:    Open ports discovered during scanning
            extra_tags:    Additional tags to include
            extra_severities: Override severity list
            custom_paths:  Paths to custom template directories or files

        Returns:
            TemplateSet ready for use with NucleiTool
        """
        profile_cfg  = PROFILE_TEMPLATES.get(profile, PROFILE_TEMPLATES["balanced"])
        base_tags    = list(profile_cfg.get("tags", []))
        severities   = extra_severities or profile_cfg.get("severities", ["critical", "high", "medium"])
        est_checks   = profile_cfg.get("est_checks", 2000)

        # Add technology-specific tags
        tech_tags: list[str] = []
        for tech in (technologies or []):
            tech_tags.extend(TECH_TO_TAGS.get(tech.lower(), []))

        # Add port-specific tags
        port_tags: list[str] = []
        for port in (open_ports or []):
            port_tags.extend(PORT_TO_TAGS.get(port, []))

        # Merge all tags (deduplicated, order preserved)
        all_tags: list[str] = []
        seen: set[str] = set()
        for tag in base_tags + tech_tags + port_tags + (extra_tags or []):
            if tag and tag not in seen:
                seen.add(tag)
                all_tags.append(tag)

        description = profile_cfg.get("description", "")
        if technologies:
            description += f" | Tech: {', '.join(technologies[:4])}"
        if open_ports:
            description += f" | Ports: {', '.join(str(p) for p in sorted(open_ports)[:6])}"

        logger.info(
            f"Template selection: profile={profile}, "
            f"tags={len(all_tags)}, severities={severities}"
        )

        return TemplateSet(
            tags             = all_tags,
            severities       = severities,
            custom_paths     = custom_paths or [],
            estimated_checks = est_checks,
            description      = description,
        )

    def is_templates_available(self) -> bool:
        """Check if nuclei templates are installed on disk."""
        if not self._templates_dir:
            return False
        return self._templates_dir.exists() and any(self._templates_dir.glob("**/*.yaml"))

    def update_templates(self, timeout: int = 120) -> tuple[bool, str]:
        """
        Update nuclei templates via `nuclei -update-templates`.

        Returns:
            (success, message)
        """
        if not shutil.which("nuclei"):
            return False, "nuclei binary not found on PATH"
        try:
            result = subprocess.run(
                ["nuclei", "-update-templates"],
                capture_output=True,
                text=True,
                timeout=timeout,
            )
            if result.returncode == 0:
                return True, "Templates updated successfully"
            return False, result.stderr.strip()[:500]
        except subprocess.TimeoutExpired:
            return False, f"Template update timed out after {timeout}s"
        except Exception as exc:
            return False, str(exc)

    def list_available_profiles(self) -> list[dict]:
        """Return all available scan profiles with descriptions."""
        return [
            {
                "name":        name,
                "severities":  cfg["severities"],
                "tags":        cfg.get("tags", ["<all>"]),
                "description": cfg["description"],
                "est_checks":  cfg.get("est_checks", 0),
            }
            for name, cfg in PROFILE_TEMPLATES.items()
        ]

    def tags_for_technology(self, tech: str) -> list[str]:
        """Return recommended Nuclei tags for a given technology."""
        return TECH_TO_TAGS.get(tech.lower(), [tech.lower()])

    def tags_for_port(self, port: int) -> list[str]:
        """Return recommended Nuclei tags for a given port."""
        return PORT_TO_TAGS.get(port, [])

    # ── Internal helpers ──────────────────────────────────────────────────────

    def _detect_templates_dir(self) -> Optional[Path]:
        """Auto-detect nuclei templates directory from common locations."""
        candidates = [
            Path.home() / "nuclei-templates",
            Path("/root/nuclei-templates"),
            Path("/opt/nuclei-templates"),
            Path.home() / ".local/nuclei-templates",
        ]
        for p in candidates:
            if p.exists():
                return p
        return None
