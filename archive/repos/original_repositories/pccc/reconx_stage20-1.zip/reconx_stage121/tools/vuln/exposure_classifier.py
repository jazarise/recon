"""
ReconX — Exposure Classifier (Stage 8).

Classifies discovered endpoints and services into exposure categories:
  - Admin interfaces
  - CI/CD systems
  - Cloud dashboards
  - Staging/dev environments
  - Debug endpoints
  - Backup/config files
  - Exposed APIs
  - Developer portals
  - Sensitive data paths
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Optional


# ── Exposure categories ───────────────────────────────────────────────────────

EXPOSURE_CATEGORIES = {
    "admin_interface":   "Admin Interface",
    "cicd_system":       "CI/CD System",
    "cloud_dashboard":   "Cloud Dashboard",
    "monitoring":        "Monitoring Dashboard",
    "staging_env":       "Staging / Dev Environment",
    "debug_endpoint":    "Debug Endpoint",
    "backup_file":       "Backup / Archive File",
    "config_file":       "Configuration File",
    "api_endpoint":      "Exposed API",
    "developer_portal":  "Developer Portal",
    "database_ui":       "Database Management UI",
    "container_mgmt":    "Container Management",
    "secret_file":       "Secret / Credential File",
    "log_file":          "Log File",
    "source_control":    "Source Control",
    "directory_listing": "Directory Listing",
    "info_disclosure":   "Information Disclosure",
}


@dataclass
class ExposureResult:
    """A classified exposure finding."""
    url:          str
    category:     str                   # key from EXPOSURE_CATEGORIES
    label:        str                   # human-readable label
    severity:     str                   # CRITICAL / HIGH / MEDIUM / LOW / INFO
    title:        str                   # brief title
    detail:       str                   # explanation
    matched_rule: str                   # which rule triggered
    confidence:   float   = 1.0
    tags:         list[str] = field(default_factory=list)


# ── Classification rules ──────────────────────────────────────────────────────
# Each rule: pattern (applied to URL/path), category, severity, title, detail, tags

CLASSIFICATION_RULES: list[dict] = [

    # ── Admin Interfaces ──────────────────────────────────────────────────────
    {
        "pattern": r"/(admin|administrator|wp-admin|cpanel|whm|plesk|directadmin)(/|$)",
        "category": "admin_interface", "severity": "MEDIUM",
        "title": "Admin Panel Exposed",
        "detail": "An administrative interface is accessible. If not protected by IP allowlist and MFA, it presents a brute-force and credential-stuffing target.",
        "tags": ["admin", "panel"],
    },
    {
        "pattern": r"/(manage|management|controlpanel|control-panel|backend|back-end)(/|$)",
        "category": "admin_interface", "severity": "MEDIUM",
        "title": "Management Interface Exposed",
        "detail": "A management/control interface is accessible without access restriction visible at URL level.",
        "tags": ["admin", "management"],
    },

    # ── CI/CD Systems ─────────────────────────────────────────────────────────
    {
        "pattern": r"/(jenkins|teamcity|bamboo|travis|circl|drone|github|gitlab|bitbucket|gitea|gogs|concourse|gocd|spinnaker|argo|flux)(/|$|:)",
        "category": "cicd_system", "severity": "HIGH",
        "title": "CI/CD System Exposed",
        "detail": "A CI/CD platform is externally accessible. These systems often contain secrets, pipeline configs, and build artifacts. Compromise can lead to supply-chain attacks.",
        "tags": ["cicd", "devops", "secrets"],
    },
    {
        "pattern": r":8080(/|$)",
        "category": "cicd_system", "severity": "LOW",
        "title": "Alternative HTTP Port (potential CI/CD)",
        "detail": "Port 8080 is commonly used by Jenkins and other CI/CD tools. Verify this is intentionally exposed.",
        "tags": ["port", "cicd"],
    },

    # ── Cloud Dashboards ──────────────────────────────────────────────────────
    {
        "pattern": r"/(grafana|kibana|prometheus|datadog|newrelic|cloudwatch|console\.aws|console\.azure|console\.gcp)(/|$)",
        "category": "cloud_dashboard", "severity": "HIGH",
        "title": "Cloud / Metrics Dashboard Exposed",
        "detail": "A cloud or metrics dashboard is accessible. These often contain infrastructure topology, secrets, or direct cloud console access.",
        "tags": ["cloud", "dashboard", "monitoring"],
    },

    # ── Monitoring ────────────────────────────────────────────────────────────
    {
        "pattern": r"/(grafana|prometheus|alertmanager|jaeger|zipkin|loki|tempo|elastic|opensearch|kibana)(/|$)",
        "category": "monitoring", "severity": "MEDIUM",
        "title": "Monitoring System Exposed",
        "detail": "Monitoring infrastructure exposed externally. May leak service topology, metrics, and logs.",
        "tags": ["monitoring", "metrics", "logs"],
    },
    {
        "pattern": r"/(actuator|actuator/health|actuator/info|actuator/env|actuator/metrics|actuator/beans)(/|$)",
        "category": "debug_endpoint", "severity": "HIGH",
        "title": "Spring Boot Actuator Exposed",
        "detail": "Spring Boot Actuator endpoints expose application internals. /env may leak secrets; /beans exposes full config.",
        "tags": ["spring", "actuator", "debug"],
    },

    # ── Staging / Dev Environments ────────────────────────────────────────────
    {
        "pattern": r"(staging|stage|dev|develop|development|test|testing|qa|uat|sandbox|preview|demo|beta|alpha)\.",
        "category": "staging_env", "severity": "MEDIUM",
        "title": "Staging / Dev Environment Detected",
        "detail": "Staging or dev environments often run with weaker security controls, outdated dependencies, and debug features enabled.",
        "tags": ["staging", "dev", "environment"],
    },
    {
        "pattern": r"/(staging|stage|dev|test|testing|qa|sandbox|preview|demo|beta|alpha)(/|$)",
        "category": "staging_env", "severity": "MEDIUM",
        "title": "Dev/Stage Path Accessible",
        "detail": "A staging or development path is accessible. Verify no production data or credentials are stored here.",
        "tags": ["staging", "dev"],
    },

    # ── Debug Endpoints ───────────────────────────────────────────────────────
    {
        "pattern": r"/(debug|phpinfo|phpinfo\.php|info\.php|test\.php|_profiler|_debug|whoops|xdebug)(/|$|\?)",
        "category": "debug_endpoint", "severity": "HIGH",
        "title": "Debug Endpoint Exposed",
        "detail": "Debug endpoints expose server internals, environment variables, loaded modules, and file paths.",
        "tags": ["debug", "phpinfo", "disclosure"],
    },
    {
        "pattern": r"/(console|rails-console|pry|byebug|python-shell|node-inspector)(/|$)",
        "category": "debug_endpoint", "severity": "CRITICAL",
        "title": "Interactive Console Exposed",
        "detail": "An interactive runtime console is accessible. This typically allows arbitrary code execution on the server.",
        "tags": ["console", "rce", "debug"],
    },

    # ── Backup / Archive Files ────────────────────────────────────────────────
    {
        "pattern": r"\.(bak|backup|old|orig|save|copy|~|swp|tmp|temp|sql|dump|dmp)$",
        "category": "backup_file", "severity": "HIGH",
        "title": "Backup File Exposed",
        "detail": "Backup files may contain source code, database dumps, credentials, or sensitive business data.",
        "tags": ["backup", "file", "disclosure"],
    },
    {
        "pattern": r"\.(zip|tar|tar\.gz|tgz|tar\.bz2|7z|rar|gz)$",
        "category": "backup_file", "severity": "CRITICAL",
        "title": "Archive File Exposed",
        "detail": "Archive file accessible via web — may contain full application source, credentials, or database dumps.",
        "tags": ["archive", "backup", "disclosure"],
    },

    # ── Config / Secret Files ─────────────────────────────────────────────────
    {
        "pattern": r"(\.env|\.env\.local|\.env\.prod|\.env\.production|\.env\.\w+)$",
        "category": "secret_file", "severity": "CRITICAL",
        "title": ".env File Exposed",
        "detail": "Environment files contain API keys, database credentials, and secrets in plaintext.",
        "tags": ["env", "secret", "credential"],
    },
    {
        "pattern": r"(wp-config\.php|config\.php|settings\.php|database\.php|db\.php|configuration\.php)$",
        "category": "config_file", "severity": "CRITICAL",
        "title": "CMS / App Config File Exposed",
        "detail": "Application configuration file accessible — typically contains database credentials and secret keys.",
        "tags": ["config", "credential", "cms"],
    },
    {
        "pattern": r"(\.git/config|\.git/HEAD|\.svn/entries|\.hg/hgrc)$",
        "category": "source_control", "severity": "HIGH",
        "title": "VCS Configuration Exposed",
        "detail": "Version control metadata accessible — can be used to reconstruct full source code repository.",
        "tags": ["git", "vcs", "source"],
    },
    {
        "pattern": r"(id_rsa|id_ecdsa|id_ed25519|\.pem|\.key|\.p12|\.pfx|\.crt|\.cer)$",
        "category": "secret_file", "severity": "CRITICAL",
        "title": "Private Key / Certificate Exposed",
        "detail": "Private key or certificate file accessible — immediate compromise of encrypted communications or authentication.",
        "tags": ["key", "certificate", "secret"],
    },

    # ── Database UIs ──────────────────────────────────────────────────────────
    {
        "pattern": r"/(phpmyadmin|adminer|pgadmin|mongo-express|redis-commander|elastichq|redisinsight|dbadmin|mysqladmin)(/|$)",
        "category": "database_ui", "severity": "CRITICAL",
        "title": "Database Management UI Exposed",
        "detail": "Database administration interface publicly accessible. Direct database access and potential for full data exfiltration.",
        "tags": ["database", "admin", "panel"],
    },

    # ── Container Management ──────────────────────────────────────────────────
    {
        "pattern": r"/(portainer|rancher|kubernetes|k8s-dashboard|docker-ui|swarmpit|lazydocker)(/|$)",
        "category": "container_mgmt", "severity": "CRITICAL",
        "title": "Container Management Interface Exposed",
        "detail": "Container orchestration interface accessible. Compromise typically results in full infrastructure takeover.",
        "tags": ["container", "docker", "kubernetes"],
    },
    {
        "pattern": r":2375(/|$)",
        "category": "container_mgmt", "severity": "CRITICAL",
        "title": "Docker API Port Exposed (unauthenticated)",
        "detail": "Docker daemon API on port 2375 (non-TLS) — full container and host access if reachable.",
        "tags": ["docker", "api", "unauthenticated"],
    },

    # ── API Endpoints ─────────────────────────────────────────────────────────
    {
        "pattern": r"/(swagger|swagger-ui|api-docs|openapi|redoc|api\.json|api\.yaml|graphql|playground)(/|$|\?)",
        "category": "api_endpoint", "severity": "MEDIUM",
        "title": "API Documentation Exposed",
        "detail": "API documentation or schema exposed — reveals full API surface, endpoints, and data models to attackers.",
        "tags": ["api", "swagger", "documentation"],
    },

    # ── Developer Portals ─────────────────────────────────────────────────────
    {
        "pattern": r"/(jira|confluence|notion|wiki|redmine|trac|mantis|bugzilla|phabricator)(/|$)",
        "category": "developer_portal", "severity": "MEDIUM",
        "title": "Developer / Project Management Portal Exposed",
        "detail": "Project management or internal wiki exposed — may contain credentials, infrastructure details, or business data.",
        "tags": ["portal", "devops", "wiki"],
    },

    # ── Log Files ─────────────────────────────────────────────────────────────
    {
        "pattern": r"\.(log|logs|access\.log|error\.log|debug\.log|application\.log)(/|$|\?|$)",
        "category": "log_file", "severity": "HIGH",
        "title": "Log File Accessible",
        "detail": "Log files may contain authentication tokens, session IDs, stack traces, PII, and internal IP addresses.",
        "tags": ["log", "disclosure", "file"],
    },

    # ── Directory Listing ─────────────────────────────────────────────────────
    {
        "pattern": r"Index of /",
        "category": "directory_listing", "severity": "MEDIUM",
        "title": "Directory Listing Enabled",
        "detail": "Web server serves directory listings. Attackers can enumerate all files and discover sensitive assets.",
        "tags": ["listing", "directory", "disclosure"],
    },
]


# ── Exposure Classifier ───────────────────────────────────────────────────────

class ExposureClassifier:
    """
    Classifies URLs, paths, and finding messages into structured exposure categories.

    Supports:
      - URL-based classification (path matching)
      - Message-based classification (Nikto/Nuclei messages)
      - Technology-aware boosting
    """

    def __init__(self) -> None:
        self._compiled = self._compile_rules()

    def _compile_rules(self) -> list[dict]:
        compiled = []
        for rule in CLASSIFICATION_RULES:
            try:
                compiled.append({
                    **rule,
                    "_re": re.compile(rule["pattern"], re.IGNORECASE),
                })
            except re.error:
                pass
        return compiled

    # ── Public API ─────────────────────────────────────────────────────────────

    def classify_url(self, url: str) -> Optional[ExposureResult]:
        """Classify a URL into an exposure category. Returns None if no match."""
        for rule in self._compiled:
            if rule["_re"].search(url):
                return self._make_result(url, rule)
        return None

    def classify_message(self, message: str, url: str = "") -> Optional[ExposureResult]:
        """Classify a finding message string."""
        combined = f"{url} {message}"
        for rule in self._compiled:
            if rule["_re"].search(combined):
                return self._make_result(url or message, rule)
        return None

    def classify_findings(self, findings: list[dict]) -> list[ExposureResult]:
        """
        Classify a list of normalized findings (from Nuclei/Nikto).
        Each finding should have at minimum a 'url' or 'matched_at' key.
        Returns deduplicated ExposureResult list sorted by severity.
        """
        results: list[ExposureResult] = []
        seen: set[str] = set()

        for f in findings:
            url = f.get("matched_at") or f.get("url") or ""
            msg = f.get("message") or f.get("name") or f.get("description") or ""

            result = self.classify_url(url) or self.classify_message(msg, url)

            if result:
                dedup_key = f"{result.category}::{result.matched_rule}::{url[:80]}"
                if dedup_key not in seen:
                    seen.add(dedup_key)
                    results.append(result)

        # Sort by severity
        sev_order = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "INFO": 4}
        results.sort(key=lambda r: sev_order.get(r.severity, 5))
        return results

    def summarize(self, results: list[ExposureResult]) -> dict:
        """Summarize exposure classification results."""
        by_category: dict[str, int] = {}
        by_severity: dict[str, int] = {}
        critical_exposures: list[str] = []

        for r in results:
            by_category[r.label] = by_category.get(r.label, 0) + 1
            by_severity[r.severity] = by_severity.get(r.severity, 0) + 1
            if r.severity == "CRITICAL":
                critical_exposures.append(r.title)

        return {
            "total":              len(results),
            "by_category":        by_category,
            "by_severity":        by_severity,
            "critical_exposures": critical_exposures,
            "critical":           by_severity.get("CRITICAL", 0),
            "high":               by_severity.get("HIGH", 0),
        }

    # ── Internal ──────────────────────────────────────────────────────────────

    def _make_result(self, url: str, rule: dict) -> ExposureResult:
        category = rule["category"]
        return ExposureResult(
            url          = url,
            category     = category,
            label        = EXPOSURE_CATEGORIES.get(category, category),
            severity     = rule["severity"],
            title        = rule["title"],
            detail       = rule["detail"],
            matched_rule = rule["pattern"],
            confidence   = 0.90,
            tags         = rule.get("tags", []),
        )
