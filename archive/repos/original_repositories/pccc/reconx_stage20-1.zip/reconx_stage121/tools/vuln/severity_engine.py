"""
ReconX — Severity Engine (Stage 8).

CVSS-style scoring engine that:
  - Normalizes severity across all tool outputs
  - Computes composite risk scores
  - Maps findings to business impact
  - Prioritizes by exploitability
  - Supports contextual score boosting (internet-exposed, auth bypass, etc.)
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


# ── Severity enum ─────────────────────────────────────────────────────────────

class Severity(str, Enum):
    CRITICAL = "CRITICAL"
    HIGH     = "HIGH"
    MEDIUM   = "MEDIUM"
    LOW      = "LOW"
    INFO     = "INFO"

    @property
    def numeric(self) -> int:
        return {"CRITICAL": 5, "HIGH": 4, "MEDIUM": 3, "LOW": 2, "INFO": 1}[self.value]

    @property
    def color(self) -> str:
        return {
            "CRITICAL": "bold red",
            "HIGH":     "red",
            "MEDIUM":   "yellow",
            "LOW":      "cyan",
            "INFO":     "dim",
        }[self.value]

    @property
    def icon(self) -> str:
        return {"CRITICAL": "🔴", "HIGH": "🟠", "MEDIUM": "🟡", "LOW": "🔵", "INFO": "⚪"}[self.value]

    @classmethod
    def from_string(cls, s: str) -> "Severity":
        mapping = {
            "critical": cls.CRITICAL,
            "high":     cls.HIGH,
            "medium":   cls.MEDIUM,
            "med":      cls.MEDIUM,
            "low":      cls.LOW,
            "info":     cls.INFO,
            "informational": cls.INFO,
            "unknown":  cls.INFO,
        }
        return mapping.get(s.strip().lower(), cls.INFO)

    @classmethod
    def from_cvss(cls, score: float) -> "Severity":
        """Map CVSS numeric score (0–10) to Severity enum."""
        if score >= 9.0:
            return cls.CRITICAL
        if score >= 7.0:
            return cls.HIGH
        if score >= 4.0:
            return cls.MEDIUM
        if score > 0.0:
            return cls.LOW
        return cls.INFO


# ── Score result ──────────────────────────────────────────────────────────────

@dataclass
class ScoredFinding:
    """A finding with computed severity score and business impact metadata."""
    raw_finding:     dict
    source:          str
    severity:        Severity
    base_score:      float       # 0.0–10.0
    adjusted_score:  float       # base + contextual boosts
    business_impact: str         # human-readable impact statement
    exploitability:  str         # "EASY" | "MODERATE" | "HARD" | "UNKNOWN"
    is_actionable:   bool        = True
    boost_reasons:   list[str]   = field(default_factory=list)
    cves:            list[str]   = field(default_factory=list)


# ── Severity engine ───────────────────────────────────────────────────────────

class SeverityEngine:
    """
    Computes risk scores for vulnerability findings.

    Scoring pipeline:
      1. Map raw severity string → base score (0–10)
      2. Apply contextual boosts (exposure, auth, network position)
      3. Apply CVSS score if available (raises base score if higher)
      4. Map final score back → Severity enum
      5. Determine business impact and exploitability tier
    """

    # Base scores per severity level
    BASE_SCORES: dict[str, float] = {
        "critical": 9.5,
        "high":     7.5,
        "medium":   5.0,
        "low":      2.5,
        "info":     0.5,
        "unknown":  0.5,
    }

    # Contextual boost rules (key → score delta + reason label)
    BOOST_RULES: list[dict] = [
        # Exposure boosts
        {
            "condition": "internet_exposed",
            "delta":     1.0,
            "reason":    "Internet-exposed service",
        },
        {
            "condition": "auth_bypass",
            "delta":     2.0,
            "reason":    "Authentication bypass possible",
        },
        {
            "condition": "default_credential",
            "delta":     2.0,
            "reason":    "Default credentials detected",
        },
        {
            "condition": "rce_indicator",
            "delta":     2.5,
            "reason":    "Remote code execution indicator",
        },
        {
            "condition": "data_exposure",
            "delta":     1.5,
            "reason":    "Sensitive data exposure",
        },
        {
            "condition": "has_cve",
            "delta":     0.5,
            "reason":    "Known CVE with public exploit",
        },
        {
            "condition": "no_auth",
            "delta":     1.5,
            "reason":    "Service requires no authentication",
        },
        {
            "condition": "ssl_weak",
            "delta":     0.5,
            "reason":    "Weak SSL/TLS configuration",
        },
        {
            "condition": "backup_exposed",
            "delta":     2.0,
            "reason":    "Backup or configuration file exposed",
        },
        {
            "condition": "admin_panel",
            "delta":     0.5,
            "reason":    "Admin interface exposed",
        },
    ]

    # Business impact templates
    IMPACT_TEMPLATES: dict[str, str] = {
        Severity.CRITICAL.value: (
            "Immediate exploitation risk — potential full system compromise, "
            "data breach, or service takeover. Requires urgent remediation."
        ),
        Severity.HIGH.value: (
            "Significant exploitation risk — data exposure, privilege escalation, "
            "or lateral movement likely. Remediate within 24–72 hours."
        ),
        Severity.MEDIUM.value: (
            "Moderate risk — could be chained with other findings for higher impact. "
            "Remediate within 2 weeks."
        ),
        Severity.LOW.value: (
            "Low direct impact — informational or hardening opportunity. "
            "Address in next maintenance cycle."
        ),
        Severity.INFO.value: (
            "Informational — no direct exploitability. Review for defence-in-depth."
        ),
    }

    # Exploitability tiers based on finding type + score
    EXPLOITABILITY: dict[str, str] = {
        "rce":              "EASY",
        "sqli":             "MODERATE",
        "xss":              "MODERATE",
        "lfi":              "MODERATE",
        "ssrf":             "MODERATE",
        "default_login":    "EASY",
        "exposed_panel":    "EASY",
        "backup_file":      "EASY",
        "directory_index":  "EASY",
        "info_disclosure":  "EASY",
        "missing_header":   "HARD",
        "ssl":              "HARD",
        "outdated":         "MODERATE",
    }

    # ── Public API ────────────────────────────────────────────────────────────

    def score(self, finding: dict, context: Optional[dict] = None) -> ScoredFinding:
        """
        Score a single finding dict.

        Args:
            finding: Normalized finding from NucleiTool or NiktoTool
            context: Optional dict with contextual flags
                     e.g. {"internet_exposed": True, "has_cve": True}

        Returns:
            ScoredFinding with computed scores and metadata
        """
        context = context or {}

        raw_sev   = finding.get("severity", finding.get("sev", "info")).lower()
        cvss      = float(finding.get("cvss_score", 0.0) or 0.0)
        ftype     = finding.get("type", finding.get("category", "")).lower()
        cves      = finding.get("cves", [])
        source    = finding.get("source", "")

        # 1. Base score from severity label
        base = self.BASE_SCORES.get(raw_sev, 0.5)

        # 2. Use CVSS if it gives a higher base
        if cvss > base:
            base = min(cvss, 10.0)

        # 3. Auto-detect context flags from finding content
        context = self._enrich_context(finding, context, cves)

        # 4. Apply boosts
        adjusted   = base
        boost_reasons: list[str] = []
        for rule in self.BOOST_RULES:
            if context.get(rule["condition"], False):
                adjusted += rule["delta"]
                boost_reasons.append(rule["reason"])
        adjusted = min(adjusted, 10.0)

        # 5. Derive final severity
        severity = Severity.from_cvss(adjusted)

        # 6. Business impact
        impact = self.IMPACT_TEMPLATES.get(severity.value, "")

        # 7. Exploitability
        exploitability = self._determine_exploitability(ftype, adjusted, cves)

        return ScoredFinding(
            raw_finding     = finding,
            source          = source or finding.get("source", ""),
            severity        = severity,
            base_score      = round(base, 2),
            adjusted_score  = round(adjusted, 2),
            business_impact = impact,
            exploitability  = exploitability,
            is_actionable   = severity != Severity.INFO,
            boost_reasons   = boost_reasons,
            cves            = cves if isinstance(cves, list) else [],
        )

    def score_batch(
        self,
        findings:  list[dict],
        context:   Optional[dict] = None,
    ) -> list[ScoredFinding]:
        """Score a batch of findings; returns sorted by adjusted_score desc."""
        scored = [self.score(f, context) for f in findings]
        scored.sort(key=lambda s: s.adjusted_score, reverse=True)
        return scored

    def summarize(self, scored: list[ScoredFinding]) -> dict:
        """Generate a summary dict from a list of ScoredFinding objects."""
        by_severity: dict[str, int] = {}
        actionable  = 0
        total_score = 0.0
        cves: set[str] = set()

        for sf in scored:
            sev = sf.severity.value
            by_severity[sev] = by_severity.get(sev, 0) + 1
            if sf.is_actionable:
                actionable += 1
            total_score += sf.adjusted_score
            cves.update(sf.cves)

        avg_score = total_score / len(scored) if scored else 0.0
        overall   = Severity.from_cvss(avg_score) if scored else Severity.INFO

        return {
            "total":       len(scored),
            "actionable":  actionable,
            "by_severity": by_severity,
            "overall":     overall.value,
            "avg_score":   round(avg_score, 2),
            "cves":        sorted(cves),
            "critical":    by_severity.get("CRITICAL", 0),
            "high":        by_severity.get("HIGH", 0),
            "medium":      by_severity.get("MEDIUM", 0),
            "low":         by_severity.get("LOW", 0),
            "info":        by_severity.get("INFO", 0),
        }

    # ── Internal helpers ──────────────────────────────────────────────────────

    def _enrich_context(
        self, finding: dict, context: dict, cves: list[str]
    ) -> dict:
        """Auto-detect contextual flags from finding content."""
        ctx = dict(context)
        msg = (
            finding.get("message", "") +
            finding.get("description", "") +
            finding.get("name", "") +
            finding.get("category", "")
        ).lower()

        if not ctx.get("has_cve"):
            ctx["has_cve"] = bool(cves)

        if not ctx.get("rce_indicator"):
            ctx["rce_indicator"] = any(
                kw in msg for kw in ["remote code", "rce", "command execution", "shellshock", "struts"]
            )

        if not ctx.get("auth_bypass"):
            ctx["auth_bypass"] = any(
                kw in msg for kw in ["auth bypass", "authentication bypass", "unauthenticated", "no auth required"]
            )

        if not ctx.get("default_credential"):
            ctx["default_credential"] = any(
                kw in msg for kw in ["default password", "default credential", "default login", "admin:admin"]
            )

        if not ctx.get("data_exposure"):
            ctx["data_exposure"] = any(
                kw in msg for kw in [".env", "config", "backup", "database", "secret", "token", "key"]
            )

        if not ctx.get("backup_exposed"):
            ctx["backup_exposed"] = any(
                kw in msg for kw in ["backup", ".bak", ".sql", ".zip", ".tar", ".gz"]
            )

        if not ctx.get("ssl_weak"):
            ctx["ssl_weak"] = any(
                kw in msg for kw in ["weak ssl", "sslv2", "sslv3", "tls 1.0", "weak cipher", "self-signed"]
            )

        if not ctx.get("admin_panel"):
            ctx["admin_panel"] = any(
                kw in msg for kw in ["admin panel", "admin interface", "admin page", "dashboard", "jenkins", "grafana"]
            )

        if not ctx.get("no_auth"):
            ctx["no_auth"] = any(
                kw in msg for kw in ["no authentication", "authentication required", "anonymous access", "unauthenticated"]
            )

        return ctx

    def _determine_exploitability(
        self, ftype: str, score: float, cves: list[str]
    ) -> str:
        for key, tier in self.EXPLOITABILITY.items():
            if key in ftype:
                return tier
        # Score-based fallback
        if cves:
            return "MODERATE"
        if score >= 8.0:
            return "EASY"
        if score >= 5.0:
            return "MODERATE"
        return "HARD"
