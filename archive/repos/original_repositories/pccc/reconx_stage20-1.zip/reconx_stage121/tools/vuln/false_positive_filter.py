"""
ReconX — False Positive Filter (Stage 8).

Reduces noise from vulnerability scan outputs by:
  - Suppressing known benign patterns
  - Confidence scoring per finding
  - Technology correlation (finding must match detected tech stack)
  - Response-based validation hints
  - Duplicate suppression
  - Info-only finding threshold management
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Optional


# ── Filter result ─────────────────────────────────────────────────────────────

@dataclass
class FilterResult:
    """Result of filtering a single finding."""
    passed:       bool
    confidence:   float       # final confidence after filter adjustments
    reason:       str         # why it was filtered (if passed=False)
    adjustments:  list[str]   # list of confidence adjustments applied


# ── Known benign patterns (suppress these) ────────────────────────────────────

BENIGN_PATTERNS: list[dict] = [
    # Nuclei info-level tech detection — not a vulnerability
    {
        "condition": lambda f: f.get("severity", "").lower() == "info"
                               and f.get("type", "") == "tech",
        "reason": "Technology detection (info/tech) — not a vulnerability",
    },
    # Generic 'robots.txt found' — informational only
    {
        "condition": lambda f: "robots.txt" in f.get("matched_at", "").lower()
                               and f.get("severity", "").lower() == "info",
        "reason": "robots.txt detection — informational, not exploitable",
    },
    # Missing headers on non-HTTPS — expected behaviour
    {
        "condition": lambda f: (
            f.get("category", "") == "missing_header"
            and "strict-transport-security" in f.get("header_name", "").lower()
            and not f.get("matched_at", "").startswith("https://")
        ),
        "reason": "HSTS missing on HTTP endpoint — expected (HSTS only applies to HTTPS)",
    },
    # X-Content-Type-Options on image endpoints — negligible
    {
        "condition": lambda f: (
            f.get("category", "") == "missing_header"
            and any(ext in f.get("matched_at", "") for ext in [".jpg", ".png", ".gif", ".svg", ".ico"])
        ),
        "reason": "Security header missing on static asset endpoint — negligible risk",
    },
]

# ── Confidence boost rules (increase confidence for strong signals) ────────────

CONFIDENCE_BOOSTS: list[dict] = [
    {
        "condition":   lambda f: bool(f.get("cves")),
        "delta":       +0.15,
        "description": "Known CVE with public identifier",
    },
    {
        "condition":   lambda f: float(f.get("cvss_score", 0) or 0) >= 7.0,
        "delta":       +0.10,
        "description": "High CVSS score (7.0+)",
    },
    {
        "condition":   lambda f: f.get("severity", "").lower() == "critical",
        "delta":       +0.10,
        "description": "Critical severity finding",
    },
    {
        "condition":   lambda f: bool(f.get("extracted")),
        "delta":       +0.15,
        "description": "Data extracted from response (high signal)",
    },
    {
        "condition":   lambda f: bool(f.get("matcher_name")),
        "delta":       +0.05,
        "description": "Specific matcher name indicates targeted template",
    },
    {
        "condition":   lambda f: len(f.get("sources", [])) > 1,
        "delta":       +0.20,
        "description": "Multiple tools confirmed same finding",
    },
]

# ── Confidence penalty rules (reduce confidence for weak signals) ──────────────

CONFIDENCE_PENALTIES: list[dict] = [
    {
        "condition":   lambda f: f.get("severity", "").lower() == "info",
        "delta":       -0.15,
        "description": "Info-level severity — low signal",
    },
    {
        "condition":   lambda f: not f.get("matched_at", "").startswith("http"),
        "delta":       -0.10,
        "description": "Non-HTTP match location — may be indirect",
    },
    {
        "condition":   lambda f: f.get("type", "") == "tech",
        "delta":       -0.20,
        "description": "Technology detection template — passive/indirect",
    },
    {
        "condition":   lambda f: f.get("type", "") == "dns",
        "delta":       -0.10,
        "description": "DNS-based template — indirect evidence",
    },
]

# ── Technology correlation rules ───────────────────────────────────────────────
# If detected_tech is provided, finding must match at least one relevant tech tag

TECH_CORRELATION: dict[str, list[str]] = {
    "wordpress":    ["wordpress", "wp-plugin", "wp-theme", "wp"],
    "drupal":       ["drupal"],
    "joomla":       ["joomla"],
    "apache":       ["apache"],
    "nginx":        ["nginx"],
    "iis":          ["iis", "asp", "aspx"],
    "tomcat":       ["tomcat"],
    "jenkins":      ["jenkins"],
    "grafana":      ["grafana"],
    "spring":       ["spring", "springboot", "actuator"],
    "kubernetes":   ["kubernetes", "k8s"],
    "docker":       ["docker"],
    "php":          ["php"],
    "django":       ["django"],
    "laravel":      ["laravel"],
    "redis":        ["redis"],
    "mongodb":      ["mongodb"],
    "elasticsearch": ["elasticsearch", "elastic"],
}

# Template categories that are always tech-agnostic (skip tech correlation)
TECH_AGNOSTIC_CATEGORIES = {
    "exposed-panels", "default-login", "cve", "exposure",
    "misconfiguration", "network", "dns", "ssl", "generic",
}


class FalsePositiveFilter:
    """
    Multi-stage false positive filtering pipeline.

    Stages:
      1. Benign pattern suppression (immediate reject)
      2. Technology correlation check (penalize mismatches)
      3. Confidence scoring (boosts + penalties)
      4. Threshold gate (drop findings below min_confidence)
    """

    def __init__(
        self,
        min_confidence:     float = 0.50,
        suppress_info:      bool  = False,
        tech_strict:        bool  = False,
    ) -> None:
        """
        Args:
            min_confidence: Findings below this threshold are filtered out.
            suppress_info:  If True, all INFO-severity findings are dropped.
            tech_strict:    If True, tech-specific findings without matching
                            detected tech are dropped rather than just penalized.
        """
        self.min_confidence = min_confidence
        self.suppress_info  = suppress_info
        self.tech_strict    = tech_strict

    # ── Public API ─────────────────────────────────────────────────────────────

    def filter(
        self,
        finding:       dict,
        detected_tech: Optional[list[str]] = None,
    ) -> FilterResult:
        """
        Filter a single finding.

        Args:
            finding:       Normalized finding dict (from Nuclei/Nikto parsers)
            detected_tech: List of technologies detected on target (from WhatWeb, httpx, etc.)

        Returns:
            FilterResult — check .passed before using the finding
        """
        # Stage 0: Info suppression
        if self.suppress_info and finding.get("severity", "").lower() == "info":
            return FilterResult(
                passed=False,
                confidence=0.0,
                reason="INFO severity suppressed (suppress_info=True)",
                adjustments=[],
            )

        # Stage 1: Benign pattern check
        benign = self._check_benign(finding)
        if benign:
            return FilterResult(
                passed=False,
                confidence=0.0,
                reason=benign,
                adjustments=["Benign pattern matched"],
            )

        # Stage 2: Base confidence from severity
        base_confidence = self._base_confidence(finding)
        adjustments: list[str] = []

        # Stage 3: Technology correlation
        tech_adjustment, tech_adj_desc = self._tech_correlation(
            finding, detected_tech or []
        )
        if tech_adjustment != 0.0:
            base_confidence += tech_adjustment
            adjustments.append(tech_adj_desc)

        # If tech_strict and correlation is very negative, reject
        if self.tech_strict and tech_adjustment <= -0.30:
            return FilterResult(
                passed=False,
                confidence=max(0.0, base_confidence),
                reason="Technology mismatch — finding not relevant to detected stack",
                adjustments=adjustments,
            )

        # Stage 4: Confidence boosts
        for boost in CONFIDENCE_BOOSTS:
            try:
                if boost["condition"](finding):
                    base_confidence += boost["delta"]
                    adjustments.append(f"+{boost['delta']:.2f} ({boost['description']})")
            except Exception:
                pass

        # Stage 5: Confidence penalties
        for penalty in CONFIDENCE_PENALTIES:
            try:
                if penalty["condition"](finding):
                    base_confidence += penalty["delta"]
                    adjustments.append(f"{penalty['delta']:.2f} ({penalty['description']})")
            except Exception:
                pass

        # Clamp
        final_confidence = max(0.0, min(1.0, base_confidence))

        # Stage 6: Threshold gate
        if final_confidence < self.min_confidence:
            return FilterResult(
                passed=False,
                confidence=final_confidence,
                reason=f"Confidence {final_confidence:.2f} below threshold {self.min_confidence:.2f}",
                adjustments=adjustments,
            )

        return FilterResult(
            passed=True,
            confidence=final_confidence,
            reason="",
            adjustments=adjustments,
        )

    def filter_batch(
        self,
        findings:       list[dict],
        detected_tech:  Optional[list[str]] = None,
    ) -> tuple[list[dict], int]:
        """
        Filter a batch of findings.

        Returns:
            (passed_findings, suppressed_count)
        """
        passed: list[dict] = []
        suppressed = 0

        for finding in findings:
            result = self.filter(finding, detected_tech)
            if result.passed:
                # Attach final confidence to finding
                enriched = {**finding, "_confidence": result.confidence}
                passed.append(enriched)
            else:
                suppressed += 1

        return passed, suppressed

    def filter_duplicates(self, findings: list[dict]) -> list[dict]:
        """
        Remove exact duplicates from a list of findings.
        Uses (template_id or message) + matched_at as dedup key.
        """
        seen: set[str] = set()
        unique: list[dict] = []

        for f in findings:
            tpl = f.get("template_id", "")
            msg = f.get("message", f.get("name", ""))[:60]
            loc = f.get("matched_at", f.get("url", ""))
            key = f"{tpl or msg}::{loc}"

            if key not in seen:
                seen.add(key)
                unique.append(f)

        return unique

    # ── Internal helpers ──────────────────────────────────────────────────────

    def _check_benign(self, finding: dict) -> Optional[str]:
        """Return reason string if finding matches a benign pattern, else None."""
        for rule in BENIGN_PATTERNS:
            try:
                if rule["condition"](finding):
                    return rule["reason"]
            except Exception:
                pass
        return None

    def _base_confidence(self, finding: dict) -> float:
        """Map severity to initial confidence value."""
        sev = finding.get("severity", "info").lower()
        return {
            "critical": 0.90,
            "high":     0.80,
            "medium":   0.70,
            "low":      0.60,
            "info":     0.45,
            "unknown":  0.40,
        }.get(sev, 0.50)

    def _tech_correlation(
        self, finding: dict, detected_tech: list[str]
    ) -> tuple[float, str]:
        """
        Check if finding's technology tags match detected tech stack.

        Returns:
            (adjustment_delta, description)
        """
        if not detected_tech:
            return 0.0, ""

        tags     = [t.lower() for t in finding.get("tags", [])]
        category = finding.get("category", finding.get("type", "")).lower()
        tpl_id   = finding.get("template_id", "").lower()

        # Skip tech-agnostic categories
        for ag_cat in TECH_AGNOSTIC_CATEGORIES:
            if ag_cat in category or ag_cat in tpl_id:
                return 0.0, ""

        # Check if any detected tech's tags overlap with finding tags
        detected_lower = [t.lower() for t in detected_tech]

        for tech_name in detected_lower:
            corr_tags = TECH_CORRELATION.get(tech_name, [tech_name])
            if any(ct in tags or ct in tpl_id for ct in corr_tags):
                return +0.15, f"Technology correlation match ({tech_name})"

        # No tech match found — slight penalty if finding has tech-specific tags
        tech_specific_tags = set(sum(TECH_CORRELATION.values(), []))
        if any(t in tech_specific_tags for t in tags):
            return -0.20, "Technology mismatch — finding targets tech not in detected stack"

        return 0.0, ""
