"""
ReconX — Nuclei Vulnerability Scanner (Stage 8).

Production-grade Nuclei orchestration with:
  - Technology-aware template selection
  - Severity filtering
  - Parallel template category execution
  - JSONL output parsing
  - Rate-limit and WAF-aware throttling
  - Workflow and custom template support
"""
from __future__ import annotations

import json
import os
import tempfile
import time
from pathlib import Path
from typing import Optional

from ..base import BaseTool
from ...config.settings import VULN_CONFIG
from ...models.tool_result import ExecutionMetrics, ParsedFinding, ToolRunResult


# ── Severity ordering ─────────────────────────────────────────────────────────
SEVERITY_ORDER = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4, "unknown": 5}


class NucleiTool(BaseTool):
    """
    Nuclei template-based vulnerability scanner wrapper.

    Supports targeted scanning by severity, tag, template category, and
    detected technologies. Outputs normalized ParsedFinding objects.
    """

    NAME         = "Nuclei"
    BINARY       = "nuclei"
    CATEGORY     = "vuln"
    STAGE        = 5
    PRIORITY     = 10
    PASSIVE      = False
    TIMEOUT      = 600
    DEPENDENCIES: list[str] = []
    INSTALL_CMD  = "go install -v github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest"

    # ── Template category → nuclei tag mapping ────────────────────────────────
    TAG_MAP: dict[str, list[str]] = {
        "cve":           ["cve"],
        "exposures":     ["exposure", "exposed-panels", "exposed-ports"],
        "misconfigs":    ["misconfiguration", "misconfig", "default-login"],
        "web":           ["xss", "sqli", "ssrf", "lfi", "rfi", "redirect"],
        "cloud":         ["aws", "gcp", "azure", "s3", "cloud"],
        "tech":          ["tech", "technologies", "detect"],
        "network":       ["network", "dns", "ssl"],
        "wordpress":     ["wordpress", "wp-plugin", "wp-theme"],
        "apache":        ["apache"],
        "nginx":         ["nginx"],
        "jenkins":       ["jenkins"],
        "grafana":       ["grafana"],
        "kubernetes":    ["kubernetes", "k8s"],
        "docker":        ["docker"],
        "panels":        ["panel", "login", "dashboard"],
        "tokens":        ["token", "secret", "key", "credential"],
        "files":         ["files", "backup", "config", "git"],
    }

    # ── Technology → tag hint mapping ─────────────────────────────────────────
    TECH_TAG_HINTS: dict[str, list[str]] = {
        "wordpress":   ["wordpress"],
        "drupal":      ["drupal"],
        "joomla":      ["joomla"],
        "apache":      ["apache"],
        "nginx":       ["nginx"],
        "jenkins":     ["jenkins"],
        "grafana":     ["grafana"],
        "kibana":      ["kibana"],
        "gitlab":      ["gitlab"],
        "jira":        ["jira"],
        "confluence":  ["confluence"],
        "django":      ["django"],
        "laravel":     ["laravel"],
        "spring":      ["spring", "springboot"],
        "tomcat":      ["tomcat"],
        "php":         ["php"],
        "iis":         ["iis"],
        "docker":      ["docker"],
        "kubernetes":  ["kubernetes"],
        "redis":       ["redis"],
        "mongodb":     ["mongodb"],
        "elasticsearch": ["elasticsearch"],
    }

    def run(
        self,
        target: str,
        *,
        severities:       Optional[list[str]] = None,
        tags:             Optional[list[str]] = None,
        categories:       Optional[list[str]] = None,
        technologies:     Optional[list[str]] = None,
        custom_templates: Optional[list[str]] = None,
        rate_limit:       int  = 0,
        concurrency:      int  = 0,
        retries:          int  = 1,
        timeout_per_req:  int  = 10,
        update_templates: bool = False,
        **kwargs,
    ) -> ToolRunResult:
        if s := self.skip_if_unavailable(): return s
        if f := self.validate_or_fail(target): return f

        cfg = VULN_CONFIG.get("nuclei", {})

        # ── Resolve effective parameters ───────────────────────────────────────
        severities  = severities  or cfg.get("default_severities", ["critical", "high", "medium"])
        rate_limit  = rate_limit  or cfg.get("rate_limit", 150)
        concurrency = concurrency or cfg.get("concurrency", 25)

        # Build effective tag list from categories + technologies
        effective_tags: list[str] = list(tags or [])
        for cat in (categories or []):
            effective_tags.extend(self.TAG_MAP.get(cat, [cat]))
        for tech in (technologies or []):
            effective_tags.extend(self.TECH_TAG_HINTS.get(tech.lower(), [tech.lower()]))
        # Deduplicate while preserving order
        seen: set[str] = set()
        unique_tags: list[str] = []
        for t in effective_tags:
            if t not in seen:
                seen.add(t)
                unique_tags.append(t)

        t0 = time.perf_counter()

        try:
            # Optional template update (skip by default — slow)
            if update_templates:
                self._log("info", "Updating nuclei templates…")
                self.exec(["nuclei", "-update-templates"], timeout_s=120.0)

            # Write findings to a temp JSONL file for reliable parsing
            with tempfile.NamedTemporaryFile(
                suffix=".jsonl", delete=False, mode="w"
            ) as tf:
                out_path = tf.name

            cmd = self._build_command(
                target=target,
                severities=severities,
                tags=unique_tags,
                custom_templates=custom_templates,
                rate_limit=rate_limit,
                concurrency=concurrency,
                retries=retries,
                timeout_per_req=timeout_per_req,
                out_path=out_path,
            )

            self._log("info", f"Running: {' '.join(cmd[:8])} …")
            res = self.exec(cmd, timeout_s=float(self.timeout), expected_codes=(0, 1))
            dur = time.perf_counter() - t0

            if res.timed_out:
                self._cleanup(out_path)
                return ToolRunResult.timeout(self.NAME, dur, self.timeout)

            raw_jsonl = self._read_and_cleanup(out_path)
            parsed    = self.parse_output(raw_jsonl)

            findings = self._to_parsed_findings(parsed.get("findings", []))

            self._log(
                "info",
                f"Complete — {len(findings)} findings in {dur:.1f}s "
                f"(critical={parsed.get('by_severity', {}).get('critical', 0)}, "
                f"high={parsed.get('by_severity', {}).get('high', 0)})"
            )

            return self.build_result(
                data=parsed,
                findings=findings,
                stdout=res.stdout or "",
                stderr=res.stderr or "",
                duration_s=dur,
                returncode=res.returncode or 0,
            )

        except Exception as exc:
            import traceback
            dur = time.perf_counter() - t0
            self._cleanup(out_path if "out_path" in dir() else None)
            return self.fail(
                reason="runtime_error",
                message=str(exc),
                duration_s=dur,
                tb=traceback.format_exc(),
            )

    # ── Command builder ───────────────────────────────────────────────────────

    def _build_command(
        self,
        target:           str,
        severities:       list[str],
        tags:             list[str],
        custom_templates: Optional[list[str]],
        rate_limit:       int,
        concurrency:      int,
        retries:          int,
        timeout_per_req:  int,
        out_path:         str,
    ) -> list[str]:
        cmd = [
            "nuclei",
            "-u", target,
            "-jsonl",
            "-o", out_path,
            "-rl",  str(rate_limit),
            "-c",   str(concurrency),
            "-retries", str(retries),
            "-timeout", str(timeout_per_req),
            "-silent",
            "-no-interactsh",       # avoid external callback dependency
        ]

        if severities:
            cmd += ["-severity", ",".join(severities)]

        if tags:
            cmd += ["-tags", ",".join(tags)]

        if custom_templates:
            for tpl in custom_templates:
                cmd += ["-t", tpl]

        return cmd

    # ── Output parser ─────────────────────────────────────────────────────────

    def parse_output(self, raw: str, **kwargs) -> dict:
        """Parse JSONL nuclei output into structured findings dict."""
        if not raw or not raw.strip():
            return {"findings": [], "by_severity": {}, "by_type": {}, "total": 0}

        findings: list[dict] = []
        by_severity: dict[str, int] = {}
        by_type: dict[str, int] = {}
        seen_keys: set[str] = set()

        for line in raw.splitlines():
            line = line.strip()
            if not line or not line.startswith("{"):
                continue
            try:
                entry = json.loads(line)
            except json.JSONDecodeError:
                continue

            finding = self._normalize_finding(entry)
            if not finding:
                continue

            # Deduplicate by template-id + matched-at
            dedup_key = f"{finding['template_id']}::{finding['matched_at']}"
            if dedup_key in seen_keys:
                continue
            seen_keys.add(dedup_key)

            findings.append(finding)
            sev = finding["severity"].lower()
            by_severity[sev] = by_severity.get(sev, 0) + 1
            ftype = finding["type"]
            by_type[ftype] = by_type.get(ftype, 0) + 1

        # Sort by severity priority
        findings.sort(key=lambda f: SEVERITY_ORDER.get(f["severity"].lower(), 5))

        return {
            "findings":    findings,
            "by_severity": by_severity,
            "by_type":     by_type,
            "total":       len(findings),
        }

    def _normalize_finding(self, entry: dict) -> Optional[dict]:
        """Normalize a single nuclei JSONL entry into ReconX schema."""
        try:
            info       = entry.get("info", {})
            severity   = info.get("severity", "unknown").lower()
            name       = info.get("name", entry.get("template-id", "unknown"))
            tpl_id     = entry.get("template-id", "")
            matched_at = entry.get("matched-at", entry.get("host", ""))
            ftype      = entry.get("type", "http")
            curl_cmd   = entry.get("curl-command", "")
            extractor  = entry.get("extracted-results", [])
            matcher    = entry.get("matcher-name", "")
            cves       = self._extract_cves(info)
            cvss       = info.get("classification", {}).get("cvss-score", 0.0)

            return {
                "template_id":  tpl_id,
                "name":         name,
                "severity":     severity,
                "type":         ftype,
                "matched_at":   matched_at,
                "description":  info.get("description", ""),
                "tags":         info.get("tags", []),
                "cves":         cves,
                "cvss_score":   float(cvss) if cvss else 0.0,
                "matcher_name": matcher,
                "extracted":    extractor if isinstance(extractor, list) else [],
                "curl_command": curl_cmd,
                "reference":    info.get("reference", []),
            }
        except Exception:
            return None

    def _extract_cves(self, info: dict) -> list[str]:
        cves: list[str] = []
        classification = info.get("classification", {})
        cve_ids = classification.get("cve-id", [])
        if isinstance(cve_ids, list):
            cves.extend(cve_ids)
        elif isinstance(cve_ids, str) and cve_ids:
            cves.append(cve_ids)
        # Also scan tags
        for tag in info.get("tags", []):
            if tag.upper().startswith("CVE-"):
                if tag.upper() not in [c.upper() for c in cves]:
                    cves.append(tag.upper())
        return cves

    # ── ParsedFinding converter ───────────────────────────────────────────────

    def _to_parsed_findings(self, findings: list[dict]) -> list[ParsedFinding]:
        result: list[ParsedFinding] = []
        for f in findings:
            confidence = self._confidence_from_severity(f["severity"])
            pf = ParsedFinding(
                finding_type="vulnerability",
                value=f["matched_at"],
                source=self.NAME,
                confidence=confidence,
                metadata={
                    "template_id": f["template_id"],
                    "name":        f["name"],
                    "severity":    f["severity"],
                    "type":        f["type"],
                    "cves":        f["cves"],
                    "cvss_score":  f["cvss_score"],
                    "description": f["description"],
                    "tags":        f["tags"],
                    "extracted":   f["extracted"],
                    "reference":   f["reference"],
                },
            )
            result.append(pf)
        return result

    def _confidence_from_severity(self, severity: str) -> float:
        return {
            "critical": 0.95,
            "high":     0.90,
            "medium":   0.80,
            "low":      0.70,
            "info":     0.60,
        }.get(severity.lower(), 0.50)

    # ── Filesystem helpers ────────────────────────────────────────────────────

    def _read_and_cleanup(self, path: Optional[str]) -> str:
        if not path:
            return ""
        try:
            content = Path(path).read_text(encoding="utf-8", errors="replace")
        except FileNotFoundError:
            content = ""
        finally:
            self._cleanup(path)
        return content

    def _cleanup(self, path: Optional[str]) -> None:
        if path and os.path.exists(path):
            try:
                os.unlink(path)
            except OSError:
                pass
