"""
ReconX — massdns wrapper.

massdns is a high-performance stub DNS resolver capable of resolving
millions of domain names per second. Used to validate large subdomain
lists produced by enumeration tools. Requires a resolver list.

Stage 2 — Active DNS Mass Resolution.
"""
from __future__ import annotations
import os
import re
import time
from pathlib import Path
from typing import Optional

from ..base import BaseTool
from ...models.tool_result import ParsedFinding, RunStatus, ToolRunResult

_BUILTIN_RESOLVERS = [
    "8.8.8.8", "8.8.4.4", "1.1.1.1", "1.0.0.1",
    "9.9.9.9", "149.112.112.112", "208.67.222.222", "208.67.220.220",
    "64.6.64.6", "64.6.65.6", "84.200.69.80", "84.200.70.40",
    "185.228.168.9", "185.228.169.9", "76.76.19.19", "76.223.122.150",
]


class MassDNSTool(BaseTool):

    NAME         = "massdns"
    BINARY       = "massdns"
    CATEGORY     = "dns_intel"
    STAGE        = 2
    PRIORITY     = 10
    PASSIVE      = False
    TIMEOUT      = 300
    DEPENDENCIES: list[str] = []
    INSTALL_CMD  = (
        "git clone https://github.com/blechschmidt/massdns && "
        "cd massdns && make && sudo cp bin/massdns /usr/local/bin/"
    )

    # ── run ───────────────────────────────────────────────────────────────────

    def run(
        self,
        target: str,
        *,
        wordlist:      Optional[str]       = None,
        resolver_file: Optional[str]       = None,
        subdomains:    Optional[list[str]] = None,
        record_types:  list[str]           = None,
        threads:       int                 = 500,
        max_retries:   int                 = 3,
        **kwargs,
    ) -> ToolRunResult:
        """
        Args:
            target:        Root domain to resolve against.
            wordlist:      Path to subdomain wordlist.
            resolver_file: Path to resolver IP list (auto-generated if absent).
            subdomains:    Pre-built list of FQDNs to resolve (skips wordlist).
            record_types:  DNS record types to query (default: A).
            threads:       Concurrent DNS query threads.
            max_retries:   Per-query retry count.
        """
        if s := self.skip_if_unavailable():
            return s

        rtypes = record_types or ["A"]
        t0 = time.perf_counter()

        # Build input file
        input_path = self._build_input(target, wordlist, subdomains)
        if not input_path:
            return self.fail("no_input", "No wordlist or subdomains provided.")

        # Resolver file
        res_file = resolver_file or self._write_resolvers()
        out_path = "/tmp/massdns_out.txt"

        args = [
            "-r", res_file,
            "-t", ",".join(rtypes),
            "-o", "S",                     # simple text output
            "-w", out_path,
            "--retry", str(max_retries),
            "--flush",
            "-q",
            input_path,
        ]

        # massdns uses thread count via -s (status lines), actual concurrency via OS
        res = self.exec(args, timeout_s=float(self.timeout), expected_codes=(0, 1))
        dur = time.perf_counter() - t0

        if res.timed_out:
            return ToolRunResult.timeout(self.NAME, dur, self.timeout)

        raw = self._read_and_clean(out_path) or res.stdout
        data = self.parse_output(raw)
        findings = self._build_findings(data)
        r = self.build_result(data, findings, stdout=res.stdout,
                              duration_s=dur, returncode=res.returncode)
        if not data["resolved"]: r.status = RunStatus.NO_OUTPUT
        return r

    # ── parse_output ──────────────────────────────────────────────────────────

    def parse_output(self, raw: str, **kwargs) -> dict:
        """
        massdns -o S format:
          sub.example.com. A 1.2.3.4
          www.example.com. CNAME target.cdn.net.
          fail.example.com. -- NXDOMAIN
        """
        if not raw.strip():
            return self._empty()

        resolved:  list[dict] = []
        nxdomain:  list[str]  = []
        wildcards: list[str]  = []
        ip_re = re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b")

        for line in raw.splitlines():
            line = line.strip()
            if not line or line.startswith(";"):
                continue

            parts = line.split()
            if len(parts) < 3:
                continue

            fqdn   = parts[0].rstrip(".")
            rtype  = parts[1] if len(parts) > 1 else ""
            rdata  = parts[2] if len(parts) > 2 else ""

            if "NXDOMAIN" in line or "SERVFAIL" in line:
                nxdomain.append(fqdn)
                continue

            if rtype in ("A", "AAAA"):
                resolved.append({
                    "fqdn":  fqdn,
                    "type":  rtype,
                    "value": rdata.rstrip("."),
                })
            elif rtype == "CNAME":
                resolved.append({
                    "fqdn":  fqdn,
                    "type":  "CNAME",
                    "value": rdata.rstrip("."),
                })

        return {
            "resolved":  resolved,
            "nxdomain":  nxdomain,
            "wildcards": wildcards,
            "count":     len(resolved),
        }

    # ── internal ──────────────────────────────────────────────────────────────

    def _build_input(
        self,
        root:      str,
        wordlist:  Optional[str],
        subdomains: Optional[list[str]],
    ) -> Optional[str]:
        path = "/tmp/massdns_input.txt"
        if subdomains:
            Path(path).write_text("\n".join(subdomains))
            return path
        if wordlist and os.path.exists(wordlist):
            # Prefix each word with root domain
            words = Path(wordlist).read_text().splitlines()
            fqdns = [f"{w.strip()}.{root}" for w in words if w.strip()]
            Path(path).write_text("\n".join(fqdns))
            return path
        return None

    def _write_resolvers(self) -> str:
        path = "/tmp/massdns_resolvers.txt"
        Path(path).write_text("\n".join(_BUILTIN_RESOLVERS))
        return path

    @staticmethod
    def _read_and_clean(path: str) -> str:
        try:
            if os.path.exists(path):
                data = Path(path).read_text()
                os.unlink(path)
                return data
        except Exception:
            pass
        return ""

    @staticmethod
    def _empty() -> dict:
        return {"resolved": [], "nxdomain": [], "wildcards": [], "count": 0}

    def _build_findings(self, data: dict) -> list[ParsedFinding]:
        findings = []
        for r in data.get("resolved", []):
            findings.append(ParsedFinding(
                finding_type="subdomain",
                value=r["fqdn"],
                source=self.NAME,
                confidence=1.0,
                metadata={"record_type": r["type"], "resolved_to": r["value"]},
            ))
        return findings
