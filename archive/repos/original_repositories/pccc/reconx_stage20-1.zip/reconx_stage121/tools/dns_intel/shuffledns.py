"""
ReconX — shuffledns wrapper.

shuffledns wraps massdns with wildcard detection and filtering logic.
It resolves subdomain lists at scale while automatically removing
wildcard false positives — a common problem with mass DNS tools.

Stage 2 — Active DNS Validation with Wildcard Filtering.
"""
from __future__ import annotations
import os
import re
import time
from pathlib import Path
from typing import Optional

from ..base import BaseTool
from ...models.tool_result import ParsedFinding, RunStatus, ToolRunResult

_DEFAULT_RESOLVERS = [
    "8.8.8.8", "1.1.1.1", "9.9.9.9", "8.8.4.4",
    "1.0.0.1", "64.6.64.6", "208.67.222.222", "149.112.112.112",
]


class ShuffleDNSTool(BaseTool):

    NAME         = "shuffledns"
    BINARY       = "shuffledns"
    CATEGORY     = "dns_intel"
    STAGE        = 2
    PRIORITY     = 12
    PASSIVE      = False
    TIMEOUT      = 300
    DEPENDENCIES: list[str] = []
    INSTALL_CMD  = "go install github.com/projectdiscovery/shuffledns/cmd/shuffledns@latest"

    # ── run ───────────────────────────────────────────────────────────────────

    def run(
        self,
        target: str,
        *,
        wordlist:      Optional[str]       = None,
        resolver_file: Optional[str]       = None,
        subdomains:    Optional[list[str]] = None,
        mode:          str                 = "resolve",   # "bruteforce"|"resolve"
        threads:       int                 = 10000,
        retries:       int                 = 5,
        **kwargs,
    ) -> ToolRunResult:
        """
        Args:
            target:        Root domain.
            wordlist:      Wordlist path (bruteforce mode).
            resolver_file: Resolver IPs file.
            subdomains:    Pre-built FQDN list (resolve mode).
            mode:          'bruteforce' or 'resolve'.
            threads:       Concurrent resolution threads.
            retries:       Per-query retries.
        """
        if s := self.skip_if_unavailable():
            return s

        res_file = resolver_file or self._write_resolvers()
        out_path = "/tmp/shuffledns_out.txt"
        t0 = time.perf_counter()

        args = [
            "-d", target,
            "-r", res_file,
            "-o", out_path,
            "-t", str(threads),
            "-retries", str(retries),
            "-silent",
        ]

        if mode == "bruteforce" and wordlist:
            args += ["-w", wordlist]
        elif subdomains:
            sub_file = "/tmp/shuffledns_input.txt"
            Path(sub_file).write_text("\n".join(subdomains))
            args += ["-list", sub_file]

        res = self.exec(args, timeout_s=float(self.timeout), expected_codes=(0, 1))
        dur = time.perf_counter() - t0

        if res.timed_out:
            return ToolRunResult.timeout(self.NAME, dur, self.timeout)
        if res.returncode == 127:
            return ToolRunResult.skipped(self.NAME, res.stderr)

        raw = self._read_file(out_path) or res.stdout
        data = self.parse_output(raw)
        findings = self._build_findings(data)
        r = self.build_result(data, findings, stdout=res.stdout,
                              duration_s=dur, returncode=res.returncode)
        if not data["subdomains"]: r.status = RunStatus.NO_OUTPUT
        return r

    # ── parse_output ──────────────────────────────────────────────────────────

    def parse_output(self, raw: str, **kwargs) -> dict:
        """shuffledns -silent outputs one valid FQDN per line."""
        if not raw.strip():
            return {"subdomains": [], "count": 0, "wildcards_filtered": 0}

        ansi_re   = re.compile(r"\x1b\[[0-9;]*[A-Za-z]")
        domain_re = re.compile(
            r"\b([a-zA-Z0-9](?:[a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?"
            r"(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?)+\.[a-zA-Z]{2,})\b"
        )
        subs: list[str] = []
        seen: set[str]  = set()
        wildcards_filtered = 0

        for line in raw.splitlines():
            line = ansi_re.sub("", line).strip()
            if not line:
                continue
            if "wildcard" in line.lower():
                try:
                    wildcards_filtered = int(re.search(r"\d+", line).group())
                except Exception:
                    pass
                continue
            for m in domain_re.findall(line):
                if m not in seen:
                    seen.add(m)
                    subs.append(m)

        return {
            "subdomains":         sorted(subs),
            "count":              len(subs),
            "wildcards_filtered": wildcards_filtered,
        }

    # ── internal ──────────────────────────────────────────────────────────────

    @staticmethod
    def _write_resolvers() -> str:
        path = "/tmp/shuffledns_resolvers.txt"
        Path(path).write_text("\n".join(_DEFAULT_RESOLVERS))
        return path

    @staticmethod
    def _read_file(path: str) -> str:
        try:
            if os.path.exists(path):
                data = Path(path).read_text()
                os.unlink(path)
                return data
        except Exception:
            pass
        return ""

    def _build_findings(self, data: dict) -> list[ParsedFinding]:
        return [
            ParsedFinding(
                finding_type="subdomain", value=sub,
                source=self.NAME, confidence=0.97,
                metadata={"wildcard_filtered": True},
            )
            for sub in data.get("subdomains", [])
        ]
