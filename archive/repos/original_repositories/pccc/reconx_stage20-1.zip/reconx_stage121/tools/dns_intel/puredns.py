"""
ReconX — puredns wrapper.

puredns is a fast and reliable domain resolver and brute-force tool
that uses massdns under the hood while adding accurate wildcard detection
via a two-phase resolution approach. Industry standard for high-volume
subdomain validation in bug-bounty workflows.

Stage 2 — Active DNS Validation (high-accuracy, wildcard-aware).
"""
from __future__ import annotations
import os
import re
import time
from pathlib import Path
from typing import Optional

from ..base import BaseTool
from ...models.tool_result import ParsedFinding, RunStatus, ToolRunResult

_DEFAULT_RESOLVERS = [
    "8.8.8.8", "1.1.1.1", "9.9.9.9", "8.8.4.4", "1.0.0.1",
    "64.6.64.6", "208.67.222.222", "149.112.112.112",
    "185.228.168.9", "76.76.19.19",
]

_TRUSTED_RESOLVERS = ["8.8.8.8", "1.1.1.1", "9.9.9.9"]


class PureDNSTool(BaseTool):

    NAME         = "puredns"
    BINARY       = "puredns"
    CATEGORY     = "dns_intel"
    STAGE        = 2
    PRIORITY     = 14
    PASSIVE      = False
    TIMEOUT      = 300
    DEPENDENCIES: list[str] = ["massdns"]
    INSTALL_CMD  = "go install github.com/d3mondev/puredns/v2@latest"

    # ── run ───────────────────────────────────────────────────────────────────

    def run(
        self,
        target: str,
        *,
        wordlist:        Optional[str]       = None,
        resolver_file:   Optional[str]       = None,
        trusted_file:    Optional[str]       = None,
        subdomains:      Optional[list[str]] = None,
        mode:            str                 = "resolve",  # "bruteforce"|"resolve"
        rate_limit:      int                 = 0,
        wildcard_tests:  int                 = 3,
        **kwargs,
    ) -> ToolRunResult:
        """
        Args:
            target:          Root domain.
            wordlist:        Subdomain wordlist (bruteforce mode).
            resolver_file:   Untrusted resolver list (used for initial resolution).
            trusted_file:    Trusted resolver list (used for wildcard verification).
            subdomains:      Pre-built FQDN list (resolve mode).
            mode:            'bruteforce' or 'resolve'.
            rate_limit:      Max DNS queries per second (0 = unlimited).
            wildcard_tests:  Number of random labels to test for wildcard detection.
        """
        if s := self.skip_if_unavailable():
            return s

        res_file     = resolver_file or self._write_resolvers(_DEFAULT_RESOLVERS, "puredns_r.txt")
        trusted_file = trusted_file  or self._write_resolvers(_TRUSTED_RESOLVERS, "puredns_t.txt")
        out_path     = "/tmp/puredns_out.txt"
        t0           = time.perf_counter()

        if mode == "bruteforce":
            if not wordlist:
                return self.fail("missing_wordlist", "Bruteforce mode requires a wordlist.")
            args = ["bruteforce", wordlist, target,
                    "-r", res_file,
                    "--resolvers-trusted", trusted_file,
                    "--wildcard-tests", str(wildcard_tests),
                    "-q",
                    "--write", out_path]
        else:
            # resolve mode — takes a list of FQDNs
            if subdomains:
                sub_file = "/tmp/puredns_input.txt"
                Path(sub_file).write_text("\n".join(subdomains))
            else:
                return self.fail("missing_input", "Resolve mode requires subdomains list.")

            args = ["resolve", sub_file,
                    "-r", res_file,
                    "--resolvers-trusted", trusted_file,
                    "-q",
                    "--write", out_path]

        if rate_limit:
            args += ["-l", str(rate_limit)]

        res = self.exec(args, timeout_s=float(self.timeout), expected_codes=(0, 1))
        dur = time.perf_counter() - t0

        if res.timed_out:
            return ToolRunResult.timeout(self.NAME, dur, self.timeout)
        if res.returncode == 127:
            return ToolRunResult.skipped(self.NAME, res.stderr)

        raw = self._read_file(out_path) or res.stdout
        data = self.parse_output(raw)
        findings = self._build_findings(data)
        r = self.build_result(data, findings, stdout=res.stdout,
                              duration_s=dur, returncode=res.returncode)
        if not data["subdomains"]: r.status = RunStatus.NO_OUTPUT
        return r

    # ── parse_output ──────────────────────────────────────────────────────────

    def parse_output(self, raw: str, **kwargs) -> dict:
        """puredns outputs one valid FQDN per line (clean, no headers)."""
        if not raw.strip():
            return {"subdomains": [], "count": 0}

        ansi_re   = re.compile(r"\x1b\[[0-9;]*[A-Za-z]")
        domain_re = re.compile(
            r"\b([a-zA-Z0-9](?:[a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?"
            r"(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?)+\.[a-zA-Z]{2,})\b"
        )
        subs: list[str] = []
        seen: set[str]  = set()

        for line in raw.splitlines():
            line = ansi_re.sub("", line).strip()
            if not line or line.startswith("["):
                continue
            for m in domain_re.findall(line):
                if m not in seen:
                    seen.add(m)
                    subs.append(m)

        return {"subdomains": sorted(subs), "count": len(subs)}

    # ── internal ──────────────────────────────────────────────────────────────

    @staticmethod
    def _write_resolvers(resolvers: list[str], filename: str) -> str:
        path = f"/tmp/{filename}"
        Path(path).write_text("\n".join(resolvers))
        return path

    @staticmethod
    def _read_file(path: str) -> str:
        try:
            if os.path.exists(path):
                data = Path(path).read_text()
                os.unlink(path)
                return data
        except Exception:
            pass
        return ""

    def _build_findings(self, data: dict) -> list[ParsedFinding]:
        return [
            ParsedFinding(
                finding_type="subdomain", value=sub,
                source=self.NAME, confidence=0.99,
                metadata={"validation": "two-phase-wildcard-aware"},
            )
            for sub in data.get("subdomains", [])
        ]
