"""
ReconX — WhatWeb wrapper for web technology fingerprinting.
"""
from __future__ import annotations
import json
import logging

from .base import BaseTool

logger = logging.getLogger("reconx.tools.whatweb")


class WhatwebTool(BaseTool):
    BINARY = "whatweb"
    NAME = "WhatWeb"

    def run(self, target: str, **kwargs) -> dict:
        if not self.is_available():
            logger.warning("whatweb not found; skipping web fingerprinting.")
            return {"technologies": []}

        # Use --log-json for machine-readable output
        stdout, _, rc = self._run(
            [target, "--log-json=-", "--quiet"],
            timeout=60,
        )

        technologies: list[str] = []

        for line in stdout.splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                records = json.loads(line)
                if isinstance(records, list):
                    for record in records:
                        for plugin_name, plugin_data in record.get("plugins", {}).items():
                            tech = plugin_name
                            versions = plugin_data.get("version", [])
                            if versions:
                                tech += f" {versions[0]}"
                            technologies.append(tech)
            except (json.JSONDecodeError, AttributeError):
                continue

        return {"technologies": list(set(technologies))}
