# ReconX — Stage 12.3 Changelog

## Overview

Stage 12.3 completes the modern reconnaissance ecosystem with 17 new tools
across 8 categories. ReconX now covers the full professional recon stack:
DNS intelligence pipelines, visual recon, API surface mapping, secret
detection, cloud exposure, certificate intelligence, TLS auditing, and
identity OSINT.

---

## New Tools (17)

### DNS Intelligence  (`tools/dns_intel/`)

| File | Class | Description |
|---|---|---|
| `massdns.py` | `MassDNSTool` | High-performance DNS resolution at millions of queries/sec. Built-in resolver list. |
| `shuffledns.py` | `ShuffleDNSTool` | massdns wrapper with automatic wildcard detection and filtering. |
| `puredns.py` | `PureDNSTool` | Two-phase DNS validation: public resolvers → trusted resolver verification. Industry standard. |

### Screenshot Intelligence  (`tools/screenshot/`)

| File | Class | Description |
|---|---|---|
| `aquatone.py` | `AquatoneTool` | Screenshots + visual clustering + HTML report. Reads aquatone_session.json. |
| `gowitness.py` | `GoWitnessTool` | Modern screenshotter with SQLite storage. Reads DB directly for structured results. |

### API Recon  (`tools/api_recon/`)

| File | Class | Description |
|---|---|---|
| `kiterunner.py` | `KiterunnerTool` | API route discovery using Swagger/OpenAPI-derived .kite wordlists. JSON + text parse. |
| `graphw00f.py` | `Graphw00fTool` | GraphQL detection + engine fingerprinting. HTTP introspection probe fallback. 17 engine signatures. |

### Secret Intelligence  (`tools/secrets/`)

| File | Class | Description |
|---|---|---|
| `trufflehog.py` | `TrufflehogTool` | 700+ credential detectors with live verification. Automatic severity escalation for critical types. |
| `gitleaks.py` | `GitleaksTool` | Fast git secret scanner. Reads JSON report file; text fallback. |

### Cloud Recon  (`tools/cloud/`)

| File | Class | Description |
|---|---|---|
| `s3scanner.py` | `S3ScannerTool` | S3/GCS/Azure bucket exposure detection. HTTP HEAD probe fallback with 15 bucket name patterns per domain. |

### Certificate Intelligence  (`tools/certs/`)

| File | Class | Description |
|---|---|---|
| `crtsh.py` | `CrtshTool` | crt.sh CT log API — zero binary required. Wildcard dedup, SAN extraction, cert metadata. |
| `tlsx.py` | `TLSXTool` | TLS fingerprinting + SAN extraction + JARM. Python `ssl` socket fallback. |

### Fingerprinting  (`tools/fingerprint/`)

| File | Class | Description |
|---|---|---|
| `wafw00f.py` | `Wafw00fTool` | WAF detection (160+ signatures). HTTP header/cookie/body probe fallback with 15 WAF signatures. |
| `testssl.py` | `TestSSLTool` | TLS vulnerability audit. JSON report parse; severity filtering; escalates known critical check IDs. |

### Identity Intelligence  (`tools/identity/`)

| File | Class | Description |
|---|---|---|
| `sherlock.py` | `SherlockTool` | Username enumeration across 400+ platforms. HTTP probe fallback for 15 high-value platforms. |
| `holehe.py` | `HoleheTool` | Email-to-account discovery via password-reset probing. Clean `[+]/[-]/[x]` output parse. |
| `phoneinfoga.py` | `PhoneInfogaTool` | Phone number intelligence: carrier, country, line type. JSON + text fallback parse. |

---

## New Infrastructure

### Knowledge Catalog  (`knowledge/tools/s123/stage123_catalog.py`)
- 17 `ToolKnowledge` entries with full educational content
- 8 new categories: DNS Intelligence, Screenshot Intelligence, API Recon,
  Secret Intelligence, Cloud Recon, Certificate Intelligence, Fingerprinting,
  Identity Intelligence
- `get_stage123_by_category()`, `search_stage123()` utility functions
- Passive/active correctly flagged: crt.sh, trufflehog, s3scanner, sherlock,
  holehe, phoneinfoga all marked passive; massdns, kiterunner, testssl active

### Registry  (`tools/registry_123.py`)
- `get_123_additions()` — loads all 17 Stage 12.3 tools
- `get_full_registry_123()` — single call merges 12.1 + 12.2 + 12.3 (40+ tools)
- `_NullTool` stub pattern maintained — no registry crash on missing tool

### Tests  (`tests/test_stage123_integration.py`)
- **4 test classes, 45+ test methods**
- Import, attribute, parse_output safety, is_available() for all 17 tools
- Correctness tests for realistic output samples:
  - massdns: A/CNAME/NXDOMAIN parsing
  - graphw00f: JSON parse + Apollo fingerprint detection
  - trufflehog: JSON parse + severity escalation + redaction
  - gitleaks: JSON report parse
  - s3scanner: JSON + provider detection + bucket name generation
  - crtsh: SAN extraction + wildcard stripping
  - tlsx: JSON parse + subdomain extraction from SAN
  - wafw00f: text parse + Cloudflare signature regex
  - testssl: JSON severity filtering (OK filtered, CRITICAL retained)
  - sherlock: `[+]/[-]` line parse
  - holehe: `[+]/[-]/[x]` line parse
  - phoneinfoga: JSON carrier/country parse
- Catalog: 17 entries, 8 categories, all populated, search, passive flags
- Registry: all 17 present, no crash, NullTool safe run()

---

## Design Decisions

### gowitness: SQLite-first result collection
GoWitness stores results in a SQLite DB rather than just files. The wrapper
reads the DB directly via Python's `sqlite3` standard library when available,
falling back to filesystem PNG walk. This gives structured metadata (URL,
title, HTTP status) rather than just file paths.

### crt.sh: Zero-binary tool
The entire implementation is a pure-Python HTTPS API client. No binary
is shipped or required — the `BINARY = "curl"` field is nominal. This
tool is always available in any Python environment with internet access.

### graphw00f: HTTP introspection probe fallback
Rather than returning SKIPPED when the binary is absent, the fallback
actively probes 13 common GraphQL paths with a real introspection query
and fingerprints the response body/headers against 15 engine signatures.
This gives useful results without any dependencies.

### s3scanner: Domain-derived bucket name generation
`_bucket_names(domain)` generates 16 candidate bucket names from a domain
(base name, with common suffixes: -backup, -dev, -prod, -assets, etc.)
The fallback HTTP probe tests each name against 5 cloud storage endpoints.

### wafw00f: Dual-request probe strategy
The fallback sends two requests: a normal GET and a SQLi-like probe path.
WAFs often reveal themselves only when blocking malicious requests. The
probe path (`/?id=1+AND+1=1+UNION+SELECT+NULL--`) triggers most WAF
blocking signatures without causing actual harm.

### testssl: Check ID escalation
Known high-severity check IDs (heartbleed, poodle, robot, rc4, sweet32, etc.)
are escalated to HIGH/CRITICAL regardless of testssl's own severity rating.
This ensures critical vulnerabilities are never buried by conservative ratings.

---

## Full ReconX Ecosystem Coverage (All Stages)

After Stage 12.3, ReconX covers:

| Domain | Tools |
|---|---|
| Passive OSINT | theHarvester, SpiderFoot, OSRFramework, Maltego, github-subdomains |
| DNS | dnsenum, dnsrecon, fierce, Sublist3r, massdns, shuffledns, puredns |
| Asset Discovery | assetfinder, findomain, chaos, asnmap, mapcidr, alterx |
| Historical URLs | gau, waybackurls, waymore, katana, hakrawler |
| Parameters | paramspider, arjun, gospider |
| Network Discovery | netdiscover, fping |
| Port Scanning | Nmap, masscan |
| Web Recon | dirb, feroxbuster, gobuster, nikto, WhatWeb |
| Visual Recon | EyeWitness, aquatone, gowitness |
| API Intelligence | kiterunner, graphw00f |
| Certificate Intel | crt.sh, tlsx |
| Fingerprinting | wafw00f, testssl.sh |
| Secrets | trufflehog, gitleaks |
| Cloud | s3scanner |
| Identity | sherlock, holehe, phoneinfoga |
| Frameworks | Metasploit Auxiliary |
| Utilities | netcat wrapper |

---

## Installation for Stage 12.3 Tools

```bash
# DNS Intelligence
git clone https://github.com/blechschmidt/massdns && cd massdns && make && sudo cp bin/massdns /usr/local/bin/
go install github.com/projectdiscovery/shuffledns/cmd/shuffledns@latest
go install github.com/d3mondev/puredns/v2@latest

# Screenshots
# aquatone: download binary from github.com/michenriksen/aquatone/releases
go install github.com/sensepost/gowitness@latest

# API Recon
go install github.com/assetnote/kiterunner/cmd/kr@latest
pip install graphw00f

# Secrets
curl -sSfL https://raw.githubusercontent.com/trufflesecurity/trufflehog/main/scripts/install.sh | sh
go install github.com/gitleaks/gitleaks/v8@latest

# Cloud
pip install s3scanner

# Certificates (crt.sh needs no install)
go install github.com/projectdiscovery/tlsx/cmd/tlsx@latest

# Fingerprinting
pip install wafw00f
git clone --depth 1 https://github.com/drwetter/testssl.sh.git && sudo ln -s $(pwd)/testssl.sh/testssl.sh /usr/local/bin/testssl.sh

# Identity
pip install sherlock-project holehe
go install github.com/sundowndev/phoneinfoga/v2/cmd/phoneinfoga@latest
```

All tools degrade gracefully: `[MISSING]`/`[SKIPPED]` status with
install instructions displayed. Python fallbacks activate automatically
for: graphw00f, s3scanner, tlsx, wafw00f, sherlock.
