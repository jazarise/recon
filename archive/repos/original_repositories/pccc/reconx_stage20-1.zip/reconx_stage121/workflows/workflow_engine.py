"""
ReconX — Stage 18: Workflow Engine.

Executes WorkflowTemplate steps against a target with:
  • Sequential and parallel step execution
  • Per-step status indicators: ✓ ⚡ ✗ ⏳
  • Live Rich progress panel
  • Tool isolation (one failure never stops the run)
  • DecisionEngine integration (mid-run recommendations)
  • WorkflowRecorder auto-save after each step
  • Pause / resume support
  • Learning context injection at step boundaries

Usage:
    from reconx.workflows.workflow_engine import WorkflowEngine18
    from reconx.workflows.workflow_templates import WorkflowTemplateLibrary

    engine = WorkflowEngine18(registry=registry)
    lib    = WorkflowTemplateLibrary()
    tmpl   = lib.get("bug_bounty")
    record = engine.execute(tmpl, "example.com")
"""
from __future__ import annotations

import logging
import time
import uuid
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Optional

from rich import box
from rich.console import Console
from rich.live import Live
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

log = logging.getLogger("reconx.workflows.engine18")


# ─────────────────────────────────────────────────────────────────────────────
# Status types
# ─────────────────────────────────────────────────────────────────────────────

class StepStatus18(str, Enum):
    WAITING   = "waiting"
    RUNNING   = "running"
    SUCCESS   = "success"
    FAILED    = "failed"
    SKIPPED   = "skipped"
    CANCELLED = "cancelled"


_STATUS_ICON = {
    StepStatus18.WAITING:   "[dim]⏳[/]",
    StepStatus18.RUNNING:   "[bold yellow]⚡[/]",
    StepStatus18.SUCCESS:   "[bold green]✓[/]",
    StepStatus18.FAILED:    "[bold red]✗[/]",
    StepStatus18.SKIPPED:   "[dim]○[/]",
    StepStatus18.CANCELLED: "[dim]—[/]",
}

_STATUS_STYLE = {
    StepStatus18.WAITING:   "dim",
    StepStatus18.RUNNING:   "bold yellow",
    StepStatus18.SUCCESS:   "bold green",
    StepStatus18.FAILED:    "bold red",
    StepStatus18.SKIPPED:   "dim",
    StepStatus18.CANCELLED: "dim",
}


# ─────────────────────────────────────────────────────────────────────────────
# Execution record models
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class StepRecord:
    """Runtime record of one executed step."""
    tool:        str
    tool_class:  str
    stage:       int
    status:      StepStatus18    = StepStatus18.WAITING
    started_at:  float           = 0.0
    finished_at: float           = 0.0
    finding_count: int           = 0
    error:       str             = ""
    output_summary: str          = ""

    @property
    def duration_s(self) -> float:
        if self.started_at and self.finished_at:
            return self.finished_at - self.started_at
        return 0.0

    def icon(self) -> str:
        return _STATUS_ICON.get(self.status, "?")

    def style(self) -> str:
        return _STATUS_STYLE.get(self.status, "white")

    def to_dict(self) -> dict:
        return {
            "tool":           self.tool,
            "tool_class":     self.tool_class,
            "stage":          self.stage,
            "status":         self.status.value,
            "started_at":     self.started_at,
            "finished_at":    self.finished_at,
            "duration_s":     self.duration_s,
            "finding_count":  self.finding_count,
            "error":          self.error,
            "output_summary": self.output_summary,
        }


@dataclass
class WorkflowRunRecord:
    """Complete execution record for one workflow run."""
    run_id:        str
    template_name: str
    target:        str
    started_at:    float              = field(default_factory=time.time)
    finished_at:   float              = 0.0
    steps:         list[StepRecord]   = field(default_factory=list)
    recommendations: list[dict]       = field(default_factory=list)
    total_findings: int               = 0
    status:        str                = "running"   # running | completed | failed | interrupted
    recon_result:  Optional[Any]      = field(default=None, repr=False)

    @property
    def duration_s(self) -> float:
        end = self.finished_at or time.time()
        return end - self.started_at

    @property
    def success_count(self) -> int:
        return sum(1 for s in self.steps if s.status == StepStatus18.SUCCESS)

    @property
    def failed_count(self) -> int:
        return sum(1 for s in self.steps if s.status == StepStatus18.FAILED)

    def to_dict(self) -> dict:
        return {
            "run_id":          self.run_id,
            "template_name":   self.template_name,
            "target":          self.target,
            "started_at":      self.started_at,
            "finished_at":     self.finished_at,
            "duration_s":      self.duration_s,
            "status":          self.status,
            "total_findings":  self.total_findings,
            "success_count":   self.success_count,
            "failed_count":    self.failed_count,
            "steps":           [s.to_dict() for s in self.steps],
            "recommendations": self.recommendations,
        }


# ─────────────────────────────────────────────────────────────────────────────
# WorkflowEngine18
# ─────────────────────────────────────────────────────────────────────────────

class WorkflowEngine18:
    """
    Executes Stage 18 WorkflowTemplates against a target.

    Responsibilities:
      - Build execution plan (sequential + parallel groups)
      - Display a live Rich status table during execution
      - Integrate with ToolRegistry for actual tool invocation
      - Run DecisionEngine after each stage for mid-run recommendations
      - Call step callbacks for recorder auto-save
      - Never allow one step failure to halt the run
    """

    def __init__(
        self,
        registry:      Any                   = None,
        console:       Optional[Console]     = None,
        max_workers:   int                   = 6,
        on_step_done:  Optional[Callable]    = None,
        on_recommend:  Optional[Callable]    = None,
        silent:        bool                  = False,
    ):
        self._registry    = registry
        self.console      = console or Console()
        self._max_workers = max_workers
        self.on_step_done = on_step_done
        self.on_recommend = on_recommend
        self.silent       = silent
        self._paused      = False

    # ── Public API ────────────────────────────────────────────────────────────

    def execute(
        self,
        template,          # WorkflowTemplate
        target: str,
        run_id: Optional[str] = None,
        recon_result: Any     = None,
    ) -> WorkflowRunRecord:
        """
        Execute a WorkflowTemplate against target.

        Returns a WorkflowRunRecord.  Never raises.
        """
        rid    = run_id or f"run_{int(time.time())}_{uuid.uuid4().hex[:6]}"
        record = WorkflowRunRecord(
            run_id        = rid,
            template_name = template.name,
            target        = target,
            steps         = [
                StepRecord(
                    tool       = step.tool,
                    tool_class = step.tool_class,
                    stage      = step.stage,
                )
                for step in template.steps
            ],
        )

        if not self.silent:
            self.console.print()
            self.console.print(Panel(
                f"[bold cyan]{template.display_name}[/]  →  "
                f"[bold white]{target}[/]\n"
                f"[dim]{template.description[:90]}[/]",
                border_style="cyan",
                padding=(0, 2),
            ))
            self.console.print()

        try:
            self._run(template, target, record, recon_result)
        except Exception as exc:
            log.exception(f"WorkflowEngine18 unhandled error: {exc}")
            record.status = "failed"

        record.finished_at = time.time()
        if record.status == "running":
            record.status = "completed"

        if not self.silent:
            self._print_summary(record)

        return record

    def pause(self) -> None:
        self._paused = True

    def resume(self) -> None:
        self._paused = False

    # ── Execution ─────────────────────────────────────────────────────────────

    def _run(
        self,
        template,
        target:  str,
        record:  WorkflowRunRecord,
        recon_result: Any,
    ) -> None:
        """Main run loop: group steps by stage+parallel, execute, collect recs."""
        # Group steps: (stage, parallel_group|None) → [step_indices]
        from collections import defaultdict, OrderedDict
        batches: OrderedDict[tuple, list[int]] = OrderedDict()

        for idx, step in enumerate(template.steps):
            key = (step.stage, step.parallel_group)
            batches.setdefault(key, []).append(idx)

        decision_eng = self._get_decision_engine()
        current_stage = -1

        # Build live table
        with Live(
            self._build_status_table(record, template.display_name),
            console    = self.console,
            refresh_per_second = 4,
            transient  = False,
        ) as live:

            for (stage, group), indices in batches.items():
                # Honour pause between batches
                while self._paused:
                    time.sleep(0.2)

                if stage != current_stage:
                    current_stage = stage

                if len(indices) == 1:
                    idx = indices[0]
                    self._run_step(idx, template.steps[idx], target,
                                   record, live, template.display_name)
                else:
                    self._run_parallel(indices, template.steps, target,
                                       record, live, template.display_name)

                # Mid-run DecisionEngine call after each stage
                if decision_eng and recon_result:
                    try:
                        recs = decision_eng.recommend(recon_result)
                        for dr in recs[:3]:
                            record.recommendations.append(dr.to_dict())
                        if recs and self.on_recommend:
                            self.on_recommend(recs, record)
                    except Exception as exc:
                        log.debug(f"Decision engine recommendation failed: {exc}")

                live.update(self._build_status_table(record, template.display_name))

    def _run_step(
        self,
        idx:      int,
        step,              # TemplateStep
        target:   str,
        record:   WorkflowRunRecord,
        live:     Live,
        title:    str,
    ) -> None:
        sr = record.steps[idx]
        sr.status     = StepStatus18.RUNNING
        sr.started_at = time.time()
        live.update(self._build_status_table(record, title))

        try:
            result = self._invoke(step.tool_class, target)
            sr.status        = StepStatus18.SUCCESS
            sr.finding_count = self._count(result)
            sr.output_summary = self._summarise(result)
            if record.recon_result is None and result:
                record.recon_result = result
        except Exception as exc:
            sr.status = StepStatus18.FAILED
            sr.error  = str(exc)[:120]
            log.warning(f"Step '{step.tool}' failed: {exc}")

        sr.finished_at = time.time()

        if self.on_step_done:
            try:
                self.on_step_done(sr, record)
            except Exception:
                pass

        live.update(self._build_status_table(record, title))

    def _run_parallel(
        self,
        indices:  list[int],
        steps:    list,
        target:   str,
        record:   WorkflowRunRecord,
        live:     Live,
        title:    str,
    ) -> None:
        for idx in indices:
            record.steps[idx].status     = StepStatus18.RUNNING
            record.steps[idx].started_at = time.time()
        live.update(self._build_status_table(record, title))

        workers = min(self._max_workers, len(indices))
        with ThreadPoolExecutor(max_workers=workers) as pool:
            futures = {
                pool.submit(
                    self._invoke_safe, steps[idx].tool_class, target
                ): idx
                for idx in indices
            }
            for fut in as_completed(futures):
                idx = futures[fut]
                sr  = record.steps[idx]
                try:
                    result, error = fut.result()
                    if error:
                        sr.status = StepStatus18.FAILED
                        sr.error  = error[:120]
                    else:
                        sr.status        = StepStatus18.SUCCESS
                        sr.finding_count = self._count(result)
                        sr.output_summary = self._summarise(result)
                except Exception as exc:
                    sr.status = StepStatus18.FAILED
                    sr.error  = str(exc)[:80]

                sr.finished_at = time.time()
                if self.on_step_done:
                    try:
                        self.on_step_done(sr, record)
                    except Exception:
                        pass
                live.update(self._build_status_table(record, title))

    # ── Tool invocation ───────────────────────────────────────────────────────

    def _invoke(self, tool_class: str, target: str) -> Any:
        if not self._registry:
            raise RuntimeError("No ToolRegistry — running in dry-run mode.")
        desc = self._registry.get(tool_class)
        if not desc:
            raise RuntimeError(f"Tool '{tool_class}' not in registry.")
        if not desc.available():
            raise RuntimeError(f"Tool binary '{desc.binary}' not installed.")
        instance = desc.cls() if desc.cls else None
        if instance is None:
            raise RuntimeError(f"Tool class for '{tool_class}' could not be instantiated.")
        return instance.run(target)

    def _invoke_safe(self, tool_class: str, target: str) -> tuple[Any, str]:
        try:
            return self._invoke(tool_class, target), ""
        except Exception as exc:
            return None, str(exc)

    # ── UI ────────────────────────────────────────────────────────────────────

    def _build_status_table(
        self, record: WorkflowRunRecord, title: str
    ) -> Panel:
        table = Table(
            box       = box.SIMPLE,
            show_header = True,
            border_style = "dim",
            padding   = (0, 1),
            expand    = True,
        )
        table.add_column("",        width=3, no_wrap=True)
        table.add_column("Tool",    style="bold white", width=22, no_wrap=True)
        table.add_column("Stage",   style="dim cyan",   width=7,  no_wrap=True)
        table.add_column("Status",  width=12, no_wrap=True)
        table.add_column("Time",    style="dim",        width=7,  no_wrap=True)
        table.add_column("Finds",   style="dim yellow", width=6,  no_wrap=True)

        for sr in record.steps:
            icon     = _STATUS_ICON.get(sr.status, "?")
            sty      = _STATUS_STYLE.get(sr.status, "white")
            dur      = f"{sr.duration_s:.1f}s" if sr.duration_s > 0 else "—"
            finds    = str(sr.finding_count) if sr.finding_count else "—"
            status_t = Text(sr.status.value.upper(), style=sty)
            table.add_row(icon, sr.tool, f"S{sr.stage}", status_t, dur, finds)

        # Footer counters
        done  = record.success_count
        fail  = record.failed_count
        total = len(record.steps)
        wait  = sum(1 for s in record.steps if s.status == StepStatus18.WAITING)
        run   = sum(1 for s in record.steps if s.status == StepStatus18.RUNNING)

        footer = (
            f"[green]{done} done[/]  "
            f"[yellow]{run} running[/]  "
            f"[dim]{wait} waiting[/]  "
            + (f"[red]{fail} failed[/]  " if fail else "")
            + f"[dim]{record.duration_s:.0f}s elapsed[/]"
        )

        return Panel(
            table,
            title   = f"[bold cyan]{title}[/]  →  [white]{record.target}[/]",
            subtitle = footer,
            border_style = "cyan",
            padding  = (0, 1),
        )

    def _print_summary(self, record: WorkflowRunRecord) -> None:
        status_style = "green" if record.status == "completed" else "red"
        self.console.print(Panel(
            f"[bold {status_style}]{record.status.upper()}[/]  "
            f"{record.duration_s:.1f}s\n\n"
            f"[green]✓ {record.success_count}[/] succeeded  "
            f"[red]✗ {record.failed_count}[/] failed  "
            f"[dim]{len(record.steps)} total steps[/]\n"
            f"Findings: [bold cyan]{record.total_findings}[/]",
            title  = f"[bold]{record.template_name}[/] Complete",
            border_style = status_style,
        ))

        if record.recommendations:
            self.console.print("\n[bold cyan]Recommendations:[/]")
            for rec in record.recommendations[:5]:
                sev   = rec.get("severity", "INFO")
                label = rec.get("label", "?")
                sug   = rec.get("suggestions", [{}])[0].get("tool", "")
                sev_style = {"CRITICAL": "bold red", "HIGH": "orange3",
                             "MEDIUM": "yellow"}.get(sev, "dim")
                self.console.print(
                    f"  [{sev_style}][{sev}][/]  {label}"
                    + (f"  [dim]→ try {sug}[/]" if sug else "")
                )

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _get_decision_engine(self):
        try:
            from .decision_engine import DecisionEngine
            return DecisionEngine()
        except Exception:
            return None

    @staticmethod
    def _count(result: Any) -> int:
        if not result:
            return 0
        if hasattr(result, "findings"):
            return len(result.findings)
        if isinstance(result, list):
            return len(result)
        return 0

    @staticmethod
    def _summarise(result: Any) -> str:
        if not result:
            return ""
        if hasattr(result, "summary"):
            return str(result.summary)[:80]
        return ""
