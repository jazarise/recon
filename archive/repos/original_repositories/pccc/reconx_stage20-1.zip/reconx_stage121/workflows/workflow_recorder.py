"""
ReconX — Stage 18: Workflow Recorder.

Persists WorkflowRunRecords to disk as JSON after each step and on
completion.  Provides session listing, deletion, and export.

Storage layout:
    reconx/data/workflows/
        workflow_<run_id>.json        ← individual run record
        workflow_<run_id>.partial.json ← in-progress checkpoint

Usage:
    from reconx.workflows.workflow_recorder import WorkflowRecorder18

    recorder = WorkflowRecorder18()
    callback = recorder.make_step_callback()

    engine = WorkflowEngine18(on_step_done=callback)
    record = engine.execute(template, target)
    path   = recorder.save(record)

    # CLI equivalents
    reconx workflow list
    reconx workflow replay workflow_20260101_abc123
    reconx workflow export workflow_20260101_abc123 --format json
"""
from __future__ import annotations

import json
import logging
import time
from datetime import datetime
from pathlib import Path
from typing import Optional

from .workflow_engine import WorkflowRunRecord

log = logging.getLogger("reconx.workflows.recorder18")

_DEFAULT_DIR = Path("reconx/data/workflows")


class WorkflowRecorder18:
    """
    Saves and manages workflow run records.

    Features:
      - Auto-save after every step (partial checkpoint)
      - Atomic save on completion (rename from .partial)
      - Listing with metadata (sorted newest first)
      - Export to JSON
      - Delete by run_id
    """

    def __init__(self, storage_dir: Optional[str] = None):
        self.dir = Path(storage_dir) if storage_dir else _DEFAULT_DIR
        self.dir.mkdir(parents=True, exist_ok=True)

    # ── Save / checkpoint ─────────────────────────────────────────────────────

    def save(self, record: WorkflowRunRecord) -> str:
        """Persist a completed record.  Returns the file path."""
        path = self._path(record.run_id)
        tmp  = path.with_suffix(".tmp")
        try:
            data = record.to_dict()
            data["_saved_at"]  = time.time()
            data["_reconx_v"]  = "18.0"
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump(data, fh, indent=2, default=str)
            tmp.rename(path)
            # Remove partial file if present
            partial = self._partial_path(record.run_id)
            if partial.exists():
                partial.unlink(missing_ok=True)
            log.info(f"Workflow saved: {path}")
        except Exception as exc:
            log.error(f"Failed to save workflow {record.run_id}: {exc}")
            raise
        return str(path)

    def checkpoint(self, record: WorkflowRunRecord) -> None:
        """Write a partial checkpoint (non-atomic, best-effort)."""
        path = self._partial_path(record.run_id)
        try:
            data = record.to_dict()
            data["_checkpoint_at"] = time.time()
            with open(path, "w", encoding="utf-8") as fh:
                json.dump(data, fh, indent=2, default=str)
        except Exception as exc:
            log.debug(f"Checkpoint write failed: {exc}")

    def make_step_callback(self, autosave: bool = True):
        """
        Return an on_step_done callback for WorkflowEngine18.

        When autosave=True every completed step triggers a checkpoint write,
        so progress survives crashes.
        """
        recorder = self

        def _cb(step_record, run_record: WorkflowRunRecord) -> None:
            if autosave:
                try:
                    recorder.checkpoint(run_record)
                except Exception:
                    pass

        return _cb

    # ── Load ──────────────────────────────────────────────────────────────────

    def load(self, run_id: str) -> Optional[WorkflowRunRecord]:
        """Load a saved record by run_id.  Returns None if not found."""
        for path in [self._path(run_id), self._partial_path(run_id)]:
            if path.exists():
                try:
                    with open(path, encoding="utf-8") as fh:
                        return self._deserialise(json.load(fh))
                except Exception as exc:
                    log.warning(f"Failed to load {path}: {exc}")
        return None

    # ── List ──────────────────────────────────────────────────────────────────

    def list_runs(self, limit: int = 50) -> list[dict]:
        """
        Return metadata for all saved runs, newest first.

        Each entry: run_id, template_name, target, status,
                    duration_s, step_count, saved_at, path.
        """
        entries = []
        for p in sorted(
            list(self.dir.glob("workflow_*.json")),
            key=lambda x: x.stat().st_mtime,
            reverse=True,
        )[:limit]:
            try:
                with open(p, encoding="utf-8") as fh:
                    d = json.load(fh)
                entries.append({
                    "run_id":        d.get("run_id", p.stem),
                    "template_name": d.get("template_name", "?"),
                    "target":        d.get("target", "?"),
                    "status":        d.get("status", "?"),
                    "duration_s":    d.get("duration_s", 0),
                    "step_count":    len(d.get("steps", [])),
                    "success":       d.get("success_count", 0),
                    "failed":        d.get("failed_count", 0),
                    "saved_at":      d.get("_saved_at", 0),
                    "path":          str(p),
                })
            except Exception:
                pass
        return entries

    def delete(self, run_id: str) -> bool:
        """Delete a saved run.  Returns True if deleted."""
        path = self._path(run_id)
        if path.exists():
            path.unlink()
            log.info(f"Deleted workflow: {run_id}")
            return True
        return False

    # ── Export ────────────────────────────────────────────────────────────────

    def export_json(self, run_id: str, out_path: Optional[str] = None) -> str:
        """Export a run to a human-readable JSON file.  Returns export path."""
        record = self.load(run_id)
        if not record:
            raise FileNotFoundError(f"Run not found: {run_id}")
        out = Path(out_path) if out_path else Path(f"workflow_export_{run_id}.json")
        with open(out, "w", encoding="utf-8") as fh:
            json.dump(record.to_dict(), fh, indent=2, default=str)
        log.info(f"Exported workflow to: {out}")
        return str(out)

    def export_markdown(self, run_id: str, out_path: Optional[str] = None) -> str:
        """Export a run as a human-readable Markdown report."""
        record = self.load(run_id)
        if not record:
            raise FileNotFoundError(f"Run not found: {run_id}")

        lines = [
            f"# ReconX Workflow Report",
            f"",
            f"**Workflow:** {record.template_name}  ",
            f"**Target:** `{record.target}`  ",
            f"**Status:** {record.status.upper()}  ",
            f"**Duration:** {record.duration_s:.1f}s  ",
            f"**Run ID:** `{record.run_id}`  ",
            f"",
            f"## Execution Timeline",
            f"",
            f"| # | Tool | Stage | Status | Duration | Findings |",
            f"|---|------|-------|--------|----------|----------|",
        ]
        for i, s in enumerate(record.steps, 1):
            # Support both StepRecord objects and plain dicts
            if hasattr(s, "status"):
                s_dict = s.to_dict()
            else:
                s_dict = s
            icon = {"success": "✓", "failed": "✗", "skipped": "○",
                    "waiting": "⏳", "running": "⚡"}.get(s_dict["status"], "?")
            lines.append(
                f"| {i} | {s_dict['tool']} | S{s_dict['stage']} | "
                f"{icon} {s_dict['status']} | {s_dict['duration_s']:.1f}s | "
                f"{s_dict['finding_count']} |"
            )

        if record.recommendations:
            lines += ["", "## Recommendations", ""]
            for rec in record.recommendations[:8]:
                lines.append(f"### {rec.get('label', '?')}  [{rec.get('severity','')}]")
                lines.append(f"{rec.get('context', '')}")
                for s in rec.get("suggestions", [])[:3]:
                    lines.append(f"- **{s['tool']}** — {s['reason']}")
                    for cmd in s.get("commands", [])[:1]:
                        lines.append(f"  ```\n  {cmd}\n  ```")
                lines.append("")

        out = Path(out_path) if out_path else Path(f"workflow_report_{run_id}.md")
        out.write_text("\n".join(lines), encoding="utf-8")
        return str(out)

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _path(self, run_id: str) -> Path:
        safe = run_id.replace("/", "_").replace("\\", "_")
        return self.dir / f"workflow_{safe}.json"

    def _partial_path(self, run_id: str) -> Path:
        safe = run_id.replace("/", "_").replace("\\", "_")
        return self.dir / f"workflow_{safe}.partial.json"

    @staticmethod
    def _deserialise(d: dict) -> WorkflowRunRecord:
        from .workflow_engine import StepRecord, StepStatus18
        record = WorkflowRunRecord(
            run_id        = d.get("run_id", ""),
            template_name = d.get("template_name", ""),
            target        = d.get("target", ""),
            started_at    = d.get("started_at", 0.0),
            finished_at   = d.get("finished_at", 0.0),
            status        = d.get("status", "completed"),
            total_findings = d.get("total_findings", 0),
        )
        for sd in d.get("steps", []):
            sr = StepRecord(
                tool       = sd.get("tool", ""),
                tool_class = sd.get("tool_class", ""),
                stage      = sd.get("stage", 1),
            )
            sr.status        = StepStatus18(sd.get("status", "waiting"))
            sr.started_at    = sd.get("started_at", 0.0)
            sr.finished_at   = sd.get("finished_at", 0.0)
            sr.finding_count = sd.get("finding_count", 0)
            sr.error         = sd.get("error", "")
            record.steps.append(sr)
        record.recommendations = d.get("recommendations", [])
        return record
