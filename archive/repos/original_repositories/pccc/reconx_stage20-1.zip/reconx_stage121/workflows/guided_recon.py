"""
ReconX — Stage 18: Guided Recon Assistant.

Interactive analyst assistant that walks operators through:

  Step 1 → Enter target
  Step 2 → Select target type  (Domain / Web App / Internal / API / Cloud)
  Step 3 → Choose objective    (10 curated goals)
  Step 4 → Review recommended tools + chain explanation
  Step 5 → [Run Now] | [Learn Chain] | [Customise] | [Back]
  Step 6 → (optional) Learn First — explains each tool in the chain
  Step 7 → Execute with live status panel
  Step 8 → Show DecisionEngine recommendations on findings

Integrates with:
  WorkflowTemplateLibrary  — selects the best template for the objective
  WorkflowEngine18         — executes the workflow
  WorkflowRecorder18       — saves the session
  DecisionEngine           — post-execution recommendations

Usage:
    from reconx.workflows.guided_recon import GuidedRecon18
    GuidedRecon18().run()
"""
from __future__ import annotations

import logging
import time
from typing import Optional

from rich import box
from rich.console import Console
from rich.panel import Panel
from rich.prompt import IntPrompt, Prompt
from rich.rule import Rule
from rich.table import Table
from rich.text import Text

from .workflow_engine import WorkflowEngine18
from .workflow_recorder import WorkflowRecorder18
from .workflow_templates import WorkflowTemplateLibrary

log = logging.getLogger("reconx.workflows.guided18")


# ─────────────────────────────────────────────────────────────────────────────
# Target types and objectives catalogue
# ─────────────────────────────────────────────────────────────────────────────

TARGET_TYPES = [
    {"id": "domain",   "label": "Domain / Organisation",    "icon": "🌐",
     "hint": "e.g. example.com — discover all assets"},
    {"id": "web",      "label": "Web Application",          "icon": "🕸️",
     "hint": "e.g. https://app.example.com — test the web surface"},
    {"id": "internal", "label": "Internal Network",         "icon": "🏢",
     "hint": "e.g. 192.168.1.0/24 — LAN reconnaissance"},
    {"id": "api",      "label": "API / Microservice",       "icon": "⚙️",
     "hint": "e.g. https://api.example.com — REST/GraphQL surface"},
    {"id": "cloud",    "label": "Cloud Infrastructure",     "icon": "☁️",
     "hint": "e.g. example.com — S3, Azure, GCP asset mapping"},
]

OBJECTIVES = {
    "domain": [
        {"id": "full_recon",       "label": "Full External Recon",        "icon": "🗺️",  "template": "external_infra"},
        {"id": "subdomains",       "label": "Find All Subdomains",        "icon": "🌐",  "template": "bug_bounty"},
        {"id": "bug_bounty",       "label": "Bug Bounty Recon",           "icon": "🐛",  "template": "bug_bounty"},
        {"id": "fast_triage",      "label": "Quick 5-Minute Triage",      "icon": "⚡",  "template": "fast_triage"},
        {"id": "deep_investigation","label":"Deep Investigation",          "icon": "🔍", "template": "deep_investigation"},
    ],
    "web": [
        {"id": "web_recon",        "label": "Web App Assessment",         "icon": "🕸️",  "template": "web_application"},
        {"id": "find_endpoints",   "label": "Discover Hidden Endpoints",  "icon": "🔍",  "template": "web_application"},
        {"id": "find_secrets",     "label": "Find Hardcoded Secrets",     "icon": "🔑",  "template": "web_application"},
        {"id": "fast_triage",      "label": "Quick HTTP Triage",          "icon": "⚡",  "template": "fast_triage"},
    ],
    "internal": [
        {"id": "lan_discovery",    "label": "Internal Network Map",       "icon": "🏢",  "template": "internal_network"},
        {"id": "service_enum",     "label": "Service Enumeration",        "icon": "🔌",  "template": "internal_network"},
        {"id": "fast_triage",      "label": "Quick Host Discovery",       "icon": "⚡",  "template": "fast_triage"},
    ],
    "api": [
        {"id": "api_recon",        "label": "API Surface Discovery",      "icon": "⚙️",  "template": "api_assessment"},
        {"id": "graphql",          "label": "GraphQL Enumeration",        "icon": "🔷",  "template": "api_assessment"},
        {"id": "find_endpoints",   "label": "Hidden Endpoint Discovery",  "icon": "🔍",  "template": "api_assessment"},
    ],
    "cloud": [
        {"id": "cloud_recon",      "label": "Cloud Asset Mapping",        "icon": "☁️",  "template": "cloud_assessment"},
        {"id": "buckets",          "label": "S3 / Bucket Exposure",       "icon": "🪣",  "template": "cloud_assessment"},
        {"id": "fast_triage",      "label": "Quick Cloud Triage",         "icon": "⚡",  "template": "fast_triage"},
    ],
}

# Per-tool learning blurbs shown in "Learn Chain" mode
_TOOL_LEARN: dict[str, dict] = {
    "WHOIS":        {"desc": "Queries domain registration, registrar, ASN, and org details.",
                     "why":  "First step — establishes who owns what before touching anything.",
                     "out":  "Registrar, creation date, nameservers, ASN, org name."},
    "Subfinder":    {"desc": "Passive subdomain discovery from CT logs, APIs, and aggregators.",
                     "why":  "Finds subdomains without sending traffic to the target.",
                     "out":  "Subdomain list (hundreds to thousands)."},
    "Amass":        {"desc": "Active + passive subdomain enumeration with graph intelligence.",
                     "why":  "Highest coverage of any single subdomain tool.",
                     "out":  "Subdomain list with source attribution."},
    "HTTPX":        {"desc": "Probes a list of hostnames for live HTTP/HTTPS services.",
                     "why":  "Filters dead subdomains — only work on live targets.",
                     "out":  "Live URLs, status codes, titles, technologies, CDN headers."},
    "Nmap":         {"desc": "Port scanner with service and version detection.",
                     "why":  "The ground truth for what's running where.",
                     "out":  "Open ports, service names, version strings, OS guess."},
    "Masscan":      {"desc": "Fastest TCP port scanner — millions of packets per second.",
                     "why":  "Sweeps large IP ranges quickly before Nmap deep-dives.",
                     "out":  "Open port list (no service info)."},
    "Nuclei":       {"desc": "Template-based vulnerability scanner with 10,000+ templates.",
                     "why":  "Automated CVE, misconfig, and exposure checking at scale.",
                     "out":  "Matched vulnerability findings with severity ratings."},
    "GoSpider":     {"desc": "Fast web crawler that recursively follows all links.",
                     "why":  "Feeds endpoint lists to fuzzing, secret scanning, and param discovery.",
                     "out":  "URL list, JavaScript file paths, form actions."},
    "Katana":       {"desc": "JavaScript-aware crawler that executes JS to find SPA routes.",
                     "why":  "Modern SPAs hide routes in JS — GoSpider alone misses them.",
                     "out":  "Endpoint list including JavaScript-rendered routes."},
    "SecretFinder": {"desc": "Scans JavaScript files for API keys and secrets using regex.",
                     "why":  "Hardcoded secrets in JS are a top bug bounty finding.",
                     "out":  "API keys, tokens, credentials found in JS source."},
    "FeroxBuster":  {"desc": "Recursive directory and file brute-force tool.",
                     "why":  "Finds hidden admin panels, backup files, and config endpoints.",
                     "out":  "Hidden paths and files (200/403 responses)."},
    "GoWitness":    {"desc": "Headless Chromium-based screenshot tool.",
                     "why":  "Visual triage of hundreds of subdomains in seconds.",
                     "out":  "PNG screenshots for every live host."},
    "WhatWeb":      {"desc": "HTTP technology fingerprinting (CMS, framework, server).",
                     "why":  "Identifies the tech stack so you know which attacks apply.",
                     "out":  "CMS type, server software, frameworks, plugins."},
    "WafW00f":      {"desc": "WAF fingerprinting tool.",
                     "why":  "Knowing the WAF type prevents wasting time on blocked payloads.",
                     "out":  "WAF vendor (Cloudflare, Akamai, Imperva, etc.)."},
    "theHarvester": {"desc": "OSINT tool for emails, hostnames, and names from public sources.",
                     "why":  "Social engineering preparation; email list for phishing simulation.",
                     "out":  "Email addresses, employee names, subdomains from Google/LinkedIn."},
    "Kiterunner":   {"desc": "API route brute-force using real-world API wordlists.",
                     "why":  "Generic wordlists miss API routes — Kiterunner uses production routes.",
                     "out":  "Valid API endpoints not found by crawling."},
    "Arjun":        {"desc": "HTTP parameter discovery tool.",
                     "why":  "Undocumented parameters are a top source of injection vulnerabilities.",
                     "out":  "Hidden GET/POST parameter names."},
    "S3Scanner":    {"desc": "Discovers and tests access to S3-compatible cloud storage buckets.",
                     "why":  "Public buckets are a constant source of data breaches.",
                     "out":  "Bucket names, public/private status, readable files."},
    "netdiscover":  {"desc": "ARP-based network host discovery tool.",
                     "why":  "ARP is more reliable than ICMP on LAN — finds hosts that block ping.",
                     "out":  "Live host IPs and MAC addresses."},
    "enum4linux-ng":{"desc": "SMB/NetBIOS enumeration: shares, users, groups, policies.",
                     "why":  "Essential for any Windows/AD environment assessment.",
                     "out":  "Share list, user accounts, password policy, OS info."},
}


# ─────────────────────────────────────────────────────────────────────────────
# GuidedRecon18
# ─────────────────────────────────────────────────────────────────────────────

class GuidedRecon18:
    """
    Interactive guided reconnaissance assistant for Stage 18.

    Manages the full 8-step flow from target entry to post-execution
    recommendations.
    """

    def __init__(
        self,
        console:  Optional[Console]             = None,
        engine:   Optional[WorkflowEngine18]    = None,
        recorder: Optional[WorkflowRecorder18]  = None,
        registry: Optional[object]              = None,
    ):
        self.console  = console  or Console()
        self._engine  = engine   or WorkflowEngine18(registry=registry)
        self._rec     = recorder or WorkflowRecorder18()
        self._lib     = WorkflowTemplateLibrary()

    # ── Entry point ───────────────────────────────────────────────────────────

    def run(self) -> None:
        """Launch the full guided recon flow."""
        self._header()

        target = self._step_target()
        if not target:
            return

        ttype = self._step_target_type()
        if not ttype:
            return

        objective = self._step_objective(ttype["id"])
        if not objective:
            return

        template = self._lib.get(objective["template"])
        if not template:
            self.console.print(
                f"[red]Template '{objective['template']}' not found.[/]"
            )
            return

        self._step_preview(template, objective, target)
        action = self._step_action()

        if action == "back":
            self.run()
            return

        if action == "learn":
            self._step_learn_chain(template)
            if not self._confirm_run():
                return

        if action == "customise":
            template = self._step_customise(template)

        if action in ("run", "learn", "customise"):
            self._execute(template, target)

    # ── Step 1: Target ────────────────────────────────────────────────────────

    def _step_target(self) -> Optional[str]:
        self.console.print(Rule("[bold cyan]Step 1 — Target[/]", style="cyan"))
        self.console.print(
            "[dim]Enter a domain, IP, CIDR, or URL.\n"
            "Examples:  example.com · 10.0.0.0/24 · https://app.example.com[/]\n"
        )
        try:
            t = Prompt.ask("[bold cyan]Target[/]").strip()
        except (KeyboardInterrupt, EOFError):
            return None
        if not t:
            self.console.print("[red]No target entered.[/]")
            return None
        return t

    # ── Step 2: Target type ───────────────────────────────────────────────────

    def _step_target_type(self) -> Optional[dict]:
        self.console.print()
        self.console.print(Rule("[bold cyan]Step 2 — Target Type[/]", style="cyan"))

        table = Table(box=box.SIMPLE, show_header=False, border_style="dim cyan")
        table.add_column("#",     style="cyan dim", width=4)
        table.add_column("Type",  style="bold white", width=26)
        table.add_column("Hint",  style="dim")
        for i, t in enumerate(TARGET_TYPES, 1):
            table.add_row(str(i), f"{t['icon']}  {t['label']}", t["hint"])
        self.console.print(table)
        self.console.print()

        try:
            n = IntPrompt.ask("[bold cyan]Select[/]", default=1)
            if 1 <= n <= len(TARGET_TYPES):
                return TARGET_TYPES[n - 1]
        except (KeyboardInterrupt, EOFError):
            pass
        return None

    # ── Step 3: Objective ─────────────────────────────────────────────────────

    def _step_objective(self, target_type_id: str) -> Optional[dict]:
        self.console.print()
        self.console.print(Rule("[bold cyan]Step 3 — Objective[/]", style="cyan"))

        objectives = OBJECTIVES.get(target_type_id, OBJECTIVES["domain"])
        table = Table(box=box.SIMPLE, show_header=False, border_style="dim cyan")
        table.add_column("#",     style="cyan dim", width=4)
        table.add_column("Goal",  style="bold white")
        for i, o in enumerate(objectives, 1):
            table.add_row(str(i), f"{o['icon']}  {o['label']}")
        self.console.print(table)
        self.console.print()

        try:
            n = IntPrompt.ask("[bold cyan]Select[/]", default=1)
            if 1 <= n <= len(objectives):
                return objectives[n - 1]
        except (KeyboardInterrupt, EOFError):
            pass
        return None

    # ── Step 4: Preview ───────────────────────────────────────────────────────

    def _step_preview(self, template, objective: dict, target: str) -> None:
        self.console.print()
        self.console.print(Rule("[bold cyan]Step 4 — Recommended Workflow[/]", style="cyan"))

        self.console.print(Panel(
            f"[bold white]{objective['icon']}  {objective['label']}[/]\n\n"
            f"[dim]{template.description[:120]}[/]\n\n"
            f"[dim]Estimated time:[/] [bold]{template.estimated_min}m[/]  "
            f"[dim]Steps:[/] [bold]{template.step_count}[/]  "
            f"[dim]Category:[/] {template.category}",
            title=f"[bold cyan]{template.display_name}[/]",
            border_style="cyan",
        ))

        # Tool chain visual
        self.console.print()
        self.console.print("[bold dim]Tool Chain:[/]")
        for i, step in enumerate(template.steps):
            icon = "┌" if i == 0 else ("└" if i == len(template.steps) - 1 else "├")
            why  = f"  [dim]→ {step.why_next[:60]}[/]" if step.why_next else ""
            par  = (f" [dim cyan][parallel: {step.parallel_group}][/]"
                    if step.parallel_group else "")
            self.console.print(
                f"  {icon}─ [bold white]{step.tool}[/]{par}{why}"
            )

    # ── Step 5: Action ────────────────────────────────────────────────────────

    def _step_action(self) -> str:
        self.console.print()
        table = Table(box=box.SIMPLE, show_header=False, border_style="dim")
        table.add_row("[bold cyan][1][/]", "[bold]Run Now[/]",      "Execute the workflow immediately")
        table.add_row("[bold yellow][2][/]","[bold]Learn Chain[/]", "Understand each tool before running")
        table.add_row("[bold green][3][/]", "[bold]Customise[/]",   "Add or remove tools from the workflow")
        table.add_row("[bold dim][4][/]",   "[dim]Back[/]",         "Return to objective selection")
        self.console.print(table)
        self.console.print()

        try:
            raw = Prompt.ask("[bold cyan]Choice[/]", default="1").strip()
        except (KeyboardInterrupt, EOFError):
            return "back"
        return {"1": "run", "2": "learn", "3": "customise", "4": "back"}.get(raw, "run")

    # ── Step 6: Learn chain ───────────────────────────────────────────────────

    def _step_learn_chain(self, template) -> None:
        self.console.print()
        self.console.print(Rule("[bold yellow]Learn Chain[/]", style="yellow"))
        self.console.print(
            f"[dim]{template.display_name} — {template.step_count} tools explained.[/]\n"
        )

        for i, step in enumerate(template.steps, 1):
            blurb = _TOOL_LEARN.get(step.tool, {})
            self.console.print(Panel(
                f"[bold white]{blurb.get('desc', 'No description available.')}[/]\n\n"
                f"[cyan]Why here:[/] {blurb.get('why', step.why_next or '—')}\n"
                f"[green]Expected output:[/] {blurb.get('out', step.expected_output or '—')}",
                title=f"[bold cyan][{i}/{template.step_count}] {step.tool}[/]  "
                      f"[dim]Stage {step.stage}[/]",
                border_style="yellow",
                padding=(0, 2),
            ))
            try:
                Prompt.ask("[dim]Enter → next tool[/]", default="")
            except (KeyboardInterrupt, EOFError):
                break

        # Chain explanation if available
        if template.chain_explanation:
            self.console.print()
            self.console.print("[bold yellow]Why this sequence?[/]")
            for line in template.chain_explanation:
                self.console.print(f"  [dim]•[/] {line}")
            self.console.print()

    # ── Step 7: Customise ─────────────────────────────────────────────────────

    def _step_customise(self, template):
        self.console.print()
        self.console.print(Rule("[bold green]Customise Workflow[/]", style="green"))

        table = Table(box=box.SIMPLE_HEAD, border_style="dim green")
        table.add_column("#",      style="dim cyan", width=4)
        table.add_column("Tool",   style="bold white", width=20)
        table.add_column("Stage",  style="dim", width=7)
        table.add_column("Parallel", style="dim green", width=14)
        for i, s in enumerate(template.steps, 1):
            table.add_row(
                str(i), s.tool, f"S{s.stage}",
                s.parallel_group or "—"
            )
        self.console.print(table)
        self.console.print()

        self.console.print("[dim]Enter step numbers to remove (e.g. 3,5,7), or Enter to keep all.[/]")
        try:
            raw = Prompt.ask("[bold green]Remove[/]", default="").strip()
        except (KeyboardInterrupt, EOFError):
            return template

        if raw:
            remove = set()
            for part in raw.split(","):
                try:
                    remove.add(int(part.strip()))
                except ValueError:
                    pass
            template.steps = [
                s for i, s in enumerate(template.steps, 1)
                if i not in remove
            ]
            self.console.print(
                f"[green]✓[/] Kept {len(template.steps)} steps."
            )
        return template

    # ── Execute ───────────────────────────────────────────────────────────────

    def _execute(self, template, target: str) -> None:
        self.console.print()
        cb     = self._rec.make_step_callback()
        engine = WorkflowEngine18(
            registry    = self._engine._registry,
            console     = self.console,
            on_step_done = cb,
        )

        record = engine.execute(template, target)

        # Save session
        try:
            path = self._rec.save(record)
            self.console.print(f"\n[bold green]📁 Session saved:[/] {path}")
        except Exception as exc:
            self.console.print(f"[yellow]Session save failed: {exc}[/]")

        # DecisionEngine recommendations
        self._show_recommendations(record, target)

    def _show_recommendations(self, record, target: str) -> None:
        if not record.recommendations:
            return
        self.console.print()
        self.console.print(
            Panel(
                "\n".join(
                    f"  [{'bold red' if r.get('severity') == 'CRITICAL' else 'yellow'}]"
                    f"[{r.get('severity','INFO')}][/]  "
                    f"[bold white]{r.get('label','?')}[/]  "
                    f"[dim]→ {r.get('suggestions',[{}])[0].get('tool','?')}[/]"
                    for r in record.recommendations[:6]
                ),
                title="[bold cyan]What to investigate next[/]",
                border_style="cyan",
            )
        )

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _header(self) -> None:
        self.console.print()
        self.console.print(Panel(
            "[bold cyan]ReconX Guided Recon Assistant[/]\n"
            "[dim]I'll guide you through a structured reconnaissance workflow "
            "step by step — from target selection to actionable findings.[/]",
            border_style="cyan",
            title="[bold]Stage 18 — Guided Operations[/]",
        ))

    def _confirm_run(self) -> bool:
        try:
            ans = Prompt.ask(
                "[bold cyan]Run the workflow now?[/] (y/n)", default="y"
            ).lower()
        except (KeyboardInterrupt, EOFError):
            return False
        return ans == "y"
