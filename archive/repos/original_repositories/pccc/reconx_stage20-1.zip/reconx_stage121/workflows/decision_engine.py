"""
ReconX — Stage 18: Decision Engine.

AI-style recommendation layer that maps discovered findings to intelligent
next-step tool suggestions.  Given what has been found so far, the engine
reasons about what an experienced operator would investigate next.

Pattern:  finding_type + context → [ToolSuggestion, ...]

Finding signals handled:
  Port-based:    SMB, RDP, Redis, MongoDB, Elasticsearch, Docker, K8s,
                 FTP, SMTP, Telnet, VNC, MSSQL, MySQL, PostgreSQL, RabbitMQ
  Web-based:     Login panel, Admin panel, API endpoint, GraphQL, Swagger
  Discovery:     Subdomains found, Live hosts, Cloud buckets, Git repos
  Tech-based:    WordPress, Joomla, Drupal, Jenkins, GitLab, Confluence
  Certificate:   SAN domains, Expiring/expired TLS
  OSINT:         Email addresses, Breaches, GitHub presence

Usage:
    from reconx.workflows.decision_engine import DecisionEngine

    engine = DecisionEngine()
    tips   = engine.recommend(result)          # from ReconResult
    tips   = engine.recommend_from_tags(tags)  # from TagEngine output
    tips   = engine.recommend_finding("port:445")
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Optional

log = logging.getLogger("reconx.workflows.decision_engine")


# ─────────────────────────────────────────────────────────────────────────────
# Data models
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class ToolSuggestion:
    """A single recommended tool with rationale."""
    tool_name:   str           # display name, e.g. "enum4linux-ng"
    tool_class:  str           # registry class name, e.g. "Enum4linuxTool"
    reason:      str           # why this tool is recommended
    priority:    int           = 50       # 1=urgent, 100=optional
    category:    str           = "active"  # passive | active | exploit
    commands:    list[str]     = field(default_factory=list)
    learn_key:   str           = ""        # ServiceLearning lookup key


@dataclass
class DecisionResult:
    """Recommendations produced for one finding or a full result set."""
    trigger:     str                         # what caused this recommendation
    label:       str                         # human-readable finding label
    suggestions: list[ToolSuggestion]        = field(default_factory=list)
    context:     str                         = ""
    severity:    str                         = "INFO"   # INFO | LOW | MEDIUM | HIGH | CRITICAL

    def top(self, n: int = 3) -> list[ToolSuggestion]:
        return sorted(self.suggestions, key=lambda t: t.priority)[:n]

    def to_dict(self) -> dict:
        return {
            "trigger":    self.trigger,
            "label":      self.label,
            "context":    self.context,
            "severity":   self.severity,
            "suggestions": [
                {
                    "tool":     s.tool_name,
                    "class":    s.tool_class,
                    "reason":   s.reason,
                    "priority": s.priority,
                    "commands": s.commands,
                }
                for s in self.suggestions
            ],
        }


# ─────────────────────────────────────────────────────────────────────────────
# Decision rules database
# ─────────────────────────────────────────────────────────────────────────────
# Format: trigger_key → DecisionResult prototype (without dynamic context)

_RULES: dict[str, dict] = {

    # ── Port-based findings ───────────────────────────────────────────────────

    "port:445": {
        "label":    "SMB Service (port 445)",
        "context":  "SMB is exposed. Enumerate shares, sessions, and check for EternalBlue.",
        "severity": "CRITICAL",
        "suggestions": [
            ToolSuggestion("enum4linux-ng",  "Enum4linuxTool",  "Full SMB enumeration: shares, users, policies", 1,  "active", ["enum4linux-ng -A TARGET"]),
            ToolSuggestion("netexec (nxc)",  "NetexecTool",     "SMB authentication and share probing",           2,  "active", ["nxc smb TARGET -u '' -p '' --shares"]),
            ToolSuggestion("smbclient",      "SmbclientTool",   "Interactive SMB share browsing",                 3,  "active", ["smbclient -L //TARGET -N"]),
            ToolSuggestion("nmap smb-vuln*", "NmapTool",        "Check for EternalBlue (MS17-010)",               4,  "active", ["nmap -p445 --script smb-vuln-ms17-010 TARGET"]),
            ToolSuggestion("Metasploit",     "MetasploitTool",  "auxiliary/scanner/smb/smb_ms17_010",            10, "exploit", ["use auxiliary/scanner/smb/smb_ms17_010"]),
        ],
    },

    "port:3389": {
        "label":    "RDP Service (port 3389)",
        "context":  "RDP is exposed. Highest ransomware entry vector — verify patch level and authentication.",
        "severity": "CRITICAL",
        "suggestions": [
            ToolSuggestion("nmap rdp*",    "NmapTool",      "RDP encryption audit + BlueKeep check", 1, "active", ["nmap -p3389 --script rdp-enum-encryption,rdp-vuln-ms12-020 TARGET"]),
            ToolSuggestion("Hydra",        "HydraTool",     "RDP credential brute-force",            2, "active", ["hydra -L users.txt -P pass.txt rdp://TARGET"]),
            ToolSuggestion("netexec rdp",  "NetexecTool",   "RDP authentication testing",            3, "active", ["nxc rdp TARGET -u admin -p pass"]),
        ],
    },

    "port:6379": {
        "label":    "Redis (port 6379)",
        "context":  "Redis is exposed. Default: no authentication. Test for config dump and RCE.",
        "severity": "CRITICAL",
        "suggestions": [
            ToolSuggestion("redis-cli",    "RedisTool",   "Unauthenticated info dump",             1, "active", ["redis-cli -h TARGET info", "redis-cli -h TARGET config get bind"]),
            ToolSuggestion("nuclei redis", "NucleiTool",  "Redis exposure templates",              2, "active", ["nuclei -t redis/ -target TARGET"]),
            ToolSuggestion("nmap redis",   "NmapTool",    "Redis service info",                    3, "active", ["nmap -p6379 --script redis-info TARGET"]),
        ],
    },

    "port:9200": {
        "label":    "Elasticsearch (port 9200)",
        "context":  "Elasticsearch REST API exposed. Test for unauthenticated index access.",
        "severity": "CRITICAL",
        "suggestions": [
            ToolSuggestion("curl ES API",  "CurlTool",    "List all indices without auth",          1, "active", ["curl http://TARGET:9200/_cat/indices?v", "curl http://TARGET:9200/_cluster/health"]),
            ToolSuggestion("nuclei ES",    "NucleiTool",  "Elasticsearch exposure templates",       2, "active", ["nuclei -t elasticsearch/ -target TARGET"]),
        ],
    },

    "port:27017": {
        "label":    "MongoDB (port 27017)",
        "context":  "MongoDB exposed. Test for unauthenticated database access.",
        "severity": "CRITICAL",
        "suggestions": [
            ToolSuggestion("mongosh",      "MongoTool",   "List databases without auth",            1, "active", ["mongosh --host TARGET --eval 'db.adminCommand({listDatabases:1})'"]),
            ToolSuggestion("nuclei mongo", "NucleiTool",  "MongoDB exposure templates",             2, "active", ["nuclei -t mongodb/ -target TARGET"]),
            ToolSuggestion("nmap mongo",   "NmapTool",    "MongoDB service info",                   3, "active", ["nmap -p27017 --script mongodb-info TARGET"]),
        ],
    },

    "port:2375": {
        "label":    "Docker API (port 2375)",
        "context":  "Unauthenticated Docker API. Full host compromise possible via container escape.",
        "severity": "CRITICAL",
        "suggestions": [
            ToolSuggestion("docker cli",   "DockerTool",  "List containers remotely",               1, "active", ["docker -H tcp://TARGET:2375 ps", "docker -H tcp://TARGET:2375 info"]),
            ToolSuggestion("nuclei docker","NucleiTool",  "Docker API exposure templates",          2, "active", ["nuclei -t docker/ -target TARGET"]),
        ],
    },

    "port:6443": {
        "label":    "Kubernetes API (port 6443)",
        "context":  "Kubernetes API exposed. Test for anonymous access and RBAC misconfigs.",
        "severity": "CRITICAL",
        "suggestions": [
            ToolSuggestion("kube-hunter",  "KubeHunterTool", "K8s cluster penetration testing",   1, "active", ["kube-hunter --remote TARGET"]),
            ToolSuggestion("kubectl",      "KubectlTool",    "Unauthenticated API access test",    2, "active", ["kubectl --server https://TARGET:6443 get pods --all-namespaces"]),
            ToolSuggestion("nuclei k8s",   "NucleiTool",     "Kubernetes exposure templates",      3, "active", ["nuclei -t kubernetes/ -target TARGET"]),
        ],
    },

    "port:22": {
        "label":    "SSH (port 22)",
        "context":  "SSH exposed. Audit algorithms, check version, test credentials.",
        "severity": "MEDIUM",
        "suggestions": [
            ToolSuggestion("ssh-audit",    "SshAuditTool", "Algorithm audit and version check",    1, "active", ["ssh-audit TARGET"]),
            ToolSuggestion("nmap ssh",     "NmapTool",     "SSH hostkey and algorithm enum",       2, "active", ["nmap -p22 --script ssh-hostkey,ssh2-enum-algos TARGET"]),
            ToolSuggestion("Hydra",        "HydraTool",    "SSH credential brute-force",           5, "active", ["hydra -L users.txt -P pass.txt TARGET ssh"]),
        ],
    },

    "port:21": {
        "label":    "FTP (port 21)",
        "context":  "FTP exposed. Test anonymous access and vsftpd 2.3.4 backdoor.",
        "severity": "HIGH",
        "suggestions": [
            ToolSuggestion("nmap ftp",     "NmapTool",    "FTP anon access + vsftpd backdoor",     1, "active", ["nmap -p21 --script ftp-anon,ftp-vsftpd-backdoor TARGET"]),
            ToolSuggestion("ftp client",   "FtpTool",     "Anonymous FTP login test",              2, "active", ["ftp -A TARGET"]),
            ToolSuggestion("Hydra",        "HydraTool",   "FTP credential brute-force",            3, "active", ["hydra -L users.txt -P pass.txt ftp://TARGET"]),
        ],
    },

    # ── Web findings ──────────────────────────────────────────────────────────

    "tag:ADMIN": {
        "label":    "Admin Panel Detected",
        "context":  "Administrative interface found. Test for default credentials and version disclosure.",
        "severity": "HIGH",
        "suggestions": [
            ToolSuggestion("nuclei admin", "NucleiTool",    "Admin panel exposure templates",      1, "active", ["nuclei -t exposures/ -target TARGET"]),
            ToolSuggestion("Hydra",        "HydraTool",     "Default credential test",             2, "active", ["hydra -l admin -P passwords.txt TARGET http-form-post"]),
            ToolSuggestion("WhatWeb",      "WhatWebTool",   "CMS and tech fingerprint",            3, "passive", ["whatweb TARGET"]),
        ],
    },

    "tag:API": {
        "label":    "API Endpoint Detected",
        "context":  "API surface found. Enumerate endpoints, parameters, and authentication.",
        "severity": "MEDIUM",
        "suggestions": [
            ToolSuggestion("Kiterunner",   "KiterunnerTool",  "API route brute-force",             1, "active", ["kr scan TARGET -w routes-small.kite"]),
            ToolSuggestion("Arjun",        "ArjunTool",       "HTTP parameter discovery",          2, "active", ["arjun -u TARGET"]),
            ToolSuggestion("nuclei api",   "NucleiTool",      "API exposure and auth templates",   3, "active", ["nuclei -t exposures/apis/ -target TARGET"]),
            ToolSuggestion("ffuf",         "FfufTool",        "API endpoint fuzzing",              4, "active", ["ffuf -u TARGET/FUZZ -w /wordlists/api-endpoints.txt"]),
        ],
    },

    "graphql": {
        "label":    "GraphQL Endpoint",
        "context":  "GraphQL endpoint detected. Perform introspection and query enumeration.",
        "severity": "MEDIUM",
        "suggestions": [
            ToolSuggestion("graphw00f",    "Graphw00fTool",   "GraphQL engine fingerprint",        1, "passive", ["graphw00f -t TARGET"]),
            ToolSuggestion("InQL",         "InQLTool",        "GraphQL introspection query",       2, "active",  ["python inql.py -t TARGET/graphql"]),
            ToolSuggestion("clairvoyance", "ClairvoyanceTool","Blind introspection",               3, "active",  ["python clairvoyance.py -u TARGET/graphql"]),
            ToolSuggestion("nuclei graphql","NucleiTool",     "GraphQL templates",                 4, "active",  ["nuclei -t exposures/ -target TARGET"]),
        ],
    },

    "swagger": {
        "label":    "Swagger / OpenAPI Spec",
        "context":  "API specification found. Extract all endpoints and test each for auth bypass.",
        "severity": "MEDIUM",
        "suggestions": [
            ToolSuggestion("ffuf",         "FfufTool",     "Fuzz all documented endpoints",        1, "active",  ["ffuf -u TARGET/FUZZ -w api-endpoints.txt"]),
            ToolSuggestion("Arjun",        "ArjunTool",    "Parameter discovery on API paths",     2, "active",  ["arjun -u TARGET/api/v1/endpoint"]),
            ToolSuggestion("nuclei swagger","NucleiTool",  "OpenAPI exposure templates",           3, "active",  ["nuclei -t exposures/apis/swagger.yaml -target TARGET"]),
        ],
    },

    "login_panel": {
        "label":    "Login Panel",
        "context":  "Authentication panel found. Test for default credentials and brute-force protection.",
        "severity": "HIGH",
        "suggestions": [
            ToolSuggestion("Hydra",        "HydraTool",    "HTTP form credential brute-force",     1, "active",  ["hydra -L users.txt -P pass.txt TARGET http-post-form '/login:user=^USER^&pass=^PASS^:Invalid'"]),
            ToolSuggestion("nuclei auth",  "NucleiTool",   "Default credential templates",         2, "active",  ["nuclei -t default-logins/ -target TARGET"]),
            ToolSuggestion("ffuf login",   "FfufTool",     "Login bypass fuzzing",                 3, "active",  ["ffuf -u TARGET/login -X POST -d 'user=FUZZ&pass=admin' -w usernames.txt"]),
        ],
    },

    # ── Discovery findings ────────────────────────────────────────────────────

    "subdomains_found": {
        "label":    "Subdomains Discovered",
        "context":  "Subdomain list populated. Probe for live hosts and technology stack.",
        "severity": "INFO",
        "suggestions": [
            ToolSuggestion("HTTPX",        "HttpxTool",    "Probe subdomains for live HTTP/S",     1, "active",  ["httpx -list subdomains.txt -title -tech-detect -status-code"]),
            ToolSuggestion("GoWitness",    "GoWitnessTool","Screenshot all live hosts",            2, "active",  ["gowitness file -f subdomains.txt"]),
            ToolSuggestion("AlterX",       "AlterxTool",   "Generate subdomain permutations",      3, "active",  ["alterx -list subs.txt | httpx -silent"]),
            ToolSuggestion("Subfinder",    "SubfinderTool","Expand with additional passive enum",  4, "passive", ["subfinder -d TARGET -all -o more-subs.txt"]),
        ],
    },

    "subdomain_takeover": {
        "label":    "Subdomain Takeover Candidate",
        "context":  "DNS points to unclaimed resource. Verify and claim the external resource.",
        "severity": "HIGH",
        "suggestions": [
            ToolSuggestion("nuclei takeover","NucleiTool",   "Takeover confirmation templates",    1, "active",  ["nuclei -t dns/subdomain-takeover.yaml -target TARGET"]),
            ToolSuggestion("subjack",        "SubjackTool",  "Bulk subdomain takeover check",      2, "active",  ["subjack -w subs.txt -t 100 -ssl"]),
            ToolSuggestion("can-i-take-over","TakeoverTool", "Service-aware takeover check",       3, "active",  ["python3 can-i-take-over.py -l subs.txt"]),
        ],
    },

    "cloud_bucket": {
        "label":    "Cloud Storage Bucket",
        "context":  "S3 or cloud storage bucket detected. Test read/write access and listing.",
        "severity": "HIGH",
        "suggestions": [
            ToolSuggestion("S3Scanner",    "S3ScannerTool",  "S3 bucket ACL and listing",         1, "active",  ["s3scanner scan --buckets-file buckets.txt"]),
            ToolSuggestion("AWS CLI",      "AwsCliTool",     "List bucket contents",              2, "active",  ["aws s3 ls s3://TARGET --no-sign-request"]),
            ToolSuggestion("GrayhatWarfare","GrayhatTool",   "Find related buckets",              3, "passive", ["curl 'https://buckets.grayhatwarfare.com/api/v1/buckets?keywords=TARGET'"]),
        ],
    },

    "git_exposure": {
        "label":    "Git Repository / .git Exposed",
        "context":  "Source code or git history accessible. Extract secrets and credentials.",
        "severity": "CRITICAL",
        "suggestions": [
            ToolSuggestion("GitLeaks",     "GitLeaksTool",  "Secret scanning in git history",     1, "active",  ["gitleaks detect --source=. -v"]),
            ToolSuggestion("git-dumper",   "GitDumperTool", "Download exposed .git directory",    2, "active",  ["git-dumper http://TARGET/.git ./output"]),
            ToolSuggestion("TruffleHog",   "TruffleHogTool","Deep secret detection in history",  3, "active",  ["trufflehog git --repo=https://github.com/ORG/REPO"]),
        ],
    },

    # ── Technology findings ───────────────────────────────────────────────────

    "tech:wordpress": {
        "label":    "WordPress CMS",
        "context":  "WordPress detected. Enumerate plugins, themes, users, and vulnerabilities.",
        "severity": "MEDIUM",
        "suggestions": [
            ToolSuggestion("WPScan",       "WpscanTool",   "WordPress vulnerability scan",         1, "active",  ["wpscan --url TARGET --enumerate vp,vt,u"]),
            ToolSuggestion("nuclei wp",    "NucleiTool",   "WordPress-specific templates",         2, "active",  ["nuclei -t cms/wordpress/ -target TARGET"]),
        ],
    },

    "tech:jenkins": {
        "label":    "Jenkins CI/CD",
        "context":  "Jenkins detected. Test for unauthenticated script console and exposed builds.",
        "severity": "HIGH",
        "suggestions": [
            ToolSuggestion("nuclei jenkins","NucleiTool",   "Jenkins exposure templates",          1, "active",  ["nuclei -t exposures/jenkins/ -target TARGET"]),
            ToolSuggestion("nmap jenkins",  "NmapTool",     "Jenkins script console check",       2, "active",  ["nmap -p8080 --script http-jenkins TARGET"]),
        ],
    },

    "tech:jira": {
        "label":    "Jira / Atlassian",
        "context":  "Jira detected. Check for CVE-2022-26134 (OGNL injection) and user enumeration.",
        "severity": "HIGH",
        "suggestions": [
            ToolSuggestion("nuclei jira",  "NucleiTool",   "Jira vulnerability templates",        1, "active",  ["nuclei -t exposures/jira/ -target TARGET"]),
            ToolSuggestion("nmap jira",    "NmapTool",     "Jira version detection",              2, "active",  ["nmap -p443 --script http-auth-finder TARGET"]),
        ],
    },

    # ── OSINT / email findings ────────────────────────────────────────────────

    "emails_found": {
        "label":    "Email Addresses Harvested",
        "context":  "Email addresses discovered. Check for breaches and use for phishing simulation.",
        "severity": "INFO",
        "suggestions": [
            ToolSuggestion("Holehe",       "HoleheTool",   "Check email on 200+ services",        1, "passive", ["holehe EMAIL"]),
            ToolSuggestion("theHarvester", "TheHarvesterTool","Expand email/domain OSINT",        2, "passive", ["theHarvester -d TARGET -b all"]),
            ToolSuggestion("h8mail",       "H8mailTool",   "Breach database check",               3, "passive", ["h8mail -t EMAIL"]),
        ],
    },

    # ── TLS findings ──────────────────────────────────────────────────────────

    "tls_weak": {
        "label":    "Weak / Expired TLS",
        "context":  "TLS misconfiguration detected. Full audit for weak ciphers and protocol versions.",
        "severity": "HIGH",
        "suggestions": [
            ToolSuggestion("testssl.sh",   "TestSSLTool",  "Comprehensive TLS cipher audit",      1, "active",  ["testssl.sh TARGET"]),
            ToolSuggestion("TLSX",         "TLSXTool",     "Fast TLS fingerprinting",             2, "active",  ["tlsx -u TARGET -san -cn -serial"]),
            ToolSuggestion("nmap ssl",     "NmapTool",     "SSL/TLS vulnerability check",         3, "active",  ["nmap --script ssl-enum-ciphers -p443 TARGET"]),
        ],
    },
}


# ─────────────────────────────────────────────────────────────────────────────
# DecisionEngine
# ─────────────────────────────────────────────────────────────────────────────

class DecisionEngine:
    """
    Maps findings from a completed (or partial) scan to prioritised
    next-step tool recommendations.

    Never raises — all errors are logged and empty results returned.
    """

    def recommend(self, result) -> list[DecisionResult]:
        """
        Produce recommendations from a ReconResult object.

        Inspects open ports, technologies, TLS info, emails, and
        infrastructure tags to produce actionable next steps.
        """
        results: list[DecisionResult] = []
        seen: set[str] = set()

        def _add(key: str) -> None:
            if key in seen:
                return
            seen.add(key)
            rule = _RULES.get(key)
            if rule:
                results.append(self._build(key, rule, result.target))

        try:
            # Port-based
            for port in getattr(result, "ports", []):
                if getattr(port, "state", "") == "open":
                    _add(f"port:{port.number}")

            # Technology-based
            for tech in getattr(result, "technologies", []):
                name_lower = tech.name.lower()
                for kw in ("wordpress", "jenkins", "jira", "confluence",
                           "gitlab", "grafana", "kibana", "elasticsearch"):
                    if kw in name_lower:
                        _add(f"tech:{kw}")

            # Emails
            if getattr(result, "emails", []):
                _add("emails_found")

            # Subdomains
            if len(getattr(result, "subdomains", [])) > 3:
                _add("subdomains_found")

            # Takeover candidates
            if getattr(result, "takeover_candidates", []):
                _add("subdomain_takeover")

            # TLS
            tls = getattr(result, "tls_info", None)
            if tls and (getattr(tls, "is_expired", False) or
                        getattr(tls, "is_self_signed", False)):
                _add("tls_weak")

            # Intelligence tags
            intel = getattr(result, "raw", {}).get("intelligence", {})
            tag_summary = intel.get("tags", {}).get("tag_summary", {})
            for tag in ("ADMIN", "API", "DEVTOOLS", "K8S"):
                if tag in tag_summary:
                    _add(f"tag:{tag}")

        except Exception as exc:
            log.warning(f"DecisionEngine.recommend() error: {exc}")

        # Sort by severity priority
        _sev_order = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "INFO": 4}
        results.sort(key=lambda r: _sev_order.get(r.severity, 99))
        return results

    def recommend_finding(self, finding_key: str, target: str = "TARGET") -> Optional[DecisionResult]:
        """
        Return recommendations for a specific finding key.

        Keys follow the pattern used in _RULES:
          "port:445", "tag:ADMIN", "graphql", "cloud_bucket", etc.
        """
        rule = _RULES.get(finding_key)
        if not rule:
            # Fuzzy fallback
            for key, r in _RULES.items():
                if finding_key.lower() in key.lower():
                    rule = r
                    finding_key = key
                    break
        if not rule:
            return None
        return self._build(finding_key, rule, target)

    def recommend_from_tags(
        self, tag_summary: dict[str, int], target: str = "TARGET"
    ) -> list[DecisionResult]:
        """
        Produce recommendations directly from a TagEngine tag_summary dict.
        """
        results: list[DecisionResult] = []
        seen: set[str] = set()
        for tag in tag_summary:
            key = f"tag:{tag}"
            if key in _RULES and key not in seen:
                seen.add(key)
                results.append(self._build(key, _RULES[key], target))
        return results

    def all_rules(self) -> list[str]:
        """Return all registered rule keys."""
        return list(_RULES.keys())

    # ── Internal ──────────────────────────────────────────────────────────────

    def _build(self, key: str, rule: dict, target: str) -> DecisionResult:
        """Materialise a rule dict into a DecisionResult with target substituted."""
        suggestions = []
        for s in rule.get("suggestions", []):
            cmds = [c.replace("TARGET", target) for c in s.commands]
            suggestions.append(ToolSuggestion(
                tool_name  = s.tool_name,
                tool_class = s.tool_class,
                reason     = s.reason,
                priority   = s.priority,
                category   = s.category,
                commands   = cmds,
                learn_key  = s.learn_key,
            ))
        return DecisionResult(
            trigger     = key,
            label       = rule.get("label", key),
            context     = rule.get("context", ""),
            severity    = rule.get("severity", "INFO"),
            suggestions = suggestions,
        )
