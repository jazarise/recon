"""
ReconX — Stage 18: Workflow Templates.

Eight named, richly-documented workflow blueprints covering the most
common professional reconnaissance engagement types.

Each template defines:
  - Ordered tool chains with stage grouping
  - Parallelism hints
  - Learning context (purpose, use-cases, advantages, expected output)
  - Tool chain explanation (why each step follows the previous)

Templates:
  1. bug_bounty          — Modern bug bounty recon
  2. external_infra      — External infrastructure assessment
  3. web_application     — Web application security review
  4. api_assessment      — API surface discovery and testing
  5. internal_network    — Internal / LAN network assessment
  6. cloud_assessment    — Cloud infrastructure review
  7. deep_investigation  — Maximum-depth investigation
  8. fast_triage         — Speed-first 5-minute triage

Usage:
    from reconx.workflows.workflow_templates import WorkflowTemplateLibrary

    lib  = WorkflowTemplateLibrary()
    tmpl = lib.get("bug_bounty")
    for step in tmpl.steps:
        print(step.tool, "→", step.why_next)
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional


# ─────────────────────────────────────────────────────────────────────────────
# Data models
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class TemplateStep:
    """One step in a workflow template."""
    tool:          str              # display name
    tool_class:    str              # registry class name
    stage:         int              = 1
    parallel_group: Optional[str]  = None   # steps with same group run together
    skippable:     bool             = True
    why_next:      str              = ""    # explains the chain link
    expected_output: str           = ""
    timeout_s:     Optional[int]   = None


@dataclass
class WorkflowTemplate:
    """
    A named, self-documenting workflow blueprint.

    Contains all data needed to:
      - Execute the workflow (via WorkflowEngine)
      - Explain it to learners (purpose, chain explanation)
      - Display it in the TUI builder
    """
    name:          str
    display_name:  str
    description:   str
    category:      str                    # web | network | api | cloud | osint | full
    target_types:  list[str]              # domain | ip | cidr | url | email
    tags:          list[str]
    steps:         list[TemplateStep]     = field(default_factory=list)
    purpose:       str                    = ""
    use_cases:     list[str]             = field(default_factory=list)
    advantages:    list[str]             = field(default_factory=list)
    expected_output: str                 = ""
    chain_explanation: list[str]         = field(default_factory=list)
    estimated_min: int                   = 0
    requires_root: bool                  = False
    author:        str                   = "ReconX"

    @property
    def step_count(self) -> int:
        return len(self.steps)

    @property
    def tool_names(self) -> list[str]:
        return [s.tool for s in self.steps]

    def to_dict(self) -> dict:
        return {
            "name":             self.name,
            "display_name":     self.display_name,
            "description":      self.description,
            "category":         self.category,
            "target_types":     self.target_types,
            "tags":             self.tags,
            "steps":            [
                {
                    "tool":           s.tool,
                    "tool_class":     s.tool_class,
                    "stage":          s.stage,
                    "parallel_group": s.parallel_group,
                    "skippable":      s.skippable,
                    "why_next":       s.why_next,
                }
                for s in self.steps
            ],
            "purpose":            self.purpose,
            "use_cases":          self.use_cases,
            "advantages":         self.advantages,
            "expected_output":    self.expected_output,
            "chain_explanation":  self.chain_explanation,
            "estimated_min":      self.estimated_min,
            "requires_root":      self.requires_root,
        }


# ─────────────────────────────────────────────────────────────────────────────
# Step builder shorthand
# ─────────────────────────────────────────────────────────────────────────────

def _s(tool: str, cls: str, stage: int = 1, group: str = None,
       skip: bool = True, why: str = "", out: str = "", to: int = None) -> TemplateStep:
    return TemplateStep(
        tool=tool, tool_class=cls, stage=stage, parallel_group=group,
        skippable=skip, why_next=why, expected_output=out, timeout_s=to,
    )


# ─────────────────────────────────────────────────────────────────────────────
# Template definitions
# ─────────────────────────────────────────────────────────────────────────────

def _bug_bounty() -> WorkflowTemplate:
    return WorkflowTemplate(
        name="bug_bounty", display_name="Bug Bounty Recon",
        description="Modern bug bounty reconnaissance chain covering subdomain discovery, "
                    "live host validation, technology fingerprinting, content discovery, "
                    "JS secret scanning, and vulnerability templates.",
        category="web", target_types=["domain"],
        tags=["bug-bounty", "subdomain", "takeover", "secrets", "cors"],
        estimated_min=45,
        purpose="Maximise target surface coverage for bug bounty engagements.",
        use_cases=[
            "HackerOne / Bugcrowd program recon",
            "Pre-engagement scope definition",
            "Continuous monitoring of growing attack surface",
        ],
        advantages=[
            "Covers passive + active subdomain discovery in parallel",
            "Automatically checks for subdomain takeovers",
            "JS secret scanning surfaces hardcoded API keys",
            "GoWitness screenshots let you visually triage 100s of subdomains fast",
        ],
        expected_output="Subdomain list, live host map, screenshots, endpoint list, "
                        "secret findings, vulnerability matches.",
        chain_explanation=[
            "WHOIS → establishes domain ownership and registrar history",
            "Subfinder + Amass → passive subdomain discovery from CT logs and APIs",
            "CrtSH → certificate transparency logs for historical subdomains",
            "AlterX → permutation generation from known subdomains",
            "HTTPX → filters subdomain list to only live HTTP targets",
            "Subdomain Takeover Check → identifies dangling DNS pointers",
            "GoSpider + Katana → crawl live targets for endpoints and JS files",
            "SecretFinder → scans JS files for API keys and credentials",
            "FeroxBuster → content discovery on each live host",
            "CORS Check → identifies cross-origin policy misconfigurations",
            "Nuclei → runs vulnerability templates against all live targets",
            "GoWitness → screenshot all hosts for visual triage",
        ],
        steps=[
            _s("WHOIS",          "WhoisTool",         1, skip=False, why="Establish domain ownership", out="Registrar, org, ASN"),
            _s("Subfinder",      "SubfinderTool",      1, "passive_subs", why="Passive subdomain discovery", out="Subdomain list"),
            _s("Amass",          "AmassTool",          1, "passive_subs", why="Passive + active subdomain enum", out="Subdomain list"),
            _s("CrtSH",          "CrtshTool",          1, "passive_subs", why="Certificate transparency log search", out="Subdomain list"),
            _s("AlterX",         "AlterxTool",         1, why="Permutation-based subdomain generation", out="Permutation list"),
            _s("HTTPX",          "HttpxTool",          2, skip=False, why="Probe subdomains for live HTTP services", out="Live host list"),
            _s("Takeover Check", "TakeoverDetector",   2, why="Identify dangling DNS → takeover candidates", out="Takeover list"),
            _s("GoSpider",       "GospiderTool",       2, "crawl", why="Crawl live targets for links and JS", out="URL list, JS files"),
            _s("Katana",         "KatanaTool",         2, "crawl", why="JavaScript-aware crawling for SPA routes", out="Endpoint list"),
            _s("SecretFinder",   "SecretFinderTool",   3, why="Scan JS for API keys / credentials", out="Secret list"),
            _s("FeroxBuster",    "FeroxbusterTool",    3, why="Recursive content discovery", out="Hidden paths"),
            _s("CORS Check",     "NucleiTool",         3, why="Identify CORS misconfigurations", out="CORS issues"),
            _s("Nuclei",         "NucleiTool",         3, why="Run CVE and exposure templates", out="Vulnerability list"),
            _s("GoWitness",      "GoWitnessTool",      3, why="Screenshot all live hosts for visual triage", out="Screenshots"),
        ],
    )


def _external_infra() -> WorkflowTemplate:
    return WorkflowTemplate(
        name="external_infra", display_name="External Infrastructure Assessment",
        description="Comprehensive external asset discovery and service enumeration. "
                    "Covers OSINT, ASN mapping, port scanning, service fingerprinting, "
                    "and CVE identification.",
        category="network", target_types=["domain", "ip", "cidr"],
        tags=["external", "infrastructure", "ports", "services", "cve"],
        estimated_min=50,
        purpose="Map an organisation's complete external attack surface.",
        use_cases=[
            "External penetration test scoping",
            "Attack surface management (ASM)",
            "Post-acquisition due diligence",
            "Red team preparation",
        ],
        advantages=[
            "ASNMap expands a single domain into all org-owned IP ranges",
            "Masscan fast-sweeps the full IP range before Nmap deep-dives",
            "WhatWeb + WafW00f fingerprint tech stack and WAF before scanning",
            "CVEMapper auto-correlates service versions to known vulnerabilities",
        ],
        expected_output="IP ranges, open ports, service versions, OS guesses, "
                        "CVE matches, technology stack.",
        chain_explanation=[
            "WHOIS → identify registrant organisation and ASN",
            "ASNMap → expand ASN to all IP ranges owned by the org",
            "MapCIDR → enumerate individual IPs from CIDR ranges",
            "Masscan → fast TCP sweep across all IPs (top ports)",
            "Nmap → service/version detection on discovered open ports",
            "WhatWeb → HTTP technology fingerprinting on web services",
            "WafW00f → WAF detection before active web testing",
            "Nikto → web server vulnerability scanning",
            "CVEMapper → map detected service versions to known CVEs",
            "Nuclei → run infrastructure exposure templates",
        ],
        steps=[
            _s("WHOIS",     "WhoisTool",     1, skip=False, why="Identify org and ASN"),
            _s("ASNMap",    "AsnmapTool",    1, why="Expand to all org-owned IP ranges"),
            _s("MapCIDR",   "MapCIDRTool",   1, why="Enumerate individual IPs from CIDRs"),
            _s("Subfinder", "SubfinderTool", 1, "dns_enum", why="Passive subdomain discovery"),
            _s("DNSRecon",  "DNSReconTool",  1, "dns_enum", why="DNS record enumeration"),
            _s("Masscan",   "MasscanTool",   2, why="Fast TCP sweep of all discovered IPs"),
            _s("Nmap",      "NmapTool",      2, skip=False, why="Service/version fingerprinting on open ports"),
            _s("HTTPX",     "HttpxTool",     2, why="HTTP probe on all discovered hosts"),
            _s("WhatWeb",   "WhatWebTool",   2, why="Technology stack fingerprinting"),
            _s("WafW00f",   "Wafw00fTool",   2, why="WAF identification before web testing"),
            _s("Nikto",     "NiktoTool",     3, why="Web server vulnerability scan"),
            _s("Nuclei",    "NucleiTool",    3, why="Infrastructure exposure templates"),
        ],
    )


def _web_application() -> WorkflowTemplate:
    return WorkflowTemplate(
        name="web_application", display_name="Web Application Assessment",
        description="Complete web application recon covering HTTP probing, WAF detection, "
                    "content discovery, parameter identification, JS analysis, "
                    "and vulnerability scanning.",
        category="web", target_types=["domain", "url"],
        tags=["web", "http", "endpoints", "parameters", "javascript", "waf"],
        estimated_min=30,
        purpose="Full security assessment of a web application.",
        use_cases=[
            "DAST pre-engagement surface mapping",
            "Bug bounty web target recon",
            "WAPT scoping and fingerprinting",
        ],
        advantages=[
            "WAF detection prevents wasting time on blocked payloads",
            "Multiple crawlers (GoSpider + Katana) ensure full endpoint coverage",
            "ParamSpider + Arjun cover both passive and active parameter discovery",
            "Nuclei web templates cover OWASP Top 10 patterns",
        ],
        expected_output="Live status, tech stack, WAF info, directory tree, "
                        "parameter list, endpoint map, vulnerability findings.",
        chain_explanation=[
            "HTTPX → verify target is live and capture title, tech, headers",
            "WhatWeb → identify CMS, framework, and server technology",
            "WafW00f → detect WAF to calibrate further testing",
            "GoSpider → crawl all links recursively",
            "Katana → JavaScript-aware crawl for SPA routes",
            "GAU → pull archived URLs from Wayback and URLScan",
            "FeroxBuster → recursive directory and file brute-force",
            "ParamSpider → extract parameters from archived URLs",
            "Arjun → discover hidden GET/POST parameters",
            "LinkFinder → extract endpoints from JavaScript source",
            "SecretFinder → scan JS for API keys and secrets",
            "Nuclei → run web vulnerability templates",
            "GoWitness → screenshot for report",
        ],
        steps=[
            _s("HTTPX",        "HttpxTool",        1, skip=False, why="Confirm live target + fingerprint"),
            _s("WhatWeb",      "WhatWebTool",       1, why="Technology stack identification"),
            _s("WafW00f",      "Wafw00fTool",       1, why="WAF detection"),
            _s("GoSpider",     "GospiderTool",      2, "crawl", why="Recursive link crawling"),
            _s("Katana",       "KatanaTool",        2, "crawl", why="JS-aware SPA crawling"),
            _s("GAU",          "GauTool",           2, "archive", why="Archive URL mining (Wayback + URLScan)"),
            _s("Waymore",      "WaymoreTool",       2, "archive", why="Extended archive source coverage"),
            _s("FeroxBuster",  "FeroxbusterTool",   2, why="Recursive content discovery"),
            _s("ParamSpider",  "ParamSpiderTool",   3, why="Parameter extraction from archived URLs"),
            _s("Arjun",        "ArjunTool",         3, why="Hidden parameter discovery"),
            _s("LinkFinder",   "LinkFinderTool",    3, why="Endpoint extraction from JS"),
            _s("SecretFinder", "SecretFinderTool",  3, why="Secret scanning in JS files"),
            _s("Nuclei",       "NucleiTool",        3, why="Web vulnerability templates"),
            _s("GoWitness",    "GoWitnessTool",     3, why="Visual screenshot for report"),
        ],
    )


def _api_assessment() -> WorkflowTemplate:
    return WorkflowTemplate(
        name="api_assessment", display_name="API Assessment",
        description="API surface discovery covering GraphQL introspection, "
                    "OpenAPI schema extraction, endpoint brute-force, "
                    "parameter discovery, and auth analysis.",
        category="api", target_types=["domain", "url"],
        tags=["api", "graphql", "openapi", "rest", "parameters", "auth"],
        estimated_min=25,
        purpose="Map and test the complete API attack surface.",
        use_cases=[
            "REST API security review",
            "GraphQL endpoint assessment",
            "Microservices attack surface mapping",
            "Mobile app backend testing",
        ],
        advantages=[
            "graphw00f identifies the GraphQL engine before introspection",
            "Kiterunner uses real-world API route wordlists (not generic paths)",
            "Arjun discovers hidden parameters not in documentation",
        ],
        expected_output="API endpoints, GraphQL schema, parameter list, "
                        "authentication patterns, OpenAPI spec.",
        chain_explanation=[
            "HTTPX → confirm API base URL is live",
            "graphw00f → detect GraphQL engine type before introspection",
            "GoSpider → crawl for /api/, /v1/, /v2/ paths in JS",
            "Kiterunner → route brute-force with API-specific wordlists",
            "GAU → mine archived API endpoints",
            "Arjun → discover hidden GET/POST parameters",
            "ffuf → fuzz API endpoints for undocumented paths",
            "nuclei api → API-specific vulnerability templates",
        ],
        steps=[
            _s("HTTPX",        "HttpxTool",        1, skip=False, why="Confirm API is live"),
            _s("graphw00f",    "Graphw00fTool",     1, why="GraphQL engine fingerprinting"),
            _s("GoSpider",     "GospiderTool",      1, why="Crawl for API path references"),
            _s("GAU",          "GauTool",           1, why="Archive API endpoint mining"),
            _s("Kiterunner",   "KiterunnerTool",    2, why="API route brute-force with real wordlists"),
            _s("Arjun",        "ArjunTool",         2, why="Hidden parameter discovery on API endpoints"),
            _s("ffuf",         "FfufTool",          2, why="API endpoint fuzzing"),
            _s("LinkFinder",   "LinkFinderTool",    2, why="JS endpoint extraction"),
            _s("Nuclei",       "NucleiTool",        3, why="API exposure and auth vulnerability templates"),
        ],
    )


def _internal_network() -> WorkflowTemplate:
    return WorkflowTemplate(
        name="internal_network", display_name="Internal Network Assessment",
        description="Internal network reconnaissance covering host discovery, "
                    "port scanning, SMB enumeration, SNMP, service identification, "
                    "and vulnerability assessment.",
        category="network", target_types=["cidr", "ip"],
        tags=["internal", "lan", "smb", "snmp", "active-directory"],
        estimated_min=30, requires_root=True,
        purpose="Map all internal hosts and services on a LAN segment.",
        use_cases=[
            "Internal penetration test",
            "Network security audit",
            "Post-breach lateral movement assessment",
            "Active Directory exposure review",
        ],
        advantages=[
            "ARP scan is faster and more reliable than ICMP on local networks",
            "enum4linux-ng provides comprehensive Windows host intelligence",
            "SNMP community string discovery often yields network topology data",
        ],
        expected_output="Live host list, open ports, service versions, SMB shares, "
                        "SNMP data, OS fingerprints.",
        chain_explanation=[
            "netdiscover → fast ARP-based host discovery on the local subnet",
            "fping → ICMP sweep to confirm live hosts and measure latency",
            "Nmap host scan → OS fingerprinting and hostname resolution",
            "Masscan → fast full-port sweep across all live hosts",
            "Nmap service → detailed version detection on open ports",
            "enum4linux-ng → SMB enumeration: shares, users, policies",
            "SNMP scan → community string discovery and MIB enumeration",
            "Nuclei → internal service vulnerability templates",
        ],
        steps=[
            _s("netdiscover", "NetdiscoverTool",  1, skip=False, why="ARP host discovery on local subnet"),
            _s("fping",       "FpingTool",         1, why="ICMP sweep to confirm live hosts"),
            _s("Nmap OS",     "NmapTool",          1, why="OS fingerprinting and hostname resolution"),
            _s("Masscan",     "MasscanTool",       2, why="Fast full-port sweep", to=600),
            _s("Nmap SVC",    "NmapTool",          2, skip=False, why="Service/version detection on open ports"),
            _s("enum4linux-ng","Enum4linuxTool",   2, why="SMB share, user, policy enumeration"),
            _s("SNMP scan",   "NmapTool",          2, why="SNMP community string discovery"),
            _s("netexec",     "NetexecTool",       2, why="Windows authentication and share testing"),
            _s("Nuclei",      "NucleiTool",        3, why="Internal service exposure templates"),
        ],
    )


def _cloud_assessment() -> WorkflowTemplate:
    return WorkflowTemplate(
        name="cloud_assessment", display_name="Cloud Infrastructure Assessment",
        description="Cloud asset discovery covering ASN mapping, S3 bucket enumeration, "
                    "certificate transparency, cloud host fingerprinting, "
                    "and storage access testing.",
        category="cloud", target_types=["domain", "asn"],
        tags=["cloud", "aws", "s3", "azure", "gcp", "buckets", "iam"],
        estimated_min=35,
        purpose="Enumerate and assess an organisation's cloud infrastructure exposure.",
        use_cases=[
            "Cloud security posture review",
            "S3 bucket exposure assessment",
            "Multi-cloud attack surface mapping",
            "Cloud-native application testing",
        ],
        advantages=[
            "S3Scanner checks bucket permissions without requiring AWS credentials",
            "CrtSH often reveals cloud-specific subdomains not found by DNS brute-force",
            "Nuclei cloud templates check for common misconfigurations at scale",
        ],
        expected_output="Cloud subdomains, S3 buckets (public/private), "
                        "cloud service endpoints, IAM exposure indicators.",
        chain_explanation=[
            "WHOIS → identify cloud provider from ASN registration",
            "ASNMap → map all IP ranges attributed to the organisation",
            "CrtSH → certificate transparency reveals cloud-specific subdomains",
            "Subfinder → passive discovery including cloud provider subdomains",
            "HTTPX → probe for live cloud management interfaces",
            "S3Scanner → enumerate and test S3-compatible bucket access",
            "Nuclei cloud → run AWS/Azure/GCP misconfiguration templates",
            "GoWitness → screenshot cloud management portals",
        ],
        steps=[
            _s("WHOIS",     "WhoisTool",      1, skip=False, why="Identify cloud provider from ASN"),
            _s("ASNMap",    "AsnmapTool",     1, why="Expand to all cloud-attributed IP ranges"),
            _s("CrtSH",     "CrtshTool",      1, "cloud_enum", why="Cloud subdomain discovery via CT logs"),
            _s("Subfinder", "SubfinderTool",  1, "cloud_enum", why="Passive cloud subdomain enumeration"),
            _s("HTTPX",     "HttpxTool",      2, why="Probe for live cloud management interfaces"),
            _s("S3Scanner", "S3ScannerTool",  2, why="S3 bucket enumeration and access testing"),
            _s("TLSX",      "TLSXTool",       2, why="TLS/cert fingerprinting on cloud hosts"),
            _s("Nuclei",    "NucleiTool",     3, why="Cloud misconfiguration templates (AWS/Azure/GCP)"),
            _s("GoWitness", "GoWitnessTool",  3, why="Screenshot cloud portals for report"),
        ],
    )


def _deep_investigation() -> WorkflowTemplate:
    return WorkflowTemplate(
        name="deep_investigation", display_name="Deep Investigation",
        description="Maximum-depth investigation using all available tools across all phases: "
                    "OSINT, subdomain enum, DNS, port scanning, web recon, "
                    "secret scanning, cloud, and vulnerability assessment.",
        category="full", target_types=["domain"],
        tags=["deep", "comprehensive", "all-tools", "full-coverage"],
        estimated_min=120,
        purpose="Leave no stone unturned — maximum coverage investigation.",
        use_cases=[
            "Full external penetration test",
            "Comprehensive attack surface mapping",
            "Pre-acquisition due diligence",
            "Red team full engagement preparation",
        ],
        advantages=[
            "All subdomain discovery methods run in parallel",
            "Both passive and active web crawling for complete endpoint coverage",
            "Historical URL mining reveals retired but still-live content",
            "Combined OSINT provides full organisational intelligence picture",
        ],
        expected_output="Complete asset map: all subdomains, IPs, ports, "
                        "technologies, endpoints, parameters, secrets, "
                        "vulnerabilities, screenshots.",
        chain_explanation=[
            "WHOIS + theHarvester + SpiderFoot → organisational OSINT baseline",
            "ASNMap + MapCIDR → IP space expansion",
            "Subfinder + Amass + CrtSH + Sublist3r + dnsx → comprehensive subdomain coverage",
            "AlterX + ShuffleDNS → permutation-based additional discovery",
            "HTTPX → live host validation across all subdomains",
            "Nmap + Masscan → full port sweep with service detection",
            "WhatWeb + WafW00f + TLSX → technology and WAF fingerprinting",
            "GoSpider + Katana + GAU + Waymore → full endpoint and URL coverage",
            "FeroxBuster + Gobuster → directory and file brute-force",
            "ParamSpider + Arjun → complete parameter discovery",
            "LinkFinder + SecretFinder → JS analysis for endpoints and secrets",
            "S3Scanner + cloud tools → cloud exposure",
            "Nuclei (full templates) → all vulnerability categories",
            "GoWitness + EyeWitness → visual documentation",
        ],
        steps=[
            # Phase 1: OSINT
            _s("WHOIS",         "WhoisTool",        1, skip=False),
            _s("theHarvester",  "TheHarvesterTool", 1, "osint"),
            _s("SpiderFoot",    "SpiderFootTool",   1, "osint"),
            _s("ASNMap",        "AsnmapTool",       1),
            # Phase 2: Subdomain
            _s("Subfinder",     "SubfinderTool",    2, "subs"),
            _s("Amass",         "AmassTool",        2, "subs"),
            _s("CrtSH",         "CrtshTool",        2, "subs"),
            _s("Sublist3r",     "Sublist3rTool",    2, "subs"),
            _s("DNSRecon",      "DNSReconTool",     2, "dns"),
            _s("dnsenum",       "DNSEnumTool",      2, "dns"),
            _s("Fierce",        "FierceTool",       2, "dns"),
            _s("AlterX",        "AlterxTool",       2),
            _s("ShuffleDNS",    "ShuffleDNSTool",   2),
            # Phase 3: Active
            _s("HTTPX",         "HttpxTool",        3, skip=False),
            _s("Masscan",       "MasscanTool",      3),
            _s("Nmap",          "NmapTool",         3, skip=False),
            _s("WhatWeb",       "WhatWebTool",      3),
            _s("WafW00f",       "Wafw00fTool",      3),
            _s("TLSX",          "TLSXTool",         3),
            # Phase 4: Web
            _s("GoSpider",      "GospiderTool",     4, "crawl"),
            _s("Katana",        "KatanaTool",       4, "crawl"),
            _s("GAU",           "GauTool",          4, "archive"),
            _s("Waymore",       "WaymoreTool",      4, "archive"),
            _s("FeroxBuster",   "FeroxbusterTool",  4),
            _s("Gobuster",      "GobusterTool",     4),
            _s("ParamSpider",   "ParamSpiderTool",  4),
            _s("Arjun",         "ArjunTool",        4),
            _s("LinkFinder",    "LinkFinderTool",   4),
            _s("SecretFinder",  "SecretFinderTool", 4),
            # Phase 5: Cloud + Vuln
            _s("S3Scanner",     "S3ScannerTool",    5, "cloud"),
            _s("Nuclei",        "NucleiTool",       5, skip=False),
            _s("Nikto",         "NiktoTool",        5),
            _s("GoWitness",     "GoWitnessTool",    5),
            _s("EyeWitness",    "EyeWitnessTool",   5),
        ],
    )


def _fast_triage() -> WorkflowTemplate:
    return WorkflowTemplate(
        name="fast_triage", display_name="Fast Triage",
        description="Speed-first 5-minute triage using only the highest-yield tools "
                    "in parallel. Gets a quick picture before committing to deeper recon.",
        category="web", target_types=["domain", "ip", "url"],
        tags=["fast", "quick", "triage", "parallel"],
        estimated_min=5,
        purpose="Initial target triage in under 5 minutes.",
        use_cases=[
            "CTF reconnaissance",
            "Initial scope validation",
            "Quick health check before full engagement",
        ],
        advantages=[
            "All phase-1 tools run in parallel for maximum speed",
            "Only 5 tools — minimal noise, maximum signal",
        ],
        expected_output="Basic host info, open ports, HTTP title and tech, "
                        "subdomain count.",
        chain_explanation=[
            "WHOIS → owner and ASN in seconds",
            "Subfinder → passive subdomains with no active traffic",
            "DNSRecon → DNS records reveal mail, cloud, and CDN usage",
            "HTTPX → live web services with title and technology",
            "Nmap top-1000 → most common open ports quickly",
        ],
        steps=[
            _s("WHOIS",     "WhoisTool",      1, "fast_parallel", skip=False),
            _s("Subfinder", "SubfinderTool",  1, "fast_parallel"),
            _s("DNSRecon",  "DNSReconTool",   1, "fast_parallel"),
            _s("HTTPX",     "HttpxTool",      2, skip=False),
            _s("Nmap",      "NmapTool",       2),
        ],
    )


# ─────────────────────────────────────────────────────────────────────────────
# Library
# ─────────────────────────────────────────────────────────────────────────────

class WorkflowTemplateLibrary:
    """
    Registry of all built-in Stage 18 workflow templates.
    Supports runtime registration of custom templates.
    """

    def __init__(self):
        self._templates: dict[str, WorkflowTemplate] = {}
        for fn in [
            _bug_bounty, _external_infra, _web_application,
            _api_assessment, _internal_network, _cloud_assessment,
            _deep_investigation, _fast_triage,
        ]:
            t = fn()
            self._templates[t.name] = t

    def get(self, name: str) -> Optional[WorkflowTemplate]:
        return self._templates.get(name)

    def all(self) -> list[WorkflowTemplate]:
        return list(self._templates.values())

    def by_category(self, category: str) -> list[WorkflowTemplate]:
        return [t for t in self._templates.values() if t.category == category]

    def for_target_type(self, target_type: str) -> list[WorkflowTemplate]:
        return [t for t in self._templates.values()
                if not t.target_types or target_type in t.target_types]

    def names(self) -> list[str]:
        return list(self._templates.keys())

    def register(self, template: WorkflowTemplate) -> None:
        self._templates[template.name] = template

    def summary(self) -> list[dict]:
        return [
            {
                "name":         t.name,
                "display_name": t.display_name,
                "category":     t.category,
                "steps":        t.step_count,
                "est_min":      t.estimated_min,
                "tags":         t.tags[:3],
            }
            for t in self._templates.values()
        ]
