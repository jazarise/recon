"""
ReconX — Stage 18: Recon Workflow Intelligence & Guided Operations.

Public package API:

    from reconx.workflows import (
        WorkflowTemplateLibrary,
        WorkflowEngine18,
        WorkflowRecorder18,
        WorkflowPlayer18,
        WorkflowBuilder18,
        GuidedRecon18,
        DecisionEngine,
    )
"""
from .decision_engine      import DecisionEngine, DecisionResult, ToolSuggestion
from .workflow_templates   import WorkflowTemplateLibrary, WorkflowTemplate, TemplateStep
from .workflow_engine      import WorkflowEngine18, WorkflowRunRecord, StepRecord, StepStatus18
from .workflow_recorder    import WorkflowRecorder18
from .workflow_player      import WorkflowPlayer18
from .workflow_builder     import WorkflowBuilder18
from .guided_recon         import GuidedRecon18
from .report_18            import inject_workflow_section18

__all__ = [
    "DecisionEngine",    "DecisionResult",    "ToolSuggestion",
    "WorkflowTemplateLibrary", "WorkflowTemplate", "TemplateStep",
    "WorkflowEngine18",  "WorkflowRunRecord", "StepRecord", "StepStatus18",
    "WorkflowRecorder18",
    "WorkflowPlayer18",
    "WorkflowBuilder18",
    "GuidedRecon18",
    "inject_workflow_section18",
]
