"""
ReconX — Stage 18: Interactive TUI Workflow Builder.

Allows operators to compose custom workflows from the tool registry,
arrange execution order, set parallelism, and save for later use.

Features:
  • Category-based tool browser
  • Add / remove steps with #-key selection
  • Move steps up/down (drag-style in terminal)
  • Set parallel group labels
  • Preview chain before saving
  • Save as named workflow JSON
  • Load existing workflow for editing

Usage:
    from reconx.workflows.workflow_builder import WorkflowBuilder18
    WorkflowBuilder18().run()
"""
from __future__ import annotations

import json
import logging
import time
from pathlib import Path
from typing import Optional

from rich import box
from rich.columns import Columns
from rich.console import Console
from rich.panel import Panel
from rich.prompt import IntPrompt, Prompt
from rich.rule import Rule
from rich.table import Table

log = logging.getLogger("reconx.workflows.builder18")

_SAVE_DIR = Path("reconx/data/workflows")

# Tool catalogue grouped by category
_TOOL_CATALOGUE: dict[str, list[tuple[str, str, str]]] = {
    "Passive / OSINT": [
        ("WHOIS",          "WhoisTool",      "Domain registration and ASN lookup"),
        ("theHarvester",   "TheHarvesterTool","Email, hostname, name OSINT"),
        ("SpiderFoot",     "SpiderFootTool", "Automated OSINT framework"),
        ("Subfinder",      "SubfinderTool",  "Passive subdomain enumeration"),
        ("Amass Passive",  "AmassTool",      "Passive subdomain discovery"),
        ("CrtSH",          "CrtshTool",      "Certificate transparency log search"),
        ("GAU",            "GauTool",        "Archive URL mining (Wayback, URLScan)"),
        ("Shodan",         "ShodanTool",     "Internet-wide scan results lookup"),
    ],
    "DNS": [
        ("DNSRecon",       "DNSReconTool",   "DNS record enumeration"),
        ("dnsenum",        "DNSEnumTool",    "DNS host and zone enumeration"),
        ("Fierce",         "FierceTool",     "DNS brute-force and zone transfer"),
        ("AlterX",         "AlterxTool",     "Subdomain permutation generation"),
        ("ShuffleDNS",     "ShuffleDNSTool", "Fast DNS resolution"),
    ],
    "Port Scanning": [
        ("Nmap",           "NmapTool",       "Port scan with service/version detection"),
        ("Masscan",        "MasscanTool",    "Ultra-fast TCP port sweep"),
        ("fping",          "FpingTool",      "ICMP host discovery"),
        ("netdiscover",    "NetdiscoverTool","ARP-based LAN host discovery"),
    ],
    "Web Recon": [
        ("HTTPX",          "HttpxTool",      "HTTP probe with tech detection"),
        ("WhatWeb",        "WhatWebTool",    "Technology fingerprinting"),
        ("WafW00f",        "Wafw00fTool",    "WAF detection"),
        ("Nikto",          "NiktoTool",      "Web server vulnerability scan"),
        ("GoSpider",       "GospiderTool",   "Recursive web crawling"),
        ("Katana",         "KatanaTool",     "JS-aware crawling"),
        ("FeroxBuster",    "FeroxbusterTool","Recursive content discovery"),
        ("Gobuster",       "GobusterTool",   "Directory/DNS brute-force"),
        ("GoWitness",      "GoWitnessTool",  "Screenshot capture"),
        ("EyeWitness",     "EyeWitnessTool", "Web screenshot and reporting"),
    ],
    "API / JS": [
        ("Kiterunner",     "KiterunnerTool", "API route brute-force"),
        ("Arjun",          "ArjunTool",      "HTTP parameter discovery"),
        ("ParamSpider",    "ParamSpiderTool","Parameter mining from archives"),
        ("LinkFinder",     "LinkFinderTool", "JS endpoint extraction"),
        ("SecretFinder",   "SecretFinderTool","JS secret scanning"),
        ("graphw00f",      "Graphw00fTool",  "GraphQL engine fingerprinting"),
    ],
    "Vulnerability": [
        ("Nuclei",         "NucleiTool",     "Template-based vulnerability scanner"),
        ("WPScan",         "WpscanTool",     "WordPress vulnerability scanner"),
        ("testssl.sh",     "TestSSLTool",    "TLS/SSL cipher and config audit"),
        ("TLSX",           "TLSXTool",       "TLS fingerprinting"),
    ],
    "Internal / SMB": [
        ("enum4linux-ng",  "Enum4linuxTool", "SMB/NetBIOS enumeration"),
        ("netexec",        "NetexecTool",    "Windows network authentication testing"),
        ("smbclient",      "SmbclientTool",  "SMB share interaction"),
        ("SNMP scan",      "NmapTool",       "SNMP community string discovery"),
    ],
    "Cloud": [
        ("S3Scanner",      "S3ScannerTool",  "S3 bucket enumeration and access test"),
        ("ASNMap",         "AsnmapTool",     "ASN-to-IP-range mapping"),
        ("CloudFox",       "CloudFoxTool",   "Cloud asset enumeration"),
    ],
}


class WorkflowBuilder18:
    """
    Interactive terminal workflow builder.

    Maintains a mutable step list and renders it in real time.
    """

    def __init__(
        self,
        console: Optional[Console] = None,
        registry: Optional[object] = None,
    ):
        self.console  = console or Console()
        self.registry = registry
        self._steps:  list[dict] = []   # {"tool", "tool_class", "stage", "parallel_group"}
        self._name:   str        = ""

    # ── Entry point ───────────────────────────────────────────────────────────

    def run(self) -> Optional[dict]:
        """Launch the interactive builder.  Returns saved workflow dict or None."""
        self.console.clear()
        self.console.print(Panel(
            "[bold cyan]ReconX Workflow Builder[/]\n"
            "[dim]Compose a custom recon workflow tool by tool.\n"
            "Select categories, add tools, arrange order, then save.[/]",
            border_style="cyan",
            title="[bold]Stage 18 — Workflow Builder[/]",
        ))

        while True:
            self._render_current()
            choice = self._main_menu()

            if choice == "1":
                self._add_from_catalogue()
            elif choice == "2":
                self._remove_step()
            elif choice == "3":
                self._move_step()
            elif choice == "4":
                self._set_parallel()
            elif choice == "5":
                self._preview_chain()
            elif choice == "6":
                return self._save_workflow()
            elif choice == "7":
                self._load_workflow()
            elif choice in ("0", "q", ""):
                self.console.print("[dim]Builder closed.[/]")
                return None

    # ── Menu ──────────────────────────────────────────────────────────────────

    def _main_menu(self) -> str:
        table = Table(box=box.SIMPLE, show_header=False, border_style="dim",
                      padding=(0, 1))
        table.add_column("key",  style="bold cyan",  width=4)
        table.add_column("action", style="bold white", width=22)
        table.add_column("desc",   style="dim")
        rows = [
            ("1", "Add Tool",        "Browse category catalogue and add a tool"),
            ("2", "Remove Step",     "Remove a step by number"),
            ("3", "Move Step",       "Reorder steps (↑/↓)"),
            ("4", "Set Parallel",    "Mark steps to run in parallel"),
            ("5", "Preview Chain",   "Show chain explanation"),
            ("6", "Save Workflow",   "Save as a named workflow JSON"),
            ("7", "Load Workflow",   "Load an existing workflow for editing"),
            ("0", "Back",            "Exit builder"),
        ]
        for k, a, d in rows:
            table.add_row(k, a, d)
        self.console.print(table)
        self.console.print()

        try:
            return Prompt.ask("[bold cyan]Action[/]", default="0").strip()
        except (KeyboardInterrupt, EOFError):
            return "0"

    # ── Add ───────────────────────────────────────────────────────────────────

    def _add_from_catalogue(self) -> None:
        self.console.print()
        self.console.print(Rule("[bold cyan]Add Tool[/]", style="cyan"))

        categories = list(_TOOL_CATALOGUE.keys())
        for i, cat in enumerate(categories, 1):
            self.console.print(f"  [cyan]{i}[/]  {cat}")
        self.console.print()

        try:
            ci = IntPrompt.ask("[cyan]Category #[/]", default=1)
            if not (1 <= ci <= len(categories)):
                return
        except (KeyboardInterrupt, EOFError):
            return

        cat  = categories[ci - 1]
        tools = _TOOL_CATALOGUE[cat]

        table = Table(box=box.SIMPLE_HEAD, border_style="dim cyan",
                      title=f"[bold]{cat}[/]")
        table.add_column("#",     style="cyan dim", width=4)
        table.add_column("Tool",  style="bold white", width=20)
        table.add_column("Description", style="dim")
        for i, (name, cls, desc) in enumerate(tools, 1):
            table.add_row(str(i), name, desc)
        self.console.print(table)
        self.console.print()

        try:
            ti = IntPrompt.ask("[cyan]Tool #[/]", default=1)
            if not (1 <= ti <= len(tools)):
                return
            name, cls, desc = tools[ti - 1]
            stage = IntPrompt.ask("[cyan]Stage (1-5)[/]", default=len(self._stages_used()) + 1 or 1)
            self._steps.append({
                "tool":          name,
                "tool_class":    cls,
                "description":   desc,
                "stage":         stage,
                "parallel_group": None,
            })
            self.console.print(f"[green]✓[/] Added: [bold]{name}[/] (stage {stage})")
        except (KeyboardInterrupt, EOFError):
            pass

    # ── Remove ────────────────────────────────────────────────────────────────

    def _remove_step(self) -> None:
        if not self._steps:
            self.console.print("[dim]No steps to remove.[/]")
            return
        try:
            n = IntPrompt.ask("[cyan]Remove step #[/]", default=len(self._steps))
            if 1 <= n <= len(self._steps):
                removed = self._steps.pop(n - 1)
                self.console.print(f"[yellow]Removed:[/] {removed['tool']}")
        except (KeyboardInterrupt, EOFError):
            pass

    # ── Move ──────────────────────────────────────────────────────────────────

    def _move_step(self) -> None:
        if len(self._steps) < 2:
            return
        try:
            n   = IntPrompt.ask("[cyan]Move step #[/]", default=1)
            dir = Prompt.ask("[cyan]Direction[/] (u=up / d=down)", default="u").lower()
            idx = n - 1
            if not (0 <= idx < len(self._steps)):
                return
            if dir == "u" and idx > 0:
                self._steps[idx], self._steps[idx - 1] = (
                    self._steps[idx - 1], self._steps[idx]
                )
                self.console.print(f"[green]↑[/] Moved '{self._steps[idx - 1]['tool']}' up")
            elif dir == "d" and idx < len(self._steps) - 1:
                self._steps[idx], self._steps[idx + 1] = (
                    self._steps[idx + 1], self._steps[idx]
                )
                self.console.print(f"[green]↓[/] Moved '{self._steps[idx + 1]['tool']}' down")
        except (KeyboardInterrupt, EOFError):
            pass

    # ── Parallel ──────────────────────────────────────────────────────────────

    def _set_parallel(self) -> None:
        if not self._steps:
            return
        self.console.print(
            "[dim]Enter step numbers that should run in parallel (e.g. 2,3,4)[/]"
        )
        try:
            raw   = Prompt.ask("[cyan]Steps[/]", default="").strip()
            label = Prompt.ask("[cyan]Group label[/]", default="parallel_group").strip()
        except (KeyboardInterrupt, EOFError):
            return

        for part in raw.split(","):
            try:
                idx = int(part.strip()) - 1
                if 0 <= idx < len(self._steps):
                    self._steps[idx]["parallel_group"] = label
            except ValueError:
                pass
        self.console.print(f"[green]✓[/] Parallel group '{label}' set.")

    # ── Preview ───────────────────────────────────────────────────────────────

    def _preview_chain(self) -> None:
        if not self._steps:
            self.console.print("[dim]No steps to preview.[/]")
            return
        self.console.print()
        self.console.print(Rule("[bold cyan]Workflow Chain Preview[/]", style="cyan"))
        for i, s in enumerate(self._steps):
            connector = "┌" if i == 0 else ("└" if i == len(self._steps) - 1 else "├")
            par = (f"  [dim cyan][{s['parallel_group']}][/]"
                   if s.get("parallel_group") else "")
            self.console.print(
                f"  {connector}─ [bold white]{s['tool']}[/]"
                f"  [dim]S{s['stage']}[/]{par}"
            )
        self.console.print()
        self.console.print(f"[dim]{len(self._steps)} steps total[/]")
        self._pause()

    # ── Save ──────────────────────────────────────────────────────────────────

    def _save_workflow(self) -> Optional[dict]:
        if not self._steps:
            self.console.print("[red]No steps to save.[/]")
            return None

        try:
            name = Prompt.ask(
                "[cyan]Workflow name[/]",
                default=self._name or f"custom_{int(time.time())}",
            ).strip()
            desc = Prompt.ask("[cyan]Description[/]", default="Custom workflow").strip()
        except (KeyboardInterrupt, EOFError):
            return None

        self._name = name
        data = {
            "name":         name,
            "display_name": name.replace("_", " ").title(),
            "description":  desc,
            "category":     "custom",
            "target_types": [],
            "tags":         ["custom"],
            "estimated_min": len(self._steps) * 3,
            "steps":        [
                {
                    "tool":           s["tool"],
                    "tool_class":     s["tool_class"],
                    "stage":          s["stage"],
                    "parallel_group": s.get("parallel_group"),
                    "skippable":      True,
                    "why_next":       "",
                }
                for s in self._steps
            ],
            "author":  "operator",
            "_saved_at": time.time(),
        }

        _SAVE_DIR.mkdir(parents=True, exist_ok=True)
        path = _SAVE_DIR / f"custom_{name}.json"
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(data, fh, indent=2)
        self.console.print(f"\n[bold green]✓[/] Workflow saved: [bold]{path}[/]")
        return data

    # ── Load ──────────────────────────────────────────────────────────────────

    def _load_workflow(self) -> None:
        files = list(_SAVE_DIR.glob("custom_*.json"))
        if not files:
            self.console.print("[dim]No custom workflows found.[/]")
            return

        for i, f in enumerate(files, 1):
            self.console.print(f"  [cyan]{i}[/]  {f.stem}")
        self.console.print()

        try:
            n = IntPrompt.ask("[cyan]Select #[/]", default=1)
            if not (1 <= n <= len(files)):
                return
            with open(files[n - 1], encoding="utf-8") as fh:
                data = json.load(fh)
            self._name  = data.get("name", "")
            self._steps = [
                {
                    "tool":          s.get("tool", ""),
                    "tool_class":    s.get("tool_class", ""),
                    "description":   "",
                    "stage":         s.get("stage", 1),
                    "parallel_group": s.get("parallel_group"),
                }
                for s in data.get("steps", [])
            ]
            self.console.print(f"[green]✓[/] Loaded: {self._name} ({len(self._steps)} steps)")
        except (KeyboardInterrupt, EOFError, json.JSONDecodeError, OSError):
            pass

    # ── Render current state ──────────────────────────────────────────────────

    def _render_current(self) -> None:
        self.console.print()
        if not self._steps:
            self.console.print(Panel(
                "[dim]No steps added yet.[/]",
                title=f"[bold cyan]Workflow: {self._name or '(unsaved)'}[/]",
                border_style="dim",
            ))
        else:
            table = Table(
                box=box.SIMPLE,
                show_header=True,
                border_style="dim cyan",
                title=f"[bold cyan]Workflow: {self._name or '(unsaved)'}[/]  "
                      f"[dim]{len(self._steps)} steps[/]",
            )
            table.add_column("#",        style="dim cyan", width=4)
            table.add_column("Tool",     style="bold white", width=20)
            table.add_column("Stage",    style="dim cyan",   width=7)
            table.add_column("Parallel", style="dim green",  width=16)
            for i, s in enumerate(self._steps, 1):
                table.add_row(
                    str(i), s["tool"],
                    f"S{s['stage']}",
                    s.get("parallel_group") or "—",
                )
            self.console.print(table)
        self.console.print()

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _stages_used(self) -> set[int]:
        return {s["stage"] for s in self._steps}

    def _pause(self) -> None:
        try:
            Prompt.ask("[dim]Press Enter to continue[/]", default="",
                       console=self.console)
        except (KeyboardInterrupt, EOFError):
            pass
