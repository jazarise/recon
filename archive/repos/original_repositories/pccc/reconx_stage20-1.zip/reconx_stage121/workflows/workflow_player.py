"""
ReconX — Stage 18: Workflow Player.

Replays, resumes, clones, and compares saved WorkflowRunRecords.

CLI commands powered by this module:
    reconx workflow replay  <run_id>
    reconx workflow resume  <run_id>
    reconx workflow clone   <run_id> --target new.example.com
    reconx workflow list
    reconx workflow export  <run_id>
    reconx workflow diff    <run_id_a> <run_id_b>

Usage:
    from reconx.workflows.workflow_player import WorkflowPlayer18

    player = WorkflowPlayer18()
    player.list_runs()                          # print all saved runs
    record = player.replay("run_abc123")        # re-run same target
    record = player.clone("run_abc123", "other.com")
    diff   = player.diff("run_a", "run_b")
"""
from __future__ import annotations

import logging
from typing import Optional

from rich import box
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from .workflow_recorder import WorkflowRecorder18
from .workflow_engine import WorkflowEngine18, WorkflowRunRecord, StepStatus18

log = logging.getLogger("reconx.workflows.player18")


class WorkflowPlayer18:
    """
    Provides replay, resume, clone, list, export, and diff capabilities
    over persisted WorkflowRunRecords.
    """

    def __init__(
        self,
        recorder:  Optional[WorkflowRecorder18] = None,
        engine:    Optional[WorkflowEngine18]   = None,
        console:   Optional[Console]            = None,
        registry:  Optional[object]             = None,
    ):
        self._recorder = recorder or WorkflowRecorder18()
        self._engine   = engine   or WorkflowEngine18(registry=registry)
        self.console   = console  or Console()

    # ── List ──────────────────────────────────────────────────────────────────

    def list_runs(self, limit: int = 20) -> None:
        """Print a Rich table of all saved workflow runs."""
        runs = self._recorder.list_runs(limit)
        if not runs:
            self.console.print("[dim]No saved workflows found.[/]")
            return

        table = Table(
            title      = "Saved Workflow Runs",
            box        = box.SIMPLE_HEAD,
            border_style = "cyan",
        )
        table.add_column("#",          style="dim cyan",  width=4)
        table.add_column("Run ID",     style="dim white", width=26, no_wrap=True)
        table.add_column("Workflow",   style="bold white", width=22)
        table.add_column("Target",     style="cyan",      width=24)
        table.add_column("Status",     width=12)
        table.add_column("Steps",      style="dim",       width=7)
        table.add_column("Duration",   style="dim",       width=9)

        status_styles = {
            "completed":   "bold green",
            "failed":      "bold red",
            "interrupted": "yellow",
        }

        for i, r in enumerate(runs, 1):
            sty     = status_styles.get(r["status"], "dim")
            dur     = f"{r['duration_s']:.0f}s" if r["duration_s"] else "—"
            steps   = f"[green]{r['success']}[/]/[dim]{r['step_count']}[/]"
            table.add_row(
                str(i),
                r["run_id"][-24:],
                r["template_name"][:20],
                r["target"][:22],
                f"[{sty}]{r['status']}[/]",
                steps,
                dur,
            )
        self.console.print(table)

    # ── Replay ────────────────────────────────────────────────────────────────

    def replay(
        self,
        run_id:     str,
        new_target: Optional[str] = None,
    ) -> Optional[WorkflowRunRecord]:
        """
        Re-run all steps from a saved workflow against the same or new target.

        Returns a fresh WorkflowRunRecord.
        """
        original = self._recorder.load(run_id)
        if not original:
            self.console.print(f"[red]Run not found: {run_id}[/]")
            return None

        target = new_target or original.target
        tmpl   = self._template_from_record(original)
        if not tmpl:
            self.console.print("[red]Cannot reconstruct template from saved record.[/]")
            return None

        self.console.print(
            f"[cyan]Replaying[/] '{original.template_name}' → [white]{target}[/]"
        )
        cb     = self._recorder.make_step_callback()
        engine = WorkflowEngine18(
            registry    = self._engine._registry,
            console     = self.console,
            on_step_done = cb,
        )
        record = engine.execute(tmpl, target)
        record.template_name = f"{original.template_name} [replay]"
        self._recorder.save(record)
        return record

    # ── Resume ────────────────────────────────────────────────────────────────

    def resume(self, run_id: str) -> Optional[WorkflowRunRecord]:
        """
        Resume an interrupted run, skipping steps already marked SUCCESS.

        Returns the completed WorkflowRunRecord.
        """
        original = self._recorder.load(run_id)
        if not original:
            self.console.print(f"[red]Run not found: {run_id}[/]")
            return None

        # Count already-done steps
        done_tools = {
            s.tool for s in original.steps if s.status == StepStatus18.SUCCESS
        }
        remaining  = len(original.steps) - len(done_tools)
        self.console.print(
            f"[cyan]Resuming[/] '{original.template_name}' "
            f"— {len(done_tools)} steps done, {remaining} remaining"
        )

        # Reset non-success steps for re-execution
        for sr in original.steps:
            if sr.status != StepStatus18.SUCCESS:
                sr.status      = StepStatus18.WAITING
                sr.error       = ""
                sr.started_at  = 0.0
                sr.finished_at = 0.0

        tmpl = self._template_from_record(original, skip_done=done_tools)
        if not tmpl:
            self.console.print("[red]Cannot reconstruct template.[/]")
            return None

        cb     = self._recorder.make_step_callback()
        engine = WorkflowEngine18(
            registry    = self._engine._registry,
            console     = self.console,
            on_step_done = cb,
        )
        record = engine.execute(tmpl, original.target, run_id=original.run_id)
        self._recorder.save(record)
        return record

    # ── Clone ─────────────────────────────────────────────────────────────────

    def clone(
        self,
        run_id:     str,
        new_target: str,
    ) -> Optional[WorkflowRunRecord]:
        """Clone a saved run and execute against a new target."""
        return self.replay(run_id, new_target=new_target)

    # ── Export ────────────────────────────────────────────────────────────────

    def export(
        self,
        run_id:     str,
        fmt:        str = "json",
        out_path:   Optional[str] = None,
    ) -> None:
        """Export a saved run to JSON or Markdown."""
        try:
            if fmt == "markdown":
                path = self._recorder.export_markdown(run_id, out_path)
            else:
                path = self._recorder.export_json(run_id, out_path)
            self.console.print(f"[green]✓[/] Exported to: [bold]{path}[/]")
        except FileNotFoundError:
            self.console.print(f"[red]Run not found: {run_id}[/]")
        except Exception as exc:
            self.console.print(f"[red]Export failed: {exc}[/]")

    # ── Diff ──────────────────────────────────────────────────────────────────

    def diff(self, run_id_a: str, run_id_b: str) -> dict:
        """
        Compare two saved runs and display differences.

        Returns a summary dict for programmatic use.
        """
        a = self._recorder.load(run_id_a)
        b = self._recorder.load(run_id_b)
        if not a or not b:
            self.console.print("[red]One or both runs not found.[/]")
            return {}

        tools_a = {s.tool: s.status.value for s in a.steps}
        tools_b = {s.tool: s.status.value for s in b.steps}
        all_tools = sorted(set(list(tools_a.keys()) + list(tools_b.keys())))

        table = Table(
            title = f"Diff: {run_id_a[-16:]} vs {run_id_b[-16:]}",
            box   = box.SIMPLE_HEAD,
            border_style = "cyan",
        )
        table.add_column("Tool",    style="bold white", width=22)
        table.add_column("Run A",   width=12)
        table.add_column("Run B",   width=12)
        table.add_column("Change",  width=12)

        changes = []
        for tool in all_tools:
            sa = tools_a.get(tool, "absent")
            sb = tools_b.get(tool, "absent")
            change = "" if sa == sb else f"{'→'}"
            if sa != sb:
                changes.append({"tool": tool, "from": sa, "to": sb})
            style_a = "green" if sa == "success" else ("red" if sa == "failed" else "dim")
            style_b = "green" if sb == "success" else ("red" if sb == "failed" else "dim")
            table.add_row(
                tool,
                f"[{style_a}]{sa}[/]",
                f"[{style_b}]{sb}[/]",
                change,
            )
        self.console.print(table)

        self.console.print(Panel(
            f"Run A: [dim]{run_id_a}[/]  target={a.target}  "
            f"duration={a.duration_s:.0f}s  finds={a.total_findings}\n"
            f"Run B: [dim]{run_id_b}[/]  target={b.target}  "
            f"duration={b.duration_s:.0f}s  finds={b.total_findings}\n"
            f"Changed steps: [bold]{len(changes)}[/]",
            border_style="dim",
        ))

        return {
            "run_a":   run_id_a,
            "run_b":   run_id_b,
            "changes": changes,
            "finds_delta": b.total_findings - a.total_findings,
            "duration_delta_s": b.duration_s - a.duration_s,
        }

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _template_from_record(
        self,
        record: WorkflowRunRecord,
        skip_done: Optional[set] = None,
    ):
        """Reconstruct a minimal WorkflowTemplate from a saved run record."""
        try:
            from .workflow_templates import WorkflowTemplate, TemplateStep
        except ImportError:
            return None

        skip_done = skip_done or set()
        steps = []
        for sr in record.steps:
            if sr.tool in skip_done:
                continue
            steps.append(TemplateStep(
                tool       = sr.tool,
                tool_class = sr.tool_class,
                stage      = sr.stage,
            ))

        if not steps:
            return None

        return WorkflowTemplate(
            name         = record.template_name,
            display_name = record.template_name,
            description  = f"Reconstructed from run {record.run_id}",
            category     = "general",
            target_types = [],
            tags         = [],
            steps        = steps,
        )
