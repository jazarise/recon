"""
ReconX — Stage 18 Report Extension: Workflow Intelligence Section.

Injects a workflow execution timeline and AI recommendations section
into HTML reports.  Reads from WorkflowRunRecord.to_dict().

Sections added:
  1. Workflow Summary        — template, target, status, duration
  2. Execution Timeline      — step-by-step with colour-coded status
                               and duration bars
  3. AI Recommendations      — DecisionEngine findings with commands

Usage:
    from reconx.workflows.report_18 import inject_workflow_section18

    inject_workflow_section18(
        html_path = "reports/reconx_example_com.html",
        run_record = workflow_run_record.to_dict(),
    )
"""
from __future__ import annotations

from html import escape
from pathlib import Path


# ─────────────────────────────────────────────────────────────────────────────
# CSS
# ─────────────────────────────────────────────────────────────────────────────

_WF18_CSS = """
/* ── Stage 18 Workflow Section ───────────────────── */
.wf18-meta-pills {
  display: flex; gap: 10px; flex-wrap: wrap; margin: 16px 0 24px;
}
.wf18-pill {
  padding: 4px 14px; border-radius: 20px; font-size: 11px; letter-spacing: 1px;
  background: var(--bg3); border: 1px solid var(--border);
  color: var(--dim);
}
.wf18-pill span { color: var(--text); font-weight: 600; margin-left: 4px; }
.wf18-timeline { display: flex; flex-direction: column; gap: 5px; margin-top: 16px; }
.wf18-step {
  display: grid;
  grid-template-columns: 28px 200px 60px 1fr 70px 60px;
  gap: 8px; align-items: center;
  padding: 6px 10px;
  background: var(--bg3); border: 1px solid var(--border); border-radius: 5px;
  font-size: 12px;
}
.wf18-step:hover { border-color: var(--accent); }
.wf18-step.success { border-left: 3px solid #30d158; }
.wf18-step.failed  { border-left: 3px solid #ff2d55; }
.wf18-step.skipped { border-left: 3px solid #5a7a9a; opacity: .7; }
.wf18-icon-SUCCESS  { color: #30d158; font-weight: 700; }
.wf18-icon-FAILED   { color: #ff2d55; font-weight: 700; }
.wf18-icon-SKIPPED  { color: #5a7a9a; }
.wf18-icon-WAITING  { color: #5a7a9a; }
.wf18-bar-wrap {
  height: 5px; background: rgba(255,255,255,.05); border-radius: 3px; overflow: hidden;
}
.wf18-bar-success { height: 100%; background: #30d158; border-radius: 3px; }
.wf18-bar-failed  { height: 100%; background: #ff2d55; border-radius: 3px; }
.wf18-dur { color: var(--dim); font-size: 11px; }
.wf18-finds { color: var(--accent); font-size: 11px; font-weight: 600; }
/* Recommendations */
.wf18-rec-card {
  background: var(--bg3); border: 1px solid var(--border);
  border-left: 3px solid var(--accent); border-radius: 0 6px 6px 0;
  padding: 14px 18px; margin-bottom: 10px;
}
.wf18-rec-label { font-weight: 600; color: var(--text); margin-bottom: 6px; }
.wf18-rec-ctx { color: var(--dim); font-size: 12px; margin-bottom: 10px; }
.wf18-rec-sev-CRITICAL { color: #ff2d55; font-weight: 700; font-size: 11px; }
.wf18-rec-sev-HIGH     { color: #ff6b35; font-weight: 600; font-size: 11px; }
.wf18-rec-sev-MEDIUM   { color: #ffd60a; font-size: 11px; }
.wf18-rec-sev-INFO     { color: #5a7a9a; font-size: 11px; }
.wf18-cmd-block {
  background: var(--bg2); border: 1px solid var(--border); border-radius: 4px;
  padding: 8px 12px; margin-top: 8px;
  font-family: var(--font-mono); font-size: 11.5px; color: #30d158;
}
.wf18-suggestions { display: flex; flex-wrap: wrap; gap: 8px; margin-top: 8px; }
.wf18-sug-pill {
  background: rgba(0,212,255,.08); border: 1px solid rgba(0,212,255,.25);
  color: var(--accent); border-radius: 4px;
  padding: 3px 10px; font-size: 11px; font-family: var(--font-mono);
}
"""


# ─────────────────────────────────────────────────────────────────────────────
# Renderers
# ─────────────────────────────────────────────────────────────────────────────

def _render_summary(run: dict) -> str:
    name     = escape(run.get("template_name", "?"))
    target   = escape(run.get("target", "?"))
    status   = run.get("status", "?")
    dur      = run.get("duration_s", 0)
    success  = run.get("success_count", 0)
    failed   = run.get("failed_count", 0)
    total    = len(run.get("steps", []))
    dur_str  = f"{dur:.1f}s" if dur < 60 else f"{dur/60:.1f}m"

    status_colour = {
        "completed": "#30d158", "failed": "#ff2d55", "interrupted": "#ff6b35"
    }.get(status, "#5a7a9a")

    return f"""
<div class="wf18-meta-pills">
  <div class="wf18-pill">Workflow <span>{name}</span></div>
  <div class="wf18-pill">Target <span>{target}</span></div>
  <div class="wf18-pill">Status <span style="color:{status_colour}">{escape(status.upper())}</span></div>
  <div class="wf18-pill">Duration <span>{dur_str}</span></div>
  <div class="wf18-pill">Steps
    <span style="color:#30d158">{success} ✓</span> /
    <span style="color:#ff2d55">{failed} ✗</span> /
    <span style="color:#5a7a9a">{total} total</span>
  </div>
</div>"""


def _render_timeline(run: dict) -> str:
    steps = run.get("steps", [])
    if not steps:
        return "<p class='dim'>No steps recorded.</p>"

    durations = [s.get("duration_s", 0) for s in steps]
    max_dur   = max(durations) if durations else 1.0

    icons = {
        "success":  ("✓", "wf18-icon-SUCCESS", "success"),
        "failed":   ("✗", "wf18-icon-FAILED",  "failed"),
        "skipped":  ("○", "wf18-icon-SKIPPED",  "skipped"),
        "waiting":  ("⏳","wf18-icon-WAITING",  ""),
        "running":  ("⚡","wf18-icon-RUNNING",   ""),
        "cancelled":("—", "wf18-icon-SKIPPED",  "skipped"),
    }

    rows = ""
    for s in steps:
        status    = s.get("status", "waiting")
        tool      = escape(s.get("tool", "?"))
        stage     = s.get("stage", 1)
        dur       = s.get("duration_s", 0)
        finds     = s.get("finding_count", 0)
        error     = s.get("error", "")
        bar_pct   = int((dur / max_dur) * 100) if max_dur > 0 else 0
        dur_str   = f"{dur:.2f}s" if dur > 0 else "—"
        icon, icon_cls, row_cls = icons.get(status, ("?", "", ""))
        bar_cls   = "wf18-bar-success" if status == "success" else "wf18-bar-failed"

        finds_html = f'<span class="wf18-finds">{finds}</span>' if finds else '<span class="dim">—</span>'
        err_html   = (f'<div style="grid-column:1/-1;font-family:var(--font-mono);'
                      f'font-size:10.5px;color:#ff6b80;padding-top:2px">✗ {escape(error[:120])}</div>'
                      if error else "")

        rows += f"""
<div class="wf18-step {row_cls}">
  <span class="{icon_cls}">{icon}</span>
  <span class="mono">{tool}</span>
  <span class="dim">S{stage}</span>
  <div class="wf18-bar-wrap"><div class="{bar_cls}" style="width:{bar_pct}%"></div></div>
  <span class="wf18-dur">{dur_str}</span>
  {finds_html}
  {err_html}
</div>"""

    return f'<div class="wf18-timeline">{rows}</div>'


def _render_recommendations(run: dict) -> str:
    recs = run.get("recommendations", [])
    if not recs:
        return ""

    cards = ""
    for rec in recs[:8]:
        label   = escape(rec.get("label", "?"))
        ctx     = escape(rec.get("context", ""))
        sev     = rec.get("severity", "INFO")
        sev_cls = f"wf18-rec-sev-{sev}"
        sug_pills = " ".join(
            f'<span class="wf18-sug-pill">{escape(s.get("tool","?"))}</span>'
            for s in rec.get("suggestions", [])[:4]
        )
        # First command from first suggestion
        cmds = (rec.get("suggestions", [{}])[0] or {}).get("commands", [])
        cmd_html = ""
        if cmds:
            cmd_html = "<div class='wf18-cmd-block'>" + "<br>".join(
                f"$ {escape(c)}" for c in cmds[:2]
            ) + "</div>"

        cards += f"""
<div class="wf18-rec-card">
  <div class="wf18-rec-label">
    <span class="{sev_cls}">[{sev}]</span>  {label}
  </div>
  <div class="wf18-rec-ctx">{ctx}</div>
  <div class="wf18-suggestions">{sug_pills}</div>
  {cmd_html}
</div>"""

    return f"""
<section class="report-section">
  <h2 class="section-title">🤖 AI Recommendations</h2>
  <p class="dim" style="margin-bottom:16px">
    Based on findings, these tools are recommended for the next phase.
  </p>
  {cards}
</section>"""


# ─────────────────────────────────────────────────────────────────────────────
# Public API
# ─────────────────────────────────────────────────────────────────────────────

def inject_workflow_section18(
    html_path:  str,
    run_record: dict,
) -> bool:
    """
    Inject Stage 18 workflow timeline and recommendations into an HTML report.

    Args:
        html_path:  Path to existing HTML report.
        run_record: WorkflowRunRecord.to_dict() output.

    Returns True on success.
    """
    p = Path(html_path)
    if not p.exists():
        return False

    content = p.read_text(encoding="utf-8")

    if "wf18-timeline" not in content:
        content = content.replace(
            "</head>",
            f"<style>{_WF18_CSS}</style>\n</head>",
            1,
        )

    full_section = f"""
<section class="report-section" id="workflow18">
  <h2 class="section-title">⚡ Workflow Execution</h2>
  {_render_summary(run_record)}
  <h3 style="font-size:12px;letter-spacing:2px;text-transform:uppercase;
             color:var(--dim);margin:20px 0 8px">Step Timeline</h3>
  {_render_timeline(run_record)}
</section>
{_render_recommendations(run_record)}
"""

    if "<!-- workflow18-section -->" in content:
        content = content.replace("<!-- workflow18-section -->", full_section, 1)
    elif "<!-- workflow-section -->" in content:
        content = content.replace("<!-- workflow-section -->", full_section, 1)
    elif "</body>" in content:
        content = content.replace("</body>", f"{full_section}\n</body>", 1)
    else:
        content += full_section

    p.write_text(content, encoding="utf-8")
    return True
