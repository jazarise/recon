# ReconX — Stage 20 Changelog: Protocol & Service Analysis Engine

## Overview

Stage 20 builds an Intelligent Protocol & Service Analysis Engine that
automatically identifies, classifies, enriches, and risk-scores every service
discovered by any scanner. It acts as a smart interpretation layer between raw
scanner output and actionable intelligence.

**Before Stage 20:** ReconX received raw port/service data and stored it as-is.
**After Stage 20:** Every service is fingerprinted, protocol-classified, risk-scored,
enriched with attack vectors, misconfig patterns, and enumeration paths, and
assembled into a structured `ServiceIntelligenceReport`.

---

## New Files (11)

### `analysis/protocol/models.py` — Data Models

| Model | Purpose |
|---|---|
| `ServiceRecord` | One enriched service: host, port, protocol, classification, fingerprints, risk signals, TLS context, AI analysis |
| `ProtocolClassification` | Protocol detected with family, confidence, method, encrypted flag |
| `FingerprintResult` | One fingerprint match (banner/header/TLS/version/port) |
| `RiskSignal` | One risk indicator with severity, evidence, optional CVE |
| `ServiceAnalysis` | Full AI analysis: beginner summary, technical summary, risk score, attack vectors, misconfig patterns, enumeration paths |
| `ServiceIntelligenceReport` | Full target report with aggregated counts, executive summary, suggested actions |
| `ScanParseResult` | Normalised output from any parser |
| `EnumerationPath` | One suggested next-step with tool, command, purpose, priority |
| `ProtocolFamily` | WEB / NETWORK / DATABASE / CLOUD / MAIL / FILE / REMOTE / DIRECTORY / MESSAGING |
| `ServiceRisk` | CRITICAL / HIGH / MEDIUM / LOW / INFO |
| `FingerprintMethod` | BANNER / HEADER / TLS / BEHAVIOR / VERSION / PORT |

`ServiceRecord.risk_level` — computed from highest-severity risk signal.
`ServiceRecord.protocol_name` — prefers classification, falls back to service_name.
`ServiceIntelligenceReport.compute_counts()` — recomputes all aggregated stats.
`ServiceIntelligenceReport.to_dict()` — fully JSON-serialisable.

---

### `analysis/protocol/knowledge_base.py` — Protocol Knowledge Database

Local static knowledge database — no network, no external dependencies.

**`PORT_DB`** — 60+ port → `PortEntry` mappings covering:
- Remote access: FTP(21), SSH(22), Telnet(23), RDP(3389), VNC(5900)
- Web: HTTP(80), HTTPS(443), HTTP-alt(8080/8443/8000/3000/8888/9000)
- Mail: SMTP(25), POP3(110), IMAP(143), and TLS variants
- Network: DNS(53), SNMP(161), LDAP(389), SMB(445), NFS(2049), Kerberos(88)
- Databases: MySQL(3306), PostgreSQL(5432), MSSQL(1433), MongoDB(27017), Redis(6379), Elasticsearch(9200/5601), Cassandra(9042), Memcached(11211), CouchDB(5984), InfluxDB(8086), ZooKeeper(2181)
- Messaging: MQTT(1883), AMQP(5672), RabbitMQ-mgmt(15672), Kafka(9092)
- Cloud: Docker(2375/2376), Kubernetes(6443), Kubelet(10250/10255), etcd

**`SERVICE_DB`** — 15 deep `ServiceEntry` records with:
- Beginner explanation (plain English)
- Attack vectors (offensive context for defenders)
- Misconfig patterns (what to check)
- Enumeration commands (tool + command + purpose, with `{host}/{port}` templating)
- CVE pattern references
- Risk baseline

Services covered: Redis, MongoDB, Elasticsearch, SMB, FTP, SSH, Telnet, RDP, SNMP, MySQL, LDAP, Docker, Kubernetes, HTTP, HTTPS.

`lookup_port(port)` / `lookup_service(name)` — public API with case-insensitive aliases.

---

### `analysis/protocol/parsers.py` — Scanner Output Parsers

Normalises raw output from 5 scanners + generic fallback into `ServiceRecord` lists.

| Parser | Input formats | Detection |
|---|---|---|
| `NmapParser` | XML (-oX), Grepable (-oG), Normal (-oN) | Auto-detected from content |
| `RustscanParser` | JSON, plain `Open ip:port`, embedded Nmap | Auto-detected |
| `NaabuParser` | JSONL, plain `ip:port`, `ip:port/proto` | Auto-detected |
| `MasscanParser` | JSON (-oJ), List (-oL), XML (-oX) | Auto-detected |
| `HTTPXParser` | JSON lines (-json flag) | Parses URL, status, TLS, tech |
| `GenericParser` | Any text with port-like patterns | Regex fallback |

All parsers: never raise, all errors go to `ScanParseResult.parse_errors`, `source_tool` always set.

`parse_scan_output(raw, tool_name, host)` — convenience one-liner.
`get_parser(tool_name)` — returns the right parser, falls back to `GenericParser`.

---

### `analysis/protocol/detection_engine.py` — Protocol Detection Engine

Classifies the protocol running on each port via three methods in priority order:

**1. Banner signature matching (confidence 0.90–0.99)**
40 regex patterns covering: SSH, HTTP, HTTP/2, WebSocket, Telnet, RDP, VNC, SMTP, POP3, IMAP, FTP, SMB, NFS, DNS, SNMP, LDAP, MySQL, PostgreSQL, MSSQL, Oracle, MongoDB, Redis, Elasticsearch, Cassandra, Memcached, CouchDB, InfluxDB, ZooKeeper, MQTT, AMQP, Kafka, Docker, Kubernetes, Kubelet, etcd.

**2. Service version string matching (confidence 0.88)**
50-entry name map covering all major protocols and Nmap service name variants (e.g. `microsoft-ds` → SMB, `ms-wbt-server` → RDP).

**3. Port knowledge base heuristic (confidence 0.72)**
Fallback using `PORT_DB` — lower confidence since no payload evidence.

`classify(record)` → `ProtocolClassification`
`classify_all(records)` → mutates records in place, sets `.classification` and `.fingerprints`.
`_fingerprint(record)` → `list[FingerprintResult]` — banner, version, TLS signals.

---

### `analysis/protocol/service_analyzer.py` — Service Analyzer

Produces `ServiceAnalysis` using static rules + optional AI enrichment.

**Static rule engine (always runs):**

Risk signals detected:
| Signal | Trigger | Severity |
|---|---|---|
| `cleartext_protocol` | Protocol in cleartext set | HIGH |
| `no_auth_known` | Service in `_ALWAYS_HIGH_RISK` set | CRITICAL |
| `non_default_port` | Non-standard port for classified protocol | LOW |
| `expired_cert` | `record.tls_cert_expired == True` | MEDIUM |
| `legacy_tls` | TLS version < 1.2 | HIGH |
| `database_exposed` | Protocol family == DATABASE | CRITICAL |
| `cloud_api_exposed` | Protocol family == CLOUD | HIGH |

Risk scoring (0.0–10.0):
- Sum of `_RISK_WEIGHTS` per signal type
- KB baseline bonus for CRITICAL/HIGH-baseline services (+3.0)
- Capped at 10.0

Risk thresholds: ≥8.0 CRITICAL · ≥6.0 HIGH · ≥3.5 MEDIUM · ≥1.0 LOW.

**AI enrichment layer (optional, graceful fallback):**
Calls existing `ExplanationEngine` with a structured prompt. Falls back silently if AI unavailable. Enriches `beginner_summary`, `technical_summary`, and `enumeration_paths`.

`analyze_all(records, target)` → `ServiceIntelligenceReport` with executive summary and suggested actions.

---

### `analysis/protocol/engine.py` — Service Intelligence Engine

Top-level pipeline orchestrator.

```
Scanner Output
  ↓ parse_scan_output()
ServiceRecord list (raw)
  ↓ ProtocolDetectionEngine.classify_all()
ServiceRecord list (classified + fingerprinted)
  ↓ ServiceAnalyzer.analyze_all()
ServiceIntelligenceReport
```

**Deduplication guard:** removes duplicate `(host, port, protocol)` tuples before analysis — prevents infinite loop if scanner is called twice.

**Cache:** `_cache[target] = report` — `get_cached(target)` returns existing report.

**Scanned registry:** `already_scanned(target)` / `mark_scanned(target)` — prevents excessive retries.

**ReconResult integration:** `enrich_recon_result(recon_result, report)` — non-destructively attaches Stage 20 findings and sensitive findings to existing ReconResult objects.

**Structured logging:** `get_log_entries(report)` → `list[dict]` with timestamp / tool / host / service / version / risk / ai_notes.

---

### `analysis/protocol/report_injector.py` — HTML Report Injector

Injects a "Service Intelligence" section into existing ReconX HTML reports.
Can also create a standalone dark-theme HTML report.

**7 sections:**
1. Summary bar — target, total services, critical/high/medium counts
2. Stats row — 7 metric cards (Services, Critical, High, Medium, Low, Databases, Cloud)
3. Services table — sorted by risk, risk badge, host, port/proto, protocol, family, version, score bar
4. Risk signals table — all flagged misconfigs sorted by severity
5. AI Analysis cards — top 5 high-risk services with beginner summary + attack vectors
6. Enumeration paths table — tool, service, command, purpose
7. Executive summary — plain text

`inject_service_section(html_path, data, create_if_missing=False)` — idempotent CSS injection, safe to call multiple times.

---

### `tui/views/service_intelligence_view.py` — TUI Panel

Rich-rendered Service Intelligence panel with:
- Status header with target and executive summary
- 7-card stats row
- Services table (sorted by risk, up to 40 rows)
- Risk signals table (up to 20 rows)
- AI Analysis cards for top high-risk services
- Enumeration paths table with suggested actions

`render_service_intelligence(console, report)` — standalone helper.

---

### `cli/services_commands.py` — CLI Commands

```bash
reconx services analyze <file>                    Full pipeline from scanner file
reconx services analyze <file> --tool nmap        Specify parser
reconx services analyze <file> --host 10.0.0.1    Provide target context
reconx services analyze <file> --no-ai            Skip AI enrichment
reconx services info <host> <port>                Knowledge base lookup for a port
reconx services report <file>                     Analyze + generate HTML report
reconx services report <file> --output my.html    Custom output path
reconx services kb                                Browse service knowledge base
reconx services kb redis                          Search knowledge base
```

---

## Test Suite

### `tests/test_stage20_services.py` — 69 tests, 10 classes

**Results: 69/69 passing (0.20s)**

| Class | Tests | Coverage |
|---|---|---|
| `TestModels` | 8 | ServiceRecord properties, risk_level computation, to_dict, ScanParseResult defaults |
| `TestKnowledgeBase` | 9 | Port lookups, service lookups, case-insensitive aliases, SERVICE_DB completeness |
| `TestNmapParser` | 8 | XML (open/closed filter, service version, source_tool), grepable, normal, empty, malformed |
| `TestRustscanParser` | 4 | Plain open format, JSON, source_tool, embedded Nmap delegation |
| `TestNaabuParser` | 3 | Plain ip:port, JSON lines, source_tool |
| `TestMasscanParser` | 3 | List format, JSON format, source_tool |
| `TestHTTPXParser` | 3 | HTTP JSON line, HTTPS+TLS, source_tool |
| `TestProtocolDetectionEngine` | 10 | SSH/Redis/HTTP/MySQL banner, service name version string, port heuristic, unknown port, classify_all, TLS KB check, Elasticsearch |
| `TestServiceAnalyzer` | 11 | Redis critical, attack vectors, enum paths, SSH low risk, Telnet high risk, beginner summary, analyze_all, executive summary, suggested actions, risk rationale, to_dict |
| `TestServiceIntelligenceEngine` | 10 | Full pipeline Nmap XML, Redis high risk, dedup, already_scanned, cache, clear_cache, empty output, log entries, to_dict full pipeline, empty records |

---

## Combined Results: All Stages

| Stage | Feature | Tests | Status |
|---|---|---|---|
| 18 / 18.1 | Burp Intelligence Layer | 77 | ✓ all pass |
| 18.2 | Traffic Intelligence Layer | 87 | ✓ all pass |
| 19 | Plugin SDK Foundation | 70 + 11 skip | ✓ all pass |
| 20 | Service Intelligence Engine | 69 | ✓ all pass |
| **Total** | | **303 passed · 11 skipped · 0 failures** | |

---

## Architecture

```
reconx/
└── analysis/protocol/
    ├── __init__.py              Public package API
    ├── models.py                ServiceRecord · ServiceAnalysis · ServiceIntelligenceReport · ...
    ├── knowledge_base.py        PORT_DB (60+ ports) · SERVICE_DB (15 services)
    ├── parsers.py               Nmap · Rustscan · Naabu · Masscan · HTTPX · Generic
    ├── detection_engine.py      40 banner sigs · 50 name mappings · port heuristic
    ├── service_analyzer.py      Static rules · risk scoring · AI enrichment
    ├── engine.py                Pipeline orchestrator · dedup · cache · logging
    └── report_injector.py       HTML injection + standalone report

Supporting:
  tui/views/service_intelligence_view.py   Rich TUI panel
  cli/services_commands.py                 CLI subcommand dispatcher
```

---

## Workflow Integration

```
Discovery (passive recon)
    ↓
Port Detection (Nmap/Rustscan/Naabu/Masscan)
    ↓ parse_scan_output(raw, "nmap", host)
Service Identification (ProtocolDetectionEngine)
    ↓ classify_all(records)
AI Analysis (ServiceAnalyzer + static rules + optional LLM)
    ↓ analyze_all(records, target)
Results Database (ServiceIntelligenceReport.to_dict())
    ↓
ReconResult enrichment / HTML Report / TUI Panel
```

---

## Safety Rules

| Rule | Implementation |
|---|---|
| No exploit code | All analysis is educational/advisory only |
| No duplicate scans | `already_scanned()` + `dedup()` guard |
| No infinite loops | Dedup + cache prevent re-analysis |
| No malformed output crashes | Every parser try-caught, errors in `parse_errors` |
| Non-destructive enrichment | `enrich_recon_result()` appends, never overwrites |
| AI failure is non-fatal | `_ai_enrich()` returns None on any exception |
| Backward compatible | Zero existing files modified |
