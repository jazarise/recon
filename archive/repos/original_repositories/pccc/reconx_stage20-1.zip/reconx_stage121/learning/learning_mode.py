"""
ReconX — Learning Mode Engine (Stage 12.1 expansion).

Renders interactive tool lessons in the terminal using Rich.
Supports three interaction modes per tool:
  [1] Learn    — read description, how it works, use cases, errors
  [2] Examples — browse and copy example commands
  [3] Practice — dry-run the tool with safe defaults (no live network traffic)

Category structure (Stage 12.1):
  Passive Recon | Active Recon | DNS | Network Discovery | Web Recon | Frameworks | Utilities
"""
from __future__ import annotations
import shlex
import time
from typing import Optional

from rich.columns import Columns
from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.prompt import Prompt, IntPrompt
from rich.rule import Rule
from rich.table import Table
from rich import box

from ..knowledge.tools.stage121_catalog import (
    ALL_TOOL_KNOWLEDGE,
    CATEGORY_ORDER,
    ToolKnowledge,
    get_by_category,
    get_by_name,
    search,
)


console = Console()


# ─────────────────────────────────────────────────────────────────────────────
# Rendering helpers
# ─────────────────────────────────────────────────────────────────────────────

def _header(text: str, subtitle: str = "") -> None:
    console.print()
    console.print(Rule(f"[bold cyan]{text}[/]", style="dim cyan"))
    if subtitle:
        console.print(f"[dim]{subtitle}[/]", justify="center")
    console.print()


def _tool_card(tool: ToolKnowledge) -> Panel:
    flags = []
    if tool.passive:
        flags.append("[green]PASSIVE[/]")
    else:
        flags.append("[yellow]ACTIVE[/]")
    if tool.requires_root:
        flags.append("[red]ROOT[/]")

    body = (
        f"[bold white]{tool.description}[/]\n\n"
        f"[dim]Category:[/] [cyan]{tool.category}[/]  "
        + "  ".join(flags)
    )
    return Panel(
        body,
        title=f"[bold cyan]{tool.name}[/]",
        border_style="cyan",
        padding=(1, 2),
    )


def _use_cases_table(tool: ToolKnowledge) -> Table:
    t = Table(box=box.SIMPLE, show_header=False, border_style="dim")
    t.add_column("", style="dim cyan", width=3)
    t.add_column("Use Case")
    for i, uc in enumerate(tool.use_cases, 1):
        t.add_row(f"{i}.", uc)
    return t


def _commands_panel(tool: ToolKnowledge) -> Panel:
    cmds = "\n".join(
        f"[bold cyan]$[/] [white]{cmd}[/]"
        for cmd in tool.example_commands
    )
    return Panel(cmds, title="[bold]Example Commands[/]", border_style="dim cyan",
                 padding=(1, 2))


def _errors_table(tool: ToolKnowledge) -> Table:
    t = Table(box=box.ROUNDED, border_style="dim", show_header=True,
              header_style="bold dim")
    t.add_column("Error",    style="red",   width=40)
    t.add_column("Solution", style="green")
    for err in tool.common_errors:
        t.add_row(err["error"], err["solution"])
    return t


def _workflow_path(tool: ToolKnowledge) -> str:
    steps = tool.typical_workflow
    if not steps:
        return ""
    parts = []
    for i, s in enumerate(steps):
        if s == tool.name:
            parts.append(f"[bold cyan underline]{s}[/]")
        else:
            parts.append(f"[dim]{s}[/]")
    return " → ".join(parts)


def _integrations_chips(tool: ToolKnowledge) -> str:
    return "  ".join(
        f"[bold cyan on #0c1420] {t} [/]"
        for t in tool.integrations
    )


# ─────────────────────────────────────────────────────────────────────────────
# Tool lesson view
# ─────────────────────────────────────────────────────────────────────────────

def show_tool_lesson(tool: ToolKnowledge) -> None:
    """Full interactive lesson for a single tool."""
    console.clear()
    _header(tool.name, tool.category)

    console.print(_tool_card(tool))

    # How it works
    console.print(Panel(
        tool.how_it_works,
        title="[bold]How It Works[/]",
        border_style="dim",
        padding=(1, 2),
    ))

    # Use cases
    console.print("[bold cyan]Use Cases[/]")
    console.print(_use_cases_table(tool))
    console.print()

    # Typical workflow
    wf = _workflow_path(tool)
    if wf:
        console.print("[bold cyan]Typical Workflow[/]")
        console.print(f"  {wf}")
        console.print()

    # Related tools
    if tool.integrations:
        console.print("[bold cyan]Works Well With[/]")
        console.print(f"  {_integrations_chips(tool)}")
        console.print()

    # Install
    console.print("[bold cyan]Installation[/]")
    console.print(Panel(
        f"[white]{tool.install}[/]",
        border_style="dim",
        padding=(0, 2),
    ))

    # Sub-menu
    console.print()
    console.print("[1] Example Commands   [2] Common Errors   [3] Practice Mode   [0] Back",
                  style="dim cyan")
    choice = Prompt.ask("", choices=["0", "1", "2", "3"], default="0")

    if choice == "1":
        console.print(_commands_panel(tool))
        Prompt.ask("\n[dim]Press Enter to continue[/]", default="")
        show_tool_lesson(tool)

    elif choice == "2":
        console.print("[bold]Common Errors & Solutions[/]")
        console.print(_errors_table(tool))
        Prompt.ask("\n[dim]Press Enter to continue[/]", default="")
        show_tool_lesson(tool)

    elif choice == "3":
        run_practice_mode(tool)


# ─────────────────────────────────────────────────────────────────────────────
# Practice mode — dry-run simulation
# ─────────────────────────────────────────────────────────────────────────────

def run_practice_mode(tool: ToolKnowledge) -> None:
    """
    Safe practice mode: shows what the tool would run without executing it.
    For selected tools, runs with --help or a version flag to prove installation.
    """
    console.clear()
    _header(f"Practice Mode — {tool.name}", "No live network traffic generated")

    console.print(f"[dim]Tool binary:[/] [cyan]{tool.name.lower()}[/]")
    console.print()

    # Show a practice command (first example)
    if tool.example_commands:
        ex = tool.example_commands[0]
        console.print(Panel(
            f"[bold cyan]$[/] [white]{ex}[/]\n\n"
            f"[dim]↳ This command would {_humanise_command(ex)}[/]",
            title="[bold]Practice Command[/]",
            border_style="cyan",
            padding=(1, 2),
        ))

    # Check if the binary is actually installed
    import shutil
    binary = _get_binary_name(tool.name)
    installed = shutil.which(binary) is not None

    if installed:
        console.print(f"\n[bold green]✓ {tool.name} is installed[/] at [cyan]{shutil.which(binary)}[/]")
        console.print("[dim]Run with --help to explore options:[/]")
        console.print(f"[bold cyan]$[/] [white]{binary} --help[/]")
    else:
        console.print(f"\n[bold yellow]⚠ {tool.name} is not installed[/]")
        console.print(Panel(
            tool.install,
            title="[bold]Install Command[/]",
            border_style="yellow",
            padding=(0, 2),
        ))

    if tool.reference_url:
        console.print(f"\n[dim]Reference:[/] [cyan]{tool.reference_url}[/]")

    console.print()
    Prompt.ask("[dim]Press Enter to return[/]", default="")
    show_tool_lesson(tool)


def _humanise_command(cmd: str) -> str:
    """Return a plain English description of what a command does."""
    low = cmd.lower()
    if "theharvester" in low:  return "harvest emails and subdomains from public OSINT sources"
    if "sfcli" in low:         return "run SpiderFoot automated OSINT collection"
    if "usufy" in low:         return "check username existence across 300+ platforms"
    if "sublist3r" in low:     return "enumerate subdomains passively via search engines"
    if "dnsenum" in low:       return "enumerate DNS records and attempt zone transfers"
    if "dnsrecon" in low:      return "perform comprehensive DNS record enumeration"
    if "fierce" in low:        return "discover subdomains and adjacent IP ranges via DNS"
    if "netdiscover" in low:   return "discover live hosts via ARP on the local network"
    if "fping" in low:         return "sweep a network range with ICMP host-alive probes"
    if "dirb" in low:          return "brute-force hidden web directories and files"
    if "feroxbuster" in low:   return "recursively discover web content with fast multi-threading"
    if "eyewitness" in low:    return "take screenshots of discovered web services"
    if "msfconsole" in low:    return "run safe Metasploit auxiliary enumeration modules"
    if "nc" in low or "ncat" in low: return "grab service banners via TCP connection"
    return "perform reconnaissance against the target"


def _get_binary_name(tool_name: str) -> str:
    mapping = {
        "theHarvester":      "theHarvester",
        "SpiderFoot":        "sfcli",
        "OSRFramework":      "usufy",
        "Maltego":           "maltego",
        "dnsenum":           "dnsenum",
        "dnsrecon":          "dnsrecon",
        "fierce":            "fierce",
        "Sublist3r":         "sublist3r",
        "netdiscover":       "netdiscover",
        "fping":             "fping",
        "DirBuster / dirb":  "dirb",
        "feroxbuster":       "feroxbuster",
        "EyeWitness":        "eyewitness",
        "Metasploit Auxiliary": "msfconsole",
        "NetcatWrapper":     "nc",
    }
    return mapping.get(tool_name, tool_name.lower().split()[0])


# ─────────────────────────────────────────────────────────────────────────────
# Category browser
# ─────────────────────────────────────────────────────────────────────────────

def show_category(category: str) -> None:
    tools = get_by_category(category)
    if not tools:
        console.print(f"[yellow]No tools found for category: {category}[/]")
        return

    console.clear()
    _header(category, f"{len(tools)} tool(s) available")

    table = Table(box=box.ROUNDED, border_style="cyan", show_header=True,
                  header_style="bold dim")
    table.add_column("#",       width=4,  justify="right", style="dim")
    table.add_column("Tool",    width=22, style="bold white")
    table.add_column("Type",    width=10)
    table.add_column("Description")

    for i, t in enumerate(tools, 1):
        ptype = "[green]PASSIVE[/]" if t.passive else "[yellow]ACTIVE[/]"
        table.add_row(str(i), t.name, ptype, t.description[:80] + "…"
                      if len(t.description) > 80 else t.description)

    console.print(table)
    console.print()

    choices = [str(i) for i in range(len(tools) + 1)]
    console.print("[dim]Enter a number to learn about a tool, or [bold]0[/] to go back[/]")
    choice = Prompt.ask("", choices=choices, default="0")

    if choice != "0":
        selected = tools[int(choice) - 1]
        show_tool_lesson(selected)
        show_category(category)   # return to category list after lesson


# ─────────────────────────────────────────────────────────────────────────────
# Search
# ─────────────────────────────────────────────────────────────────────────────

def show_search() -> None:
    console.print()
    query = Prompt.ask("[bold cyan]Search tools[/]")
    results = search(query)

    if not results:
        console.print(f"[yellow]No tools matched '{query}'[/]")
        return

    console.print(f"\n[dim]Found {len(results)} result(s) for '[cyan]{query}[/]':[/]\n")
    for i, t in enumerate(results, 1):
        console.print(
            f"  [bold]{i}.[/] [bold cyan]{t.name}[/] [dim]({t.category})[/] — {t.description[:70]}…"
        )

    console.print()
    choices = [str(i) for i in range(len(results) + 1)]
    choice  = Prompt.ask("[dim]Enter number to open, or 0 to cancel[/]",
                          choices=choices, default="0")
    if choice != "0":
        show_tool_lesson(results[int(choice) - 1])


# ─────────────────────────────────────────────────────────────────────────────
# Main learning mode menu
# ─────────────────────────────────────────────────────────────────────────────

def learning_mode_menu() -> None:
    """Top-level Learning Mode interactive menu."""
    while True:
        console.clear()
        _header("ReconX Learning Mode",
                "Master every reconnaissance tool — one lesson at a time")

        # Category cards
        cards = []
        for cat in CATEGORY_ORDER:
            tools = get_by_category(cat)
            if not tools:
                continue
            passive_count = sum(1 for t in tools if t.passive)
            cards.append(Panel(
                f"[bold white]{cat}[/]\n"
                f"[dim]{len(tools)} tools[/]  "
                f"[green]{passive_count} passive[/]  "
                f"[yellow]{len(tools)-passive_count} active[/]",
                border_style="dim cyan",
                padding=(1, 2),
            ))

        console.print(Columns(cards, equal=True, expand=True))
        console.print()

        console.print(
            "[bold cyan]Categories:[/]\n"
            + "".join(f"  [{i+1}] {cat}\n"
                      for i, cat in enumerate(CATEGORY_ORDER)
                      if get_by_category(cat))
            + "  [s] Search tools   [0] Exit Learning Mode"
        )

        # Build valid choices
        valid_cats = [c for c in CATEGORY_ORDER if get_by_category(c)]
        choices    = [str(i+1) for i in range(len(valid_cats))] + ["s", "0"]

        choice = Prompt.ask("", choices=choices, default="0")

        if choice == "0":
            break
        elif choice == "s":
            show_search()
        else:
            idx = int(choice) - 1
            if 0 <= idx < len(valid_cats):
                show_category(valid_cats[idx])
