"""
ReconX — Learning: Tool Lessons + Relationship Graph (Stage 14, Parts 4 & 9).

Interactive learning flow:
  1. Read tool concept
  2. See workflow position
  3. Browse example commands
  4. Understand tool relationships
  5. Run tool in practice mode (dry)

Tool relationship graph shows chaining rationale:
  Subfinder → HTTPX → Katana → LinkFinder
  WHOIS → ASNMap → MapCIDR → Masscan → Nmap
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from rich import box
from rich.align import Align
from rich.console import Console, Group
from rich.panel import Panel
from rich.prompt import Prompt
from rich.rule import Rule
from rich.table import Table
from rich.text import Text


# ─────────────────────────────────────────────────────────────────────────────
# Tool relationship definitions
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class ToolRelationship:
    from_tool:  str
    to_tool:    str
    reason:     str                  # why they chain
    benefit:    str                  # what you gain
    data_flow:  str = ""             # what data passes
    alternative: Optional[str] = None


TOOL_RELATIONSHIPS: list[ToolRelationship] = [
    # Asset discovery chain
    ToolRelationship("WHOIS",       "ASNMap",     "WHOIS reveals org → ASN resolves IP ranges",
                     "Expands single domain to all org IP space", "org name → ASN numbers"),
    ToolRelationship("ASNMap",      "MapCIDR",    "ASN returns CIDRs → MapCIDR expands them",
                     "Individual IPs ready for port scanning",    "CIDR blocks → IP list"),
    ToolRelationship("MapCIDR",     "Masscan",    "IP list feeds Masscan for fast port sweep",
                     "Find all open ports across org IP space",   "IP list → open ports"),
    ToolRelationship("Masscan",     "Nmap",       "Masscan finds ports → Nmap identifies services",
                     "Service/version fingerprinting on known-open ports", "ports → services"),
    # Subdomain chain
    ToolRelationship("theHarvester","Sublist3r",  "Passive enum feeds into passive enum for coverage",
                     "Broader subdomain list with less false positives", "subdomains → more subdomains",
                     alternative="Amass"),
    ToolRelationship("Sublist3r",   "AlterX",     "Known subs seed permutation generator",
                     "Generates env-specific candidates: dev, stg, prod", "subdomains → permutations"),
    ToolRelationship("AlterX",      "ShuffleDNS", "Permutations need wildcard-safe validation",
                     "Resolves thousands of candidates, filters wildcards", "permutations → valid subs"),
    ToolRelationship("ShuffleDNS",  "HTTPX",      "Valid DNS names probed for HTTP services",
                     "Live web targets with title, tech, status code", "subdomains → HTTP services"),
    # Web recon chain
    ToolRelationship("HTTPX",       "Katana",     "HTTP services → JS-aware crawling",
                     "Full endpoint map including SPA routes", "URLs → all endpoints",
                     alternative="Gospider"),
    ToolRelationship("Katana",      "ParamSpider","Crawled URLs → parameter extraction",
                     "Parameter list for fuzzing", "URLs → parameters"),
    ToolRelationship("ParamSpider", "Arjun",      "Passive params → active verification",
                     "Confirms hidden params that passive missed", "param names → verified params"),
    ToolRelationship("HTTPX",       "GoWitness",  "HTTP targets → visual screenshot",
                     "Visual triage without visiting each target", "URLs → screenshots",
                     alternative="Aquatone"),
    # Historical chain
    ToolRelationship("GAU",         "Waymore",    "GAU baseline → Waymore adds more sources",
                     "Higher URL coverage: Wayback + CC + URLScan + OTX", "domain → historical URLs"),
    ToolRelationship("Waymore",     "FeroxBuster","Historical URLs reveal content patterns → recursive discovery",
                     "Finds paths that match historical patterns", "URL patterns → content"),
    # Cert chain
    ToolRelationship("CRT.SH",      "TLSX",       "CT log subs → TLS probe for live verification",
                     "Confirms which CT subs are live + extracts more SANs", "subs → verified + more subs"),
    ToolRelationship("TLSX",        "TestSSL",    "Known TLS hosts → vulnerability audit",
                     "TLS CVE scan on verified targets only", "hosts → TLS vulns"),
    # Secret chain
    ToolRelationship("github-subdomains","TruffleHog","GitHub search finds repos → scan for secrets",
                     "Verified live credentials from public code", "repos → secrets"),
    ToolRelationship("TruffleHog",  "Gitleaks",   "TruffleHog (verified) + Gitleaks (fast) for coverage",
                     "Complementary: TH verifies, GL is faster", "repos → more secrets",
                     alternative="gitLeaks alone (faster, no verification)"),
    # Comparison pairs
    ToolRelationship("Gobuster",    "Feroxbuster","Both: directory brute-force",
                     "Feroxbuster recurses automatically; Gobuster is faster for single-level",
                     alternative="Use Feroxbuster for thorough, Gobuster for speed"),
    ToolRelationship("Masscan",     "Nmap",       "Masscan (fast sweep) → Nmap (deep fingerprint)",
                     "10x faster combined vs Nmap alone on large ranges", "ports"),
    ToolRelationship("Subfinder",   "Amass",      "Subfinder (fast passive) → Amass (thorough active)",
                     "Amass finds what Subfinder misses via brute-force and graph", "subdomains"),
]


@dataclass
class ToolLesson:
    """Full educational entry for one tool."""
    name:            str
    tagline:         str
    problem_solved:  str
    how_it_works:    str
    use_cases:       list[str]
    examples:        list[str]
    output_sample:   str
    common_mistakes: list[str]
    comparisons:     list[str]          # "vs X: ..."
    workflow_before: list[str]          # tools that typically run before
    workflow_after:  list[str]          # tools that typically run after
    install:         str
    tags:            list[str] = field(default_factory=list)


# Core lessons (expandable — catalog from Stages 12.1-12.3 merged here)
LESSONS: dict[str, ToolLesson] = {
    "Subfinder": ToolLesson(
        name="Subfinder",
        tagline="Passive subdomain discovery from 40+ sources",
        problem_solved="You need subdomains without touching the target.",
        how_it_works=(
            "Subfinder queries 40+ passive data sources simultaneously: "
            "Certificate Transparency logs, VirusTotal, Shodan, SecurityTrails, "
            "and more. Results are aggregated and deduplicated. No DNS queries "
            "to the target — entirely passive."
        ),
        use_cases=[
            "Build initial subdomain list before active scanning",
            "Discover subdomains without alerting target IDS",
            "Seed permutation tools like AlterX",
            "Compare passive coverage vs Amass active",
        ],
        examples=[
            "subfinder -d example.com -silent",
            "subfinder -d example.com -all -silent | httpx -silent",
            "subfinder -d example.com -oJ -o subs.json",
            "subfinder -dL domains.txt -silent | sort -u > all_subs.txt",
        ],
        output_sample=(
            "api.example.com\n"
            "dev.example.com\n"
            "staging.example.com\n"
            "www.example.com"
        ),
        common_mistakes=[
            "Running without API keys — free tier has 40% lower coverage",
            "Not piping to HTTPX for live verification",
            "Treating every result as live without DNS validation",
        ],
        comparisons=[
            "vs Amass: Subfinder is faster + passive. Amass has active brute-force.",
            "vs theHarvester: Subfinder focuses on subdomains. theHarvester also finds emails/IPs.",
            "vs crt.sh: crt.sh is one source. Subfinder aggregates 40+.",
        ],
        workflow_before=["WHOIS", "theHarvester"],
        workflow_after=["AlterX", "ShuffleDNS", "HTTPX"],
        install="go install github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest",
        tags=["subdomain", "passive", "enumeration"],
    ),
    "HTTPX": ToolLesson(
        name="HTTPX",
        tagline="Multi-threaded HTTP probing for large target lists",
        problem_solved="Turn a list of domains/IPs into confirmed live HTTP targets with metadata.",
        how_it_works=(
            "HTTPX sends HTTP/HTTPS requests to each target concurrently, "
            "following redirects, and extracts: status code, title, server, "
            "content length, technology fingerprint, CDN detection, and TLS info. "
            "Much faster than manual checking and essential before crawlers."
        ),
        use_cases=[
            "Filter live web targets from large subdomain lists",
            "Extract page titles for quick triage",
            "Detect technology stacks (React, WordPress, etc.)",
            "Find non-standard ports (8080, 8443, 3000)",
        ],
        examples=[
            "subfinder -d example.com -silent | httpx -silent",
            "httpx -list subs.txt -title -tech-detect -status-code",
            "httpx -list subs.txt -ports 80,443,8080,8443 -silent",
            "cat ips.txt | httpx -title -server -status-code -o live.txt",
        ],
        output_sample=(
            "https://api.example.com [200] [Example API] [nginx/1.18]\n"
            "https://dev.example.com [302] [→ login.example.com] [Apache]\n"
            "https://admin.example.com [200] [Admin Panel] [PHP/8.1]"
        ),
        common_mistakes=[
            "Not using -follow-redirects — misses redirected pages",
            "Skipping -tech-detect — loses valuable fingerprinting",
            "Not probing non-standard ports (-ports 80,443,8080,8443,3000)",
        ],
        comparisons=[
            "vs curl: HTTPX handles thousands of targets; curl is for single URLs.",
            "vs WhatWeb: HTTPX is faster; WhatWeb has deeper fingerprinting.",
        ],
        workflow_before=["Subfinder", "ShuffleDNS", "Nmap"],
        workflow_after=["Katana", "GoWitness", "Feroxbuster"],
        install="go install github.com/projectdiscovery/httpx/cmd/httpx@latest",
        tags=["web", "active", "http", "fingerprint"],
    ),
    "Feroxbuster": ToolLesson(
        name="Feroxbuster",
        tagline="Fast recursive web content discovery written in Rust",
        problem_solved="Find hidden directories, files, and endpoints not linked anywhere.",
        how_it_works=(
            "Feroxbuster sends HTTP requests for each word in a wordlist against "
            "the target URL. When it finds a directory, it automatically spawns "
            "child scans into that directory. Response filtering (by size, word "
            "count, status) eliminates false positives. The Rust engine makes it "
            "significantly faster than Python alternatives."
        ),
        use_cases=[
            "Discover admin panels, backup files, debug endpoints",
            "Recursive scan into discovered directories",
            "API endpoint discovery with extension fuzzing",
            "Find soft-404 pages using --filter-size",
        ],
        examples=[
            "feroxbuster --url https://example.com",
            "feroxbuster --url https://example.com --depth 3 --extensions php,html,bak",
            "feroxbuster --url https://example.com --filter-status 404,500 --threads 50",
            "feroxbuster --url https://example.com -w /usr/share/seclists/Discovery/Web-Content/raft-medium-directories.txt",
        ],
        output_sample=(
            "200 GET 1234l 56w 8901c https://example.com/admin/\n"
            "200 GET 456l  12w  890c https://example.com/api/v1/\n"
            "301 GET   0l   0w    0c https://example.com/backup/ → /old/"
        ),
        common_mistakes=[
            "Using too small a wordlist — miss important paths",
            "Not filtering soft-404s — thousands of false positives",
            "Forgetting --extensions for API/PHP/backup file discovery",
        ],
        comparisons=[
            "vs Gobuster: Feroxbuster recurses automatically; Gobuster is single-pass but faster.",
            "vs dirb: Feroxbuster is 10-50x faster and has better filtering.",
            "vs DirBuster: DirBuster needs Java GUI; Feroxbuster is headless CLI.",
        ],
        workflow_before=["HTTPX", "Gobuster"],
        workflow_after=["ParamSpider", "Arjun", "GoWitness"],
        install="sudo apt install feroxbuster  # or download from GitHub",
        tags=["web", "active", "directory", "recursive"],
    ),
}


# ─────────────────────────────────────────────────────────────────────────────
# LearningMode
# ─────────────────────────────────────────────────────────────────────────────

class LearningMode:
    """
    Interactive learning interface. Two entry points:
      browse_lessons()       — catalog of all tool lessons
      show_relationships()   — tool relationship graph
    """

    def __init__(self, console: Optional[Console] = None, registry=None):
        self.console  = console or Console()
        self.registry = registry

    # ── lesson browser ────────────────────────────────────────────────────────

    def browse_lessons(self) -> None:
        all_lessons = self._all_lessons()
        while True:
            self.console.clear()
            self.console.print(self._lesson_list_panel(all_lessons))
            self.console.print()

            choice = Prompt.ask(
                "[cyan]Lesson number[/] (or [bold]R[/]=Relationships, [bold]0[/]=Back)",
                console=self.console, default="0"
            ).strip().lower()

            if choice in ("0", "b"):
                break
            if choice == "r":
                self.show_relationships()
                continue
            try:
                idx = int(choice) - 1
                if 0 <= idx < len(all_lessons):
                    self._show_lesson(all_lessons[idx])
            except ValueError:
                pass

    def _all_lessons(self) -> list[ToolLesson]:
        """Return all available lessons — from LESSONS dict + registry knowledge."""
        lessons = list(LESSONS.values())
        # Try to add lessons from Stage 12.1 catalog
        try:
            from reconx.knowledge.tools.stage121_catalog import ALL_TOOL_KNOWLEDGE
        except ModuleNotFoundError:
            try:
                from knowledge.tools.stage121_catalog import ALL_TOOL_KNOWLEDGE
            except Exception:
                ALL_TOOL_KNOWLEDGE = []

        for tk in ALL_TOOL_KNOWLEDGE:
            if tk.name not in LESSONS:
                lessons.append(ToolLesson(
                    name            = tk.name,
                    tagline         = tk.description[:80],
                    problem_solved  = tk.description,
                    how_it_works    = tk.how_it_works,
                    use_cases       = tk.use_cases,
                    examples        = tk.example_commands,
                    output_sample   = "",
                    common_mistakes = [e["error"] for e in tk.common_errors],
                    comparisons     = [],
                    workflow_before = tk.typical_workflow[:-1] if tk.typical_workflow else [],
                    workflow_after  = tk.typical_workflow[1:]  if tk.typical_workflow else [],
                    install         = tk.install,
                    tags            = tk.tags,
                ))
        return lessons

    def _lesson_list_panel(self, lessons: list[ToolLesson]) -> Panel:
        table = Table(box=box.SIMPLE, show_header=False, padding=(0, 1), expand=True)
        table.add_column("#",       style="dim",       width=4)
        table.add_column("Tool",    style="bold white")
        table.add_column("Tagline", style="dim")
        table.add_column("Tags",    style="cyan",       max_width=30)

        for i, lesson in enumerate(lessons, 1):
            table.add_row(
                f"{i}.",
                lesson.name,
                lesson.tagline[:55],
                " ".join(f"[{t}]" for t in lesson.tags[:3]),
            )

        return Panel(
            table,
            title="[bold cyan]Learning Mode — Tool Lessons[/]",
            subtitle="[dim]R=Relationships  0=Back[/]",
            border_style="cyan",
            padding=(1, 2),
        )

    # ── single lesson ─────────────────────────────────────────────────────────

    def _show_lesson(self, lesson: ToolLesson) -> None:
        sections = [
            ("1", "Overview",        self._section_overview),
            ("2", "How It Works",    self._section_how),
            ("3", "Use Cases",       self._section_usecases),
            ("4", "Examples",        self._section_examples),
            ("5", "Common Mistakes", self._section_mistakes),
            ("6", "Comparisons",     self._section_comparisons),
            ("7", "Workflow Chain",  self._section_workflow),
        ]

        while True:
            self.console.clear()
            self._print_lesson_header(lesson)

            menu_table = Table(box=None, show_header=False, padding=(0, 2))
            for key, label, _ in sections:
                menu_table.add_row(f"[cyan][{key}][/]", label)
            menu_table.add_row("[dim][0][/]", "Back to list")
            self.console.print(Panel(menu_table, border_style="dim cyan"))

            choice = Prompt.ask("›", console=self.console, default="0").strip()
            if choice in ("0", "b"):
                break
            for key, _, fn in sections:
                if choice == key:
                    self.console.clear()
                    self._print_lesson_header(lesson)
                    fn(lesson)
                    Prompt.ask("\n[dim]Press Enter to continue[/]", default="")
                    break

    def _print_lesson_header(self, lesson: ToolLesson) -> None:
        self.console.print(Panel(
            Group(
                Align.center(Text(lesson.name, style="bold cyan")),
                Align.center(Text(lesson.tagline, style="dim")),
                Align.center(Text(lesson.install, style="dim green")),
            ),
            border_style="cyan", padding=(0, 4),
        ))

    def _section_overview(self, lesson: ToolLesson) -> None:
        self.console.print(Panel(
            lesson.problem_solved,
            title="[cyan]Problem It Solves[/]", border_style="dim cyan",
        ))

    def _section_how(self, lesson: ToolLesson) -> None:
        self.console.print(Panel(
            lesson.how_it_works,
            title="[cyan]How It Works[/]", border_style="dim cyan",
        ))

    def _section_usecases(self, lesson: ToolLesson) -> None:
        for i, uc in enumerate(lesson.use_cases, 1):
            self.console.print(f"  [cyan]{i}.[/] {uc}")

    def _section_examples(self, lesson: ToolLesson) -> None:
        for cmd in lesson.examples:
            self.console.print(Panel(
                f"[bold cyan]$[/] [white]{cmd}[/]",
                border_style="dim", padding=(0, 2),
            ))
        if lesson.output_sample:
            self.console.print(Panel(
                f"[dim]{lesson.output_sample}[/]",
                title="[dim]Sample Output[/]", border_style="dim",
            ))

    def _section_mistakes(self, lesson: ToolLesson) -> None:
        for m in lesson.common_mistakes:
            self.console.print(f"  [red]⚠[/] {m}")

    def _section_comparisons(self, lesson: ToolLesson) -> None:
        if not lesson.comparisons:
            self.console.print("[dim]No comparisons available.[/]")
            return
        for c in lesson.comparisons:
            self.console.print(f"  [cyan]•[/] {c}")

    def _section_workflow(self, lesson: ToolLesson) -> None:
        self._render_chain(lesson.workflow_before + [lesson.name] + lesson.workflow_after)

    # ── relationship graph ─────────────────────────────────────────────────────

    def show_relationships(self) -> None:
        """Display tool relationship graph with rationale."""
        # Group relationships by chain
        chains = self._build_chains()
        while True:
            self.console.clear()
            self.console.print(self._relationship_overview(chains))
            self.console.print()

            choice = Prompt.ask(
                "[cyan]Chain number[/] (or 0=Back)",
                console=self.console, default="0"
            ).strip()
            if choice in ("0", "b"):
                break
            try:
                idx = int(choice) - 1
                if 0 <= idx < len(chains):
                    self._show_chain_detail(chains[idx])
            except ValueError:
                pass

    def _build_chains(self) -> list[list[ToolRelationship]]:
        """Group relationships into meaningful named chains."""
        return [
            # Asset chain
            [r for r in TOOL_RELATIONSHIPS if r.from_tool in
             ("WHOIS", "ASNMap", "MapCIDR", "Masscan")],
            # Subdomain chain
            [r for r in TOOL_RELATIONSHIPS if r.from_tool in
             ("theHarvester", "Sublist3r", "AlterX", "ShuffleDNS")],
            # Web recon chain
            [r for r in TOOL_RELATIONSHIPS if r.from_tool in
             ("HTTPX", "Katana", "ParamSpider")],
            # Historical chain
            [r for r in TOOL_RELATIONSHIPS if r.from_tool in ("GAU", "Waymore")],
            # Certificate chain
            [r for r in TOOL_RELATIONSHIPS if r.from_tool in ("CRT.SH", "TLSX")],
            # Secret chain
            [r for r in TOOL_RELATIONSHIPS if r.from_tool in
             ("github-subdomains", "TruffleHog")],
            # Comparisons
            [r for r in TOOL_RELATIONSHIPS
             if "vs" in r.reason.lower() or r.alternative],
        ]

    _CHAIN_NAMES = [
        "Infrastructure Chain (WHOIS → ASN → CIDR → Ports → Services)",
        "Subdomain Chain (Harvest → Permute → Validate → Probe)",
        "Web Recon Chain (HTTP → Crawl → Parameters)",
        "Historical Chain (GAU → Waymore → Content Discovery)",
        "Certificate Chain (CT Logs → TLS → Vuln Audit)",
        "Secrets Chain (GitHub → TruffleHog → Gitleaks)",
        "Tool Comparisons (when to use which)",
    ]

    def _relationship_overview(self, chains: list) -> Panel:
        table = Table(box=box.SIMPLE, show_header=False, padding=(0, 1))
        table.add_column("#",     style="dim",        width=4)
        table.add_column("Chain", style="bold white")

        for i, name in enumerate(self._CHAIN_NAMES, 1):
            table.add_row(f"{i}.", name)

        return Panel(
            table,
            title="[bold cyan]Tool Relationship Graph — Chains[/]",
            border_style="cyan", padding=(1, 2),
        )

    def _show_chain_detail(self, relationships: list[ToolRelationship]) -> None:
        self.console.clear()
        if not relationships:
            self.console.print("[dim]No relationships in this chain.[/]")
            Prompt.ask("[dim]Press Enter[/]", default="")
            return

        # ASCII chain visualization
        tools = [relationships[0].from_tool]
        for r in relationships:
            tools.append(r.to_tool)
        self._render_chain(tools)
        self.console.print()

        # Detail table
        table = Table(box=box.ROUNDED, border_style="dim cyan",
                      show_header=True, header_style="bold dim")
        table.add_column("From",        style="cyan",  width=18)
        table.add_column("→ To",        style="white", width=18)
        table.add_column("Why",         style="dim")
        table.add_column("Benefit")

        for rel in relationships:
            table.add_row(rel.from_tool, rel.to_tool, rel.reason, rel.benefit)
            if rel.alternative:
                table.add_row("", "", f"[dim]Alt: {rel.alternative}[/]", "")

        self.console.print(table)
        Prompt.ask("\n[dim]Press Enter to continue[/]", default="")

    def _render_chain(self, tools: list[str]) -> None:
        """ASCII chain: Tool1 → Tool2 → Tool3."""
        self.console.print()
        for i, tool in enumerate(tools):
            colour = "bold cyan" if i == 0 or i == len(tools) - 1 else "white"
            self.console.print(f"  [{colour}]{tool}[/{colour}]")
            if i < len(tools) - 1:
                self.console.print("    [dim cyan]↓[/]")
        self.console.print()
