# ReconX — Stage 17 Changelog

## Overview

Stage 17 transforms ReconX from a collection of scanners into an
**infrastructure intelligence platform**.  Raw scan findings are now
correlated, labelled, and contextualised into a coherent picture of
the target's infrastructure — revealing relationships, CDN shielding,
shared hosting clusters, and critical exposures that isolated tool
outputs cannot surface.

---

## New Files (7)

### `analysis/service_correlator.py` — `ServiceCorrelator`

Correlates all raw findings into a typed, confidence-scored
infrastructure graph with hierarchical tree output.

**Correlation passes (all isolated — failure = warning + continue):**

| Pass | What it does |
|---|---|
| `ip_hostname` | Maps IP addresses ↔ hostnames via DNS A/AAAA records and TLS SAN |
| `service_tech` | Links open ports ↔ detected technologies via banner matching |
| `port_app` | Maps canonical port numbers → application names (80 port dictionary) |
| `cdn_detect` | Identifies CDN/WAF presence from 9 provider signatures (Cloudflare, Akamai, Fastly, CloudFront, Azure, Incapsula, Sucuri, Imperva, Google) |
| `asn_infra` | Groups IPs under their WHOIS ASN node |
| `build_tree` | Constructs hierarchical tree: host → IP → service → technology |

**Output:** `CorrelationReport` with `.nodes`, `.edges`, `.cdn_detected`, `.ip_to_hosts`, `.host_to_ips`, `.port_to_app`, `.tech_to_ports`, `.to_dict()`

---

### `analysis/relationship_mapper.py` — `RelationshipMapper`

Identifies structural relationships across discovered assets.

**Analysis passes:**

| Pass | What it finds |
|---|---|
| `shared_ip` | Multiple hostnames resolving to the same IP; shared CNAME targets |
| `tls_match` | Subdomains sharing a TLS certificate via SAN list |
| `banner_match` | Ports with identical normalised server banners |
| `tech_overlap` | Services exposing the same technology stack |
| `sub_cluster` | Subdomain families grouped by prefix pattern |

**High-value subdomain prefixes** trigger elevated confidence: `admin`, `portal`, `vpn`, `api`, `dev`, `staging`, `jenkins`, `gitlab`, `mail`, `db`, `backup`, `rdp`.

**Output:** `RelationshipMap` with typed group lists, `.high_confidence_groups(min=0.8)`, `.all_groups`, `.to_dict()`

---

### `tools/banner_analyzer.py` — `BannerAnalyzer`

Structured banner intelligence from raw service banners.

**48 detection patterns** across protocols:
- HTTP servers: nginx, Apache, IIS, Lighttpd, Tomcat, Jetty, Caddy, OpenResty, Gunicorn, Werkzeug, PHP
- SSH: OpenSSH, Dropbear, libssh, Bitvise, Cisco SSH
- FTP: vsftpd, ProFTPD, PureFTPD, FileZilla, wu-ftpd, IIS FTP
- SMTP: Postfix, Sendmail, Exim, Exchange, hMailServer, Haraka
- IMAP/POP3: Dovecot, Cyrus, Courier
- Databases: MySQL/MariaDB, PostgreSQL, MongoDB, Redis, Memcached, Elasticsearch
- VPN: OpenVPN, Cisco VPN, Fortinet, Pulse Secure

**Known-vulnerable version database** for: OpenSSH, Apache, nginx, vsftpd (2.3.4 backdoor), ProFTPD, IIS, PHP, Exim.

**Output:** `BannerResult` per port with `.software`, `.version`, `.confidence`, `.risk_level`, `.risk_reason`, `.tags`. `analyze_all(ports)` processes the full `result.ports` list. `summarize(results)` returns aggregate statistics.

---

### `analysis/tag_engine.py` — `TagEngine`

Auto-labels all assets with 18 semantic infrastructure tags.

**Tags:**
`[CDN]` `[LOGIN]` `[API]` `[ADMIN]` `[CLOUD]` `[VPN]` `[MAIL]` `[CRITICAL]` `[DATABASE]` `[DEVTOOLS]` `[K8S]` `[LEGACY]` `[EXPOSED]` `[TLS-WEAK]` `[TAKEOVER]` `[SSH]` `[FTP]` `[SMB]` `[RDP]` `[DNS]`

**Tagging passes:**

| Pass | Source |
|---|---|
| `ports` | Port-number table (80 entries) + banner text |
| `technologies` | Technology name keyword matching |
| `subdomains` | Subdomain prefix regex patterns (22 patterns) |
| `tls` | TLS expiry, self-signed, weak protocol (TLSv1/1.1/SSLv3) |
| `takeovers` | All `result.takeover_candidates` → `[TAKEOVER][CRITICAL]` |
| `host` | Aggregate host risk from CVE severity and critical ports |

`tag_style(tag)` returns Rich style string for TUI rendering.
`tag_description(tag)` returns operator-readable description.

---

### `analysis/service_learning.py` — `ServiceLearning`

Inline educational context for 11 high-risk services:

`SMB (445)` · `SSH (22)` · `RDP (3389)` · `Redis (6379)` · `Elasticsearch (9200)` · `MongoDB (27017)` · `FTP (21)` · `Docker API (2375)` · `Kubernetes API (6443)` · `HTTP (80)` · `SMTP (25)`

Each `ServiceContext` provides:
- Description
- Common uses (3–4 items)
- Security relevance (paragraph)
- Typical risks (4–6 items)
- Recommended next tools (3–4)
- Ready-to-use commands (2–3, with `TARGET` placeholder)
- Possible errors and meaning
- Fix steps (4–5)

`get_context(port, service, technology)` — fuzzy lookup.
`get_all_risky(ports)` — returns HIGH/CRITICAL contexts for open ports.

---

### `tui/views/infrastructure_view.py` — `InfrastructureView`

Rich TUI panel for the full infrastructure intelligence dashboard.

**Panels:**
1. **Live Counters** — Subdomains / IPs / Open Ports / Technologies / Correlations / Relationship Groups / Critical Tags (Columns layout)
2. **Asset Tree View** — Rich `Tree` component with colour-coded nodes: host (cyan) → IP (yellow) → service (white) → technology (green) → CDN (cyan)
3. **Service Intelligence** — Tagged asset groups with risk descriptions, grouped by tag priority, border-coloured by severity
4. **Asset Relationships** — Shared IP, TLS, banner, tech, subdomain cluster groups with confidence percentages
5. **CDN Notice** — Panel when CDN/WAF detected; advises on origin IP masking
6. **Interactive Loop** — `[1] Learn about a service` → port selector → inline `ServiceContext` panel; `[2] Show full tag list` → tag reference table

---

### `output/report_17.py` — `inject_intelligence_section()`

Injects a six-section infrastructure intelligence block into any HTML report.

| Section | Content |
|---|---|
| Intelligence Summary | Stat cards: nodes, relationships, groups, identified banners, critical tags, CDN |
| Asset Tree | CSS-rendered hierarchy: host → IP → service → tech with risk badges |
| Infrastructure Tags | Tag summary pills + high-risk asset table |
| Asset Relationships | Grouped by type (shared IP, TLS, banner, tech, subdomain) with confidence and evidence |
| Banner Intelligence | Software identification pills + version-risk table |
| Service Intelligence | Learning cards for HIGH/CRITICAL ports with commands substituted with actual target |

`inject_intelligence_section(html_path, intel, target)` — idempotent; safe to call multiple times.

---

## Modified Files (1)

### `engine/executor.py`

Added `_run_intelligence_pipeline(result)` as a post-processing phase in `run()`, after the standard analysis pipeline:

```
discovery → scanning → dedup → sensitive → CVE → suggestions → risk
  → [Stage 17] banner analysis → service correlation → relationship mapping
                                → infrastructure tagging → result.raw["intelligence"]
```

All four Stage 17 sub-phases are **independently isolated**:
- Each wrapped in `try/except`
- Failure logs a `WARNING` and stores error in `result.raw["intelligence"][phase]["warning"]`
- No sub-phase failure can stop any other sub-phase or the overall scan
- Components are **lazy-initialised** — no import cost on first run

---

## Architecture Map

```
ExecutionEngine.run()
  └── _run_intelligence_pipeline(result)
        ├── BannerAnalyzer.analyze_all(result.ports)
        │     └── 48 regex patterns → BannerResult[] → version risk flags
        │
        ├── ServiceCorrelator.correlate(result)
        │     ├── ip_hostname pass  → ip_to_hosts, host_to_ips
        │     ├── service_tech pass → tech_to_ports, service edges
        │     ├── port_app pass     → port_to_app dict
        │     ├── cdn_detect pass   → cdn_detected list
        │     ├── asn_infra pass    → ASN InfraNode
        │     └── build_tree pass   → hierarchical InfraNode tree
        │
        ├── RelationshipMapper.map(result)
        │     ├── shared_ip_analysis    → AssetGroup[]
        │     ├── tls_match_analysis    → AssetGroup[]
        │     ├── banner_match_analysis → AssetGroup[]
        │     ├── tech_overlap_analysis → AssetGroup[]
        │     └── subdomain_cluster_analysis → AssetGroup[]
        │
        └── TagEngine.tag(result)
              ├── _tag_ports          → [CRITICAL][SMB][RDP]…
              ├── _tag_technologies   → [CDN][DEVTOOLS][API]…
              ├── _tag_subdomains     → [ADMIN][VPN][LOGIN]…
              ├── _tag_tls            → [TLS-WEAK]
              ├── _tag_takeovers      → [TAKEOVER][CRITICAL]
              └── _tag_host           → host-level [CRITICAL]
```

All output stored in `result.raw["intelligence"]` as serialisable dicts.

---

## Error Handling

All components follow the same contract:

```python
try:
    phase_output = component.run(result)
    intelligence["phase"] = phase_output.to_dict()
except Exception as exc:
    logger.warning(f"[Stage17] Phase failed: {exc}")
    intelligence["phase"] = {"warning": f"Phase unavailable: {exc}"}
```

**TUI display:** Shows `[WARNING] relationship analysis unavailable` inline if a phase fails.
**Report:** Shows warning text in place of the section content.
**Scan continuity:** All other scan results (ports, subdomains, CVEs, etc.) are unaffected.

---

## Compatibility

- All new modules import safely from both `reconx.*` and bare paths
- `result.raw["intelligence"]` is always a dict — never None
- `BannerAnalyzer`, `ServiceCorrelator`, `RelationshipMapper`, `TagEngine` accept any `ReconResult` object and degrade gracefully with empty fields
- `InfrastructureView` accepts `None` for any of its three input arguments
- `inject_intelligence_section()` is idempotent and non-destructive
- Learning mode integration: `ServiceLearning.get_context()` returns `None` gracefully for unknown services — callers display a generic message
