# ReconX — Stage 18.1 Changelog

## Overview

Stage 18.1 integrates Burp Suite Professional into ReconX as a
**browser-aware web intelligence and traffic analysis layer**.

ReconX does NOT embed the Burp GUI. Instead it communicates with Burp
through its REST API, orchestrates proxy capture, parses captured traffic
into structured intelligence, imports passive findings, manages sessions,
and replays requests — all feeding directly into the ReconX intelligence
pipeline.

> **Capability gained:** ReconX can now analyse real browser traffic
> rather than relying solely on static crawlers and scanners. Hidden
> endpoints, API routes, auth tokens, cookies, OAuth flows, SPA routes,
> and passive security findings all emerge automatically from traffic that
> flows through Burp.

```
Browser Automation
      ↓
Burp Proxy (127.0.0.1:8080)
      ↓
Traffic Capture
      ↓
ReconX Intelligence Pipeline
```

---

## New Files (11)

### `integrations/burp/burp_client.py` — `BurpClient`

Thin synchronous HTTP client for the Burp Suite Professional REST API
(`http://127.0.0.1:1337` by default).

**Design decisions:**
- All methods return `(data, error_str)` tuples — never raises to callers
- API key read from `RECONX_BURP_API_KEY` env var, kwarg, or omitted
- TLS support for secured Burp instances
- Timeout configurable per instance

**API surface:**

| Group | Methods |
|---|---|
| Connectivity | `ping()`, `get_version()`, `get_diagnostics()` |
| Projects | `create_project()`, `load_project()`, `list_projects()`, `delete_project()` |
| Proxy | `get_proxy_history()`, `get_proxy_config()`, `set_proxy_intercept()`, `clear_proxy_history()` |
| Scanner | `get_scan_issues()`, `get_issue_definitions()`, `start_scan()`, `get_scan_status()` |
| Session | `get_cookies()`, `get_site_map()` |
| Repeater | `send_to_repeater()`, `replay_request()` |

---

### `integrations/burp/project_manager.py` — `ProjectManager`, `BurpProject`

Creates, loads, saves, resumes, and closes Burp projects scoped to
ReconX scan targets.

```
create_for_target("example.com")
    → reconx_example.com_20250501_143022
    → cached to cache/burp/<project_id>.json
```

**`BurpProject` dataclass fields:**
`project_id`, `name`, `target`, `created_at`, `last_saved`,
`description`, `status` (`active|saved|resumed|closed`), `remote_meta`

**Key methods:**
- `create_for_target(target)` — new project with timestamp name
- `load(project_id)` — cache-first, then API fallback
- `save(project)` — persist local metadata
- `resume(project_id)` — validate API connectivity, load, mark resumed
- `list_cached()` — all local project records, newest-first
- `find_for_target(host)` — filter cached projects by target host

Local cache: `reconx/cache/burp/<project_id>.json`

---

### `integrations/burp/proxy_controller.py` — `ProxyController`, `ProxyConfig`

Controls Burp Suite as a transparent proxy for automated traffic capture.

**`ProxyConfig` helpers:**

```python
cfg = ProxyConfig(port=8080)
cfg.proxy_url           # "http://127.0.0.1:8080"
cfg.playwright_proxy    # {"server": "http://127.0.0.1:8080"}
cfg.httpx_proxy         # {"proxy": "http://127.0.0.1:8080"}
cfg.env_vars            # {"HTTP_PROXY": ..., "HTTPS_PROXY": ..., ...}
```

**`ProxyController` strategy:**
1. If Burp REST API already alive → skip launch, configure listener
2. If `RECONX_BURP_JAR` set → launch headless via `java -jar` with 30s startup poll
3. Otherwise → mark status with setup instructions, continue gracefully

**Browser/tool integration helpers:**
```python
ctrl.playwright_config()   # browser launch kwargs with proxy + cert ignore
ctrl.httpx_config()        # httpx client kwargs with proxy + verify=False
ctrl.subprocess_env()      # merged os.environ + proxy env vars
```

Intercept is always disabled for automated runs (passive capture mode).

---

### `integrations/burp/traffic_parser.py` — `TrafficParser`, `TrafficSummary`

Core intelligence engine. Parses raw Burp proxy history items into a
structured `TrafficSummary`.

**Extraction coverage:**

| Category | What is extracted |
|---|---|
| Endpoints | URL, method, status, category (api/graphql/admin/auth/upload/…) |
| API routes | `/api/`, `/v1/`, `/v2/` patterns |
| GraphQL | `/graphql`, `gql` in URL |
| Auth tokens | JWTs (header+payload decoded), Bearer tokens, API keys |
| Cookies | Name, domain, Secure, HttpOnly, SameSite attributes |
| Parameters | Query string and form-encoded body params |
| Security issues | Missing HSTS, CSP, X-Frame-Options, X-Content-Type-Options, CORS wildcard |
| Info disclosure | Server, X-Powered-By, X-Generator, X-PHP-Version banners |
| Redirects | 301/302/307/308 chains captured |
| Web discovery | Login pages, admin portals, upload forms, OAuth flows, SSO pages |
| SPA routes | `#/` hash routes, `/app/`, `/ng/`, pushState patterns |

**`TrafficSummary.to_dict()`** — fully JSON-serialisable for caching and reporting.

Regex patterns compiled once at module load; stateless parser (safe for
concurrent use).

---

### `integrations/burp/session_manager.py` — `SessionManager`, `BurpSession`

Manages named capture sessions — discrete time-bounded windows of proxy
traffic collection.

**Session lifecycle:**
```
start() → active → pause() → resume() → stop() → saved
```

**`BurpSession` key properties:**
- `short_id` — first 8 hex chars, used for CLI references (`reconx burp replay abc12345`)
- `is_active` — True for `active` and `resumed` states
- `duration_s` — elapsed seconds (uses `time.time()` at stop)
- `item_ids` — list of Burp proxy item IDs captured in this session
- `baseline_count` — proxy history size at session start (isolates session traffic)
- `traffic_summary` — `TrafficSummary.to_dict()` written at `stop()`

**Baseline isolation:** records proxy history length at `start()` so only
traffic captured during the session is parsed — prior history is excluded.

Local cache: `reconx/cache/burp/sessions/<session_id>.json`

---

### `integrations/burp/issue_importer.py` — `IssueImporter`, `ImportedFindings`

Imports Burp passive scan findings and normalises them into ReconX
finding models.

**Input:** raw Burp `issues` API dicts

**Output:** `ImportedFindings` with three normalised collections:

| Collection | ReconX model | Populated from |
|---|---|---|
| `headers` | `HeaderFinding` | HSTS, CSP, X-Frame-Options, X-Content-Type-Options |
| `sensitive` | `SensitiveFinding` | CORS, TLS, cookies, disclosure, redirects, credentials |
| `suggestions` | `Suggestion` | Every issue with remediation text |

**`ImportedFindings.to_parsed_findings()`** — converts to `list[ParsedFinding]`
for direct injection into `ToolRunResult.findings`.

**Severity normalisation:**

| Burp severity | ReconX severity |
|---|---|
| `high` | `HIGH` |
| `medium` | `MEDIUM` |
| `low` | `LOW` |
| `information` | `INFO` |
| `false positive` | `INFO` |

Also imports site map URLs via `import_site_map_findings()` — returns
all URLs Burp has observed, used to supplement endpoint discovery.

---

### `integrations/burp/replay_engine.py` — `ReplayEngine`, `ReplayReport`

Replays captured HTTP requests via Burp Repeater.

**Three replay modes:**

| Mode | CLI | When |
|---|---|---|
| Single | `reconx burp replay SESSION --request-id ID` | Specific item |
| Sequence | `reconx burp replay SESSION --sequence` | Ordered list of IDs |
| Workflow | `reconx burp replay SESSION` | Full session, all items |

**`ReplayReport`:**
- `total`, `succeeded`, `failed` counts
- `success_rate` — float percentage
- `results` — list of `ReplayResult` (per-request status, timing, URL)
- `to_dict()` — JSON-serialisable for logging and reporting

**Safety:** minimum `0.2s` delay between replayed requests enforced
regardless of `delay_s` argument. Maximum 200 items per workflow replay
(safety cap, configurable). Replay targets original captured hosts only.

---

### `integrations/burp/__init__.py` — `BurpIntelligenceLayer`

Top-level orchestrator implementing the `BaseTool` interface.

**BaseTool metadata:**

| Field | Value |
|---|---|
| `NAME` | `"Burp Suite"` |
| `CATEGORY` | `"web_intelligence"` |
| `STAGE` | `4` (after service detection and web crawling) |
| `PASSIVE` | `True` |
| `TIMEOUT` | `300s` |

**`run(target)` pipeline:**
1. `ping()` — if Burp unreachable → `ToolRunResult.skipped()` (non-fatal)
2. `create_for_target()` — scoped Burp project
3. `start()` — capture session with baseline recording
4. `proxy.start()` — configure proxy listener
5. `stop()` — harvest traffic, run `TrafficParser`
6. `import_findings()` — normalise Burp passive issues
7. `import_site_map_findings()` — supplement endpoint list
8. `save()` — persist project metadata
9. Return `ToolRunResult` with all findings and structured data

**External API for CLI/TUI:**

```python
layer.start_session("example.com")   # start standalone
layer.stop_session()                  # stop + collect
layer.resume_session("abc12345")      # resume by short ID
layer.list_sessions(target="...")     # list all
layer.replay("abc12345")              # workflow replay
layer.get_status()                    # diagnostics dict
layer.get_proxy_config()              # ProxyConfig
```

**Re-exports:** all 7 component classes and their key dataclasses.

---

### `integrations/burp/report_injector.py` — `inject_burp_section()`

Injects a **Web Intelligence** HTML section into any existing ReconX
HTML report.

**Sections injected:**

1. **Status bar** — API reachability, proxy URL, session ID, duration, item count
2. **Stats row** — 7 stat cards: Requests, Endpoints, API Routes, Auth Tokens, Cookies, Issues, Site Map
3. **Captured Endpoints** table — method badge, URL, HTTP status, category badges (up to 30 rows)
4. **Authentication Artefacts** table — JWT/Bearer/API-key tokens with type colour-coding
5. **Session Cookies** table — name, host, Secure ✓/✗, HttpOnly ✓/✗, SameSite
6. **Passive Security Findings** table — type, detail, URL (up to 20 rows)
7. **Web Discovery** grid — 8 cards: Login Pages, Admin Portals, Upload Forms, OAuth/Token, SSO Pages, GraphQL, SPA Routes, API Routes

**CSS:** injected once into `<style>` block (idempotent guard on re-injection).
Designed to visually match existing ReconX dark cyberpunk report theme
using the same CSS custom properties (`--bg2`, `--border`, `--accent`, etc.).

`inject_burp_section(html_path, burp_data, session, imported)` — safe to
call on any existing report. Returns `True` on success, `False` if file
not found.

---

### `tui/views/web_intelligence_view.py` — `WebIntelligencePanel`

Rich-rendered Web Intelligence panel for the ReconX TUI.

**Status bar line:**
```
API: ✓ active   Proxy: ⚡ capturing  127.0.0.1:8080  v2024.12
Session: abc12345  |  Project: reconx_example.com_20250501
Session state: ▶ active
```

**7-panel stats row:** Requests · Endpoints · API Routes · Auth Tokens ·
Cookies · Issues · Site Map (each colour-coded by domain)

**5 data tables:**
- Captured Endpoints (method badge, URL, status, type)
- Auth Tokens (type, truncated value, observed URL)
- Session Cookies (name, host, Secure, HttpOnly, SameSite)
- Passive Security Issues (type, detail, URL)

**Web Discovery panels** — 2-row grid of 7 category cards:
Login Pages / Admin Portals / Upload Forms / OAuth Flows /
SSO Pages / GraphQL / SPA Routes

**Standalone helper:**
```python
from reconx.tui.views.web_intelligence_view import render_web_intelligence
render_web_intelligence(console, burp_layer=layer)
```

Status icons:

| State | Icon | Style |
|---|---|---|
| active / resumed | `▶ active` / `▶ resumed` | green / cyan |
| paused | `⏸ paused` | yellow |
| stopped | `■ stopped` | dim |
| none | `— none` | dim |
| API up | `✓ active` | bold green |
| API down | `✗ failed` | bold red |
| Proxy capturing | `⚡ capturing` | bold cyan |

---

### `tools/registry_181.py` — Stage 18.1 Registry

Registers `BurpIntelligenceLayer` with the ReconX tool ecosystem.

**`get_stage181_registry()`** — returns instantiated tool dict for the
execution engine. Import failures are silent (logged at DEBUG), preserving
the non-fatal registry contract.

**`get_stage181_catalog()`** — pure metadata list (no instantiation).
Provides 14-field entries for the TUI tool browser and marketplace:
`name`, `class`, `module`, `category`, `stage`, `passive`, `description`,
`capabilities` (10 items), `tags` (10 items), `requires_root`,
`install_required`, `recommended_after`, `learning_yaml`, `install_cmd`.

**`get_stage181_tool_chains()`** — two chain definitions for the workflow
builder catalogue:
- `web_intelligence` — Katana → Burp Suite
- `full_web_assessment` — httpx → Gobuster → Katana → Burp Suite

---

### `knowledge/burp/burp_suite.yaml` — Learning Mode Entry

Full YAML knowledge entry for Learning Mode and Guided Recon integration.

Covers:
- `description` — what the integration does
- `use_cases` (8 entries)
- `how_it_works` — proxy flow explanation
- `setup` — requirements, environment variables, browser proxy config
- `cli_commands` — all 5 subcommands with examples
- `common_errors` (5 errors) — message, causes, and fix steps each
- `recommended_integrations` — Playwright, httpx, JS Intelligence Engine, Katana/Hakrawler
- `what_reconx_extracts` — traffic and passive findings categories
- `safety_notes` — passive-only contract statement

---

## Modified Files (0)

Stage 18.1 is entirely additive. No existing files were modified.
All integration points use opt-in imports:

```python
# Tool registry merge (caller's responsibility):
from reconx.tools.registry_181 import get_stage181_registry

# Report injection (called from output pipeline):
from reconx.integrations.burp.report_injector import inject_burp_section

# TUI panel (called from navigator or dashboard):
from reconx.tui.views.web_intelligence_view import render_web_intelligence

# CLI dispatch (called from __main__ when argv[1] == "burp"):
from reconx.cli.burp_commands import dispatch_burp_command
```

---

## Test Suite

### `tests/test_stage181_burp.py` — 77 tests, 12 test classes

**Results: 77/77 passing (1.33s)**

| Class | Tests | Coverage |
|---|---|---|
| `TestBurpClient` | 9 | URL formation, headers, ping failure, graceful error returns |
| `TestTrafficParser` | 11 | Empty parse, API/GraphQL/admin/login detection, JWT, CORS, cookies, HSTS, server banner, serialisation, multi-host |
| `TestProjectManager` | 5 | Create, failure handling, list, cache roundtrip, target filter |
| `TestSessionManager` | 7 | Start, stop, pause, short ID, duration, list, find by short ID |
| `TestIssueImporter` | 7 | Empty, HSTS→header, CORS→sensitive, severity normalisation, site map, to_parsed_findings, API error |
| `TestReplayEngine` | 7 | Single, sequence, error isolation, empty session, serialisation, success rate, missing session |
| `TestProxyController` | 6 | URL, Playwright config, httpx config, env vars, stop no-op, is_running |
| `TestReportInjector` | 4 | Valid file, endpoint content, missing file, idempotent CSS |
| `TestWebIntelligencePanel` | 2 | Render without layer, render with full data |
| `TestBurpCLI` | 6 | Status, sessions, missing target, unknown command, no args, missing session ID |
| `TestRegistry181` | 7 | Catalog length, required fields, capabilities list, burp tag, tool chains, graceful load |
| `TestBurpIntelligenceLayerOffline` | 5 | Status dict, proxy config, skipped when offline, list sessions, stop without start |

---

## Architecture

```
BurpIntelligenceLayer (BaseTool, STAGE=4, PASSIVE=True)
│
├── BurpClient          ← REST API over HTTP to Burp on :1337
│     ├── ping / version / diagnostics
│     ├── project CRUD
│     ├── proxy history / config / intercept
│     ├── scanner issues / site map / cookies
│     └── repeater send / replay
│
├── ProjectManager      ← Burp project lifecycle
│     ├── create_for_target()  → reconx_<target>_<ts>
│     ├── load() / save() / resume() / close()
│     └── cache: cache/burp/<id>.json
│
├── ProxyController     ← Proxy start/stop/configure
│     ├── start()  → ping first, launch jar if RECONX_BURP_JAR set
│     ├── stop()   → SIGTERM + wait + kill fallback
│     ├── playwright_config() / httpx_config() / subprocess_env()
│     └── enable_intercept() / disable_intercept()
│
├── SessionManager      ← Time-bounded capture sessions
│     ├── start(project)   → baseline_count recorded
│     ├── pause() / resume(session_id)
│     ├── stop()           → traffic parsed at stop time
│     └── cache: cache/burp/sessions/<id>.json
│
├── TrafficParser       ← Raw Burp items → structured intelligence
│     ├── parse_history(items) → TrafficSummary
│     ├── endpoint detection  (15 signal patterns)
│     ├── auth extraction     (JWT / Bearer / API key)
│     ├── cookie parsing      (Secure / HttpOnly / SameSite)
│     ├── security header check (5 required headers)
│     ├── info disclosure     (8 server headers)
│     ├── redirect chains     (3xx)
│     └── page classification (login/admin/upload/oauth/sso/spa)
│
├── IssueImporter       ← Burp passive findings → ReconX findings
│     ├── import_findings() → ImportedFindings
│     │     ├── headers    → list[HeaderFinding]
│     │     ├── sensitive  → list[SensitiveFinding]
│     │     └── suggestions → list[Suggestion]
│     ├── import_site_map_findings() → list[str]
│     └── to_parsed_findings() → list[ParsedFinding]
│
└── ReplayEngine        ← Request replay via Burp Repeater
      ├── replay_single(session, request_id)
      ├── replay_sequence(session, ids, delay_s)
      ├── replay_session(session, limit=200)
      └── run_from_cli(session_id, request_id, sequence)

Supporting modules:
  integrations/burp/report_injector.py   → HTML section injection
  tui/views/web_intelligence_view.py      → Rich TUI panel
  cli/burp_commands.py                    → CLI subcommand dispatcher
  tools/registry_181.py                  → tool + catalog + chain registration
  knowledge/burp/burp_suite.yaml         → Learning Mode entry
```

---

## CLI Reference

```bash
# Show Burp connection status
reconx burp status

# Start a capture session
reconx burp start example.com

# Stop the current session
reconx burp stop

# List all sessions
reconx burp sessions
reconx burp sessions --target example.com

# Replay a full session
reconx burp replay a1b2c3d4

# Replay one specific request
reconx burp replay a1b2c3d4 --request-id itemId

# Replay all items in capture order
reconx burp replay a1b2c3d4 --sequence
```

---

## Safety Contract

Stage 18.1 maintains the full ReconX safety contract:

| Rule | Implementation |
|---|---|
| Passive analysis only | No active scanning triggered by ReconX |
| No exploit modules | `PASSIVE = True`; no payload injection in any module |
| Tool failure non-fatal | `ping()` failure → `ToolRunResult.skipped()`, execution continues |
| Replay isolation | Replays only to original captured hosts, no host rewriting |
| BaseTool compatible | `run(target)` signature identical to all other tools |
| Plugin compatible | Registers cleanly through `registry_181.py` merge pattern |
| No breaking changes | Zero existing files modified |
| Graceful degradation | Every component handles Burp-unreachable without exception |

---

## Environment Variables

| Variable | Required | Description |
|---|---|---|
| `RECONX_BURP_API_KEY` | Optional | Burp REST API authentication key |
| `RECONX_BURP_JAR` | Optional | Path to Burp `.jar` for headless launch |

---

## Requirements

| Requirement | Notes |
|---|---|
| Burp Suite Professional | Community Edition has no REST API |
| Java 11+ | Only if using headless launch via `RECONX_BURP_JAR` |
| REST API enabled | Burp → Settings → Suite → REST API → Service running |
| Port 1337 accessible | Default Burp REST API port (localhost only) |
| Port 8080 accessible | Default Burp proxy port (localhost only) |
