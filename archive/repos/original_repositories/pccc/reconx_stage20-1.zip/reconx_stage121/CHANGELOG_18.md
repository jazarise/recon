# ReconX — Stage 18 Changelog

## Overview

Stage 18 transforms ReconX into a **guided analyst assistant and
workflow intelligence platform**.  The new `reconx/workflows/` package
provides an interactive recon assistant, AI-driven next-tool recommendations,
eight professional workflow templates, a live execution engine with Rich
status panels, session recording with replay and diff, an interactive
workflow builder, and an HTML report extension — all while preserving
full BaseTool compatibility and tool-isolation guarantees.

---

## New Files (9)

### `workflows/decision_engine.py` — `DecisionEngine`

AI-style recommendation layer that maps findings to prioritised tool
suggestions.  23 rules covering:

| Signal Category | Rules |
|---|---|
| Port-based | 445 (SMB), 3389 (RDP), 6379 (Redis), 9200 (ES), 27017 (Mongo), 2375 (Docker), 6443 (K8s), 22 (SSH), 21 (FTP) |
| Web | `[ADMIN]`, `[API]`, GraphQL, Swagger/OpenAPI, login panel |
| Discovery | subdomains found, subdomain takeover, cloud bucket, `.git` exposed |
| Technology | WordPress, Jenkins, Jira |
| OSINT | emails found |
| TLS | weak/expired certificate |

Each rule returns a `DecisionResult` with:
- `trigger` — finding key (`"port:445"`, `"graphql"`, etc.)
- `label` — human-readable finding description
- `context` — why this matters
- `severity` — `CRITICAL | HIGH | MEDIUM | INFO`
- `suggestions` — list of `ToolSuggestion` with tool name, class, reason, priority, and ready-to-use commands (target substituted)

**API:**
```python
engine = DecisionEngine()
engine.recommend(result)                        # from ReconResult
engine.recommend_finding("port:445", "target")  # single rule lookup
engine.recommend_from_tags(tag_summary)         # from TagEngine output
```

---

### `workflows/workflow_templates.py` — `WorkflowTemplateLibrary`

Eight professionally documented workflow templates:

| Template | Category | Steps | Est. |
|---|---|---|---|
| `bug_bounty` | web | 14 | 45m |
| `external_infra` | network | 12 | 50m |
| `web_application` | web | 14 | 30m |
| `api_assessment` | api | 9 | 25m |
| `internal_network` | network | 9 | 30m (root) |
| `cloud_assessment` | cloud | 9 | 35m |
| `deep_investigation` | full | 35 | 120m |
| `fast_triage` | web | 5 | 5m |

Each `WorkflowTemplate` contains:
- Ordered `TemplateStep` list with `tool`, `tool_class`, `stage`, `parallel_group`, `why_next`, `expected_output`
- `purpose` — one-line goal
- `use_cases` — 3-4 real-world applications
- `advantages` — why this chain works well
- `expected_output` — what you'll have when it's done
- `chain_explanation` — step-by-step rationale list (shown in Learn Chain)

---

### `workflows/workflow_engine.py` — `WorkflowEngine18`

Executes `WorkflowTemplate` steps with a **live Rich status panel**.

Status indicators per step:
- `⏳ waiting` — queued
- `⚡ running` — currently executing (yellow)
- `✓ success` — completed (green)
- `✗ failed`  — error (red)
- `○ skipped` — condition not met (dim)
- `— cancelled` — halted by required-step failure (dim)

**Execution model:**
- Steps grouped by `(stage, parallel_group)` — same group runs concurrently via `ThreadPoolExecutor`
- Each step wrapped in `try/except` — failure is recorded, execution continues
- `DecisionEngine.recommend()` called after each stage for mid-run suggestions
- `on_step_done` callback fires after each step (recorder auto-save)
- `on_recommend` callback fires when new recommendations are generated
- `pause()` / `resume()` support between batches

**Post-execution summary panel:**
- ✓ / ✗ step counts
- Total duration
- Top 5 recommendations with severity and suggested first tool

---

### `workflows/workflow_recorder.py` — `WorkflowRecorder18`

Persists `WorkflowRunRecord` to disk with atomic save (write → `.tmp` → rename).

Storage: `reconx/data/workflows/workflow_<run_id>.json`
Partial:  `reconx/data/workflows/workflow_<run_id>.partial.json`

**Methods:**
- `save(record)` — atomic full save, removes partial
- `checkpoint(record)` — non-atomic partial write (called after each step)
- `make_step_callback()` — returns `on_step_done` for engine integration
- `load(run_id)` — deserialise from disk
- `list_runs(limit)` — metadata for all saved runs, newest first
- `delete(run_id)` — remove saved run
- `export_json(run_id)` — human-readable JSON export
- `export_markdown(run_id)` — Markdown report with timeline table and recommendations

**CLI equivalents:**
```
reconx workflow list
reconx workflow export <run_id>
reconx workflow export <run_id> --format markdown
```

---

### `workflows/workflow_player.py` — `WorkflowPlayer18`

Replay, resume, clone, diff, and export saved runs.

| Method | What it does |
|---|---|
| `replay(run_id)` | Re-run all steps against original target |
| `replay(run_id, new_target)` | Re-run against different target |
| `resume(run_id)` | Skip already-`SUCCESS` steps, re-run the rest |
| `clone(run_id, new_target)` | Alias for `replay` with new target |
| `export(run_id, fmt)` | Export to JSON or Markdown |
| `diff(run_id_a, run_id_b)` | Compare two runs: step status changes, findings delta, duration delta |
| `list_runs()` | Rich table of all saved runs |

**CLI equivalents:**
```
reconx workflow replay <run_id>
reconx workflow replay <run_id> --target new.example.com
reconx workflow resume <run_id>
reconx workflow diff   <run_id_a> <run_id_b>
```

---

### `workflows/guided_recon.py` — `GuidedRecon18`

Interactive 8-step guided analyst assistant.

**Flow:**
1. **Target entry** — any domain, IP, CIDR, or URL
2. **Target type** — Domain / Web App / Internal / API / Cloud (5 options)
3. **Objective** — curated list per target type (3-5 goals each, 19 total)
4. **Preview** — recommended template with step-by-step tool chain display
5. **Action menu** — `[1] Run Now` / `[2] Learn Chain` / `[3] Customise` / `[4] Back`
6. **Learn Chain** (optional) — tool-by-tool education using `_TOOL_LEARN` blurbs (18 tools covered): description, why-here, expected output, then chain_explanation overview
7. **Customise** (optional) — remove steps by number before running
8. **Execute** — full `WorkflowEngine18` run + session save + DecisionEngine recommendations panel

**Objective catalogue (19 total across 5 target types):**

| Target Type | Objectives |
|---|---|
| Domain | Full External Recon, Find All Subdomains, Bug Bounty Recon, Quick Triage, Deep Investigation |
| Web App | Web App Assessment, Hidden Endpoints, Find Secrets, Quick HTTP Triage |
| Internal | Internal Network Map, Service Enumeration, Quick Host Discovery |
| API | API Surface Discovery, GraphQL Enumeration, Hidden Endpoint Discovery |
| Cloud | Cloud Asset Mapping, S3/Bucket Exposure, Quick Cloud Triage |

---

### `workflows/workflow_builder.py` — `WorkflowBuilder18`

Interactive terminal workflow builder with drag-style step ordering.

**Tool catalogue:** 8 categories, 48 tools total:
`Passive/OSINT` · `DNS` · `Port Scanning` · `Web Recon` · `API/JS` · `Vulnerability` · `Internal/SMB` · `Cloud`

**Actions:**
- `[1] Add Tool` — category browser → tool picker → stage assignment
- `[2] Remove Step` — remove by #
- `[3] Move Step` — ↑/↓ drag-style reordering by number + direction
- `[4] Set Parallel` — mark steps for concurrent execution with group label
- `[5] Preview Chain` — ASCII tree view of current workflow
- `[6] Save Workflow` — writes to `reconx/data/workflows/custom_<name>.json`
- `[7] Load Workflow` — edit a previously saved custom workflow
- `[0] Back` — exit builder

Saved custom workflows are compatible with `WorkflowPlayer18` and `WorkflowEngine18`.

---

### `workflows/report_18.py` — `inject_workflow_section18()`

Injects two HTML sections into any existing ReconX report:

**Section 1: Workflow Execution**
- Summary pills: workflow name, target, status (colour-coded), duration, step counts
- Step timeline: grid layout with icon (✓/✗/○/⏳), tool name, stage, proportional duration bar, duration, findings count

**Section 2: AI Recommendations**
- One card per `DecisionResult` with severity badge, context paragraph, tool suggestion pills, and ready-to-use command block (target substituted)

`inject_workflow_section18(html_path, run_record)` — idempotent, safe to call on any existing report. Falls back to `</body>` injection if no placeholder is found.

---

### `workflows/__init__.py`

Clean public API exporting all 7 public classes and key types.

---

## Modified Files (1)

### `tui/navigator.py`

- Route `"3"` updated to call `_guided_recon18()` — launches `GuidedRecon18`
- Route `"4b"` added — launches `WorkflowBuilder18`
- `_guided_recon18()` lazy-init method added
- `_workflow_builder18()` lazy-init method added

Both integrate with existing `self.console` and `self.registry`.

---

## Architecture

```
Navigator [3] → GuidedRecon18
                  │
                  ├─ Step 1-3: target / type / objective selection
                  ├─ Step 4: WorkflowTemplateLibrary.get(template_name)
                  ├─ Step 5: action choice
                  ├─ Step 6: _TOOL_LEARN blurbs (18 tools)
                  ├─ Step 7: WorkflowEngine18.execute(template, target)
                  │            ├─ parallel groups → ThreadPoolExecutor
                  │            ├─ per-step: try/except isolation
                  │            ├─ mid-stage: DecisionEngine.recommend()
                  │            └─ per-step: WorkflowRecorder18.checkpoint()
                  └─ Step 8: post-execution recommendations panel

Navigator [4] → WorkflowCenter (Stage 16)
Navigator [4b]→ WorkflowBuilder18
                  ├─ catalogue browser (8 categories, 48 tools)
                  ├─ add/remove/move/parallel step management
                  └─ save to reconx/data/workflows/custom_*.json

WorkflowPlayer18
  ├─ replay()   → WorkflowEngine18.execute(reconstructed_template)
  ├─ resume()   → skip SUCCESS steps → WorkflowEngine18.execute()
  └─ diff()     → Rich comparison table

DecisionEngine
  ├─ 23 rules (port/tag/tech/osint/tls/discovery)
  ├─ recommend(ReconResult)       → list[DecisionResult]
  ├─ recommend_finding(key)       → DecisionResult
  └─ recommend_from_tags(summary) → list[DecisionResult]

report_18.inject_workflow_section18(html, run_record)
  ├─ Summary pills
  ├─ Step timeline (proportional duration bars)
  └─ Recommendation cards with substituted commands
```

---

## Safety Contract

All Stage 18 components maintain the existing ReconX safety contract:

- **Tool isolation**: every `_invoke()` call in `WorkflowEngine18` is wrapped in `try/except`; the error is stored in `StepRecord.error` and execution continues with the next step
- **Registry fallback**: `WorkflowEngine18` without a registry marks all steps `FAILED` gracefully (verified in smoke tests)
- **Recorder non-fatal**: `checkpoint()` failures are caught and logged at `DEBUG` level; they never interrupt execution
- **Navigator lazy-init**: `GuidedRecon18` and `WorkflowBuilder18` are only imported when their routes are selected — no startup cost
- **BaseTool compatibility**: `WorkflowEngine18._invoke()` calls `tool_instance.run(target)` — identical to the existing `ExecutionEngine` contract
- **No breaking changes**: all Stage 16/17 components unchanged; `workflows/` is a new package that imports nothing from `workflow/`
