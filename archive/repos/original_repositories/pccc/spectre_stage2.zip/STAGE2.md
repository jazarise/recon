# Spectre — Stage 2: Task Engine & Execution System

## Overview

Stage 2 delivers the execution backbone that powers all future agents, workflows,
and tool orchestration in Spectre. Every action Spectre takes — from an nmap scan
to a memory write — flows through this pipeline.

```
PlannerAgent / CLI
        │
        ▼
   Scheduler               ← dependency-aware gating
        │
        ▼
   TaskQueue               ← async priority queue (heapq)
        │
        ▼
ExecutionEngine            ← concurrent worker slots
        │
        ▼
WorkerRegistry → Worker    ← typed, swappable executors
        │
        ▼
   TaskResult
        │
   ┌────┴────┐
EventBus   RetryEngine
   │
StatusTracker
```

---

## New Files (Stage 2)

```
spectre/core/tasks/
├── __init__.py            ← full public surface export
├── task.py                ← Task model + state machine + RetryPolicy
├── queue.py               ← Async priority queue (heapq + lazy delete)
├── executor.py            ← ExecutionEngine (concurrent worker slots)
├── worker.py              ← BaseWorker + WorkerRegistry + 9 concrete workers
├── scheduler.py           ← Dependency-aware scheduler + delay loop
├── dependency_graph.py    ← NetworkX DAG with cycle detection
├── retry.py               ← RetryEngine + failure classification
├── events.py              ← EventBus + full event type hierarchy
└── status.py              ← StatusTracker (reactive, EventBus subscriber)
```

---

## Component Reference

### 1. Task Model (`task.py`)

The atomic unit of work. Every agent action is a `Task`.

```python
from spectre.core.tasks import Task, TaskType, TaskPriority, RetryPolicy

task = Task(
    name="nmap_scan",
    type=TaskType.SCAN,
    priority=TaskPriority.HIGH,
    session_id="session-uuid",
    payload={"target": "10.10.10.1", "ports": "1-65535"},
    dependencies=[],                          # IDs of tasks that must complete first
    retry_policy=RetryPolicy(
        max_retries=3,
        backoff_base=2.0,
        backoff_max=60.0,
        retry_on=["timeout", "transient_error"],
    ),
)
```

**State machine:**
```
PENDING → QUEUED → RUNNING → COMPLETED
                           ↘ FAILED → (retry) → QUEUED
                           ↘ CANCELLED
          PAUSED ↗ (resume)
```

All transitions are validated. Illegal transitions raise `ValueError`.

**Priorities:** `CRITICAL=0`, `HIGH=1`, `NORMAL=2`, `LOW=3`, `IDLE=4`

**Task types:** `scan`, `parse`, `web`, `crypto`, `forensics`, `stego`, `reverse`, `privsec`, `memory`, `reasoning`, `generic`

---

### 2. Async Queue (`queue.py`)

Priority queue backed by `heapq`. Lower priority value = dequeued first.
Equal-priority tasks are FIFO by insertion sequence.

```python
from spectre.core.tasks import TaskQueue

queue = TaskQueue(maxsize=0)   # 0 = unlimited

await queue.add_task(task)             # enqueue (PENDING → QUEUED)
task = await queue.get_task(timeout=5) # blocking dequeue
await queue.pause_task(task_id)        # QUEUED → PAUSED (hold without removal)
await queue.resume_task(task_id)       # PAUSED → QUEUED
await queue.remove_task(task_id)       # lazy cancel
task = await queue.get_by_id(task_id)  # O(1) lookup
stats = await queue.stats()            # metrics snapshot
```

**Lazy deletion:** `remove_task()` marks entries as removed without rebuilding
the heap. Stale entries are discarded on the next `get_task()` pop.

---

### 3. Execution Engine (`executor.py`)

Runs `max_concurrent` async slots. Each slot loops: pull → resolve worker → execute → handle result.

```python
from spectre.core.tasks import ExecutionEngine

engine = ExecutionEngine(
    queue=queue,
    worker_registry=registry,
    event_bus=bus,
    max_concurrent=5,        # concurrent slots
    task_timeout=30.0,       # per-task timeout (asyncio.wait_for)
    scheduler=scheduler,     # optional — notifies of completions/failures
)

await engine.start()
# ... application runs ...
await engine.stop(drain_timeout=5.0)

stats = await engine.stats()
# {running, active_tasks, completed_total, failed_total, retried_total, uptime_seconds, ...}
```

**Per-task lifecycle inside a slot:**
1. Pull from queue
2. Validate state
3. Resolve worker via `WorkerRegistry.resolve(task)`
4. Transition `QUEUED → RUNNING`
5. `asyncio.wait_for(worker.execute(task), timeout)`
6. On success → `COMPLETED`, emit `task_completed`, notify scheduler
7. On failure → `FAILED`, pass to `RetryEngine`, emit events

---

### 4. Worker System (`worker.py`)

All workers extend `BaseWorker`. The registry routes tasks by `TaskType`.

```python
from spectre.core.tasks import BaseWorker, WorkerRegistry, TaskResult

class MyCustomWorker(BaseWorker):
    @property
    def worker_type(self) -> str:
        return "my_custom"

    @property
    def handles(self):
        return [TaskType.GENERIC]

    async def on_startup(self):
        # open connections, load wordlists, etc.
        pass

    async def _execute(self, task: Task) -> TaskResult:
        # do the real work here
        return TaskResult(
            success=True,
            data={"result": "..."},
            raw_output="raw tool output",
        )

registry = WorkerRegistry()
await registry.register(MyCustomWorker())
```

**Registered workers (Stage 2 stubs):**

| Worker | Type | Planned tools (Stage 3) |
|---|---|---|
| `GenericWorker` | generic | catch-all |
| `ScanWorker` | scan | nmap, masscan, rustscan |
| `ParseWorker` | parse | ParserEngine entity extraction |
| `WebWorker` | web | gobuster, nikto, curl, whatweb |
| `CryptoWorker` | crypto | hashid, john, openssl |
| `ForensicsWorker` | forensics | volatility3, foremost, tshark |
| `StegoWorker` | stego | steghide, zsteg, binwalk, exiftool |
| `ReverseWorker` | reverse | radare2, ghidra, strings |
| `MemoryWorker` | memory | MemorySystem (Stage 4) |

---

### 5. Scheduler (`scheduler.py`)

Gates tasks on dependency completion and optional time delays.

```python
from spectre.core.tasks import Scheduler

scheduler = Scheduler(queue=queue)
await scheduler.start()

# Task with no deps — queued immediately
await scheduler.submit(task_a)

# Task that waits for task_a to complete
task_b = Task(name="service_parse", dependencies=[task_a.id])
await scheduler.submit(task_b)

# Delayed task — queued after 10 seconds
await scheduler.submit(task_c, delay_seconds=10.0)

# Notify completion → unblocks dependents
await scheduler.notify_completed(task_a.id)

# Notify failure → cancels downstream
await scheduler.notify_failed(task_a.id)

await scheduler.stop()
```

**Chain example:**
```
nmap_scan → service_parser → web_workflow → flag_extraction
```
Submit all four tasks with appropriate `dependencies`. The scheduler
promotes each task to the queue only when its parent completes.

---

### 6. Dependency Graph (`dependency_graph.py`)

NetworkX `DiGraph` with cycle detection and topological ordering.

```python
from spectre.core.tasks import DependencyGraph

graph = DependencyGraph()
graph.add_task("task-a", name="nmap_scan")
graph.add_task("task-b", name="service_parser")
graph.add_dependency("task-a", "task-b")   # b depends on a

graph.mark_completed("task-a")
assert graph.is_ready("task-b")            # True

order = graph.topological_order()          # ["task-a", "task-b"]
blocked = graph.blocked_by_failure("task-a")  # all downstream IDs
```

**Cycle detection** is enforced on every `add_dependency()` call.
Any edge that would create a cycle raises `ValueError` immediately.

---

### 7. Retry Engine (`retry.py`)

```python
from spectre.core.tasks import RetryEngine, classify_failure, FailureClass

classify_failure(asyncio.TimeoutError())    # → "timeout"
classify_failure(ConnectionError())        # → "transient_error"
classify_failure(ValueError())             # → "permanent_error"
classify_failure(None, "timed out after") # → "timeout" (message scan)
```

**Retry logic:**
- `permanent_error` → never retried
- Failure class not in `retry_on` → not retried
- Retries exhausted → not retried, `TaskFailedEvent` emitted
- Otherwise → `asyncio.sleep(backoff)` then re-enqueue

**Backoff formula:** `min(base ** attempt, max_seconds)`

---

### 8. Event Bus (`events.py`)

Decoupled publish/subscribe. Publishers never wait for handlers.

```python
from spectre.core.tasks import EventBus, EventType, TaskCompletedEvent

bus = EventBus()

# Subscribe
@bus.on(EventType.TASK_COMPLETED)
async def on_complete(event: TaskCompletedEvent) -> None:
    print(f"Done: {event.task_name} in {event.duration_seconds:.2f}s")

# Wildcard — receives everything
bus.subscribe_all(my_logger)

# Publish
await bus.publish(TaskCompletedEvent(
    source="ExecutionEngine",
    task_id=task.id,
    task_name=task.name,
    task_type=task.type.value,
    duration_seconds=1.23,
))
```

**All event types:**
`task_created`, `task_queued`, `task_started`, `task_completed`,
`task_failed`, `task_cancelled`, `task_paused`, `task_resumed`,
`task_retrying`, `engine_started`, `engine_stopped`

---

### 9. Status Tracker (`status.py`)

Reactive aggregator — subscribes to the event bus, never mutates tasks.

```python
from spectre.core.tasks import StatusTracker

tracker = StatusTracker(event_bus=bus)

# CLI summary
summary = tracker.cli_summary()
# {"Running": 2, "Completed": 25, "Failed": 1, "Cancelled": 0, "Retried": 3}

# Full snapshot
snap = await tracker.snapshot(queue=queue, scheduler=scheduler)
# {uptime_seconds, tasks: {running, completed, failed, ...}, by_type: {...}, ...}

# Recent event log
log = tracker.recent_event_log(limit=20)
```

---

## CLI Commands (Stage 2)

```bash
# Task management
spectre task status                              # live engine metrics
spectre task list                               # queued + paused tasks
spectre task submit --name nmap --type scan --priority high \
    --payload '{"target":"10.10.10.1"}'         # submit to queue
spectre task cancel <id-prefix>                 # cancel a queued task
spectre task workers                            # list registered workers

# Engine control
spectre engine start                            # start engine + run until Ctrl-C
spectre engine start --slots 10 --timeout 60   # override config
spectre engine status                           # show config + queue depth
```

**`spectre task status` output:**
```
╭──────────────────────────────╮
│     Task Engine Status       │
├──────────────┬───────────────┤
│ Queue        │ 8             │
│ Running      │ 2             │
│ Completed    │ 25            │
│ Failed       │ 1             │
│ Cancelled    │ 0             │
│ Retried      │ 3             │
╰──────────────┴───────────────╯
```

---

## Configuration (`config/default.yaml`)

```yaml
task_engine:
  max_concurrent_tasks: 5       # ExecutionEngine parallel slots
  task_timeout_seconds: 30.0    # per-task asyncio.wait_for timeout
  queue_maxsize: 0              # 0 = unlimited
  default_max_retries: 3
  default_backoff_base: 2.0
  default_backoff_max: 60.0
  scheduler_poll_interval: 0.5
  status_history_limit: 100
```

Override via environment variables:
```bash
SPECTRE_TASK_ENGINE_MAX_CONCURRENT_TASKS=10
SPECTRE_TASK_ENGINE_TASK_TIMEOUT_SECONDS=60
```

---

## Running the Engine

```bash
# Start the full engine (blocking, Ctrl-C to stop)
spectre engine start

# Submit tasks while engine runs (from another terminal)
spectre task submit --name "nmap_scan" --type scan \
    --priority high --payload '{"target":"10.10.10.1"}'

# Watch status
spectre task status
```

---

## Running Tests

```bash
# Stage 2 tests only
pytest tests/test_stage2.py -v

# All stages
pytest tests/ -v

# With coverage
pytest tests/test_stage2.py -v --cov=spectre.core.tasks --cov-report=term-missing

# Specific component
pytest tests/test_stage2.py -v -k "TestTaskQueue"
pytest tests/test_stage2.py -v -k "TestExecutionEngine"
pytest tests/test_stage2.py -v -k "TestScheduler"
```

---

## Stage Roadmap

| Stage | System | Status |
|---|---|---|
| 1 | Foundation (config, logging, sessions, plugins, CLI) | ✅ Complete |
| 2 | Task Engine (queue, executor, workers, scheduler, events) | ✅ Complete |
| 3 | Tool Wrappers + Parser Engine + Knowledge Graph | 🔜 Next |
| 4 | Memory System (working, episodic, semantic, long-term) | ⬜ |
| 5 | Reasoning Engine + PlannerAgent + Workflow Intelligence | ⬜ |
| 6 | REST API + Web UI + Dataset Export | ⬜ |

---

## Integration Points for Stage 3

The following `TODO Stage 3` hooks are wired throughout the codebase:

- `executor.py` → `_handle_success()` → call `ParserEngine` on `result.raw_output`
- `worker.py` → `ParseWorker._execute()` → real entity extraction
- `worker.py` → `ScanWorker._execute()` → real nmap XML parsing
- `dependency_graph.py` → persist to `KnowledgeGraph` (Neo4j) alongside host nodes
- `events.py` → `GRAPH_NODE_ADDED`, `GRAPH_EDGE_CREATED` event types (reserved)
- `task.py` → `TaskResult.graph_entities: List[GraphEntity]` field (reserved)
