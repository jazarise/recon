"""
spectre/cli/main.py

Typer-based CLI for Spectre.

Stage 1 commands:
    spectre start
    spectre status
    spectre session list / new / show
    spectre plugin list

Stage 2 commands:
    spectre task submit   — submit a task to the engine
    spectre task status   — live task engine metrics
    spectre task list     — show queued and active tasks
    spectre task cancel   — cancel a queued task
    spectre engine start  — start the execution engine (async loop)
    spectre engine status — show engine metrics

TODO Stage 3: spectre graph  commands
TODO Stage 4: spectre memory commands
TODO Stage 5: spectre plan   commands
"""

from __future__ import annotations

import asyncio
from typing import Optional

import typer
from rich import box
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from spectre.core.app import SpectreApp
from spectre.core.config import get_settings

# ---------------------------------------------------------------------------
# CLI app and sub-apps
# ---------------------------------------------------------------------------

app = typer.Typer(
    name="spectre",
    help="[bold cyan]Spectre[/bold cyan] — AI-powered CTF intelligence platform.",
    rich_markup_mode="rich",
    no_args_is_help=True,
)

session_app = typer.Typer(help="Session management commands.")
plugin_app  = typer.Typer(help="Plugin management commands.")
task_app    = typer.Typer(help="Task engine commands.")
engine_app  = typer.Typer(help="Execution engine commands.")

app.add_typer(session_app, name="session")
app.add_typer(plugin_app,  name="plugin")
app.add_typer(task_app,    name="task")
app.add_typer(engine_app,  name="engine")

console = Console()

# Module-level singleton
_spectre: Optional[SpectreApp] = None


def _get_app() -> SpectreApp:
    global _spectre
    if _spectre is None:
        _spectre = SpectreApp()
        _spectre.initialize_sync()
    return _spectre


# ---------------------------------------------------------------------------
# UI helpers
# ---------------------------------------------------------------------------

def _print_banner() -> None:
    banner = Text()
    banner.append("  ██████  ██▓███  ▓█████  ▄████▄  ▄▄▄█████▓ ██▀███  ▓█████ \n", style="bold cyan")
    banner.append("▒██    ▒ ▓██░  ██▒▓█   ▀ ▒██▀ ▀█  ▓  ██▒ ▓▒▓██ ▒ ██▒▓█   ▀ \n", style="cyan")
    banner.append("░ ▓██▄   ▓██░ ██▓▒▒███   ▒▓█    ▄ ▒ ▓██░ ▒░▓██ ░▄█ ▒▒███   \n", style="blue")
    banner.append("  ▒   ██▒▒██▄█▓▒ ▒▒▓█  ▄ ▒▓▓▄ ▄██▒░ ▓██▓ ░ ▒██▀▀█▄  ▒▓█  ▄ \n", style="blue")
    banner.append("▒██████▒▒▒██▒ ░  ░░▒████▒▒ ▓███▀ ░  ▒██▒ ░ ░██▓ ▒██▒░▒████▒\n", style="bold blue")
    banner.append("  Stage 2: Task Engine & Execution System\n", style="bold white")
    console.print(Panel(banner, border_style="cyan", padding=(0, 2)))


def _kv_table(data: dict, title: str = "") -> Table:
    table = Table(
        box=box.ROUNDED, border_style="cyan",
        show_header=False, padding=(0, 2),
        title=title if title else None,
    )
    table.add_column("Key",   style="bold cyan", width=26)
    table.add_column("Value", style="white")
    for k, v in data.items():
        if isinstance(v, dict):
            table.add_row(k, str(v))
        elif isinstance(v, bool):
            table.add_row(k, "[green]yes[/green]" if v else "[red]no[/red]")
        else:
            table.add_row(k, str(v))
    return table


# ---------------------------------------------------------------------------
# Core commands
# ---------------------------------------------------------------------------

@app.command("start")
def cmd_start() -> None:
    """Initialize Spectre and display startup status."""
    _print_banner()
    with console.status("[cyan]Initializing Spectre...[/cyan]", spinner="dots"):
        spectre = _get_app()

    status = spectre.status_sync()
    te = status.get("task_engine", {})

    rows = {
        "Application":       f"{status['app']} v{status['version']}",
        "Environment":       status["environment"],
        "Status":            "[green]Ready[/green]" if status["ready"] else "[red]Not Ready[/red]",
        "Sessions (active)": str(status["sessions"]["active"]),
        "Sessions (total)":  str(status["sessions"]["total"]),
        "Plugins loaded":    str(status["plugins"]["loaded"]),
        "Log level":         status["logging"]["level"],
        "Task engine":       te.get("note", "inactive"),
    }

    console.print()
    console.print(Panel(_kv_table(rows), title="[bold cyan]Spectre Status[/bold cyan]", border_style="cyan"))
    console.print()
    console.print("[bold green]✓[/bold green] [bold white]Spectre initialized[/bold white]")
    console.print(f"  Session:        [green]active[/green]")
    console.print(f"  Plugins:        [green]{status['plugins']['loaded']} loaded[/green]")
    console.print(f"  Logging:        [green]enabled[/green]")
    console.print(f"  Configuration:  [green]loaded ({spectre.settings.app.environment})[/green]")
    console.print(f"  Task engine:    [yellow]inactive — run 'spectre engine start'[/yellow]")
    console.print()


@app.command("status")
def cmd_status() -> None:
    """Show current application status."""
    with console.status("[cyan]Fetching status...[/cyan]", spinner="dots"):
        spectre = _get_app()
    status = spectre.status_sync()
    console.print(Panel(_kv_table(status), title="[bold cyan]Spectre Status[/bold cyan]", border_style="cyan"))


# ---------------------------------------------------------------------------
# Session subcommands (Stage 1 — preserved)
# ---------------------------------------------------------------------------

@session_app.command("list")
def session_list() -> None:
    """List all sessions."""
    spectre = _get_app()
    sessions = spectre.session_manager.list_sessions()
    if not sessions:
        console.print("[yellow]No sessions found.[/yellow]  Create one: [cyan]spectre session new[/cyan]")
        return

    table = Table(title="Sessions", box=box.ROUNDED, border_style="cyan", header_style="bold cyan")
    table.add_column("ID", width=10)
    table.add_column("Name", width=24)
    table.add_column("Target", width=20)
    table.add_column("Category", width=12)
    table.add_column("Status", width=12)
    table.add_column("Created", width=18)

    colors = {"active":"green","paused":"yellow","completed":"blue","archived":"dim","error":"red"}
    for s in sessions:
        sm = s.to_summary()
        c = colors.get(sm["status"], "white")
        table.add_row(sm["id"], sm["name"], sm["target"], sm["category"],
                      f"[{c}]{sm['status']}[/{c}]", sm["created"])
    console.print(table)


@session_app.command("new")
def session_new(
    name:     str = typer.Option("Unnamed Session", "--name",     "-n"),
    target:   str = typer.Option("",               "--target",   "-t"),
    category: str = typer.Option("unknown",         "--category", "-c"),
) -> None:
    """Create a new session."""
    spectre = _get_app()
    from spectre.sessions.models import ChallengeCategory, SessionMeta
    try:
        cat = ChallengeCategory(category.lower())
    except ValueError:
        cat = ChallengeCategory.UNKNOWN
    meta = SessionMeta(category=cat)
    s = spectre.session_manager.create_session(name=name, target=target, meta=meta)
    console.print(f"\n[bold green]✓[/bold green] Session created  [cyan]{s.id[:8]}[/cyan]  {s.name}\n")


@session_app.command("show")
def session_show(session_id: str = typer.Argument(..., help="Session ID prefix")) -> None:
    """Show details of a specific session."""
    spectre = _get_app()
    matches = [s for s in spectre.session_manager.list_sessions() if s.id.startswith(session_id)]
    if not matches:
        console.print(f"[red]No session matching '{session_id}'[/red]"); raise typer.Exit(1)
    if len(matches) > 1:
        console.print("[yellow]Ambiguous prefix.[/yellow]"); raise typer.Exit(1)
    s = matches[0]
    rows = {
        "ID": s.id, "Name": s.name, "Target": s.target or "—",
        "Status": s.status, "Category": s.meta.category,
        "Workspace": s.workspace_path or "—",
        "Created": s.created_at.strftime("%Y-%m-%d %H:%M UTC"),
    }
    console.print(Panel(_kv_table(rows), title=f"[bold cyan]Session: {s.name}[/bold cyan]", border_style="cyan"))


# ---------------------------------------------------------------------------
# Plugin subcommands (Stage 1 — preserved)
# ---------------------------------------------------------------------------

@plugin_app.command("list")
def plugin_list() -> None:
    """List all loaded plugins."""
    spectre = _get_app()
    plugins = spectre.plugin_registry.list_all()
    if not plugins:
        console.print("[yellow]No plugins loaded.[/yellow]"); return

    table = Table(title="Loaded Plugins", box=box.ROUNDED, border_style="cyan", header_style="bold cyan")
    table.add_column("Name", width=16)
    table.add_column("Version", width=10)
    table.add_column("Category", width=14)
    table.add_column("Capabilities", width=40)
    table.add_column("Loaded", width=8)

    for p in plugins:
        caps = ", ".join(p["capabilities"][:3])
        if len(p["capabilities"]) > 3:
            caps += f" +{len(p['capabilities']) - 3}"
        table.add_row(p["name"], p["version"], p["category"], caps or "—",
                      "[green]✓[/green]" if p["loaded"] else "[red]✗[/red]")
    console.print(table)


# ---------------------------------------------------------------------------
# Task subcommands — Stage 2
# ---------------------------------------------------------------------------

@task_app.command("status")
def task_status() -> None:
    """
    Show live task engine metrics.

    Expected output:
        Queue:     8
        Running:   2
        Completed: 25
        Failed:    1
    """
    spectre = _get_app()
    tracker = spectre.status_tracker.cli_summary()
    queue_depth = len(spectre.task_queue)   # sync best-effort

    console.print()
    table = Table(
        title="Task Engine Status",
        box=box.ROUNDED,
        border_style="cyan",
        header_style="bold cyan",
        show_header=False,
        padding=(0, 3),
    )
    table.add_column("Metric", style="bold cyan", width=18)
    table.add_column("Value", style="white", width=10)

    table.add_row("Queue",     str(queue_depth))
    table.add_row("Running",   str(tracker.get("Running", 0)))
    table.add_row("Completed", str(tracker.get("Completed", 0)))
    table.add_row("Failed",    str(tracker.get("Failed", 0)))
    table.add_row("Cancelled", str(tracker.get("Cancelled", 0)))
    table.add_row("Retried",   str(tracker.get("Retried", 0)))

    console.print(Panel(table, border_style="cyan"))

    # Recent events
    events = spectre.status_tracker.recent_event_log(limit=8)
    if events:
        console.print()
        evt_table = Table(
            title="Recent Events",
            box=box.SIMPLE,
            border_style="dim",
            header_style="bold dim",
        )
        evt_table.add_column("Time", width=10)
        evt_table.add_column("Status", width=14)
        evt_table.add_column("Task", width=24)
        evt_table.add_column("Type", width=12)
        evt_table.add_column("ID", width=10)

        status_colors = {
            "STARTED": "green", "COMPLETED": "bold green",
            "FAILED": "red", "RETRYING": "yellow",
            "CANCELLED": "dim", "ENGINE_STARTED": "cyan",
        }
        for ev in reversed(events):
            sc = status_colors.get(ev["status"], "white")
            evt_table.add_row(
                ev.get("ts", "—"),
                f"[{sc}]{ev['status']}[/{sc}]",
                ev.get("name", "—"),
                ev.get("type", "—"),
                ev.get("id", "—"),
            )
        console.print(evt_table)


@task_app.command("list")
def task_list() -> None:
    """List all queued and paused tasks."""
    spectre = _get_app()

    async def _list():
        queued = await spectre.task_queue.list_queued()
        paused = await spectre.task_queue.list_paused()
        return queued, paused

    queued, paused = asyncio.run(_list())

    if not queued and not paused:
        console.print("[yellow]No tasks in queue.[/yellow]")
        console.print("  Submit one with: [cyan]spectre task submit --name <name> --type <type>[/cyan]")
        return

    if queued:
        table = Table(
            title=f"Queued Tasks ({len(queued)})",
            box=box.ROUNDED, border_style="cyan", header_style="bold cyan",
        )
        table.add_column("ID",       width=10)
        table.add_column("Name",     width=24)
        table.add_column("Type",     width=12)
        table.add_column("Priority", width=10)
        table.add_column("Retries",  width=8)
        table.add_column("Session",  width=10)

        for t in queued:
            sm = t.to_summary()
            table.add_row(
                sm["id"], sm["name"], sm["type"],
                sm["priority"], str(sm["retries"]), sm["session"],
            )
        console.print(table)

    if paused:
        p_table = Table(
            title=f"Paused Tasks ({len(paused)})",
            box=box.ROUNDED, border_style="yellow", header_style="bold yellow",
        )
        p_table.add_column("ID",   width=10)
        p_table.add_column("Name", width=24)
        p_table.add_column("Type", width=12)
        for t in paused:
            sm = t.to_summary()
            p_table.add_row(sm["id"], sm["name"], sm["type"])
        console.print(p_table)


@task_app.command("submit")
def task_submit(
    name:       str = typer.Option(...,        "--name",       "-n", help="Task name"),
    task_type:  str = typer.Option("generic",  "--type",       "-t", help="Task type (scan/web/crypto/parse/...)"),
    priority:   str = typer.Option("normal",   "--priority",   "-p", help="Priority: critical/high/normal/low/idle"),
    session_id: str = typer.Option("",        "--session",    "-s", help="Session ID to associate"),
    payload:    str = typer.Option("{}",       "--payload",    help="JSON payload string"),
) -> None:
    """Submit a task to the execution engine queue."""
    import json
    from spectre.core.tasks.task import Task, TaskType, TaskPriority

    spectre = _get_app()

    # Parse task type
    try:
        ttype = TaskType(task_type.lower())
    except ValueError:
        console.print(f"[red]Unknown task type '{task_type}'.[/red]")
        console.print(f"  Valid types: {', '.join(t.value for t in TaskType)}")
        raise typer.Exit(1)

    # Parse priority
    priority_map = {
        "critical": TaskPriority.CRITICAL,
        "high":     TaskPriority.HIGH,
        "normal":   TaskPriority.NORMAL,
        "low":      TaskPriority.LOW,
        "idle":     TaskPriority.IDLE,
    }
    tpriority = priority_map.get(priority.lower(), TaskPriority.NORMAL)

    # Parse payload
    try:
        payload_dict = json.loads(payload)
    except json.JSONDecodeError:
        console.print(f"[red]Invalid JSON payload.[/red]")
        raise typer.Exit(1)

    task = Task(
        name=name,
        type=ttype,
        priority=tpriority,
        session_id=session_id or None,
        payload=payload_dict,
    )

    async def _submit():
        await spectre.task_queue.add_task(task)

    asyncio.run(_submit())

    console.print(f"\n[bold green]✓[/bold green] Task submitted")
    console.print(f"  ID:       [cyan]{task.id[:8]}[/cyan]")
    console.print(f"  Name:     {task.name}")
    console.print(f"  Type:     {task.type.value}")
    console.print(f"  Priority: {task.priority.name}")
    console.print(f"  Queue:    [green]{len(spectre.task_queue)} task(s)[/green]")
    console.print()


@task_app.command("cancel")
def task_cancel(
    task_id: str = typer.Argument(..., help="Task ID prefix to cancel"),
) -> None:
    """Cancel a queued or paused task."""
    spectre = _get_app()

    async def _cancel():
        queued = await spectre.task_queue.list_queued()
        paused = await spectre.task_queue.list_paused()
        all_tasks = queued + paused
        matches = [t for t in all_tasks if t.id.startswith(task_id)]

        if not matches:
            return None, "not_found"
        if len(matches) > 1:
            return None, "ambiguous"

        target = matches[0]
        ok = await spectre.task_queue.remove_task(target.id)
        return target, "ok" if ok else "error"

    task, result = asyncio.run(_cancel())

    if result == "not_found":
        console.print(f"[red]No queued task matching '{task_id}'[/red]")
        raise typer.Exit(1)
    elif result == "ambiguous":
        console.print("[yellow]Ambiguous ID prefix — use more characters.[/yellow]")
        raise typer.Exit(1)
    elif result == "ok":
        console.print(f"\n[bold green]✓[/bold green] Task cancelled  [cyan]{task.id[:8]}[/cyan]  {task.name}\n")
    else:
        console.print(f"[red]Failed to cancel task.[/red]")
        raise typer.Exit(1)


@task_app.command("workers")
def task_workers() -> None:
    """List all registered workers and their stats."""
    spectre = _get_app()

    async def _register_workers():
        from spectre.core.tasks.worker import DEFAULT_WORKERS
        for cls in DEFAULT_WORKERS:
            try:
                await spectre.worker_registry.register(cls())
            except Exception:
                pass  # may already be registered in sync mode

    # In sync mode workers aren't registered — run the async setup
    asyncio.run(_register_workers())

    workers = spectre.worker_registry.list_workers()
    if not workers:
        console.print("[yellow]No workers registered.[/yellow]")
        return

    table = Table(
        title=f"Registered Workers ({len(workers)})",
        box=box.ROUNDED, border_style="cyan", header_style="bold cyan",
    )
    table.add_column("ID",        width=10)
    table.add_column("Type",      width=14)
    table.add_column("Handles",   width=30)
    table.add_column("Completed", width=10)
    table.add_column("Failed",    width=8)
    table.add_column("Active",    width=10)

    for w in workers:
        table.add_row(
            w["id"],
            w["worker_type"],
            ", ".join(w["handles"]),
            str(w["tasks_completed"]),
            str(w["tasks_failed"]),
            w["active_task"][:8] if w["active_task"] else "—",
        )
    console.print(table)


# ---------------------------------------------------------------------------
# Engine subcommands — Stage 2
# ---------------------------------------------------------------------------

@engine_app.command("start")
def engine_start(
    slots:   int   = typer.Option(0,    "--slots",   "-s", help="Concurrent slots (0 = from config)"),
    timeout: float = typer.Option(0.0,  "--timeout", "-t", help="Task timeout seconds (0 = from config)"),
) -> None:
    """
    Start the execution engine and run until Ctrl-C.

    The engine pulls tasks from the queue and dispatches them
    to registered workers continuously.
    """
    spectre = _get_app()

    # Override settings from CLI flags
    if slots > 0:
        spectre.settings.task_engine.max_concurrent_tasks = slots
    if timeout > 0:
        spectre.settings.task_engine.task_timeout_seconds = timeout

    async def _run() -> None:
        await spectre.initialize()
        console.print()
        console.print(Panel(
            f"[bold green]Execution Engine Running[/bold green]\n"
            f"  Slots:   {spectre.settings.task_engine.max_concurrent_tasks}\n"
            f"  Timeout: {spectre.settings.task_engine.task_timeout_seconds}s\n"
            f"  Workers: {len(spectre.worker_registry.list_workers())}\n\n"
            f"  Press [bold]Ctrl-C[/bold] to stop.",
            border_style="green",
        ))
        try:
            # Keep the event loop alive
            while True:
                await asyncio.sleep(1.0)
        except asyncio.CancelledError:
            pass
        finally:
            await spectre.shutdown()

    try:
        asyncio.run(_run())
    except KeyboardInterrupt:
        console.print("\n[yellow]Engine stopped by user.[/yellow]")


@engine_app.command("status")
def engine_status() -> None:
    """Show execution engine configuration and worker list."""
    spectre = _get_app()
    cfg = spectre.settings.task_engine

    rows = {
        "Engine state":          "[yellow]inactive (CLI mode)[/yellow]",
        "Max concurrent slots":  str(cfg.max_concurrent_tasks),
        "Task timeout":          f"{cfg.task_timeout_seconds}s",
        "Queue max size":        str(cfg.queue_maxsize) if cfg.queue_maxsize else "unlimited",
        "Default max retries":   str(cfg.default_max_retries),
        "Backoff base":          str(cfg.default_backoff_base),
        "Backoff max":           f"{cfg.default_backoff_max}s",
        "Queue depth (current)": str(len(spectre.task_queue)),
    }
    console.print(Panel(
        _kv_table(rows),
        title="[bold cyan]Execution Engine Configuration[/bold cyan]",
        border_style="cyan",
    ))
