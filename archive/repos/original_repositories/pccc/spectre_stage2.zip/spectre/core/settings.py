"""
spectre/core/settings.py

Strongly-typed configuration models using Pydantic.
All settings are validated at startup. Unknown fields are forbidden
to catch typos and config drift early.

Stage 1: Foundation & Core Skeleton
TODO Stage 2: Add AgentSettings, MemorySettings
TODO Stage 3: Add GraphSettings, VectorDBSettings
TODO Stage 4: Add ReasoningEngineSettings
"""

from __future__ import annotations

from pathlib import Path
from typing import List, Optional

from pydantic import BaseModel, Field, field_validator


# ---------------------------------------------------------------------------
# Sub-models
# ---------------------------------------------------------------------------

class AppSettings(BaseModel):
    """Top-level application identity and environment settings."""

    name: str = "Spectre"
    version: str = "0.1.0"
    stage: str = "1"
    description: str = "AI-powered CTF assistant and challenge-intelligence platform"
    environment: str = "development"
    debug: bool = True

    @field_validator("environment")
    @classmethod
    def validate_environment(cls, v: str) -> str:
        allowed = {"development", "production", "testing"}
        if v not in allowed:
            raise ValueError(f"environment must be one of {allowed}, got '{v}'")
        return v


class WorkspaceSettings(BaseModel):
    """File-system paths used by Spectre at runtime."""

    base_path: Path = Path("./sessions")
    logs_path: Path = Path("./logs")
    datasets_path: Path = Path("./datasets")
    plugins_path: Path = Path("./plugins")

    def ensure_directories(self) -> None:
        """Create workspace directories if they do not exist."""
        for field_name in self.model_fields:
            path: Path = getattr(self, field_name)
            path.mkdir(parents=True, exist_ok=True)


class SessionSettings(BaseModel):
    """Session persistence and lifecycle settings."""

    auto_save: bool = True
    save_interval_seconds: int = Field(default=30, ge=5)
    max_sessions: int = Field(default=100, ge=1)
    session_file_format: str = "json"

    @field_validator("session_file_format")
    @classmethod
    def validate_format(cls, v: str) -> str:
        allowed = {"json", "yaml"}
        if v not in allowed:
            raise ValueError(f"session_file_format must be one of {allowed}")
        return v


class LoggingSettings(BaseModel):
    """Logging configuration for loguru."""

    level: str = "DEBUG"
    console: bool = True
    file: bool = True
    file_path: Path = Path("./logs/spectre.log")
    rotation: str = "10 MB"
    retention: str = "7 days"
    format: str = "[{time:YYYY-MM-DD HH:mm:ss}] [{level}] {name} | {message}"

    @field_validator("level")
    @classmethod
    def validate_level(cls, v: str) -> str:
        allowed = {"TRACE", "DEBUG", "INFO", "SUCCESS", "WARNING", "ERROR", "CRITICAL"}
        if v.upper() not in allowed:
            raise ValueError(f"log level must be one of {allowed}")
        return v.upper()


class PluginSettings(BaseModel):
    """Plugin discovery and enable/disable lists."""

    auto_discover: bool = True
    enabled: List[str] = Field(default_factory=list)
    disabled: List[str] = Field(default_factory=list)


class ThreadingSettings(BaseModel):
    """Concurrency limits for tool execution and async tasks."""

    max_threads: int = Field(default=10, ge=1, le=256)
    max_async_tasks: int = Field(default=50, ge=1)
    tool_timeout_seconds: int = Field(default=30, ge=1)


class TaskEngineSettings(BaseModel):
    """
    Configuration for the Stage 2 Task Engine & Execution System.

    Controls concurrency, timeouts, retry behaviour, and queue limits
    for the ExecutionEngine, TaskQueue, Scheduler, and RetryEngine.
    """

    # ExecutionEngine
    max_concurrent_tasks: int = Field(default=5, ge=1, le=64,
        description="Number of parallel worker slots in the ExecutionEngine")
    task_timeout_seconds: float = Field(default=30.0, ge=1.0,
        description="Per-task execution timeout before forced cancellation")

    # TaskQueue
    queue_maxsize: int = Field(default=0, ge=0,
        description="Maximum queue depth (0 = unlimited)")

    # Retry defaults (per-task RetryPolicy overrides these)
    default_max_retries: int = Field(default=3, ge=0, le=20)
    default_backoff_base: float = Field(default=2.0, ge=1.0)
    default_backoff_max: float = Field(default=60.0, ge=1.0)

    # Scheduler
    scheduler_poll_interval: float = Field(default=0.5, ge=0.1,
        description="Seconds between delay-queue polls in the Scheduler")

    # Status / observability
    status_history_limit: int = Field(default=100, ge=10,
        description="Number of task events retained in the status tracker ring buffer")

    # TODO Stage 3: Add parser_engine settings block
    # TODO Stage 4: Add memory_worker settings block
    # TODO Stage 5: Add reasoning_engine integration flags


# ---------------------------------------------------------------------------
# Root settings model
# ---------------------------------------------------------------------------

class SpectreSettings(BaseModel):
    """
    Root validated configuration model for Spectre.

    Assembled by core/config.py from YAML files and environment variables.
    All downstream components should consume this object rather than reading
    config files directly.
    """

    app: AppSettings = Field(default_factory=AppSettings)
    workspace: WorkspaceSettings = Field(default_factory=WorkspaceSettings)
    session: SessionSettings = Field(default_factory=SessionSettings)
    logging: LoggingSettings = Field(default_factory=LoggingSettings)
    plugins: PluginSettings = Field(default_factory=PluginSettings)
    threading: ThreadingSettings = Field(default_factory=ThreadingSettings)
    task_engine: TaskEngineSettings = Field(default_factory=TaskEngineSettings)

    # TODO Stage 3: graph: GraphSettings
    # TODO Stage 4: memory: MemorySettings
    # TODO Stage 5: reasoning: ReasoningEngineSettings

    model_config = {"extra": "ignore"}  # gracefully ignore unknown keys
