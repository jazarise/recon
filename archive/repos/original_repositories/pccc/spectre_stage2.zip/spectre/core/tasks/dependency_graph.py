"""
spectre/core/tasks/dependency_graph.py

Task dependency graph for the Spectre execution engine.

Uses NetworkX directed graph (DiGraph) to model task relationships.
The scheduler queries this graph to determine which tasks are ready
to execute (all dependencies completed).

Features:
- Add task nodes and dependency edges
- Detect cycles (deadlock prevention)
- Topological ordering for scheduling
- Ready-task discovery (dependencies satisfied)
- Subgraph visualization for debugging

Example dependency chain:
    nmap_scan → service_parser → web_workflow → flag_extraction

Stage 2: Task Engine & Execution System
TODO Stage 3: Persist graph to KnowledgeGraph (Neo4j) alongside host/service nodes
TODO Stage 5: ReasoningEngine uses dependency graph to plan multi-step workflows
"""

from __future__ import annotations

from typing import Any, Dict, FrozenSet, Generator, List, Optional, Set

from spectre.core.logger import get_logger

log = get_logger(__name__)

try:
    import networkx as nx
    _NX_AVAILABLE = True
except ImportError:
    _NX_AVAILABLE = False
    log.warning("networkx not installed — DependencyGraph will use fallback mode")


# ---------------------------------------------------------------------------
# Fallback lightweight graph (if networkx is absent)
# ---------------------------------------------------------------------------

class _FallbackGraph:
    """Minimal DAG implementation when networkx is not available."""

    def __init__(self) -> None:
        self._nodes: Dict[str, Dict] = {}
        self._edges: Dict[str, Set[str]] = {}  # parent → children

    def add_node(self, node_id: str, **attrs: Any) -> None:
        self._nodes[node_id] = attrs
        self._edges.setdefault(node_id, set())

    def remove_node(self, node_id: str) -> None:
        self._nodes.pop(node_id, None)
        self._edges.pop(node_id, None)
        for children in self._edges.values():
            children.discard(node_id)

    def add_edge(self, parent: str, child: str) -> None:
        self._edges.setdefault(parent, set()).add(child)

    def has_node(self, node_id: str) -> bool:
        return node_id in self._nodes

    def predecessors(self, node_id: str) -> List[str]:
        return [p for p, children in self._edges.items() if node_id in children]

    def successors(self, node_id: str) -> List[str]:
        return list(self._edges.get(node_id, set()))

    def nodes(self) -> List[str]:
        return list(self._nodes.keys())

    def has_cycle(self) -> bool:
        """DFS-based cycle detection."""
        visited: Set[str] = set()
        rec_stack: Set[str] = set()

        def dfs(node: str) -> bool:
            visited.add(node)
            rec_stack.add(node)
            for child in self._edges.get(node, set()):
                if child not in visited:
                    if dfs(child):
                        return True
                elif child in rec_stack:
                    return True
            rec_stack.discard(node)
            return False

        for node in self._nodes:
            if node not in visited:
                if dfs(node):
                    return True
        return False

    def topological_sort(self) -> List[str]:
        in_degree: Dict[str, int] = {n: 0 for n in self._nodes}
        for children in self._edges.values():
            for child in children:
                in_degree[child] = in_degree.get(child, 0) + 1

        queue = [n for n, d in in_degree.items() if d == 0]
        result: List[str] = []
        while queue:
            node = queue.pop(0)
            result.append(node)
            for child in self._edges.get(node, set()):
                in_degree[child] -= 1
                if in_degree[child] == 0:
                    queue.append(child)
        return result


# ---------------------------------------------------------------------------
# DependencyGraph
# ---------------------------------------------------------------------------

class DependencyGraph:
    """
    Directed acyclic graph (DAG) tracking task dependencies.

    Nodes:  Task IDs
    Edges:  parent_id → child_id means "child depends on parent"
            (child cannot start until parent is COMPLETED)

    The graph maintains a `completed_ids` set so that ready-task
    discovery (is_ready) does not require scanning all nodes.
    """

    def __init__(self) -> None:
        if _NX_AVAILABLE:
            self._g = nx.DiGraph()
        else:
            self._g = _FallbackGraph()

        self._completed: Set[str] = set()
        self._task_metadata: Dict[str, Dict[str, Any]] = {}

        log.debug(
            "DependencyGraph initialized | backend={}",
            "networkx" if _NX_AVAILABLE else "fallback",
        )

    # ------------------------------------------------------------------
    # Graph construction
    # ------------------------------------------------------------------

    def add_task(self, task_id: str, name: str = "", **metadata: Any) -> None:
        """Register a task node in the graph."""
        self._g.add_node(task_id, name=name, **metadata)
        self._task_metadata[task_id] = {"name": name, **metadata}
        log.debug("DependencyGraph: node added | id={} | name={}", task_id[:8], name)

    def add_dependency(self, parent_id: str, child_id: str) -> None:
        """
        Declare that child_id depends on parent_id.

        Raises ValueError if:
          - Either node is not in the graph
          - Adding this edge would create a cycle (deadlock)
        """
        if not self._g.has_node(parent_id):
            raise ValueError(f"Parent task '{parent_id[:8]}' not in dependency graph")
        if not self._g.has_node(child_id):
            raise ValueError(f"Child task '{child_id[:8]}' not in dependency graph")

        # Add the edge tentatively and check for cycles
        self._g.add_edge(parent_id, child_id)

        if self._has_cycle():
            self._g.remove_edge(parent_id, child_id) if _NX_AVAILABLE else None
            raise ValueError(
                f"Adding dependency {parent_id[:8]} → {child_id[:8]} "
                f"would create a cycle (deadlock)"
            )

        log.debug(
            "DependencyGraph: edge added | {} → {}",
            parent_id[:8], child_id[:8],
        )

    def remove_task(self, task_id: str) -> None:
        """Remove a task node and all its edges from the graph."""
        if self._g.has_node(task_id):
            if _NX_AVAILABLE:
                self._g.remove_node(task_id)
            else:
                self._g.remove_node(task_id)
            self._task_metadata.pop(task_id, None)
            self._completed.discard(task_id)

    # ------------------------------------------------------------------
    # State tracking
    # ------------------------------------------------------------------

    def mark_completed(self, task_id: str) -> None:
        """Mark a task as completed so its dependents become ready."""
        self._completed.add(task_id)
        log.debug("DependencyGraph: task completed | id={}", task_id[:8])

    def mark_failed(self, task_id: str) -> None:
        """
        Mark a task as failed.
        Dependents of a failed task cannot become ready.
        TODO Stage 5: ReasoningEngine decides whether to replan around failures.
        """
        log.warning(
            "DependencyGraph: task failed | id={} | {} dependent(s) blocked",
            task_id[:8], len(self.get_dependents(task_id)),
        )

    # ------------------------------------------------------------------
    # Queries
    # ------------------------------------------------------------------

    def is_ready(self, task_id: str) -> bool:
        """
        Return True if all of this task's dependencies are completed.
        A task with no dependencies is always ready.
        """
        if not self._g.has_node(task_id):
            return False

        if _NX_AVAILABLE:
            parents = list(self._g.predecessors(task_id))
        else:
            parents = self._g.predecessors(task_id)

        return all(p in self._completed for p in parents)

    def get_ready_tasks(self, candidate_ids: Set[str]) -> List[str]:
        """
        From a set of candidate task IDs (PENDING tasks), return those
        whose dependencies are all completed.
        """
        return [tid for tid in candidate_ids if self.is_ready(tid)]

    def get_dependents(self, task_id: str) -> List[str]:
        """Return all tasks that directly depend on task_id."""
        if not self._g.has_node(task_id):
            return []
        if _NX_AVAILABLE:
            return list(self._g.successors(task_id))
        return self._g.successors(task_id)

    def get_dependencies(self, task_id: str) -> List[str]:
        """Return all tasks that task_id directly depends on."""
        if not self._g.has_node(task_id):
            return []
        if _NX_AVAILABLE:
            return list(self._g.predecessors(task_id))
        return self._g.predecessors(task_id)

    def topological_order(self) -> List[str]:
        """
        Return all task IDs in valid execution order.
        Tasks with no dependencies come first.
        Raises ValueError if a cycle exists.
        """
        if self._has_cycle():
            raise ValueError("Dependency graph contains a cycle — cannot compute order")

        if _NX_AVAILABLE:
            return list(nx.topological_sort(self._g))
        else:
            return self._g.topological_sort()

    def blocked_by_failure(self, failed_id: str) -> Set[str]:
        """
        Return all task IDs (transitively) blocked by a failed task.
        Useful for bulk-cancelling downstream tasks after a critical failure.
        """
        if not self._g.has_node(failed_id):
            return set()

        if _NX_AVAILABLE:
            return set(nx.descendants(self._g, failed_id))
        else:
            # BFS fallback
            blocked: Set[str] = set()
            queue = [failed_id]
            while queue:
                node = queue.pop()
                for child in self._g.successors(node):
                    if child not in blocked:
                        blocked.add(child)
                        queue.append(child)
            return blocked

    # ------------------------------------------------------------------
    # Introspection
    # ------------------------------------------------------------------

    def node_count(self) -> int:
        if _NX_AVAILABLE:
            return self._g.number_of_nodes()
        return len(self._g.nodes())

    def edge_count(self) -> int:
        if _NX_AVAILABLE:
            return self._g.number_of_edges()
        return sum(len(children) for children in self._g._edges.values())

    def summary(self) -> Dict[str, Any]:
        return {
            "nodes":     self.node_count(),
            "edges":     self.edge_count(),
            "completed": len(self._completed),
            "has_cycle": self._has_cycle(),
            "backend":   "networkx" if _NX_AVAILABLE else "fallback",
        }

    def _has_cycle(self) -> bool:
        if _NX_AVAILABLE:
            return not nx.is_directed_acyclic_graph(self._g)
        return self._g.has_cycle()

    def __repr__(self) -> str:
        return (
            f"<DependencyGraph nodes={self.node_count()} "
            f"edges={self.edge_count()} completed={len(self._completed)}>"
        )
