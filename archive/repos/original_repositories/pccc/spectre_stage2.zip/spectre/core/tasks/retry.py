"""
spectre/core/tasks/retry.py

Retry engine for the Spectre execution system.

The RetryEngine decides whether a failed task should be retried,
computes the backoff delay, classifies the failure, and schedules
the task back into the queue after the delay has elapsed.

Failure classifications:
    timeout          — tool or worker exceeded time limit
    tool_failure     — external tool returned non-zero exit / error output
    transient_error  — network blip, resource temporarily unavailable
    permanent_error  — logic error, invalid input, exhausted retries
    unknown          — unclassified exception

Stage 2: Task Engine & Execution System
TODO Stage 3: Log retry attempts as KnowledgeGraph edge annotations
TODO Stage 4: Feed retry history into EpisodicMemory for learning
TODO Stage 5: ReasoningEngine uses retry patterns to avoid re-failing tasks
"""

from __future__ import annotations

import asyncio
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Callable, Dict, Optional, Tuple

from spectre.core.logger import get_logger
from spectre.core.tasks.task import Task, TaskResult, TaskStatus

if TYPE_CHECKING:
    from spectre.core.tasks.queue import TaskQueue

log = get_logger(__name__)


# ---------------------------------------------------------------------------
# Failure classification
# ---------------------------------------------------------------------------

class FailureClass(str):
    """String constants for failure classification."""
    TIMEOUT         = "timeout"
    TOOL_FAILURE    = "tool_failure"
    TRANSIENT_ERROR = "transient_error"
    PERMANENT_ERROR = "permanent_error"
    UNKNOWN         = "unknown"


# Classification rules: exception type → failure class
# Extend this mapping to cover domain-specific exceptions.
_EXCEPTION_CLASS_MAP: Dict[str, str] = {
    "asyncio.TimeoutError":      FailureClass.TIMEOUT,
    "TimeoutError":              FailureClass.TIMEOUT,
    "ConnectionError":           FailureClass.TRANSIENT_ERROR,
    "ConnectionResetError":      FailureClass.TRANSIENT_ERROR,
    "ConnectionRefusedError":    FailureClass.TRANSIENT_ERROR,
    "OSError":                   FailureClass.TRANSIENT_ERROR,
    "ValueError":                FailureClass.PERMANENT_ERROR,
    "TypeError":                 FailureClass.PERMANENT_ERROR,
    "NotImplementedError":       FailureClass.PERMANENT_ERROR,
    "PermissionError":           FailureClass.PERMANENT_ERROR,
    # TODO Stage 2: Add ToolExecutionError, WorkerError, ParseError
}


def classify_failure(exc: Optional[Exception], error_message: str = "") -> str:
    """
    Determine the failure class for a given exception.

    First checks the exception type registry, then falls back to
    keyword scanning of the error message.
    """
    if exc is not None:
        exc_type = type(exc).__name__
        qualified = f"{type(exc).__module__}.{exc_type}"

        if qualified in _EXCEPTION_CLASS_MAP:
            return _EXCEPTION_CLASS_MAP[qualified]
        if exc_type in _EXCEPTION_CLASS_MAP:
            return _EXCEPTION_CLASS_MAP[exc_type]

    # Keyword scan on error message
    lower = (error_message or "").lower()
    if any(kw in lower for kw in ("timeout", "timed out", "deadline")):
        return FailureClass.TIMEOUT
    if any(kw in lower for kw in ("connection refused", "unreachable", "reset")):
        return FailureClass.TRANSIENT_ERROR
    if any(kw in lower for kw in ("invalid", "permission denied", "not found")):
        return FailureClass.PERMANENT_ERROR

    return FailureClass.UNKNOWN


# ---------------------------------------------------------------------------
# RetryEngine
# ---------------------------------------------------------------------------

class RetryEngine:
    """
    Decides whether a failed task qualifies for retry and schedules it.

    The engine respects each task's individual RetryPolicy (max retries,
    backoff base, backoff cap) and the global non-retryable failure classes.
    """

    # Failure classes that are NEVER retried regardless of retry_on list
    NON_RETRYABLE: frozenset = frozenset({
        FailureClass.PERMANENT_ERROR,
    })

    def __init__(self, queue: "TaskQueue") -> None:
        self._queue = queue

        # Counters
        self._retried_total:  int = 0
        self._exhausted_total: int = 0
        self._non_retryable_total: int = 0

        log.debug("RetryEngine initialized")

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def handle_failure(
        self,
        task: Task,
        exc: Optional[Exception] = None,
        error_message: str = "",
    ) -> Tuple[bool, float]:
        """
        Evaluate whether the task should be retried.

        Returns
        -------
        (should_retry: bool, delay_seconds: float)
            should_retry — True if the task was re-queued
            delay_seconds — the backoff delay applied before re-queuing
        """
        failure_class = classify_failure(exc, error_message)

        log.debug(
            "RetryEngine evaluating | id={} | name={} | class={} | attempt={}",
            task.id[:8], task.name, failure_class, task.retries,
        )

        # 1. Check non-retryable classes
        if failure_class in self.NON_RETRYABLE:
            log.warning(
                "Task not retryable (permanent failure) | id={} | name={} | class={}",
                task.id[:8], task.name, failure_class,
            )
            self._non_retryable_total += 1
            return False, 0.0

        # 2. Check if this failure class is in the task's retry_on list
        if failure_class not in task.retry_policy.retry_on:
            log.warning(
                "Failure class '{}' not in retry_on list for task '{}' | id={}",
                failure_class, task.name, task.id[:8],
            )
            return False, 0.0

        # 3. Check retry budget
        if task.retries >= task.retry_policy.max_retries:
            log.error(
                "Task exhausted retries ({}) | id={} | name={}",
                task.retry_policy.max_retries, task.id[:8], task.name,
            )
            self._exhausted_total += 1
            return False, 0.0

        # 4. Calculate backoff delay
        delay = task.retry_policy.backoff_delay(task.retries)

        log.info(
            "Scheduling retry | id={} | name={} | attempt={}/{} | delay={:.1f}s | class={}",
            task.id[:8], task.name,
            task.retries + 1, task.retry_policy.max_retries,
            delay, failure_class,
        )

        # 5. Schedule re-queue after delay
        asyncio.create_task(self._delayed_requeue(task, delay, failure_class))

        self._retried_total += 1
        return True, delay

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    async def _delayed_requeue(
        self,
        task: Task,
        delay: float,
        failure_class: str,
    ) -> None:
        """Sleep for delay seconds, then increment retries and re-enqueue."""
        if delay > 0:
            await asyncio.sleep(delay)

        try:
            task.increment_retry()   # increments retries, transitions FAILED→QUEUED
            await self._queue.add_task(task)
            log.info(
                "Task re-queued after retry delay | id={} | name={} | attempt={}",
                task.id[:8], task.name, task.retries,
            )
        except Exception as exc:
            log.error(
                "Failed to re-queue task after retry | id={} | {} ",
                task.id[:8], exc,
            )

    # ------------------------------------------------------------------
    # Metrics
    # ------------------------------------------------------------------

    def stats(self) -> Dict:
        return {
            "retried_total":       self._retried_total,
            "exhausted_total":     self._exhausted_total,
            "non_retryable_total": self._non_retryable_total,
        }
