"""
Patch file: adds TaskEngineSettings to core/settings.py

This is applied by the Stage 2 update to settings.py.
Run: python patch_settings.py  (or copy manually)
"""

# This content is meant to be merged into spectre/core/settings.py
# See the updated settings.py file instead.
