"""
spectre/core/tasks/executor.py

Execution Engine for Spectre — the central async orchestrator.

Responsibility chain:
    TaskQueue → ExecutionEngine → WorkerRegistry → Worker → TaskResult
                      ↓
                  EventBus (publishes lifecycle events)
                      ↓
                  RetryEngine (handles failures)
                      ↓
                  Scheduler.notify_completed/failed

The engine runs a configurable number of concurrent worker coroutines.
Each slot pulls a task from the queue, resolves the right worker,
executes it, and handles the result — all without blocking other slots.

Key design decisions:
- asyncio.Semaphore controls max concurrency (not thread pool)
- Worker execution is wrapped in a timeout guard
- Exceptions inside workers never crash the engine loop
- All state changes emit events on the EventBus
- The engine is fully restartable (stop → start)

Stage 2: Task Engine & Execution System
TODO Stage 3: Engine reads ParserEngine output after each task
TODO Stage 4: Engine writes results to MemorySystem
TODO Stage 5: Engine notifies ReasoningEngine for replanning on failure
"""

from __future__ import annotations

import asyncio
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Set

from spectre.core.logger import get_logger
from spectre.core.tasks.events import (
    EventBus,
    TaskCancelledEvent,
    TaskCompletedEvent,
    TaskFailedEvent,
    TaskRetryingEvent,
    TaskStartedEvent,
    EngineStartedEvent,
    EngineStoppedEvent,
)
from spectre.core.tasks.queue import TaskQueue
from spectre.core.tasks.retry import RetryEngine, classify_failure
from spectre.core.tasks.task import Task, TaskResult, TaskStatus
from spectre.core.tasks.worker import WorkerRegistry

log = get_logger(__name__)


# ---------------------------------------------------------------------------
# ExecutionEngine
# ---------------------------------------------------------------------------

class ExecutionEngine:
    """
    Central async execution orchestrator.

    Manages a pool of concurrent execution slots. Each slot is an
    asyncio coroutine that continuously pulls tasks from the queue
    and dispatches them to the appropriate worker.

    Usage::

        engine = ExecutionEngine(
            queue=queue,
            worker_registry=registry,
            event_bus=bus,
            max_concurrent=5,
            task_timeout=30.0,
        )
        await engine.start()
        # ... application runs ...
        await engine.stop()
    """

    def __init__(
        self,
        queue: TaskQueue,
        worker_registry: WorkerRegistry,
        event_bus: EventBus,
        max_concurrent: int = 5,
        task_timeout: float = 30.0,
        scheduler: Optional[Any] = None,   # Scheduler (forward ref avoidance)
    ) -> None:
        self._queue            = queue
        self._worker_registry  = worker_registry
        self._event_bus        = event_bus
        self._max_concurrent   = max_concurrent
        self._task_timeout     = task_timeout
        self._scheduler        = scheduler

        self._retry_engine = RetryEngine(queue=self._queue)

        # Concurrency control
        self._semaphore = asyncio.Semaphore(max_concurrent)

        # Runtime state
        self._running:         bool = False
        self._start_time:      Optional[float] = None
        self._slot_tasks:      List[asyncio.Task] = []
        self._active_task_ids: Set[str] = set()
        self._active_lock      = asyncio.Lock()

        # Counters
        self._completed_total: int = 0
        self._failed_total:    int = 0
        self._cancelled_total: int = 0
        self._retried_total:   int = 0

        log.debug(
            "ExecutionEngine initialized | slots={} | timeout={}s",
            max_concurrent, task_timeout,
        )

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def start(self) -> None:
        """
        Start the execution engine.

        Spawns `max_concurrent` worker-slot coroutines. Each slot
        independently pulls tasks from the queue and executes them.
        """
        if self._running:
            log.warning("ExecutionEngine.start() called but engine is already running")
            return

        self._running = True
        self._start_time = time.monotonic()

        # Spawn worker slots
        for i in range(self._max_concurrent):
            slot = asyncio.create_task(
                self._worker_slot(slot_id=i),
                name=f"engine-slot-{i}",
            )
            self._slot_tasks.append(slot)

        await self._event_bus.publish(
            EngineStartedEvent(
                source="ExecutionEngine",
                worker_count=self._max_concurrent,
            )
        )
        log.info(
            "ExecutionEngine started | slots={} | timeout={}s",
            self._max_concurrent, self._task_timeout,
        )

    async def stop(self, drain_timeout: float = 5.0) -> None:
        """
        Stop the execution engine gracefully.

        Waits up to drain_timeout seconds for in-flight tasks to finish,
        then cancels remaining slots.
        """
        if not self._running:
            return

        log.info("ExecutionEngine stopping... | drain_timeout={}s", drain_timeout)
        self._running = False

        # Wait briefly for in-flight tasks to complete
        if self._active_task_ids:
            log.info(
                "Waiting for {} active task(s) to finish...",
                len(self._active_task_ids),
            )
            await asyncio.sleep(min(drain_timeout, 1.0))

        # Cancel slot coroutines
        for task in self._slot_tasks:
            if not task.done():
                task.cancel()

        await asyncio.gather(*self._slot_tasks, return_exceptions=True)
        self._slot_tasks.clear()

        uptime = time.monotonic() - (self._start_time or 0)

        await self._event_bus.publish(
            EngineStoppedEvent(
                source="ExecutionEngine",
                worker_count=self._max_concurrent,
                tasks_completed=self._completed_total,
                tasks_failed=self._failed_total,
            )
        )
        log.info(
            "ExecutionEngine stopped | uptime={:.1f}s | completed={} | failed={}",
            uptime, self._completed_total, self._failed_total,
        )

    # ------------------------------------------------------------------
    # Submit convenience (wraps queue.add_task)
    # ------------------------------------------------------------------

    async def submit(self, task: Task) -> None:
        """
        Submit a task directly to the queue (bypasses scheduler).
        Use Scheduler.submit() for dependency-aware scheduling.
        """
        await self._queue.add_task(task)
        log.debug("Task submitted directly | id={} | name={}", task.id[:8], task.name)

    # ------------------------------------------------------------------
    # Worker slot
    # ------------------------------------------------------------------

    async def _worker_slot(self, slot_id: int) -> None:
        """
        A single concurrent execution slot.

        Loops continuously:
          1. Acquire semaphore slot
          2. Pull task from queue (blocks until available)
          3. Execute task in a sub-coroutine (non-blocking for this slot)
          4. Release semaphore
        """
        log.debug("Engine slot {} started", slot_id)
        try:
            while self._running:
                # Pull next task — wait up to 1s then re-check _running
                task = await self._queue.get_task(timeout=1.0)
                if task is None:
                    continue

                # Execute concurrently without blocking other slots
                asyncio.create_task(
                    self._execute_task(task, slot_id=slot_id),
                    name=f"exec-{task.id[:8]}",
                )
        except asyncio.CancelledError:
            log.debug("Engine slot {} cancelled", slot_id)

    # ------------------------------------------------------------------
    # Task execution lifecycle
    # ------------------------------------------------------------------

    async def _execute_task(self, task: Task, slot_id: int) -> None:
        """
        Full execution lifecycle for one task:
            validate → assign worker → execute → handle result
        """
        async with self._semaphore:
            async with self._active_lock:
                self._active_task_ids.add(task.id)

            try:
                await self._run_task(task, slot_id)
            finally:
                async with self._active_lock:
                    self._active_task_ids.discard(task.id)

    async def _run_task(self, task: Task, slot_id: int) -> None:
        """Core execution logic — called inside the semaphore guard."""

        # --- 1. Validate task state ---
        if task.status == TaskStatus.CANCELLED:
            log.info("Skipping cancelled task | id={} | name={}", task.id[:8], task.name)
            return

        # --- 2. Resolve worker ---
        worker = self._worker_registry.resolve(task)
        if worker is None:
            log.error(
                "No worker found for task '{}' (type={}) | id={}",
                task.name, task.type.value, task.id[:8],
            )
            await self._handle_failure(
                task,
                error_message=f"No worker registered for task type '{task.type.value}'",
            )
            return

        # --- 3. Transition to RUNNING ---
        try:
            task.transition(TaskStatus.RUNNING)
        except ValueError as exc:
            log.error("Invalid task state transition | id={} | {}", task.id[:8], exc)
            return

        # --- 4. Emit task_started event ---
        await self._event_bus.publish(
            TaskStartedEvent(
                source="ExecutionEngine",
                task_id=task.id,
                task_name=task.name,
                task_type=task.type.value,
                session_id=task.session_id,
                worker_id=worker.id,
                correlation_id=task.session_id,
            )
        )

        log.info(
            "Task started | id={} | name={} | type={} | worker={} | slot={}",
            task.id[:8], task.name, task.type.value, worker.worker_type, slot_id,
        )

        # --- 5. Execute with timeout guard ---
        exc_caught: Optional[Exception] = None
        result: Optional[TaskResult] = None

        try:
            result = await asyncio.wait_for(
                worker.execute(task),
                timeout=self._task_timeout,
            )
        except asyncio.TimeoutError as exc:
            exc_caught = exc
            result = TaskResult(
                success=False,
                error=f"Task timed out after {self._task_timeout}s",
                worker_id=worker.id,
            )
            log.warning(
                "Task timed out | id={} | name={} | timeout={}s",
                task.id[:8], task.name, self._task_timeout,
            )
        except Exception as exc:
            exc_caught = exc
            result = TaskResult(
                success=False,
                error=str(exc),
                worker_id=worker.id,
            )
            log.error(
                "Task raised unhandled exception | id={} | name={} | {}",
                task.id[:8], task.name, exc,
            )

        # --- 6. Handle result ---
        if result and result.success:
            await self._handle_success(task, result)
        else:
            await self._handle_failure(
                task,
                result=result,
                exc=exc_caught,
                error_message=result.error if result else "Unknown error",
            )

    # ------------------------------------------------------------------
    # Success / failure handlers
    # ------------------------------------------------------------------

    async def _handle_success(self, task: Task, result: TaskResult) -> None:
        """Mark task completed, attach result, emit event, notify scheduler."""
        task.result = result
        task.transition(TaskStatus.COMPLETED)
        self._completed_total += 1

        await self._event_bus.publish(
            TaskCompletedEvent(
                source="ExecutionEngine",
                task_id=task.id,
                task_name=task.name,
                task_type=task.type.value,
                session_id=task.session_id,
                duration_seconds=result.duration_seconds or 0.0,
                worker_id=result.worker_id or "",
                correlation_id=task.session_id,
            )
        )

        log.success(
            "Task completed | id={} | name={} | dur={:.2f}s",
            task.id[:8], task.name,
            result.duration_seconds or 0.0,
        )

        # Notify scheduler to unblock dependents
        if self._scheduler:
            await self._scheduler.notify_completed(task.id)

        # TODO Stage 3: Pass result to ParserEngine for entity extraction
        # TODO Stage 4: Write result to MemorySystem episodic store

    async def _handle_failure(
        self,
        task: Task,
        result: Optional[TaskResult] = None,
        exc: Optional[Exception] = None,
        error_message: str = "",
    ) -> None:
        """
        Mark task failed, attempt retry via RetryEngine, emit events.
        """
        error_msg = error_message or (result.error if result else "Unknown error")

        # Transition to FAILED
        try:
            task.transition(TaskStatus.FAILED)
        except ValueError:
            pass  # already in a terminal state

        if result:
            task.result = result

        self._failed_total += 1

        # --- Attempt retry ---
        failure_class = classify_failure(exc, error_msg)
        should_retry, delay = await self._retry_engine.handle_failure(
            task, exc=exc, error_message=error_msg
        )

        if should_retry:
            self._retried_total += 1
            await self._event_bus.publish(
                TaskRetryingEvent(
                    source="ExecutionEngine",
                    task_id=task.id,
                    task_name=task.name,
                    task_type=task.type.value,
                    session_id=task.session_id,
                    attempt=task.retries,
                    delay_seconds=delay,
                    reason=failure_class,
                    correlation_id=task.session_id,
                )
            )
            log.info(
                "Task scheduled for retry | id={} | name={} | attempt={} | delay={:.1f}s",
                task.id[:8], task.name, task.retries, delay,
            )
        else:
            # Permanent failure
            await self._event_bus.publish(
                TaskFailedEvent(
                    source="ExecutionEngine",
                    task_id=task.id,
                    task_name=task.name,
                    task_type=task.type.value,
                    session_id=task.session_id,
                    error=error_msg,
                    retries_remaining=0,
                    worker_id=(result.worker_id if result else ""),
                    correlation_id=task.session_id,
                )
            )
            log.error(
                "Task permanently failed | id={} | name={} | error={}",
                task.id[:8], task.name, error_msg,
            )

            # Notify scheduler to cancel downstream dependents
            if self._scheduler:
                await self._scheduler.notify_failed(task.id)

            # TODO Stage 5: Notify ReasoningEngine for replanning

    # ------------------------------------------------------------------
    # Status / metrics
    # ------------------------------------------------------------------

    @property
    def is_running(self) -> bool:
        return self._running

    async def active_count(self) -> int:
        async with self._active_lock:
            return len(self._active_task_ids)

    def uptime_seconds(self) -> float:
        if self._start_time is None:
            return 0.0
        return time.monotonic() - self._start_time

    async def stats(self) -> Dict[str, Any]:
        queue_stats = await self._queue.stats()
        return {
            "running":           self._running,
            "uptime_seconds":    round(self.uptime_seconds(), 1),
            "max_concurrent":    self._max_concurrent,
            "task_timeout":      self._task_timeout,
            "active_tasks":      await self.active_count(),
            "completed_total":   self._completed_total,
            "failed_total":      self._failed_total,
            "cancelled_total":   self._cancelled_total,
            "retried_total":     self._retried_total,
            "queue":             queue_stats,
            "retry_engine":      self._retry_engine.stats(),
            "workers":           self._worker_registry.list_workers(),
        }

    def __repr__(self) -> str:
        return (
            f"<ExecutionEngine running={self._running} "
            f"slots={self._max_concurrent} "
            f"completed={self._completed_total} "
            f"failed={self._failed_total}>"
        )
