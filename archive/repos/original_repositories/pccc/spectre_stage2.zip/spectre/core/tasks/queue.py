"""
spectre/core/tasks/queue.py

Async priority task queue for the Spectre execution engine.

Architecture:
    Producer (PlannerAgent / CLI) → TaskQueue → ExecutionEngine

The queue is an asyncio-native priority queue backed by heapq.
Priority is determined by TaskPriority (0=CRITICAL, 4=IDLE).
Tasks with equal priority are ordered FIFO by insertion sequence number.

Features:
- add_task()    — enqueue with priority ordering
- get_task()    — dequeue the highest-priority ready task
- remove_task() — cancel and remove by ID
- pause_task()  — suspend without removal
- resume_task() — re-enter a paused task
- peek()        — inspect head without consuming
- Task lookup   — O(1) by task ID

Stage 2: Task Engine & Execution System
TODO Stage 3: Add persistence hook — flush queue to disk on shutdown
TODO Stage 4: Add Redis-backed distributed queue option
TODO Stage 5: PlannerAgent dynamically re-priorities queue on new findings
"""

from __future__ import annotations

import asyncio
import heapq
import itertools
import time
from collections import defaultdict
from typing import Dict, Iterator, List, Optional, Set, Tuple

from spectre.core.logger import get_logger
from spectre.core.tasks.task import Task, TaskPriority, TaskStatus

log = get_logger(__name__)


# ---------------------------------------------------------------------------
# Internal heap entry
# ---------------------------------------------------------------------------

class _QueueEntry:
    """
    Wrapper that allows Task objects to be stored in a min-heap.

    Heap ordering:  (priority_value, sequence, task)
    - priority_value: lower int = higher priority (CRITICAL=0, IDLE=4)
    - sequence:       monotonically increasing insertion counter for FIFO
                      tie-breaking within the same priority level
    """

    __slots__ = ("priority_value", "sequence", "task", "removed")

    def __init__(self, priority_value: int, sequence: int, task: Task) -> None:
        self.priority_value = priority_value
        self.sequence       = sequence
        self.task           = task
        self.removed        = False   # lazy deletion marker

    def __lt__(self, other: "_QueueEntry") -> bool:
        if self.priority_value != other.priority_value:
            return self.priority_value < other.priority_value
        return self.sequence < other.sequence


# ---------------------------------------------------------------------------
# TaskQueue
# ---------------------------------------------------------------------------

class TaskQueue:
    """
    Async priority task queue.

    Thread-safety: designed for single-event-loop use.
    All public methods are async and safe to call from coroutines.
    """

    def __init__(self, maxsize: int = 0) -> None:
        """
        Parameters
        ----------
        maxsize:
            Maximum number of queued tasks. 0 = unlimited.
        """
        self._maxsize    = maxsize
        self._heap: List[_QueueEntry] = []
        self._counter    = itertools.count()        # FIFO tie-breaker
        self._task_map: Dict[str, _QueueEntry] = {} # id → entry (O(1) lookup)
        self._paused: Dict[str, Task] = {}          # id → task (suspended pool)
        self._lock       = asyncio.Lock()
        self._not_empty  = asyncio.Event()          # signals get_task() waiters

        # Metrics counters
        self._enqueued_total: int = 0
        self._dequeued_total: int = 0
        self._removed_total:  int = 0

        log.debug("TaskQueue initialized | maxsize={}", maxsize or "unlimited")

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def add_task(self, task: Task) -> None:
        """
        Enqueue a task.

        Transitions the task from PENDING → QUEUED.
        Raises asyncio.QueueFull if maxsize is set and queue is at capacity.
        Raises ValueError if the task ID is already in the queue.
        """
        async with self._lock:
            if self._maxsize and self._active_size() >= self._maxsize:
                raise asyncio.QueueFull(
                    f"TaskQueue is at capacity ({self._maxsize})"
                )

            if task.id in self._task_map:
                raise ValueError(
                    f"Task '{task.id[:8]}' is already in the queue"
                )

            task.transition(TaskStatus.QUEUED)

            entry = _QueueEntry(
                priority_value=task.priority.value,
                sequence=next(self._counter),
                task=task,
            )
            heapq.heappush(self._heap, entry)
            self._task_map[task.id] = entry
            self._enqueued_total += 1
            self._not_empty.set()

        log.debug(
            "Task enqueued | id={} | name={} | priority={}",
            task.id[:8], task.name, task.priority.name,
        )

    async def get_task(self, timeout: Optional[float] = None) -> Optional[Task]:
        """
        Dequeue the highest-priority non-removed task.

        Blocks until a task is available or timeout expires.
        Returns None on timeout.
        """
        deadline = (time.monotonic() + timeout) if timeout is not None else None

        while True:
            async with self._lock:
                task = self._pop_ready()
                if task is not None:
                    self._dequeued_total += 1
                    return task
                # Queue is empty — clear the event
                self._not_empty.clear()

            # Wait outside the lock
            if deadline is not None:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    return None
                try:
                    await asyncio.wait_for(self._not_empty.wait(), timeout=remaining)
                except asyncio.TimeoutError:
                    return None
            else:
                await self._not_empty.wait()

    async def remove_task(self, task_id: str) -> bool:
        """
        Cancel and remove a task from the queue.

        Uses lazy deletion — marks the entry as removed; the next pop
        will discard it. Also removes from the paused pool if present.

        Returns True if the task was found and marked, False otherwise.
        """
        async with self._lock:
            # Check paused pool first
            if task_id in self._paused:
                task = self._paused.pop(task_id)
                task.transition(TaskStatus.CANCELLED)
                self._removed_total += 1
                log.info("Paused task cancelled | id={} | name={}", task_id[:8], task.name)
                return True

            entry = self._task_map.pop(task_id, None)
            if entry is None:
                return False

            entry.removed = True
            entry.task.transition(TaskStatus.CANCELLED)
            self._removed_total += 1

        log.info("Task removed from queue | id={} | name={}", task_id[:8], entry.task.name)
        return True

    async def pause_task(self, task_id: str) -> bool:
        """
        Move a QUEUED task into the paused pool.

        The task is removed from the heap and held until resume_task()
        is called. Running tasks cannot be paused via the queue — the
        ExecutionEngine handles that directly.

        Returns True on success.
        """
        async with self._lock:
            entry = self._task_map.pop(task_id, None)
            if entry is None or entry.removed:
                return False

            entry.removed = True   # mark heap entry as dead
            task = entry.task
            task.transition(TaskStatus.PAUSED)
            self._paused[task_id] = task

        log.info("Task paused | id={} | name={}", task_id[:8], task.name)
        return True

    async def resume_task(self, task_id: str) -> bool:
        """
        Move a paused task back into the active queue at its original priority.

        Returns True on success.
        """
        async with self._lock:
            task = self._paused.pop(task_id, None)
            if task is None:
                return False

            # Reset to PENDING so add_task() transition is valid
            task.status = TaskStatus.PENDING
            task.timestamps.resumed_at = None  # will be re-stamped

        # Re-enqueue outside the lock to avoid deadlock
        await self.add_task(task)
        log.info("Task resumed | id={} | name={}", task_id[:8], task.name)
        return True

    async def peek(self) -> Optional[Task]:
        """Return the next task without removing it. Returns None if empty."""
        async with self._lock:
            for entry in self._heap:
                if not entry.removed:
                    return entry.task
            return None

    async def get_by_id(self, task_id: str) -> Optional[Task]:
        """Look up any queued or paused task by its full ID. O(1)."""
        async with self._lock:
            entry = self._task_map.get(task_id)
            if entry and not entry.removed:
                return entry.task
            return self._paused.get(task_id)

    async def list_queued(self) -> List[Task]:
        """Return all active (non-removed) queued tasks sorted by priority."""
        async with self._lock:
            return [
                e.task for e in sorted(self._heap)
                if not e.removed
            ]

    async def list_paused(self) -> List[Task]:
        """Return all paused tasks."""
        async with self._lock:
            return list(self._paused.values())

    # ------------------------------------------------------------------
    # Metrics
    # ------------------------------------------------------------------

    async def size(self) -> int:
        """Number of active (non-removed) tasks in the queue."""
        async with self._lock:
            return self._active_size()

    async def paused_count(self) -> int:
        async with self._lock:
            return len(self._paused)

    async def stats(self) -> Dict:
        """Snapshot of queue metrics for status display and observability."""
        async with self._lock:
            return {
                "queued":         self._active_size(),
                "paused":         len(self._paused),
                "enqueued_total": self._enqueued_total,
                "dequeued_total": self._dequeued_total,
                "removed_total":  self._removed_total,
                "heap_len":       len(self._heap),   # includes lazy-deleted entries
            }

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _active_size(self) -> int:
        """Count of non-removed entries in the heap (no lock acquired)."""
        return sum(1 for e in self._heap if not e.removed)

    def _pop_ready(self) -> Optional[Task]:
        """
        Pop and return the highest-priority non-removed task.
        Discards lazy-deleted entries encountered on the way.
        Must be called with self._lock held.
        """
        while self._heap:
            entry = heapq.heappop(self._heap)
            if entry.removed:
                continue   # discard lazy-deleted entry
            # Remove from lookup map
            self._task_map.pop(entry.task.id, None)
            return entry.task
        return None

    def __len__(self) -> int:
        """Synchronous best-effort size (may include lazy-deleted entries)."""
        return sum(1 for e in self._heap if not e.removed)

    def __repr__(self) -> str:
        return f"<TaskQueue queued={self._active_size()} paused={len(self._paused)}>"
