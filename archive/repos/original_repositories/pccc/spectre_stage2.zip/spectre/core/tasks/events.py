"""
spectre/core/tasks/events.py

Async event bus for the Spectre execution system.

The event bus decouples producers (ExecutionEngine, Workers) from consumers
(MemorySystem, KnowledgeGraph, StatusTracker, CLI, future AI agents).

Any component can subscribe to any event type. Handlers are called
concurrently as asyncio Tasks so slow handlers do not block the engine.

Standard events (all TaskEvent subclasses):
    task_created    — task instantiated and submitted
    task_queued     — task entered the priority queue
    task_started    — worker began execution
    task_completed  — worker finished successfully
    task_failed     — worker raised an exception or returned failure
    task_cancelled  — task removed before execution
    task_paused     — task suspended
    task_resumed    — task re-entered the queue after pause
    task_retrying   — task scheduled for retry

Custom events can be published by passing any SpectreEvent subclass.

Stage 2: Task Engine & Execution System
TODO Stage 3: Pipe events into KnowledgeGraph edge recorder
TODO Stage 4: Pipe task_completed events into EpisodicMemory
TODO Stage 5: ReasoningEngine subscribes to task_failed for replanning
"""

from __future__ import annotations

import asyncio
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Awaitable, Callable, Dict, List, Optional, Type

from spectre.core.logger import get_logger

log = get_logger(__name__)

# Type alias for async event handlers
AsyncHandler = Callable[["SpectreEvent"], Awaitable[None]]


# ---------------------------------------------------------------------------
# Event type registry
# ---------------------------------------------------------------------------

class EventType(str, Enum):
    """All first-class event types emitted by the execution system."""

    # Task lifecycle
    TASK_CREATED   = "task_created"
    TASK_QUEUED    = "task_queued"
    TASK_STARTED   = "task_started"
    TASK_COMPLETED = "task_completed"
    TASK_FAILED    = "task_failed"
    TASK_CANCELLED = "task_cancelled"
    TASK_PAUSED    = "task_paused"
    TASK_RESUMED   = "task_resumed"
    TASK_RETRYING  = "task_retrying"

    # Engine lifecycle
    ENGINE_STARTED  = "engine_started"
    ENGINE_STOPPED  = "engine_stopped"
    WORKER_SPAWNED  = "worker_spawned"
    WORKER_RETIRED  = "worker_retired"

    # Custom / plugin-defined
    CUSTOM = "custom"

    # TODO Stage 3: GRAPH_NODE_ADDED, GRAPH_EDGE_CREATED
    # TODO Stage 4: MEMORY_STORED, MEMORY_RETRIEVED
    # TODO Stage 5: PLAN_GENERATED, PLAN_REVISED


# ---------------------------------------------------------------------------
# Base event dataclass
# ---------------------------------------------------------------------------

@dataclass
class SpectreEvent:
    """
    Base class for all events published on the Spectre event bus.

    All events carry a timestamp, the event type, and an optional
    correlation ID for tracing chains of related events.
    """

    event_type: EventType
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    correlation_id: Optional[str] = None   # e.g. session_id or parent task_id
    source: str = "unknown"                # component that published this event
    payload: Dict[str, Any] = field(default_factory=dict)

    def __str__(self) -> str:
        return (
            f"[{self.event_type.value}] from={self.source} "
            f"corr={self.correlation_id or '—'}"
        )


# ---------------------------------------------------------------------------
# Concrete event types
# ---------------------------------------------------------------------------

@dataclass
class TaskEvent(SpectreEvent):
    """Event carrying a task ID and snapshot of task state."""
    task_id:   str = ""
    task_name: str = ""
    task_type: str = ""
    session_id: Optional[str] = None


@dataclass
class TaskCreatedEvent(TaskEvent):
    event_type: EventType = field(default=EventType.TASK_CREATED, init=False)


@dataclass
class TaskQueuedEvent(TaskEvent):
    event_type: EventType = field(default=EventType.TASK_QUEUED, init=False)
    priority: str = ""


@dataclass
class TaskStartedEvent(TaskEvent):
    event_type: EventType = field(default=EventType.TASK_STARTED, init=False)
    worker_id: str = ""


@dataclass
class TaskCompletedEvent(TaskEvent):
    event_type: EventType = field(default=EventType.TASK_COMPLETED, init=False)
    duration_seconds: float = 0.0
    worker_id: str = ""


@dataclass
class TaskFailedEvent(TaskEvent):
    event_type: EventType = field(default=EventType.TASK_FAILED, init=False)
    error: str = ""
    retries_remaining: int = 0
    worker_id: str = ""


@dataclass
class TaskCancelledEvent(TaskEvent):
    event_type: EventType = field(default=EventType.TASK_CANCELLED, init=False)
    reason: str = ""


@dataclass
class TaskPausedEvent(TaskEvent):
    event_type: EventType = field(default=EventType.TASK_PAUSED, init=False)


@dataclass
class TaskResumedEvent(TaskEvent):
    event_type: EventType = field(default=EventType.TASK_RESUMED, init=False)


@dataclass
class TaskRetryingEvent(TaskEvent):
    event_type: EventType = field(default=EventType.TASK_RETRYING, init=False)
    attempt: int = 0
    delay_seconds: float = 0.0
    reason: str = ""


@dataclass
class EngineEvent(SpectreEvent):
    """Engine-level lifecycle event."""
    worker_count: int = 0


@dataclass
class EngineStartedEvent(EngineEvent):
    event_type: EventType = field(default=EventType.ENGINE_STARTED, init=False)


@dataclass
class EngineStoppedEvent(EngineEvent):
    event_type: EventType = field(default=EventType.ENGINE_STOPPED, init=False)
    tasks_completed: int = 0
    tasks_failed: int = 0


# ---------------------------------------------------------------------------
# Event Bus
# ---------------------------------------------------------------------------

class EventBus:
    """
    Async publish/subscribe event bus.

    Usage::

        bus = EventBus()

        @bus.on(EventType.TASK_COMPLETED)
        async def on_complete(event: SpectreEvent) -> None:
            print(f"Done: {event.task_name}")

        await bus.publish(TaskCompletedEvent(task_id="...", task_name="nmap"))
    """

    def __init__(self) -> None:
        # EventType → list of async handlers
        self._handlers: Dict[EventType, List[AsyncHandler]] = defaultdict(list)
        # Wildcard handlers receive ALL events
        self._wildcard_handlers: List[AsyncHandler] = []

        # History ring buffer for debugging (last N events)
        self._history: List[SpectreEvent] = []
        self._history_limit: int = 500

        # Counters
        self._published: int = 0
        self._handler_errors: int = 0

        log.debug("EventBus initialized")

    # ------------------------------------------------------------------
    # Subscribe
    # ------------------------------------------------------------------

    def subscribe(
        self,
        event_type: EventType,
        handler: AsyncHandler,
    ) -> None:
        """
        Register an async handler for a specific event type.

        The handler signature must be:
            async def handler(event: SpectreEvent) -> None
        """
        self._handlers[event_type].append(handler)
        log.debug(
            "EventBus subscription | event={} | handler={}",
            event_type.value,
            getattr(handler, "__qualname__", repr(handler)),
        )

    def subscribe_all(self, handler: AsyncHandler) -> None:
        """Register a wildcard handler that receives every published event."""
        self._wildcard_handlers.append(handler)

    def unsubscribe(self, event_type: EventType, handler: AsyncHandler) -> bool:
        """Remove a specific handler. Returns True if it was found."""
        try:
            self._handlers[event_type].remove(handler)
            return True
        except ValueError:
            return False

    def on(self, event_type: EventType) -> Callable:
        """
        Decorator shorthand for subscribe()::

            @bus.on(EventType.TASK_FAILED)
            async def handle_failure(event): ...
        """
        def decorator(fn: AsyncHandler) -> AsyncHandler:
            self.subscribe(event_type, fn)
            return fn
        return decorator

    # ------------------------------------------------------------------
    # Publish
    # ------------------------------------------------------------------

    async def publish(self, event: SpectreEvent) -> None:
        """
        Publish an event to all registered handlers.

        Handlers are dispatched as concurrent asyncio Tasks so that
        a slow handler does not block the engine. Exceptions in handlers
        are caught and logged — they never propagate back to the publisher.
        """
        self._published += 1

        # Append to history ring buffer
        self._history.append(event)
        if len(self._history) > self._history_limit:
            self._history.pop(0)

        # Gather all handlers for this event type + wildcards
        handlers: List[AsyncHandler] = (
            list(self._handlers.get(event.event_type, []))
            + self._wildcard_handlers
        )

        if not handlers:
            return

        # Dispatch concurrently
        tasks = [asyncio.create_task(self._call(h, event)) for h in handlers]
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)

    async def _call(self, handler: AsyncHandler, event: SpectreEvent) -> None:
        """Invoke a handler and absorb any exception."""
        try:
            await handler(event)
        except Exception as exc:
            self._handler_errors += 1
            log.error(
                "EventBus handler error | event={} | handler={} | {}",
                event.event_type.value,
                getattr(handler, "__qualname__", repr(handler)),
                exc,
            )

    # ------------------------------------------------------------------
    # Introspection
    # ------------------------------------------------------------------

    def handler_count(self, event_type: Optional[EventType] = None) -> int:
        """Count registered handlers, optionally filtered by event type."""
        if event_type:
            return len(self._handlers.get(event_type, []))
        total = sum(len(v) for v in self._handlers.values())
        return total + len(self._wildcard_handlers)

    def recent_events(self, limit: int = 20) -> List[SpectreEvent]:
        """Return the most recently published events (newest last)."""
        return self._history[-limit:]

    def stats(self) -> Dict[str, Any]:
        return {
            "published_total":   self._published,
            "handler_errors":    self._handler_errors,
            "subscriptions":     {k.value: len(v) for k, v in self._handlers.items()},
            "wildcard_handlers": len(self._wildcard_handlers),
        }

    def __repr__(self) -> str:
        return f"<EventBus published={self._published} handlers={self.handler_count()}>"


# ---------------------------------------------------------------------------
# Module-level singleton (optional convenience)
# ---------------------------------------------------------------------------

# Components that don't need a dedicated bus can import this directly.
# SpectreApp creates and owns its own instance.
_default_bus: Optional[EventBus] = None


def get_event_bus() -> EventBus:
    """Return (or lazily create) the module-level default EventBus."""
    global _default_bus
    if _default_bus is None:
        _default_bus = EventBus()
    return _default_bus
