"""
spectre/core/tasks/status.py

Status tracker for the Spectre task execution system.

The StatusTracker is an EventBus subscriber that maintains a live,
aggregated view of the entire task pipeline. It is the single source
of truth for the `spectre task status` CLI command and future dashboards.

Tracked metrics:
    - Queue depth (waiting, paused)
    - Running task count and IDs
    - Completed / failed / cancelled / retried counts
    - Per-task-type breakdown
    - Engine uptime
    - Recent event history (ring buffer)

The tracker is purely reactive — it never mutates tasks, only observes.

Stage 2: Task Engine & Execution System
TODO Stage 3: Expose metrics via /api/v1/status HTTP endpoint
TODO Stage 4: Write periodic snapshots to MemorySystem for trend analysis
TODO Stage 5: ReasoningEngine reads tracker to detect stalled workflows
"""

from __future__ import annotations

import time
from collections import defaultdict
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Set

from spectre.core.logger import get_logger
from spectre.core.tasks.events import (
    EventBus,
    EventType,
    SpectreEvent,
    TaskCancelledEvent,
    TaskCompletedEvent,
    TaskFailedEvent,
    TaskRetryingEvent,
    TaskStartedEvent,
    EngineStartedEvent,
    EngineStoppedEvent,
)

log = get_logger(__name__)


class StatusTracker:
    """
    Real-time aggregated metrics for the Spectre task engine.

    Subscribes to the EventBus on instantiation and updates internal
    counters and sets in response to lifecycle events.
    """

    def __init__(self, event_bus: EventBus) -> None:
        self._bus = event_bus
        self._start_time: float = time.monotonic()
        self._engine_start_time: Optional[float] = None

        # Live sets
        self._running_ids:   Set[str] = set()
        self._completed_ids: Set[str] = set()
        self._failed_ids:    Set[str] = set()
        self._cancelled_ids: Set[str] = set()

        # Counters
        self._completed_total:  int = 0
        self._failed_total:     int = 0
        self._cancelled_total:  int = 0
        self._retried_total:    int = 0

        # Per-type breakdown
        self._completed_by_type: Dict[str, int] = defaultdict(int)
        self._failed_by_type:    Dict[str, int] = defaultdict(int)

        # Recent event log (ring buffer, newest last)
        self._recent_events: List[Dict[str, Any]] = []
        self._event_log_limit: int = 100

        # Register subscriptions
        self._register_handlers()

        log.debug("StatusTracker initialized and subscribed to EventBus")

    # ------------------------------------------------------------------
    # EventBus subscription setup
    # ------------------------------------------------------------------

    def _register_handlers(self) -> None:
        self._bus.subscribe(EventType.TASK_STARTED,   self._on_task_started)
        self._bus.subscribe(EventType.TASK_COMPLETED, self._on_task_completed)
        self._bus.subscribe(EventType.TASK_FAILED,    self._on_task_failed)
        self._bus.subscribe(EventType.TASK_CANCELLED, self._on_task_cancelled)
        self._bus.subscribe(EventType.TASK_RETRYING,  self._on_task_retrying)
        self._bus.subscribe(EventType.ENGINE_STARTED, self._on_engine_started)
        self._bus.subscribe(EventType.ENGINE_STOPPED, self._on_engine_stopped)

    # ------------------------------------------------------------------
    # Event handlers
    # ------------------------------------------------------------------

    async def _on_task_started(self, event: SpectreEvent) -> None:
        if isinstance(event, TaskStartedEvent):
            self._running_ids.add(event.task_id)
            self._log_event("STARTED", event.task_name, event.task_type, event.task_id)

    async def _on_task_completed(self, event: SpectreEvent) -> None:
        if isinstance(event, TaskCompletedEvent):
            self._running_ids.discard(event.task_id)
            self._completed_ids.add(event.task_id)
            self._completed_total += 1
            self._completed_by_type[event.task_type] += 1
            self._log_event(
                "COMPLETED", event.task_name, event.task_type, event.task_id,
                extra={"duration": f"{event.duration_seconds:.2f}s"},
            )

    async def _on_task_failed(self, event: SpectreEvent) -> None:
        if isinstance(event, TaskFailedEvent):
            self._running_ids.discard(event.task_id)
            self._failed_ids.add(event.task_id)
            self._failed_total += 1
            self._failed_by_type[event.task_type] += 1
            self._log_event(
                "FAILED", event.task_name, event.task_type, event.task_id,
                extra={"error": event.error},
            )

    async def _on_task_cancelled(self, event: SpectreEvent) -> None:
        if isinstance(event, TaskCancelledEvent):
            self._running_ids.discard(event.task_id)
            self._cancelled_ids.add(event.task_id)
            self._cancelled_total += 1
            self._log_event("CANCELLED", event.task_name, event.task_type, event.task_id)

    async def _on_task_retrying(self, event: SpectreEvent) -> None:
        if isinstance(event, TaskRetryingEvent):
            self._retried_total += 1
            self._log_event(
                "RETRYING", event.task_name, event.task_type, event.task_id,
                extra={"attempt": event.attempt, "delay": f"{event.delay_seconds:.1f}s"},
            )

    async def _on_engine_started(self, event: SpectreEvent) -> None:
        self._engine_start_time = time.monotonic()
        self._log_event("ENGINE_STARTED", "ExecutionEngine", "system", "—")

    async def _on_engine_stopped(self, event: SpectreEvent) -> None:
        self._log_event("ENGINE_STOPPED", "ExecutionEngine", "system", "—")

    # ------------------------------------------------------------------
    # Metrics output
    # ------------------------------------------------------------------

    async def snapshot(
        self,
        queue: Optional[Any] = None,
        scheduler: Optional[Any] = None,
    ) -> Dict[str, Any]:
        """
        Return a complete status snapshot.

        Parameters
        ----------
        queue:      TaskQueue — if provided, live queue depth is included.
        scheduler:  Scheduler — if provided, waiting task counts are included.
        """
        queue_stats: Dict = {}
        if queue is not None:
            queue_stats = await queue.stats()

        sched_stats: Dict = {}
        if scheduler is not None:
            sched_stats = scheduler.stats()

        uptime = time.monotonic() - self._start_time
        engine_uptime = (
            time.monotonic() - self._engine_start_time
            if self._engine_start_time else 0.0
        )

        return {
            "uptime_seconds":     round(uptime, 1),
            "engine_uptime_seconds": round(engine_uptime, 1),
            "tasks": {
                "running":        len(self._running_ids),
                "running_ids":    [tid[:8] for tid in self._running_ids],
                "completed":      self._completed_total,
                "failed":         self._failed_total,
                "cancelled":      self._cancelled_total,
                "retried":        self._retried_total,
            },
            "queue":              queue_stats,
            "scheduler":          sched_stats,
            "by_type": {
                "completed":      dict(self._completed_by_type),
                "failed":         dict(self._failed_by_type),
            },
            "recent_events":      self._recent_events[-10:],
        }

    def cli_summary(self) -> Dict[str, Any]:
        """
        Compact dict for the `spectre task status` CLI command.

        Expected output:
            Queue:     8
            Running:   2
            Completed: 25
            Failed:    1
        """
        return {
            "Running":   len(self._running_ids),
            "Completed": self._completed_total,
            "Failed":    self._failed_total,
            "Cancelled": self._cancelled_total,
            "Retried":   self._retried_total,
        }

    def recent_event_log(self, limit: int = 20) -> List[Dict[str, Any]]:
        """Return the most recent task events (newest last)."""
        return self._recent_events[-limit:]

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _log_event(
        self,
        status: str,
        name: str,
        task_type: str,
        task_id: str,
        extra: Optional[Dict] = None,
    ) -> None:
        """Append an entry to the rolling event log."""
        entry: Dict[str, Any] = {
            "ts":   datetime.now(timezone.utc).strftime("%H:%M:%S"),
            "status": status,
            "name": name,
            "type": task_type,
            "id":   task_id[:8] if task_id and task_id != "—" else "—",
        }
        if extra:
            entry.update(extra)

        self._recent_events.append(entry)
        if len(self._recent_events) > self._event_log_limit:
            self._recent_events.pop(0)

    def __repr__(self) -> str:
        return (
            f"<StatusTracker running={len(self._running_ids)} "
            f"completed={self._completed_total} "
            f"failed={self._failed_total}>"
        )
