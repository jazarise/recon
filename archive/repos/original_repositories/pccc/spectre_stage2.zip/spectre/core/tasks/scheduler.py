"""
spectre/core/tasks/scheduler.py

Dependency-aware task scheduler for the Spectre execution engine.

The Scheduler sits between the PlannerAgent and the TaskQueue.
It holds tasks that are not yet ready (dependencies unmet or delayed)
and promotes them to the queue the moment their preconditions are satisfied.

Scheduling modes:
    Immediate    — task has no dependencies and no delay; queued at once
    Dependency   — task waits until all dependency IDs are completed
    Delayed      — task queued after a fixed wall-clock delay
    Chained      — delayed + dependency combined

Architecture:
    PlannerAgent
        │
        ▼
    Scheduler.submit(task)
        │
        ├── dependencies met? → TaskQueue.add_task()
        └── waiting          → held in _pending pool
                                   │
                        on_task_completed(dep_id)
                                   │
                             re-evaluate pending
                                   │
                             TaskQueue.add_task()

Stage 2: Task Engine & Execution System
TODO Stage 3: PlannerAgent calls scheduler.submit() for all generated tasks
TODO Stage 5: ReasoningEngine calls scheduler.replan() to inject new tasks mid-run
"""

from __future__ import annotations

import asyncio
import time
from datetime import datetime, timezone
from typing import Any, Callable, Dict, List, Optional, Set

from spectre.core.logger import get_logger
from spectre.core.tasks.dependency_graph import DependencyGraph
from spectre.core.tasks.task import Task, TaskStatus

log = get_logger(__name__)


# ---------------------------------------------------------------------------
# Scheduler
# ---------------------------------------------------------------------------

class Scheduler:
    """
    Dependency-aware task scheduler.

    Maintains three internal pools:
        _waiting_deps   — tasks blocked on unmet dependencies
        _waiting_delay  — tasks blocked on a time delay
        _dep_graph      — DAG tracking all submitted task relationships

    The scheduler is driven by two triggers:
        submit(task)           — called by PlannerAgent to add a new task
        notify_completed(id)   — called by ExecutionEngine when a task finishes
    """

    def __init__(self, queue: Any) -> None:
        """
        Parameters
        ----------
        queue : TaskQueue
            The async priority queue that receives ready tasks.
        """
        self._queue = queue
        self._dep_graph = DependencyGraph()

        # task_id → Task for tasks with unmet dependencies
        self._waiting_deps: Dict[str, Task] = {}

        # task_id → (Task, run_at_monotonic) for delayed tasks
        self._waiting_delay: Dict[str, tuple] = {}

        # IDs of all tasks known to this scheduler
        self._all_ids: Set[str] = set()

        # Completed task IDs — used for dependency resolution
        self._completed_ids: Set[str] = set()

        # Background delay-check loop handle
        self._delay_loop_task: Optional[asyncio.Task] = None

        # Metrics
        self._submitted_total: int = 0
        self._promoted_total: int = 0

        log.debug("Scheduler initialized")

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def start(self) -> None:
        """Start the background delay-monitoring loop."""
        self._delay_loop_task = asyncio.create_task(
            self._delay_loop(), name="scheduler-delay-loop"
        )
        log.info("Scheduler started")

    async def stop(self) -> None:
        """Stop the background loop gracefully."""
        if self._delay_loop_task and not self._delay_loop_task.done():
            self._delay_loop_task.cancel()
            try:
                await self._delay_loop_task
            except asyncio.CancelledError:
                pass
        log.info("Scheduler stopped")

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def submit(
        self,
        task: Task,
        delay_seconds: float = 0.0,
    ) -> None:
        """
        Submit a task for scheduling.

        Parameters
        ----------
        task:
            The task to schedule. Must be in PENDING status.
        delay_seconds:
            If > 0, the task will not be queued until this many seconds
            have elapsed, regardless of dependency status.

        The scheduler registers the task's declared dependencies
        (task.dependencies) in the DependencyGraph and evaluates
        whether the task is immediately ready.
        """
        self._submitted_total += 1
        self._all_ids.add(task.id)

        # Register in dependency graph
        self._dep_graph.add_task(task.id, name=task.name)
        for dep_id in task.dependencies:
            if self._dep_graph._g.has_node(dep_id):
                try:
                    self._dep_graph.add_dependency(dep_id, task.id)
                except ValueError as exc:
                    log.error("Dependency cycle detected — task rejected | {}", exc)
                    return

        log.debug(
            "Scheduler: task submitted | id={} | name={} | deps={} | delay={:.1f}s",
            task.id[:8], task.name, len(task.dependencies), delay_seconds,
        )

        # Handle delayed tasks
        if delay_seconds > 0:
            run_at = time.monotonic() + delay_seconds
            self._waiting_delay[task.id] = (task, run_at)
            log.info(
                "Task delayed | id={} | name={} | delay={:.1f}s",
                task.id[:8], task.name, delay_seconds,
            )
            return

        # Evaluate immediate readiness
        await self._evaluate(task)

    async def notify_completed(self, task_id: str) -> None:
        """
        Notify the scheduler that a task has completed successfully.

        This triggers a re-evaluation of all tasks waiting on this
        task as a dependency.
        """
        self._completed_ids.add(task_id)
        self._dep_graph.mark_completed(task_id)

        log.debug("Scheduler: notified completed | id={}", task_id[:8])

        # Find all waiting tasks that depend on this one
        dependents = self._dep_graph.get_dependents(task_id)
        for dep_id in dependents:
            if dep_id in self._waiting_deps:
                task = self._waiting_deps[dep_id]
                await self._evaluate(task)

    async def notify_failed(self, task_id: str) -> None:
        """
        Notify the scheduler that a task has failed (not being retried).

        Dependents of the failed task are cancelled.
        TODO Stage 5: ReasoningEngine may replan around failures instead.
        """
        self._dep_graph.mark_failed(task_id)
        blocked = self._dep_graph.blocked_by_failure(task_id)

        if blocked:
            log.warning(
                "Task failure blocks {} downstream task(s) | failed={}",
                len(blocked), task_id[:8],
            )
            for blocked_id in blocked:
                task = self._waiting_deps.pop(blocked_id, None)
                if task:
                    task.transition(TaskStatus.CANCELLED)
                    log.info(
                        "Downstream task cancelled | id={} | name={}",
                        blocked_id[:8], task.name,
                    )

    async def resubmit(self, task: Task, delay_seconds: float = 0.0) -> None:
        """
        Re-submit a task that was previously removed or cancelled.
        Cleans up stale graph entries before re-registering.
        TODO Stage 5: ReasoningEngine calls this during replan.
        """
        self._dep_graph.remove_task(task.id)
        self._all_ids.discard(task.id)
        self._waiting_deps.pop(task.id, None)
        self._waiting_delay.pop(task.id, None)
        task.status = TaskStatus.PENDING
        await self.submit(task, delay_seconds=delay_seconds)

    # ------------------------------------------------------------------
    # Scheduling order helpers
    # ------------------------------------------------------------------

    def topological_order(self) -> List[str]:
        """
        Return all known task IDs in valid execution order.
        Useful for pre-flight plan display and debugging.
        """
        try:
            return self._dep_graph.topological_order()
        except ValueError as exc:
            log.error("Cannot compute topological order | {}", exc)
            return []

    # ------------------------------------------------------------------
    # Status
    # ------------------------------------------------------------------

    def waiting_count(self) -> int:
        """Total number of tasks not yet promoted to the queue."""
        return len(self._waiting_deps) + len(self._waiting_delay)

    def stats(self) -> Dict[str, Any]:
        return {
            "submitted_total":  self._submitted_total,
            "promoted_total":   self._promoted_total,
            "waiting_deps":     len(self._waiting_deps),
            "waiting_delay":    len(self._waiting_delay),
            "completed_known":  len(self._completed_ids),
            "graph_summary":    self._dep_graph.summary(),
        }

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    async def _evaluate(self, task: Task) -> None:
        """
        Check whether a task's dependencies are met.
        If yes, promote it to the queue. If no, hold it in _waiting_deps.
        """
        # Check all declared dependencies against completed set
        unmet = [
            dep for dep in task.dependencies
            if dep not in self._completed_ids
        ]

        if unmet:
            self._waiting_deps[task.id] = task
            log.debug(
                "Task waiting on {} dep(s) | id={} | name={} | unmet={}",
                len(unmet), task.id[:8], task.name,
                [u[:8] for u in unmet],
            )
        else:
            await self._promote(task)

    async def _promote(self, task: Task) -> None:
        """Move a task from the waiting pool into the live queue."""
        self._waiting_deps.pop(task.id, None)
        self._waiting_delay.pop(task.id, None)

        try:
            await self._queue.add_task(task)
            self._promoted_total += 1
            log.info(
                "Task promoted to queue | id={} | name={} | priority={}",
                task.id[:8], task.name, task.priority.name,
            )
        except Exception as exc:
            log.error(
                "Failed to promote task to queue | id={} | {} ",
                task.id[:8], exc,
            )

    async def _delay_loop(self) -> None:
        """
        Background coroutine that polls delayed tasks every 0.5 seconds
        and promotes them when their scheduled time arrives.
        """
        log.debug("Scheduler delay loop started")
        try:
            while True:
                await asyncio.sleep(0.5)
                now = time.monotonic()
                ready_ids = [
                    tid for tid, (_, run_at) in self._waiting_delay.items()
                    if now >= run_at
                ]
                for tid in ready_ids:
                    task, _ = self._waiting_delay.pop(tid)
                    log.info(
                        "Delayed task now ready | id={} | name={}",
                        task.id[:8], task.name,
                    )
                    await self._evaluate(task)
        except asyncio.CancelledError:
            log.debug("Scheduler delay loop cancelled")
