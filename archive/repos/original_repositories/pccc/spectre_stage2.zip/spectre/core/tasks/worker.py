"""
spectre/core/tasks/worker.py

Worker base class and concrete worker stubs for the Spectre execution engine.

Architecture:
    ExecutionEngine → WorkerRegistry → Worker.execute(task) → TaskResult

Every Worker is responsible for:
  1. Accepting a Task
  2. Performing the actual work (tool execution, parsing, analysis)
  3. Returning a populated TaskResult

Workers are stateless per-execution. The ExecutionEngine passes them tasks;
workers must not hold cross-task mutable state.

Concrete workers in Stage 2 are stubs with full lifecycle hooks.
Stage 3+ will fill in real tool execution via the ToolWrapper layer.

Workers registered in Stage 2:
    GenericWorker   — catch-all for any task type
    ScanWorker      — network scanning (nmap, masscan)
    ParseWorker     — output parsing / entity extraction
    WebWorker       — web enumeration / HTTP interaction
    CryptoWorker    — cryptographic analysis
    ForensicsWorker — disk / memory / PCAP analysis
    StegoWorker     — steganography analysis
    ReverseWorker   — binary / reverse engineering
    MemoryWorker    — memory system read/write ops (Stage 4 stub)

Stage 2: Task Engine & Execution System
TODO Stage 3: Replace stub execute() bodies with real ToolWrapper calls
TODO Stage 3: Each worker emits structured findings via ParserEngine
TODO Stage 4: MemoryWorker reads/writes MemorySystem
TODO Stage 5: Workers report confidence scores to ReasoningEngine
"""

from __future__ import annotations

import abc
import asyncio
import time
import uuid
from typing import Any, Dict, List, Optional, Type

from spectre.core.logger import get_logger
from spectre.core.tasks.task import Task, TaskResult, TaskType

log = get_logger(__name__)


# ---------------------------------------------------------------------------
# Base Worker
# ---------------------------------------------------------------------------

class BaseWorker(abc.ABC):
    """
    Abstract base class for all Spectre workers.

    Subclasses must implement:
        - worker_type: str  — unique identifier
        - handles: List[TaskType]  — task types this worker accepts
        - _execute(task) → TaskResult  — the actual work logic
    """

    # --- Class-level descriptors (must be overridden) ---

    @property
    @abc.abstractmethod
    def worker_type(self) -> str:
        """Unique snake_case identifier for this worker."""
        ...

    @property
    @abc.abstractmethod
    def handles(self) -> List[TaskType]:
        """List of TaskTypes this worker is capable of handling."""
        ...

    # --- Instance state ---

    def __init__(self) -> None:
        self.id: str = str(uuid.uuid4())[:8]
        self._tasks_completed: int = 0
        self._tasks_failed: int = 0
        self._active_task: Optional[str] = None

    # --- Lifecycle hooks ---

    async def on_startup(self) -> None:
        """
        Called once when the worker is registered with the engine.
        Override to set up persistent resources (HTTP sessions, DB handles).
        TODO Stage 3: Open tool subprocess pools here.
        """
        log.debug("Worker {} ({}) started", self.worker_type, self.id)

    async def on_shutdown(self) -> None:
        """
        Called once during engine shutdown.
        Override to clean up resources.
        """
        log.debug("Worker {} ({}) shut down", self.worker_type, self.id)

    async def on_task_start(self, task: Task) -> None:
        """Hook called immediately before _execute(). Override for setup."""
        self._active_task = task.id

    async def on_task_complete(self, task: Task, result: TaskResult) -> None:
        """Hook called after a successful _execute(). Override for cleanup."""
        self._tasks_completed += 1
        self._active_task = None

    async def on_task_fail(self, task: Task, exc: Exception) -> None:
        """Hook called when _execute() raises. Override for cleanup."""
        self._tasks_failed += 1
        self._active_task = None

    # --- Core execution ---

    async def execute(self, task: Task) -> TaskResult:
        """
        Orchestrate a full task execution cycle with hooks.

        Do NOT override this method. Override _execute() instead.
        """
        start = time.monotonic()
        await self.on_task_start(task)

        try:
            result = await self._execute(task)
            result.worker_id = self.id
            result.duration_seconds = time.monotonic() - start
            await self.on_task_complete(task, result)
            return result

        except Exception as exc:
            duration = time.monotonic() - start
            await self.on_task_fail(task, exc)
            log.error(
                "Worker {} failed on task '{}' | {} | dur={:.2f}s",
                self.worker_type, task.name, exc, duration,
            )
            return TaskResult(
                success=False,
                error=str(exc),
                duration_seconds=duration,
                worker_id=self.id,
            )

    @abc.abstractmethod
    async def _execute(self, task: Task) -> TaskResult:
        """
        Perform the actual work for a task.

        Parameters
        ----------
        task: Task — the fully validated task object including payload.

        Returns
        -------
        TaskResult — populated result object. Set success=True and
                     populate `data` and optionally `raw_output`.
        """
        ...

    # --- Metrics / introspection ---

    def describe(self) -> Dict[str, Any]:
        return {
            "id":                self.id,
            "worker_type":       self.worker_type,
            "handles":           [t.value for t in self.handles],
            "tasks_completed":   self._tasks_completed,
            "tasks_failed":      self._tasks_failed,
            "active_task":       self._active_task,
        }

    def __repr__(self) -> str:
        return f"<Worker {self.worker_type} id={self.id}>"


# ---------------------------------------------------------------------------
# Worker Registry
# ---------------------------------------------------------------------------

class WorkerRegistry:
    """
    Central registry mapping TaskType → Worker instance.

    Workers are registered at startup and looked up per-task by the
    ExecutionEngine. Multiple workers can handle the same TaskType;
    the first registered worker wins (round-robin in Stage 3+).
    """

    def __init__(self) -> None:
        # TaskType → list of worker instances (for future load balancing)
        self._registry: Dict[TaskType, List[BaseWorker]] = {}
        self._all_workers: Dict[str, BaseWorker] = {}  # worker_id → worker

        log.debug("WorkerRegistry initialized")

    async def register(self, worker: BaseWorker) -> None:
        """Register a worker and call its on_startup() hook."""
        await worker.on_startup()

        for task_type in worker.handles:
            self._registry.setdefault(task_type, []).append(worker)

        self._all_workers[worker.id] = worker
        log.info(
            "Worker registered | type={} | id={} | handles={}",
            worker.worker_type, worker.id,
            [t.value for t in worker.handles],
        )

    async def unregister_all(self) -> None:
        """Shut down all registered workers."""
        for worker in self._all_workers.values():
            try:
                await worker.on_shutdown()
            except Exception as exc:
                log.warning("Error shutting down worker {} | {}", worker.id, exc)
        self._registry.clear()
        self._all_workers.clear()
        log.info("All workers unregistered")

    def resolve(self, task: Task) -> Optional[BaseWorker]:
        """
        Find the best worker for a task.

        Routing priority:
          1. If task.worker_type is set, find that specific worker type.
          2. Otherwise, look up by task.type.
          3. Fall back to GenericWorker if no specific match.
        """
        if task.worker_type:
            for worker in self._all_workers.values():
                if worker.worker_type == task.worker_type:
                    return worker

        candidates = self._registry.get(task.type)
        if candidates:
            # TODO Stage 3: Replace with load-balanced selection
            return candidates[0]

        # Fallback to generic
        generic = self._registry.get(TaskType.GENERIC)
        if generic:
            return generic[0]

        return None

    def list_workers(self) -> List[Dict[str, Any]]:
        return [w.describe() for w in self._all_workers.values()]

    def __repr__(self) -> str:
        return f"<WorkerRegistry workers={len(self._all_workers)}>"


# ---------------------------------------------------------------------------
# Concrete Workers (Stage 2 stubs)
# ---------------------------------------------------------------------------

class GenericWorker(BaseWorker):
    """
    Catch-all worker that handles any TaskType.
    Used as the fallback when no specialized worker is registered.
    """

    @property
    def worker_type(self) -> str:
        return "generic"

    @property
    def handles(self) -> List[TaskType]:
        return [TaskType.GENERIC]

    async def _execute(self, task: Task) -> TaskResult:
        """
        Generic execution stub.
        TODO Stage 3: Route to appropriate tool based on task.payload["tool"]
        """
        log.debug("GenericWorker executing task '{}' | id={}", task.name, task.id[:8])
        await asyncio.sleep(0)  # yield to event loop

        return TaskResult(
            success=True,
            data={"message": "Generic execution placeholder", "payload": task.payload},
            raw_output=f"[GenericWorker] Task '{task.name}' completed (stub)",
        )


class ScanWorker(BaseWorker):
    """
    Network scanning worker.
    Stage 2: Stub. Stage 3: Wraps nmap, masscan, rustscan via ToolWrapper.
    """

    @property
    def worker_type(self) -> str:
        return "scan"

    @property
    def handles(self) -> List[TaskType]:
        return [TaskType.SCAN]

    async def _execute(self, task: Task) -> TaskResult:
        """
        TODO Stage 3: Execute nmap/masscan based on task.payload:
            target: str — IP or hostname
            ports:  str — port range (e.g. "1-65535")
            flags:  List[str] — additional nmap flags
        """
        target = task.payload.get("target", "unknown")
        log.info("ScanWorker stub | target={} | task={}", target, task.name)
        await asyncio.sleep(0)

        return TaskResult(
            success=True,
            data={
                "target": target,
                "open_ports": [],  # TODO Stage 3: populate from nmap XML output
                "services": [],
                "os_guess": None,
            },
            raw_output=f"[ScanWorker stub] Scanned {target} — Stage 3 will run nmap",
        )


class ParseWorker(BaseWorker):
    """
    Output parsing worker.
    Stage 2: Stub. Stage 3: Integrates with ParserEngine for entity extraction.
    """

    @property
    def worker_type(self) -> str:
        return "parse"

    @property
    def handles(self) -> List[TaskType]:
        return [TaskType.PARSE]

    async def _execute(self, task: Task) -> TaskResult:
        """
        TODO Stage 3: Pass task.payload["raw_output"] through ParserEngine:
            - entity extraction (IPs, URLs, users, hashes)
            - confidence scoring
            - KnowledgeGraph injection
        """
        raw = task.payload.get("raw_output", "")
        log.info("ParseWorker stub | input_length={} | task={}", len(raw), task.name)
        await asyncio.sleep(0)

        return TaskResult(
            success=True,
            data={
                "entities": [],    # TODO Stage 3: extracted entities
                "confidence": 0.0, # TODO Stage 3: confidence scoring
            },
            raw_output=raw,
        )


class WebWorker(BaseWorker):
    """
    Web enumeration and exploitation worker.
    Stage 2: Stub. Stage 3: Wraps gobuster, nikto, curl, whatweb.
    """

    @property
    def worker_type(self) -> str:
        return "web"

    @property
    def handles(self) -> List[TaskType]:
        return [TaskType.WEB]

    async def _execute(self, task: Task) -> TaskResult:
        """
        TODO Stage 3: Orchestrate web enumeration pipeline:
            1. HTTP banner / technology fingerprint
            2. Directory bruteforce (gobuster/ffuf)
            3. JavaScript endpoint extraction
            4. Vulnerability scanning (nikto)
        """
        target = task.payload.get("target", "unknown")
        log.info("WebWorker stub | target={} | task={}", target, task.name)
        await asyncio.sleep(0)

        return TaskResult(
            success=True,
            data={
                "target": target,
                "endpoints": [],
                "technologies": [],
                "vulnerabilities": [],
            },
            raw_output=f"[WebWorker stub] Enumerated {target} — Stage 3 will run gobuster/nikto",
        )


class CryptoWorker(BaseWorker):
    """
    Cryptographic analysis worker.
    Stage 2: Stub. Stage 3: Integrates cipher detection, RSA weaknesses, hash cracking.
    """

    @property
    def worker_type(self) -> str:
        return "crypto"

    @property
    def handles(self) -> List[TaskType]:
        return [TaskType.CRYPTO]

    async def _execute(self, task: Task) -> TaskResult:
        """
        TODO Stage 3: Run crypto analysis pipeline:
            - hashid for hash type detection
            - frequency analysis for classical ciphers
            - RSA parameter weakness checks
            - john/hashcat for hash cracking
        """
        ciphertext = task.payload.get("ciphertext", "")
        log.info("CryptoWorker stub | input_length={} | task={}", len(ciphertext), task.name)
        await asyncio.sleep(0)

        return TaskResult(
            success=True,
            data={
                "cipher_type": "unknown",   # TODO Stage 3
                "plaintext":   None,
                "key":         None,
            },
            raw_output="[CryptoWorker stub] — Stage 3 will run hashid/john",
        )


class ForensicsWorker(BaseWorker):
    """
    Digital forensics worker.
    Stage 2: Stub. Stage 3: Integrates volatility, foremost, tshark.
    """

    @property
    def worker_type(self) -> str:
        return "forensics"

    @property
    def handles(self) -> List[TaskType]:
        return [TaskType.FORENSICS]

    async def _execute(self, task: Task) -> TaskResult:
        """
        TODO Stage 3: Run forensics pipeline:
            - volatility3 for memory dumps
            - foremost/scalpel for file carving
            - tshark for PCAP analysis
            - strings + grep for artifact extraction
        """
        file_path = task.payload.get("file_path", "")
        log.info("ForensicsWorker stub | file={} | task={}", file_path, task.name)
        await asyncio.sleep(0)

        return TaskResult(
            success=True,
            data={
                "artifacts": [],
                "processes": [],
                "network_connections": [],
                "carved_files": [],
            },
            raw_output=f"[ForensicsWorker stub] Analyzed {file_path} — Stage 3 will run volatility",
        )


class StegoWorker(BaseWorker):
    """
    Steganography analysis worker.
    Stage 2: Stub. Stage 3: Integrates steghide, zsteg, binwalk, exiftool.
    """

    @property
    def worker_type(self) -> str:
        return "stego"

    @property
    def handles(self) -> List[TaskType]:
        return [TaskType.STEGO]

    async def _execute(self, task: Task) -> TaskResult:
        """
        TODO Stage 3: Run stego analysis pipeline:
            - exiftool for metadata
            - binwalk for embedded files
            - zsteg for LSB (PNG)
            - steghide for passphrase-based stego
        """
        file_path = task.payload.get("file_path", "")
        log.info("StegoWorker stub | file={} | task={}", file_path, task.name)
        await asyncio.sleep(0)

        return TaskResult(
            success=True,
            data={
                "hidden_data": None,
                "metadata": {},
                "embedded_files": [],
                "lsb_payload": None,
            },
            raw_output=f"[StegoWorker stub] Analyzed {file_path} — Stage 3 will run steghide/zsteg",
        )


class ReverseWorker(BaseWorker):
    """
    Binary / reverse engineering worker.
    Stage 2: Stub. Stage 3: Integrates radare2, ghidra headless, strings.
    """

    @property
    def worker_type(self) -> str:
        return "reverse"

    @property
    def handles(self) -> List[TaskType]:
        return [TaskType.REVERSE]

    async def _execute(self, task: Task) -> TaskResult:
        """
        TODO Stage 3: Run binary analysis pipeline:
            - file type detection
            - strings extraction
            - radare2 for disassembly
            - ghidra headless for decompilation
            - checksec for binary protections
        """
        binary_path = task.payload.get("binary_path", "")
        log.info("ReverseWorker stub | binary={} | task={}", binary_path, task.name)
        await asyncio.sleep(0)

        return TaskResult(
            success=True,
            data={
                "file_type": "unknown",
                "architecture": "unknown",
                "protections": {},
                "strings": [],
                "functions": [],
            },
            raw_output=f"[ReverseWorker stub] Analyzed {binary_path} — Stage 3 will run radare2",
        )


class MemoryWorker(BaseWorker):
    """
    Memory system read/write worker.
    Stage 2: Stub. Stage 4: Reads/writes the MemorySystem (episodic/semantic).
    """

    @property
    def worker_type(self) -> str:
        return "memory"

    @property
    def handles(self) -> List[TaskType]:
        return [TaskType.MEMORY]

    async def _execute(self, task: Task) -> TaskResult:
        """
        TODO Stage 4: Interface with MemorySystem:
            - store episodic records from task results
            - query semantic memory for relevant context
            - retrieve long-term memory for agent reasoning
        """
        operation = task.payload.get("operation", "unknown")
        log.info("MemoryWorker stub | op={} | task={}", operation, task.name)
        await asyncio.sleep(0)

        return TaskResult(
            success=True,
            data={"operation": operation, "result": None},
            raw_output="[MemoryWorker stub] — Stage 4 will implement MemorySystem",
        )


# ---------------------------------------------------------------------------
# Default worker set (registered at engine startup)
# ---------------------------------------------------------------------------

DEFAULT_WORKERS: List[Type[BaseWorker]] = [
    GenericWorker,
    ScanWorker,
    ParseWorker,
    WebWorker,
    CryptoWorker,
    ForensicsWorker,
    StegoWorker,
    ReverseWorker,
    MemoryWorker,
]
