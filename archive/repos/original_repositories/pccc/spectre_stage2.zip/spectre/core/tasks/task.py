"""
spectre/core/tasks/task.py

Strongly-typed Pydantic task model for the Spectre execution engine.

A Task is the atomic unit of work in Spectre. Every agent action,
tool execution, scan, parse operation, or analysis step is expressed
as a Task. Tasks flow through the queue → executor → worker pipeline.

State machine:
    pending → queued → running → completed
                              ↘ failed → (retry) → queued
                              ↘ cancelled
                    ↗ paused ↘ queued (resume)

Stage 2: Task Engine & Execution System
TODO Stage 3: Link tasks to KnowledgeGraph update hooks
TODO Stage 4: Link task results to MemorySystem episodic records
TODO Stage 5: ReasoningEngine reads task history to plan next tasks
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field, field_validator, model_validator


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _new_task_id() -> str:
    return str(uuid.uuid4())


# ---------------------------------------------------------------------------
# Enumerations
# ---------------------------------------------------------------------------

class TaskStatus(str, Enum):
    """All valid lifecycle states for a Task."""
    PENDING   = "pending"
    QUEUED    = "queued"
    RUNNING   = "running"
    COMPLETED = "completed"
    FAILED    = "failed"
    CANCELLED = "cancelled"
    PAUSED    = "paused"


class TaskType(str, Enum):
    """
    Broad functional category of a task.
    Used by the ExecutionEngine to route tasks to the correct Worker.
    """
    SCAN       = "scan"        # Network / port scanning
    PARSE      = "parse"       # Output parsing / entity extraction
    WEB        = "web"         # Web enumeration / exploitation
    CRYPTO     = "crypto"      # Cryptographic analysis
    FORENSICS  = "forensics"   # Disk / memory / pcap analysis
    STEGO      = "stego"       # Steganography
    REVERSE    = "reverse"     # Binary / reverse engineering
    PRIVSEC    = "privsec"     # Privilege escalation
    MEMORY     = "memory"      # Memory system read/write
    REASONING  = "reasoning"   # Reasoning engine step
    GENERIC    = "generic"     # Catch-all for uncategorized tasks


class TaskPriority(int, Enum):
    """
    Integer priority levels — lower number = higher priority.
    The async priority queue uses these values directly.
    """
    CRITICAL = 0
    HIGH     = 1
    NORMAL   = 2
    LOW      = 3
    IDLE     = 4


# ---------------------------------------------------------------------------
# Sub-models
# ---------------------------------------------------------------------------

class TaskResult(BaseModel):
    """
    Structured output captured after a task completes or fails.

    Workers populate this object and attach it to the parent Task.
    The ParserEngine (Stage 3) reads `raw_output` and `data` to extract
    entities into the KnowledgeGraph.
    """

    success: bool = False
    data: Dict[str, Any] = Field(default_factory=dict)
    raw_output: Optional[str] = None
    error: Optional[str] = None
    exit_code: Optional[int] = None
    duration_seconds: Optional[float] = None
    worker_id: Optional[str] = None

    # TODO Stage 3: graph_entities: List[GraphEntity] = []
    # TODO Stage 4: memory_snapshot_id: Optional[str] = None


class RetryPolicy(BaseModel):
    """
    Per-task retry configuration.
    Overrides the engine-level default when present.
    """

    max_retries: int = Field(default=3, ge=0, le=20)
    backoff_base: float = Field(default=2.0, ge=1.0)   # exponential base
    backoff_max: float = Field(default=60.0, ge=1.0)   # cap in seconds
    retry_on: List[str] = Field(
        default_factory=lambda: ["timeout", "tool_failure", "transient_error"]
    )

    def backoff_delay(self, attempt: int) -> float:
        """Calculate exponential backoff delay for the given attempt number."""
        delay = self.backoff_base ** attempt
        return min(delay, self.backoff_max)


class TaskTimestamps(BaseModel):
    """Immutable audit trail of when a task transitioned through states."""

    created_at:   datetime = Field(default_factory=_utc_now)
    queued_at:    Optional[datetime] = None
    started_at:   Optional[datetime] = None
    completed_at: Optional[datetime] = None
    failed_at:    Optional[datetime] = None
    cancelled_at: Optional[datetime] = None
    paused_at:    Optional[datetime] = None
    resumed_at:   Optional[datetime] = None

    def mark(self, state: TaskStatus) -> None:
        """Stamp the appropriate timestamp for a given state transition."""
        now = _utc_now()
        mapping = {
            TaskStatus.QUEUED:    "queued_at",
            TaskStatus.RUNNING:   "started_at",
            TaskStatus.COMPLETED: "completed_at",
            TaskStatus.FAILED:    "failed_at",
            TaskStatus.CANCELLED: "cancelled_at",
            TaskStatus.PAUSED:    "paused_at",
        }
        attr = mapping.get(state)
        if attr:
            object.__setattr__(self, attr, now)

    def elapsed_seconds(self) -> Optional[float]:
        """Wall-clock seconds from started_at to completed_at/failed_at."""
        if not self.started_at:
            return None
        end = self.completed_at or self.failed_at or _utc_now()
        return (end - self.started_at).total_seconds()


# ---------------------------------------------------------------------------
# Core Task model
# ---------------------------------------------------------------------------

class Task(BaseModel):
    """
    Atomic unit of work within the Spectre execution engine.

    Tasks are created by the PlannerAgent (Stage 3), enqueued by the
    TaskQueue, executed by the ExecutionEngine via Workers, and their
    results flow back into the KnowledgeGraph and MemorySystem.

    Serializes to/from JSON for persistence and event payloads.
    """

    # Identity
    id: str = Field(default_factory=_new_task_id)
    name: str
    description: str = ""

    # Classification
    type: TaskType = TaskType.GENERIC
    priority: TaskPriority = TaskPriority.NORMAL

    # Lifecycle
    status: TaskStatus = TaskStatus.PENDING

    # Dependency tracking — list of Task IDs that must complete first
    dependencies: List[str] = Field(default_factory=list)

    # Retry tracking
    retries: int = Field(default=0, ge=0)
    retry_policy: RetryPolicy = Field(default_factory=RetryPolicy)

    # Worker routing — if set, only this worker type handles the task
    worker_type: Optional[str] = None

    # Arbitrary key-value payload passed to the Worker
    payload: Dict[str, Any] = Field(default_factory=dict)

    # Metadata (session linkage, tags, source agent, etc.)
    metadata: Dict[str, Any] = Field(default_factory=dict)

    # Session linkage
    session_id: Optional[str] = None

    # Results captured by the Worker
    result: Optional[TaskResult] = None

    # Timestamps
    timestamps: TaskTimestamps = Field(default_factory=TaskTimestamps)

    # Tags for filtering and observability
    tags: List[str] = Field(default_factory=list)

    model_config = {"use_enum_values": False}  # keep enum objects for comparisons

    # ------------------------------------------------------------------
    # Validators
    # ------------------------------------------------------------------

    @field_validator("name")
    @classmethod
    def name_must_not_be_empty(cls, v: str) -> str:
        if not v.strip():
            raise ValueError("Task name must not be empty")
        return v.strip()

    # ------------------------------------------------------------------
    # State machine helpers
    # ------------------------------------------------------------------

    # Valid forward transitions
    _TRANSITIONS: Dict[TaskStatus, List[TaskStatus]] = {
        TaskStatus.PENDING:   [TaskStatus.QUEUED, TaskStatus.CANCELLED],
        TaskStatus.QUEUED:    [TaskStatus.RUNNING, TaskStatus.CANCELLED, TaskStatus.PAUSED],
        TaskStatus.RUNNING:   [TaskStatus.COMPLETED, TaskStatus.FAILED, TaskStatus.CANCELLED, TaskStatus.PAUSED],
        TaskStatus.FAILED:    [TaskStatus.QUEUED],   # retry path
        TaskStatus.PAUSED:    [TaskStatus.QUEUED, TaskStatus.CANCELLED],
        TaskStatus.COMPLETED: [],
        TaskStatus.CANCELLED: [],
    }

    def can_transition(self, new_status: TaskStatus) -> bool:
        """Return True if transitioning to new_status is a valid move."""
        return new_status in self._TRANSITIONS.get(self.status, [])

    def transition(self, new_status: TaskStatus) -> None:
        """
        Apply a validated state transition and stamp the timestamp.

        Raises ValueError on illegal transitions to enforce the state machine.
        """
        if not self.can_transition(new_status):
            raise ValueError(
                f"Invalid transition: {self.status.value} → {new_status.value} "
                f"for task '{self.name}' ({self.id[:8]})"
            )
        self.status = new_status
        self.timestamps.mark(new_status)

    def is_terminal(self) -> bool:
        """Return True if the task has reached a terminal state."""
        return self.status in (TaskStatus.COMPLETED, TaskStatus.CANCELLED)

    def is_ready(self, completed_ids: set[str]) -> bool:
        """
        Return True if all dependencies are in the completed_ids set,
        meaning this task is eligible for queuing.
        """
        return all(dep in completed_ids for dep in self.dependencies)

    def increment_retry(self) -> None:
        """Increment retry counter and re-queue the task."""
        if self.retries >= self.retry_policy.max_retries:
            raise ValueError(
                f"Task '{self.name}' has exhausted {self.retry_policy.max_retries} retries"
            )
        self.retries += 1
        self.transition(TaskStatus.QUEUED)

    # ------------------------------------------------------------------
    # Serialization helpers
    # ------------------------------------------------------------------

    def to_summary(self) -> Dict[str, Any]:
        """Compact dict for CLI table and status display."""
        elapsed = self.timestamps.elapsed_seconds()
        return {
            "id":       self.id[:8],
            "name":     self.name,
            "type":     self.type.value,
            "priority": self.priority.name,
            "status":   self.status.value,
            "retries":  self.retries,
            "elapsed":  f"{elapsed:.1f}s" if elapsed is not None else "—",
            "session":  (self.session_id or "—")[:8],
        }

    def __repr__(self) -> str:
        return (
            f"<Task id={self.id[:8]} name={self.name!r} "
            f"type={self.type.value} status={self.status.value} "
            f"priority={self.priority.name}>"
        )

    # Priority comparison operators — used by heapq in the async queue
    def __lt__(self, other: "Task") -> bool:
        return self.priority.value < other.priority.value

    def __le__(self, other: "Task") -> bool:
        return self.priority.value <= other.priority.value
