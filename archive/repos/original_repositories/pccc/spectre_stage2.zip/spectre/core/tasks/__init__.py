"""
spectre.core.tasks

Task Engine & Execution System — Stage 2.

Public surface:

    Task, TaskStatus, TaskType, TaskPriority, TaskResult, RetryPolicy
    TaskQueue
    ExecutionEngine
    BaseWorker, WorkerRegistry, DEFAULT_WORKERS
    Scheduler
    DependencyGraph
    RetryEngine, classify_failure, FailureClass
    EventBus, EventType, SpectreEvent  (+ all concrete event types)
    StatusTracker
"""

from spectre.core.tasks.task import (
    Task,
    TaskStatus,
    TaskType,
    TaskPriority,
    TaskResult,
    TaskTimestamps,
    RetryPolicy,
)
from spectre.core.tasks.queue import TaskQueue
from spectre.core.tasks.executor import ExecutionEngine
from spectre.core.tasks.worker import (
    BaseWorker,
    WorkerRegistry,
    GenericWorker,
    ScanWorker,
    ParseWorker,
    WebWorker,
    CryptoWorker,
    ForensicsWorker,
    StegoWorker,
    ReverseWorker,
    MemoryWorker,
    DEFAULT_WORKERS,
)
from spectre.core.tasks.scheduler import Scheduler
from spectre.core.tasks.dependency_graph import DependencyGraph
from spectre.core.tasks.retry import RetryEngine, classify_failure, FailureClass
from spectre.core.tasks.events import (
    EventBus,
    EventType,
    SpectreEvent,
    TaskEvent,
    TaskCreatedEvent,
    TaskQueuedEvent,
    TaskStartedEvent,
    TaskCompletedEvent,
    TaskFailedEvent,
    TaskCancelledEvent,
    TaskPausedEvent,
    TaskResumedEvent,
    TaskRetryingEvent,
    EngineStartedEvent,
    EngineStoppedEvent,
    get_event_bus,
)
from spectre.core.tasks.status import StatusTracker

__all__ = [
    # Task model
    "Task", "TaskStatus", "TaskType", "TaskPriority",
    "TaskResult", "TaskTimestamps", "RetryPolicy",
    # Queue
    "TaskQueue",
    # Engine
    "ExecutionEngine",
    # Workers
    "BaseWorker", "WorkerRegistry", "DEFAULT_WORKERS",
    "GenericWorker", "ScanWorker", "ParseWorker", "WebWorker",
    "CryptoWorker", "ForensicsWorker", "StegoWorker",
    "ReverseWorker", "MemoryWorker",
    # Scheduler
    "Scheduler",
    # Dependency Graph
    "DependencyGraph",
    # Retry
    "RetryEngine", "classify_failure", "FailureClass",
    # Events
    "EventBus", "EventType", "SpectreEvent",
    "TaskEvent", "TaskCreatedEvent", "TaskQueuedEvent",
    "TaskStartedEvent", "TaskCompletedEvent", "TaskFailedEvent",
    "TaskCancelledEvent", "TaskPausedEvent", "TaskResumedEvent",
    "TaskRetryingEvent", "EngineStartedEvent", "EngineStoppedEvent",
    "get_event_bus",
    # Status
    "StatusTracker",
]
