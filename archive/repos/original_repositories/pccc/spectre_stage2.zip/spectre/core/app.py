"""
spectre/core/app.py

Application bootstrap for Spectre.

Stage 1:  Configuration, Logging, Sessions, Plugins, CLI
Stage 2:  TaskQueue, ExecutionEngine, Scheduler, EventBus,
          WorkerRegistry, StatusTracker
TODO Stage 3: Attach KnowledgeGraph, ParserEngine
TODO Stage 4: Attach MemorySystem
TODO Stage 5: Attach ReasoningEngine, PlannerAgent
"""

from __future__ import annotations

from typing import Optional

from spectre.core.config import get_settings
from spectre.core.logger import get_logger, setup_logging
from spectre.core.settings import SpectreSettings
from spectre.plugins.registry import PluginRegistry
from spectre.sessions.manager import SessionManager

# Stage 2 imports
from spectre.core.tasks.events import EventBus
from spectre.core.tasks.queue import TaskQueue
from spectre.core.tasks.worker import WorkerRegistry, DEFAULT_WORKERS
from spectre.core.tasks.executor import ExecutionEngine
from spectre.core.tasks.scheduler import Scheduler
from spectre.core.tasks.status import StatusTracker

log = get_logger(__name__)


class SpectreApp:
    """Central application object — owns all subsystem instances."""

    def __init__(self, settings: Optional[SpectreSettings] = None) -> None:
        self.settings: SpectreSettings = settings or get_settings()
        setup_logging(self.settings.logging)

        # Stage 1
        self.session_manager  = SessionManager(settings=self.settings)
        self.plugin_registry  = PluginRegistry(settings=self.settings)

        # Stage 2
        self.event_bus        = EventBus()
        self.task_queue       = TaskQueue(maxsize=self.settings.task_engine.queue_maxsize)
        self.worker_registry  = WorkerRegistry()
        self.scheduler        = Scheduler(queue=self.task_queue)
        self.execution_engine = ExecutionEngine(
            queue=self.task_queue,
            worker_registry=self.worker_registry,
            event_bus=self.event_bus,
            max_concurrent=self.settings.task_engine.max_concurrent_tasks,
            task_timeout=self.settings.task_engine.task_timeout_seconds,
            scheduler=self.scheduler,
        )
        self.status_tracker   = StatusTracker(event_bus=self.event_bus)

        # TODO Stage 3: self.graph = KnowledgeGraph(app=self)
        # TODO Stage 4: self.memory = MemorySystem(app=self)
        # TODO Stage 5: self.reasoning = ReasoningEngine(app=self)

        self._ready: bool = False

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def initialize(self) -> None:
        """Full async startup — plugins, workers, scheduler, engine."""
        log.info("[Spectre initialized]")
        log.info("App version {} | environment: {}",
                 self.settings.app.version, self.settings.app.environment)

        self.plugin_registry.discover()

        for worker_cls in DEFAULT_WORKERS:
            await self.worker_registry.register(worker_cls())

        await self.scheduler.start()
        await self.execution_engine.start()

        self._ready = True
        log.success(
            "Spectre ready | plugins={} | workers={} | engine_slots={}",
            len(self.plugin_registry.plugins),
            len(self.worker_registry.list_workers()),
            self.settings.task_engine.max_concurrent_tasks,
        )

    def initialize_sync(self) -> None:
        """Sync shim for CLI commands — plugins only, no engine."""
        log.info("[Spectre initialized] (sync mode)")
        self.plugin_registry.discover()
        self._ready = True
        log.success("Spectre ready (sync) | plugins={}", len(self.plugin_registry.plugins))

    async def shutdown(self) -> None:
        """Graceful async shutdown."""
        log.info("Shutting down Spectre...")
        await self.execution_engine.stop()
        await self.scheduler.stop()
        await self.worker_registry.unregister_all()
        self.session_manager.save_all()
        self.plugin_registry.unload_all()
        log.info("Shutdown complete.")

    def shutdown_sync(self) -> None:
        """Sync shutdown for CLI contexts."""
        self.session_manager.save_all()
        self.plugin_registry.unload_all()

    # ------------------------------------------------------------------
    # Status
    # ------------------------------------------------------------------

    @property
    def is_ready(self) -> bool:
        return self._ready

    async def status(self) -> dict:
        """Full async status dict including engine metrics."""
        engine_stats = await self.execution_engine.stats()
        queue_stats  = await self.task_queue.stats()
        tracker      = self.status_tracker.cli_summary()

        return {
            "app":         self.settings.app.name,
            "version":     self.settings.app.version,
            "environment": self.settings.app.environment,
            "ready":       self._ready,
            "sessions": {
                "active": len([s for s in self.session_manager.list_sessions() if s.status == "active"]),
                "total":  len(self.session_manager.list_sessions()),
            },
            "plugins": {
                "loaded": len(self.plugin_registry.plugins),
                "names":  list(self.plugin_registry.plugins.keys()),
            },
            "logging": {
                "level": self.settings.logging.level,
                "file":  str(self.settings.logging.file_path),
            },
            "task_engine": {
                "running":   engine_stats["running"],
                "slots":     engine_stats["max_concurrent"],
                "active":    engine_stats["active_tasks"],
                "completed": engine_stats["completed_total"],
                "failed":    engine_stats["failed_total"],
                "retried":   engine_stats["retried_total"],
                "uptime":    engine_stats["uptime_seconds"],
            },
            "queue":        queue_stats,
            "task_summary": tracker,
            "workers": {
                "count": len(self.worker_registry.list_workers()),
                "types": [w["worker_type"] for w in self.worker_registry.list_workers()],
            },
        }

    def status_sync(self) -> dict:
        """Sync status snapshot for CLI without engine running."""
        return {
            "app":         self.settings.app.name,
            "version":     self.settings.app.version,
            "environment": self.settings.app.environment,
            "ready":       self._ready,
            "sessions": {
                "active": len([s for s in self.session_manager.list_sessions() if s.status == "active"]),
                "total":  len(self.session_manager.list_sessions()),
            },
            "plugins": {
                "loaded": len(self.plugin_registry.plugins),
                "names":  list(self.plugin_registry.plugins.keys()),
            },
            "logging": {
                "level": self.settings.logging.level,
                "file":  str(self.settings.logging.file_path),
            },
            "task_engine": {
                "running": False,
                "note":    "Use `spectre engine start` to activate the task engine",
            },
        }
