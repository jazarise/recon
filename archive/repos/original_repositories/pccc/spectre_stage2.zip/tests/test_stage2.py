"""
tests/test_stage2.py

Comprehensive test suite for Stage 2: Task Engine & Execution System.

Coverage:
  - Task model: fields, state machine, serialization
  - TaskQueue: add, get, remove, pause, resume, priority ordering
  - RetryEngine: classification, backoff, exhaustion
  - DependencyGraph: add nodes/edges, cycle detection, ready resolution
  - EventBus: subscribe, publish, wildcard, error isolation
  - Scheduler: submit, delay, dependency promotion
  - ExecutionEngine: start/stop, task dispatch, success/failure handling
  - StatusTracker: event-driven metric updates
  - Workers: lifecycle hooks, execute contract
  - Settings: TaskEngineSettings validation

Run with:
    pytest tests/test_stage2.py -v
    pytest tests/test_stage2.py -v -k "TestTask"
"""

from __future__ import annotations

import asyncio
import json
import sys
import time
from pathlib import Path
from typing import List
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

# Ensure project root is on path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


# ===========================================================================
# Helpers
# ===========================================================================

def make_task(name="test_task", task_type="generic", priority="normal",
              dependencies=None, max_retries=3, **kwargs):
    """Factory for Task objects with sensible defaults."""
    from spectre.core.tasks.task import Task, TaskType, TaskPriority, RetryPolicy
    type_map = {
        "generic": TaskType.GENERIC, "scan": TaskType.SCAN,
        "web": TaskType.WEB, "crypto": TaskType.CRYPTO,
        "parse": TaskType.PARSE, "forensics": TaskType.FORENSICS,
    }
    prio_map = {
        "critical": TaskPriority.CRITICAL, "high": TaskPriority.HIGH,
        "normal": TaskPriority.NORMAL, "low": TaskPriority.LOW,
        "idle": TaskPriority.IDLE,
    }
    return Task(
        name=name,
        type=type_map.get(task_type, TaskType.GENERIC),
        priority=prio_map.get(priority, TaskPriority.NORMAL),
        dependencies=dependencies or [],
        retry_policy=RetryPolicy(max_retries=max_retries),
        **kwargs,
    )


# ===========================================================================
# Component 1: Task Model
# ===========================================================================

class TestTaskModel:
    """Strongly-typed Pydantic task model."""

    def test_task_default_id_is_uuid(self):
        t = make_task()
        assert len(t.id) == 36
        assert t.id.count("-") == 4

    def test_task_name_required_and_stripped(self):
        from spectre.core.tasks.task import Task, TaskType
        t = Task(name="  padded  ", type=TaskType.GENERIC)
        assert t.name == "padded"

    def test_task_empty_name_raises(self):
        import pydantic
        from spectre.core.tasks.task import Task, TaskType
        with pytest.raises(pydantic.ValidationError):
            Task(name="   ", type=TaskType.GENERIC)

    def test_task_default_status_is_pending(self):
        from spectre.core.tasks.task import TaskStatus
        t = make_task()
        assert t.status == TaskStatus.PENDING

    def test_task_all_types_valid(self):
        from spectre.core.tasks.task import TaskType
        for tt in TaskType:
            t = make_task(task_type=tt.value)
            assert t.type == tt

    def test_task_all_priorities_valid(self):
        from spectre.core.tasks.task import TaskPriority
        for p in TaskPriority:
            t = make_task()
            t.priority = p
            assert t.priority == p

    def test_task_serializes_to_json(self):
        t = make_task(name="json_test")
        raw = t.model_dump_json()
        data = json.loads(raw)
        assert data["name"] == "json_test"
        assert "id" in data
        assert "status" in data

    def test_task_json_roundtrip(self):
        from spectre.core.tasks.task import Task
        t = make_task(name="roundtrip", task_type="scan")
        raw = t.model_dump_json()
        t2 = Task.model_validate_json(raw)
        assert t2.id == t.id
        assert t2.name == t.name
        assert t2.type == t.type

    def test_task_to_summary_keys(self):
        t = make_task()
        s = t.to_summary()
        assert {"id", "name", "type", "priority", "status", "retries", "elapsed", "session"} == set(s.keys())

    def test_task_is_terminal_completed(self):
        from spectre.core.tasks.task import TaskStatus
        t = make_task()
        t.status = TaskStatus.COMPLETED
        assert t.is_terminal()

    def test_task_is_terminal_cancelled(self):
        from spectre.core.tasks.task import TaskStatus
        t = make_task()
        t.status = TaskStatus.CANCELLED
        assert t.is_terminal()

    def test_task_pending_is_not_terminal(self):
        t = make_task()
        assert not t.is_terminal()

    def test_task_is_ready_no_deps(self):
        t = make_task()
        assert t.is_ready(set())

    def test_task_is_ready_with_completed_deps(self):
        dep_id = "abc-123"
        t = make_task(dependencies=[dep_id])
        assert not t.is_ready(set())
        assert t.is_ready({dep_id})

    def test_task_timestamps_created_at_set(self):
        t = make_task()
        assert t.timestamps.created_at is not None

    def test_retry_policy_backoff_exponential(self):
        from spectre.core.tasks.task import RetryPolicy
        rp = RetryPolicy(backoff_base=2.0, backoff_max=60.0)
        assert rp.backoff_delay(0) == 1.0
        assert rp.backoff_delay(1) == 2.0
        assert rp.backoff_delay(2) == 4.0
        assert rp.backoff_delay(10) == 60.0  # capped

    def test_task_lt_comparison_by_priority(self):
        t_high = make_task(priority="high")
        t_low  = make_task(priority="low")
        assert t_high < t_low


# ===========================================================================
# State Machine
# ===========================================================================

class TestTaskStateMachine:
    """Task state machine transitions."""

    def test_valid_transition_pending_to_queued(self):
        from spectre.core.tasks.task import TaskStatus
        t = make_task()
        t.transition(TaskStatus.QUEUED)
        assert t.status == TaskStatus.QUEUED

    def test_valid_transition_queued_to_running(self):
        from spectre.core.tasks.task import TaskStatus
        t = make_task()
        t.status = TaskStatus.QUEUED
        t.transition(TaskStatus.RUNNING)
        assert t.status == TaskStatus.RUNNING

    def test_valid_transition_running_to_completed(self):
        from spectre.core.tasks.task import TaskStatus
        t = make_task()
        t.status = TaskStatus.RUNNING
        t.transition(TaskStatus.COMPLETED)
        assert t.status == TaskStatus.COMPLETED

    def test_valid_transition_running_to_failed(self):
        from spectre.core.tasks.task import TaskStatus
        t = make_task()
        t.status = TaskStatus.RUNNING
        t.transition(TaskStatus.FAILED)
        assert t.status == TaskStatus.FAILED

    def test_invalid_transition_completed_to_running(self):
        from spectre.core.tasks.task import TaskStatus
        t = make_task()
        t.status = TaskStatus.COMPLETED
        with pytest.raises(ValueError):
            t.transition(TaskStatus.RUNNING)

    def test_invalid_transition_pending_to_completed(self):
        from spectre.core.tasks.task import TaskStatus
        t = make_task()
        with pytest.raises(ValueError):
            t.transition(TaskStatus.COMPLETED)

    def test_transition_stamps_timestamp(self):
        from spectre.core.tasks.task import TaskStatus
        t = make_task()
        t.transition(TaskStatus.QUEUED)
        assert t.timestamps.queued_at is not None

    def test_increment_retry_transitions_to_queued(self):
        from spectre.core.tasks.task import TaskStatus
        t = make_task(max_retries=3)
        t.status = TaskStatus.FAILED
        t.increment_retry()
        assert t.retries == 1
        assert t.status == TaskStatus.QUEUED

    def test_increment_retry_exhausted_raises(self):
        from spectre.core.tasks.task import TaskStatus
        t = make_task(max_retries=2)
        t.retries = 2
        t.status = TaskStatus.FAILED
        with pytest.raises(ValueError):
            t.increment_retry()


# ===========================================================================
# Component 2: Async Queue
# ===========================================================================

class TestTaskQueue:
    """Async priority task queue."""

    @pytest.fixture
    def queue(self):
        from spectre.core.tasks.queue import TaskQueue
        return TaskQueue()

    @pytest.mark.asyncio
    async def test_add_and_get_task(self, queue):
        t = make_task()
        await queue.add_task(t)
        got = await queue.get_task(timeout=1.0)
        assert got is not None
        assert got.id == t.id

    @pytest.mark.asyncio
    async def test_queue_size_increments(self, queue):
        for i in range(3):
            await queue.add_task(make_task(name=f"t{i}"))
        assert await queue.size() == 3

    @pytest.mark.asyncio
    async def test_priority_ordering(self, queue):
        """CRITICAL tasks should dequeue before LOW tasks."""
        t_low      = make_task(name="low",      priority="low")
        t_critical = make_task(name="critical", priority="critical")
        t_normal   = make_task(name="normal",   priority="normal")

        await queue.add_task(t_low)
        await queue.add_task(t_normal)
        await queue.add_task(t_critical)

        first  = await queue.get_task(timeout=0.5)
        second = await queue.get_task(timeout=0.5)
        third  = await queue.get_task(timeout=0.5)

        assert first.name  == "critical"
        assert second.name == "normal"
        assert third.name  == "low"

    @pytest.mark.asyncio
    async def test_fifo_within_same_priority(self, queue):
        """Tasks with equal priority must dequeue in insertion order."""
        tasks = [make_task(name=f"t{i}") for i in range(4)]
        for t in tasks:
            await queue.add_task(t)

        for t in tasks:
            got = await queue.get_task(timeout=0.5)
            assert got.id == t.id

    @pytest.mark.asyncio
    async def test_remove_task_cancels_it(self, queue):
        from spectre.core.tasks.task import TaskStatus
        t = make_task()
        await queue.add_task(t)
        ok = await queue.remove_task(t.id)
        assert ok is True
        assert t.status == TaskStatus.CANCELLED
        assert await queue.size() == 0

    @pytest.mark.asyncio
    async def test_remove_unknown_task_returns_false(self, queue):
        ok = await queue.remove_task("no-such-id")
        assert ok is False

    @pytest.mark.asyncio
    async def test_pause_task(self, queue):
        from spectre.core.tasks.task import TaskStatus
        t = make_task()
        await queue.add_task(t)
        ok = await queue.pause_task(t.id)
        assert ok is True
        assert t.status == TaskStatus.PAUSED
        assert await queue.size() == 0
        assert await queue.paused_count() == 1

    @pytest.mark.asyncio
    async def test_resume_task(self, queue):
        from spectre.core.tasks.task import TaskStatus
        t = make_task()
        await queue.add_task(t)
        await queue.pause_task(t.id)
        ok = await queue.resume_task(t.id)
        assert ok is True
        assert await queue.size() == 1
        assert await queue.paused_count() == 0

    @pytest.mark.asyncio
    async def test_get_by_id_returns_task(self, queue):
        t = make_task()
        await queue.add_task(t)
        found = await queue.get_by_id(t.id)
        assert found is not None
        assert found.id == t.id

    @pytest.mark.asyncio
    async def test_duplicate_add_raises(self, queue):
        t = make_task()
        await queue.add_task(t)
        t.status = type(t.status).PENDING  # reset for re-add attempt
        with pytest.raises((ValueError, Exception)):
            await queue.add_task(t)

    @pytest.mark.asyncio
    async def test_maxsize_raises_when_full(self):
        from spectre.core.tasks.queue import TaskQueue
        q = TaskQueue(maxsize=2)
        await q.add_task(make_task(name="a"))
        await q.add_task(make_task(name="b"))
        with pytest.raises(asyncio.QueueFull):
            await q.add_task(make_task(name="c"))

    @pytest.mark.asyncio
    async def test_get_task_timeout_returns_none(self, queue):
        got = await queue.get_task(timeout=0.05)
        assert got is None

    @pytest.mark.asyncio
    async def test_stats_structure(self, queue):
        stats = await queue.stats()
        assert "queued" in stats
        assert "enqueued_total" in stats
        assert "dequeued_total" in stats

    @pytest.mark.asyncio
    async def test_list_queued_sorted_by_priority(self, queue):
        await queue.add_task(make_task(name="idle", priority="idle"))
        await queue.add_task(make_task(name="high", priority="high"))
        listed = await queue.list_queued()
        assert listed[0].name == "high"

    @pytest.mark.asyncio
    async def test_peek_does_not_remove(self, queue):
        t = make_task()
        await queue.add_task(t)
        peeked = await queue.peek()
        assert peeked is not None
        assert await queue.size() == 1


# ===========================================================================
# Component 7: Retry Engine
# ===========================================================================

class TestRetryEngine:
    """Retry engine: classification, backoff, exhaustion."""

    def test_classify_timeout(self):
        from spectre.core.tasks.retry import classify_failure, FailureClass
        assert classify_failure(asyncio.TimeoutError()) == FailureClass.TIMEOUT

    def test_classify_connection_error(self):
        from spectre.core.tasks.retry import classify_failure, FailureClass
        assert classify_failure(ConnectionError()) == FailureClass.TRANSIENT_ERROR

    def test_classify_value_error(self):
        from spectre.core.tasks.retry import classify_failure, FailureClass
        assert classify_failure(ValueError()) == FailureClass.PERMANENT_ERROR

    def test_classify_from_message_timeout(self):
        from spectre.core.tasks.retry import classify_failure, FailureClass
        result = classify_failure(None, "operation timed out after 30s")
        assert result == FailureClass.TIMEOUT

    def test_classify_unknown(self):
        from spectre.core.tasks.retry import classify_failure, FailureClass
        assert classify_failure(None, "some random error") == FailureClass.UNKNOWN

    @pytest.mark.asyncio
    async def test_retry_schedules_requeue(self):
        from spectre.core.tasks.retry import RetryEngine
        from spectre.core.tasks.queue import TaskQueue
        from spectre.core.tasks.task import TaskStatus

        queue = TaskQueue()
        engine = RetryEngine(queue=queue)
        t = make_task(max_retries=3)
        t.status = TaskStatus.FAILED

        should_retry, delay = await engine.handle_failure(
            t, exc=asyncio.TimeoutError(), error_message="timeout"
        )

        assert should_retry is True
        assert delay > 0

    @pytest.mark.asyncio
    async def test_permanent_error_not_retried(self):
        from spectre.core.tasks.retry import RetryEngine
        from spectre.core.tasks.queue import TaskQueue
        from spectre.core.tasks.task import TaskStatus

        queue = TaskQueue()
        engine = RetryEngine(queue=queue)
        t = make_task(max_retries=5)
        t.status = TaskStatus.FAILED

        should_retry, delay = await engine.handle_failure(
            t, exc=ValueError("bad input"), error_message="invalid value"
        )
        assert should_retry is False

    @pytest.mark.asyncio
    async def test_exhausted_retries_not_retried(self):
        from spectre.core.tasks.retry import RetryEngine
        from spectre.core.tasks.queue import TaskQueue
        from spectre.core.tasks.task import TaskStatus, RetryPolicy

        queue = TaskQueue()
        engine = RetryEngine(queue=queue)
        t = make_task(max_retries=2)
        t.retries = 2
        t.status = TaskStatus.FAILED

        should_retry, _ = await engine.handle_failure(
            t, exc=asyncio.TimeoutError()
        )
        assert should_retry is False
        assert engine.stats()["exhausted_total"] == 1

    def test_backoff_delay_increases(self):
        from spectre.core.tasks.task import RetryPolicy
        rp = RetryPolicy(backoff_base=3.0, backoff_max=100.0)
        assert rp.backoff_delay(0) < rp.backoff_delay(1) < rp.backoff_delay(2)

    def test_backoff_delay_capped_at_max(self):
        from spectre.core.tasks.task import RetryPolicy
        rp = RetryPolicy(backoff_base=10.0, backoff_max=5.0)
        assert rp.backoff_delay(10) == 5.0


# ===========================================================================
# Component 6: Dependency Graph
# ===========================================================================

class TestDependencyGraph:
    """NetworkX-backed DAG for task dependency management."""

    @pytest.fixture
    def graph(self):
        from spectre.core.tasks.dependency_graph import DependencyGraph
        return DependencyGraph()

    def test_add_task_node(self, graph):
        graph.add_task("task-a", name="Task A")
        assert graph.node_count() == 1

    def test_add_dependency_edge(self, graph):
        graph.add_task("task-a", name="A")
        graph.add_task("task-b", name="B")
        graph.add_dependency("task-a", "task-b")
        assert graph.edge_count() == 1

    def test_is_ready_no_deps(self, graph):
        graph.add_task("standalone")
        assert graph.is_ready("standalone")

    def test_is_ready_with_unmet_dep(self, graph):
        graph.add_task("parent")
        graph.add_task("child")
        graph.add_dependency("parent", "child")
        assert not graph.is_ready("child")

    def test_is_ready_after_completion(self, graph):
        graph.add_task("parent")
        graph.add_task("child")
        graph.add_dependency("parent", "child")
        graph.mark_completed("parent")
        assert graph.is_ready("child")

    def test_cycle_detection_raises(self, graph):
        graph.add_task("a")
        graph.add_task("b")
        graph.add_task("c")
        graph.add_dependency("a", "b")
        graph.add_dependency("b", "c")
        with pytest.raises(ValueError, match="cycle"):
            graph.add_dependency("c", "a")

    def test_topological_order_correct(self, graph):
        graph.add_task("a")
        graph.add_task("b")
        graph.add_task("c")
        graph.add_dependency("a", "b")
        graph.add_dependency("b", "c")
        order = graph.topological_order()
        assert order.index("a") < order.index("b") < order.index("c")

    def test_get_dependents(self, graph):
        graph.add_task("parent")
        graph.add_task("child1")
        graph.add_task("child2")
        graph.add_dependency("parent", "child1")
        graph.add_dependency("parent", "child2")
        deps = graph.get_dependents("parent")
        assert set(deps) == {"child1", "child2"}

    def test_blocked_by_failure_transitive(self, graph):
        graph.add_task("a")
        graph.add_task("b")
        graph.add_task("c")
        graph.add_dependency("a", "b")
        graph.add_dependency("b", "c")
        blocked = graph.blocked_by_failure("a")
        assert "b" in blocked
        assert "c" in blocked

    def test_get_ready_tasks_from_candidates(self, graph):
        graph.add_task("a")
        graph.add_task("b")
        graph.add_dependency("a", "b")
        graph.mark_completed("a")
        ready = graph.get_ready_tasks({"a", "b"})
        assert "b" in ready

    def test_summary_structure(self, graph):
        s = graph.summary()
        assert "nodes" in s
        assert "edges" in s
        assert "completed" in s

    def test_remove_task(self, graph):
        graph.add_task("x")
        graph.remove_task("x")
        assert graph.node_count() == 0

    def test_unknown_node_is_not_ready(self, graph):
        assert not graph.is_ready("does-not-exist")


# ===========================================================================
# Component 8: Event Bus
# ===========================================================================

class TestEventBus:
    """Async publish/subscribe event bus."""

    @pytest.fixture
    def bus(self):
        from spectre.core.tasks.events import EventBus
        return EventBus()

    @pytest.mark.asyncio
    async def test_subscribe_and_publish(self, bus):
        from spectre.core.tasks.events import EventType, TaskCompletedEvent
        received = []

        async def handler(event):
            received.append(event)

        bus.subscribe(EventType.TASK_COMPLETED, handler)
        evt = TaskCompletedEvent(
            source="test", task_id="abc", task_name="t", task_type="generic",
        )
        await bus.publish(evt)
        assert len(received) == 1
        assert received[0].task_id == "abc"

    @pytest.mark.asyncio
    async def test_wildcard_receives_all_events(self, bus):
        from spectre.core.tasks.events import EventType, TaskStartedEvent, TaskFailedEvent
        all_events = []

        async def wildcard(event):
            all_events.append(event)

        bus.subscribe_all(wildcard)
        await bus.publish(TaskStartedEvent(source="t", task_id="1", task_name="a", task_type="scan"))
        await bus.publish(TaskFailedEvent(source="t", task_id="2", task_name="b", task_type="web", error="err"))
        assert len(all_events) == 2

    @pytest.mark.asyncio
    async def test_handler_exception_isolated(self, bus):
        """A failing handler must not prevent other handlers from running."""
        from spectre.core.tasks.events import EventType, TaskCompletedEvent
        second_called = []

        async def bad_handler(event):
            raise RuntimeError("I crash")

        async def good_handler(event):
            second_called.append(True)

        bus.subscribe(EventType.TASK_COMPLETED, bad_handler)
        bus.subscribe(EventType.TASK_COMPLETED, good_handler)

        await bus.publish(TaskCompletedEvent(
            source="test", task_id="x", task_name="n", task_type="generic",
        ))
        assert second_called  # good handler still ran
        assert bus.stats()["handler_errors"] == 1

    @pytest.mark.asyncio
    async def test_unsubscribe_removes_handler(self, bus):
        from spectre.core.tasks.events import EventType, TaskQueuedEvent
        called = []

        async def handler(event):
            called.append(event)

        bus.subscribe(EventType.TASK_QUEUED, handler)
        bus.unsubscribe(EventType.TASK_QUEUED, handler)
        await bus.publish(TaskQueuedEvent(source="t", task_id="1", task_name="a", task_type="x"))
        assert not called

    @pytest.mark.asyncio
    async def test_decorator_syntax(self, bus):
        from spectre.core.tasks.events import EventType, TaskCancelledEvent
        captured = []

        @bus.on(EventType.TASK_CANCELLED)
        async def on_cancel(event):
            captured.append(event)

        await bus.publish(TaskCancelledEvent(source="t", task_id="z", task_name="n", task_type="x"))
        assert len(captured) == 1

    @pytest.mark.asyncio
    async def test_recent_events_history(self, bus):
        from spectre.core.tasks.events import EventType, TaskStartedEvent
        for i in range(5):
            await bus.publish(TaskStartedEvent(
                source="t", task_id=str(i), task_name="n", task_type="x"
            ))
        assert len(bus.recent_events()) == 5

    def test_handler_count(self, bus):
        from spectre.core.tasks.events import EventType
        async def h(e): pass
        bus.subscribe(EventType.TASK_STARTED, h)
        bus.subscribe(EventType.TASK_STARTED, h)
        assert bus.handler_count(EventType.TASK_STARTED) == 2

    @pytest.mark.asyncio
    async def test_stats_published_counter(self, bus):
        from spectre.core.tasks.events import TaskCreatedEvent
        for _ in range(7):
            await bus.publish(TaskCreatedEvent(source="t", task_id="x", task_name="n", task_type="x"))
        assert bus.stats()["published_total"] == 7


# ===========================================================================
# Component 4: Workers
# ===========================================================================

class TestWorkers:
    """Worker base class and concrete implementations."""

    @pytest.mark.asyncio
    async def test_generic_worker_returns_success(self):
        from spectre.core.tasks.worker import GenericWorker
        w = GenericWorker()
        await w.on_startup()
        t = make_task()
        result = await w.execute(t)
        assert result.success is True
        assert result.worker_id == w.id

    @pytest.mark.asyncio
    async def test_scan_worker_returns_result(self):
        from spectre.core.tasks.worker import ScanWorker
        w = ScanWorker()
        t = make_task(task_type="scan", payload={"target": "10.0.0.1"})
        result = await w.execute(t)
        assert result.success is True
        assert "open_ports" in result.data

    @pytest.mark.asyncio
    async def test_web_worker_returns_result(self):
        from spectre.core.tasks.worker import WebWorker
        w = WebWorker()
        t = make_task(task_type="web", payload={"target": "http://example.com"})
        result = await w.execute(t)
        assert result.success is True
        assert "endpoints" in result.data

    @pytest.mark.asyncio
    async def test_crypto_worker_returns_result(self):
        from spectre.core.tasks.worker import CryptoWorker
        w = CryptoWorker()
        t = make_task(task_type="crypto", payload={"ciphertext": "ABCD"})
        result = await w.execute(t)
        assert result.success is True

    @pytest.mark.asyncio
    async def test_worker_exception_returns_failed_result(self):
        from spectre.core.tasks.worker import BaseWorker, GenericWorker
        from spectre.core.tasks.task import TaskResult

        class CrashWorker(GenericWorker):
            @property
            def worker_type(self): return "crash"
            async def _execute(self, task):
                raise RuntimeError("boom")

        w = CrashWorker()
        t = make_task()
        result = await w.execute(t)
        assert result.success is False
        assert "boom" in result.error

    @pytest.mark.asyncio
    async def test_worker_metrics_increment_on_success(self):
        from spectre.core.tasks.worker import GenericWorker
        w = GenericWorker()
        for _ in range(3):
            t = make_task()
            await w.execute(t)
        assert w._tasks_completed == 3
        assert w._tasks_failed == 0

    @pytest.mark.asyncio
    async def test_worker_describe_structure(self):
        from spectre.core.tasks.worker import ScanWorker
        w = ScanWorker()
        d = w.describe()
        assert d["worker_type"] == "scan"
        assert "handles" in d
        assert "tasks_completed" in d

    @pytest.mark.asyncio
    async def test_worker_registry_resolve_by_type(self):
        from spectre.core.tasks.worker import WorkerRegistry, ScanWorker
        from spectre.core.tasks.task import TaskType
        registry = WorkerRegistry()
        await registry.register(ScanWorker())
        t = make_task(task_type="scan")
        worker = registry.resolve(t)
        assert worker is not None
        assert worker.worker_type == "scan"

    @pytest.mark.asyncio
    async def test_worker_registry_fallback_to_generic(self):
        from spectre.core.tasks.worker import WorkerRegistry, GenericWorker
        registry = WorkerRegistry()
        await registry.register(GenericWorker())
        t = make_task(task_type="scan")   # no ScanWorker registered
        worker = registry.resolve(t)
        assert worker is not None
        assert worker.worker_type == "generic"

    @pytest.mark.asyncio
    async def test_all_default_workers_register(self):
        from spectre.core.tasks.worker import WorkerRegistry, DEFAULT_WORKERS
        registry = WorkerRegistry()
        for cls in DEFAULT_WORKERS:
            await registry.register(cls())
        assert len(registry.list_workers()) == len(DEFAULT_WORKERS)


# ===========================================================================
# Component 5: Scheduler
# ===========================================================================

class TestScheduler:
    """Dependency-aware scheduler."""

    @pytest.mark.asyncio
    async def test_submit_ready_task_goes_to_queue(self):
        from spectre.core.tasks.queue import TaskQueue
        from spectre.core.tasks.scheduler import Scheduler
        queue = TaskQueue()
        sched = Scheduler(queue=queue)
        await sched.start()

        t = make_task()
        await sched.submit(t)
        assert await queue.size() == 1

        await sched.stop()

    @pytest.mark.asyncio
    async def test_submit_with_unmet_deps_waits(self):
        from spectre.core.tasks.queue import TaskQueue
        from spectre.core.tasks.scheduler import Scheduler
        queue = TaskQueue()
        sched = Scheduler(queue=queue)
        await sched.start()

        parent = make_task(name="parent")
        child  = make_task(name="child", dependencies=[parent.id])

        await sched.submit(parent)
        await sched.submit(child)

        # Parent is ready immediately; child is still waiting
        assert await queue.size() == 1
        assert sched.waiting_count() == 1

        await sched.stop()

    @pytest.mark.asyncio
    async def test_notify_completed_unblocks_child(self):
        from spectre.core.tasks.queue import TaskQueue
        from spectre.core.tasks.scheduler import Scheduler
        queue = TaskQueue()
        sched = Scheduler(queue=queue)
        await sched.start()

        parent = make_task(name="parent")
        child  = make_task(name="child", dependencies=[parent.id])

        await sched.submit(parent)
        await sched.submit(child)

        # Dequeue parent
        await queue.get_task(timeout=0.5)
        # Notify completion
        await sched.notify_completed(parent.id)
        # Give scheduler a tick to promote child
        await asyncio.sleep(0.05)

        assert await queue.size() == 1
        got = await queue.get_task(timeout=0.5)
        assert got.name == "child"

        await sched.stop()

    @pytest.mark.asyncio
    async def test_delayed_task_promoted_after_delay(self):
        from spectre.core.tasks.queue import TaskQueue
        from spectre.core.tasks.scheduler import Scheduler
        queue = TaskQueue()
        sched = Scheduler(queue=queue)
        await sched.start()

        t = make_task(name="delayed")
        await sched.submit(t, delay_seconds=0.2)

        # Should not be queued immediately
        assert await queue.size() == 0

        # Wait for delay
        await asyncio.sleep(0.4)
        assert await queue.size() == 1

        await sched.stop()

    @pytest.mark.asyncio
    async def test_notify_failed_cancels_dependents(self):
        from spectre.core.tasks.queue import TaskQueue
        from spectre.core.tasks.scheduler import Scheduler
        from spectre.core.tasks.task import TaskStatus
        queue = TaskQueue()
        sched = Scheduler(queue=queue)
        await sched.start()

        parent = make_task(name="parent")
        child  = make_task(name="child", dependencies=[parent.id])

        await sched.submit(parent)
        await sched.submit(child)
        await queue.get_task(timeout=0.5)   # dequeue parent
        await sched.notify_failed(parent.id)
        await asyncio.sleep(0.05)

        assert child.status == TaskStatus.CANCELLED
        assert await queue.size() == 0

        await sched.stop()

    @pytest.mark.asyncio
    async def test_topological_order_no_cycle(self):
        from spectre.core.tasks.queue import TaskQueue
        from spectre.core.tasks.scheduler import Scheduler
        queue = TaskQueue()
        sched = Scheduler(queue=queue)
        await sched.start()

        a = make_task(name="a")
        b = make_task(name="b", dependencies=[a.id])
        c = make_task(name="c", dependencies=[b.id])

        await sched.submit(a)
        await sched.submit(b)
        await sched.submit(c)

        order = sched.topological_order()
        assert order.index(a.id) < order.index(b.id) < order.index(c.id)

        await sched.stop()

    @pytest.mark.asyncio
    async def test_stats_structure(self):
        from spectre.core.tasks.queue import TaskQueue
        from spectre.core.tasks.scheduler import Scheduler
        queue = TaskQueue()
        sched = Scheduler(queue=queue)
        await sched.start()
        stats = sched.stats()
        assert "submitted_total" in stats
        assert "waiting_deps" in stats
        assert "graph_summary" in stats
        await sched.stop()


# ===========================================================================
# Component 3: Execution Engine
# ===========================================================================

class TestExecutionEngine:
    """Central async orchestrator."""

    @pytest.fixture
    async def engine_setup(self):
        from spectre.core.tasks.queue import TaskQueue
        from spectre.core.tasks.worker import WorkerRegistry, GenericWorker
        from spectre.core.tasks.events import EventBus
        from spectre.core.tasks.executor import ExecutionEngine
        from spectre.core.tasks.scheduler import Scheduler

        queue    = TaskQueue()
        registry = WorkerRegistry()
        bus      = EventBus()
        sched    = Scheduler(queue=queue)

        await registry.register(GenericWorker())
        await sched.start()

        engine = ExecutionEngine(
            queue=queue,
            worker_registry=registry,
            event_bus=bus,
            max_concurrent=3,
            task_timeout=5.0,
            scheduler=sched,
        )
        yield engine, queue, bus, sched
        await engine.stop()
        await sched.stop()

    @pytest.mark.asyncio
    async def test_engine_starts_and_stops(self, engine_setup):
        engine, queue, bus, sched = engine_setup
        await engine.start()
        assert engine.is_running is True
        await engine.stop()
        assert engine.is_running is False

    @pytest.mark.asyncio
    async def test_engine_executes_task_and_completes(self, engine_setup):
        engine, queue, bus, sched = engine_setup
        await engine.start()

        t = make_task(name="should_complete")
        await queue.add_task(t)

        # Wait for execution
        await asyncio.sleep(0.3)

        from spectre.core.tasks.task import TaskStatus
        assert t.status == TaskStatus.COMPLETED
        assert t.result is not None
        assert t.result.success is True

    @pytest.mark.asyncio
    async def test_engine_emits_task_started_event(self, engine_setup):
        from spectre.core.tasks.events import EventType
        engine, queue, bus, sched = engine_setup
        started_events = []

        async def on_start(event):
            started_events.append(event)

        bus.subscribe(EventType.TASK_STARTED, on_start)
        await engine.start()

        t = make_task(name="event_test")
        await queue.add_task(t)
        await asyncio.sleep(0.3)

        assert len(started_events) >= 1

    @pytest.mark.asyncio
    async def test_engine_emits_task_completed_event(self, engine_setup):
        from spectre.core.tasks.events import EventType
        engine, queue, bus, sched = engine_setup
        completed = []

        async def on_complete(event):
            completed.append(event)

        bus.subscribe(EventType.TASK_COMPLETED, on_complete)
        await engine.start()

        t = make_task(name="comp_event_test")
        await queue.add_task(t)
        await asyncio.sleep(0.3)

        assert len(completed) >= 1

    @pytest.mark.asyncio
    async def test_engine_handles_no_worker_gracefully(self, engine_setup):
        """A task with no matching worker should fail, not crash the engine."""
        from spectre.core.tasks.task import TaskType, TaskStatus
        engine, queue, bus, sched = engine_setup

        # Only GenericWorker registered — give it a scan task with explicit worker_type
        await engine.start()
        t = make_task(name="no_worker_task", task_type="scan")
        t.worker_type = "nonexistent_worker"
        await queue.add_task(t)

        await asyncio.sleep(0.3)
        # Engine should still be running
        assert engine.is_running is True

    @pytest.mark.asyncio
    async def test_engine_stats_structure(self, engine_setup):
        engine, queue, bus, sched = engine_setup
        await engine.start()
        stats = await engine.stats()
        assert "running" in stats
        assert "completed_total" in stats
        assert "failed_total" in stats
        assert "queue" in stats
        assert "workers" in stats

    @pytest.mark.asyncio
    async def test_engine_processes_multiple_tasks(self, engine_setup):
        from spectre.core.tasks.task import TaskStatus
        engine, queue, bus, sched = engine_setup
        await engine.start()

        tasks = [make_task(name=f"batch_{i}") for i in range(5)]
        for t in tasks:
            await queue.add_task(t)

        await asyncio.sleep(0.5)

        completed = [t for t in tasks if t.status == TaskStatus.COMPLETED]
        assert len(completed) == 5


# ===========================================================================
# Component 9: Status Tracker
# ===========================================================================

class TestStatusTracker:
    """Event-driven status aggregation."""

    @pytest.fixture
    def tracker_with_bus(self):
        from spectre.core.tasks.events import EventBus
        from spectre.core.tasks.status import StatusTracker
        bus     = EventBus()
        tracker = StatusTracker(event_bus=bus)
        return tracker, bus

    @pytest.mark.asyncio
    async def test_tracker_counts_completed(self, tracker_with_bus):
        from spectre.core.tasks.events import TaskCompletedEvent
        tracker, bus = tracker_with_bus

        for i in range(3):
            await bus.publish(TaskCompletedEvent(
                source="engine", task_id=str(i),
                task_name=f"t{i}", task_type="generic",
            ))

        summary = tracker.cli_summary()
        assert summary["Completed"] == 3

    @pytest.mark.asyncio
    async def test_tracker_counts_failed(self, tracker_with_bus):
        from spectre.core.tasks.events import TaskFailedEvent
        tracker, bus = tracker_with_bus

        await bus.publish(TaskFailedEvent(
            source="engine", task_id="fail1", task_name="bad", task_type="scan", error="oops",
        ))
        assert tracker.cli_summary()["Failed"] == 1

    @pytest.mark.asyncio
    async def test_tracker_running_ids_update(self, tracker_with_bus):
        from spectre.core.tasks.events import TaskStartedEvent, TaskCompletedEvent
        tracker, bus = tracker_with_bus

        await bus.publish(TaskStartedEvent(
            source="engine", task_id="run1", task_name="running", task_type="web",
        ))
        assert len(tracker._running_ids) == 1

        await bus.publish(TaskCompletedEvent(
            source="engine", task_id="run1", task_name="running", task_type="web",
        ))
        assert len(tracker._running_ids) == 0

    @pytest.mark.asyncio
    async def test_tracker_recent_event_log(self, tracker_with_bus):
        from spectre.core.tasks.events import TaskStartedEvent
        tracker, bus = tracker_with_bus

        for i in range(5):
            await bus.publish(TaskStartedEvent(
                source="e", task_id=str(i), task_name=f"t{i}", task_type="x",
            ))

        log = tracker.recent_event_log(limit=10)
        assert len(log) == 5
        assert log[0]["status"] == "STARTED"

    @pytest.mark.asyncio
    async def test_tracker_snapshot_structure(self, tracker_with_bus):
        tracker, bus = tracker_with_bus
        snap = await tracker.snapshot()
        assert "tasks" in snap
        assert "running" in snap["tasks"]
        assert "completed" in snap["tasks"]

    @pytest.mark.asyncio
    async def test_tracker_retry_counter(self, tracker_with_bus):
        from spectre.core.tasks.events import TaskRetryingEvent
        tracker, bus = tracker_with_bus

        await bus.publish(TaskRetryingEvent(
            source="engine", task_id="r1", task_name="retry_me", task_type="scan",
            attempt=1, delay_seconds=2.0, reason="timeout",
        ))
        assert tracker.cli_summary()["Retried"] == 1


# ===========================================================================
# Settings: TaskEngineSettings
# ===========================================================================

class TestTaskEngineSettings:
    """Pydantic settings validation for Stage 2."""

    def test_task_engine_settings_defaults(self):
        from spectre.core.settings import TaskEngineSettings
        s = TaskEngineSettings()
        assert s.max_concurrent_tasks == 5
        assert s.task_timeout_seconds == 30.0
        assert s.queue_maxsize == 0

    def test_task_engine_settings_in_spectre_settings(self):
        from spectre.core.settings import SpectreSettings
        s = SpectreSettings()
        assert hasattr(s, "task_engine")
        assert s.task_engine.max_concurrent_tasks >= 1

    def test_max_concurrent_below_1_invalid(self):
        import pydantic
        from spectre.core.settings import TaskEngineSettings
        with pytest.raises(pydantic.ValidationError):
            TaskEngineSettings(max_concurrent_tasks=0)

    def test_backoff_base_below_1_invalid(self):
        import pydantic
        from spectre.core.settings import TaskEngineSettings
        with pytest.raises(pydantic.ValidationError):
            TaskEngineSettings(default_backoff_base=0.5)

    def test_task_timeout_below_1_invalid(self):
        import pydantic
        from spectre.core.settings import TaskEngineSettings
        with pytest.raises(pydantic.ValidationError):
            TaskEngineSettings(task_timeout_seconds=0.0)
