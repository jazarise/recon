"""
tests/test_stage2_integration.py

End-to-end integration tests for the Stage 2 task engine pipeline.

These tests spin up the full stack:
    TaskQueue + WorkerRegistry + EventBus + Scheduler + ExecutionEngine + StatusTracker

and verify that tasks flow correctly from submission to completion,
including dependency chains, retries, cancellations, and event emission.

Run with:
    pytest tests/test_stage2_integration.py -v
"""

from __future__ import annotations

import asyncio
import sys
from pathlib import Path
from typing import List

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


# ---------------------------------------------------------------------------
# Full stack fixture
# ---------------------------------------------------------------------------

@pytest.fixture
async def full_stack():
    """
    Spin up the complete Stage 2 pipeline:
        Queue → WorkerRegistry → EventBus → Scheduler → Engine → StatusTracker
    """
    from spectre.core.tasks.queue import TaskQueue
    from spectre.core.tasks.worker import WorkerRegistry, DEFAULT_WORKERS
    from spectre.core.tasks.events import EventBus
    from spectre.core.tasks.scheduler import Scheduler
    from spectre.core.tasks.executor import ExecutionEngine
    from spectre.core.tasks.status import StatusTracker

    queue    = TaskQueue()
    registry = WorkerRegistry()
    bus      = EventBus()
    sched    = Scheduler(queue=queue)
    tracker  = StatusTracker(event_bus=bus)

    for cls in DEFAULT_WORKERS:
        await registry.register(cls())

    await sched.start()

    engine = ExecutionEngine(
        queue=queue,
        worker_registry=registry,
        event_bus=bus,
        max_concurrent=4,
        task_timeout=10.0,
        scheduler=sched,
    )
    await engine.start()

    yield {
        "queue":    queue,
        "registry": registry,
        "bus":      bus,
        "sched":    sched,
        "engine":   engine,
        "tracker":  tracker,
    }

    await engine.stop()
    await sched.stop()
    await registry.unregister_all()


def make_task(name, task_type="generic", priority="normal", deps=None, **kw):
    from spectre.core.tasks.task import Task, TaskType, TaskPriority, RetryPolicy
    type_map = {t.value: t for t in TaskType}
    prio_map = {
        "critical": TaskPriority.CRITICAL, "high": TaskPriority.HIGH,
        "normal":   TaskPriority.NORMAL,   "low":  TaskPriority.LOW,
    }
    return Task(
        name=name,
        type=type_map.get(task_type, TaskType.GENERIC),
        priority=prio_map.get(priority, TaskPriority.NORMAL),
        dependencies=deps or [],
        **kw,
    )


# ---------------------------------------------------------------------------
# Integration tests
# ---------------------------------------------------------------------------

class TestFullPipeline:
    """End-to-end pipeline: submit → execute → complete → events."""

    @pytest.mark.asyncio
    async def test_single_task_completes(self, full_stack):
        from spectre.core.tasks.task import TaskStatus
        queue = full_stack["queue"]

        t = make_task("single_task")
        await queue.add_task(t)
        await asyncio.sleep(0.3)

        assert t.status == TaskStatus.COMPLETED
        assert t.result is not None
        assert t.result.success is True

    @pytest.mark.asyncio
    async def test_batch_of_tasks_all_complete(self, full_stack):
        from spectre.core.tasks.task import TaskStatus
        queue = full_stack["queue"]

        tasks = [make_task(f"batch_{i}") for i in range(8)]
        for t in tasks:
            await queue.add_task(t)

        await asyncio.sleep(0.8)

        completed = [t for t in tasks if t.status == TaskStatus.COMPLETED]
        assert len(completed) == len(tasks), (
            f"Only {len(completed)}/{len(tasks)} completed"
        )

    @pytest.mark.asyncio
    async def test_priority_tasks_complete_in_order(self, full_stack):
        """High-priority tasks should complete before low-priority tasks."""
        from spectre.core.tasks.task import TaskStatus
        from spectre.core.tasks.events import EventType, TaskCompletedEvent
        bus = full_stack["bus"]
        queue = full_stack["queue"]

        completion_order: List[str] = []

        async def on_complete(event: TaskCompletedEvent):
            completion_order.append(event.task_name)

        bus.subscribe(EventType.TASK_COMPLETED, on_complete)

        t_low  = make_task("low_prio",  priority="low")
        t_high = make_task("high_prio", priority="high")

        await queue.add_task(t_low)
        await queue.add_task(t_high)
        await asyncio.sleep(0.5)

        # High priority should appear first in completion order
        assert len(completion_order) == 2
        assert completion_order[0] == "high_prio"

    @pytest.mark.asyncio
    async def test_dependency_chain_executes_in_order(self, full_stack):
        """
        nmap → parser → web_workflow
        Each task must complete before the next is promoted.
        """
        from spectre.core.tasks.task import TaskStatus, TaskType
        queue = full_stack["queue"]
        sched = full_stack["sched"]
        bus   = full_stack["bus"]

        completion_order: List[str] = []
        from spectre.core.tasks.events import EventType, TaskCompletedEvent

        async def on_complete(event: TaskCompletedEvent):
            completion_order.append(event.task_name)

        bus.subscribe(EventType.TASK_COMPLETED, on_complete)

        nmap   = make_task("nmap_scan",   task_type="scan")
        parser = make_task("service_parse", task_type="parse", deps=[nmap.id])
        web    = make_task("web_workflow", task_type="web",   deps=[parser.id])

        await sched.submit(nmap)
        await sched.submit(parser)
        await sched.submit(web)

        await asyncio.sleep(1.0)

        assert completion_order == ["nmap_scan", "service_parse", "web_workflow"], (
            f"Wrong order: {completion_order}"
        )

    @pytest.mark.asyncio
    async def test_failed_task_cancels_dependents(self, full_stack):
        """
        A failing task must cascade cancellation to its dependents
        via the scheduler's notify_failed path.
        """
        from spectre.core.tasks.task import TaskStatus, TaskType
        from spectre.core.tasks.worker import BaseWorker, WorkerRegistry
        from spectre.core.tasks.events import EventType

        queue    = full_stack["queue"]
        sched    = full_stack["sched"]
        registry = full_stack["registry"]

        # Register a worker that always fails
        class FailWorker(BaseWorker):
            @property
            def worker_type(self): return "always_fail"
            @property
            def handles(self): return [TaskType.REASONING]   # use a unique type
            async def _execute(self, task):
                raise RuntimeError("Intentional failure")

        await registry.register(FailWorker())

        parent = make_task("will_fail",   task_type="reasoning")
        child  = make_task("will_cancel", task_type="generic", deps=[parent.id])

        await sched.submit(parent)
        await sched.submit(child)

        await asyncio.sleep(0.8)

        # Parent retries then fails permanently (max_retries=3 with backoff)
        # For this test, we check the scheduler cancelled the child immediately
        # Since retries have backoff, we check child was never promoted
        assert child.status in (TaskStatus.CANCELLED, TaskStatus.PENDING), (
            f"Child status should be CANCELLED or PENDING, got {child.status}"
        )

    @pytest.mark.asyncio
    async def test_events_emitted_for_full_lifecycle(self, full_stack):
        """Verify all lifecycle events are emitted for a single task."""
        from spectre.core.tasks.events import EventType
        bus   = full_stack["bus"]
        queue = full_stack["queue"]

        seen_events = set()

        async def record(event):
            seen_events.add(event.event_type)

        bus.subscribe_all(record)

        t = make_task("lifecycle_test")
        await queue.add_task(t)

        await asyncio.sleep(0.4)

        # Must have seen at minimum: queued, started, completed
        assert EventType.TASK_QUEUED    in seen_events
        assert EventType.TASK_STARTED   in seen_events
        assert EventType.TASK_COMPLETED in seen_events

    @pytest.mark.asyncio
    async def test_status_tracker_reflects_completions(self, full_stack):
        queue   = full_stack["queue"]
        tracker = full_stack["tracker"]

        n = 5
        for i in range(n):
            await queue.add_task(make_task(f"tracked_{i}"))

        await asyncio.sleep(0.5)

        summary = tracker.cli_summary()
        assert summary["Completed"] >= n, (
            f"Expected >= {n} completed, got {summary['Completed']}"
        )

    @pytest.mark.asyncio
    async def test_pause_and_resume_task(self, full_stack):
        """A paused task must not execute until resumed."""
        from spectre.core.tasks.task import TaskStatus
        queue = full_stack["queue"]

        t = make_task("pause_me")
        await queue.add_task(t)
        await queue.pause_task(t.id)

        await asyncio.sleep(0.2)
        # Still paused — not executed
        assert t.status == TaskStatus.PAUSED

        # Resume — should now execute
        await queue.resume_task(t.id)
        await asyncio.sleep(0.3)
        assert t.status == TaskStatus.COMPLETED

    @pytest.mark.asyncio
    async def test_task_cancellation_before_execution(self, full_stack):
        """A task cancelled from the queue must never execute."""
        from spectre.core.tasks.task import TaskStatus
        from spectre.core.tasks.events import EventType
        bus   = full_stack["bus"]
        queue = full_stack["queue"]

        started = []

        async def on_start(event):
            if event.task_name == "cancel_me":
                started.append(event)

        bus.subscribe(EventType.TASK_STARTED, on_start)

        t = make_task("cancel_me", priority="idle")  # low priority, cancels before slot picks it
        await queue.add_task(t)
        await queue.remove_task(t.id)  # cancel immediately

        await asyncio.sleep(0.2)

        assert t.status == TaskStatus.CANCELLED
        assert not started  # never started

    @pytest.mark.asyncio
    async def test_different_worker_types_dispatched_correctly(self, full_stack):
        """Tasks of different types should be routed to the correct worker."""
        from spectre.core.tasks.task import TaskStatus, TaskType
        from spectre.core.tasks.events import EventType, TaskCompletedEvent
        bus   = full_stack["bus"]
        queue = full_stack["queue"]

        results = {}

        async def on_complete(event: TaskCompletedEvent):
            results[event.task_name] = event.task_type

        bus.subscribe(EventType.TASK_COMPLETED, on_complete)

        tasks = [
            make_task("scan_task",     task_type="scan"),
            make_task("web_task",      task_type="web"),
            make_task("crypto_task",   task_type="crypto"),
            make_task("forensic_task", task_type="forensics"),
        ]

        for t in tasks:
            await queue.add_task(t)

        await asyncio.sleep(0.5)

        assert "scan_task"     in results
        assert "web_task"      in results
        assert "crypto_task"   in results
        assert "forensic_task" in results

    @pytest.mark.asyncio
    async def test_engine_stats_accurate_after_run(self, full_stack):
        queue  = full_stack["queue"]
        engine = full_stack["engine"]

        n = 6
        for i in range(n):
            await queue.add_task(make_task(f"stat_{i}"))

        await asyncio.sleep(0.5)

        stats = await engine.stats()
        assert stats["completed_total"] >= n
        assert stats["failed_total"] == 0
        assert stats["running"] is True

    @pytest.mark.asyncio
    async def test_delayed_task_eventually_executes(self, full_stack):
        """A delayed task must execute after its delay, not before."""
        from spectre.core.tasks.task import TaskStatus
        sched = full_stack["sched"]

        t = make_task("delayed_exec")
        await sched.submit(t, delay_seconds=0.3)

        # Not in queue yet
        queue = full_stack["queue"]
        await asyncio.sleep(0.1)
        assert t.status != TaskStatus.COMPLETED

        # After delay: should have executed
        await asyncio.sleep(0.6)
        assert t.status == TaskStatus.COMPLETED

    @pytest.mark.asyncio
    async def test_queue_stats_consistent(self, full_stack):
        queue = full_stack["queue"]

        for i in range(4):
            await queue.add_task(make_task(f"stats_{i}"))

        stats = await queue.stats()
        assert stats["enqueued_total"] >= 4

    @pytest.mark.asyncio
    async def test_multiple_dependency_levels(self, full_stack):
        """
        Four-level dependency chain:
            A → B → C → D
        All must complete in strict order.
        """
        from spectre.core.tasks.task import TaskStatus
        from spectre.core.tasks.events import EventType, TaskCompletedEvent

        bus   = full_stack["bus"]
        sched = full_stack["sched"]
        order: List[str] = []

        async def on_complete(event: TaskCompletedEvent):
            order.append(event.task_name)

        bus.subscribe(EventType.TASK_COMPLETED, on_complete)

        a = make_task("level_a")
        b = make_task("level_b", deps=[a.id])
        c = make_task("level_c", deps=[b.id])
        d = make_task("level_d", deps=[c.id])

        for t in [a, b, c, d]:
            await sched.submit(t)

        await asyncio.sleep(1.2)

        assert order == ["level_a", "level_b", "level_c", "level_d"], (
            f"Wrong execution order: {order}"
        )
